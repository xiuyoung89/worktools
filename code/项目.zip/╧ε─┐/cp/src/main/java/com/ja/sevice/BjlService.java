package com.ja.sevice;
import java.util.List;

import com.ja.domain.BaccaratBulletin;
import com.ja.domain.Bjl;
import com.ja.domain.BjlMoney;
import com.ja.domain.Bjldata;
import com.ja.domain.Lotter;
import com.ja.domain.Records;
import com.ja.domain.User;
import com.ja.domain.Yb;
/**
 * 百家乐
 * @author Administrator
 *
 */
public interface BjlService {
	
	/**
	 * 根据id查询用户金额
	 * @param userid
	 * @return
	 */
	Double Money(Integer userid);
	
	Lotter bjlpl(String name,String cname);
	/**
	 * 用户下注减钱
	 * @param money
	 * @param id
	 * @return
	 */
	int Moneyxg(Double money,Integer id);
	
	List<Records> hRecords1(Integer userid);
	

	public List<BaccaratBulletin> tableNumber();
	/**
	 * 查询历史开奖记录
	 * @param zh
	 * @return
	 */
	 List<Bjldata> history(Integer tableNumber);
	
	/**添加用户的下注金额以及开奖金额信息@param moneys 订单信息 @return*/
	int addOrderInfo(BjlMoney moneys);
	
	/** 查询用户的下注金额以及开奖金额信息@param moneys 订单信息 @return*/
	BjlMoney findUserOrderInfo(BjlMoney moneys);
	
	void insertbjl();
	/**
	 * 删除试玩账号订单
	 * @return
	 */
	int deletebjl(Integer userid);
	
	/**
	 * 插入百家乐开奖数据
	 * @param list
	 * @return
	 */
	int insertBjlData(List<Bjldata> list);
	
	/**
	 * 生成百家乐开奖数据
	 * @param num
	 * @return
	 */
	public void ississueNumber(int num);
	
	/**
	 * 查询数据库里面百家乐最新开奖的一条数据
	 * @param tableNumber
	 * @param nowTime
	 * @return
	 */
	Bjldata NewestData(Integer tableNumber,String nowTime);
	/**
	* 倒计时派奖1号桌
	 */
	void table1();
	
	/**
	* 倒计时派奖2号桌
	 */
	void table2();
	/**
	* 倒计时派奖3号桌
	 */
	void table3();
	/**
	* 倒计时派奖4号桌
	 */
	void table4();
	/**
	* 倒计时派奖5号桌
	 */
	void table5();
	/**
	 * 倒计时派奖6号桌
	 */
	void table6();
	/**
	 * 处理用户下注信息
	 * @param b
	 * @return
	 */
	int bjlBets(Bjl b,User user);
	/**
	 * 开奖
	 * @param tableNumber
	 * @param issueNumber
	 * @return
	 */
	int Lottery(Bjldata data);
	/**
	 * 开启
	 */
	void open();
	/**
	 * 每天00.00.00定时生成开奖数据
	 */
	void timingTask();
	/**
	 * 查询百家乐开奖数据
	 * @param b
	 * @return
	 */
	Bjldata bjlLotter(Bjl b);
	/**
	 * 获取百家乐全部数据
	 * @return
	 */
	List<Bjldata> bjlRoom();
	/**
	 * 查询百家乐开奖数据
	 * @param b
	 * @return
	 */
	Bjldata takeAwayTheAwardData(Bjl b);
	
	/**
	 * 返回硬币
	 * @param data
	 * @return
	 */
	List<Yb> coin(Yb data,Integer tableNumber);
	/***
	 * 用户下注以及中奖的金额信息
	 * @param table_num 桌号
	 * @param period 期号
	 * @param session session对象
	 * @return
	 */
	String findUserMoneyInfo(Integer userid,String tableNumber, String issueNumber);
	/**
	 * 查询百家乐开奖数据 默认查询前50条
	 * @param tableNumber  房间号
	 * @return 查询到数据则返回list集合包含bjl对象 如果没有查询到则返回一个空集合
	 */
	List<Bjldata>  bjlkaijiangjilu(Integer tableNumber);
	/**
	 * 查询百家乐开奖数据
	 * @param time 查询那一天的  日期
	 * @param tableNumber查询那一桌
	 * @return 查询到数据则返回list集合 没有查询到则返回一个空集合
	 */
	List<Bjldata> findTrendBjl(String time,Integer tableNumber,String issueNumber);
	/**
	 * 根据数据库下标id查询用户下注记录
	 * @param id  数据库下标id
	 * @return 查询到则返回Bjl对象数据  没有查询到则返回null
	 */
	Bjl bettingRecord(String name,Integer id);
	
}
