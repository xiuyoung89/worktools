package com.ja.sevice.impl;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.DigestUtils;

import com.ja.dao.AMapper;
import com.ja.dao.BjlMapper;
import com.ja.dao.DamalMapper;
import com.ja.dao.LiushuiMapper;
import com.ja.dao.LuckyCountMapper;
import com.ja.dao.OrderMapper;
import com.ja.dao.UserMapper;
import com.ja.domain.Admin;
import com.ja.domain.AdminUser;
import com.ja.domain.Damal;
import com.ja.domain.Logonlog;
import com.ja.domain.LuckyCount;
import com.ja.domain.Operationlog;
import com.ja.domain.User;
import com.ja.sevice.BackManagerService;
import com.ja.util.DateUtil;

public class BackManagerServiceImpl implements BackManagerService{
	
	@Autowired
	private AMapper managerMapper;
	
	@Autowired
	private UserMapper userMapper;
	
	@Autowired
	private DamalMapper damalMapper;
	
	@Autowired
	private LuckyCountMapper luckyCountMapper;
	
	@Autowired
	private OrderMapper orderMapper;
	
	@Autowired
	private LiushuiMapper liushuiMapper;
	
	@Autowired
	private BjlMapper bjlMapper;
	
	@Override
	public int createdUserAccountInfo(User user) {
		String md5 = DigestUtils.md5DigestAsHex(user.getPass().getBytes());
		String pwd = DigestUtils.md5DigestAsHex(md5.getBytes());
		User users1 = new User();
		users1.setName(user.getName());
		users1.setNicheng(user.getName());
		users1.setAvatar("img/user.jpg");
		users1.setPass(pwd);
		users1.setBalance(user.getBalance());
		users1.setFid(0);
		users1.setVip("VIP1");
		users1.setOdds(0.000);
		users1.setState(user.getState());
		users1.setTelephone(user.getTelephone());
		users1.setQq(user.getQq());
		users1.setRegisterIp(user.getRegisterIp());
		users1.setLastIp(user.getRegisterIp());
		users1.setRegisterTime(DateUtil.getCurrTime());
		users1.setLastTime(DateUtil.getCurrTime());
		users1.setNotTime("未登录0天");
		users1.setCreatetime(DateUtil.getCurrTime());
		int line = userMapper.register(users1);

		User userInfo = userMapper.checkUser(user.getName());
		Damal damal = new Damal();// 用户打码
		damal.setHuiyuanzh(user.getName());
		damal.setCreatetime(user.getCreatetime());
		damal.setTikuansx(0.00);
		damal.setUserid(userInfo.getId());
		damalMapper.addamal(damal);
		LuckyCount counts = new LuckyCount();//幸运抽奖
		counts.setName(user.getName());
		counts.setCount(0);
		counts.setCreateTime(DateUtil.getCurrTime());
		counts.setUserid(userInfo.getId());
		luckyCountMapper.addLuckyCount(counts);
		return line;
	}
	
	
	@Override
	public AdminUser admin(String name,String pass) {
		AdminUser admin1 = managerMapper.admin(name,pass);
		return admin1;
	}
	
	
	@Override
	public List<AdminUser> Allusers() {
		List<AdminUser> admin1 = managerMapper.Allusers();
		return admin1;
	}
	
	@Override
	public void logonlog(String accountnumber, String superrecord, String ip, String operationtime,String time) {
		int num = managerMapper.logonlog(accountnumber, superrecord, ip, operationtime,time);
		if(num == 1){
			
		}
	}

	@Override
	public Integer registerAdminUser(AdminUser admin) {
		admin.setCreated_time(DateUtil.getCurrTime());
		managerMapper.registerAdminUser(admin);
		return admin.getId();
	}
	
	@Override
	public AdminUser IP(String ip) {
		return managerMapper.IP(ip);
	}
	
	@Override
	public String updateAdminUser(AdminUser admin) {
		int num = managerMapper.updateAdminUser(admin);
		if(num != 1){
			return "修改失败";
		}
		return "修改成功";
	}
	
	/**
	 * 禁用-启用
	 */
	@Override
	public int jyqy(int state,String name) {
		return managerMapper.jyqy(state, name);
	}
	/**
	 * 删除后台用户
	 */
	@Override
	public int adminsc(String name) {
		return managerMapper.adminsc(name);
	}
	@Override
	public List<Operationlog> operationlog(String time) {
		return managerMapper.operationlog(time);
	}
	//添加内部账号
	@Override
	public int register(String name, double balance,String pass, String qq, String ip, String telephone, int state) {
		String str =  managerMapper.yhcx(name);
		if(str == null){
			String md5 = DigestUtils.md5DigestAsHex(pass.getBytes());
			String pwd = DigestUtils.md5DigestAsHex(md5.getBytes());
			return managerMapper.register(name, balance,pwd, qq, ip, telephone, state);
		}
		return 2;
	}
	
	@Override
	public int modifyurl(String url) {
		return managerMapper.modifyurl(url);
	}
	@Override
	public int setup(String money) {
		return managerMapper.setup(money);
	}
	@Override
	public int updatawhole(String time,String redenvelopes,String leavingamessage,String typeofredenvelopes,int numberofredpackets) {
		return managerMapper.updatawhole(time,redenvelopes,leavingamessage,typeofredenvelopes,numberofredpackets);
	}
	@Override
	public Admin inquireAll() {
		return managerMapper.inquireAll();
	}
	@Override
	public List<AdminUser> findAllAdminInfo() {
		return managerMapper.findAllAdminInfo();
	}
	
	@Override
	public int deleteKeFuUser(Integer id) {
		managerMapper.delPower(id);
		return managerMapper.deleteKeFuUser(id);
	}
	@Override
	public AdminUser findByIdAmdinUser(Integer id) {
		return managerMapper.findByIdAmdinUser(id);
	}
	@Override
	public int updatagg(String notice) {
		return managerMapper.updatagg(notice);
	}
	@Override
	public String querygg() {
		return managerMapper.querygg();
	}

	@Override
	public int recyclingTrialAccount() {
		System.out.println("正在回收试玩账号");
		List<User> user = userMapper.timingRecovery();
		for (User u : user) {
			try {
				SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
				long nowTime = new Date().getTime();
				Date date = sdf.parse(u.getRegisterTime());
				long lastTime = date.getTime();//试玩账号创建的时间
				long time=(nowTime-lastTime) /1000;//时间相减比较。
				long hh = time / 60 / 60 % 60;
				if(hh >= 48) {
					orderMapper.deleteOrderInfo(u.getId());//删除订单
					liushuiMapper.deleteliushui(u.getId());//删除流水
					bjlMapper.deletebjl(u.getId());//删除百家乐订单
					userMapper.timeDeleting(u.getId());//删除用户
				}
			} catch (ParseException e) {}
		}
		return 1;
	}

	@Override
	public AdminUser findByAdminUserInfo(String name) {
		return managerMapper.findByAdminUserInfo(name);
	}

	@Override
	public int addUserJurisdiction(AdminUser users) {
		return managerMapper.addUserJurisdiction(users);
	}

	@Override
	public AdminUser findUserJurisdiction(String name) {
		return managerMapper.findUserJurisdiction(name);
	}

	@Override
	public int updateUserJurisdiction(AdminUser user) {
		return managerMapper.updateUserJurisdiction(user);
	}

	@Override
	public List<Logonlog> findUserLoginLog(String time) {
		return managerMapper.findUserLoginLog(time);
	}
	
}
