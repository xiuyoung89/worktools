package com.ja.dao;

import java.util.List;

import com.ja.domain.KeyWords;

/**
 * TODO java文件
 * @Title　KeyWodsMapper.java
 * @Vers　v1.0
 * @AUTH　Bean
 * @Time　2018年5月23日 上午10:06:51
 */
public interface KeyWordsMapper {
	int insert(KeyWords keyWords);
	int update(KeyWords keyWords);
	int delById(KeyWords keyWords);
	KeyWords selectById();
	List<KeyWords> selectAll();
}
