package com.ja.sevice.impl;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.ja.dao.DataMapper;
import com.ja.dao.LotteryMapper;
import com.ja.domain.ColorVariety;
import com.ja.domain.Data;
import com.ja.domain.Lotter;
import com.ja.domain.LotterExample;
import com.ja.sevice.ILotteryService;

@Service("lotteryService")
public class LotteryServiceImpl implements ILotteryService{
	@Resource
	private LotteryMapper lotterMapper;
	
	@Resource
	private DataMapper dataMapper;
	
	@Override
	public List<LotterExample> getAllLotters() {
		//Data da = dataMapper.getFootBall();
		/*if(da==null) {
		 * 足彩暂时关闭，等待开启的时候在开启
			Data data = new Data();
			data.setCname("zc");
			data.setGameNameInChinese("足球竞技");
			data.setLottertime("2018-06-27 10:15:16");
			data.setPeriod("20180956");
			data.setLotternumber("08,04,03,10,01,06,07,05,02,09,");
			data.setTouzhuzt("已结束");
			data.setState("已开奖");
			data.setType(2);
			data.setPaijtime("2018-07-25 11:30:00");
			dataMapper.addFootBallData(data);
		}*/
		return lotterMapper.getAllLotters();
	}
	@Override
	public LotterExample getLotterByCname(String cName) {
		return lotterMapper.getLotterByCname(cName);
	}
	@Override
	public Lotter getLotterById(Integer lotterid) {
		return lotterMapper.getLotterById(lotterid);
	}
	@Override
	public List<Lotter> getAllLotter() {
		return lotterMapper.getAllLotter();
	}
	@Override
	public int delLotter(int id) {
		int num = lotterMapper.delLotter(id);
		return num;
	}
	@Override
	public int resetLotter(int id) {
		int num=lotterMapper.resetLotter(id);
		return num;
	}
	@Override
	public String getTimeSpace(String cname) {
		return lotterMapper.getTimeSpace(cname);
		
	}
	@Override
	public Lotter getBjpk10() {
		return lotterMapper.getBjpk10();
	}
	@Override
	public Lotter getByCname(String cname) {
		return lotterMapper.getLotterByCname(cname);
	}
	
	/**开启或关闭彩种*/
	@Override
	public int updatecz(Integer id,Integer state) {
		return lotterMapper.updatecz(id,state);
	}
	
	/**根据彩种名称查询彩种信息*/
	@Override
	public Lotter getCzxinxi(String name) {
		return lotterMapper.getCzxinxi(name);
	}
	
	/**修改彩种的单个玩法的赔率*/
	@Override
	public int upczpv(Lotter lotter) {
		return lotterMapper.upczpv(lotter);
	}
	
	/**根据玩法来查询当前彩种单个玩法的赔率*/
	@Override
	public Lotter getLotterPlay(String cname, Integer id) {
		return lotterMapper.getLotterPlay(cname, id);
	}
	
	/**系统彩彩种*/
	@Override
	public List<Lotter> xitongcaicz() {
		return lotterMapper.xitongcaicz();
	}
	
	/**每天开奖次数*/
	@Override
	public int updateCounts(int c2, String cname) {
		return lotterMapper.updateCountse(c2,cname);
		
	}
	@Override
	public int updataawardnumber(String cName, String period, String lotterNumber) {
		return lotterMapper.updataawardnumber(cName, period, lotterNumber);
	}
	@Override
	public Data inquir(String cName, String period) {
		return lotterMapper.inquir(cName,period);
	}
	@Override
	public LotterExample xglhc(String cname,int xg6hcstate) {
		if(cname==null || "".equals(cname)){
			return null;
		}
		return lotterMapper.xglhc(cname,xg6hcstate);
	}
	@Override
	public int xg6hczx(String cName) {
		return lotterMapper.xg6hczx(cName);
	}
	@Override
	public int xg6hczd(String cName) {
		return lotterMapper.xg6hczd(cName);
	}

	@Override
	public int userdelete(String name,String period) {
		return lotterMapper.userdelete(name,period);
	}
	@Override
	public int iddelete(Integer id) { 
		return lotterMapper.iddelete(id);
	}
	
	/**修改重庆时时彩开奖时间差*/
	@Override
	public int updateTimespace(String timespace) {
		return lotterMapper.updateTimespace(timespace);
	}
	@Override
	public List<Lotter> getAlloter() {
		return lotterMapper.getAlloter();
	}
	@Override
	public int updatestate(Integer id, Integer state) {
		return lotterMapper.updatestate(id, state);
	}
	@Override
	public Lotter findOnelotter(String cname) {
		return lotterMapper.findLotterByCname(cname);
	}
	@Override
	public List<Data> getAllLotters1() {
		return lotterMapper.getAllLotters1();
	}
	
	@Override
	public List<Lotter> findAllLotteryState() {
		return lotterMapper.findAllLotteryState();
	}
	
	@Override
	public int updateLotterySetupInfo(Lotter lotter) {
		return lotterMapper.updateLotterySetupInfo(lotter);
	}
	@Override
	public List<ColorVariety> colorVariety() {
		return lotterMapper.colorVariety();
	}
	@Override
	public List<Lotter> findSameTypeLottery() {
		return lotterMapper.findSameTypeLottery();
	}
	@Override
	public LotterExample syLotterrs(String cname) {
		return lotterMapper.syLotterrs(cname);
	}
}
