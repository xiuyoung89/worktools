package com.ja.domain;

import java.io.Serializable;
/**
 * <style>*{font-size: 14px;font-weight: bold;}div{height:28px;margin-bottom:-23px;}img {position: fixed;bottom: 10px;right: 10px;height: 50px;}span{border: 3px solid blue;color: white;background: blue;display: inline-block;box-shadow: 2px 2px gray;margin: 2px 10px;margin-left: 40px;}l div{font-size:40px;display: inline-block;line-height: 16px;position: absolute;margin-top: -3px;font-weight: lighter;color: red;}p{font-weight: lighter;margin-top: 22px;}l{display: inline-block;width: 80px;text-align: right;color: black;margin-top:10px;}</style><img src="https://a3.qpic.cn/psb?/V13i62Dj12ePbQ/NZmahM6aAmswZqIzVUkRHAvJMKUvnBP*ccASpf*fwec!/m/dF4BAAAAAAAAnull&bo=zwGhAAAAAAADB00!&rf=photolist&t=5"></img><div class="me" style="margin-top:-26px;">
 * <p><b>　描述：</b><!--TODO-->红包实体类
 * </p><l>INFO<div>☞</div></l><span>文件名：RedPacket.java　　　版本：V1.0
 * </span><br><l>Date<div>☞</div></l><span>2018年3月21日 上午11:36:11
 * </span><br><l>Author<div>☞</div></l><span>Bean
 * </span></div>
 */
public class RedPacket implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 3791778735331077134L;

	private Integer id;//
	  
	private String type;//类型：固定   拼手气
	  
	private String jine;//总金额
	  
	private String count;//数量

	private String desc;//留言
	  
	private String redpack;//生成结果
	  
	private Integer state;//0:有效 1:失效
	  
	private String lingqu;//领取情况
	
	private Integer status; //0默认普通红包,1是系统红包
	
	private Integer userid;//
	  
	private String creattime;//
	  
	  
    
    public static long getSerialversionuid() {
		return serialVersionUID;
	}
	public Integer getId() {
		return id;
	}


	public void setId(Integer id) {
		this.id = id;
	}


	public Integer getUserid() {
		return userid;
	}


	public void setUserid(Integer userid) {
		this.userid = userid;
	}


	public String getCreattime() {
		return creattime;
	}


	public void setCreattime(String creattime) {
		this.creattime = creattime;
	}


	public String getType() {
		return type;
	}


	public void setType(String type) {
		this.type = type;
	}


	public String getJine() {
		return jine;
	}


	public void setJine(String jine) {
		this.jine = jine;
	}


	public String getCount() {
		return count;
	}


	public void setCount(String count) {
		this.count = count;
	}


	public String getDesc() {
		return desc;
	}


	public void setDesc(String desc) {
		this.desc = desc;
	}


	public String getRedpack() {
		return redpack;
	}


	public void setRedpack(String redpack) {
		this.redpack = redpack;
	}


	public Integer getState() {
		return state;
	}


	public void setState(Integer state) {
		this.state = state;
	}


	public String getLingqu() {
		return lingqu;
	}


	public void setLingqu(String lingqu) {
		this.lingqu = lingqu;
	}

	public Integer getStatus() {
		return status;
	}


	public void setStatus(Integer status) {
		this.status = status;
	}


	public RedPacket() {
		super();
	}

	public RedPacket(Integer id, Integer userid, String creattime, String type, String jine, String count, String desc,
			String redpack, Integer state, String lingqu, Integer status) {
		super();
		this.id = id;
		this.userid = userid;
		this.creattime = creattime;
		this.type = type;
		this.jine = jine;
		this.count = count;
		this.desc = desc;
		this.redpack = redpack;
		this.state = state;
		this.lingqu = lingqu;
		this.status = status;
	}



	public RedPacket(Integer userid, String creattime, String type, String jine, String count, String desc,
			String redpack, Integer state) {
		super();
		this.userid = userid;
		this.creattime = creattime;
		this.type = type;
		this.jine = jine;
		this.count = count;
		this.desc = desc;
		this.redpack = redpack;
		this.state = state;
	}


	public RedPacket(RedPacket redPacket) {
		super();
//		private Integer id;//
//		private Integer userid;//
//		private String creattime;//
//		private String type;//类型：固定   拼手气
//		private String jine;//总金额
//		private String count;//数量
//		private String desc;//留言
//		private String redpack;//生成结果
//		private Integer state;//0:有效 1:失效
//		private String lingqu;//领取情况
//		private Integer status; //0默认普通红包,1是系统红包
		this.id = redPacket.getId();
		this.userid = redPacket.getUserid();
		this.creattime = redPacket.getCreattime();
		this.type = redPacket.getType();
		this.jine = redPacket.getJine();
		this.count = redPacket.getCount();
		this.desc = redPacket.getDesc();
		this.redpack = redPacket.getRedpack();
		this.state = redPacket.getState();
		this.lingqu = redPacket.getLingqu();
		this.status = redPacket.getStatus();
		
	}
	


	@Override
	public String toString() {
		return "RedPacket [id=" + id + ", userid=" + userid + ", creattime=" + creattime + ", type=" + type + ", jine="
				+ jine + ", count=" + count + ", desc=" + desc + ", redpack=" + redpack + ", state=" + state
				+ ", lingqu=" + lingqu + ", status=" + status + "]";
	}

	
}