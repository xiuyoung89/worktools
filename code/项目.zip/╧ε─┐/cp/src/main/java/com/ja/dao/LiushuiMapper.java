package com.ja.dao;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.ja.domain.Liushui;
import com.ja.domain.Lsltjl;
import com.ja.domain.PagingData;
import com.ja.domain.TodayRecord;
import com.ja.domain.User;
import com.ja.domain.YunyingJl;

public interface LiushuiMapper {
	
	/**
	 * 
	 * ----TODO：报表管理
	 * 
	 */
	
	/**
	 * 	 报表管理--全局报表(财务报表,统计概况,运营报表)	
	 *   方法名：findByUserNameTimeTodayRecord   
	 *   描述：    根据时间和名称查询统计                      
	 *   参数：    @param date 今天时间
	 *   参数：    @param userName 用户名称
	 *   参数：    @return 
	 * @return: TodayRecord
	 */
	TodayRecord findByUserNameTimeTodayRecord(@Param("date")String date, @Param("userName")String userName);

	/**
	 * 	 报表管理--财务报表
	 *   方法名：findAllFinanceReport   
	 *   描述：     查询用户的存款以及提款次数                     
	 *   参数：    @param startTime 开始时间
	 *   参数：    @param endTime 结束时间
	 *   参数：    @param userName 用户名
	 *   参数：    @param type 查询类型
	 *   参数：    @return 
	 * @return: Integer
	 */
	Integer findAllFinanceReport(@Param("startTime")String startTime, @Param("endTime")String endTime, @Param("userName")String userName,@Param("type")String type);
	
	/**
	  *   方法名：findByUserIdTimeTodayRecord   
	  *   描述：     查询用户和平台昨天的总计                     
	  *   参数：    @param id
	  *   参数：    @param findLatelyDate
	  *   参数：    @return 
	 * @return: TodayRecord
	 */
	TodayRecord findByUserIdTimeTodayRecord(@Param("user_id")Integer user_id, @Param("date")String date,@Param("type")Integer type);

	/**
	  *   方法名：findByTimeUserRechargeTotal   
	  *   描述：   查询用户每天-每月的充值总计                       
	  *   参数：    @param id
	  *   参数：    @return 
	 * @return: TodayRecord
	 */
	TodayRecord findByTimeUserRechargeTotal(@Param("date1")String date1,@Param("date2")String date2,@Param("user_id")Integer user_id);

	/**
	  * 方法名：addUserFlowingWaterRecrod 
	  * 描述：    添加用户的流水记录                  
	  * 参数：    @return 
	 * @return: int
	 */
	int addUserFlowingWaterRecrod(Liushui water);
	
	/**
	  * 方法名：getLiushui 
	  * 描述：    查询用户的流水记录                  
	  * 参数：    @param userid
	  * 参数：    @return 
	 * @return: List<Liushui>
	 */
	List<Liushui> getLiushui(Integer userid);
	
	
	
   
	/**查询所有流水
	 * @param i 
	 * @param integer2 
	 * @param integer */
	List<Liushui> getAllJl(@Param("startIndex")Integer integer, @Param("lineCount")Integer integer2, @Param("model")int i);
	
	/**根据条件查询流水
	 * @param i 
	 * @param integer2 
	 * @param integer */
	List<Liushui> getTypeJl(@Param("startIndex")Integer integer, @Param("lineCount")Integer integer2, @Param("l")Liushui l, @Param("date1")String date1, @Param("date2")String date2, @Param("model")int i);
	
	/**代理下级的流水记录单个用户*/
	List<Liushui> getOneLsJl(@Param("l")Liushui l, @Param("date1")String date1, @Param("date2")String date2,@Param("id")Integer id);
	
	/**查询全部反水记录 */
	List<Liushui> getFanshuiJl();
	
	/**个人投注反水记录*/
	List<Liushui> getOneFanshui(Integer id);

	/**已读状态
	 * @param integer */
	int upliushui(Integer id);

	/** 当前有多少条未读 */
	int weidu(Integer id);
	
	/**今天的投注总计*/
	Double getToday1(String cre1);
	
	/**今天的派奖总计*/
	double getToday2(String cre1);

	/**今天的返点总计*/
	double getToday3(String cre1);
	
	/**今天的返水总计*/
	double getToday4(String cre1);
	
	/**用户的签到记录*/
	List<Liushui> getSignInRecord(Integer id);
	
	/**所有用户的签到记录*/
	List<Liushui> getAllSignInRecord();
	
	/**查询有没有签到*/
	Liushui checkSigIn(@Param("id")Integer id,@Param("date1")String date);
	
	/**查询聊天数据*/
	List<Lsltjl> query(String date);
	
	User chax(Integer id);
	
	List<User> img(@Param("list")List<Integer> list);
	
	/**
	 * 查询用户的未读流水
	 * @param id 用户id
	 * @param i 
	 * @param id2 
	 * @param integer2 
	 * @return
	 */
	List<Liushui> getWDLiushui(@Param("startIndex")Integer startIndex, @Param("lineCount")Integer lineCount, @Param("id")Integer id, @Param("model")int model);
	
	/**
	 * 查询用户的已读流水
	 * @param id 用户id
	 * @param i 
	 * @param id2 
	 * @param integer2 
	 * @return
	 */
	List<Liushui> getYDLiushui(@Param("startIndex")Integer startIndex, @Param("lineCount")Integer lineCount, @Param("id")Integer id, @Param("model")int model);
	
	/**定时删除流水表里面的试玩账号记录*/
	void deleteliushui(@Param("userid")Integer userid);
	
	/**
	 * 查询某段时间数据详情
	 * @param findFormatDate
	 * @return
	 */
	List<Liushui> findByTimeDetails(String date);
	
	/**
	 * 
	    *   方法名：getWDLiushuiCounts   
	    *   描述：       查询未读流水的数量                   
	    *   参数：    @param id
	    *   参数：    @return 
	 * @param state 
	 * @return: Integer
	 */
	Integer getWDLiushuiCounts(Integer id, int state);
	
	/**
	 * 
	 *   方法名：getAllJlCounts   
	 *   描述：                          
	 *   参数：    @return 
	 * @return: Integer
	 */
	Integer getAllJlCounts();

	/**
	 * 
	 *   方法名：getTypeJlCounts   
	 *   描述：                          
	 *   参数：    @param liushui
	 *   参数：    @param date1
	 *   参数：    @param date2
	 *   参数：    @param i
	 *   参数：    @return 
	 * @return: Integer  
	 */
	Integer getTypeJlCounts(@Param("l")Liushui l, @Param("date1")String date1, @Param("date2")String date2); 
	
	/**
	 * 
	   *   方法名：getLiushuiCounts   
	   *   描述：                          
	   *   参数：    @param id
	   *   参数：    @return
	 * @return: Integer
	 */
	Integer getLiushuiCounts(@Param("liushui")Liushui liushui);
	
	/**
	 * 
	   *   方法名：getLiushuis   
	   *   描述：                          
	   *   参数：    @param paging
	   *   参数：    @param id
	   *   参数：    @return 
	 * @return: List<Liushui>
	 */
	List<Liushui> getLiushuis(@Param("paging")PagingData paging, @Param("liushui")Liushui liushui);

	/**
	 * 
	 * @param userid
	 * @return
	 */
	Double checkinTotal(Integer userid);

	/**
	 * 
	   *   方法名：findAllGlobalReport   
	   *   描述：    查询平台的全局报表统计 (手续费总计 - 代理返点总计  - 日常反水总计 - 彩票撤单总计 - 系统彩撤单总计 - 和局退还本金总计 - 港彩特码B反水总计)                     
	   *   参数：    @param startTime 开始时间
	   *   参数：    @param endTime 结束时间
	   *   参数：    @param userName 用户名
	   *   参数：    @param type 查询类型
	   *   参数：    @return 
	 * @param j 
	 * @param i 
	 * @return: TodayRecord
	 */
	Double findAllGlobalReport(@Param("startTime")String startTime, @Param("endTime")String endTime, @Param("userName")String userName,@Param("type")String type);

	
	/**
	 * 
	   *   方法名：findRecentReport   
	   *   描述：   查询最近报表                       
	   *   参数：    @param date 时间
	   *   参数：    @param index 最近几个月
	   *   参数：    @return 
	 * @return: YunyingJl
	 */
	YunyingJl findRecentReport(@Param("date")String date, @Param("index")int index);

	/**
	 * 
	   *   方法名：findRecentReport   
	   *   描述：     查询近期的统计数据                     
	   *   参数：    @param date 查询的世界
	   *   参数：    @param type 查询的类型
	   *   参数：    @return 
	 * @return: Double
	 */
	Double findRecentReport(@Param("date")String date, @Param("type")String type);

	/**
	 * 方法名：findByIdTimeTodayRecord 
	 * 描述：     同时根据多名用户id查询代理下级总计                 
	 * 参数：    @param findFormatDate
	 * 参数：    @param userName
	 * 参数：    @return 
	 * @return: TodayRecord
	 */
	TodayRecord findByIdTimeTodayRecord(@Param("date")String date, @Param("ids")String ids);

	/**
	 * @return
	 */
	List<Liushui> findWaterData();

	/**
	 * @param liushui
	 */
	void updateWaterData(Liushui liushui);
	
	
}
