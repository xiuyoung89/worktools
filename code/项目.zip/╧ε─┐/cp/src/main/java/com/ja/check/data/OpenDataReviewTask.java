package com.ja.check.data;

import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;

import org.springframework.web.context.ContextLoader;

import com.alibaba.druid.util.StringUtils;
import com.ja.check.action.CheckOrder;
import com.ja.domain.Data;
import com.ja.sevice.IDataService;
import com.ja.util.DateUtil;

/**
 * @DESC: 
 * @AUTH: qhzh 
 * @DATE: 2018年8月28日 上午10:56:22
 */
public class OpenDataReviewTask {

	private IDataService dataService = (IDataService) ContextLoader.getCurrentWebApplicationContext()
			.getBean("dataService");
	
	public static Timer openTimeCheckTimer = new Timer();

	public static List<TimerTask> openTimeCheckTasks = new ArrayList<>();

	public static List<Data> currDatas = new ArrayList<>();
	
	public static boolean[] isFirstTimes = {true,true,true,true,true,true,true,true,true,true
			,true,true,true,true,true,true,true,true,true,true};
	
	public static String URL_DDH_LATEST_DATA = "https://ddh202.com/mobile/v3/draw_notice_data.do";
	
	static {
		for(int i=0;i<CpData.cnames.length;i++) {
			currDatas.add(null);
		}
		for(int i=0;i<CpData.cnames.length-2;i++) {
			openTimeCheckTasks.add(null);
		}
	}

	/**
	 * 执行每日回头看任务：准备定时任务需要的数据、配置定时任务并启动、关闭定时任务
	 */
	public void startReviewTask() {
		initCurrDatasList();
		if (currDatas.isEmpty()) {
			return;
		}
		// 开启回头看任务
		startReviewThread0();
		startReviewThread1();
		startReviewThread2();
		startReviewThread3();
		startReviewThread4();
		startReviewThread5();
		startReviewThread6();
		startReviewThread7();
		startReviewThread8();
		startReviewThread9();
		startReviewThread10();
		startReviewThread11();
		startReviewThread12();
		startReviewThread13();
		startReviewThread14();
		startReviewThread15();
		startReviewThread16();
		startReviewThread17();
		startReviewThread18();
		startReviewThread19();
		//startReviewThread20();
	}

	/**
	 * 初始化当前未开奖的最新一期数据集合
	 */
	private void initCurrDatasList() {
		String nowTime = DateUtil.formatDateTime(LocalDateTime.now());
		//先查询出每个彩种最新开奖的一期
		currDatas = dataService.findCurrDatas(nowTime );
		if(currDatas == null) {
			return;
		}
		List<Data> temp = new ArrayList<>();
		for(int i=0;i<currDatas.size();i++) {
			Data data = currDatas.get(i);
			//System.out.println("initCurrDatasList我打印的"+data.toString());
			temp.add(i, dataService.findDataByNameAndPeriod(data.getCname(), data.getPeriod()));
		}
		currDatas = sortCurrMap(temp);
		//System.out.println("[" + DateUtil.getCurrTime() + "]" + "OpenDataReviewTask.getCurrMapByCalculate()-----计算得出的当前期数集合大小为：" + currDatas.size()+"\n"+currDatas);
	}

	/**
	 * 按照cname进行排序
	 * @param datas
	 * @return
	 */
	private List<Data> sortCurrMap(List<Data> datas) {
		if(datas.isEmpty()) {
			return datas;
		}
		List<Data> temp = new ArrayList<>();
		for (int i = 0; i < CpData.cnames.length; i++) {
			temp.add(i,null);
			for (Data data : datas) {
				if (CpData.cnames[i].equals(data.getCname())) {
					temp.add(i, data);
					break;
				}
			}
		}
		return temp;
	}

	/**
	 * 为各彩种生成回头看任务
	 */
	public void startReviewThread0() {
		//先拿当前未开奖的最新一期数据，睡到下期开奖时间前的一分钟执行回头看任务，最后更新当前未开奖数据
		new Thread(new Runnable() {
			public void run() {
				while(true) {
					Data currData = currDatas.get(0);
					System.out.println(currData);
					if(currData == null) {
						break;
					}
					System.out.println("正在检测"+CpData.cnames[0]+"有没有超时的期号");
					try {
						LocalDateTime openTime = LocalDateTime.parse(currData.getOpenTime(), DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));
						long seconds = openTime.toEpochSecond(ZoneOffset.of("+8"))-(LocalDateTime.now().toEpochSecond(ZoneOffset.of("+8")));
						if(seconds > 0) {	
							System.out.println(seconds+"------1--ah11x5------睡眠时间的值seconds");
							Thread.sleep(seconds*1000);
						}
						if(isFirstTimes[0]) {
							dataService.updatePreDataStatusTo1(currData.getCname(),currData.getId());							
						}else {
							dataService.updateStatusTo1(currData.getId());	
							isFirstTimes[0] = false;
						}
						LocalDateTime nextOpenTime = LocalDateTime.parse(currData.getNextStopOrderTimeEpoch(), DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));
						seconds = nextOpenTime.toEpochSecond(ZoneOffset.of("+8"))-(LocalDateTime.now().toEpochSecond(ZoneOffset.of("+8")))-30;
						if(seconds > 0) {		
							System.out.println(seconds+"------2---ah11x5-----睡眠时间的值seconds");
							Thread.sleep(seconds*1000);
						}
						currData = dataService.findById(currData.getId());
						if (currData !=null && StringUtils.isEmpty(currData.getLotternumber())) {
							CpData.isShotFlags.put(currData.getCname(), currData.getNextperiod());
							dataService.updateLotterNumberToEmptyStr(currData.getId());
							new CheckOrder().checkLotters(currData);
						}
					} catch (Exception e) {
						e.printStackTrace();
					}finally {
						Data nextData = dataService.findDataByNameAndPeriod(CpData.cnames[0], currData.getNextperiod());
						currDatas.add(0, nextData);
					}
				}
			}
		}).start();
	}

	/**
	 * 为各彩种生成回头看任务
	 */
	public void startReviewThread1() {
		//先拿当前未开奖的最新一期数据，睡到下期开奖时间前的一分钟执行回头看任务，最后更新当前未开奖数据
		new Thread(new Runnable() {
			public void run() {
				while(true) {
					Data currData = currDatas.get(1);
					if(currData == null) {
						break;
					}
					try {
						LocalDateTime openTime = LocalDateTime.parse(currData.getOpenTime(), 
								DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));
						long seconds = openTime.toEpochSecond(ZoneOffset.of("+8"))-
								(LocalDateTime.now().toEpochSecond(ZoneOffset.of("+8")));
						if(seconds > 0) {			
							System.out.println(seconds+"------1---ahk3-----睡眠时间的值seconds");
							Thread.sleep(seconds*1000);
						}
						if(isFirstTimes[1]) {
							dataService.updatePreDataStatusTo1(currData.getCname(),currData.getId());							
						}else {
							dataService.updateStatusTo1(currData.getId());	
							isFirstTimes[1] = false;
						}
						LocalDateTime nextOpenTime = LocalDateTime.parse(currData.getNextStopOrderTimeEpoch(), 
								DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));
						seconds = nextOpenTime.toEpochSecond(ZoneOffset.of("+8"))-
								(LocalDateTime.now().toEpochSecond(ZoneOffset.of("+8")))-30;
						if(seconds > 0) {	
							System.out.println(seconds+"------2---ahk3-----睡眠时间的值seconds");
							Thread.sleep(seconds*1000);
						}
						currData = dataService.findById(currData.getId());
						if (currData !=null && StringUtils.isEmpty(currData.getLotternumber())) {
							CpData.isShotFlags.put(currData.getCname(), currData.getNextperiod());
							//System.out.println("[wch---------"+DateUtil.getCurrTime()+"] "+CpData.cnames[1]+".run()-----没有开出：\n"+currData+"-------------------------wch");
							dataService.updateLotterNumberToEmptyStr(currData.getId());
							new CheckOrder().checkLotters(currData);
						}
					} catch (Exception e) {
						e.printStackTrace();
					}finally {
						currDatas.add(1, dataService.findDataByNameAndPeriod(CpData.cnames[1], currData.getNextperiod()));
					}
				}
			}
		}).start();
	}

	/**
	 * 为各彩种生成回头看任务
	 */
	public void startReviewThread2() {
		//先拿当前未开奖的最新一期数据，睡到下期开奖时间前的一分钟执行回头看任务，最后更新当前未开奖数据
		new Thread(new Runnable() {
			public void run() {
				while(true) {
					Data currData = currDatas.get(2);
					if(currData == null) {
						break;
					}
					try {
						LocalDateTime openTime = LocalDateTime.parse(currData.getOpenTime(), 
								DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));
						long seconds = openTime.toEpochSecond(ZoneOffset.of("+8"))-
								(LocalDateTime.now().toEpochSecond(ZoneOffset.of("+8")));
						if(seconds > 0) {
							System.out.println(seconds+"------1---cqkl10f-----睡眠时间的值seconds");
							Thread.sleep(seconds*1000);
						}
						if(isFirstTimes[2]) {
							dataService.updatePreDataStatusTo1(currData.getCname(),currData.getId());							
						}else {
							dataService.updateStatusTo1(currData.getId());	
							isFirstTimes[2] = false;
						}
						LocalDateTime nextOpenTime = LocalDateTime.parse(currData.getNextStopOrderTimeEpoch(), 
								DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));
						seconds = nextOpenTime.toEpochSecond(ZoneOffset.of("+8"))-
								(LocalDateTime.now().toEpochSecond(ZoneOffset.of("+8")))-30;
						if(seconds > 0) {	
							System.out.println(seconds+"------2---cqkl10f-----睡眠时间的值seconds");
							Thread.sleep(seconds*1000);
						}
						currData = dataService.findById(currData.getId());
						if (currData !=null && StringUtils.isEmpty(currData.getLotternumber())) {
							CpData.isShotFlags.put(currData.getCname(), currData.getNextperiod());
							dataService.updateLotterNumberToEmptyStr(currData.getId());
							new CheckOrder().checkLotters(currData);
						}
					} catch (Exception e) {
						e.printStackTrace();
					}finally {
						currDatas.add(2, dataService.findDataByNameAndPeriod(CpData.cnames[2], currData.getNextperiod()));
					}
				}
			}
		}).start();
	}

	/**
	 * 为各彩种生成回头看任务
	 */
	public void startReviewThread3() {
		//先拿当前未开奖的最新一期数据，睡到下期开奖时间前的一分钟执行回头看任务，最后更新当前未开奖数据
		new Thread(new Runnable() {
			public void run() {
				while(true) {
					Data currData = currDatas.get(3);
					if(currData == null) {
						break;
					}
					try {
						LocalDateTime openTime = LocalDateTime.parse(currData.getOpenTime(), 
								DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));
						long seconds = openTime.toEpochSecond(ZoneOffset.of("+8"))-
								(LocalDateTime.now().toEpochSecond(ZoneOffset.of("+8")));
						if(seconds > 0) {
							System.out.println(seconds+"------1---cqssc-----睡眠时间的值seconds");
							Thread.sleep(seconds*1000);
						}
						if(isFirstTimes[3]) {
							dataService.updatePreDataStatusTo1(currData.getCname(),currData.getId());							
						}else {
							dataService.updateStatusTo1(currData.getId());	
							isFirstTimes[3] = false;
						}
						LocalDateTime nextOpenTime = LocalDateTime.parse(currData.getNextStopOrderTimeEpoch(), 
								DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));
						seconds = nextOpenTime.toEpochSecond(ZoneOffset.of("+8"))-
								(LocalDateTime.now().toEpochSecond(ZoneOffset.of("+8")))-30;
						if(seconds > 0) {	
							System.out.println(seconds+"------2---cqssc-----睡眠时间的值seconds");
							Thread.sleep(seconds*1000);
						}
						currData = dataService.findById(currData.getId());
						if (currData !=null && StringUtils.isEmpty(currData.getLotternumber())) {
							CpData.isShotFlags.put(currData.getCname(), currData.getNextperiod());
							dataService.updateLotterNumberToEmptyStr(currData.getId());
							new CheckOrder().checkLotters(currData);
						}
					} catch (Exception e) {
						e.printStackTrace();
					}finally {
						currDatas.add(3, dataService.findDataByNameAndPeriod(CpData.cnames[3], currData.getNextperiod()));
					}
				}
			}
		}).start();
	}

	/**
	 * 为各彩种生成回头看任务
	 */
	public void startReviewThread4() {
		//先拿当前未开奖的最新一期数据，睡到下期开奖时间前的一分钟执行回头看任务，最后更新当前未开奖数据
		new Thread(new Runnable() {
			public void run() {
				while(true) {
					Data currData = currDatas.get(4);
					if(currData == null) {
						break;
					}
					try {
						LocalDateTime openTime = LocalDateTime.parse(currData.getOpenTime(), 
								DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));
						long seconds = openTime.toEpochSecond(ZoneOffset.of("+8"))-
								(LocalDateTime.now().toEpochSecond(ZoneOffset.of("+8")));
						if(seconds > 0) {
							System.out.println(seconds+"------1---xjssc-----睡眠时间的值seconds");
							Thread.sleep(seconds*1000);
						}
						if(isFirstTimes[4]) {
							dataService.updatePreDataStatusTo1(currData.getCname(),currData.getId());							
						}else {
							dataService.updateStatusTo1(currData.getId());	
							isFirstTimes[4] = false;
						}
						LocalDateTime nextOpenTime = LocalDateTime.parse(currData.getNextStopOrderTimeEpoch(), 
								DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));
						seconds = nextOpenTime.toEpochSecond(ZoneOffset.of("+8"))-
								(LocalDateTime.now().toEpochSecond(ZoneOffset.of("+8")))-30;
						if(seconds > 0) {
							System.out.println(seconds+"------2---xjssc-----睡眠时间的值seconds");
							Thread.sleep(seconds*1000);
						}
						currData = dataService.findById(currData.getId());
						if (currData !=null && StringUtils.isEmpty(currData.getLotternumber())) {
							CpData.isShotFlags.put(currData.getCname(), currData.getNextperiod());
							dataService.updateLotterNumberToEmptyStr(currData.getId());
							new CheckOrder().checkLotters(currData);
						}
					} catch (Exception e) {
						e.printStackTrace();
					}finally {
						currDatas.add(4, dataService.findDataByNameAndPeriod(CpData.cnames[4], currData.getNextperiod()));
					}
				}
			}
		}).start();
	}

	/**
	 * 为各彩种生成回头看任务
	 */
	public void startReviewThread5() {
		//先拿当前未开奖的最新一期数据，睡到下期开奖时间前的一分钟执行回头看任务，最后更新当前未开奖数据
		new Thread(new Runnable() {
			public void run() {
				while(true) {
					Data currData = currDatas.get(5);
					if(currData == null) {
						break;
					}
					try {
						LocalDateTime openTime = LocalDateTime.parse(currData.getOpenTime(), 
								DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));
						long seconds = openTime.toEpochSecond(ZoneOffset.of("+8"))-
								(LocalDateTime.now().toEpochSecond(ZoneOffset.of("+8")));
						if(seconds > 0) {	
							System.out.println(seconds+"------1---gd11x5-----睡眠时间的值seconds");
							Thread.sleep(seconds*1000);
						}
						if(isFirstTimes[5]) {
							dataService.updatePreDataStatusTo1(currData.getCname(),currData.getId());							
						}else {
							dataService.updateStatusTo1(currData.getId());	
							isFirstTimes[5] = false;
						}
						LocalDateTime nextOpenTime = LocalDateTime.parse(currData.getNextStopOrderTimeEpoch(), 
								DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));
						seconds = nextOpenTime.toEpochSecond(ZoneOffset.of("+8"))-
								(LocalDateTime.now().toEpochSecond(ZoneOffset.of("+8")))-30;
						if(seconds > 0) {
							System.out.println(seconds+"------2---gd11x5-----睡眠时间的值seconds");
							Thread.sleep(seconds*1000);
						}
						currData = dataService.findById(currData.getId());
						if (currData !=null && StringUtils.isEmpty(currData.getLotternumber())) {
							CpData.isShotFlags.put(currData.getCname(), currData.getNextperiod());
							dataService.updateLotterNumberToEmptyStr(currData.getId());
							new CheckOrder().checkLotters(currData);
						}
					} catch (Exception e) {
						e.printStackTrace();
					}finally {
						currDatas.add(5, dataService.findDataByNameAndPeriod(CpData.cnames[5], currData.getNextperiod()));
					}
				}
			}
		}).start();
	}

	/**
	 * 为各彩种生成回头看任务
	 */
	public void startReviewThread6() {
		//先拿当前未开奖的最新一期数据，睡到下期开奖时间前的一分钟执行回头看任务，最后更新当前未开奖数据
		new Thread(new Runnable() {
			public void run() {
				while(true) {
					Data currData = currDatas.get(6);
					if(currData == null) {
						break;
					}
					try {
						LocalDateTime openTime = LocalDateTime.parse(currData.getOpenTime(), 
								DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));
						long seconds = openTime.toEpochSecond(ZoneOffset.of("+8"))-
								(LocalDateTime.now().toEpochSecond(ZoneOffset.of("+8")));
						if(seconds > 0) {
							System.out.println(seconds+"------1---gdkl10f-----睡眠时间的值seconds");
							Thread.sleep(seconds*1000);
						}
						if(isFirstTimes[6]) {
							dataService.updatePreDataStatusTo1(currData.getCname(),currData.getId());							
						}else {
							dataService.updateStatusTo1(currData.getId());	
							isFirstTimes[6] = false;
						}
						LocalDateTime nextOpenTime = LocalDateTime.parse(currData.getNextStopOrderTimeEpoch(), 
								DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));
						seconds = nextOpenTime.toEpochSecond(ZoneOffset.of("+8"))-
								(LocalDateTime.now().toEpochSecond(ZoneOffset.of("+8")))-30;
						if(seconds > 0) {		
							System.out.println(seconds+"------2---gdkl10f-----睡眠时间的值seconds");
							Thread.sleep(seconds*1000);
						}
						currData = dataService.findById(currData.getId());
						if (currData !=null && StringUtils.isEmpty(currData.getLotternumber())) {
							CpData.isShotFlags.put(currData.getCname(), currData.getNextperiod());
							dataService.updateLotterNumberToEmptyStr(currData.getId());
							new CheckOrder().checkLotters(currData);
						}
					} catch (Exception e) {
						e.printStackTrace();
					}finally {
						currDatas.add(6, dataService.findDataByNameAndPeriod(CpData.cnames[6], currData.getNextperiod()));
					}
				}
			}
		}).start();
	}

	/**
	 * 为各彩种生成回头看任务
	 */
	public void startReviewThread7() {
		//先拿当前未开奖的最新一期数据，睡到下期开奖时间前的一分钟执行回头看任务，最后更新当前未开奖数据
		new Thread(new Runnable() {
			public void run() {
				while(true) {
					Data currData = currDatas.get(7);
					if(currData == null) {
						break;
					}
					try {
						LocalDateTime openTime = LocalDateTime.parse(currData.getOpenTime(), 
								DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));
						long seconds = openTime.toEpochSecond(ZoneOffset.of("+8"))-
								(LocalDateTime.now().toEpochSecond(ZoneOffset.of("+8")));
						if(seconds > 0) {	
							System.out.println(seconds+"------1---gxk3-----睡眠时间的值seconds");
							Thread.sleep(seconds*1000);
						}
						if(isFirstTimes[7]) {
							dataService.updatePreDataStatusTo1(currData.getCname(),currData.getId());							
						}else {
							dataService.updateStatusTo1(currData.getId());	
							isFirstTimes[7] = false;
						}
						LocalDateTime nextOpenTime = LocalDateTime.parse(currData.getNextStopOrderTimeEpoch(), 
								DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));
						seconds = nextOpenTime.toEpochSecond(ZoneOffset.of("+8"))-
								(LocalDateTime.now().toEpochSecond(ZoneOffset.of("+8")))-30;
						if(seconds > 0) {	
							System.out.println(seconds+"------2---gxk3-----睡眠时间的值seconds");
							Thread.sleep(seconds*1000);
						}
						currData = dataService.findById(currData.getId());
						if (currData !=null && StringUtils.isEmpty(currData.getLotternumber())) {
							CpData.isShotFlags.put(currData.getCname(), currData.getNextperiod());
							dataService.updateLotterNumberToEmptyStr(currData.getId());
							new CheckOrder().checkLotters(currData);
						}
					} catch (Exception e) {
						e.printStackTrace();
					}finally {
						currDatas.add(7, dataService.findDataByNameAndPeriod(CpData.cnames[7], currData.getNextperiod()));
					}
				}
			}
		}).start();
	}

	/**
	 * 为各彩种生成回头看任务
	 */
	public void startReviewThread8() {
		//先拿当前未开奖的最新一期数据，睡到下期开奖时间前的一分钟执行回头看任务，最后更新当前未开奖数据
		new Thread(new Runnable() {
			public void run() {
				while(true) {
					Data currData = currDatas.get(8);
					if(currData == null) {
						break;
					}
					try {
						LocalDateTime openTime = LocalDateTime.parse(currData.getOpenTime(), 
								DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));
						long seconds = openTime.toEpochSecond(ZoneOffset.of("+8"))-
								(LocalDateTime.now().toEpochSecond(ZoneOffset.of("+8")));
						if(seconds > 0) {	
							System.out.println(seconds+"------1---jsk3-----睡眠时间的值seconds");
							Thread.sleep(seconds*1000);
						}
						if(isFirstTimes[8]) {
							dataService.updatePreDataStatusTo1(currData.getCname(),currData.getId());							
						}else {
							dataService.updateStatusTo1(currData.getId());	
							isFirstTimes[8] = false;
						}
						LocalDateTime nextOpenTime = LocalDateTime.parse(currData.getNextStopOrderTimeEpoch(), 
								DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));
						seconds = nextOpenTime.toEpochSecond(ZoneOffset.of("+8"))-
								(LocalDateTime.now().toEpochSecond(ZoneOffset.of("+8")))-30;
						if(seconds > 0) {	
							System.out.println(seconds+"------2---jsk3-----睡眠时间的值seconds");
							Thread.sleep(seconds*1000);
						}
						currData = dataService.findById(currData.getId());
						if (currData !=null && StringUtils.isEmpty(currData.getLotternumber())) {
							CpData.isShotFlags.put(currData.getCname(), currData.getNextperiod());
							dataService.updateLotterNumberToEmptyStr(currData.getId());
							new CheckOrder().checkLotters(currData);
						}
					} catch (Exception e) {
						e.printStackTrace();
					}finally {
						currDatas.add(8, dataService.findDataByNameAndPeriod(CpData.cnames[8], currData.getNextperiod()));
					}
				}
			}
		}).start();
	}

	/**
	 * 为各彩种生成回头看任务
	 */
	public void startReviewThread9() {
		//先拿当前未开奖的最新一期数据，睡到下期开奖时间前的一分钟执行回头看任务，最后更新当前未开奖数据
		new Thread(new Runnable() {
			public void run() {
				while(true) {
					Data currData = currDatas.get(9);
					if(currData == null) {
						break;
					}
					try {
						LocalDateTime openTime = LocalDateTime.parse(currData.getOpenTime(), 
								DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));
						long seconds = openTime.toEpochSecond(ZoneOffset.of("+8"))-
								(LocalDateTime.now().toEpochSecond(ZoneOffset.of("+8")));
						if(seconds > 0) {
							System.out.println(seconds+"------1---jx11x5-----睡眠时间的值seconds");
							Thread.sleep(seconds*1000);
						}
						if(isFirstTimes[9]) {
							dataService.updatePreDataStatusTo1(currData.getCname(),currData.getId());							
						}else {
							dataService.updateStatusTo1(currData.getId());	
							isFirstTimes[9] = false;
						}
						LocalDateTime nextOpenTime = LocalDateTime.parse(currData.getNextStopOrderTimeEpoch(), 
								DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));
						seconds = nextOpenTime.toEpochSecond(ZoneOffset.of("+8"))-
								(LocalDateTime.now().toEpochSecond(ZoneOffset.of("+8")))-30;
						if(seconds > 0) {
							System.out.println(seconds+"------2---jx11x5-----睡眠时间的值seconds");
							Thread.sleep(seconds*1000);
						}
						currData = dataService.findById(currData.getId());
						if (currData !=null && StringUtils.isEmpty(currData.getLotternumber())) {
							CpData.isShotFlags.put(currData.getCname(), currData.getNextperiod());
							dataService.updateLotterNumberToEmptyStr(currData.getId());
							new CheckOrder().checkLotters(currData);
						}
					} catch (Exception e) {
						e.printStackTrace();
					}finally {
						currDatas.add(9, dataService.findDataByNameAndPeriod(CpData.cnames[9], currData.getNextperiod()));
					}
				}
			}
		}).start();
	}

	/**
	 * 为各彩种生成回头看任务
	 */
	public void startReviewThread10() {
		//先拿当前未开奖的最新一期数据，睡到下期开奖时间前的一分钟执行回头看任务，最后更新当前未开奖数据
		new Thread(new Runnable() {
			public void run() {
				while(true) {
					Data currData = currDatas.get(10);
					if(currData == null) {
						break;
					}
					try {
						LocalDateTime openTime = LocalDateTime.parse(currData.getOpenTime(), 
								DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));
						long seconds = openTime.toEpochSecond(ZoneOffset.of("+8"))-
								(LocalDateTime.now().toEpochSecond(ZoneOffset.of("+8")));
						if(seconds > 0) {	
							System.out.println(seconds+"------1---sd11x5-----睡眠时间的值seconds");
							Thread.sleep(seconds*1000);
						}
						if(isFirstTimes[10]) {
							dataService.updatePreDataStatusTo1(currData.getCname(),currData.getId());							
						}else {
							dataService.updateStatusTo1(currData.getId());	
							isFirstTimes[10] = false;
						}
						LocalDateTime nextOpenTime = LocalDateTime.parse(currData.getNextStopOrderTimeEpoch(), 
								DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));
						seconds = nextOpenTime.toEpochSecond(ZoneOffset.of("+8"))-
								(LocalDateTime.now().toEpochSecond(ZoneOffset.of("+8")))-30;
						if(seconds > 0) {	
							System.out.println(seconds+"------2---sd11x5-----睡眠时间的值seconds");
							Thread.sleep(seconds*1000);
						}
						currData = dataService.findById(currData.getId());
						if (currData !=null && StringUtils.isEmpty(currData.getLotternumber())) {
							CpData.isShotFlags.put(currData.getCname(), currData.getNextperiod());
							dataService.updateLotterNumberToEmptyStr(currData.getId());
							new CheckOrder().checkLotters(currData);
						}
					} catch (Exception e) {
						e.printStackTrace();
					}finally {
						currDatas.add(10, dataService.findDataByNameAndPeriod(CpData.cnames[10], currData.getNextperiod()));
					}
				}
			}
		}).start();
	}

	/**
	 * 为各彩种生成回头看任务
	 */
	public void startReviewThread11() {
		//先拿当前未开奖的最新一期数据，睡到下期开奖时间前的一分钟执行回头看任务，最后更新当前未开奖数据
		new Thread(new Runnable() {
			public void run() {
				while(true) {
					Data currData = currDatas.get(11);
					if(currData == null) {
						break;
					}
					try {
						LocalDateTime openTime = LocalDateTime.parse(currData.getOpenTime(), 
								DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));
						long seconds = openTime.toEpochSecond(ZoneOffset.of("+8"))-
								(LocalDateTime.now().toEpochSecond(ZoneOffset.of("+8")));
						if(seconds > 0) {	
							System.out.println(seconds+"------1---sh11x5-----睡眠时间的值seconds");
							Thread.sleep(seconds*1000);
						}
						if(isFirstTimes[11]) {
							dataService.updatePreDataStatusTo1(currData.getCname(),currData.getId());							
						}else {
							dataService.updateStatusTo1(currData.getId());	
							isFirstTimes[11] = false;
						}
						LocalDateTime nextOpenTime = LocalDateTime.parse(currData.getNextStopOrderTimeEpoch(), 
								DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));
						seconds = nextOpenTime.toEpochSecond(ZoneOffset.of("+8"))-
								(LocalDateTime.now().toEpochSecond(ZoneOffset.of("+8")))-30;
						if(seconds > 0) {	
							System.out.println(seconds+"------2---sh11x5-----睡眠时间的值seconds");
							Thread.sleep(seconds*1000);
						}
						currData = dataService.findById(currData.getId());
						if (currData !=null && StringUtils.isEmpty(currData.getLotternumber())) {
							CpData.isShotFlags.put(currData.getCname(), currData.getNextperiod());
							dataService.updateLotterNumberToEmptyStr(currData.getId());
							new CheckOrder().checkLotters(currData);
						}
					} catch (Exception e) {
						e.printStackTrace();
					}finally {
						currDatas.add(11, dataService.findDataByNameAndPeriod(CpData.cnames[11], currData.getNextperiod()));
					}
				}
			}
		}).start();
	}

	/**
	 * 为各彩种生成回头看任务
	 */
	public void startReviewThread12() {
		//先拿当前未开奖的最新一期数据，睡到下期开奖时间前的一分钟执行回头看任务，最后更新当前未开奖数据
		new Thread(new Runnable() {
			public void run() {
				while(true) {
					Data currData = currDatas.get(12);
					if(currData == null) {
						break;
					}
					try {
						LocalDateTime openTime = LocalDateTime.parse(currData.getOpenTime(), 
								DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));
						long seconds = openTime.toEpochSecond(ZoneOffset.of("+8"))-
								(LocalDateTime.now().toEpochSecond(ZoneOffset.of("+8")));
						if(seconds > 0) {	
							System.out.println(seconds+"------1---shssl-----睡眠时间的值seconds");
							Thread.sleep(seconds*1000);
						}
						if(isFirstTimes[12]) {
							dataService.updatePreDataStatusTo1(currData.getCname(),currData.getId());							
						}else {
							dataService.updateStatusTo1(currData.getId());	
							isFirstTimes[12] = false;
						}
						LocalDateTime nextOpenTime = LocalDateTime.parse(currData.getNextStopOrderTimeEpoch(), 
								DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));
						seconds = nextOpenTime.toEpochSecond(ZoneOffset.of("+8"))-
								(LocalDateTime.now().toEpochSecond(ZoneOffset.of("+8")))-30;
						if(seconds > 0) {	
							System.out.println(seconds+"------2---shssl-----睡眠时间的值seconds");
							Thread.sleep(seconds*1000);
						}
						currData = dataService.findById(currData.getId());
						if (currData !=null && StringUtils.isEmpty(currData.getLotternumber())) {
							CpData.isShotFlags.put(currData.getCname(), currData.getNextperiod());
							dataService.updateLotterNumberToEmptyStr(currData.getId());
							new CheckOrder().checkLotters(currData);
						}
					} catch (Exception e) {
						e.printStackTrace();
					}finally {
						currDatas.add(12, dataService.findDataByNameAndPeriod(CpData.cnames[12], currData.getNextperiod()));
					}
				}
			}
		}).start();
	}

	/**
	 * 为各彩种生成回头看任务
	 */
	public void startReviewThread13() {
		//先拿当前未开奖的最新一期数据，睡到下期开奖时间前的一分钟执行回头看任务，最后更新当前未开奖数据
		new Thread(new Runnable() {
			public void run() {
				while(true) {
					Data currData = currDatas.get(13);
					if(currData == null) {
						break;
					}
					try {
						LocalDateTime openTime = LocalDateTime.parse(currData.getOpenTime(), 
								DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));
						long seconds = openTime.toEpochSecond(ZoneOffset.of("+8"))-
								(LocalDateTime.now().toEpochSecond(ZoneOffset.of("+8")));
						if(seconds > 0) {	
							System.out.println(seconds+"------1---tjssc-----睡眠时间的值seconds");
							Thread.sleep(seconds*1000);
						}
						if(isFirstTimes[13]) {
							dataService.updatePreDataStatusTo1(currData.getCname(),currData.getId());							
						}else {
							dataService.updateStatusTo1(currData.getId());	
							isFirstTimes[13] = false;
						}
						LocalDateTime nextOpenTime = LocalDateTime.parse(currData.getNextStopOrderTimeEpoch(), 
								DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));
						seconds = nextOpenTime.toEpochSecond(ZoneOffset.of("+8"))-
								(LocalDateTime.now().toEpochSecond(ZoneOffset.of("+8")))-30;
						if(seconds > 0) {
							System.out.println(seconds+"------2---tjssc-----睡眠时间的值seconds");
							Thread.sleep(seconds*1000);
						}
						currData = dataService.findById(currData.getId());
						if (currData !=null && StringUtils.isEmpty(currData.getLotternumber())) {
							CpData.isShotFlags.put(currData.getCname(), currData.getNextperiod());
							dataService.updateLotterNumberToEmptyStr(currData.getId());
							new CheckOrder().checkLotters(currData);
						}
					} catch (Exception e) {
						e.printStackTrace();
					}finally {
						currDatas.add(13, dataService.findDataByNameAndPeriod(CpData.cnames[13], currData.getNextperiod()));
					}
				}
			}
		}).start();
	}

	/**
	 * 为各彩种生成回头看任务
	 */
	public void startReviewThread14() {
		//先拿当前未开奖的最新一期数据，睡到下期开奖时间前的一分钟执行回头看任务，最后更新当前未开奖数据
		new Thread(new Runnable() {
			public void run() {
				while(true) {
					Data currData = currDatas.get(14);
					if(currData == null) {
						break;
					}
					try {
						LocalDateTime openTime = LocalDateTime.parse(currData.getOpenTime(), 
								DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));
						long seconds = openTime.toEpochSecond(ZoneOffset.of("+8"))-
								(LocalDateTime.now().toEpochSecond(ZoneOffset.of("+8")));
						if(seconds > 0) {	
							System.out.println(seconds+"------1---xyft-----睡眠时间的值seconds");
							Thread.sleep(seconds*1000);
						}
						if(isFirstTimes[14]) {
							dataService.updatePreDataStatusTo1(currData.getCname(),currData.getId());							
						}else {
							dataService.updateStatusTo1(currData.getId());	
							isFirstTimes[14] = false;
						}
						LocalDateTime nextOpenTime = LocalDateTime.parse(currData.getNextStopOrderTimeEpoch(), 
								DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));
						seconds = nextOpenTime.toEpochSecond(ZoneOffset.of("+8"))-
								(LocalDateTime.now().toEpochSecond(ZoneOffset.of("+8")))-30;
						if(seconds > 0) {		
							System.out.println(seconds+"------2---xyft-----睡眠时间的值seconds");
							Thread.sleep(seconds*1000);
						}
						currData = dataService.findById(currData.getId());
						if (currData !=null && StringUtils.isEmpty(currData.getLotternumber())) {
							CpData.isShotFlags.put(currData.getCname(), currData.getNextperiod());
							dataService.updateLotterNumberToEmptyStr(currData.getId());
							new CheckOrder().checkLotters(currData);
						}
					} catch (Exception e) {
						e.printStackTrace();
					}finally {
						currDatas.add(14, dataService.findDataByNameAndPeriod(CpData.cnames[14], currData.getNextperiod()));
					}
				}
			}
		}).start();
	}

	/**
	 * 为各彩种生成回头看任务
	 */
	public void startReviewThread15() {
		//先拿当前未开奖的最新一期数据，睡到下期开奖时间前的一分钟执行回头看任务，最后更新当前未开奖数据
		new Thread(new Runnable() {
			public void run() {
				while(true) {
					Data currData = currDatas.get(15);
					if(currData == null) {
						break;
					}
					try {
						LocalDateTime openTime = LocalDateTime.parse(currData.getOpenTime(), 
								DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));
						long seconds = openTime.toEpochSecond(ZoneOffset.of("+8"))-
								(LocalDateTime.now().toEpochSecond(ZoneOffset.of("+8")));
						if(seconds > 0) {	
							System.out.println(seconds+"------1---bjk3-----睡眠时间的值seconds");
							Thread.sleep(seconds*1000);
						}
						if(isFirstTimes[15]) {
							dataService.updatePreDataStatusTo1(currData.getCname(),currData.getId());							
						}else {
							dataService.updateStatusTo1(currData.getId());	
							isFirstTimes[15] = false;
						}
						LocalDateTime nextOpenTime = LocalDateTime.parse(currData.getNextStopOrderTimeEpoch(), 
								DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));
						seconds = nextOpenTime.toEpochSecond(ZoneOffset.of("+8"))-
								(LocalDateTime.now().toEpochSecond(ZoneOffset.of("+8")))-30;
						if(seconds > 0) {	
							System.out.println(seconds+"------2---bjk3-----睡眠时间的值seconds");
							Thread.sleep(seconds*1000);
						}
						currData = dataService.findById(currData.getId());
						if (currData !=null && StringUtils.isEmpty(currData.getLotternumber())) {
							CpData.isShotFlags.put(currData.getCname(), currData.getNextperiod());
							dataService.updateLotterNumberToEmptyStr(currData.getId());
							new CheckOrder().checkLotters(currData);
						}
					} catch (Exception e) {
						e.printStackTrace();
					}finally {
						currDatas.add(15, dataService.findDataByNameAndPeriod(CpData.cnames[15], currData.getNextperiod()));
					}
				}
			}
		}).start();
	}

	/**
	 * 为各彩种生成回头看任务
	 */
	public void startReviewThread16() {
		//先拿当前未开奖的最新一期数据，睡到下期开奖时间前的一分钟执行回头看任务，最后更新当前未开奖数据
		new Thread(new Runnable() {
			public void run() {
				while(true) {
					Data currData = currDatas.get(16);
					if(currData == null) {
						break;
					}
					try {
						LocalDateTime openTime = LocalDateTime.parse(currData.getOpenTime(), 
								DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));
						long seconds = openTime.toEpochSecond(ZoneOffset.of("+8"))-
								(LocalDateTime.now().toEpochSecond(ZoneOffset.of("+8")));
						if(seconds > 0) {	
							System.out.println(seconds+"------1---bjpk10-----睡眠时间的值seconds");
							Thread.sleep(seconds*1000);
						}
						if(isFirstTimes[16]) {
							dataService.updatePreDataStatusTo1(currData.getCname(),currData.getId());							
						}else {
							dataService.updateStatusTo1(currData.getId());	
							isFirstTimes[16] = false;
						}
						LocalDateTime nextOpenTime = LocalDateTime.parse(currData.getNextStopOrderTimeEpoch(), 
								DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));
						seconds = nextOpenTime.toEpochSecond(ZoneOffset.of("+8"))-
								(LocalDateTime.now().toEpochSecond(ZoneOffset.of("+8")))-30;
						if(seconds > 0) {		
							System.out.println(seconds+"------2---bjpk10-----睡眠时间的值seconds");
							Thread.sleep(seconds*1000);
						}
						currData = dataService.findById(currData.getId());
						if (currData !=null && StringUtils.isEmpty(currData.getLotternumber())) {
							CpData.isShotFlags.put(currData.getCname(), currData.getNextperiod());
							dataService.updateLotterNumberToEmptyStr(currData.getId());
							new CheckOrder().checkLotters(currData);
						}
					} catch (Exception e) {
						e.printStackTrace();
					}finally {
						currDatas.add(16, dataService.findDataByNameAndPeriod(CpData.cnames[16], currData.getNextperiod()));
					}
				}
			}
		}).start();
	}

	/**
	 * 为各彩种生成回头看任务
	 */
	public void startReviewThread17() {
		//先拿当前未开奖的最新一期数据，睡到下期开奖时间前的一分钟执行回头看任务，最后更新当前未开奖数据
		new Thread(new Runnable() {
			public void run() {
				while(true) {
					Data currData = currDatas.get(17);
					if(currData == null) {
						break;
					}
					try {
						LocalDateTime openTime = LocalDateTime.parse(currData.getOpenTime(), 
								DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));
						long seconds = openTime.toEpochSecond(ZoneOffset.of("+8"))-
								(LocalDateTime.now().toEpochSecond(ZoneOffset.of("+8")));
						if(seconds > 0) {
							System.out.println(seconds+"------1---fc3d-----睡眠时间的值seconds");
							Thread.sleep(seconds*1000);
						}
						if(isFirstTimes[17]) {
							dataService.updatePreDataStatusTo1(currData.getCname(),currData.getId());							
						}else {
							dataService.updateStatusTo1(currData.getId());	
							isFirstTimes[17] = false;
						}
						LocalDateTime nextOpenTime = LocalDateTime.parse(currData.getNextStopOrderTimeEpoch(), 
								DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));
						seconds = nextOpenTime.toEpochSecond(ZoneOffset.of("+8"))-
								(LocalDateTime.now().toEpochSecond(ZoneOffset.of("+8")))-30;
						if(seconds > 0) {		
							System.out.println(seconds+"------2---fc3d-----睡眠时间的值seconds");
							Thread.sleep(seconds*1000);
						}
						currData = dataService.findById(currData.getId());
						if (currData !=null && StringUtils.isEmpty(currData.getLotternumber())) {
							CpData.isShotFlags.put(currData.getCname(), currData.getNextperiod());
							dataService.updateLotterNumberToEmptyStr(currData.getId());
							new CheckOrder().checkLotters(currData);
						}
					} catch (Exception e) {
						e.printStackTrace();
					}finally {
						currDatas.add(17, dataService.findDataByNameAndPeriod(CpData.cnames[17], currData.getNextperiod()));
					}
				}
			}
		}).start();
	}

	/**
	 * 为各彩种生成回头看任务
	 */
	public void startReviewThread18() {
		//先拿当前未开奖的最新一期数据，睡到下期开奖时间前的一分钟执行回头看任务，最后更新当前未开奖数据
		new Thread(new Runnable() {
			public void run() {
				while(true) {
					Data currData = currDatas.get(18);
					System.out.println(currData);
					if(currData == null) {
						break;
					}
					try {
						LocalDateTime openTime = LocalDateTime.parse(currData.getOpenTime(), DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));
						long seconds = openTime.toEpochSecond(ZoneOffset.of("+8"))-(LocalDateTime.now().toEpochSecond(ZoneOffset.of("+8")));
						if(seconds > 0) {	
							System.out.println(seconds+"------1---pl3-----睡眠时间的值seconds");
							Thread.sleep(seconds*1000);
						}
						if(isFirstTimes[18]) {
							dataService.updatePreDataStatusTo1(currData.getCname(),currData.getId());							
						}else {
							dataService.updateStatusTo1(currData.getId());	
							isFirstTimes[18] = false;
						}
						LocalDateTime nextOpenTime = LocalDateTime.parse(currData.getNextStopOrderTimeEpoch(), 
								DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));
						seconds = nextOpenTime.toEpochSecond(ZoneOffset.of("+8"))-
								(LocalDateTime.now().toEpochSecond(ZoneOffset.of("+8")))-30;
						if(seconds > 0) {			
							System.out.println(seconds+"------2---pl3-----睡眠时间的值seconds");
							Thread.sleep(seconds*1000);
						}
						currData = dataService.findById(currData.getId());
						if (currData !=null && StringUtils.isEmpty(currData.getLotternumber())) {
							CpData.isShotFlags.put(currData.getCname(), currData.getNextperiod());
							dataService.updateLotterNumberToEmptyStr(currData.getId());
							new CheckOrder().checkLotters(currData);
						}
					} catch (Exception e) {
						e.printStackTrace();
					}finally {
						currDatas.add(18, dataService.findDataByNameAndPeriod(CpData.cnames[18], currData.getNextperiod()));
					}
				}
			}
		}).start();
	}

	/**
	 * 为各彩种生成回头看任务
	 */
	public void startReviewThread19() {
		//先拿当前未开奖的最新一期数据，睡到下期开奖时间前的一分钟执行回头看任务，最后更新当前未开奖数据
		new Thread(new Runnable() {
			public void run() {
				while(true) {
				//	System.out.println(currDatas);
					Data currData = currDatas.get(19);
					System.out.println(currData);
					if(currData == null) {
						break;
					}
					try {
						LocalDateTime openTime = LocalDateTime.parse(currData.getOpenTime(), 
								DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));
						long seconds = openTime.toEpochSecond(ZoneOffset.of("+8"))-
								(LocalDateTime.now().toEpochSecond(ZoneOffset.of("+8")));
						if(seconds > 0) {	
							System.out.println(seconds+"------1---bj28-----睡眠时间的值seconds");
							Thread.sleep(seconds*1000);
						}
						if(isFirstTimes[19]) {
							dataService.updatePreDataStatusTo1(currData.getCname(),currData.getId());							
						}else {
							dataService.updateStatusTo1(currData.getId());	
							isFirstTimes[19] = false;
						}
						LocalDateTime nextOpenTime = LocalDateTime.parse(currData.getNextStopOrderTimeEpoch(), 
								DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));
						seconds = nextOpenTime.toEpochSecond(ZoneOffset.of("+8"))-
								(LocalDateTime.now().toEpochSecond(ZoneOffset.of("+8")))-30;
						if(seconds > 0) {	
							System.out.println(seconds+"------2---bj28-----睡眠时间的值seconds");
							Thread.sleep(seconds*1000);
						}
						currData = dataService.findById(currData.getId());
						if (currData !=null && StringUtils.isEmpty(currData.getLotternumber())) {
							CpData.isShotFlags.put(currData.getCname(), currData.getNextperiod());
							dataService.updateLotterNumberToEmptyStr(currData.getId());
							new CheckOrder().checkLotters(currData);
						}
					} catch (Exception e) {
						e.printStackTrace();
					}finally {
						currDatas.add(19, dataService.findDataByNameAndPeriod(CpData.cnames[19], currData.getNextperiod()));
					}
				}
			}
		}).start();
	}

	/**
	 * 为各彩种生成回头看任务
	 */
	public void startReviewThread20() {
		//先拿当前未开奖的最新一期数据，睡到下期开奖时间前的一分钟执行回头看任务，最后更新当前未开奖数据
		new Thread(new Runnable() {
			public void run() {
				while(true) {
					Data currData = currDatas.get(20);
					if(currData == null) {
						break;
					}
					try {
						LocalDateTime openTime = LocalDateTime.parse(currData.getOpenTime(), 
								DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));
						long seconds = openTime.toEpochSecond(ZoneOffset.of("+8"))-
								(LocalDateTime.now().toEpochSecond(ZoneOffset.of("+8")));
						if(seconds > 0) {							
							Thread.sleep(seconds*1000);
						}
						if(isFirstTimes[20]) {
							dataService.updatePreDataStatusTo1(currData.getCname(),currData.getId());							
						}else {
							dataService.updateStatusTo1(currData.getId());	
							isFirstTimes[20] = false;
						}
						LocalDateTime nextOpenTime = LocalDateTime.parse(currData.getNextStopOrderTimeEpoch(), 
								DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));
						seconds = nextOpenTime.toEpochSecond(ZoneOffset.of("+8"))-
								(LocalDateTime.now().toEpochSecond(ZoneOffset.of("+8")))-30;
						if(seconds > 0) {							
							Thread.sleep(seconds*1000);
						}
						currData = dataService.findById(currData.getId());
						if (currData !=null && StringUtils.isEmpty(currData.getLotternumber())) {
							CpData.isShotFlags.put(currData.getCname(), currData.getNextperiod());
							dataService.updateLotterNumberToEmptyStr(currData.getId());
							new CheckOrder().checkLotters(currData);
						}
					} catch (Exception e) {
						e.printStackTrace();
					}finally {
						currDatas.add(20, dataService.findDataByNameAndPeriod(CpData.cnames[20], currData.getNextperiod()));
					}
				}
			}
		}).start();
	}

}
