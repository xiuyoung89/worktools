package com.ja.dao;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.ja.domain.PagingData;
import com.ja.domain.Touristy;
import com.ja.domain.User;
import com.ja.domain.Vip;

public interface UserMapper {

	/**
	 * 
	   *   方法名：getAllUsers   
	   *   描述：     查询用户所有信息                  TODO   
	   *   参数：    @return 
	 * @return: List<User>
	 */
	List<User> getAllUsers();

	/**
	 * 
	   *   方法名：getUserByid   
	   *   描述：     根据id查询用户信息                  TODO   
	   *   参数：    @param user_id 用户id
	   *   参数：    @return 
	 * @return: User
	 */
	User getUserByid(Integer user_id);
	
	/**
	 * 
	   *   方法名：checkUser   
	   *   描述：    根据用户名查询用户信息                   TODO   
	   *   参数：    @param name 用户名称
	   *   参数：    @return 
	 * @return: User
	 */
	User checkUser(String name);
	
	/**
	 * 
	   *   方法名：getAgentOrUserCount   
	   *   描述：      查询用户以及代理人数                 TODO   
	   *   参数：    @return 
	 * @return: Integer
	 */
	Integer getAgentOrUserCount(Integer agent_type);

	/**
	 * 
	   *   方法名：updateUserInfo   
	   *   描述：     修改用户信息                   TODO   
	   *   参数：    @param user 修改信息
	   *   参数：    @return 
	 * @return: int
	 */
	int updateUserInfo(User user);

	/**
	 * 
	   *   方法名：register   
	   *   描述：    添加用户                   TODO   
	   *   参数：    @param user 用户信息
	   *   参数：    @return 
	 * @return: int
	 */
	int register(User user);
	
	/**
	   *   方法名：getRegisterCount   
	   *   描述：     查询今日以及昨日的注册人数                  TODO   
	   *   参数：    @param date 时间
	   *   参数：    @return 
	 * @return: Integer
	 */
	Integer getRegisterCount(String date);

	/**
	 * 
	   *   方法名：getAllUserBalance 
	   *   描述：    查询用户余额总数                   TODO   
	   *   参数：    @return 
	 * @return: Double
	 */
	Double getAllUserBalance();

	/**
	 * 
	   *   方法名：getAllAgentRebateTotal   
	   *   描述：     查询所有的返点总计                  TODO   
	   *   参数：    @return 
	 * @return: Double
	 */
	Double getAllAgentRebateTotal();
	
	
	
	

	/** 根据用户名和密码查询用户 */
	User login(@Param("name") String name, @Param("pass") String pass);

	/** 添加试玩账户 */
	int userTryplay(User u);


	void delUser(@Param("id") Integer id);

	/** 查询所有的代理 */
	List<User> getAllAgent();

	/** 定时回收试玩账号 */
	List<User> timingRecovery();

	/** 定时删除试玩账号 */
	void timeDeleting(Integer id);

	/**
	 * 查询所有的代理
	 * 
	 * @return
	 */
	List<User> findAgentUserList();

	/**
	 * 根据条件查询代理
	 * 
	 * @param user
	 *            用户信息
	 * @return
	 */
	List<User> findTermAgentList(User user);
	
	/**
	 * 根据条件查询用户信息
	 * @param name  用户名
	 * @param ip 登录ip
	 * @param bankCard 银行卡号
	 * @param cname 开户名  就是银行卡绑定的姓名
	 * @return 返回查询到的用户   list集合包含User数据对象
	 */
	int findAllUserCounts(@Param("name")String name,@Param("ip")String ip,@Param("bankCard")String bankCard,@Param("cname")String cname);
	/**
	 * 根据条件查询用户
	 * @param paging 分页对象
	 * @param ip 登录ip地址
	 * @param bankCard  用户的银行卡号
	 * @param cname 用户的绑定银行卡的  姓名
	 * @return  查询到则返回 list集合 包含User对象 
	 */
	List<User> findAllUsers(@Param("paging")PagingData paging,@Param("ip")String ip,@Param("bankCard")String bankCard,@Param("cname")String cname);
	
	/**
	 *
	 *   方法名：findUserSuperior   
	 *   描述：      查询用户的上级                  TODO   
	 *   参数：    @param agent_id 上级id
	 *   参数：    @return 
	 * @return: User
	 */
	User findUserSuperior(Integer agent_id);

	/**
	 * 
	   *   方法名：findfristAgent   
	   *   描述：     查询直属下级                 TODO   
	   *   参数：    @param id
	   *   参数：    @return 
	 * @return: List<User>
	 */
	List<User> findFristAgent(Integer id);
	
	/**
	 * 查询所有用户的推广链接
	 * @return
	 */
	List<String> promotionLinks();
	/**
	 * 查询游客是否存在于数据库，
	 * @return
	 */
	Touristy queryWhetherTouristsExist(String ip);
	/**
	 * 创建游客
	 */
	int establish(@Param("t")Touristy t);
	/**
	 * 修改游客记录
	 * @return
	 */
	int updataTouristy(@Param("t1")Touristy t1);

	/**
	 * 
	   *   方法名：findByTimeOrNameAllUsers   
	   *   描述：     根据时间或用户名查询用户信息                  TODO   
	   *   参数：    @param startTime 开始时间
	   *   参数：    @param endTime 结束时间
	   *   参数：    @param userName 用户名称
	   *   参数：    @return 
	 * @return: List<User>
	 */
	List<User> findByTimeOrNameAllUsers(User user);

	/**
	  *   方法名：findAllUserId   
	  *   描述：    查询正常用户的id                   TODO   
	  *   参数：    @return 
	 * @return: List<User>
	 */
	List<User> findAllUserIdOrName();
	/**
	 * 统计会员的充值总金额
	 * @param id 会员id  
	 * @param name 会员的用户名   只用传其中一个就可以了   这样设计主要是 方便只有id或者只有 用户名的
	 * @return
	 */
	Double Statistics(@Param("id")Integer id,@Param("name")String name);
	/**
	 * 查询会员对照表 
	 * @return
	 */
	List<Vip> queryVip();
	/**
	 * 修改会员vip等级   id 和 name 只用传一个就可以了   这样设计主要方便只有用户名或者 只有用户id的
	 * @param id  会员id 
	 * @param name 会员用户名  
	 * @return 成功则返回1 失败则返回0
	 */
	int upDataVip(@Param("id")Integer id,@Param("name")String name,@Param("v")Vip v);
	/**
	 *根据用户的id以及上级的id转移下级     通俗一点就是   把这个用户移动到某个代理的名下去
	 * @param nameId 用户的Id
	 * @param agenId 上级的id
	 * @param odds 移动以后的赔率
	 *  @param remainder 设置他给下级可调动的赔率
	 * @param return 成功则返回1  失败则返回0
	 */
	int upDataAgen(@Param("nameId")Integer nameId,@Param("agenId")Integer agenId,@Param("odds")Double odds,@Param("remainder")Double remainder);
}