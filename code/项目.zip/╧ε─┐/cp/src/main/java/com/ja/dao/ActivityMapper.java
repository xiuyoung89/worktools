package com.ja.dao;

import java.util.Date;
import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.ja.domain.Activity;
public interface ActivityMapper {
	
	/**
	 * 查询所有开启的活动
	 * @return
	 */
	List<Activity> findEnableActivity();

	/**
	 * 查询全部活动
	 * @return
	 */
	List<Activity> findAllActivity();
	
	/**
	 * 根据id查询活动详情
	 * @param id 活动id
	 * @return
	 */
	Activity findOneActivity(Integer id);
	
	/**
	 * 根据类型查询活动
	 * @param type 活动类型
	 * @return
	 */
	List<Activity> findActivityByType(int type);
	
	/**
	 * 添加活动名称
	 * @param name 活动名称
	 * @param date 操作时间
	 * @return
	 */
	Integer addtianjiahuodong(@Param("name")String name,@Param("date")Date date);
	
	/**
	 * 添加活动信息
	 * @param activity 活动对象
	 * @return
	 */
	Integer insertActivity(Activity activity);
	
	/**
	 * 修改活动信息
	 * @param activity 活动对象
	 * @return
	 */
	Integer updateActivity(Activity activity);
	
	/**
	 * 修改弹窗内容
	 * @param activity 活动对象
	 * @return
	 */
	Integer updateAlter(Activity activity);
	
	/**
	 * 删除活动
	 * @param id
	 * @return
	 */
	int deletehd(Integer id);
	
	/**
	 * 对活动进行排序
	 * @param sort 排序号
	 * @param id 活动id
	 * @return
	 */
	int sortActivity(Integer sort, Integer id);
	
}


