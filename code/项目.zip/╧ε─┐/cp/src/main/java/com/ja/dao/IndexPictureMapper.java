package com.ja.dao;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.ja.domain.IndexPicture;

public interface IndexPictureMapper {
	/**查询所有的轮播图*/
	List<IndexPicture> getAllIndexPicture();
	
	/**根据id去查询信息*/
	IndexPicture getOneByIdIndexPicture(Integer id);

	/**添加轮播图*/
	int addIndexPicture(IndexPicture info);

	/**修改轮播图*/
	int updIndexPicture(IndexPicture info);

	/**删除轮播图*/
	int delIndexPicture(Integer id);
	
	/**禁用启用*/
	int updIndexPictureState(@Param("id")Integer id,@Param("state")Integer state);

	/**删除某一张图片*/
	int delIndexPictures(@Param("id")Integer id, @Param("count")String countPicture);
	
	/**查询最新的一组轮播*/
	IndexPicture getOneByPictureDesc();

}
