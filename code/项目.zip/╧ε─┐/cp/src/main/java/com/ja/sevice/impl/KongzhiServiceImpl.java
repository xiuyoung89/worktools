package com.ja.sevice.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ja.dao.KongzhiMapper;
import com.ja.domain.Kongzhi;
import com.ja.sevice.KongzhiService;

@Service
public class KongzhiServiceImpl implements KongzhiService {
    
	@Autowired
	private KongzhiMapper kongzhiMapper;

	/**查询下注控制信息*/
	@Override
	public List<Kongzhi> getAllKongzhi() {
		return kongzhiMapper.getAllKongzhi();
	}

	/**修改控制数量*/
	@Override
	public int updateKongzhiCount(int id,int count) {
		return kongzhiMapper.updateKongzhiCount(id,count);
	}

	@Override
	public List<Kongzhi> getOneKongzhi(String cname) {
		return kongzhiMapper.getOneKongzhi(cname);
	}

	@Override
	public Kongzhi getOneKongzhiById(Integer id) {
		return kongzhiMapper.getOneKongzhiById(id);
	}

}
