package com.ja.check.data;

/**
 * @DESC: 从开彩网爬取彩票数据的类
 * @AUTH: qhzh 
 * @DATE: 2018年9月4日 上午9:38:30
 */
public class StandbyCpDataOf500Cp {

}
