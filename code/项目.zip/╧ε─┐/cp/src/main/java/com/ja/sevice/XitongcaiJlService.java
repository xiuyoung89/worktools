package com.ja.sevice;

import java.util.List;

import com.ja.domain.Data;
import com.ja.domain.XitongcaiJl;

public interface XitongcaiJlService {
	
	/**
	 * 查询系统彩预设记录
	 * @param startIndex 起始数
	 * @param lineCount 一页多少行
	 * @param model 类型 
	 * @return
	 */
	List<XitongcaiJl> getPageData(Integer startIndex, Integer lineCount, int model);
	
	/**
	 * 模糊查询系统彩记录
	 * @param startIndex 
	 * @param lineCount 
	 * @param model 
	 */
	List<XitongcaiJl> findSystemJl(Integer startIndex, Integer lineCount, String cname,String period,String date1,String date2, int model);

	/**
	 * 
	    *   方法名：getPageDataCounts   
	    *   描述：     查询私彩的记录数                  TODO   
	    *   参数：    @return 
	 * @return: Integer
	 */
	Integer getPageDataCounts();

	/**
	 * 
	    *   方法名：findSystemJlCounts   
	    *   描述：                       TODO   
	    *   参数：    @param data
	    *   参数：    @return 
	 * @return: Integer
	 */
	Integer findSystemJlCounts(Data data,String date1,String date2);

}
