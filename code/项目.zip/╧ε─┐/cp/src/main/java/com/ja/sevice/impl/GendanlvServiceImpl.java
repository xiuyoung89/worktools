package com.ja.sevice.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ja.dao.GendanlvMapper;
import com.ja.domain.Gendanlv;
import com.ja.sevice.GendanlvService;

@Service
/**
 * @author GL 跟单推荐费比例
 * @DATE 2018年1月15日 18:03:40
 */
public class GendanlvServiceImpl implements GendanlvService {

	@Autowired
	private GendanlvMapper gendanlvMapper;

	/** 查询推荐费比率 */
	@Override
	public Gendanlv getFindRebate() {
		return gendanlvMapper.getFindRebate();
	}

	/**修改跟单的推荐比率*/
	@Override
	public int updateGendanlv(Gendanlv gendan) {
		return gendanlvMapper.updateGendanlv(gendan);
	}

	/**添加跟单的推荐费规则*/
	@Override
	public int addGendanlv(Gendanlv gendan) {
		return gendanlvMapper.addGendanlv(gendan);
	}

	@Override
	public int delGendanlv(Integer id) {
		return  gendanlvMapper.delGendanlv(id);
	}
	
}