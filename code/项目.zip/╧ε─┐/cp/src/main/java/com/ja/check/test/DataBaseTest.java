package com.ja.check.test;

import java.util.List;

import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.ja.domain.Data;
import com.ja.domain.Liushui;
import com.ja.domain.User;
import com.ja.sevice.IDataService;
import com.ja.sevice.IUserService;
import com.ja.sevice.LiushuiService;

public class DataBaseTest {
	private ClassPathXmlApplicationContext ctx = new ClassPathXmlApplicationContext(
			"/spring/applicationContext-dao.xml", "/spring/applicationContext-service.xml");
	
	IDataService dataService = (IDataService) ctx.getBean("dataService");
	
	IUserService userService = (IUserService) ctx.getBean("userService");
	
	LiushuiService liushuiService = (LiushuiService) ctx.getBean("liushuiService");

	/**
	 * 
	   *   方法名：insertData   
	   *   描述：    测试200万条数据性能                   TODO   
	   *   参数：     无
	 * @return: void
	 */
	public void insertData() {
		for (int i = 0; i < 10000 * 200; i++) {
			Data data = new Data();
			data.setCname("bjpk10");
			data.setGameNameInChinese("北京PK10");
			dataService.insert(data);
		}
	}
	
	
	/**
	 * 修改流水表加字段之前的数据
	 * @return
	 */
	public int updateWaterData() {
		List<Liushui> water = liushuiService.findWaterData();
		for(Liushui liushui : water) {
			User user = userService.getUserByid(liushui.getUserid());
			liushui.setUser_type(user.getState());
			liushuiService.updateWaterData(liushui);
		}
		return 1;
	}
	
	
	public static void main(String[] args) {
		
		DataBaseTest test = new DataBaseTest();
		test.updateWaterData();
		System.err.println("修改数据完毕!!");
		
		
	}
	
	

}
