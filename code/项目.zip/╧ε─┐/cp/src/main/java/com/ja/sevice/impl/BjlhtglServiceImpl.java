package com.ja.sevice.impl;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.ja.dao.BjlMapper;
import com.ja.dao.BjlhtglMapper;
import com.ja.domain.AdminUser;
import com.ja.domain.BaccaratBulletin;
import com.ja.domain.Bjl;
import com.ja.domain.Bjldata;
import com.ja.domain.Dama;
import com.ja.domain.Damal;
import com.ja.domain.Liushui;
import com.ja.domain.Lotter;
import com.ja.domain.PagingData;
import com.ja.sevice.BjlhtglService;

public class BjlhtglServiceImpl implements BjlhtglService{
	@Autowired
	BjlhtglMapper bjl;
	@Autowired
	BjlMapper  bjlMapper;
	@Override
	public List<Bjl> xiazjl(PagingData paging,String name,String time1,String time2,String period,Integer status,Integer state,Integer id) {
				if(time1 != null && time2 != null) {//去掉会报空指针异常  不知道就看源码看明白了在改 别瞎几把乱改，会报错的  去掉if可能会出现有空串的情况
					time1 = time1.trim();
					time2 = time2.trim();
				}
		return bjl.xiazjl(paging,name, time1, time2, period, status,state,id);
	}
	@Override
	public BaccaratBulletin basicSettingsOfBaccarat(Integer tableNumber) {
		return bjl.basicSettingsOfBaccarat(tableNumber);
	}
	@Override
	public Lotter pailu() {
		return bjl.pailu(); 
	}
	@Override
	public int deletexzjl(int id) {
		return bjl.deletexzjl(id);  
	}
	@Override
	public int fandian(Double percent1) {
		return bjl.fandian(percent1);
	}
	@Override
	public Integer xiazjlCounts(String user, String time1, String time2, String period, Integer status, Integer state) {
		return bjl.xiazjlCounts(user, time1, time2, period, status,state);
	}
	@Override
	public int updateBjlControl(int tableNumber, int percentage) {
		return bjl.updateBjlControl(tableNumber, percentage);
	}
	@Override
	public int updateBjlRoomMoney(int tableNumber, String maximumAmount, String minimumSum) {
		return bjl.updateBjlRoomMoney(tableNumber, maximumAmount, minimumSum);
	}
	@Override
	public int upDateOdds(String rebate1, String rebate2, String rebate3, String rebate4, String rebate5,
			String rebate6, String rebate7, String rebate8, String rebate9, String name) {
		return bjl.upDateOdds(rebate1, rebate2, rebate3, rebate4, rebate5, rebate6, rebate7, rebate8, rebate9, name);
	}
	@Override
	public Integer lotteryRecord(String date1, String date2, String period, Integer tableNumber) {
		return bjl.lotteryRecord(date1, date2, period, tableNumber);
	}
	@Override
	public List<Bjldata> lotteryRecords(PagingData paging, String date1, String date2, String period,
			Integer tableNumber) {
		return bjl.lotteryRecords(paging, date1, date2, period, tableNumber);
	}
	@Override
	public int baccaratPresupposition(Bjldata data) {
		if("".equals(data.getLeisureCard())) {
			data.setLeisureCard(null);
		}
		if("".equals(data.getDealerCard())) {
			data.setDealerCard(null);
		}
		Bjldata  d = bjlMapper.queryBjlDatas(data.getIssueNumber(), data.getTableNumber());
		//System.out.println(data.toString());
		if(d.getState() == 1) {
			//当期已开奖
			return 5;
		}
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
		Long endTime;
		try {
			endTime = sdf.parse(d.getOpeningTimeOfTheCurrentAward()).getTime();
			//当前系统时间
			Long startTime = sdf.parse(sdf.format(new Date())).getTime();
			Long time = (endTime - startTime) - 15000;
			if(time < 0) {
				return 5;//当期已开奖
			}
		} catch (ParseException e) {}
		return bjl.baccaratPresupposition(data);
	}
	@Override
	public int baccaratRefund(Integer tableNumber, String issueNumber,AdminUser admin) {
		if(tableNumber == null || issueNumber == null || "".equals(issueNumber)) {
			return 0;//参数不能为空
		}
		List<Bjl> list =  bjl.QueryAnnotationRecord(tableNumber, issueNumber);
		for (Bjl b : list) {
			if(b.getState() == 1) {
				return 1;//已经开奖无法进行退款
			}else {
				SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
				bjl.upDataBetState(3,b.getId());//修改下注数据的状态
				Double money = bjlMapper.Money(b.getUserid());//查询用户余额
				bjlMapper.Moneyxg( money+b.getTotalBet(), b.getUserid());//修改用户余额
				//退款添加流水
				Liushui liushui = new Liushui();
				liushui.setHuiyuanzh(b.getName());//会员账号
				liushui.setBdtype("百家乐官方开奖异常");//变动类型
				liushui.setBdqjine(money);//变动前金额
				liushui.setBdjine(b.getTotalBet());//变动金额
				liushui.setBdhjine(money+b.getTotalBet());//变动后余额
				liushui.setCreatetime(sdf.format(new Date()));//变动时间
				liushui.setCname("百家乐");//彩种名称
				liushui.setPeriod(b.getIssueNumber());//期号
				liushui.setState(true);//收入还是支出   true 收入  false 支出
				liushui.setCzname(admin.getName());
				liushui.setUserid(b.getUserid());
				bjlMapper.addWater(liushui);
				//添加打码记录
				Dama dama = new Dama();
				dama.setHuiyuanzh(b.getName());//会员账号	
				dama.setBdtype("百家乐退款");//变动类型
				dama.setBdcount(b.getTotalBet());//变动打码量
				dama.setCreatetime(sdf.format(new Date()));//创建时间
				dama.setCzname("系统自动");//操作人员
				dama.setBeizhu("百家乐投注");
				dama.setUserid(b.getUserid());//会员id
				bjlMapper.addCode(dama);
				
				//减掉用户的打码量
				if(b.getUserstate() == 1) {//正规玩家才减掉打码
					Damal da = bjlMapper.queryCode(b.getUserid());
					Damal d = new Damal();
					d.setHuiyuanzh(b.getName());//会员账号
					d.setDamaliang(da.getDamaliang()-b.getTotalBet());//最新打码//减掉用户的打码量
					d.setCreatetime(sdf.format(new Date()));//创建时间
					d.setUserid(b.getUserid());//用户id
					bjlMapper.modifyUserCodings(d);
				}
				return 2;
			}
		}
		return 3;//没有要退款的
	}
}
