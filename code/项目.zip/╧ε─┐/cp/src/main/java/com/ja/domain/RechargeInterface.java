package com.ja.domain;

import java.io.Serializable;

public class RechargeInterface implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 638418499619937670L;

	private Integer id; // 支付接口

	private String payName; // 支付接口名称

	private String dealerURL;// 商户域名URL

	private String P_UserId;// 商户编号

	private String SalfStr;// 商户安全码

	private String shopName; // 商品名称

	private String payInterfaceURL;// 支付接口URL
	
	private String payQueryURL;// 异步查询地址

	private String P_ChannelId;// 支付方式编号

	private String minMoney;// 充值最小金额

	private String maxMoney;// 充值最大金额

	private String createTime;// 操作时间

	private String updateName;// 操作人姓名

    
    public static long getSerialversionuid() {
		return serialVersionUID;
	}
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getPayName() {
		return payName;
	}

	public void setPayName(String payName) {
		this.payName = payName;
	}

	public String getPayInterfaceURL() {
		return payInterfaceURL;
	}

	public void setPayInterfaceURL(String payInterfaceURL) {
		this.payInterfaceURL = payInterfaceURL;
	}

	public String getDealerURL() {
		return dealerURL;
	}

	public void setDealerURL(String dealerURL) {
		this.dealerURL = dealerURL;
	}

	public String getP_UserId() {
		return P_UserId;
	}

	public void setP_UserId(String p_UserId) {
		P_UserId = p_UserId;
	}

	public String getSalfStr() {
		return SalfStr;
	}

	public void setSalfStr(String salfStr) {
		SalfStr = salfStr;
	}

	public String getShopName() {
		return shopName;
	}

	public void setShopName(String shopName) {
		this.shopName = shopName;
	}

	public String getPayQueryURL() {
		return payQueryURL;
	}

	public void setPayQueryURL(String payQueryURL) {
		this.payQueryURL = payQueryURL;
	}

	public String getP_ChannelId() {
		return P_ChannelId;
	}

	public void setP_ChannelId(String p_ChannelId) {
		P_ChannelId = p_ChannelId;
	}

	public String getMinMoney() {
		return minMoney;
	}

	public void setMinMoney(String minMoney) {
		this.minMoney = minMoney;
	}

	public String getMaxMoney() {
		return maxMoney;
	}

	public void setMaxMoney(String maxMoney) {
		this.maxMoney = maxMoney;
	}

	public String getCreateTime() {
		return createTime;
	}

	public void setCreateTime(String createTime) {
		this.createTime = createTime;
	}

	public String getUpdateName() {
		return updateName;
	}

	public void setUpdateName(String updateName) {
		this.updateName = updateName;
	}

	@Override
	public String toString() {
		return "RechargeInterface [id=" + id + ", payName=" + payName + ", payInterfaceURL=" + payInterfaceURL
				+ ", dealerURL=" + dealerURL + ", P_UserId=" + P_UserId + ", SalfStr=" + SalfStr + ", shopName="
				+ shopName + ", payQueryURL=" + payQueryURL + ", P_ChannelId=" + P_ChannelId + ", minMoney=" + minMoney + ", maxMoney=" + maxMoney
				+ ", createTime=" + createTime + ", updateName=" + updateName + "]";
	}

	public RechargeInterface() {
		super();
	}

}