package com.ja.domain;

import java.io.Serializable;

public class AgentTotal implements Serializable{
	
    /**
	 * 
	 */
	private static final long serialVersionUID = -4441227379990131117L;

	private Integer id;//代理返点统计表

    private String user_name;//会员帐号

    private Double recharge_money;//充值金额
    
    private Double code_money;//打码金额
    
    private Double rebate_money;//返点金额
    
    private Double balance;//余额
    
    private Integer agent_grade;//代理等级
    
    private Double one_money;//个人余额
    
    private Double one_recharge;//个人充值
    
    private Double one_drawing;//个人提款
    
    private Double one_betting;//个人投注
    
    private Double one_award;//个人派奖
    
    private Double one_activity;//个人活动
    
    private Double one_chessCard_total;//棋牌亏盈
    
    private Double one_whole_total;//全部亏盈
    
    private String created_time;//创建时间

    private Integer state;//开关

    private Integer agent_id;//上级id
    
    private Integer user_id;//用户id

	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	
    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

	public String getUser_name() {
		return user_name;
	}

	public void setUser_name(String user_name) {
		this.user_name = user_name;
	}

	public Double getRecharge_money() {
		return recharge_money;
	}

	public void setRecharge_money(Double recharge_money) {
		this.recharge_money = recharge_money;
	}

	public Double getCode_money() {
		return code_money;
	}

	public void setCode_money(Double code_money) {
		this.code_money = code_money;
	}

	public Double getRebate_money() {
		return rebate_money;
	}

	public void setRebate_money(Double rebate_money) {
		this.rebate_money = rebate_money;
	}

	public Double getBalance() {
		return balance;
	}

	public void setBalance(Double balance) {
		this.balance = balance;
	}

	public Integer getAgent_grade() {
		return agent_grade;
	}

	public void setAgent_grade(Integer agent_grade) {
		this.agent_grade = agent_grade;
	}

	public String getCreated_time() {
		return created_time;
	}

	public Double getOne_money() {
		return one_money;
	}

	public void setOne_money(Double one_money) {
		this.one_money = one_money;
	}

	public Double getOne_recharge() {
		return one_recharge;
	}

	public void setOne_recharge(Double one_recharge) {
		this.one_recharge = one_recharge;
	}

	public Double getOne_drawing() {
		return one_drawing;
	}

	public void setOne_drawing(Double one_drawing) {
		this.one_drawing = one_drawing;
	}

	public Double getOne_betting() {
		return one_betting;
	}

	public void setOne_betting(Double one_betting) {
		this.one_betting = one_betting;
	}

	public Double getOne_award() {
		return one_award;
	}

	public void setOne_award(Double one_award) {
		this.one_award = one_award;
	}

	public Double getOne_activity() {
		return one_activity;
	}

	public void setOne_activity(Double one_activity) {
		this.one_activity = one_activity;
	}

	public Double getOne_chessCard_total() {
		return one_chessCard_total;
	}

	public void setOne_chessCard_total(Double one_chessCard_total) {
		this.one_chessCard_total = one_chessCard_total;
	}

	public Double getOne_whole_total() {
		return one_whole_total;
	}

	public void setOne_whole_total(Double one_whole_total) {
		this.one_whole_total = one_whole_total;
	}

	public void setCreated_time(String created_time) {
		this.created_time = created_time;
	}

	public Integer getState() {
		return state;
	}

	public void setState(Integer state) {
		this.state = state;
	}

	public Integer getAgent_id() {
		return agent_id;
	}

	public void setAgent_id(Integer agent_id) {
		this.agent_id = agent_id;
	}

	public Integer getUser_id() {
		return user_id;
	}

	public void setUser_id(Integer user_id) {
		this.user_id = user_id;
	}

	public AgentTotal() {
		super();
	}

	@Override
	public String toString() {
		return "AgentTotal [id=" + id + ", user_name=" + user_name + ", recharge_money=" + recharge_money
				+ ", code_money=" + code_money + ", rebate_money=" + rebate_money + ", balance=" + balance
				+ ", agent_grade=" + agent_grade + ", one_money=" + one_money + ", one_recharge=" + one_recharge
				+ ", one_drawing=" + one_drawing + ", one_betting=" + one_betting + ", one_award=" + one_award
				+ ", one_activity=" + one_activity + ", one_chessCard_total=" + one_chessCard_total
				+ ", one_whole_total=" + one_whole_total + ", created_time=" + created_time + ", state=" + state
				+ ", agent_id=" + agent_id + ", user_id=" + user_id + "]";
	}



}