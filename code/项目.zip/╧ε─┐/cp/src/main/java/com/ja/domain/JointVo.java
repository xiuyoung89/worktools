package com.ja.domain;

import java.io.Serializable;

public class JointVo implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 8244367530103427472L;
	// 合买订单
	private String user;// 用户名
	private Integer zcount;// 总分数
	private Double price;// 单份金额
	private Integer rcount;// 认购分数
	private Integer bcount;// 保底份数
	private Integer sjbcount;// 实际保底份数
	private Integer hcount;// 合买分数
	private Integer scount;// 剩下分数
	private Double hMoney;// 购买金额
	private Double fajine;// 方案金额
	private Double zMoney;// 中奖金额
	private Double zjjine;// 中奖总金额
	private String shenglv;// 中奖胜率
	private String orderNum;// 订单号
	private String checkNum;// 开奖号
	private String cpname;// 彩种名称
	private String qihao;// 期号
	private Integer ddstate;// 订单状态
	private Integer tqstate;// 退钱状态
	private String createtime;// 创建时间
	private Integer state;// 发起人-合买人-状态
	private Integer userid;// 用户id
	private String huiyuanzh;// 会员名称
	private Double payMoney; // 购买金额
	private String createTime; // 创建时间
	private Double rebate;// 推荐费比例
	private Double rebateMoney;// 推荐费金额
	private Double shouru;// 收入
	private Integer beishu;// 倍数
	private Integer orderid;// 倍数
	private Double acount;// 倍数
	private Double income;//总收益
	private Integer counts;

    
    public static long getSerialversionuid() {
		return serialVersionUID;
	}
	private Integer orderState; // 订单状态

	private Integer id; // 订单id

	private String cname;// 彩种名

	private String cname1;// 彩种中文名

	private String str1;// 玩法1-40

	private String str2;

	private String str3;

	private String str4;

	private String str5;

	private String str6;

	private String str7;

	private String str8;

	private String str9;

	private String str10;

	private String str11;

	private String str12;

	private String str13;

	private String str14;

	private String str15;

	private String str16;

	private String str17;

	private String str18;

	private String str19;

	private String str20;

	private String str21;

	private String str22;

	private String str23;

	private String str24;

	private String str25;

	private String str26;

	private String str27;

	private String str28;

	private String str29;

	private String str30;

	private String str31;

	private String str32;

	private String str33;

	private String str34;

	private String str35;

	private String str36;

	private String str37;

	private String str38;

	private String str39;

	private String str40;

	private String cplay1;// 玩法

	private String cplay2;

	private String cplay3;

	private String cplay4;

	private String cplay5;

	private String cplay6;

	private String cplay7;

	private String cplay8;

	private String cplay9;

	private String cplay10;

	private String cplay11;

	private String cplay12;

	private String cplay13;

	private String cplay14;

	private String cplay15;

	private String cplay16;

	private String cplay17;

	private String cplay18;

	private String cplay19;

	private String cplay20;

	private String cplay21;

	private String cplay22;

	private String cplay23;

	private String cplay24;

	private String cplay25;

	private String cplay26;

	private String cplay27;

	private String cplay28;

	private String cplay29;

	private String cplay30;

	private String cplay31;

	private String cplay32;

	private String cplay33;

	private String cplay34;

	private String cplay35;

	private String cplay36;

	private String cplay37;

	private String cplay38;

	private String cplay39;

	private String cplay40;

	private String odds;// 订单类型

	private Double goalmoney;// 中奖金额

	private String tcplay;// 中和局退还玩法
	
	private Integer lotterCount;//下注注数

	public Integer getLotterCount() {
		return lotterCount;
	}

	public void setLotterCount(Integer lotterCount) {
		this.lotterCount = lotterCount;
	}

	public Double getAcount() {
		return acount;
	}

	public void setAcount(Double acount) {
		this.acount = acount;
	}

	public Integer getOrderid() {
		return orderid;
	}

	public void setOrderid(Integer orderid) {
		this.orderid = orderid;
	}

	public Double getRebate() {
		return rebate;
	}

	public void setRebate(Double rebate) {
		this.rebate = rebate;
	}

	public Double getRebateMoney() {
		return rebateMoney;
	}

	public void setRebateMoney(Double rebateMoney) {
		this.rebateMoney = rebateMoney;
	}

	public Double getShouru() {
		return shouru;
	}

	public void setShouru(Double shouru) {
		this.shouru = shouru;
	}

	public Integer getBeishu() {
		return beishu;
	}

	public void setBeishu(Integer beishu) {
		this.beishu = beishu;
	}

	public Double getPayMoney() {
		return payMoney;
	}

	public void setPayMoney(Double payMoney) {
		this.payMoney = payMoney;
	}

	public String getCreateTime() {
		return createTime;
	}

	public void setCreateTime(String createTime) {
		this.createTime = createTime;
	}

	public Integer getOrderState() {
		return orderState;
	}

	public void setOrderState(Integer orderState) {
		this.orderState = orderState;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getUser() {
		return user;
	}

	public void setUser(String user) {
		this.user = user;
	}

	public Integer getZcount() {
		return zcount;
	}

	public void setZcount(Integer zcount) {
		this.zcount = zcount;
	}

	public Double getPrice() {
		return price;
	}

	public void setPrice(Double price) {
		this.price = price;
	}

	public Integer getRcount() {
		return rcount;
	}

	public String getShenglv() {
		return shenglv;
	}

	public void setShenglv(String shenglv) {
		this.shenglv = shenglv;
	}

	public void setRcount(Integer rcount) {
		this.rcount = rcount;
	}

	public Integer getBcount() {
		return bcount;
	}

	public void setBcount(Integer bcount) {
		this.bcount = bcount;
	}

	public Integer getSjbcount() {
		return sjbcount;
	}

	public void setSjbcount(Integer sjbcount) {
		this.sjbcount = sjbcount;
	}

	public Integer getHcount() {
		return hcount;
	}

	public void setHcount(Integer hcount) {
		this.hcount = hcount;
	}

	public Integer getScount() {
		return scount;
	}

	public void setScount(Integer scount) {
		this.scount = scount;
	}

	public Double gethMoney() {
		return hMoney;
	}

	public void sethMoney(Double hMoney) {
		this.hMoney = hMoney;
	}

	public Double getFajine() {
		return fajine;
	}

	public void setFajine(Double fajine) {
		this.fajine = fajine;
	}

	public Double getzMoney() {
		return zMoney;
	}

	public void setzMoney(Double zMoney) {
		this.zMoney = zMoney;
	}

	public Double getZjjine() {
		return zjjine;
	}

	public void setZjjine(Double zjjine) {
		this.zjjine = zjjine;
	}

	public String getOrderNum() {
		return orderNum;
	}

	public void setOrderNum(String orderNum) {
		this.orderNum = orderNum;
	}

	public String getCheckNum() {
		return checkNum;
	}

	public void setCheckNum(String checkNum) {
		this.checkNum = checkNum;
	}

	public String getCpname() {
		return cpname;
	}

	public void setCpname(String cpname) {
		this.cpname = cpname;
	}

	public String getQihao() {
		return qihao;
	}

	public void setQihao(String qihao) {
		this.qihao = qihao;
	}

	public Integer getDdstate() {
		return ddstate;
	}

	public void setDdstate(Integer ddstate) {
		this.ddstate = ddstate;
	}

	public Integer getTqstate() {
		return tqstate;
	}

	public void setTqstate(Integer tqstate) {
		this.tqstate = tqstate;
	}

	public String getCreatetime() {
		return createtime;
	}

	public void setCreatetime(String createtime) {
		this.createtime = createtime;
	}

	public Integer getState() {
		return state;
	}

	public void setState(Integer state) {
		this.state = state;
	}

	public Integer getUserid() {
		return userid;
	}

	public void setUserid(Integer userid) {
		this.userid = userid;
	}

	public String getHuiyuanzh() {
		return huiyuanzh;
	}

	public void setHuiyuanzh(String huiyuanzh) {
		this.huiyuanzh = huiyuanzh;
	}

	public String getCname() {
		return cname;
	}

	public void setCname(String cname) {
		this.cname = cname;
	}

	public String getCname1() {
		return cname1;
	}

	public void setCname1(String cname1) {
		this.cname1 = cname1;
	}
	

	public Double getIncome() {
		return income;
	}

	public void setIncome(Double income) {
		this.income = income;
	}


	public String getStr1() {
		return str1;
	}

	public void setStr1(String str1) {
		this.str1 = str1;
	}

	public String getStr2() {
		return str2;
	}

	public void setStr2(String str2) {
		this.str2 = str2;
	}

	public String getStr3() {
		return str3;
	}

	public void setStr3(String str3) {
		this.str3 = str3;
	}

	public String getStr4() {
		return str4;
	}

	public void setStr4(String str4) {
		this.str4 = str4;
	}

	public String getStr5() {
		return str5;
	}

	public void setStr5(String str5) {
		this.str5 = str5;
	}

	public String getStr6() {
		return str6;
	}

	public void setStr6(String str6) {
		this.str6 = str6;
	}

	public String getStr7() {
		return str7;
	}

	public void setStr7(String str7) {
		this.str7 = str7;
	}

	public String getStr8() {
		return str8;
	}

	public void setStr8(String str8) {
		this.str8 = str8;
	}

	public String getStr9() {
		return str9;
	}

	public void setStr9(String str9) {
		this.str9 = str9;
	}

	public String getStr10() {
		return str10;
	}

	public void setStr10(String str10) {
		this.str10 = str10;
	}

	public String getStr11() {
		return str11;
	}

	public void setStr11(String str11) {
		this.str11 = str11;
	}

	public String getStr12() {
		return str12;
	}

	public void setStr12(String str12) {
		this.str12 = str12;
	}

	public String getStr13() {
		return str13;
	}

	public void setStr13(String str13) {
		this.str13 = str13;
	}

	public String getStr14() {
		return str14;
	}

	public void setStr14(String str14) {
		this.str14 = str14;
	}

	public String getStr15() {
		return str15;
	}

	public void setStr15(String str15) {
		this.str15 = str15;
	}

	public String getStr16() {
		return str16;
	}

	public void setStr16(String str16) {
		this.str16 = str16;
	}

	public String getStr17() {
		return str17;
	}

	public void setStr17(String str17) {
		this.str17 = str17;
	}

	public String getStr18() {
		return str18;
	}

	public void setStr18(String str18) {
		this.str18 = str18;
	}

	public String getStr19() {
		return str19;
	}

	public void setStr19(String str19) {
		this.str19 = str19;
	}

	public String getStr20() {
		return str20;
	}

	public void setStr20(String str20) {
		this.str20 = str20;
	}

	public String getStr21() {
		return str21;
	}

	public void setStr21(String str21) {
		this.str21 = str21;
	}

	public String getStr22() {
		return str22;
	}

	public void setStr22(String str22) {
		this.str22 = str22;
	}

	public String getStr23() {
		return str23;
	}

	public void setStr23(String str23) {
		this.str23 = str23;
	}

	public String getStr24() {
		return str24;
	}

	public void setStr24(String str24) {
		this.str24 = str24;
	}

	public String getStr25() {
		return str25;
	}

	public void setStr25(String str25) {
		this.str25 = str25;
	}

	public String getStr26() {
		return str26;
	}

	public void setStr26(String str26) {
		this.str26 = str26;
	}

	public String getStr27() {
		return str27;
	}

	public void setStr27(String str27) {
		this.str27 = str27;
	}

	public String getStr28() {
		return str28;
	}

	public void setStr28(String str28) {
		this.str28 = str28;
	}

	public String getStr29() {
		return str29;
	}

	public void setStr29(String str29) {
		this.str29 = str29;
	}

	public String getStr30() {
		return str30;
	}

	public void setStr30(String str30) {
		this.str30 = str30;
	}

	public String getStr31() {
		return str31;
	}

	public void setStr31(String str31) {
		this.str31 = str31;
	}

	public String getStr32() {
		return str32;
	}

	public void setStr32(String str32) {
		this.str32 = str32;
	}

	public String getStr33() {
		return str33;
	}

	public void setStr33(String str33) {
		this.str33 = str33;
	}

	public String getStr34() {
		return str34;
	}

	public void setStr34(String str34) {
		this.str34 = str34;
	}

	public String getStr35() {
		return str35;
	}

	public void setStr35(String str35) {
		this.str35 = str35;
	}

	public String getStr36() {
		return str36;
	}

	public void setStr36(String str36) {
		this.str36 = str36;
	}

	public String getStr37() {
		return str37;
	}

	public void setStr37(String str37) {
		this.str37 = str37;
	}

	public String getStr38() {
		return str38;
	}

	public void setStr38(String str38) {
		this.str38 = str38;
	}

	public String getStr39() {
		return str39;
	}

	public void setStr39(String str39) {
		this.str39 = str39;
	}

	public String getStr40() {
		return str40;
	}

	public void setStr40(String str40) {
		this.str40 = str40;
	}

	public String getCplay1() {
		return cplay1;
	}

	public void setCplay1(String cplay1) {
		this.cplay1 = cplay1;
	}

	public String getCplay2() {
		return cplay2;
	}

	public void setCplay2(String cplay2) {
		this.cplay2 = cplay2;
	}

	public String getCplay3() {
		return cplay3;
	}

	public void setCplay3(String cplay3) {
		this.cplay3 = cplay3;
	}

	public String getCplay4() {
		return cplay4;
	}

	public void setCplay4(String cplay4) {
		this.cplay4 = cplay4;
	}

	public String getCplay5() {
		return cplay5;
	}

	public void setCplay5(String cplay5) {
		this.cplay5 = cplay5;
	}

	public String getCplay6() {
		return cplay6;
	}

	public Integer getCounts() {
		return counts;
	}

	public void setCounts(Integer counts) {
		this.counts = counts;
	}

	public void setCplay6(String cplay6) {
		this.cplay6 = cplay6;
	}

	public String getCplay7() {
		return cplay7;
	}

	public void setCplay7(String cplay7) {
		this.cplay7 = cplay7;
	}

	public String getCplay8() {
		return cplay8;
	}

	public void setCplay8(String cplay8) {
		this.cplay8 = cplay8;
	}

	public String getCplay9() {
		return cplay9;
	}

	public void setCplay9(String cplay9) {
		this.cplay9 = cplay9;
	}

	public String getCplay10() {
		return cplay10;
	}

	public void setCplay10(String cplay10) {
		this.cplay10 = cplay10;
	}

	public String getCplay11() {
		return cplay11;
	}

	public void setCplay11(String cplay11) {
		this.cplay11 = cplay11;
	}

	public String getCplay12() {
		return cplay12;
	}

	public void setCplay12(String cplay12) {
		this.cplay12 = cplay12;
	}

	public String getCplay13() {
		return cplay13;
	}

	public void setCplay13(String cplay13) {
		this.cplay13 = cplay13;
	}

	public String getCplay14() {
		return cplay14;
	}

	public void setCplay14(String cplay14) {
		this.cplay14 = cplay14;
	}

	public String getCplay15() {
		return cplay15;
	}

	public void setCplay15(String cplay15) {
		this.cplay15 = cplay15;
	}

	public String getCplay16() {
		return cplay16;
	}

	public void setCplay16(String cplay16) {
		this.cplay16 = cplay16;
	}

	public String getCplay17() {
		return cplay17;
	}

	public void setCplay17(String cplay17) {
		this.cplay17 = cplay17;
	}

	public String getCplay18() {
		return cplay18;
	}

	public void setCplay18(String cplay18) {
		this.cplay18 = cplay18;
	}

	public String getCplay19() {
		return cplay19;
	}

	public void setCplay19(String cplay19) {
		this.cplay19 = cplay19;
	}

	public String getCplay20() {
		return cplay20;
	}

	public void setCplay20(String cplay20) {
		this.cplay20 = cplay20;
	}

	public String getCplay21() {
		return cplay21;
	}

	public void setCplay21(String cplay21) {
		this.cplay21 = cplay21;
	}

	public String getCplay22() {
		return cplay22;
	}

	public void setCplay22(String cplay22) {
		this.cplay22 = cplay22;
	}

	public String getCplay23() {
		return cplay23;
	}

	public void setCplay23(String cplay23) {
		this.cplay23 = cplay23;
	}

	public String getCplay24() {
		return cplay24;
	}

	public void setCplay24(String cplay24) {
		this.cplay24 = cplay24;
	}

	public String getCplay25() {
		return cplay25;
	}

	public void setCplay25(String cplay25) {
		this.cplay25 = cplay25;
	}

	public String getCplay26() {
		return cplay26;
	}

	public void setCplay26(String cplay26) {
		this.cplay26 = cplay26;
	}

	public String getCplay27() {
		return cplay27;
	}

	public void setCplay27(String cplay27) {
		this.cplay27 = cplay27;
	}

	public String getCplay28() {
		return cplay28;
	}

	public void setCplay28(String cplay28) {
		this.cplay28 = cplay28;
	}

	public String getCplay29() {
		return cplay29;
	}

	public void setCplay29(String cplay29) {
		this.cplay29 = cplay29;
	}

	public String getCplay30() {
		return cplay30;
	}

	public void setCplay30(String cplay30) {
		this.cplay30 = cplay30;
	}

	public String getCplay31() {
		return cplay31;
	}

	public void setCplay31(String cplay31) {
		this.cplay31 = cplay31;
	}

	public String getCplay32() {
		return cplay32;
	}

	public void setCplay32(String cplay32) {
		this.cplay32 = cplay32;
	}

	public String getCplay33() {
		return cplay33;
	}

	public void setCplay33(String cplay33) {
		this.cplay33 = cplay33;
	}

	public String getCplay34() {
		return cplay34;
	}

	public void setCplay34(String cplay34) {
		this.cplay34 = cplay34;
	}

	public String getCplay35() {
		return cplay35;
	}

	public void setCplay35(String cplay35) {
		this.cplay35 = cplay35;
	}

	public String getCplay36() {
		return cplay36;
	}

	public void setCplay36(String cplay36) {
		this.cplay36 = cplay36;
	}

	public String getCplay37() {
		return cplay37;
	}

	public void setCplay37(String cplay37) {
		this.cplay37 = cplay37;
	}

	public String getCplay38() {
		return cplay38;
	}

	public void setCplay38(String cplay38) {
		this.cplay38 = cplay38;
	}

	public String getCplay39() {
		return cplay39;
	}

	public void setCplay39(String cplay39) {
		this.cplay39 = cplay39;
	}

	public String getCplay40() {
		return cplay40;
	}

	public void setCplay40(String cplay40) {
		this.cplay40 = cplay40;
	}

	public String getOdds() {
		return odds;
	}

	public void setOdds(String odds) {
		this.odds = odds;
	}

	public Double getGoalmoney() {
		return goalmoney;
	}

	public void setGoalmoney(Double goalmoney) {
		this.goalmoney = goalmoney;
	}

	public String getTcplay() {
		return tcplay;
	}

	public void setTcplay(String tcplay) {
		this.tcplay = tcplay;
	}

	public JointVo() {
		super();
	}

	@Override
	public String toString() {
		return "JointVo [user=" + user + ", zcount=" + zcount + ", price=" + price + ", rcount=" + rcount + ", bcount="
				+ bcount + ", sjbcount=" + sjbcount + ", hcount=" + hcount + ", scount=" + scount + ", hMoney=" + hMoney
				+ ", fajine=" + fajine + ", zMoney=" + zMoney + ", zjjine=" + zjjine + ", shenglv=" + shenglv
				+ ", orderNum=" + orderNum + ", checkNum=" + checkNum + ", cpname=" + cpname + ", qihao=" + qihao
				+ ", ddstate=" + ddstate + ", tqstate=" + tqstate + ", createtime=" + createtime + ", state=" + state
				+ ", userid=" + userid + ", huiyuanzh=" + huiyuanzh + ", payMoney=" + payMoney + ", createTime="
				+ createTime + ", rebate=" + rebate + ", rebateMoney=" + rebateMoney + ", shouru=" + shouru
				+ ", beishu=" + beishu + ", orderid=" + orderid + ", acount=" + acount + ", income=" + income
				+ ", counts=" + counts + ", orderState=" + orderState + ", id=" + id + ", cname=" + cname + ", cname1="
				+ cname1 + ", str1=" + str1 + ", str2=" + str2 + ", str3=" + str3 + ", str4=" + str4 + ", str5=" + str5
				+ ", str6=" + str6 + ", str7=" + str7 + ", str8=" + str8 + ", str9=" + str9 + ", str10=" + str10
				+ ", str11=" + str11 + ", str12=" + str12 + ", str13=" + str13 + ", str14=" + str14 + ", str15=" + str15
				+ ", str16=" + str16 + ", str17=" + str17 + ", str18=" + str18 + ", str19=" + str19 + ", str20=" + str20
				+ ", str21=" + str21 + ", str22=" + str22 + ", str23=" + str23 + ", str24=" + str24 + ", str25=" + str25
				+ ", str26=" + str26 + ", str27=" + str27 + ", str28=" + str28 + ", str29=" + str29 + ", str30=" + str30
				+ ", str31=" + str31 + ", str32=" + str32 + ", str33=" + str33 + ", str34=" + str34 + ", str35=" + str35
				+ ", str36=" + str36 + ", str37=" + str37 + ", str38=" + str38 + ", str39=" + str39 + ", str40=" + str40
				+ ", cplay1=" + cplay1 + ", cplay2=" + cplay2 + ", cplay3=" + cplay3 + ", cplay4=" + cplay4
				+ ", cplay5=" + cplay5 + ", cplay6=" + cplay6 + ", cplay7=" + cplay7 + ", cplay8=" + cplay8
				+ ", cplay9=" + cplay9 + ", cplay10=" + cplay10 + ", cplay11=" + cplay11 + ", cplay12=" + cplay12
				+ ", cplay13=" + cplay13 + ", cplay14=" + cplay14 + ", cplay15=" + cplay15 + ", cplay16=" + cplay16
				+ ", cplay17=" + cplay17 + ", cplay18=" + cplay18 + ", cplay19=" + cplay19 + ", cplay20=" + cplay20
				+ ", cplay21=" + cplay21 + ", cplay22=" + cplay22 + ", cplay23=" + cplay23 + ", cplay24=" + cplay24
				+ ", cplay25=" + cplay25 + ", cplay26=" + cplay26 + ", cplay27=" + cplay27 + ", cplay28=" + cplay28
				+ ", cplay29=" + cplay29 + ", cplay30=" + cplay30 + ", cplay31=" + cplay31 + ", cplay32=" + cplay32
				+ ", cplay33=" + cplay33 + ", cplay34=" + cplay34 + ", cplay35=" + cplay35 + ", cplay36=" + cplay36
				+ ", cplay37=" + cplay37 + ", cplay38=" + cplay38 + ", cplay39=" + cplay39 + ", cplay40=" + cplay40
				+ ", odds=" + odds + ", goalmoney=" + goalmoney + ", tcplay=" + tcplay + ", lotterCount=" + lotterCount
				+ "]";
	}
}