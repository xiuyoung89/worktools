package com.ja.sevice.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.ja.dao.AddPaymentMapper;
import com.ja.domain.ScavengingPayment;
import com.ja.sevice.AddPaymentService;

public class AddPaymentServicelmp implements AddPaymentService{
	@Autowired
	private AddPaymentMapper addPaymentMapper;
	@Override
	public int AddPayment(ScavengingPayment Payment) {
		return addPaymentMapper.AddPayment(Payment);
	}
	@Override
	public List<ScavengingPayment> QueryPaymentInformation() {
		return addPaymentMapper.QueryPaymentInformation();
	}
	@Override
	public List<ScavengingPayment> QueryPaymentInformation1() {
		return addPaymentMapper.QueryPaymentInformation1();
	}
	@Override
	public int state(Integer id,Integer state) {
		return addPaymentMapper.state(id,state);
	}
	@Override
	public int modifyPaymentInterface(ScavengingPayment Payment) {
		return addPaymentMapper.modifyPaymentInterface(Payment);
	}
	@Override
	public int deletingPayment(ScavengingPayment Payment) {
		return addPaymentMapper.deletingPayment(Payment);
	}

}
