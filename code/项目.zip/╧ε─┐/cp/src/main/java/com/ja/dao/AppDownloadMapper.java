package com.ja.dao;

import org.apache.ibatis.annotations.Param;

import com.ja.domain.AppDownload;

public interface AppDownloadMapper {
	
	/**
	 * @param load app的地址
	 * @return 添加app
	 */
	int insertApp(@Param("load") AppDownload load);
	
	/**   
	 * @param load app的地址
	 * @return 添加app
	 */
	int updateApp(@Param("load") AppDownload load);
	
	/**
	 * app下载地址
	 * @return
	 */
	AppDownload findAppImgPath();

	/**
	 * 根据id查询app的信息 
	 * @param id app ID
	 * @return
	 */
	AppDownload findByIdAppDownload(Integer id);
}



