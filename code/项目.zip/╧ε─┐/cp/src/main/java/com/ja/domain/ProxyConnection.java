package com.ja.domain;

import java.io.Serializable;
import java.util.Date;

public class ProxyConnection implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 4523353227448903134L;

	private Integer id;//id
	
	private String domain;//推广链接
	
	private String default_agency;//代理用户名
	
	private Integer domain_status;//状态
	
	private String default_index;//
	
	private Date created_time;//创建时间
	
	private String operation;//操作
	
	private String created_user;//创建人

    
    public static long getSerialversionuid() {
		return serialVersionUID;
	}
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getDomain() {
		return domain;
	}

	public void setDomain(String domain) {
		this.domain = domain;
	}

	public String getDefault_agency() {
		return default_agency;
	}

	public void setDefault_agency(String default_agency) {
		this.default_agency = default_agency;
	}

	public Integer getDomain_status() {
		return domain_status;
	}

	@Override
	public String toString() {
		return "ProxyConnection [id=" + id + ", domain=" + domain + ", default_agency=" + default_agency
				+ ", domain_status=" + domain_status + ", default_index=" + default_index + ", created_time="
				+ created_time + ", operation=" + operation + ", created_user=" + created_user + "]";
	}

	public void setDomain_status(Integer domain_status) {
		this.domain_status = domain_status;
	}

	public String getDefault_index() {
		return default_index;
	}

	public void setDefault_index(String default_index) {
		this.default_index = default_index;
	}

	public Date getCreated_time() {
		return created_time;
	}

	public void setCreated_time(Date created_time) {
		this.created_time = created_time;
	}

	public String getOperation() {
		return operation;
	}

	public void setOperation(String operation) {
		this.operation = operation;
	}

	public String getCreated_user() {
		return created_user;
	}

	public void setCreated_user(String created_user) {
		this.created_user = created_user;
	}
	
	
}
