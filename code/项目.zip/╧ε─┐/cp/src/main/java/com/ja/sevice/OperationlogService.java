package com.ja.sevice;

import java.util.List;

import com.ja.domain.AdminUser;
import com.ja.domain.Operationlog;

public interface OperationlogService {
	
	/**
	 * 方法名：addOperationlog 
	 * 描述：     添加日志记录                  TODO
	 * 参数：    @param admin 操作人
	 * 参数：    @param remarks 操作信息
	 * 参数：    @param type 操作类型
	 * 参数：    @return 
	 * @return: Integer
	 */
	Integer addOperationlog(AdminUser admin,String remarks,String type);

	/**
	 * 查询所有的操作日志记录
	 * @return
	 */
	List<Operationlog> getAllOperationlog();
	
	/**
	 * 根据条件查询操作记录
	 * @param log 查询的信息
	 * @return
	 */
	List<Operationlog> findOperationlog(Operationlog log);
	
	/**
	 * 删除日志操作记录
	 * @param id 删除的日志id
	 * @return
	 */
	Integer delOperationlog(Integer id);


}
