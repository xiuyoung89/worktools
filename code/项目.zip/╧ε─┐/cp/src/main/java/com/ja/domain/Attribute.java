package com.ja.domain;

import java.io.Serializable;

public class Attribute implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 411626358310031560L;

	private Integer id;// 港彩属性

	private String attribute;// 属性

	private String content;// 包含的球

	private int type;// 属性类型

	private String updateTime;// 修改的时间

	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getAttribute() {
		return attribute;
	}

	public void setAttribute(String attribute) {
		this.attribute = attribute;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public int getType() {
		return type;
	}

	public void setType(int type) {
		this.type = type;
	}

	public String getUpdateTime() {
		return updateTime;
	}

	public void setUpdateTime(String updateTime) {
		this.updateTime = updateTime;
	}

	@Override
	public String toString() {
		return "Attribute [id=" + id + ", attribute=" + attribute + ", content=" + content + ", type=" + type
				+ ", updateTime=" + updateTime + "]";
	}

}