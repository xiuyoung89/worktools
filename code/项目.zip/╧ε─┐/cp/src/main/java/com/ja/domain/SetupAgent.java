package com.ja.domain;

import java.io.Serializable;

public class SetupAgent implements Serializable{
	
    /**
	 * 
	 */
	private static final long serialVersionUID = 5657226308913740611L;

	private Integer id; //代理返点设置

    private Integer agent_grade; //代理等级

    private Double rebate_ratio; //代理返点率
    
    private Integer rebate_type; //返点类型

    private String created_time; //创建-操作时间

    private Integer state; //0禁用 1启用

    private String operator_name; //操作人名称

    
    public static long getSerialversionuid() {
		return serialVersionUID;
	}
    
    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

	public Integer getAgent_grade() {
		return agent_grade;
	}

	public void setAgent_grade(Integer agent_grade) {
		this.agent_grade = agent_grade;
	}

	public Double getRebate_ratio() {
		return rebate_ratio;
	}

	public void setRebate_ratio(Double rebate_ratio) {
		this.rebate_ratio = rebate_ratio;
	}

	public Integer getRebate_type() {
		return rebate_type;
	}

	public void setRebate_type(Integer rebate_type) {
		this.rebate_type = rebate_type;
	}

	public String getCreated_time() {
		return created_time;
	}

	public void setCreated_time(String created_time) {
		this.created_time = created_time;
	}

	public Integer getState() {
		return state;
	}

	public void setState(Integer state) {
		this.state = state;
	}

	public String getOperator_name() {
		return operator_name;
	}

	public void setOperator_name(String operator_name) {
		this.operator_name = operator_name;
	}

	public SetupAgent() {
		super();
	}

	@Override
	public String toString() {
		return "SetupAgent [id=" + id + ", agent_grade=" + agent_grade + ", rebate_ratio=" + rebate_ratio
				+ ", rebate_type=" + rebate_type + ", created_time=" + created_time + ", state=" + state
				+ ", operator_name=" + operator_name + "]";
	}

}