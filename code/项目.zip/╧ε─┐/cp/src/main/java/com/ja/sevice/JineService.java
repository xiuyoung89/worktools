package com.ja.sevice;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.web.servlet.ModelAndView;

import com.ja.domain.AdminUser;
import com.ja.domain.Jine;
import com.ja.domain.PagingData;
import com.ja.domain.PayMoney;
import com.ja.domain.User;
import com.ja.util.JsonResult;

public interface JineService {

	/**
	 *   方法名：insertRechargeOrder   
	 *   描述：    添加充值订单信息                  TODO 在线支付一接口  
	 *   参数：    @param payType 充值类型
	 *   参数：    @param money 充值金额
	 *   参数：    @param user 用户信息
	 *   参数：    @param request request对象
	 *   参数：    @return 
	 * @return: ModelAndView
	 */
	ModelAndView insertRechargeOrder(String payType, Double money, User user, HttpServletRequest request);
	
	/**
	 *   方法名：insertRechargeOrder   
	 *   描述：    添加充值订单信息                  TODO 在线支付二接口  
	 *   参数：    @param payType 充值类型
	 *   参数：    @param money 充值金额
	 *   参数：    @param user 用户信息
	 *   参数：    @param request request对象
	 *   参数：    @return 
	 * @return: JsonResult
	 */
	String insertRechargeOrderTwo(String payType, Double money, User users, HttpServletRequest request);
	
	/**
	 *   方法名：payNotifys   
	 *   描述：     在线充值 接口一 异步回调                  TODO   
	 *   参数：    @param pay
	 *   参数：    @param users
	 *   参数：    @return 
	 * @return: JsonResult
	 */
	JsonResult payNotifys(PayMoney pay, User users);
	
	/**
	 *   方法名：payNotifysTwo   
	 *   描述：     在线充值 接口二 异步回调                  TODO   
	 *   参数：    @param pay
	 *   参数：    @param users
	 *   参数：    @return 
	 * @return: JsonResult
	 */
	JsonResult payNotifysTwo(PayMoney pay);
	
	/**
	 *   方法名：ManualRecharge   
	 *   描述：    快速充值接口-- 银行卡转账 二维码支付                   TODO   
	 *   参数：    @param jine
	 *   参数：    @param session
	 *   参数：    @param code
	 *   参数：    @return 
	 * @return: JsonResult
	 */
	JsonResult quickRecharge(Jine jine, HttpSession session, String code);
	
	/**
	 *   方法名：findUserCodeCount   
	 *   描述：    查询用户的打码情况                   TODO   
	 *   参数：    @param user
	 *   参数：    @param money
	 *   参数：    @return 
	 * @return: JsonResult
	 */
	JsonResult findUserCodeCount(User user, Double money);
	
	/**
	 *   方法名：quickDrawing   
	 *   描述：    快速提款申请                   TODO   
	 *   参数：    @param jine 提款信息
	 *   参数：    @param zhifupass 提款密码
	 *   参数：    @return 
	 * @return: JsonResult
	 */
	JsonResult quickDrawing(Jine jine, User user,String zhifupass);
	
	/**
	 *   方法名：rechargeAudit   
	 *   描述：    用户充值审核                   TODO   
	 *   参数：    @param admin 管理员信息
	 *   参数：    @param jine 用户充值金额
	 *   参数：    @return 
	 * @return: JsonResult
	 */
	JsonResult rechargeAudit(AdminUser admin, Jine jine);
	
	/**
	 *   方法名：drawingAudit   
	 *   描述：    提款审核                   TODO   
	 *   参数：    @param jine 提款信息
	 *   参数：    @param states 提款状态
	 *   参数：    @param admin 管理员信息
	 *   参数：    @return 
	 * @return: JsonResult
	 */
	JsonResult drawingAudit(Jine jine, String states, AdminUser admin);
	
	/**
	 *   方法名：quickPayment   
	 *   描述：     人工快速加款接口                  TODO   
	 *   参数：    @param jine 金额信息
	 *   参数：    @param admin 管理员信息
	 *   参数：    @return 
	 * @return: JsonResult
	 */
	JsonResult quickPayment(Jine jine, AdminUser admin);
	
	
	
	

	
	
	/**
	 * 
	   *   方法名：addJilu   
	   *   描述：      添加充值以及提款记录                 TODO   
	   *   参数：    @param jine 充值提款信息
	   *   参数：    @return 
	 * @return: int
	 */
	int addJilu(Jine jine);

	/** 查询所有充值记录 
	 * @param model 
	 * @param i 
	 * @param integer */
	List<Jine> getAllJl( Integer integer, int i,int model);

	/** 模糊查询充值记录 
	 * @param i 
	 * @param integer2 
	 * @param integer */
	List<Jine> getTypeJl(Integer integer, Integer integer2, Jine jine, String date1, String date2, int i);

	/** 查询所有的提款记录 
	 * @param i 
	 * @param integer2 
	 * @param integer */
	List<Jine> getTikuanJl(Integer integer, Integer integer2, int i);

	/** 模糊查询提款记录 
	 * @param i 
	 * @param integer2 
	 * @param integer */
	List<Jine> getTikuanTypeJl(Integer integer, Integer integer2, Jine jine, String date1, String date2, int i); 

	/** 查询今日充值-提款 */
	Jine cxToday(String date);

	/** 最后充值金额-时间 */
	Jine zhCzJineJl(Integer id);

	/** 最后提款金额-时间 */
	Jine zhTkJineJl(Integer id);

	/** 根据用户id查询当前用户的充值信息 */
	List<Jine> getOneCzJl(Jine z, String date1, String date2, Integer id);

	/** 根据用户id查询当前用户的提款信息 */
	List<Jine> getOneTkJl(Jine z, String date1, String date2, Integer id);

	/**查询用户今日充值 
	 * @param time */
	double getCzTodyJl(Integer id, String time);

	/**查询用户本月充值*/
	double getCzMonthJl(Integer id);
	
	/**审核提款*/
	int upTikuanSh(Jine jine);

	/** 查询用户的充值记录  */
	List<Jine> onechongzhi(Integer id);

	/** 查询用户提款记录  */
	List<Jine> onetikuan(Integer id);

	/** 充值提款记录*/
	List<Jine> getAllJlLimit();

	/**今日提款次数*/
	int getTikuanCount(Integer id);

	/**今日提款成功次数*/
	int getTikuanCount1(Integer id);

	/**锁定*/
	int updateTikuansd(Jine j);

	double getTikuanSum(Integer id);

	double getTikuanSum1(Integer id);

	int getChongzhiCount(Integer id);

	double getChongzhiSum(Integer id);

	/**充值-提款-语音提示*/
	List<Jine> getByStateAllYuyin();

	/**上个月充值金额*/
	double getCzLastMonthJl(Integer id);
	
	/**查询没有显示过的信息*/
	Jine findInfoData();

	/**
	 * 查询未处理成功的提款订单
	 * @return
	 */
	List<Jine> findJineByState(Integer id);

	/**
	 * 查询今日成功提款次数
	 * @return
	 */
	int findJineByStateSuccess(Integer userid);

	/**
	 * 查询单条记录的信息
	 * @param id 单条id
	 * @return
	 */
	Jine findByIdJineInfo(Integer id);

	/**
	 * 查询今天的充值提款记录
	 * @param currTime 当前时间
	 * @return
	 */
	List<Jine> findByTimeDetails(String currTime);

	/**
	 * 查询用户今日的提款次数
	 * @param user_id 用户id
	 * @param date 查询实际
	 * @return
	 */
	List<Jine> findByDateUserIdInfo(Integer user_id, String date);

	/**
	 *   方法名：getAllJlCounts   
	 *   描述：                       TODO   
	 *   参数：    @return 
	 * @return: Integer
	 */
	Integer getAllJlCounts();

	/**
	 * 
	 *   方法名：getTypeJlCounts   
	 *   描述：                       TODO   
	 *   参数：    @param jine
	 *   参数：    @param date1
	 *   参数：    @param date2
	 *   参数：    @return 
	 * @return: Integer
	 */
	Integer getTypeJlCounts(Jine jine, String date1, String date2);

	/**
	 * 
	 *   方法名：getTikuanJlCounts   
	 *   描述：                       TODO   
	 *   参数：    @return 
	 * @return: Integer
	 */
	Integer getTikuanJlCounts();

	/**
	 * 
	 *   方法名：getTikuanTypeJlCounts   
	 *   描述：                       TODO   
	 *   参数：    @param jine
	 *   参数：    @param date1
	 *   参数：    @param date2
	 *   参数：    @return 
	 * @return: Integer
	 */
	Integer getTikuanTypeJlCounts(Jine jine, String date1, String date2);
	
	/**
	 * 
	   *   方法名：findMoneyRecordCounts   
	   *   描述：     查询充值提现记录数                  TODO   
	   *   参数：    @param jine  
	   *   参数：    @return 
	 * @return: Integer
	 */
	Integer findMoneyRecordCounts(Jine jine); 
	
	/**
	 * 根据条件查询个人的充值提现记录
	   *   方法名：findMoneyRecord   
	   *   描述：                       TODO   
	   *   参数：    @param jine
	   *   参数：    @param paging
	   *   参数：    @return 
	 * @return: List<Jine>
	 */
	List<Jine> findMoneyRecord(PagingData paging, Jine jine);

	/**
	 * 		
	   *   方法名：findUserTikuanInfo   
	   *   描述：    查询今日提款信息                   TODO   
	   *   参数：    @param id
	   *   参数：    @return 
	 * @return: Jine
	 */
	Integer findUserTikuanInfoCounts(Integer id);
	Double findUserTikuanInfoSumMoney(Integer id);

	/**
	 * 统计数据库里面还有多少条充值数据没有处理的
	 * @return  返回数据库里面没有处理的充值数据的总条数
	 */
	Integer getCount();
	
	/**
	 * 统计数据库里面还有多少条提款数据没有处理的
	 * @return  返回数据库里面没有处理的提款数据的总条数
	 */
	Integer getCountTk();

	/**
	  * 方法名：findPaymentResult 
	  * 描述：    在线支付异步查询接口                  
	  * 参数：    @param order_no 平台订单号
	  * 参数：    @return 
	 * @return: JsonResult
	 */
	JsonResult findPaymentResult(String order_no);
	
	/**
	 * 定时请求查询用户充值情况是否已经到账
	 */
	void timingTask(boolean takeInverse);
}
