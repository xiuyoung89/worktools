package com.ja.dao;

import java.util.List;

import com.ja.domain.KeFuChat;


public interface KeFuMapper {
	
	/**
	 * 保存客服咨询聊天记录
	 * @param chat 聊天记录信息
	 * @return
	 */
	int saveChatRecord(KeFuChat chat);
	
	/**
	 * 查询客服咨询聊天记录
	 * @param kefu_id 客服id
	 * @param user_id 用户id
	 * @return
	 */
	List<KeFuChat> findChatRecord(KeFuChat chat); 
	
	/**
	 * 根据id查询客服最近联系人
	 * @param id
	 * @param type 
	 * @return
	 */   
	List<KeFuChat> findChatLinkman(KeFuChat chat);
	
	/**
	  *  清除最近联系人
	 * @param chat
	 * @return
	 */
	int updateChatStatu(KeFuChat chat);
	

}