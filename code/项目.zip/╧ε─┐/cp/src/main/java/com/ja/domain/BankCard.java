package com.ja.domain;

import java.io.Serializable;

public class BankCard implements Serializable{
    /**
	 * 
	 */
	private static final long serialVersionUID = 1700279274721918789L;

	private Integer id;//银行卡信息

    private String name;//会员帐号
    
    private String xingming;//银行卡姓名

    private String bankNum;//银行卡帐号

    private String kaihuhang;//开户行
    
    private String zhihang;//开户支行
    
    private String kaihudizhi;//开户行地址
    
    private String zhifupass;//支付密码
    
    private Double yue;//余额

    private Integer userid;//用户id

	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getBankNum() {
		return bankNum;
	}

	public void setBankNum(String bankNum) {
		this.bankNum = bankNum;
	}

	public String getKaihuhang() {
		return kaihuhang;
	}

	public void setKaihuhang(String kaihuhang) {
		this.kaihuhang = kaihuhang;
	}

	public String getZhihang() {
		return zhihang;
	}

	public void setZhihang(String zhihang) {
		this.zhihang = zhihang;
	}

	public Integer getUserid() {
		return userid;
	}

	public Double getYue() {
		return yue;
	}

	public void setYue(Double yue) {
		this.yue = yue;
	}

	public String getKaihudizhi() {
		return kaihudizhi;
	}

	public void setKaihudizhi(String kaihudizhi) {
		this.kaihudizhi = kaihudizhi;
	}

	public void setUserid(Integer userid) {
		this.userid = userid;
	}

	public String getXingming() {
		return xingming;
	}

	public void setXingming(String xingming) {
		this.xingming = xingming;
	}

	public String getZhifupass() {
		return zhifupass;
	}

	public void setZhifupass(String zhifupass) {
		this.zhifupass = zhifupass;
	}

	@Override
	public String toString() {
		return "BankCard [id=" + id + ", name=" + name + ", xingming=" + xingming + ", bankNum=" + bankNum
				+ ", kaihuhang=" + kaihuhang + ", zhihang=" + zhihang + ", kaihudizhi=" + kaihudizhi + ", zhifupass="
				+ zhifupass + ", yue=" + yue + ", userid=" + userid + "]";
	}

	public BankCard() {
		super();
	}

}