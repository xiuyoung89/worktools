package com.ja.domain;

import java.io.Serializable;

public class BaccaratBulletin implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 356895612609297447L;

	//private Integer id;

	private Integer percentage;//百分百控制

	private String minimumSum;//进入房间最小金额

	private String maximumAmount;//进入房间最大金额

	private Integer tableNumber;//桌号

	private Double percent;//设置百家乐8遇到9反比多少
	
	private String control;//控制次数  到哪里控制
	
	private Integer lotteryTimes;//开奖次数

	public Integer getLotteryTimes() {
		return lotteryTimes;
	}

	public void setLotteryTimes(Integer lotteryTimes) {
		this.lotteryTimes = lotteryTimes;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	/*public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}*/

	public Integer getPercentage() {
		return percentage;
	}

	public String getControl() {
		return control;
	}

	public void setControl(String control) {
		this.control = control;
	}

	public void setPercentage(Integer percentage) {
		this.percentage = percentage;
	}

	public String getMinimumSum() {
		return minimumSum;
	}

	public void setMinimumSum(String minimumSum) {
		this.minimumSum = minimumSum;
	}

	public String getMaximumAmount() {
		return maximumAmount;
	}

	public void setMaximumAmount(String maximumAmount) {
		this.maximumAmount = maximumAmount;
	}

	public Integer getTableNumber() {
		return tableNumber;
	}

	public void setTableNumber(Integer tableNumber) {
		this.tableNumber = tableNumber;
	}

	public Double getPercent() {
		return percent;
	}

	public void setPercent(Double percent) {
		this.percent = percent;
	}

	@Override
	public String toString() {
		return "BaccaratBulletin [percentage=" + percentage + ", minimumSum=" + minimumSum + ", maximumAmount="
				+ maximumAmount + ", tableNumber=" + tableNumber + ", percent=" + percent + ", control=" + control
				+ ", lotteryTimes=" + lotteryTimes + "]";
	}


}
