package com.ja.domain;

import java.io.Serializable;

public class Fanshui implements Serializable{
    /**
	 * 
	 */
	private static final long serialVersionUID = 8583921922847029806L;

	private Integer id;//反水所需
    
    private String name;

    private String type;//反水类型
    
    private Double jine;//反水充值所需

    private Double damal;//反水打码量所需
    
    private Double fdianlv;//反水点率
    
    private Integer state;//开关

    public static long getSerialversionuid() {
		return serialVersionUID;
	}
    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}
	
	public Double getJine() {
		return jine;
	}

	public void setJine(Double jine) {
		this.jine = jine;
	}

	public Double getDamal() {
		return damal;
	}

	public void setDamal(Double damal) {
		this.damal = damal;
	}

	public Double getFdianlv() {
		return fdianlv;
	}

	public void setFdianlv(Double fdianlv) {
		this.fdianlv = fdianlv;
	}

	public Integer getState() {
		return state;
	}

	public void setState(Integer state) {
		this.state = state;
	}

	public Fanshui() {
		super();
	}

	@Override
	public String toString() {
		return "Fanshui [id=" + id + ", name=" + name + ", type=" + type + ", jine=" + jine + ", damal=" + damal
				+ ", fdianlv=" + fdianlv + ", state=" + state + "]";
	}

}