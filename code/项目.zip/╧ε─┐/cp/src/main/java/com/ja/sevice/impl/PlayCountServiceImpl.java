package com.ja.sevice.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ja.dao.PlayCountMapper;
import com.ja.domain.PlayCount;
import com.ja.sevice.PlayCountService;

/**
 * @AUTH LBQ
 * @DATE 2017年11月10日 上午9:29:09
 * @DESC 
 */
@Service
public class PlayCountServiceImpl implements PlayCountService {
	
	@Autowired
	private PlayCountMapper playCountMapper;

	/**查询当前这一期有没有下注*/
	@Override
	public PlayCount getCplay(PlayCount p) {
		return playCountMapper.getCplay(p);
	}
	
	/**添加下注人数以及金额*/
	@Override
	public int addPlayCount(PlayCount cplay) {
		return playCountMapper.addPlayCount(cplay);
	}

	/**修改这一期玩法的下注次数*/
	@Override
	public int updatePlayCount(PlayCount p) {
		return playCountMapper.updatePlayCount(p);
	}
	
	/**统计这期玩法下注多少*/
	@Override
	public int getCplayCount(String period, String cname) {
		return playCountMapper.getCplayCount(period, cname);
	}


	
	
	
	
	
	
	
	
	
}
