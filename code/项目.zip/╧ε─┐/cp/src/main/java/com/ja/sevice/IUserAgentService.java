package com.ja.sevice;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.ja.domain.Agent;
import com.ja.domain.AgentRebate;
import com.ja.domain.Jine;
import com.ja.domain.Liushui;
import com.ja.domain.Order;
import com.ja.domain.ProxyConnection;
import com.ja.domain.ProxyReport;
import com.ja.domain.User;
/**
 * 处理代理的业务接口
 * @author CY
 * @date 2018.3.24
 */
public interface IUserAgentService {

	/**
	 * 根据条件查询会员
	 * @param searchType 搜索的类型，1为直属下属，2为所有下级
	 * @param online 在想状态，null为不清楚，1为在线，2为离线
	 * @param accountType 账户类型null为全部，1为会员，2为代理
	 * @param account 根据会员名查询
	 * @return	User的List集合
	 */
	List<User> showUser(Integer id, Integer online, Integer accountType, String account);
	

	/**
	 * 根据id找到用户
	 * @param id
	 * @return
	 */
	User showSelf(Integer id);
	
	/**
	 * 修改返点数
	 * @param rebate
	 * @param id
	 * @return 影响数据库的行数
	 */
	Integer updateRebate(@Param("id") Integer id,@Param("rebate") Double rebate);
	
	/**
	 * 通过条件找到agent
	 * @param agent
	 * @return
	 */
	Agent findAgent(String agent);
	
	/**
	 * 像用户列表中插入代理id
	 * @param id
	 * @param agentId
	 * @return
	 */
	Integer addUserAgentID(Integer id,Integer agentId);
	
	/**
	 * 通过推广码找到用户
	 * @param icode
	 * @return User用户
	 */
	User findUserByIcode(String icode);
	
	/**
	 * 设置新注册用户的fid
	 * @param id
	 * @param fid
	 * @return
	 */
	Integer updateUserFid(Integer id,Integer fid);
	
	/**
	 * 根据条件找到流水对象集合
	 * @param userid 用户id
	 * @param date1	起始时间
	 * @param date2	结束时间
	 * @param account 账号名
	 * @param type  类型
	 * @param orderId 订单号
	 * @return
	 */
	List<Liushui> findLiushui(String date1,String date2,
			String account,String type,String orderId,Agent a);
	
	/**
	 * 根据条件查询报表
	 * @param userid 用户id
	 * @param date1 起始时间
	 * @param date2 结束时间
	 * @return 运营报表对象
	 */
	List<ProxyReport> findYunyingbbByUserId(Agent a,@Param("date1") String date1,@Param("date2") String date2,String name);

	/**
	 * 根据条件查询金额记录
	 * @param agentId
	 * @param status
	 * @param type
	 * @param account
	 * @param date1
	 * @param date2
	 * @return 金额对象
	 */
	List<Jine> findJineByUserId( Integer agentId, String status,String type, String account,String date1,String date2);

	// 用户登陆接口
	public Agent login(String name, String pass);
	
	/**
	 * 修改代理用户信息
	 * @param agent
	 * @return
	 */
	Integer editeAgent(Integer id,String oldPassword,String newPassword);
	
	/**
	 * 根据代理的id找到相对应的代理
	 * @param id
	 * @return
	 */
	Agent findAgentById(Integer id);
	
	/**
	 * 添加代理返点率对象
	 * @param agentRebate
	 * @return
	 */
	Integer insertAgentRebate(AgentRebate agentRebate);
	
	/**
	 * 通过用户id找到相对应的代理
	 * @param userid
	 * @return
	 */
	Agent findAgentByUserId(Integer userid);
	
	/**
	 * 根据代理id和时间找到代理返点率对象
	 * @return
	 */
	List<AgentRebate> findAgentRebate(Integer agentId,String date1,String date2);
	
	/**
	 * 查询团队余额
	 * @param agentId
	 * @param date1
	 * @param date2
	 * @param account
	 * @return
	 */
	Double teamBalance(@Param("agentId") Integer agentId,@Param("date1") String date1,@Param("date2") String date2,@Param("account") String account);
	/**
	 * 获取用户的推广链接
	 * @param a
	 * @return
	 */
	List<ProxyConnection> queryAgentConnection(Agent a);
	/**
	 * 查询代理用户下面会员的下注记录
	 * @param a 代理信息
	 * @param o 用户信息
	 * @param time 开始时间
	 * @param time1 结束时间
	 * @param startIndex  起始页
	 * @param lineCount 结束页
	 * @return
	 */
	List<Order> noteRecord(Agent a,Order o,String time,String time1,Integer startIndex,Integer lineCount,int model);
	/**
	 * 查询代理用户下面会员的下注记录
	 * @return
	 */
	Order idQuery(Integer id);


	/**
	 * 方法名：findByNameUser 
	 * 描述：     根据用户名查询用户的平台统计                 
	 * 参数：    @param userName 用户名
	 * 参数：    @return 
	 * @return: User
	 */
	User findByNameUser(String userName);

	/**
	 * 方法名：findByGeneralAgentIdUser 
	 * 描述：    根据总代理id查询总代理的下级                  
	 * 参数：    @param agent_id 总代理id
	 * 参数：    @return 
	 * @return: List<User>
	 */
	List<User> findByGeneralAgentIdUser(Integer agent_id);

}
