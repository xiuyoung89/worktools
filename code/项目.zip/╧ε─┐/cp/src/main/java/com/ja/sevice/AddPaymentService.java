package com.ja.sevice;

import java.util.List;

import com.ja.domain.ScavengingPayment;

/**
 * 扫码支付接口
 * @author Administrator
 *
 */
public interface AddPaymentService {
	/**
	 * 添加支付接口
	 * @param Payment 支付对象
	 * @return
	 */
	int AddPayment(ScavengingPayment Payment);
	/**
	 * 查询扫码支付信息
	 * @return
	 */
	List<ScavengingPayment> QueryPaymentInformation();
	
	/**
	 * 查询扫码支付信息
	 * @return
	 */
	List<ScavengingPayment> QueryPaymentInformation1();
	/**
	 * 扫码支付禁用启用
	 * @param id
	 * @return
	 */
	int state(Integer id,Integer state);
	/**
	 * 修改相关支付信息
	 * @param Payment
	 * @return
	 */
	int modifyPaymentInterface(ScavengingPayment Payment);
	/**
	 * 删除扫码支付接口
	 * @param Payment
	 * @return
	 */
	int deletingPayment(ScavengingPayment Payment);
}
