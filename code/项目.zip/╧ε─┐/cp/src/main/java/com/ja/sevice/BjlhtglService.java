package com.ja.sevice;

import java.util.List;

import org.springframework.stereotype.Service;

import com.ja.domain.AdminUser;
import com.ja.domain.BaccaratBulletin;
import com.ja.domain.Bjl;
import com.ja.domain.Bjldata;
import com.ja.domain.Lotter;
import com.ja.domain.PagingData;

@Service
public interface BjlhtglService {
	/**
	 * 修改百家乐百分比控制
	 * @param tableNumber  桌号
	 * @param percentage  百分比
	 * @return  修改成功返回 1  不成功则是别的值 有可能是0
	 */
	public int updateBjlControl(int tableNumber,int percentage);
	/**
	 * 修改百家乐房间金额 就是进入房间时显示的金额
	 * @param tableNumber 桌号
	 * @param maximumAmount 最大金额
	 * @param minimumSum 最小金额
	 * @return  修改成功则返回1 
	 */
	public int updateBjlRoomMoney(int tableNumber,String maximumAmount,String minimumSum);
	/**
	 * 	 修改百家乐开奖赔率
	 * @param rebate1   rebate1 庄家的赔率
	 * @param rebate2   rebate2 闲家的赔率
	 * @param rebate3  rebate3闲对的赔率
	 * @param rebate4  rebate4庄对的赔率
	 * @param rebate5  rebate5和局的赔率
	 * @param rebate6  rebate6大的赔率
	 * @param rebate7  rebate7小的赔率
	 * @param rebate8  rebate8完美对子的赔率
	 * @param rebate9  rebate9任意对子的赔率
	 * @param name  彩种名
	 * @return 修改成功则返回0 
	 */
	public int upDateOdds(String rebate1,String rebate2,String rebate3,String rebate4,String rebate5,String rebate6,String rebate7,String rebate8,String rebate9,String name);
	/**
	 * 查询百家乐用户下注记录
	 * @param paging  页数
	 * @param name  会员账号 根据会员账号查询
	 * @param date1 根据开始日期 
	 * @param date2 根据结束日期   查询
	 * @param period 根据期号查询
	 * @param state  开奖状态  0-未开奖  1-已开奖
	 * @param status 根据中将状态查询 主要前台查询
	 * @param id  根据id查询
	 * @return 返回list集合里面包含Bjl对象  查询到则有数据 没有查询到则返回一个空集合
	 */
	public List<Bjl> xiazjl(PagingData paging, String name,String date1,String date2,String period,Integer status,Integer state,Integer id);
	 /**
	  * 根据桌号查询当前桌的基本设置数据
	  * @param tableNumber  桌号
	  * @return 查询到则返回 BaccaratBulletin对象 如果没有查询到则返回null
	  */
	BaccaratBulletin basicSettingsOfBaccarat(Integer tableNumber);
	
	Lotter pailu();
	
	int deletexzjl(int id);
	
	int fandian(Double percent1); 
	
	/**
	 * 查询百家乐用户下注记录   根据传入的参数条件进行查询
	 * @param user  用户名  后台用
	 * @param time1 开始时间 后台用
	 * @param time2 结束时间 后台用
	 * @param period 根据期号查询 后台用
	 * @param state 根据开奖未开奖查询 后台用
	 * @param status 根据开奖状态查询  前台用
	 * @return  查询到则返回数据库里面数据的条数 没有查询到则返回0
	 */
	Integer xiazjlCounts(String user, String time1, String time2, String period, Integer status, Integer state);
	
	/**
	 * 统计百家乐开奖数据
	 * @param date1 开始时间
	 * @param date2 结束时间 
	 * @param period 期号
	 * @param tableNumber 桌号
	 * @return 返回当前数据的总数
	 */
	Integer lotteryRecord(String date1,String date2,String period,Integer tableNumber);
	
	/**
	 * 查询百家乐开奖数据
	 * @param paging  分页对象
	 * @param date1 开始时间
	 * @param date2 结束时间
	 * @param period  期号
	 * @param tableNumber 桌号
	 * @return
	 */
	List<Bjldata> lotteryRecords(PagingData paging, String date1,String date2,String period,Integer tableNumber);

	/**
	 * 百家乐开奖数据预设接口 
	 * @param Bjldata  预设数据
	 * @return  预设成功则返回1
	 */
	int baccaratPresupposition(Bjldata data);
	/**
	 * 百家乐退款接口
	 * @param tableNumber 退款的桌号
	 * @param issueNumber 退款的期号
	 * @return
	 */
	int baccaratRefund(Integer tableNumber,String issueNumber,AdminUser admin);
	
}
