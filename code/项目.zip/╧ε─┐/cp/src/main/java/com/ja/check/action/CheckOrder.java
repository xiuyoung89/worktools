package com.ja.check.action;

import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.web.context.ContextLoader;

import com.ja.check.datas.Publicmethods;
import com.ja.domain.Data;
import com.ja.domain.GcRebate;
import com.ja.domain.Order;
import com.ja.domain.User;
import com.ja.sevice.IDataService;
import com.ja.sevice.IOrderService;
import com.ja.sevice.ISystemConfigService;
import com.ja.sevice.IUserService;

/**
 * 项目名称：cp
 * 类名称：CheckOrder.java   
 * 类描述：   彩票开奖类
 * 创建人：   Administrator
 * 创建时间：2019年3月4日 下午5:24:42   
 * @version v1.0.0
 */
public class CheckOrder {
	
	private Logger logger = LogManager.getLogger(LogManager.ROOT_LOGGER_NAME);  

	private IDataService dataService = (IDataService) ContextLoader.getCurrentWebApplicationContext().getBean("dataService");
	
	private IUserService userService = (IUserService) ContextLoader.getCurrentWebApplicationContext().getBean("userService");
	
	private IOrderService orderService = (IOrderService) ContextLoader.getCurrentWebApplicationContext().getBean("orderService");
	
	private ISystemConfigService systemConfigService = (ISystemConfigService) ContextLoader.getCurrentWebApplicationContext().getBean("systemConfigService");
	
	/*private ClassPathXmlApplicationContext ctx = new ClassPathXmlApplicationContext("/spring/applicationContext-dao.xml","/spring/applicationContext-service.xml");
	IDataService dataService = (IDataService) ctx.getBean("dataService");
	IUserService userService = (IUserService) ctx.getBean("userService");
	IOrderService orderService = (IOrderService) ctx.getBean("orderService");
	ISystemConfigService systemConfigService = (ISystemConfigService) ctx.getBean("systemConfigService");*/

	/**
	 * 方法名：checkLotters 
	 * 描述：    彩种开奖接口                   
	 * 参数：    @param data 开奖信息
	 * 参数：    @return 
	 * @return: int
	 */
	public synchronized int checkLotters(Data data) {
		synchronized (this) {
			if (data.getLotternumber() == null || "".equals(data.getLotternumber())||"官方开奖异常".equals(data.getLotternumber())) {
				data.setState("数据异常");
				checkTime(data);
				Publicmethods.stopTheTask(data);// 异常数据相关信息 请不要删除
			} else {
				if(systemConfigService.findAllConfig().agent_flag==1) {
					checkLotter1(data);
				}else {
					checkLotter2(data);
				}
				lotterResult(data);
				data.setState("已开奖");
				checkTime(data);
			}
		}
		return 1; 
	}
	
	/**
	 * 方法名：checkTime 
	 * 描述：    订单开奖信息                  
	 * 参数：    @param data 开奖信息
	 * 参数：    @return 
	 * @return: int
	 */
	public int checkTime(Data data) {
		SimpleDateFormat ss = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		data.setPaijtime(ss.format(new Date()));
		data.setTouzhuzt("已结束");
		data.setState(data.getState());
		dataService.updateCheckState(data);
		return 1;
	}

	/**
	 * 方法名：lotterResult 
	 * 描述：    彩种号码开奖结果                  
	 * 参数：    @param data 开奖信息 
	 * @return: void
	 */
	public void lotterResult(Data data) {
		String[] da = data.getLotternumber().trim().split(",");
		int[] d = new int[da.length];
		String rs1 = "";
		String rs2 = "";
		String a1 = "";
		String a2 = "";
		String a3 = "";
		switch (data.getCname()) {
		case "ahk3":
		case "gxk3":
		case "jsk3":
		case "bjk3":
		case "jlk3":
		case "2fk3":
		case "3fk3":
			for (int i = 0; i < da.length; i++) {
				d[i] = Integer.parseInt(da[i].trim());
				rs1 = "和值:" + (d[0] + d[1] + d[2]);
			}
			data.setPlayResult(rs1);
			dataService.updatePlayResult(data);
			break;
		case "cqssc":
		case "2fssc":
		case "tjssc":
		case "xjssc":
			for (int i = 0; i < da.length; i++) {
				d[i] = Integer.parseInt(da[i].trim());
				int k = d[0] + d[1] + d[2] + d[3] + d[4];
				if (k > 22) {
					a1 = "大";
				}
				if (k < 23) {
					a1 = "小";
				}
				if (k % 2 != 0) {
					a2 = "单";
				}
				if (k % 2 == 0) {
					a2 = "双";
				}
				if (d[0] > d[4]) {
					a3 = "龙";
				}
				if (d[0] < d[4]) {
					a3 = "虎";
				}
				if (d[0] == d[4]) {
					a3 = "和";
				}
				rs2 = a1 + a2 + "|" + a3;
			}
			data.setPlayResult(rs2);
			dataService.updatePlayResult(data);
			break;
		}
	}

	/**
	  * 方法名：attribute1 
	  * 描述： 查询 六合彩生肖属性及五行属性                    
	  * 参数：    @return 
	 * @return: Map<String,Object>
	 */
	public Map<String, Object> attribute1() {
		String[] shu = new String[12];
		String[][] qiu = new String[12][5];
		Map<String, Object> map = new HashMap<>();
		List<Data> list = dataService.findLiuHeAttribute(1);
		for (int i = 0; i < list.size(); i++) {
			Data data = list.get(i);
			shu[i] = data.getCname();
			qiu[i] = data.getPeriod().split(",");
			map.put("attr", shu);
			map.put("content", qiu);
		}
		return map;
	}

	public Map<String, Object> attribute2() {
		String[] shus = new String[5];
		String[][] qius = new String[5][49];
		Map<String, Object> map = new HashMap<>();
		List<Data> lists = dataService.findLiuHeAttribute(2);
		for (int i = 0; i < lists.size(); i++) {
			Data data = lists.get(i);
			shus[i] = data.getCname();
			qius[i] = data.getPeriod().split(",");
			map.put("attrs", shus);
			map.put("contents", qius);
		}
		return map;
	}

	/**
	 * 方法名：calculateUserRatio 
	 * 描述：    计算用户的赔率                  
	 * 参数：    @return 
	 * @return: double
	 */
	public double ratio(User user,String rebate) {
		double ratio = Double.parseDouble(rebate) - Double.parseDouble(rebate) * user.getOdds();
		return ratio;
	}
	public void checkLotter1(Data datas) {
		Order orderInfo = new Order();
		orderInfo.setCname(datas.getCname());
		orderInfo.setPeriod(datas.getPeriod());
		List<Order> orders = orderService.findCheckOrder(orderInfo);
		List<String> list = new ArrayList<>();
		SimpleDateFormat ss = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		String p1 = ss.format(new Date());
		if (orders.size() < 1) {
			return;
		}
		for (Order order : orders) {
			try {
			/**
			 * 查询用户的信息
			 */
			User user = userService.getUserByid(order.getUserid());
			double userMoney = user.getBalance();
			String userName = user.getName();
			/** 总注数 */
			int count = 0;
			/** 总中奖金额 */
			double gMoney = 0.00;
			/** 彩种名称 */
			String game = order.getCname();
			/** 单注金额 */
			Double oMoney = order.getLottermoney();
			/** 开奖号码 */
			String[] data = datas.getLotternumber().split(",");
			int[] d = new int[data.length];
			for (int i = 0; i < data.length; i++) {
				d[i] = Integer.parseInt(data[i]);
			}
			/** 赔率 */
			String[] pv1 = order.getRebate1().split(",");
			String[] pv2 = order.getRebate2().split(",");
			String[] pv3 = order.getRebate3().split(",");
			String[] pv4 = order.getRebate4().split(",");
			String[] pv5 = order.getRebate5().split(",");
			String[] pv6 = order.getRebate6().split(",");
			String[] pv7 = order.getRebate7().split(",");
			String[] pv8 = order.getRebate8().split(",");
			String[] pv9 = order.getRebate9().split(",");
			String[] pv10 = order.getRebate10().split(",");
			String[] pv11 = order.getRebate11().split(",");
			String[] pv12 = order.getRebate12().split(",");
			String[] pv13 = order.getRebate13().split(",");
			String[] pv14 = order.getRebate14().split(",");
			String[] pv15 = order.getRebate15().split(",");
			String[] pv16 = order.getRebate16().split(",");
			String[] pv17 = order.getRebate17().split(",");
			String[] pv18 = order.getRebate18().split(",");
			String[] pv19 = order.getRebate19().split(",");
			String[] pv20 = order.getRebate20().split(",");
			String[] pv21 = order.getRebate21().split(",");
			String[] pv22 = order.getRebate22().split(",");
			String[] pv23 = order.getRebate23().split(",");
			String[] pv24 = order.getRebate24().split(",");
			String[] pv25 = order.getRebate25().split(",");
			String[] pv26 = order.getRebate26().split(",");
			String[] pv27 = order.getRebate27().split(",");
			String[] pv28 = order.getRebate28().split(",");
			String[] pv29 = order.getRebate29().split(",");
			String[] pv30 = order.getRebate30().split(",");
			String[] pv31 = order.getRebate31().split(",");
			String[] pv32 = order.getRebate32().split(",");
			String[] pv33 = order.getRebate33().split(",");
			String[] pv34 = order.getRebate34().split(",");
			String[] pv35 = order.getRebate35().split(",");
			String[] pv36 = order.getRebate36().split(",");
			String[] pv37 = order.getRebate37().split(",");
			String[] pv38 = order.getRebate38().split(",");
			String[] pv39 = order.getRebate39().split(",");
			String[] pv40 = order.getRebate40().split(",");

			/** 各自注数 */
			int count1 = 0;
			int count2 = 0;
			int count3 = 0;
			int count4 = 0;
			int count5 = 0;
			int count6 = 0;
			int count7 = 0;
			int count8 = 0;
			int count9 = 0;
			int count10 = 0;
			int count11 = 0;
			int count12 = 0;
			int count13 = 0;
			int count14 = 0;
			int count15 = 0;
			int count16 = 0;
			int count17 = 0;
			int count18 = 0;
			int count19 = 0;
			int count20 = 0;
			int count21 = 0;
			int count22 = 0;
			int count23 = 0;
			int count24 = 0;
			int count25 = 0;
			int count26 = 0;
			int count27 = 0;
			int count28 = 0;
			int count29 = 0;
			int count30 = 0;
			int count31 = 0;
			int count32 = 0;
			int count33 = 0;
			int count34 = 0;
			int count35 = 0;
			int count36 = 0;
			int count37 = 0;
			int count38 = 0;
			int count39 = 0;
			int count40 = 0;
			// 各自中奖金额
			double money1 = 0.00;
			double money2 = 0.00;
			double money3 = 0.00;
			double money4 = 0.00;
			double money5 = 0.00;
			double money6 = 0.00;
			double money7 = 0.00;
			double money8 = 0.00;
			double money9 = 0.00;
			double money10 = 0.00;
			double money11 = 0.00;
			double money12 = 0.00;
			double money13 = 0.00;
			double money14 = 0.00;
			double money15 = 0.00;
			double money16 = 0.00;
			double money17 = 0.00;
			double money18 = 0.00;
			double money19 = 0.00;
			double money20 = 0.00;
			double money21 = 0.00;
			double money22 = 0.00;
			double money23 = 0.00;
			double money24 = 0.00;
			double money25 = 0.00;
			double money26 = 0.00;
			double money27 = 0.00;
			double money28 = 0.00;
			double money29 = 0.00;
			double money30 = 0.00;
			double money31 = 0.00;
			double money32 = 0.00;
			double money33 = 0.00;
			double money34 = 0.00;
			double money35 = 0.00;
			double money36 = 0.00;
			double money37 = 0.00;
			double money38 = 0.00;
			double money39 = 0.00;
			double money40 = 0.00;
			
			//彩种下注金额
			List<Double> lm1 = new ArrayList<Double>();
			
			/** 匹配彩种和玩法计算开奖数据 */
			switch (game) {
			case "bjpk10":
			case "2fpk10":
			case "xyft":
			case "xysm":
			case "2fft":
				String[] gyhz = order.getStr1().split(",");
				String[] d1m = order.getStr2().split(",");
				String[] d2m = order.getStr3().split(",");
				String[] d3m = order.getStr4().split(",");
				String[] d4m = order.getStr5().split(",");
				String[] d5m = order.getStr6().split(",");
				String[] d6m = order.getStr7().split(",");
				String[] d7m = order.getStr8().split(",");
				String[] d8m = order.getStr9().split(",");
				String[] d9m = order.getStr10().split(",");
				String[] d10m = order.getStr11().split(",");
				String[] qiu = { "单", "双", "大", "小", "龙", "虎", "01", "02", "03", "04", "05", "06", "07", "08", "09",
						"10" };
				String[] qiu1 = { "单", "双", "大", "小", "01", "02", "03", "04", "05", "06", "07", "08", "09", "10" };
				// 冠亚和值
				if (gyhz.length != 0 && !"".equals(gyhz[0])) {
					int a1 = 0;
					int a2 = 0;
					int a3 = 0;
					int a4 = 0;
					int c = d[0] + d[1];
					for (int i = 0; i < gyhz.length; i++) {
						if (gyhz[i].equals("单")) {
							if (c % 2 != 0) {
								a1 = 1;
							}
						}
						if (gyhz[i].equals("双")) {
							if (c % 2 == 0) {
								a2 = 1;
							}
						}
						if (gyhz[i].equals("大")) {
							if (c > 11) {
								a3 = 1;
							}
						}
						if (gyhz[i].equals("小")) {
							if (c < 12) {
								a4 = 1;
							}
						}
					}
					count1 = a1 + a2 + a3 + a4;
					money1 = a1 * oMoney * Double.parseDouble(pv1[0]) + a2 * oMoney * Double.parseDouble(pv1[1])
							+ a3 * oMoney * Double.parseDouble(pv1[2]) + a4 * oMoney * Double.parseDouble(pv1[3]);
				}
				// 冠军
				if (d1m.length != 0 && !"".equals(d1m[0])) {
					int a1 = 0;
					int a2 = 0;
					int a3 = 0;
					int a4 = 0;
					int a5 = 0;
					int a6 = 0;
					int a7 = 0;
					int b = 0;
					int c = d[0];
					String c1 = data[0];
					for (int i = 0; i < d1m.length; i++) {
						if (d1m[i].equals("单")) {
							if (c % 2 != 0) {
								a1 = 1;
							}
						}
						if (d1m[i].equals("双")) {
							if (c % 2 == 0) {
								a2 = 1;
							}
						}
						if (d1m[i].equals("大")) {
							if (c >= 6) {
								a3 = 1;
							}
						}
						if (d1m[i].equals("小")) {
							if (c <= 5) {
								a4 = 1;
							}
						}
						if (d1m[i].equals("龙")) {
							if (c > d[9]) {
								a5 = 1;
							}
						}
						if (d1m[i].equals("虎")) {
							if (c < d[9]) {
								a6 = 1;
							}
						}
						for (int j = 0; j < qiu.length; j++) {
							if (d1m[i].equals(c1) && d1m[i].equals(qiu[j])) {
								a7 = 1;
								b = j;
							}
						}
					}
					count2 = a1 + a2 + a3 + a4 + a5 + a6 + a7;
					money2 = a1 * oMoney * Double.parseDouble(pv2[0]) + a2 * oMoney * Double.parseDouble(pv2[1])
							+ a3 * oMoney * Double.parseDouble(pv2[2]) + a4 * oMoney * Double.parseDouble(pv2[3])
							+ a5 * oMoney * Double.parseDouble(pv2[4]) + a6 * oMoney * Double.parseDouble(pv2[5])
							+ a7 * oMoney * Double.parseDouble(pv2[b]);
				}
				// 亚军
				if (d2m.length != 0 && !"".equals(d2m[0])) {
					int a1 = 0;
					int a2 = 0;
					int a3 = 0;
					int a4 = 0;
					int a5 = 0;
					int a6 = 0;
					int a7 = 0;
					int b = 0;
					int c = d[1];
					String c1 = data[1];
					for (int i = 0; i < d2m.length; i++) {
						if (d2m[i].equals("单")) {
							if (c % 2 != 0) {
								a1 = 1;
							}
						}
						if (d2m[i].equals("双")) {
							if (c % 2 == 0) {
								a2 = 1;
							}

						}
						if (d2m[i].equals("大")) {
							if (c >= 6) {
								a3 = 1;
							}
						}
						if (d2m[i].equals("小")) {
							if (c <= 5) {
								a4 = 1;
							}
						}
						if (d2m[i].equals("龙")) {
							if (c > d[8]) {
								a5 = 1;
							}
						}
						if (d2m[i].equals("虎")) {
							if (c < d[8]) {
								a6 = 1;
							}
						}
						for (int j = 0; j < qiu.length; j++) {
							if (d2m[i].equals(c1) && d2m[i].equals(qiu[j])) {
								a7 = 1;
								b = j;
							}
						}
					}
					count3 = a1 + a2 + a3 + a4 + a5 + a6 + a7;
					money3 = a1 * oMoney * Double.parseDouble(pv3[0]) + a2 * oMoney * Double.parseDouble(pv3[1])
							+ a3 * oMoney * Double.parseDouble(pv3[2]) + a4 * oMoney * Double.parseDouble(pv3[3])
							+ a5 * oMoney * Double.parseDouble(pv3[4]) + a6 * oMoney * Double.parseDouble(pv3[5])
							+ a7 * oMoney * Double.parseDouble(pv3[b]);
				}
				// 第3名
				if (d3m.length != 0 && !"".equals(d3m[0])) {
					int a1 = 0;
					int a2 = 0;
					int a3 = 0;
					int a4 = 0;
					int a5 = 0;
					int a6 = 0;
					int a7 = 0;
					int b = 0;
					int c = d[2];
					String c1 = data[2];
					for (int i = 0; i < d3m.length; i++) {
						if (d3m[i].equals("单")) {
							if (c % 2 != 0) {
								a1 = 1;
							}
						}
						if (d3m[i].equals("双")) {
							if (c % 2 == 0) {
								a2 = 1;
							}
						}
						if (d3m[i].equals("大")) {
							if (c >= 6) {
								a3 = 1;
							}
						}
						if (d3m[i].equals("小")) {
							if (c <= 5) {
								a4 = 1;
							}
						}
						if (d3m[i].equals("龙")) {
							if (c > d[7]) {
								a5 = 1;
							}
						}
						if (d3m[i].equals("虎")) {
							if (c < d[7]) {
								a6 = 1;
							}
						}
						for (int j = 0; j < qiu.length; j++) {
							if (d3m[i].equals(c1) && d3m[i].equals(qiu[j])) {
								a7 = 1;
								b = j;
							}
						}
					}
					count4 = a1 + a2 + a3 + a4 + a5 + a6 + a7;
					money4 = a1 * oMoney * Double.parseDouble(pv4[0]) + a2 * oMoney * Double.parseDouble(pv4[1])
							+ a3 * oMoney * Double.parseDouble(pv4[2]) + a4 * oMoney * Double.parseDouble(pv4[3])
							+ a5 * oMoney * Double.parseDouble(pv4[4]) + a6 * oMoney * Double.parseDouble(pv4[5])
							+ a7 * oMoney * Double.parseDouble(pv4[b]);
				}
				// 第4名
				if (d4m.length != 0 && !"".equals(d4m[0])) {
					int a1 = 0;
					int a2 = 0;
					int a3 = 0;
					int a4 = 0;
					int a5 = 0;
					int a6 = 0;
					int a7 = 0;
					int b = 0;
					int c = d[3];
					String c1 = data[3];
					for (int i = 0; i < d4m.length; i++) {
						if (d4m[i].equals("单")) {
							if (c % 2 != 0) {
								a1 = 1;
							}
						}
						if (d4m[i].equals("双")) {
							if (c % 2 == 0) {
								a2 = 1;
							}
						}
						if (d4m[i].equals("大")) {
							if (c >= 6) {
								a3 = 1;
							}
						}
						if (d4m[i].equals("小")) {
							if (c <= 5) {
								a4 = 1;
							}
						}
						if (d4m[i].equals("龙")) {
							if (c > d[6]) {
								a5 = 1;
							}
						}
						if (d4m[i].equals("虎")) {
							if (c < d[6]) {
								a6 = 1;
							}
						}
						for (int j = 0; j < qiu.length; j++) {
							if (d4m[i].equals(c1) && d4m[i].equals(qiu[j])) {
								a7 = 1;
								b = j;
							}
						}
					}
					count5 = a1 + a2 + a3 + a4 + a5 + a6 + a7;
					money5 = a1 * oMoney * Double.parseDouble(pv5[0]) + a2 * oMoney * Double.parseDouble(pv5[1])
							+ a3 * oMoney * Double.parseDouble(pv5[2]) + a4 * oMoney * Double.parseDouble(pv5[3])
							+ a5 * oMoney * Double.parseDouble(pv5[4]) + a6 * oMoney * Double.parseDouble(pv5[5])
							+ a7 * oMoney * Double.parseDouble(pv5[b]);
				}
				// 第5名
				if (d5m.length != 0 && !"".equals(d5m[0])) {
					int a1 = 0;
					int a2 = 0;
					int a3 = 0;
					int a4 = 0;
					int a5 = 0;
					int a6 = 0;
					int a7 = 0;
					int b = 0;
					int c = d[4];
					String c1 = data[4];
					for (int i = 0; i < d5m.length; i++) {
						if (d5m[i].equals("单")) {
							if (c % 2 != 0) {
								a1 = 1;
							}
						}
						if (d5m[i].equals("双")) {
							if (c % 2 == 0) {
								a2 = 1;
							}
						}
						if (d5m[i].equals("大")) {
							if (c >= 6) {
								a3 = 1;
							}
						}
						if (d5m[i].equals("小")) {
							if (c <= 5) {
								a4 = 1;
							}
						}
						if (d5m[i].equals("龙")) {
							if (c > d[5]) {
								a5 = 1;
							}
						}
						if (d5m[i].equals("虎")) {
							if (c < d[5]) {
								a6 = 1;
							}
						}
						for (int j = 0; j < qiu.length; j++) {
							if (d5m[i].equals(c1) && d5m[i].equals(qiu[j])) {
								a7 = 1;
								b = j;
							}
						}
					}
					count6 = a1 + a2 + a3 + a4 + a5 + a6 + a7;
					money6 = a1 * oMoney * Double.parseDouble(pv6[0]) + a2 * oMoney * Double.parseDouble(pv6[1])
							+ a3 * oMoney * Double.parseDouble(pv6[2]) + a4 * oMoney * Double.parseDouble(pv6[3])
							+ a5 * oMoney * Double.parseDouble(pv6[4]) + a6 * oMoney * Double.parseDouble(pv6[5])
							+ a7 * oMoney * Double.parseDouble(pv6[b]);
				}
				// 第6名
				if (d6m.length != 0 && !"".equals(d6m[0])) {
					int a1 = 0;
					int a2 = 0;
					int a3 = 0;
					int a4 = 0;
					int a5 = 0;
					int b = 0;
					int c = d[5];
					String c1 = data[5];
					for (int i = 0; i < d6m.length; i++) {
						if (d6m[i].equals("单")) {
							if (c % 2 != 0) {
								a1 = 1;
							}
						}
						if (d6m[i].equals("双")) {
							if (c % 2 == 0) {
								a2 = 1;
							}
						}
						if (d6m[i].equals("大")) {
							if (c >= 6) {
								a3 = 1;
							}
						}
						if (d6m[i].equals("小")) {
							if (c <= 5) {
								a4 = 1;
							}
						}
						for (int j = 0; j < qiu1.length; j++) {
							if (d6m[i].equals(c1) && d6m[i].equals(qiu1[j])) {
								a5 = 1;
								b = j;
							}
						}
					}
					count7 = a1 + a2 + a3 + a4 + a5;
					money7 = a1 * oMoney * Double.parseDouble(pv7[0]) + a2 * oMoney * Double.parseDouble(pv7[1])
							+ a3 * oMoney * Double.parseDouble(pv7[2]) + a4 * oMoney * Double.parseDouble(pv7[3])
							+ a5 * oMoney * Double.parseDouble(pv7[b]);

				}
				// 第7名
				if (d7m.length != 0 && !"".equals(d7m[0])) {
					int a1 = 0;
					int a2 = 0;
					int a3 = 0;
					int a4 = 0;
					int a5 = 0;
					int b = 0;
					int c = d[6];
					String c1 = data[6];
					for (int i = 0; i < d7m.length; i++) {
						if (d7m[i].equals("单")) {
							if (c % 2 != 0) {
								a1 = 1;
							}
						}
						if (d7m[i].equals("双")) {
							if (c % 2 == 0) {
								a2 = 1;
							}
						}
						if (d7m[i].equals("大")) {
							if (c >= 6) {
								a3 = 1;
							}
						}
						if (d7m[i].equals("小")) {
							if (c <= 5) {
								a4 = 1;
							}
						}
						for (int j = 0; j < qiu1.length; j++) {
							if (d7m[i].equals(c1) && d7m[i].equals(qiu1[j])) {
								a5 = 1;
								b = j;
							}
						}
					}
					count8 = a1 + a2 + a3 + a4 + a5;
					money8 = a1 * oMoney * Double.parseDouble(pv8[0]) + a2 * oMoney * Double.parseDouble(pv8[1])
							+ a3 * oMoney * Double.parseDouble(pv8[2]) + a4 * oMoney * Double.parseDouble(pv8[3])
							+ a5 * oMoney * Double.parseDouble(pv8[b]);

				}
				// 第8名
				if (d8m.length != 0 && !"".equals(d8m[0])) {
					int a1 = 0;
					int a2 = 0;
					int a3 = 0;
					int a4 = 0;
					int a5 = 0;
					int b = 0;
					int c = d[7];
					String c1 = data[7];
					for (int i = 0; i < d8m.length; i++) {
						if (d8m[i].equals("单")) {
							if (c % 2 != 0) {
								a1 = 1;
							}
						}
						if (d8m[i].equals("双")) {
							if (c % 2 == 0) {
								a2 = 1;
							}
						}
						if (d8m[i].equals("大")) {
							if (c >= 6) {
								a3 = 1;
							}
						}
						if (d8m[i].equals("小")) {
							if (c <= 5) {
								a4 = 1;
							}
						}
						for (int j = 0; j < qiu1.length; j++) {
							if (d8m[i].equals(c1) && d8m[i].equals(qiu1[j])) {
								a5 = 1;
								b = j;
							}
						}
					}
					count9 = a1 + a2 + a3 + a4 + a5;
					money9 = a1 * oMoney * Double.parseDouble(pv9[0]) + a2 * oMoney * Double.parseDouble(pv9[1])
							+ a3 * oMoney * Double.parseDouble(pv9[2]) + a4 * oMoney * Double.parseDouble(pv9[3])
							+ a5 * oMoney * Double.parseDouble(pv9[b]);

				}
				// 第9名
				if (d9m.length != 0 && !"".equals(d9m[0])) {
					int a1 = 0;
					int a2 = 0;
					int a3 = 0;
					int a4 = 0;
					int a5 = 0;
					int b = 0;
					int c = d[8];
					String c1 = data[8];
					for (int i = 0; i < d9m.length; i++) {
						if (d9m[i].equals("单")) {
							if (c % 2 != 0) {
								a1 = 1;
							}
						}
						if (d9m[i].equals("双")) {
							if (c % 2 == 0) {
								a2 = 1;
							}
						}
						if (d9m[i].equals("大")) {
							if (c >= 6) {
								a3 = 1;
							}
						}
						if (d9m[i].equals("小")) {
							if (c <= 5) {
								a4 = 1;
							}
						}
						for (int j = 0; j < qiu1.length; j++) {
							if (d9m[i].equals(c1) && d9m[i].equals(qiu1[j])) {
								a5 = 1;
								b = j;
							}
						}
					}
					count10 = a1 + a2 + a3 + a4 + a5;
					money10 = a1 * oMoney * Double.parseDouble(pv10[0]) + a2 * oMoney * Double.parseDouble(pv10[1])
							+ a3 * oMoney * Double.parseDouble(pv10[2]) + a4 * oMoney * Double.parseDouble(pv10[3])
							+ a5 * oMoney * Double.parseDouble(pv10[b]);

				}
				// 第10名
				if (d10m.length != 0 && !"".equals(d10m[0])) {
					int a1 = 0;
					int a2 = 0;
					int a3 = 0;
					int a4 = 0;
					int a5 = 0;
					int b = 0;
					int c = d[9];
					String c1 = data[9];
					for (int i = 0; i < d10m.length; i++) {
						if (d10m[i].equals("单")) {
							if (c % 2 != 0) {
								a1 = 1;
							}
						}
						if (d10m[i].equals("双")) {
							if (c % 2 == 0) {
								a2 = 1;
							}
						}
						if (d10m[i].equals("大")) {
							if (c >= 6) {
								a3 = 1;
							}
						}
						if (d10m[i].equals("小")) {
							if (c <= 5) {
								a4 = 1;
							}
						}
						for (int j = 0; j < qiu1.length; j++) {
							if (d10m[i].equals(c1) && d10m[i].equals(qiu1[j])) {
								a5 = 1;
								b = j;
							}
						}
					}
					count11 = a1 + a2 + a3 + a4 + a5;
					money11 = a1 * oMoney * Double.parseDouble(pv11[0]) + a2 * oMoney * Double.parseDouble(pv11[1])
							+ a3 * oMoney * Double.parseDouble(pv11[2]) + a4 * oMoney * Double.parseDouble(pv11[3])
							+ a5 * oMoney * Double.parseDouble(pv11[b]);
				}
				break;
			case "cqssc":
			case "2fssc":
			case "tjssc":
			case "xjssc":
				String[] zh = order.getStr1().split(",");
				String[] d1q = order.getStr2().split(",");
				String[] d2q = order.getStr3().split(",");
				String[] d3q = order.getStr4().split(",");
				String[] d4q = order.getStr5().split(",");
				String[] d5q = order.getStr6().split(",");
				String[] q3 = order.getStr7().split(",");
				String[] z3 = order.getStr8().split(",");
				String[] h3 = order.getStr9().split(",");
				String[] q2zhx0 = order.getStr10().split(",");
				String[] q2zhx1 = order.getStr11().split(",");
				String[] h2zhx0 = order.getStr12().split(",");
				String[] h2zhx1 = order.getStr13().split(",");
				String[] q3zhxx0 = order.getStr14().split(",");
				String[] q3zhxx1 = order.getStr15().split(",");
				String[] q3zhxx2 = order.getStr16().split(",");
				String[] z3zhx0 = order.getStr17().split(",");
				String[] z3zhx1 = order.getStr18().split(",");
				String[] z3zhx2 = order.getStr19().split(",");
				String[] h3zhx0 = order.getStr20().split(",");
				String[] h3zhx1 = order.getStr21().split(",");
				String[] h3zhx2 = order.getStr22().split(",");
				String[] q2zxx = order.getStr23().split(",");
				String[] h2zxx = order.getStr24().split(",");
				String[] q3z6 = order.getStr25().split(",");
				String[] z3z6 = order.getStr26().split(",");
				String[] h3z6 = order.getStr27().split(",");
				String[] q3z3 = order.getStr28().split(",");
				String[] z3z3 = order.getStr29().split(",");
				String[] h3z3 = order.getStr30().split(",");
				String[] qiu2 = { "单", "双", "大", "小", "0", "1", "2", "3", "4", "5", "6", "7", "8", "9" };
				// 总和
				if (zh.length != 0 && !"".equals(zh[0])) {
					int a1 = 0;
					int a2 = 0;
					int a3 = 0;
					int a4 = 0;
					int a5 = 0;
					int a6 = 0;
					int a7 = 0;
					int k = d[0] + d[1] + d[2] + d[3] + d[4];
					for (int i = 0; i < zh.length; i++) {
						if ("单".equals(zh[i])) {
							if (k % 2 != 0) {
								a1 = 1;
							}
						}
						if ("双".equals(zh[i])) {
							if (k % 2 == 0) {
								a2 = 1;
							}
						}
						if ("大".equals(zh[i])) {
							if (k > 22) {
								a3 = 1;
							}
						}
						if ("小".equals(zh[i])) {
							if (k < 23) {
								a4 = 1;
							}
						}
						if ("龙".equals(zh[i])) {
							if (d[0] > d[4]) {
								a5 = 1;
							}
						}
						if ("虎".equals(zh[i])) {
							if (d[0] < d[4]) {
								a6 = 1;
							}
						}
						if ("和".equals(zh[i])) {
							if (d[0] == d[4]) {
								a7 = 1;
							}
						}
					}
					count1 = a1 + a2 + a3 + a4 + a5 + a6 + a7;
					money1 = a1 * oMoney * Double.parseDouble(pv1[0]) + a2 * oMoney * Double.parseDouble(pv1[1])
							+ a3 * oMoney * Double.parseDouble(pv1[2]) + a4 * oMoney * Double.parseDouble(pv1[3])
							+ a5 * oMoney * Double.parseDouble(pv1[4]) + a6 * oMoney * Double.parseDouble(pv1[5])
							+ a7 * oMoney * Double.parseDouble(pv1[6]);

				}
				// 第1球
				if (d1q.length != 0 && !"".equals(d1q[0])) {
					int a1 = 0;
					int a2 = 0;
					int a3 = 0;
					int a4 = 0;
					int a5 = 0;
					int b = 0;
					int c = d[0];
					for (int i = 0; i < d1q.length; i++) {
						if (d1q[i].equals("单")) {
							if (c % 2 != 0) {
								a1 = 1;
							}
						}
						if (d1q[i].equals("双")) {
							if (c % 2 == 0) {
								a2 = 1;
							}
						}
						if (d1q[i].equals("大")) {
							if (c > 4 && c < 10) {
								a3 = 1;
							}
						}
						if (d1q[i].equals("小")) {
							if (c >= 0 && c < 5) {
								a4 = 1;
							}
						}
						for (int j = 0; j < qiu2.length; j++) {
							if (d1q[i].equals("" + c) && d1q[i].equals(qiu2[j])) {
								a5 = 1;
								b = j;
							}
						}
					}
					count2 = a1 + a2 + a3 + a4 + a5;
					money2 = a1 * oMoney * Double.parseDouble(pv2[0]) + a2 * oMoney * Double.parseDouble(pv2[1])
							+ a3 * oMoney * Double.parseDouble(pv2[2]) + a4 * oMoney * Double.parseDouble(pv2[3])
							+ a5 * oMoney * Double.parseDouble(pv2[b]);

				}
				// 第2球
				if (d2q.length != 0 && !"".equals(d2q[0])) {
					int a1 = 0;
					int a2 = 0;
					int a3 = 0;
					int a4 = 0;
					int a5 = 0;
					int b = 0;
					int c = d[1];
					for (int i = 0; i < d2q.length; i++) {
						if (d2q[i].equals("单")) {
							if (c % 2 != 0) {
								a1 = 1;
							}
						}
						if (d2q[i].equals("双")) {
							if (c % 2 == 0) {
								a2 = 1;
							}
						}
						if (d2q[i].equals("大")) {
							if (c > 4 && c < 10) {
								a3 = 1;
							}
						}
						if (d2q[i].equals("小")) {
							if (c >= 0 && c < 5) {
								a4 = 1;
							}
						}
						for (int j = 0; j < qiu2.length; j++) {
							if (d2q[i].equals("" + c) && d2q[i].equals(qiu2[j])) {
								a5 = 1;
								b = j;
							}
						}
					}
					count3 = a1 + a2 + a3 + a4 + a5;
					money3 = a1 * oMoney * Double.parseDouble(pv3[0]) + a2 * oMoney * Double.parseDouble(pv3[1])
							+ a3 * oMoney * Double.parseDouble(pv3[2]) + a4 * oMoney * Double.parseDouble(pv3[3])
							+ a5 * oMoney * Double.parseDouble(pv3[b]);
				}
				// 第3球
				if (d3q.length != 0 && !"".equals(d3q[0])) {
					int a1 = 0;
					int a2 = 0;
					int a3 = 0;
					int a4 = 0;
					int a5 = 0;
					int b = 0;
					int c = d[2];
					for (int i = 0; i < d3q.length; i++) {
						if (d3q[i].equals("单")) {
							if (c % 2 != 0) {
								a1 = 1;
							}
						}
						if (d3q[i].equals("双")) {
							if (c % 2 == 0) {
								a2 = 1;
							}
						}
						if (d3q[i].equals("大")) {
							if (c > 4 && c < 10) {
								a3 = 1;
							}
						}
						if (d3q[i].equals("小")) {
							if (c >= 0 && c < 5) {
								a4 = 1;
							}
						}
						for (int j = 0; j < qiu2.length; j++) {
							if (d3q[i].equals("" + c) && d3q[i].equals(qiu2[j])) {
								a5 = 1;
								b = j;
							}
						}
					}
					count4 = a1 + a2 + a3 + a4 + a5;
					money4 = a1 * oMoney * Double.parseDouble(pv4[0]) + a2 * oMoney * Double.parseDouble(pv4[1])
							+ a3 * oMoney * Double.parseDouble(pv4[2]) + a4 * oMoney * Double.parseDouble(pv4[3])
							+ a5 * oMoney * Double.parseDouble(pv4[b]);
				}
				// 第4球
				if (d4q.length != 0 && !"".equals(d4q[0])) {
					int a1 = 0;
					int a2 = 0;
					int a3 = 0;
					int a4 = 0;
					int a5 = 0;
					int b = 0;
					int c = d[3];
					for (int i = 0; i < d4q.length; i++) {
						if (d4q[i].equals("单")) {
							if (c % 2 != 0) {
								a1 = 1;
							}
						}
						if (d4q[i].equals("双")) {
							if (c % 2 == 0) {
								a2 = 1;
							}
						}
						if (d4q[i].equals("大")) {
							if (c > 4 && c < 10) {
								a3 = 1;
							}
						}
						if (d4q[i].equals("小")) {
							if (c >= 0 && c < 5) {
								a4 = 1;
							}
						}
						for (int j = 0; j < qiu2.length; j++) {
							if (d4q[i].equals("" + c) && d4q[i].equals(qiu2[j])) {
								a5 = 1;
								b = j;
							}
						}
					}
					count5 = a1 + a2 + a3 + a4 + a5;
					money5 = a1 * oMoney * Double.parseDouble(pv5[0]) + a2 * oMoney * Double.parseDouble(pv5[1])
							+ a3 * oMoney * Double.parseDouble(pv5[2]) + a4 * oMoney * Double.parseDouble(pv5[3])
							+ a5 * oMoney * Double.parseDouble(pv5[b]);
				}
				// 第5球
				if (d5q.length != 0 && !"".equals(d5q[0])) {
					int a1 = 0;
					int a2 = 0;
					int a3 = 0;
					int a4 = 0;
					int a5 = 0;
					int b = 0;
					int c = d[4];
					for (int i = 0; i < d5q.length; i++) {
						if (d5q[i].equals("单")) {
							if (c % 2 != 0) {
								a1 = 1;
							}
						}
						if (d5q[i].equals("双")) {
							if (c % 2 == 0) {
								a2 = 1;
							}
						}
						if (d5q[i].equals("大")) {
							if (c > 4 && c < 10) {
								a3 = 1;
							}
						}
						if (d5q[i].equals("小")) {
							if (c >= 0 && c < 5) {
								a4 = 1;
							}
						}
						for (int j = 0; j < qiu2.length; j++) {
							if (d5q[i].equals("" + c) && d5q[i].equals(qiu2[j])) {
								a5 = 1;
								b = j;
							}
						}
					}
					count6 = a1 + a2 + a3 + a4 + a5;
					money6 = a1 * oMoney * Double.parseDouble(pv6[0]) + a2 * oMoney * Double.parseDouble(pv6[1])
							+ a3 * oMoney * Double.parseDouble(pv6[2]) + a4 * oMoney * Double.parseDouble(pv6[3])
							+ a5 * oMoney * Double.parseDouble(pv6[b]);
				}
				String[] rule = { "890", "809", "901", "910", "908", "980", "091", "019", "089", "098", "109", "190" };
				String[] rule2 = { "902", "903", "904", "905", "906", "907", "029", "092", "039", "093", "049", "094",
						"059", "095", "069", "096", "079", "097", "209", "309", "409", "509", "609", "709", "290",
						"390", "490", "590", "690", "790", "920", "930", "940", "950", "960", "970" };
				// 前三
				if (q3.length != 0 && !"".equals(q3[0])) {
					int a = 0;
					int b = 0;
					int c = 0;
					int e = 0;
					int f = 0;
					for (int i = 0; i < q3.length; i++) {
						if ("豹子".equals(q3[i])) {
							if (d[0] == d[1] && d[0] == d[2]) {
								a = 1;
							}
						}
						if ("顺子".equals(q3[i])) {
							if (d[0] + 1 == d[1] && d[0] + 2 == d[2]) {
								b = 1;
							} else if (d[0] + 2 == d[1] && d[0] + 1 == d[2]) {
								b = 1;
							} else if (d[0] - 1 == d[1] && d[0] + 1 == d[2]) {
								b = 1;
							} else if (d[0] + 1 == d[1] && d[0] - 1 == d[2]) {
								b = 1;
							} else if (d[0] - 2 == d[1] && d[0] - 1 == d[2]) {
								b = 1;
							} else if (d[0] - 1 == d[1] && d[0] - 2 == d[2]) {
								b = 1;
							}
							for (int i1 = 0; i1 < rule.length; i1++) {
								if (("" + d[0] + d[1] + d[2]).equals(rule[i1])) {
									b = 1;
								}
							}
						}
						if ("对子".equals(q3[i])) {
							if ((d[0] != d[1] || d[0] != d[2])) {
								if (d[0] == d[1] || d[0] == d[2] || d[1] == d[2]) {
									c = 1;
								}
							}
						}
						if ("半顺".equals(q3[i])) {
							boolean flag1 = !(d[0] + 1 == d[1] && d[0] + 2 == d[2]);
							boolean flag2 = !(d[0] + 2 == d[1] && d[0] + 1 == d[2]);
							boolean flag3 = !(d[0] - 1 == d[1] && d[0] + 1 == d[2]);
							boolean flag4 = !(d[0] + 1 == d[1] && d[0] - 1 == d[2]);
							boolean flag5 = !(d[0] - 2 == d[1] && d[0] - 1 == d[2]);
							boolean flag6 = !(d[0] - 1 == d[1] && d[0] - 2 == d[2]);
							boolean flag13 = d[0] != d[1] && d[0] != d[2];
							boolean flag14 = d[0] != d[1];
							boolean flag15 = d[0] != d[2];
							boolean flag16 = d[1] != d[2];
							for (int p = 0; p < rule.length; p++) {
								boolean flag17 = !("" + d[0] + d[1] + d[2]).equals(rule[p]);
								if (flag1 && flag2 && flag3 && flag4 && flag5 && flag6 && flag13 && flag14 && flag15
										&& flag16) {
									if (d[0] + 1 == d[1] || d[0] + 1 == d[2] || d[0] - 1 == d[1] || d[0] - 1 == d[2]
											|| d[1] + 1 == d[2] || d[1] - 1 == d[2]) {
										if (flag17) {
											e = 1;
										}
										if (flag17 == false) {
											e = 0;
											break;
										}
									}
								}
							}
							for (int x = 0; x < rule2.length; x++) {
								if (("" + d[0] + d[1] + d[2]).equals(rule2[x])) {
									e = 1;
								}
							}
						}

						if (("杂六").equals(q3[i])) {
							boolean flag1 = d[0] + 1 != d[1];
							boolean flag2 = d[0] + 1 != d[2];
							boolean flag3 = d[0] - 1 != d[1];
							boolean flag4 = d[0] - 1 != d[2];
							boolean flag5 = d[1] - 1 != d[2];
							boolean flag6 = d[1] + 1 != d[2];
							boolean flag7 = d[0] != d[1];
							boolean flag8 = d[0] != d[2];
							boolean flag9 = d[1] != d[2];
							boolean flag17 = true;
							boolean flag18 = true;
							String qius = "" + d[0] + d[1] + d[2];
							for (int m = 0; m < rule.length; m++) {
								if (rule[m].equals(qius)) {
									flag17 = false;
								}
							}
							for (int m = 0; m < rule2.length; m++) {
								if (rule2[m].equals(qius)) {
									flag18 = false;
								}

							}
							boolean flag = flag1 && flag2 && flag3 && flag4 && flag5 && flag6 && flag7 && flag8 && flag9
									&& flag17 && flag18;
							if (flag) {
								f = 1;
							}
						}

					}
					count7 = a + b + c + e + f;
					money7 = a * oMoney * Double.parseDouble(pv7[0]) + b * oMoney * Double.parseDouble(pv7[1])
							+ c * oMoney * Double.parseDouble(pv7[2]) + e * oMoney * Double.parseDouble(pv7[3])
							+ f * oMoney * Double.parseDouble(pv7[4]);
				}
				// 中三
				if (z3.length != 0 && !"".equals(z3[0])) {
					int a = 0;
					int b = 0;
					int c = 0;
					int e = 0;
					int f = 0;
					for (int i = 0; i < z3.length; i++) {
						if ("豹子".equals(z3[i])) {
							if (d[1] == d[2] && d[1] == d[3]) {
								a = 1;
							}
						}
						if ("顺子".equals(z3[i])) {
							if (d[1] + 1 == d[2] && d[1] + 2 == d[3]) {
								b = 1;
							} else if (d[1] + 2 == d[2] && d[1] + 1 == d[3]) {
								b = 1;
							} else if (d[1] - 1 == d[2] && d[1] + 1 == d[3]) {
								b = 1;
							} else if (d[1] + 1 == d[2] && d[1] - 1 == d[3]) {
								b = 1;
							} else if (d[1] - 2 == d[2] && d[1] - 1 == d[3]) {
								b = 1;
							} else if (d[1] - 1 == d[2] && d[1] - 2 == d[3]) {
								b = 1;
							}
							for (int i1 = 0; i1 < rule.length; i1++) {
								if (("" + d[1] + d[2] + d[3]).equals(rule[i1])) {
									b = 1;
								}
							}
						}
						if ("对子".equals(z3[i])) {
							if (d[1] != d[2] || d[1] != d[3]) {
								if (d[1] == d[2] || d[1] == d[3] || d[2] == d[3]) {
									c = 1;
								}
							}
						}

						if ("半顺".equals(z3[i])) {
							boolean flag1 = !(d[1] + 1 == d[2] && d[1] + 2 == d[3]);
							boolean flag2 = !(d[1] + 2 == d[2] && d[1] + 1 == d[3]);
							boolean flag3 = !(d[1] - 1 == d[2] && d[1] + 1 == d[3]);
							boolean flag4 = !(d[1] + 1 == d[2] && d[1] - 1 == d[3]);
							boolean flag5 = !(d[1] - 2 == d[2] && d[1] - 1 == d[3]);
							boolean flag6 = !(d[1] - 1 == d[2] && d[1] - 2 == d[3]);
							boolean flag13 = d[1] != d[2] && d[1] != d[3];
							boolean flag14 = d[1] != d[2];
							boolean flag15 = d[1] != d[3];
							boolean flag16 = d[2] != d[3];
							for (int p = 0; p < rule.length; p++) {
								boolean flag17 = !("" + d[1] + d[2] + d[3]).equals(rule[p]);
								if (flag1 && flag2 && flag3 && flag4 && flag5 && flag6 && flag13 && flag14 && flag15
										&& flag16) {
									if (d[1] + 1 == d[2] || d[1] + 1 == d[3] || d[1] - 1 == d[2] || d[1] - 1 == d[3]
											|| d[2] + 1 == d[3] || d[2] - 1 == d[3]) {
										if (flag17) {
											e = 1;
										}
										if (flag17 == false) {
											e = 0;
											break;
										}
									}
								}
							}
							for (int x = 0; x < rule2.length; x++) {
								if (("" + d[1] + d[2] + d[3]).equals(rule2[x])) {
									e = 1;
								}
							}
						}
						if ("杂六".equals(z3[i])) {
							boolean flag1 = d[1] + 1 != d[2];
							boolean flag2 = d[1] + 1 != d[3];
							boolean flag3 = d[1] - 1 != d[2];
							boolean flag4 = d[1] - 1 != d[3];
							boolean flag5 = d[2] - 1 != d[3];
							boolean flag6 = d[2] + 1 != d[3];
							boolean flag7 = d[1] != d[2];
							boolean flag8 = d[1] != d[3];
							boolean flag9 = d[2] != d[3];
							boolean flag17 = true;
							boolean flag18 = true;
							String qius = "" + d[1] + d[2] + d[3];
							for (int m = 0; m < rule.length; m++) {
								if (rule[m].equals(qius)) {
									flag17 = false;
								}
							}
							for (int m = 0; m < rule2.length; m++) {
								if (rule2[m].equals(qius)) {
									flag18 = false;
								}

							}
							boolean flag = flag1 && flag2 && flag3 && flag4 && flag5 && flag6 && flag7 && flag8 && flag9
									&& flag17 && flag18;
							if (flag) {
								f = 1;
							}
						}
					}
					count8 = a + b + c + e + f;
					money8 = a * oMoney * Double.parseDouble(pv8[0]) + b * oMoney * Double.parseDouble(pv8[1])
							+ c * oMoney * Double.parseDouble(pv8[2]) + e * oMoney * Double.parseDouble(pv8[3])
							+ f * oMoney * Double.parseDouble(pv8[4]);
					;
				}
				// 后三
				if (h3.length != 0 && !"".equals(h3[0])) {
					int a = 0;
					int b = 0;
					int c = 0;
					int e = 0;
					int f = 0;
					for (int i = 0; i < h3.length; i++) {
						if ("豹子".equals(h3[i])) {
							if (d[2] == d[3] && d[2] == d[4]) {
								a = 1;
							}
						}
						if ("顺子".equals(h3[i])) {
							if (d[2] + 1 == d[3] && d[2] + 2 == d[4]) {
								b = 1;
							} else if (d[2] + 2 == d[3] && d[2] + 1 == d[4]) {
								b = 1;
							} else if (d[2] - 1 == d[3] && d[2] + 1 == d[4]) {
								b = 1;
							} else if (d[2] + 1 == d[3] && d[2] - 1 == d[4]) {
								b = 1;
							} else if (d[2] - 2 == d[3] && d[2] - 1 == d[4]) {
								b = 1;
							} else if (d[2] - 1 == d[3] && d[2] - 2 == d[4]) {
								b = 1;
							}
							for (int i1 = 0; i1 < rule.length; i1++) {
								if (("" + d[2] + d[3] + d[4]).equals(rule[i1])) {
									b = 1;
								}
							}
						}
						if ("对子".equals(h3[i])) {
							if (d[2] != d[3] || d[2] != d[4]) {
								if (d[2] == d[3] || d[2] == d[4] || d[3] == d[4]) {
									c = 1;
								}
							}
						}
						if ("半顺".equals(h3[i])) {
							boolean flag1 = !(d[2] + 1 == d[3] && d[2] + 2 == d[4]);
							boolean flag2 = !(d[2] + 2 == d[3] && d[2] + 1 == d[4]);
							boolean flag3 = !(d[2] - 1 == d[3] && d[2] + 1 == d[4]);
							boolean flag4 = !(d[2] + 1 == d[3] && d[2] - 1 == d[4]);
							boolean flag5 = !(d[2] - 2 == d[3] && d[2] - 1 == d[4]);
							boolean flag6 = !(d[2] - 1 == d[3] && d[2] - 2 == d[4]);
							boolean flag13 = d[2] != d[3] && d[2] != d[4];
							boolean flag14 = d[2] != d[3];
							boolean flag15 = d[2] != d[4];
							boolean flag16 = d[3] != d[4];
							for (int p = 0; p < rule.length; p++) {
								boolean flag17 = !("" + d[2] + d[3] + d[4]).equals(rule[p]);
								if (flag1 && flag2 && flag3 && flag4 && flag5 && flag6 && flag13 && flag14 && flag15
										&& flag16) {
									if (d[2] + 1 == d[3] || d[2] + 1 == d[4] || d[2] - 1 == d[3] || d[2] - 1 == d[4]
											|| d[3] + 1 == d[4] || d[3] - 1 == d[4]) {
										if (flag17) {
											e = 1;
										}
										if (flag17 == false) {
											e = 0;
											break;
										}
									}
								}
							}
							for (int x = 0; x < rule2.length; x++) {
								if (("" + d[2] + d[3] + d[4]).equals(rule2[x])) {
									e = 1;
								}
							}
						}
						if ("杂六".equals(h3[i])) {
							boolean flag1 = d[2] + 1 != d[3];
							boolean flag2 = d[2] + 1 != d[4];
							boolean flag3 = d[2] - 1 != d[3];
							boolean flag4 = d[2] - 1 != d[4];
							boolean flag5 = d[3] - 1 != d[4];
							boolean flag6 = d[3] + 1 != d[4];
							boolean flag7 = d[2] != d[3];
							boolean flag8 = d[2] != d[4];
							boolean flag9 = d[3] != d[4];
							boolean flag17 = true;
							boolean flag18 = true;
							String qius = "" + d[2] + d[3] + d[4];
							for (int m = 0; m < rule.length; m++) {
								if (rule[m].equals(qius)) {
									flag17 = false;
								}
							}
							for (int m = 0; m < rule2.length; m++) {
								if (rule2[m].equals(qius)) {
									flag18 = false;
								}

							}
							boolean flag = flag1 && flag2 && flag3 && flag4 && flag5 && flag6 && flag7 && flag8 && flag9
									&& flag17 && flag18;
							if (flag) {
								f = 1;
							}
						}
					}
					count9 = a + b + c + e + f;
					money9 = a * oMoney * Double.parseDouble(pv9[0]) + b * oMoney * Double.parseDouble(pv9[1])
							+ c * oMoney * Double.parseDouble(pv9[2]) + e * oMoney * Double.parseDouble(pv9[3])
							+ f * oMoney * Double.parseDouble(pv9[4]);
				}
				// 前二直选
				if (q2zhx0.length != 0 && !"".equals(q2zhx0[0])) {
					if (q2zhx1.length != 0 && !"".equals(q2zhx1[0])) {
						for (int i = 0; i < q2zhx0.length; i++) {
							for (int j = 0; j < q2zhx1.length; j++) {
								if (q2zhx0[i].equals(data[0]) && q2zhx1[j].equals(data[1])) {
									count10 = 1;
								}
							}
						}
					}
					money10 = count10 * oMoney * Double.parseDouble(pv10[0]);
				}
				// 后二直选
				if (h2zhx0.length != 0 && !"".equals(h2zhx0[0])) {
					if (h2zhx1.length != 0 && !"".equals(h2zhx1[0])) {
						for (int i = 0; i < h2zhx0.length; i++) {
							for (int j = 0; j < h2zhx1.length; j++) {
								if (h2zhx0[i].equals(data[3]) && h2zhx1[j].equals(data[4])) {
									count11 = 1;
								}
							}
						}
					}
					money11 = count11 * oMoney * Double.parseDouble(pv11[0]);
				}
				// 前三直选
				if (q3zhxx0.length != 0 && !"".equals(q3zhxx0[0])) {
					if (q3zhxx1.length != 0 && !"".equals(q3zhxx1[0])) {
						if (q3zhxx2.length != 0 && !"".equals(q3zhxx2[0])) {
							for (int i = 0; i < q3zhxx0.length; i++) {
								for (int j = 0; j < q3zhxx1.length; j++) {
									for (int k = 0; k < q3zhxx2.length; k++) {
										if (q3zhxx0[i].equals(data[0]) && q3zhxx1[j].equals(data[1])
												&& q3zhxx2[k].equals(data[2])) {
											count12 = 1;
										}
									}
								}
							}
						}
					}
					money12 = count12 * oMoney * Double.parseDouble(pv12[0]);
				}
				// 中三直选
				if (z3zhx0.length != 0 && !"".equals(z3zhx0[0])) {
					if (z3zhx1.length != 0 && !"".equals(z3zhx1[0])) {
						if (z3zhx2.length != 0 && !"".equals(z3zhx2[0])) {
							for (int i = 0; i < z3zhx0.length; i++) {
								for (int j = 0; j < z3zhx1.length; j++) {
									for (int k = 0; k < z3zhx2.length; k++) {
										if (z3zhx0[i].equals(data[1]) && z3zhx1[j].equals(data[2])
												&& z3zhx2[k].equals(data[3])) {
											count13 = 1;
										}
									}
								}
							}
						}
					}
					money13 = count13 * oMoney * Double.parseDouble(pv13[0]);
				}
				// 后三直选
				if (h3zhx0.length != 0 && !"".equals(h3zhx0[0])) {
					if (h3zhx1.length != 0 && !"".equals(h3zhx1[0])) {
						if (h3zhx2.length != 0 && !"".equals(h3zhx2[0])) {
							for (int i = 0; i < h3zhx0.length; i++) {
								for (int j = 0; j < h3zhx1.length; j++) {
									for (int k = 0; k < h3zhx2.length; k++) {
										if (h3zhx0[i].equals(data[2]) && h3zhx1[j].equals(data[3])
												&& h3zhx2[k].equals(data[4])) {
											count14 = 1;
										}
									}
								}
							}
						}
					}
					money14 = count14 * oMoney * Double.parseDouble(pv14[0]);
				}
				// 前二组选
				if (q2zxx.length != 0 && !"".equals(q2zxx[0])) {
					for (int i = 0; i < q2zxx.length; i++) {
						for (int j = 0; j < q2zxx.length; j++) {
							if (q2zxx[i].equals(data[0]) && q2zxx[j].equals(data[1]) && !data[0].equals(data[1])) {
								count15 = 1;
							}
						}
					}
					money15 = count15 * oMoney * Double.parseDouble(pv15[0]);
				}
				// 后二组选
				if (h2zxx.length != 0 && !"".equals(h2zxx[0])) {
					for (int i = 0; i < h2zxx.length; i++) {
						for (int j = 0; j < h2zxx.length; j++) {
							if (h2zxx[i].equals(data[3]) && h2zxx[j].equals(data[4]) && !data[0].equals(data[1])) {
								count16 = 1;
							}
						}
					}
					money16 = count16 * oMoney * Double.parseDouble(pv16[0]);
				}
				// 前三组六
				if (q3z6.length != 0 && !"".equals(q3z6[0])) {
					for (int i = 0; i < q3z6.length; i++) {
						for (int j = 0; j < q3z6.length; j++) {
							for (int k = 0; k < q3z6.length; k++) {
								if (data[0].equals(q3z6[i]) && data[1].equals(q3z6[j]) && data[2].equals(q3z6[k])) {
									if (!data[0].equals(data[1]) && !data[0].equals(data[2])
											&& !data[1].equals(data[2])) {
										count17 = 1;
									}
								}
							}
						}
					}
					money17 = count17 * oMoney * Double.parseDouble(pv17[0]);
				}
				// 中三组六
				if (z3z6.length != 0 && !"".equals(z3z6[0])) {
					for (int i = 0; i < z3z6.length; i++) {
						for (int j = 0; j < z3z6.length; j++) {
							for (int k = 0; k < z3z6.length; k++) {
								if (data[1].equals(z3z6[i]) && data[2].equals(z3z6[j]) && data[3].equals(z3z6[k])) {
									if (!data[0].equals(data[1]) && !data[0].equals(data[2])
											&& !data[1].equals(data[2])) {
										count18 = 1;
									}
								}
							}
						}
					}
					money18 = count18 * oMoney * Double.parseDouble(pv18[0]);
				}
				// 后三组六
				if (h3z6.length != 0 && !"".equals(h3z6[0])) {
					for (int i = 0; i < h3z6.length; i++) {
						for (int j = 0; j < h3z6.length; j++) {
							for (int k = 0; k < h3z6.length; k++) {
								if (data[2].equals(h3z6[i]) && data[3].equals(h3z6[j]) && data[4].equals(h3z6[k])) {
									if (!data[0].equals(data[1]) && !data[0].equals(data[2])
											&& !data[1].equals(data[2])) {
										count19 = 1;
									}
								}
							}
						}
					}
					money19 = count19 * oMoney * Double.parseDouble(pv19[0]);
				}
				// 前三组三
				if (q3z3.length != 0 && !"".equals(q3z3[0])) {
					for (int i = 0; i < q3z3.length; i++) {
						for (int j = 0; j < q3z3.length; j++) {
							for (int k = 0; k < q3z3.length; k++) {
								if (q3z3[i].equals(data[0]) && q3z3[j].equals(data[1]) && q3z3[k].equals(data[2])) {
									if (d[0] == d[1] || d[0] == d[2] || d[1] == d[2]) {
										count20 = 1;
									}
								}
							}
						}
					}
					money20 = count20 * oMoney * Double.parseDouble(pv20[0]);
				}
				// 中三组三
				if (z3z3.length != 0 && !"".equals(z3z3[0])) {
					for (int i = 0; i < z3z3.length; i++) {
						for (int j = 0; j < z3z3.length; j++) {
							for (int k = 0; k < z3z3.length; k++) {
								if (z3z3[i].equals(data[1]) && z3z3[j].equals(data[2]) && z3z3[k].equals(data[3])) {
									if (d[1] == d[2] || d[1] == d[3] || d[2] == d[3]) {
										count21 = 1;
									}
								}
							}
						}
					}
					money21 = count21 * oMoney * Double.parseDouble(pv21[0]);
				}
				// 后三组三
				if (h3z3.length != 0 && !"".equals(h3z3[0])) {
					for (int i = 0; i < h3z3.length; i++) {
						for (int j = 0; j < h3z3.length; j++) {
							for (int k = 0; k < h3z3.length; k++) {
								if (h3z3[i].equals(data[2]) && h3z3[j].equals(data[3]) && h3z3[k].equals(data[4])) {
									if (d[2] == d[3] || d[2] == d[4] || d[3] == d[4]) {
										count22 = 1;
									}
								}
							}
						}
					}
					money22 = count22 * oMoney * Double.parseDouble(pv22[0]);
				}

				break;
			case "ahk3":
			case "gxk3":
			case "jsk3":
			case "bjk3":
			case "jlk3":
			case "3fk3":
			case "2fk3":
				String[] c1gh = order.getStr1().split(",");
				String[] slhtx = order.getStr2().split(",");
				String[] ethfx = order.getStr3().split(",");
				String[] ethdx0 = order.getStr4().split(",");
				String[] ethdx1 = order.getStr5().split(",");
				String[] ebth = order.getStr6().split(",");
				String[] ebthdt0 = order.getStr7().split(",");
				String[] ebthdt1 = order.getStr8().split(",");
				String[] sthtx = order.getStr9().split(",");
				String[] sthdx = order.getStr10().split(",");
				String[] sbth = order.getStr11().split(",");
				String[] xt = order.getStr12().split(",");
				String[] zhhz = order.getStr13().split(",");
				String[] qiu3 = { "11", "22", "33", "44", "55", "66" };
				String[] qiu4 = { "111", "222", "333", "444", "555", "666", };
				String[] qiu5 = { "3", "4", "5", "6", "7", "8", "9", "10", "11", "12", "13", "14", "15", "16", "17",
						"18", "大", "小", "单", "双" };
				// 猜一个号
				if (c1gh.length != 0 && !"".equals(c1gh[0])) {
					int a1 = 0;
					int a2 = 0;
					int a3 = 0;
					int a4 = 0;
					int a5 = 0;
					int a6 = 0;
					int b1 = 0;
					int b2 = 0;
					int b3 = 0;
					int c1 = 0;
					int c2 = 0;
					int c3 = 0;
					int m = 0;
					int lc = order.getLottercount();
					for (int i = 0; i < c1gh.length; i++) {
						if (c1gh[i].equals(data[0])) {
							m += 1;
						}
						if (c1gh[i].equals(data[1])) {
							m += 1;
						}
						if (c1gh[i].equals(data[2])) {
							m += 1;
						}
					}
					if (m == 3 && (d[0] == d[1]) && d[0] == d[2]) {
						a1 = 1;
					} else if (d[0] == d[1] || d[0] == d[2] || d[1] == d[2]) {
						if (m == 3) {
							b1 = 1;
						} else if (m == 2) {
							b2 = 1;
						} else if (m == 1) {
							b3 = 1;
						}
					} else {
						if (m == 3) {
							c1 = 1;
						} else if (m == 2) {
							c2 = 1;
						} else if (m == 1) {
							c3 = 1;
						}
					}
					double plv1 = Double.parseDouble(pv1[0]);
					double plv2 = Double.parseDouble(pv1[1]);
					double plv3 = Double.parseDouble(pv1[2]);
					count1 = a1 + b1 + b2 + b3 + c1 + c2 + c3;
					money1 = oMoney * a1 * plv1 + oMoney * b1 * plv2 + oMoney * b2 * plv2 + oMoney * b3 * plv2
							+ oMoney * c1 * plv3 + oMoney * c2 * plv3 + oMoney * c3 * plv3;
				}
				// 三连号通选
				if (slhtx.length != 0 && !"".equals(slhtx[0])) {
					if ("三连号通选".equals(slhtx[0])) {
						if (d[0] + 1 == d[1] && d[0] + 2 == d[2]) {
							count2 = 1;
						}
					}
					money2 = count2 * oMoney * Double.parseDouble(pv2[0]);
				}
				// 二同号复选
				if (ethfx.length != 0 && !"".equals(ethfx[0])) {
					int b = 0;
					for (int i = 0; i < ethfx.length; i++) {
						for (int j = 0; j < qiu3.length; j++) {
							int s = (Integer.parseInt(ethfx[i])) / 11;
							if (ethfx[i].equals(qiu3[j]) && (s == d[0] && s == d[1] && d[0] == d[1])) {
								count3 = 1;
								b = j;
							}
							if (ethfx[i].equals(qiu3[j]) && (s == d[1] && s == d[2] && d[1] == d[2])) {
								count3 = 1;
								b = j;
							}
						}
					}
					money3 = count3 * oMoney * Double.parseDouble(pv3[b]);
				}
				// 二同号单选
				if (ethdx0.length != 0 && !"".equals(ethdx0[0])) {
					if (ethdx1.length != 0 && !"".equals(ethdx1[0])) {
						for (int i = 0; i < ethdx0.length; i++) {
							for (int j = 0; j < ethdx1.length; j++) {
								int x1 = Integer.parseInt(ethdx0[i]) / 11;
								int x2 = Integer.parseInt(ethdx1[j]);
								if (d[0] == d[1] && x1 == d[0] && x1 == d[1] && x2 == d[2]) {
									count4 = 1;
								}
								if (d[1] == d[2] && x2 == d[0] && x1 == d[1] && x1 == d[2]) {
									count4 = 1;
								}
							}
						}
					}
					money4 = count4 * oMoney * Double.parseDouble(pv4[0]);
				}
				// 二不同号
				if (ebth.length != 0 && !"".equals(ebth[0])) {
					for (int i = 0; i < data.length; i++) {
						for (int j = 0; j < ebth.length; j++) {
							if (ebth[j].equals(data[i])) {
								count5++;
							}
						}
					}
					if (count5 > 1) {
						count5 = 1;
					} else {
						count5 = 0;
					}
					money5 = count5 * oMoney * Double.parseDouble(pv5[0]);
				}
				// 二不同号胆拖
				if (ebthdt0.length != 0 && !"".equals(ebthdt0[0])) {
					if (ebthdt1.length != 0 && !"".equals(ebthdt1[0])) {
						for (int j = 0; j < ebthdt0.length; j++) {
							for (int k = 0; k < ebthdt1.length; k++) {
								for (int i = 0; i < data.length; i++) {
									if (ebthdt0[j].equals(data[i]) || ebthdt1[k].equals(data[i])) {
										count6++;
									}
								}
							}
						}
						if (count6 > 1) {
							count6 = 1;
						} else {
							count6 = 0;
						}
					}
					money6 = count6 * oMoney * Double.parseDouble(pv6[0]);
				}
				// 三同号通选
				if (sthtx.length != 0 && !"".equals(sthtx[0])) {
					if (d[0] == d[1] && d[0] == d[2]) {
						count7 = 1;
					}
					money7 = count7 * oMoney * Double.parseDouble(pv7[0]);
				}
				// 三同号单选
				if (sthdx.length != 0 && !"".equals(sthdx[0])) {
					int b = 0;
					for (int i = 0; i < sthdx.length; i++) {
						for (int j = 0; j < qiu4.length; j++) {
							int x1 = Integer.parseInt(sthdx[i]) / 111;
							if (sthdx[i].equals(qiu4[j]) && (d[0] == d[1]) && (d[0] == d[2]) && (x1 == d[0])
									&& (x1 == d[1]) && (x1 == d[2])) {
								count8 = 1;
								b = j;
							}
						}
					}
					money8 = count8 * oMoney * Double.parseDouble(pv8[b]);
				}
				// 三不同号
				if (sbth.length != 0 && !"".equals(sbth[0])) {
					for (int i = 0; i < sbth.length; i++) {
						int x1 = Integer.parseInt(sbth[i]);
						for (int j = 0; j < d.length; j++) {
							if (d[0] != d[1] && d[0] != d[2] && d[1] != d[2]) {
								if (x1 == d[j]) {
									count9++;
								}
							}
						}
					}
					if (count9 == 3) {
						count9 = 1;
					} else {
						count9 = 0;
					}
					money9 = count9 * oMoney * Double.parseDouble(pv9[0]);
				}
				// 形态
				if (xt.length != 0 && !"".equals(xt[0])) {
					int a = 0;
					int b = 0;
					int c = 0;
					int e = 0;
					int m = 0;
					for (int i = 0; i < xt.length; i++) {
						if ("豹子".equals(xt[i])) {
							if (d[0] == d[1] && d[0] == d[2]) {
								a = 1;
							}
						} else if ("顺子".equals(xt[i])) {
							if (d[0] + 1 == d[1] && d[0] + 2 == d[2]) {
								b = 1;
							} else if (d[0] + 2 == d[1] && d[0] + 1 == d[2]) {
								b = 1;
							} else if (d[0] - 1 == d[1] && d[0] + 1 == d[2]) {
								b = 1;
							} else if (d[0] + 1 == d[1] && d[0] - 1 == d[2]) {
								b = 1;
							} else if (d[0] - 2 == d[1] && d[0] - 1 == d[2]) {
								b = 1;
							} else if (d[0] - 1 == d[1] && d[0] - 2 == d[2]) {
								b = 1;
							}
						} else if ("对子".equals(xt[i])) {
							if ((d[0] != d[1] || d[0] != d[2])) {
								if (d[0] == d[1] || d[0] == d[2] || d[1] == d[2]) {
									c = 1;
								}
							}
						} else if ("半顺".equals(xt[i])) {
							boolean flag1 = !(d[0] + 1 == d[1] && d[0] + 2 == d[2]);
							boolean flag2 = !(d[0] + 2 == d[1] && d[0] + 1 == d[2]);
							boolean flag3 = !(d[0] - 1 == d[1] && d[0] + 1 == d[2]);
							boolean flag4 = !(d[0] + 1 == d[1] && d[0] - 1 == d[2]);
							boolean flag5 = !(d[0] - 2 == d[1] && d[0] - 1 == d[2]);
							boolean flag6 = !(d[0] - 1 == d[1] && d[0] - 2 == d[2]);
							boolean flag13 = d[0] != d[1] && d[0] != d[2];
							boolean flag14 = d[0] != d[1];
							boolean flag15 = d[0] != d[2];
							boolean flag16 = d[1] != d[2];
							if (flag1 && flag2 && flag3 && flag4 && flag5 && flag6 && flag13 && flag14 && flag15
									&& flag16) {
								if (d[0] + 1 == d[1] || d[0] + 1 == d[2] || d[0] - 1 == d[1] || d[0] - 1 == d[2]
										|| d[1] + 1 == d[2] || d[1] - 1 == d[2]) {
									e = 1;
								}
							}
						} else if ("杂六".equals(xt[i])) {
							boolean flag1 = d[0] + 1 != d[1];
							boolean flag2 = d[0] + 1 != d[2];
							boolean flag3 = d[1] + 1 != d[2];
							boolean flag4 = d[0] - 1 != d[1];
							boolean flag5 = d[0] - 1 != d[2];
							boolean flag6 = d[1] - 1 != d[2];
							boolean flag13 = d[0] != d[1] && d[0] != d[2];
							boolean flag14 = d[0] != d[1];
							boolean flag15 = d[0] != d[2];
							boolean flag16 = d[1] != d[2];
							if (flag1 && flag2 && flag3 && flag4 && flag5 && flag6) {
								if (flag13 && (flag14 || flag15 || flag16)) {
									m = 1;
								}
							}
						}
					}
					count10 = a + b + c + e + m;
					money10 = a * oMoney * Double.parseDouble(pv10[0]) + b * oMoney * Double.parseDouble(pv10[1])
							+ c * oMoney * Double.parseDouble(pv10[2]) + e * oMoney * Double.parseDouble(pv10[3])
							+ m * oMoney * Double.parseDouble(pv10[4]);
				}
				// 总和-和值
				if (zhhz.length != 0 && !"".equals(zhhz[0])) {
					int o = (d[0] + d[1] + d[2]);
					int a1 = 0;
					int a2 = 0;
					int a3 = 0;
					int a4 = 0;
					int a5 = 0;
					int b = 0;
					for (int i = 0; i < zhhz.length; i++) {
						for (int j = 0; j < qiu5.length; j++) {
							if (zhhz[i].equals(o + "") && zhhz[i].equals(qiu5[j])) {
								a1 = 1;
								b = j;
							}
							if (zhhz[i].equals("大")) {
								if (o  > 10 && o < 19) {
									a2 = 1;
								}
							}
							if (zhhz[i].equals("小")) {
								if (o < 11 && o > 2) {
									a3 = 1;
								}
							}
							if (zhhz[i].equals("单")) {
								if (o % 2 != 0) {
									a4 = 1;
								}
							}
							if (zhhz[i].equals("双")) {
								if (o % 2 == 0) {
									a5 = 1;
								}
							}

						}
					}
					count11 = a1 + a2 + a3 + a4 + a5;
					money11 = a1 * oMoney * Double.parseDouble(pv11[b]) + a2 * oMoney * Double.parseDouble(pv11[16])
							+ a3 * oMoney * Double.parseDouble(pv11[17]) + a4 * oMoney * Double.parseDouble(pv11[18])
							+ a5 * oMoney * Double.parseDouble(pv11[19]);
				}
				break;
			case "gdkl10f":
			case "cqkl10f":
				String[] swst = order.getStr1().split(",");
				String[] swht = order.getStr2().split(",");
				String[] elzhix0 = order.getStr3().split(",");
				String[] elzhix1 = order.getStr4().split(",");
				String[] elzx = order.getStr5().split(",");
				String[] q3zhix0 = order.getStr6().split(",");
				String[] q3zhix1 = order.getStr7().split(",");
				String[] q3zhix2 = order.getStr8().split(",");
				String[] q3zx = order.getStr9().split(",");
				String[] kl2 = order.getStr10().split(",");
				String[] kl3 = order.getStr11().split(",");
				String[] kl4 = order.getStr12().split(",");
				String[] kl5 = order.getStr13().split(",");
				String[] qiu6 = { "01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12", "13", "14",
						"15", "16", "17", "18" };
				// 首位数投
				if (swst.length != 0 && !"".equals(swst[0])) {
					int b = 0;
					for (int i = 0; i < swst.length; i++) {
						for (int j = 0; j < qiu6.length; j++) {
							if (data[0].equals(swst[i]) && swst[i].equals(qiu6[j])) {
								count1 = 1;
								b = j;
							}
						}
					}
					money1 = count1 * oMoney * Double.parseDouble(pv1[b]);
				}
				// 首位红投
				if (swht.length != 0 && !"".equals(swht[0])) {
					int a1 = 0;
					int a2 = 0;
					for (int i = 0; i < swht.length; i++) {
						if (swht[i].equals("19")) {
							if (swht[i].equals(data[0])) {
								a1 = 1;
							}
						}
						if (swht[i].equals("20")) {
							if (swht[i].equals(data[0])) {
								a2 = 1;
							}
						}
					}
					count2 = a1 + a2;
					money2 = a1 * oMoney * Double.parseDouble(pv2[0]) + a2 * oMoney * Double.parseDouble(pv2[1]);
				}
				// 二连直选
				if (elzhix0.length != 0 && !"".equals(elzhix0[0])) {
					if (elzhix1.length != 0 && !"".equals(elzhix1[0])) {
						for (int i = 1; i < data.length; i++) {
							for (int j = 0; j < elzhix0.length; j++) {
								for (int k = 0; k < elzhix1.length; k++) {
									if (data[i - 1].equals(elzhix0[j])) {
										if (data[i].equals(elzhix1[k])) {
											count3++;
										}
									}
								}
							}
						}
					}
					if (count3 > 0) {
						count3 = 1;
					} else {
						count3 = 0;
					}
					money3 = count3 * oMoney * Double.parseDouble(pv3[0]);
				}
				// 二连组选
				if (elzx.length != 0 && !"".equals(elzx[0])) {
					for (int j = 0; j < elzx.length; j++) {
						for (int k = 0; k < elzx.length; k++) {
							for (int i = 0; i < data.length - 1; i++) {
								if (elzx[j].equals(data[i])) {
									if (j != k) {
										if (elzx[k].equals(data[i + 1])) {
											if (!data[0].equals(data[1])) {
												count4++;
											}
										}
									}
								}
							}
						}
					}
					money4 = count4 * oMoney * Double.parseDouble(pv4[0]);
				}
				// 前三直选
				if (q3zhix0.length != 0 && !"".equals(q3zhix0[0])) {
					if (q3zhix1.length != 0 && !"".equals(q3zhix1[0])) {
						if (q3zhix2.length != 0 && !"".equals(q3zhix2[0])) {
							for (int i = 0; i < q3zhix0.length; i++) {
								for (int j = 0; j < q3zhix1.length; j++) {
									for (int k = 0; k < q3zhix2.length; k++) {
										if (q3zhix0[i].equals(data[0]) && q3zhix1[j].equals(data[1])
												&& q3zhix2[k].equals(data[2])) {
											count5 = 1;
										}
									}
								}
							}
						}
					}
					money5 = count5 * oMoney * Double.parseDouble(pv5[0]);
				}
				// 前三组选
				if (q3zx.length != 0 && !"".equals(q3zx[0])) {
					for (int i = 0; i < q3zx.length; i++) {
						for (int j = 0; j < q3zx.length; j++) {
							for (int k = 0; k < q3zx.length; k++) {
								if (data[0].equals(q3zx[i]) && data[1].equals(q3zx[j]) && data[2].equals(q3zx[k])) {
									if (!data[0].equals(data[1]) && !data[1].equals(data[2])
											&& !data[0].equals(data[2])) {
										count6 = 1;
									}
								}

							}
						}
					}
					money6 = count6 * oMoney * Double.parseDouble(pv6[0]);
				}
				// 快乐2
				if (kl2.length != 0 && !"".equals(kl2[0])) {
					ArrayList<String> a1Arr = new ArrayList<>();
					ArrayList<String> a2Arr = new ArrayList<>();
					Combine.combine(0, 2, kl2, a1Arr);
					Combine.combine(0, 2, data, a2Arr);
					for (int i = 0; i < a1Arr.size(); i++) {
						for (int j = 0; j < a2Arr.size(); j++) {
							if (a1Arr.get(i).toString().equals(a2Arr.get(j).toString())) {
								count7++;
							}
						}
					}
					money7 = count7 * oMoney * Double.parseDouble(pv7[0]);
				}
				// 快乐3
				if (kl3.length != 0 && !"".equals(kl3[0])) {
					ArrayList<String> a1Arr = new ArrayList<>();
					ArrayList<String> a2Arr = new ArrayList<>();
					Combine.combine(0, 3, kl3, a1Arr);
					Combine.combine(0, 3, data, a2Arr);
					for (int i = 0; i < a1Arr.size(); i++) {
						for (int j = 0; j < a2Arr.size(); j++) {
							if (a1Arr.get(i).toString().equals(a2Arr.get(j).toString())) {
								count8++;
							}
						}
					}
					money8 = count8 * oMoney * Double.parseDouble(pv8[0]);
				}
				// 快乐4
				if (kl4.length != 0 && !"".equals(kl4[0])) {
					ArrayList<String> a1Arr = new ArrayList<>();
					ArrayList<String> a2Arr = new ArrayList<>();
					Combine.combine(0, 4, kl4, a1Arr);
					Combine.combine(0, 4, data, a2Arr);
					for (int i = 0; i < a1Arr.size(); i++) {
						for (int j = 0; j < a2Arr.size(); j++) {
							if (a1Arr.get(i).toString().equals(a2Arr.get(j).toString())) {
								count9++;
							}
						}
					}
					money9 = count9 * oMoney * Double.parseDouble(pv9[0]);
				}
				// 快乐5
				if (kl5.length != 0 && !"".equals(kl5[0])) {
					ArrayList<String> a1Arr = new ArrayList<>();
					ArrayList<String> a2Arr = new ArrayList<>();
					Combine.combine(0, 5, kl5, a1Arr);
					Combine.combine(0, 5, data, a2Arr);
					for (int i = 0; i < a1Arr.size(); i++) {
						for (int j = 0; j < a2Arr.size(); j++) {
							if (a1Arr.get(i).toString().equals(a2Arr.get(j).toString())) {
								count10++;
							}
						}
					}
					money10 = count10 * oMoney * Double.parseDouble(pv10[0]);
				}
				break;

			case "shssl":
			case "pl3":
			case "fc3d":
				String[] q2zhix0 = order.getStr1().split(",");
				String[] q2zhix1 = order.getStr2().split(",");
				String[] q2zx = order.getStr3().split(",");
				String[] h2zhix0 = order.getStr4().split(",");
				String[] h2zhix1 = order.getStr5().split(",");
				String[] h2zx = order.getStr6().split(",");
				String[] sxzhix0 = order.getStr7().split(",");
				String[] sxzhix1 = order.getStr8().split(",");
				String[] sxzhix2 = order.getStr9().split(",");
				String[] sxhz = order.getStr10().split(",");
				String[] sxz3 = order.getStr11().split(",");
				String[] z3hz = order.getStr12().split(",");
				String[] sxz6 = order.getStr13().split(",");
				String[] z6hz = order.getStr14().split(",");
				// 前二直选
				if (q2zhix0.length != 0 && !"".equals(q2zhix0[0])) {
					if (q2zhix1.length != 0 && !"".equals(q2zhix1[0])) {
						for (int i = 0; i < q2zhix0.length; i++) {
							for (int j = 0; j < q2zhix1.length; j++) {
								if (data[0].equals(q2zhix0[i])) {
									if (data[1].equals(q2zhix1[j])) {
										count1 = 1;
									}
								}
							}
						}
					}
					money1 = count1 * oMoney * Double.parseDouble(pv1[0]);
				}
				// 前二组选
				if (q2zx.length != 0 && !"".equals(q2zx[0])) {
					for (int i = 0; i < q2zx.length; i++) {
						for (int j = 0; j < q2zx.length; j++) {
							if (data[0].equals(q2zx[i]) && data[1].equals(q2zx[j])) {
								if (!data[0].equals(data[1])) {
									count2 = 1;
								}
							}
						}
					}
					money2 = count2 * oMoney * Double.parseDouble(pv2[0]);
				}
				// 后二直选
				if (h2zhix0.length != 0 && !"".equals(h2zhix0[0])) {
					if (h2zhix1.length != 0 && !"".equals(h2zhix1[0])) {
						for (int i = 0; i < h2zhix0.length; i++) {
							for (int j = 0; j < h2zhix1.length; j++) {
								if (data[1].equals(h2zhix0[i])) {
									if (data[2].equals(h2zhix1[j])) {
										count3 = 1;
									}
								}
							}
						}
					}
					money3 = count3 * oMoney * Double.parseDouble(pv3[0]);
				}
				// 后二组选
				if (h2zx.length != 0 && !"".equals(h2zx[0])) {
					for (int i = 0; i < h2zx.length; i++) {
						for (int j = 0; j < h2zx.length; j++) {
							if (data[1].equals(h2zx[i]) && data[2].equals(h2zx[j])) {
								if (!data[1].equals(data[2])) {
									count4 = 1;
								}
							}
						}
					}
					money4 = count4 * oMoney * Double.parseDouble(pv4[0]);
				}
				// 三星直选
				if (sxzhix0.length != 0 && !"".equals(sxzhix0[0])) {
					if (sxzhix1.length != 0 && !"".equals(sxzhix1[0])) {
						if (sxzhix2.length != 0 && !"".equals(sxzhix2[0])) {
							for (int i = 0; i < sxzhix0.length; i++) {
								for (int j = 0; j < sxzhix1.length; j++) {
									for (int k = 0; k < sxzhix2.length; k++) {
										if (data[0].equals(sxzhix0[i])) {
											if (data[1].equals(sxzhix1[j])) {
												if (data[2].equals(sxzhix2[k])) {
													count5 = 1;
												}
											}
										}
									}
								}
							}
						}
					}
					money5 = count5 * oMoney * Double.parseDouble(pv5[0]);
				}
				// 三星直选和值
				if (sxhz.length != 0 && !"".equals(sxhz[0])) {
					for (int i = 0; i < sxhz.length; i++) {
						String s = (d[0] + d[1] + d[2]) + "";
						if (s.equals(sxhz[i])) {
							count6 = 1;
						}
					}
					money6 = count6 * oMoney * Double.parseDouble(pv6[0]);
				}
				// 三星组三
				if (sxz3.length != 0 && !"".equals(sxz3[0])) {
					for (int j = 0; j < sxz3.length; j++) {
						for (int i = 0; i < sxz3.length; i++) {
							for (int k = 0; k < sxz3.length; k++) {
								if (data[0].equals(sxz3[j]) && data[1].equals(sxz3[i]) && data[2].equals(sxz3[k])) {
									if (d[0] == d[1] || d[0] == d[2] || d[1] == d[2]) {
										count7 = 1;
									}
								}
							}
						}
					}
					money7 = count7 * oMoney * Double.parseDouble(pv7[0]);
				}
				// 组三和值
				if (z3hz.length != 0 && !"".equals(z3hz[0])) {
					int a = 0;
					String s = (d[0] + d[1] + d[2]) + "";
					for (int i = 0; i < z3hz.length; i++) {
						for (int j = 0; j < data.length; j++) {
							if (z3hz[i].equals(data[j])) {
								a++;
							}
						}
						if (s.equals(z3hz[i]) && a >= 3) {
							count8 = 1;
						}
					}
					money8 = count8 * oMoney * Double.parseDouble(pv8[0]);
				}
				// 三星组六
				if (sxz6.length != 0 && !"".equals(sxz6[0])) {
					int a = 0;
					for (int i = 0; i < sxz6.length; i++) {
						if (sxz6[i].equals(data[0]) || sxz6[i].equals(data[1]) || sxz6[i].equals(data[2])) {
							if (d[0] != d[1] || d[0] != d[2] || d[1] != d[2]) {
								a++;
							}
						}
					}
					if (a > 2) {
						count9 = 1;
					}
					money9 = count9 * oMoney * Double.parseDouble(pv9[0]);
				}
				// 组六和值
				if (z6hz.length != 0 && !"".equals(z6hz[0])) {
					String s = (d[0] + d[1] + d[2]) + "";
					int a = 0;
					for (int i = 0; i < z6hz.length; i++) {
						if (z6hz[i].equals(data[0]) || z6hz[i].equals(data[1]) || z6hz[i].equals(data[2])) {
							if (d[0] != d[1] || d[0] != d[2] || d[1] != d[2]) {
								a++;
							}
						}
						if (s.equals(z6hz[i]) && a > 2) {
							count10 = 1;
						}
					}
					money10 = count10 * oMoney * Double.parseDouble(pv10[0]);
				}
				break;
			case "ah11x5":
			case "gd11x5":
			case "jx11x5":
			case "sd11x5":
			case "sh11x5":
				String[] d1qq = order.getStr1().split(",");
				String[] d2qq = order.getStr2().split(",");
				String[] d3qq = order.getStr3().split(",");
				String[] d4qq = order.getStr4().split(",");
				String[] d5qq = order.getStr5().split(",");
				String[] zh1 = order.getStr6().split(",");
				String[] q1zhix = order.getStr7().split(",");
				String[] q2zhix01 = order.getStr8().split(",");
				String[] q2zhix02 = order.getStr9().split(",");
				String[] q3zhix01 = order.getStr10().split(",");
				String[] q3zhix02 = order.getStr11().split(",");
				String[] q3zhix03 = order.getStr12().split(",");
				String[] rx1 = order.getStr13().split(",");
				String[] rx2 = order.getStr14().split(",");
				String[] rx3 = order.getStr15().split(",");
				String[] rx4 = order.getStr16().split(",");
				String[] rx5 = order.getStr17().split(",");
				String[] rx6 = order.getStr18().split(",");
				String[] rx7 = order.getStr19().split(",");
				String[] rx8 = order.getStr20().split(",");
				String[] qiu7 = { "单", "双", "大", "小", "01", "02", "03", "04", "05", "06", "07", "08", "09", "10",
						"11" };
				String[] qiu8 = { "01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11" };
				// 第1球
				if (d1qq.length != 0 && !"".equals(d1qq[0])) {
					int a1 = 0;
					int a2 = 0;
					int a3 = 0;
					int a4 = 0;
					int a5 = 0;
					int b = 0;
					int c = d[0];
					String c1 = data[0];
					for (int i = 0; i < d1qq.length; i++) {
						if (d1qq[i].equals("单")) {
							if (c % 2 != 0) {
								a1 = 1;
							}
						}
						if (d1qq[i].equals("双")) {
							if (c % 2 == 0) {
								a2 = 1;
							}
						}
						if (d1qq[i].equals("大")) {
							if (c >= 6) {
								a3 = 1;
							}
						}
						if (d1qq[i].equals("小")) {
							if (c <= 5) {
								a4 = 1;
							}
						}
						for (int j = 0; j < qiu7.length; j++) {
							if (d1qq[i].equals(c1) && d1qq[i].equals(qiu7[j])) {
								a5 = 1;
								b = j;
							}
						}
					}
					count1 += a1 + a2 + a3 + a4 + a5;
					money1 = a1 * oMoney * Double.parseDouble(pv1[0]) + a2 * oMoney * Double.parseDouble(pv1[1])
							+ a3 * oMoney * Double.parseDouble(pv1[2]) + a4 * oMoney * Double.parseDouble(pv1[3])
							+ a5 * oMoney * Double.parseDouble(pv1[b]);
				}
				// 第2球
				if (d2qq.length != 0 && !"".equals(d2qq[0])) {
					int a1 = 0;
					int a2 = 0;
					int a3 = 0;
					int a4 = 0;
					int a5 = 0;
					int b = 0;
					int c = d[1];
					String c1 = data[1];
					for (int i = 0; i < d2qq.length; i++) {
						if (d2qq[i].equals("单")) {
							if (c % 2 != 0) {
								a1 = 1;
							}
						}
						if (d2qq[i].equals("双")) {
							if (c % 2 == 0) {
								a2 = 1;
							}
						}
						if (d2qq[i].equals("大")) {
							if (c >= 6) {
								a3 = 1;
							}
						}
						if (d2qq[i].equals("小")) {
							if (c <= 5) {
								a4 = 1;
							}
						}
						for (int j = 0; j < qiu7.length; j++) {
							if (d2qq[i].equals(c1) && d2qq[i].equals(qiu7[j])) {
								a5 = 1;
								b = j;
							}
						}
					}
					count2 += a1 + a2 + a3 + a4 + a5;
					money2 = a1 * oMoney * Double.parseDouble(pv2[0]) + a2 * oMoney * Double.parseDouble(pv2[1])
							+ a3 * oMoney * Double.parseDouble(pv2[2]) + a4 * oMoney * Double.parseDouble(pv2[3])
							+ a5 * oMoney * Double.parseDouble(pv2[b]);
				}
				// 第3球
				if (d3qq.length != 0 && !"".equals(d3qq[0])) {
					int a1 = 0;
					int a2 = 0;
					int a3 = 0;
					int a4 = 0;
					int a5 = 0;
					int b = 0;
					int c = d[2];
					String c1 = data[2];
					for (int i = 0; i < d3qq.length; i++) {
						if (d3qq[i].equals("单")) {
							if (c % 2 != 0) {
								a1 = 1;
							}
						}
						if (d3qq[i].equals("双")) {
							if (c % 2 == 0) {
								a2 = 1;
							}
						}
						if (d3qq[i].equals("大")) {
							if (c >= 6) {
								a3 = 1;
							}
						}
						if (d3qq[i].equals("小")) {
							if (c <= 5) {
								a4 = 1;
							}
						}
						for (int j = 0; j < qiu7.length; j++) {
							if (d3qq[i].equals(c1) && d3qq[i].equals(qiu7[j])) {
								a5 = 1;
								b = j;
							}
						}
					}
					count3 += a1 + a2 + a3 + a4 + a5;
					money3 = a1 * oMoney * Double.parseDouble(pv3[0]) + a2 * oMoney * Double.parseDouble(pv3[1])
							+ a3 * oMoney * Double.parseDouble(pv3[2]) + a4 * oMoney * Double.parseDouble(pv3[3])
							+ a5 * oMoney * Double.parseDouble(pv3[b]);
				}
				// 第4球
				if (d4qq.length != 0 && !"".equals(d4qq[0])) {
					int a1 = 0;
					int a2 = 0;
					int a3 = 0;
					int a4 = 0;
					int a5 = 0;
					int b = 0;
					int c = d[3];
					String c1 = data[3];
					for (int i = 0; i < d4qq.length; i++) {
						if (d4qq[i].equals("单")) {
							if (c % 2 != 0) {
								a1 = 1;
							}
						}
						if (d4qq[i].equals("双")) {
							if (c % 2 == 0) {
								a2 = 1;
							}
						}
						if (d4qq[i].equals("大")) {
							if (c >= 6) {
								a3 = 1;
							}
						}
						if (d4qq[i].equals("小")) {
							if (c <= 5) {
								a4 = 1;
							}
						}
						for (int j = 0; j < qiu7.length; j++) {
							if (d4qq[i].equals(c1) && d4qq[i].equals(qiu7[j])) {
								a5 = 1;
								b = j;
							}
						}
					}
					count4 += a1 + a2 + a3 + a4 + a5;
					money4 = a1 * oMoney * Double.parseDouble(pv4[0]) + a2 * oMoney * Double.parseDouble(pv4[1])
							+ a3 * oMoney * Double.parseDouble(pv4[2]) + a4 * oMoney * Double.parseDouble(pv4[3])
							+ a5 * oMoney * Double.parseDouble(pv4[b]);
				}
				// 第5球
				if (d5qq.length != 0 && !"".equals(d5qq[0])) {
					int a1 = 0;
					int a2 = 0;
					int a3 = 0;
					int a4 = 0;
					int a5 = 0;
					int b = 0;
					int c = d[4];
					String c1 = data[4];
					for (int i = 0; i < d5qq.length; i++) {
						if (d5qq[i].equals("单")) {
							if (c % 2 != 0) {
								a1 = 1;
							}
						}
						if (d5qq[i].equals("双")) {
							if (c % 2 == 0) {
								a2 = 1;
							}
						}
						if (d5qq[i].equals("大")) {
							if (c >= 6) {
								a3 = 1;
							}
						}
						if (d5qq[i].equals("小")) {
							if (c <= 5) {
								a4 = 1;
							}
						}
						for (int j = 0; j < qiu7.length; j++) {
							if (d5qq[i].equals(c1) && d5qq[i].equals(qiu7[j])) {
								a5 = 1;
								b = j;
							}
						}
					}
					count5 += a1 + a2 + a3 + a4 + a5;
					money5 = a1 * oMoney * Double.parseDouble(pv5[0]) + a2 * oMoney * Double.parseDouble(pv5[1])
							+ a3 * oMoney * Double.parseDouble(pv5[2]) + a4 * oMoney * Double.parseDouble(pv5[3])
							+ a5 * oMoney * Double.parseDouble(pv5[b]);
				}
				// 总和
				if (zh1.length != 0 && !"".equals(zh1[0])) {
					int a1 = 0;
					int a2 = 0;
					int a3 = 0;
					int a4 = 0;
					int b = 0;
					int c = d[0] + d[1] + d[2] + d[3] + d[4];
					for (int i = 0; i < zh1.length; i++) {
						if ("单".equals(zh1[i])) {
							if (c % 2 != 0) {
								a1 = 1;
							}
						}
						if ("双".equals(zh1[i])) {
							if (c % 2 == 0) {
								a2 = 1;
							}
						}
						if ("大".equals(zh1[i])) {
							if (c > 30) {
								a3 = 1;
							}
						}
						if ("小".equals(zh1[i])) {
							if (c < 30) {
								a4 = 1;
							}
						}
					}
					count6 = a1 + a2 + a3 + a4;
					money6 = a1 * oMoney * Double.parseDouble(pv6[0]) + a2 * oMoney * Double.parseDouble(pv6[1])
							+ a3 * oMoney * Double.parseDouble(pv6[2]) + a4 * oMoney * Double.parseDouble(pv1[3]);

				}
				// 前一直选
				if (q1zhix.length != 0 && !"".equals(q1zhix[0])) {
					int b = 0;
					for (int j = 0; j < q1zhix.length; j++) {
						for (int i = 0; i < qiu8.length; i++) {
							if (data[0].equals(q1zhix[j]) && q1zhix[j].equals(qiu8[j])) {
								count7 = 1;
								b = j;
							}
						}
					}
					money7 = count7 * oMoney * Double.parseDouble(pv7[b]);
				}
				// 前二直选
				if (q2zhix01.length != 0 && !"".equals(q2zhix01[0])) {
					if (q2zhix02.length != 0 && !"".equals(q2zhix02[0])) {
						for (int j = 0; j < q2zhix01.length; j++) {
							if (data[0].equals(q2zhix01[j])) {
								for (int i = 0; i < q2zhix02.length; i++) {
									if (data[1].equals(q2zhix02[i])) {
										count8 = 1;
									}
								}
							}
						}
					}
					money8 = count8 * oMoney * Double.parseDouble(pv8[0]);
				}

				// 前三直选
				if (q3zhix01.length != 0 && !"".equals(q3zhix01[0])) {
					if (q3zhix02.length != 0 && !"".equals(q3zhix02[0])) {
						if (q3zhix03.length != 0 && !"".equals(q3zhix03[0])) {
							for (int i = 0; i < q3zhix01.length; i++) {
								if (data[0].equals(q3zhix01[i])) {
									for (int j = 0; j < q3zhix02.length; j++) {
										if (data[1].equals(q3zhix02[j])) {
											for (int k = 0; k < q3zhix03.length; k++) {
												if (data[2].equals(q3zhix03[k])) {
													count9 = 1;
												}
											}
										}
									}
								}
							}
						}
					}
					money9 = count9 * oMoney * Double.parseDouble(pv9[0]);
				}
				// 任选1
				if (rx1.length != 0 && !"".equals(rx1[0])) {
					int b = 0;
					for (int i = 0; i < rx1.length; i++) {
						for (int j = 0; j < data.length; j++) {
							for (int k = 0; k < qiu8.length; k++) {
								if (rx1[i].equals(data[j]) && rx1[i].equals(qiu8[k])) {
									count10++;
									b = j;
								}
							}
						}
					}
					if (count10 > 0) {
						count10 = 1;
					} else {
						count10 = 0;
					}
					money10 = count10 * oMoney * Double.parseDouble(pv10[b]);
				}
				// 任选2
				if (rx2.length != 0 && !"".equals(rx2[0])) {
					ArrayList<String> a1Arr = new ArrayList<>();
					Combine.combine(0, 2, rx2, a1Arr);
					for (int i = 0; i < a1Arr.size(); i++) {
						int a1 = 0;
						String[] arrs = a1Arr.get(i).split(",");
						for (int j = 0; j < arrs.length; j++) {
							for (int k = 0; k < data.length; k++) {
								if (arrs[j].equals(data[k])) {
									a1++;
								}
							}
						}
						if (a1 == 2) {
							count11++;
						}
					}
					money11 = count11 * oMoney * Double.parseDouble(pv11[0]);
				}
				// 任选3
				if (rx3.length != 0 && !"".equals(rx3[0])) {
					ArrayList<String> a1Arr = new ArrayList<>();
					Combine.combine(0, 3, rx3, a1Arr);
					for (int i = 0; i < a1Arr.size(); i++) {
						int a1 = 0;
						String[] arrs = a1Arr.get(i).split(",");
						for (int j = 0; j < arrs.length; j++) {
							for (int k = 0; k < data.length; k++) {
								if (arrs[j].equals(data[k])) {
									a1++;
								}
							}
						}
						if (a1 == 3) {
							count12++;
						}
					}
					money12 = count12 * oMoney * Double.parseDouble(pv12[0]);
				}
				// 任选4
				if (rx4.length != 0 && !"".equals(rx4[0])) {
					ArrayList<String> a1Arr = new ArrayList<>();
					Combine.combine(0, 4, rx4, a1Arr);
					for (int i = 0; i < a1Arr.size(); i++) {
						int a1 = 0;
						String[] arrs = a1Arr.get(i).split(",");
						for (int j = 0; j < arrs.length; j++) {
							for (int k = 0; k < data.length; k++) {
								if (arrs[j].equals(data[k])) {
									a1++;
								}
							}
						}
						if (a1 == 4) {
							count13++;
						}
					}
					money13 = count13 * oMoney * Double.parseDouble(pv13[0]);
				}

				// 任选5
				if (rx5.length != 0 && !"".equals(rx5[0])) {
					ArrayList<String> a1Arr = new ArrayList<>();
					Combine.combine(0, 5, rx5, a1Arr);
					for (int i = 0; i < a1Arr.size(); i++) {
						int a1 = 0;
						String[] arrs = a1Arr.get(i).split(",");
						for (int j = 0; j < arrs.length; j++) {
							for (int k = 0; k < data.length; k++) {
								if (arrs[j].equals(data[k])) {
									a1++;
								}
							}
						}
						if (a1 == 5) {
							count14++;
						}
					}
					money14 = count14 * oMoney * Double.parseDouble(pv14[0]);
				}

				// 任选6
				if (rx6.length != 0 && !"".equals(rx6[0])) {
					ArrayList<String> a1Arr = new ArrayList<>();
					Combine.combine(0, 6, rx6, a1Arr);
					for (int i = 0; i < a1Arr.size(); i++) {
						int a1 = 0;
						String[] arrs = a1Arr.get(i).split(",");
						for (int j = 0; j < arrs.length; j++) {
							for (int k = 0; k < data.length; k++) {
								if (arrs[j].equals(data[k])) {
									a1++;
								}
							}
						}
						if (a1 == 5) {
							count15++;
						}
					}
					money15 = count15 * oMoney * Double.parseDouble(pv15[0]);
				}

				// 任选7
				if (rx7.length != 0 && !"".equals(rx7[0])) {
					ArrayList<String> a1Arr = new ArrayList<>();
					Combine.combine(0, 7, rx7, a1Arr);
					for (int i = 0; i < a1Arr.size(); i++) {
						int a1 = 0;
						String[] arrs = a1Arr.get(i).split(",");
						for (int j = 0; j < arrs.length; j++) {
							for (int k = 0; k < data.length; k++) {
								if (arrs[j].equals(data[k])) {
									a1++;
								}
							}
						}
						if (a1 == 5) {
							count16++;
						}
					}
					money16 = count16 * oMoney * Double.parseDouble(pv16[0]);
				}

				// 任选8
				if (rx8.length != 0 && !"".equals(rx8[0])) {
					ArrayList<String> a1Arr = new ArrayList<>();
					Combine.combine(0, 8, rx8, a1Arr);
					for (int i = 0; i < a1Arr.size(); i++) {
						int a1 = 0;
						String[] arrs = a1Arr.get(i).split(",");
						for (int j = 0; j < arrs.length; j++) {
							for (int k = 0; k < data.length; k++) {
								if (arrs[j].equals(data[k])) {
									a1++;
								}
							}
						}
						if (a1 == 5) {
							count17++;
						}
					}
					money17 = count17 * oMoney * Double.parseDouble(pv17[0]);
				}
				break;
			case "xg6hc":
			case "5f6hc":
				String[] tma = order.getStr1().split(",");
				String[] tmb = order.getStr2().split(",");
				String[] tmsx = order.getStr3().split(",");
				String[] dxds = order.getStr4().split(",");
				String[] jqys = order.getStr5().split(",");
				String[] ts = order.getStr6().split(",");
				String[] ws = order.getStr7().split(",");
				String[] wx = order.getStr8().split(",");
				String[] zh2 = order.getStr9().split(",");
				String[] hs = order.getStr10().split(",");
				String[] dp = order.getStr11().split(",");
				String[] p2z2 = order.getStr12().split(",");
				String[] p3z3 = order.getStr13().split(",");
				String[] p3z2 = order.getStr14().split(",");
				String[] sxzt = order.getStr15().split(",");
				String[] wxzt = order.getStr16().split(",");
				String[] lxzt = order.getStr17().split(",");
				String[] pt1x = order.getStr18().split(",");
				String[] pt2x = order.getStr19().split(",");
				String[] pt3x = order.getStr20().split(",");
				String[] pt4x = order.getStr21().split(",");
				String[] pt1w = order.getStr22().split(",");
				String[] pt2w = order.getStr23().split(",");
				String[] pt3w = order.getStr24().split(",");
				String[] pt4w = order.getStr25().split(",");
				String[] wbz = order.getStr26().split(",");
				String[] lbz = order.getStr27().split(",");
				String[] qbz = order.getStr28().split(",");
				String[] bbz = order.getStr29().split(",");
				String[] jbz = order.getStr30().split(",");
				String[] shbz = order.getStr31().split(",");
				String[] sh1bz = order.getStr32().split(",");
				String[] sh2bz = order.getStr33().split(",");
				String[] sh3bz = order.getStr34().split(",");
				String[] sh4bz = order.getStr35().split(",");
				String[] sh5bz = order.getStr36().split(",");
				String[] zx = order.getStr37().split(",");
				String[] sb = order.getStr38().split(",");
				String[] bb = order.getStr39().split(",");
				String[] bbb = order.getStr40().split(",");

				/** tmab */
				String[] tm = { "01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12", "13", "14",
						"15", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25", "26", "27", "28", "29", "30",
						"31", "32", "33", "34", "35", "36", "37", "38", "39", "40", "41", "42", "43", "44", "45", "46",
						"47", "48", "49" };
				/** 生肖 1 */
				CheckOrder orc = new CheckOrder();
				Map<String, Object> map = orc.attribute1();
				String[] sx1 = (String[]) map.get("attr");
				String[][] sx2 = (String[][]) map.get("content");
				/** 总和合数 */
				int dh = d[0] + d[1] + d[2] + d[3] + d[4] + d[5] + d[6];
				/** 家禽野兽 */
				String jiax = "牛马羊鸡狗猪";
				String yex = "鼠虎兔龙蛇猴";
				String tianx = "牛兔龙马侯猪";
				String dix = "鼠虎蛇羊鸡狗";
				String[][][] jqyss = new String[4][6][5];
				List<Integer> idss = new ArrayList<Integer>();
				String[] sxss = { "鼠", "牛", "虎", "兔", "龙", "蛇", "马", "羊", "猴", "鸡", "狗", "猪" };
				for (int i10 = 0; i10 < sxss.length; i10++) {
					for (int j10 = 0; j10 < sx1.length; j10++) {
						if (sxss[i10].equals(sx1[j10])) {
							idss.add(j10);
						}
					}
				}

				String[] jqysss = { "家肖", "野肖", "天肖", "地肖" };
				/** jiax */
				jqyss[0][0] = sx2[idss.get(1)];
				jqyss[0][1] = sx2[idss.get(6)];
				jqyss[0][2] = sx2[idss.get(7)];
				jqyss[0][3] = sx2[idss.get(9)];
				jqyss[0][4] = sx2[idss.get(10)];
				jqyss[0][5] = sx2[idss.get(11)];
				/** yex */
				jqyss[1][0] = sx2[idss.get(0)];
				jqyss[1][1] = sx2[idss.get(2)];
				jqyss[1][2] = sx2[idss.get(3)];
				jqyss[1][3] = sx2[idss.get(4)];
				jqyss[1][4] = sx2[idss.get(5)];
				jqyss[1][5] = sx2[idss.get(8)];
				/** tianx */
				jqyss[2][0] = sx2[idss.get(1)];
				jqyss[2][1] = sx2[idss.get(3)];
				jqyss[2][2] = sx2[idss.get(4)];
				jqyss[2][3] = sx2[idss.get(6)];
				jqyss[2][4] = sx2[idss.get(8)];
				jqyss[2][5] = sx2[idss.get(11)];
				/** dix */
				jqyss[3][0] = sx2[idss.get(0)];
				jqyss[3][1] = sx2[idss.get(2)];
				jqyss[3][2] = sx2[idss.get(5)];
				jqyss[3][3] = sx2[idss.get(7)];
				jqyss[3][4] = sx2[idss.get(9)];
				jqyss[3][5] = sx2[idss.get(10)];
				/** 头数 */
				String[] t1 = { "0头", "1头", "2头", "3头", "4头" };
				String[][] t2 = { { "01", "02", "03", "04", "05", "06", "07", "08", "09" },
						{ "10", "11", "12", "13", "14", "15", "16", "17", "18", "19" },
						{ "20", "21", "22", "23", "24", "25", "26", "27", "28", "29" },
						{ "30", "31", "32", "33", "34", "35", "36", "37", "38", "39" },
						{ "40", "41", "42", "43", "44", "45", "46", "47", "48", "49" } };
				/** 尾数 */
				String[] w1 = { "0尾", "1尾", "2尾", "3尾", "4尾", "5尾", "6尾", "7尾", "8尾", "9尾" };
				String[][] w2 = { { "10", "20", "30", "40", "50" }, { "01", "11", "21", "31", "41" },
						{ "02", "12", "22", "32", "42" }, { "03", "13", "23", "33", "43" },
						{ "04", "14", "24", "34", "44" }, { "05", "15", "25", "35", "45" },
						{ "06", "16", "26", "36", "46" }, { "07", "17", "27", "37", "47" },
						{ "08", "18", "28", "38", "48" }, { "09", "19", "29", "39", "49" } };
				String[] w3 = { "0", "1", "2", "3", "4", "5", "6", "7", "8", "9" };
				/** 五行 */
				Map<String, Object> maps = orc.attribute2();
				String[] x1 = (String[]) maps.get("attrs");
				String[][] x2 = (String[][]) maps.get("contents");
				/** 合数 */
				int hss = (d[6] % 100) / 10 + d[6] % 10;
				/** 总肖 */
				String[] z1 = { "2肖", "3肖", "4肖", "5肖", "6肖", "7肖" };
				/** 波色-红波-蓝波-绿波 */
				String[] hob = { "01", "02", "07", "08", "12", "13", "18", "19", "23", "24", "29", "30", "34", "35",
						"40", "45", "46" };
				String[] lab = { "03", "04", "09", "10", "14", "15", "20", "25", "26", "31", "36", "37", "41", "42",
						"47", "48" };
				String[] lvb = { "05", "06", "11", "16", "17", "21", "22", "27", "28", "32", "33", "38", "39", "43",
						"44", "49" };
				String[] b1 = { "红", "蓝", "绿" };
				String[][] b2 = {
						{ "01", "02", "07", "08", "12", "13", "18", "19", "23", "24", "29", "30", "34", "35", "40",
								"45", "46" },
						{ "03", "04", "09", "10", "14", "15", "20", "25", "26", "31", "36", "37", "41", "42", "47",
								"48" },
						{ "05", "06", "11", "16", "17", "21", "22", "27", "28", "32", "33", "38", "39", "43", "44",
								"49" } };
				/** 半波 */
				String[] bb1 = { "红大", "红小", "红单", "红双", "蓝大", "蓝小", "蓝单", "蓝双", "绿大", "绿小", "绿单", "绿双" };
				/** 半半波 */
				String[] bbb1 = { "红大单", "红大双", "红小单", "红小双", "蓝大单", "蓝大双", "蓝小单", "蓝小双", "绿大单", "绿大双", "绿小单", "绿小双" };
				// 特码A
				if (tma.length != 0 && !tma[0].equals("")) {
					int a = 0;
					for (int i = 0; i < tma.length; i++) {
						for (int j = 0; j < tm.length; j++) {
							if (tma[i].equals(data[6]) && tm[j].equals(tma[i]) && data[6].equals(tm[j])) {
								if (d[6] == 49) {
									list.add("特码A");
								} else {
									count1 = 1;
									a = j;
								}
							}
						}
					}
					money1 = count1 * oMoney * Double.parseDouble(pv1[a]);
				}
				// 特码B
				if (tmb.length != 0 && !tmb[0].equals("")) {
					int a = 0;
					for (int i = 0; i < tmb.length; i++) {
						for (int j = 0; j < tm.length; j++) {
							if (tmb[i].equals(data[6]) && tm[j].equals(tmb[i]) && data[6].equals(tm[j])) {
								if (d[6] == 49) {
									list.add("特码B");
								} else {
									count2 = 1;
									a = j;
								}
							}
						}
					}
					money2 = count2 * oMoney * Double.parseDouble(pv2[a]);
					List<GcRebate> gcRebate = orderService.findAllGcRebate(game);
					if (gcRebate.size() > 0) {
						double tmb_money = order.getCount2() * order.getLottermoney();
						Order ors = new Order();
						ors.setOrdernum(order.getOrdernum());
						double gc_rebate = 0.00;
						for (GcRebate gc : gcRebate) {
							if (gc.getGc_state() == 1) {
									if (gc.getGc_rebate() > gc_rebate) {
										gc_rebate = gc.getGc_rebate();
									}
								}
							}
						double rebate_money = tmb_money * gc_rebate;
						ors.setAcount(rebate_money);
						if(game.equals("xg6hc")) {
							ors.setCname1("香港六合彩");
						}else {
							ors.setCname1("五分六合彩");
						}
						// 反水金额
						orderService.GcBettingRebate(user, ors);
					}
				}

				// 特码生肖
				if (tmsx.length != 0 && !tmsx[0].equals("")) {
					int a = 0;
					for (int i = 0; i < sx1.length; i++) {
						for (int j = 0; j < sx2[i].length; j++) {
							for (int k = 0; k < tmsx.length; k++) {
								if (sx1[i].equals(tmsx[k]) && sx2[i][j].equals(data[6])) {
									count3 = 1;
									a = i;
								}
							}
						}
					}
					money3 = count3 * oMoney * Double.parseDouble(pv3[a]);
				}
				// 大小单双
				if (dxds.length != 0 && !dxds[0].equals("")) {
					int a1 = 0;
					int a2 = 0;
					int a3 = 0;
					int a4 = 0;
					for (int i = 0; i < dxds.length; i++) {
						if (d[6] % 2 != 0 && dxds[i].equals("单")) {
							a1++;
						}
						if (d[6] % 2 == 0 && dxds[i].equals("双")) {
							a2++;
						}
						if (d[6] > 24 && dxds[i].equals("大")) {
							a3++;
						}
						if (d[6] < 25 && dxds[i].equals("小")) {
							a4++;
						}
						if (d[6] == 49) {
							list.add("大小单双");
						}
					}
					count4 = a1 + a2 + a3 + a4;
					money4 = a1 * oMoney * Double.parseDouble(pv4[0]) + a2 * oMoney * Double.parseDouble(pv4[1])
							+ a3 * oMoney * Double.parseDouble(pv4[2]) + a4 * oMoney * Double.parseDouble(pv4[3]);
				}
				// 家禽野兽
				if (jqys.length != 0 && !jqys[0].equals("")) {
					int a1 = 0;
					int a2 = 0;
					int a3 = 0;
					int a4 = 0;

					for (int i = 0; i < jqyss.length; i++) {
						for (int j = 0; j < jqyss[i].length; j++) {
							for (int k = 0; k < jqyss[i][j].length; k++) {
								for (int m = 0; m < jqys.length; m++) {
									if (d[6] == 49) {
										list.add("家禽野兽");
									} else {
										if (jqyss[i][j][k].equals(data[6]) && jqysss[i].equals(jqys[m])
												&& jqys[m].equals("家肖")) {
											a1 = 1;
										}
										if (jqyss[i][j][k].equals(data[6]) && jqysss[i].equals(jqys[m])
												&& jqys[m].equals("野肖")) {
											a2 = 1;
										}
										if (jqyss[i][j][k].equals(data[6]) && jqysss[i].equals(jqys[m])
												&& jqys[m].equals("天肖")) {
											a3 = 1;
										}
										if (jqyss[i][j][k].equals(data[6]) && jqysss[i].equals(jqys[m])
												&& jqys[m].equals("地肖")) {
											a4 = 1;
										}
									}
								}
							}
						}
					}
					count5 = a1 + a2 + a3 + a4;
					money5 = a1 * oMoney * Double.parseDouble(pv5[0]) + a2 * oMoney * Double.parseDouble(pv5[1])
							+ a3 * oMoney * Double.parseDouble(pv5[2]) + a4 * oMoney * Double.parseDouble(pv5[3]);
				}
				// 头数
				if (ts.length != 0 && !ts[0].equals("")) {
					int b = 0;
					for (int i = 0; i < t2.length; i++) {
						for (int j = 0; j < t2[i].length; j++) {
							for (int k = 0; k < t1.length; k++) {
								for (int m = 0; m < ts.length; m++) {
									if (t2[i][j].equals(data[6]) && t1[k].equals(ts[m]) && (t1[i].equals(ts[m]))) {
										b = i;
										count6++;
									}
								}
							}
						}
					}
					money6 = count6 * oMoney * Double.parseDouble(pv6[b]);
				}
				// 尾数
				if (ws.length != 0 && !ws[0].equals("")) {
					int a1 = 0;
					int a2 = 0;
					int a3 = 0;
					int a4 = 0;
					int a5 = 0;
					int g = 0;
					for (int i = 0; i < w2.length; i++) {
						for (int j = 0; j < w2[i].length; j++) {
							for (int k = 0; k < w1.length; k++) {
								for (int m = 0; m < ws.length; m++) {
									if (w2[i][j].equals(data[6])) {
										if (d[6] == 49) {
											list.add("尾数");
										} else {
											if (w1[k].equals(ws[m])) {
												g = i;
												a1 = 1;
											}
											if (ws[m].equals("大")) {
												if (d[6] % 10 > 4 && d[6] % 10 < 10) {
													a2 = 1;
												}
											}
											if (ws[m].equals("小")) {
												if (d[6] % 10 < 5) {
													a3 = 1;
												}
											}
											if (ws[m].equals("单")) {
												if (d[6] % 2 != 0) {
													a4 = 1;
												}
											}
											if (ws[m].equals("双")) {
												if (d[6] % 2 == 0) {
													a5 = 1;
												}
											}
										}
									}
								}
							}
						}
					}
					count7 = a1 + a2 + a3 + a4 + a5;
					money7 = a1 * oMoney * Double.parseDouble(pv7[g]) + a2 * oMoney * Double.parseDouble(pv7[10])
							+ a3 * oMoney * Double.parseDouble(pv7[11]) + a4 * oMoney * Double.parseDouble(pv7[12])
							+ a5 * oMoney * Double.parseDouble(pv7[13]);
				}
				// 五行
				if (wx.length != 0 && !wx[0].equals("")) {
					int b = 0;
					for (int i = 0; i < x1.length; i++) {
						for (int j = 0; j < x2[i].length; j++) {
							for (int k = 0; k < wx.length; k++) {
								if (wx[k].equals(x1[i]) && x2[i][j].equals(data[6])) {
									count8 = 1;
									b = i;
								}
							}
						}
					}
					money8 = count8 * oMoney * Double.parseDouble(pv8[b]);
				}
				// 总和
				if (zh2.length != 0 && !zh2[0].equals("")) {
					int a1 = 0;
					int a2 = 0;
					int a3 = 0;
					int a4 = 0;
					for (int i = 0; i < zh2.length; i++) {
						if (zh2[i].equals("单")) {
							if (dh % 2 != 0) {
								a1 = 1;
							}
						}
						if (zh2[i].equals("双")) {
							if (dh % 2 == 0) {
								a2 = 1;
							}
						}
						if (zh2[i].equals("大")) {
							if (dh > 174) {
								a3 = 1;
							}
						}
						if (zh2[i].equals("小")) {
							if (dh < 175) {
								a4 = 1;
							}
						}
					}
					count9 = a1 + a2 + a3 + a4;
					money9 = a1 * oMoney * Double.parseDouble(pv9[0]) + a2 * oMoney * Double.parseDouble(pv9[1])
							+ a3 * oMoney * Double.parseDouble(pv9[2]) + a4 * oMoney * Double.parseDouble(pv9[3]);

				}
				// 合数
				if (hs.length != 0 && !hs[0].equals("")) {
					int a1 = 0;
					int a2 = 0;
					int a3 = 0;
					int a4 = 0;
					for (int i = 0; i < hs.length; i++) {
						if (hs[i].equals("单")) {
							if (hss % 2 != 0) {
								a1 = 1;
							}
						}
						if (hs[i].equals("双")) {
							if (hss % 2 == 0) {
								a2 = 1;
							}
						}
						if (hs[i].equals("大")) {
							if (hss > 6) {
								a3 = 1;
							}
						}
						if (hs[i].equals("小")) {
							if (hss < 7) {
								a4 = 1;
							}
						}
						if (d[6] == 49) {
							list.add("合数");
						}
					}
					count10 = a1 + a2 + a3 + a4;
					money10 = a1 * oMoney * Double.parseDouble(pv10[0]) + a2 * oMoney * Double.parseDouble(pv10[1])
							+ a3 * oMoney * Double.parseDouble(pv10[2]) + a4 * oMoney * Double.parseDouble(pv10[3]);
				}
				// 独平
				if (dp.length != 0 && !dp[0].equals("")) {
					int a = 0;
					for (int i = 0; i < dp.length; i++) {
						for (int j = 0; j < tm.length; j++) {
							for (int k = 0; k < data.length; k++) {
								if (dp[i].equals(data[k]) && tm[j].equals(dp[i])) {
									count11 = 1;
								}
							}
						}
					}
					money11 = count11 * oMoney * Double.parseDouble(pv11[0]);
				}
				// 平二中二
				if (p2z2.length != 0 && !p2z2[0].equals("")) {
					int a = 0;
					for (int i = 0; i < p2z2.length; i++) {
						for (int j = 0; j < data.length - 1; j++) {
							if (p2z2[i].equals(data[j])) {
								a++;
							}
						}
					}
					if (a > 1) {
						count12 = 1;
					}
					money12 = count12 * oMoney * Double.parseDouble(pv12[0]);
				}
				// 平三中三
				if (p3z3.length != 0 && !p3z3[0].equals("")) {
					int a = 0;
					for (int i = 0; i < p3z3.length; i++) {
						for (int j = 0; j < data.length - 1; j++) {
							if (p3z3[i].equals(data[j])) {
								a++;
							}
						}
					}
					if (a > 2) {
						count13 = 1;
					}
					money13 = count13 * oMoney * Double.parseDouble(pv13[0]);
				}
				// 平三中二
				if (p3z2.length != 0 && !p3z2[0].equals("")) {
					int a = 0;
					for (int i = 0; i < p3z2.length; i++) {
						for (int j = 0; j < data.length - 1; j++) {
							if (p3z2[i].equals(data[j])) {
								a++;
							}
						}
					}
					if (a > 1) {
						count14 = 1;
					}
					money14 = count14 * oMoney * Double.parseDouble(pv14[0]);
				}
				// 四肖中特
				if (sxzt.length != 0 && !sxzt[0].equals("")) {
					int a = 0;
					for (int i = 0; i < sx1.length; i++) {
						for (int j = 0; j < sx2[i].length; j++) {
							for (int k = 0; k < sxzt.length; k++) {
								if (sx2[i][j].equals(data[6]) && sxzt[k].equals(sx1[i])) {
									count15 = 1;
									a = i;
								}
							}
						}
					}
					money15 = count15 * oMoney * Double.parseDouble(pv15[a]);
				}
				// 五肖中特
				if (wxzt.length != 0 && !wxzt[0].equals("")) {
					int a = 0;
					for (int i = 0; i < sx1.length; i++) {
						for (int j = 0; j < sx2[i].length; j++) {
							for (int k = 0; k < wxzt.length; k++) {
								if (sx2[i][j].equals(data[6]) && wxzt[k].equals(sx1[i])) {
									count16 = 1;
									a = i;
								}
							}
						}
					}
					money16 = count16 * oMoney * Double.parseDouble(pv16[a]);
				}
				// 六肖中特
				if (lxzt.length != 0 && !lxzt[0].equals("")) {
					int a = 0;
					for (int i = 0; i < sx1.length; i++) {
						for (int j = 0; j < sx2[i].length; j++) {
							for (int k = 0; k < lxzt.length; k++) {
								if (sx2[i][j].equals(data[6]) && lxzt[k].equals(sx1[i])) {
									count17 = 1;
									a = i;
								}
							}
						}
					}
					money17 = count17 * oMoney * Double.parseDouble(pv17[a]);
				}
				// 平特1肖
				if (pt1x.length != 0 && !pt1x[0].equals("")) {
					int a = 0;
					List<Integer> list1 = new ArrayList<Integer>();
					List<Double> list2 = new ArrayList<Double>();
					for (int i = 0; i < sx1.length; i++) {
						for (int j = 0; j < sx2[i].length; j++) {
							for (int k = 0; k < pt1x.length; k++) {
								for (int n = 0; n < data.length; n++) {
									if (sx2[i][j].equals(data[n]) && pt1x[k].equals(sx1[i])) {// i就是data中对应的生肖
										count18 = 1;
										a = i;
										list1.add(a);
									}
								}
							}
						}
					}
					for (int i = 0; i < list1.size() - 1; i++) {
						for (int j = list1.size() - 1; j > i; j--) {
							if (list1.get(j).equals(list1.get(i))) {
								list1.remove(j);
							}
						}
					}
					for (int i = 0; i < list1.size(); i++) {
						Double a1 = Double.parseDouble(pv18[list1.get(i)]);
						list2.add(a1);
					}
					try {
						Double a3 = Collections.min(list2);// 获取最小值 本命肖
						Double a4 = Collections.max(list2);// 获取最大值 中奖的 二选1
						if (list2.size() > 1) {
							if (a3 != null) {
								money18 = count18 * oMoney * a3;
							} else {
								money18 = count18 * oMoney * a4;
							}
						} else {
							money18 = count18 * oMoney * Double.parseDouble(pv18[list1.get(0)]);
						}
					} catch (Exception e) {
						money18 = count18 * oMoney * Double.parseDouble(pv18[list1.get(0)]);
					}
				}
				// 平特2肖
				if (pt2x.length != 0 && !pt2x[0].equals("")) {
					List<Integer> list1 = new ArrayList<Integer>();
					List<Double> list2 = new ArrayList<Double>();
					int a = 0;
					for (int i = 0; i < sx1.length; i++) {
						for (int j = 0; j < sx2[i].length; j++) {
							for (int k = 0; k < pt2x.length; k++) {
								for (int n = 0; n < data.length; n++) {
									if (sx2[i][j].equals(data[n]) && pt2x[k].equals(sx1[i])) {
										list1.add(a);
										a = i;
									}
								}
							}
						}
					}
					for (int i = 0; i < list1.size() - 1; i++) {
						for (int j = list1.size() - 1; j > i; j--) {
							if (list1.get(j).equals(list1.get(i))) {
								list1.remove(j);
							}
						}
					}
					if (list1.size() > 1) {
						count19 = 1;
					}
					for (int i = 0; i < list1.size(); i++) {
						Double a1 = Double.parseDouble(pv19[list1.get(i)]);
						list2.add(a1);
					}
					try {
						Double a3 = Collections.min(list2);
						Double a4 = Collections.max(list2);
						if (list2.size() > 1) {
							if (a3 != null) {
								money19 = count19 * oMoney * a3;
							} else {
								money19 = count19 * oMoney * a4;
							}
						} else {
							money19 = count19 * oMoney * Double.parseDouble(pv19[list1.get(0)]);
						}
					} catch (Exception e) {
						money19 = count19 * oMoney * Double.parseDouble(pv19[list1.get(0)]);
					}
				}
				// 平特3肖
				if (pt3x.length != 0 && !pt3x[0].equals("")) {
					List<Integer> list1 = new ArrayList<Integer>();
					List<Double> list2 = new ArrayList<Double>();
					int a = 0;
					for (int i = 0; i < sx1.length; i++) {
						for (int j = 0; j < sx2[i].length; j++) {
							for (int k = 0; k < pt3x.length; k++) {
								for (int n = 0; n < data.length; n++) {
									if (sx2[i][j].equals(data[n]) && pt3x[k].equals(sx1[i])) {
										a = i;
										list1.add(a);
									}
								}
							}
						}
					}
					for (int i = 0; i < list1.size() - 1; i++) {
						for (int j = list1.size() - 1; j > i; j--) {
							if (list1.get(j).equals(list1.get(i))) {
								list1.remove(j);
							}
						}
					}
					if (list1.size() > 2) {
						count20 = 1;
					}
					for (int i = 0; i < list1.size(); i++) {
						Double a1 = Double.parseDouble(pv20[list1.get(i)]);
						list2.add(a1);
					}
					try {
						Double a3 = Collections.min(list2);
						Double a4 = Collections.max(list2);
						if (list2.size() > 1) {
							if (a3 != null) {
								money20 = count20 * oMoney * a3;
							} else {
								money20 = count20 * oMoney * a4;
							}
						} else {
							money20 = count20 * oMoney * Double.parseDouble(pv20[list1.get(0)]);
						}
					} catch (Exception e) {
						money20 = count20 * oMoney * Double.parseDouble(pv20[list1.get(0)]);
					}
				}
				// 平特4肖
				if (pt4x.length != 0 && !pt4x[0].equals("")) {

					List<Integer> list1 = new ArrayList<Integer>();
					List<Double> list2 = new ArrayList<Double>();
					int a = 0;
					for (int i = 0; i < sx1.length; i++) {
						for (int j = 0; j < sx2[i].length; j++) {
							for (int k = 0; k < pt4x.length; k++) {
								for (int n = 0; n < data.length; n++) {
									if (sx2[i][j].equals(data[n]) && pt4x[k].equals(sx1[i])) {
										a = i;
										list1.add(a);
									}
								}
							}
						}
					}
					for (int i = 0; i < list1.size() - 1; i++) {
						for (int j = list1.size() - 1; j > i; j--) {
							if (list1.get(j).equals(list1.get(i))) {
								list1.remove(j);
							}
						}
					}
					if (list1.size() > 3) {
						count21 = 1;
					}
					for (int i = 0; i < list1.size(); i++) {
						Double a1 = Double.parseDouble(pv21[list1.get(i)]);
						list2.add(a1);
					}
					try {
						Double a3 = Collections.min(list2);
						Double a4 = Collections.max(list2);
						if (list2.size() > 1) {
							if (a3 != null) {
								money21 = count21 * oMoney * a3;
							} else {
								money21 = count21 * oMoney * a4;
							}
						} else {
							money21 = count21 * oMoney * Double.parseDouble(pv21[list1.get(0)]);
						}
					} catch (Exception e) {
						money21 = count21 * oMoney * Double.parseDouble(pv21[list1.get(0)]);
					}
				}
				// 平特1尾
				if (pt1w.length != 0 && !pt1w[0].equals("")) {
					List<Integer> list1 = new ArrayList<Integer>();
					List<Double> list2 = new ArrayList<Double>();
					int a = 0;
					for (int i = 0; i < w3.length; i++) {
						for (int j = 0; j < w2[i].length; j++) {
							for (int k = 0; k < pt1w.length; k++) {
								for (int n = 0; n < data.length; n++) {
									if (w2[i][j].equals(data[n]) && pt1w[k].equals(w3[i])) {
										count22 = 1;
										a = i;
										list1.add(a);
									}
								}
							}
						}
					}
					for (int i = 0; i < list1.size() - 1; i++) {
						for (int j = list1.size() - 1; j > i; j--) {
							if (list1.get(j).equals(list1.get(i))) {
								list1.remove(j);
							}
						}
					}
					for (int i = 0; i < list1.size(); i++) {
						Double a1 = Double.parseDouble(pv22[list1.get(i)]);
						list2.add(a1);
					}
					try {
						Double a3 = Collections.max(list2);
						Double a4 = Collections.min(list2);
						if (list2.size() > 1) {
							if (a3 != null) {
								money22 = count22 * oMoney * a3;
							} else {
								money22 = count22 * oMoney * a4;
							}
						} else {
							money22 = count22 * oMoney * Double.parseDouble(pv22[list1.get(0)]);
						}
					} catch (Exception e) {
						money22 = count22 * oMoney * Double.parseDouble(pv22[list1.get(0)]);
					}
				}
				// 平特2尾
				if (pt2w.length != 0 && !pt2w[0].equals("")) {
					List<Integer> list1 = new ArrayList<Integer>();
					List<Double> list2 = new ArrayList<Double>();
					int a = 0;
					for (int i = 0; i < w3.length; i++) {
						for (int j = 0; j < w2[i].length; j++) {
							for (int k = 0; k < pt2w.length; k++) {
								for (int n = 0; n < data.length; n++) {
									if (w2[i][j].equals(data[n]) && pt2w[k].equals(w3[i])) {
										a = i;
										list1.add(a);
									}
								}
							}
						}
					}
					for (int i = 0; i < list1.size() - 1; i++) {
						for (int j = list1.size() - 1; j > i; j--) {
							if (list1.get(j).equals(list1.get(i))) {
								list1.remove(j);
							}
						}
					}
					if (list1.size() > 1) {
						count23 = 1;
					}
					for (int i = 0; i < list1.size(); i++) {
						Double a1 = Double.parseDouble(pv23[list1.get(i)]);
						list2.add(a1);
					}
					try {
						Double a3 = Collections.max(list2);
						Double a4 = Collections.min(list2);
						if (list2.size() > 1) {
							if (a3 != null) {
								money23 = count23 * oMoney * a3;
							} else {
								money23 = count23 * oMoney * a4;
							}
						} else {
							money23 = count23 * oMoney * Double.parseDouble(pv23[list1.get(0)]);
						}
					} catch (Exception e) {
						money23 = count23 * oMoney * Double.parseDouble(pv23[list1.get(0)]);
					}
				}
				// 平特3尾
				if (pt3w.length != 0 && !pt3w[0].equals("")) {
					List<Integer> list1 = new ArrayList<Integer>();
					List<Double> list2 = new ArrayList<Double>();
					int a = 0;
					for (int i = 0; i < w3.length; i++) {
						for (int j = 0; j < w2[i].length; j++) {
							for (int k = 0; k < pt3w.length; k++) {
								for (int n = 0; n < data.length; n++) {
									if (w2[i][j].equals(data[n]) && pt3w[k].equals(w3[i])) {
										a = i;
										list1.add(a);
									}
								}
							}
						}
					}
					for (int i = 0; i < list1.size() - 1; i++) {
						for (int j = list1.size() - 1; j > i; j--) {
							if (list1.get(j).equals(list1.get(i))) {
								list1.remove(j);
							}
						}
					}
					if (list1.size() > 2) {
						count24 = 1;
					}
					for (int i = 0; i < list1.size(); i++) {
						Double a1 = Double.parseDouble(pv24[list1.get(i)]);
						list2.add(a1);
					}
					try {
						Double a3 = Collections.max(list2);
						Double a4 = Collections.min(list2);
						if (list2.size() > 1) {
							if (a3 != null) {
								money24 = count24 * oMoney * a3;
							} else {
								money24 = count24 * oMoney * a4;
							}
						} else {
							money24 = count24 * oMoney * Double.parseDouble(pv24[list1.get(0)]);
						}
					} catch (Exception e) {
						money24 = count24 * oMoney * Double.parseDouble(pv24[list1.get(0)]);
					}
				}
				// 平特4尾
				if (pt4w.length != 0 && !pt4w[0].equals("")) {
					List<Integer> list1 = new ArrayList<Integer>();
					List<Double> list2 = new ArrayList<Double>();
					int a = 0;
					for (int i = 0; i < w3.length; i++) {
						for (int j = 0; j < w2[i].length; j++) {
							for (int k = 0; k < pt4w.length; k++) {
								for (int n = 0; n < data.length; n++) {
									if (w2[i][j].equals(data[n]) && pt4w[k].equals(w3[i])) {
										a = i;
										list1.add(a);
									}
								}
							}
						}
					}
					for (int i = 0; i < list1.size() - 1; i++) {
						for (int j = list1.size() - 1; j > i; j--) {
							if (list1.get(j).equals(list1.get(i))) {
								list1.remove(j);
							}
						}
					}
					if (list1.size() > 3) {
						count25 = 1;
					}
					for (int i = 0; i < list1.size(); i++) {
						Double a1 = Double.parseDouble(pv24[list1.get(i)]);
						list2.add(a1);
					}
					try {
						Double a3 = Collections.max(list2);
						Double a4 = Collections.min(list2);
						if (list2.size() > 1) {
							if (a3 != null) {
								money25 = count25 * oMoney * a3;
							} else {
								money25 = count25 * oMoney * a4;
							}
						} else {
							money25 = count25 * oMoney * Double.parseDouble(pv25[list1.get(0)]);
						}
					} catch (Exception e) {
						money25 = count25 * oMoney * Double.parseDouble(pv25[list1.get(0)]);
					}
				}
				// 五不中
				if (wbz.length != 0 && !wbz[0].equals("")) {
					int a = 0;
					for (int i = 0; i < wbz.length; i++) {
						for (int j = 0; j < data.length; j++) {
							if (wbz[i].equals(data[j])) {
								a++;
							}
						}
					}
					if (a == 0) {
						count26 = 1;
					}
					money26 = count26 * oMoney * Double.parseDouble(pv26[0]);
				}
				// 六不中
				if (lbz.length != 0 && !lbz[0].equals("")) {
					int a = 0;
					for (int i = 0; i < lbz.length; i++) {
						for (int j = 0; j < data.length; j++) {
							if (lbz[i].equals(data[j])) {
								a++;
							}
						}
					}
					if (a == 0) {
						count27 = 1;
					} else {
						count27 = 0;
					}
					money27 = count27 * oMoney * Double.parseDouble(pv27[0]);
				}
				// 七不中
				if (qbz.length != 0 && !qbz[0].equals("")) {
					int a = 0;
					for (int i = 0; i < qbz.length; i++) {
						for (int j = 0; j < data.length; j++) {
							if (qbz[i].equals(data[j])) {
								a++;
							}
						}
					}
					if (a == 0) {
						count28 = 1;
					} else {
						count28 = 0;
					}
					money28 = count28 * oMoney * Double.parseDouble(pv28[0]);
				}
				// 八不中
				if (bbz.length != 0 && !bbz[0].equals("")) {
					int a = 0;
					for (int i = 0; i < bbz.length; i++) {
						for (int j = 0; j < data.length; j++) {
							if (bbz[i].equals(data[j])) {
								a++;
							}
						}
					}
					if (a == 0) {
						count29 = 1;
					} else {
						count29 = 0;
					}
					money29 = count29 * oMoney * Double.parseDouble(pv29[0]);
				}
				// 九不中
				if (jbz.length != 0 && !jbz[0].equals("")) {
					int a = 0;
					for (int i = 0; i < jbz.length; i++) {
						for (int j = 0; j < data.length; j++) {
							if (jbz[i].equals(data[j])) {
								a++;
							}
						}
					}
					if (a == 0) {
						count30 = 1;
					} else {
						count30 = 0;
					}
					money30 = count30 * oMoney * Double.parseDouble(pv30[0]);
				}
				// 十不中
				if (shbz.length != 0 && !shbz[0].equals("")) {
					int a = 0;
					for (int i = 0; i < shbz.length; i++) {
						for (int j = 0; j < data.length; j++) {
							if (shbz[i].equals(data[j])) {
								a++;
							}
						}
					}
					if (a == 0) {
						count31 = 1;
					} else {
						count31 = 0;
					}
					money31 = count31 * oMoney * Double.parseDouble(pv31[0]);
				}
				// 十一不中
				if (sh1bz.length != 0 && !sh1bz[0].equals("")) {
					int a = 0;
					for (int i = 0; i < sh1bz.length; i++) {
						for (int j = 0; j < data.length; j++) {
							if (sh1bz[i].equals(data[j])) {
								a++;
							}
						}
					}
					if (a == 0) {
						count32 = 1;
					} else {
						count32 = 0;
					}
					money32 = count32 * oMoney * Double.parseDouble(pv32[0]);
				}
				// 十二不中
				if (sh2bz.length != 0 && !sh2bz[0].equals("")) {
					int a = 0;
					for (int i = 0; i < sh2bz.length; i++) {
						for (int j = 0; j < data.length; j++) {
							if (sh2bz[i].equals(data[j])) {
								a++;
							}
						}
					}
					if (a == 0) {
						count33 = 1;
					} else {
						count33 = 0;
					}
					money33 = count33 * oMoney * Double.parseDouble(pv33[0]);
				}
				// 十三不中
				if (sh3bz.length != 0 && !sh3bz[0].equals("")) {
					int a = 0;
					for (int i = 0; i < sh3bz.length; i++) {
						for (int j = 0; j < data.length; j++) {
							if (sh3bz[i].equals(data[j])) {
								a++;
							}
						}
					}
					if (a == 0) {
						count34 = 1;
					} else {
						count34 = 0;
					}
					money34 = count34 * oMoney * Double.parseDouble(pv34[0]);
				}
				// 十四不中
				if (sh4bz.length != 0 && !sh4bz[0].equals("")) {
					int a = 0;
					for (int i = 0; i < sh4bz.length; i++) {
						for (int j = 0; j < data.length; j++) {
							if (sh4bz[i].equals(data[j])) {
								a++;
							}
						}
					}
					if (a == 0) {
						count35 = 1;
					} else {
						count35 = 0;
					}
					money35 = count35 * oMoney * Double.parseDouble(pv35[0]);
				}
				// 十五不中
				if (sh5bz.length != 0 && !sh5bz[0].equals("")) {
					int a = 0;
					for (int i = 0; i < sh5bz.length; i++) {
						for (int j = 0; j < data.length; j++) {
							if (sh5bz[i].equals(data[j])) {
								a++;
							}
						}
					}
					if (a == 0) {
						count36 = 1;
					} else {
						count36 = 0;
					}
					money36 = count36 * oMoney * Double.parseDouble(pv36[0]);
				}
				// 总肖
				if (zx.length != 0 && !zx[0].equals("")) {
					List<Integer> list1 = new ArrayList<Integer>();
					int a = 0;
					int b = 0;
					int c = 0;
					int e = 0;
					for (int i = 0; i < sx1.length; i++) {
						for (int j = 0; j < sx2[i].length; j++) {
							for (int n = 0; n < data.length; n++) {
								if (sx2[i][j].equals(data[n])) {
									a = i;
									list1.add(a);
								}
							}
						}
					}
					for (int i = 0; i < list1.size() - 1; i++) {
						for (int j = list1.size() - 1; j > i; j--) {
							if (list1.get(j).equals(list1.get(i))) {
								list1.remove(j);
							}
						}
					}
					if (list1.size() > 1) {
						for (int i = 0; i < z1.length; i++) {
							for (int k = 0; k < zx.length; k++) {
								if (z1[i].contains(list1.size() + "") && zx[k].contains(list1.size() + "")) {
									a = i;
									b = 1;
								}
							}
						}
					}
					for (int i = 0; i < zx.length; i++) {
						if ((list1.size() % 2 != 0) && (zx[i].equals("单"))) {
							c = 1;
						} else if ((list1.size() % 2 == 0) && (zx[i].equals("双"))) {
							e = 1;
						}
					}
					count37 = b + c + e;
					money37 = b * oMoney * Double.parseDouble(pv37[a]) + c * oMoney * Double.parseDouble(pv37[6])
							+ e * oMoney * Double.parseDouble(pv37[7]);
				}
				// 色波
				if (sb.length != 0 && !sb[0].equals("")) {
					int a = 0;
					for (int i = 0; i < b1.length; i++) {
						for (int j = 0; j < b2[i].length; j++) {
							for (int m = 0; m < sb.length; m++) {
								if (b2[i][j].equals(data[6]) && sb[m].contains(b1[i])) {
									count38 = 1;
									a = i;
								}
							}
						}
					}
					money38 = count38 * oMoney * Double.parseDouble(pv38[a]);
				}
				// 半波
				if (bb.length != 0 && !bb[0].equals("")) {
					List<Integer> list1 = new ArrayList<Integer>();
					int a = 0;
					int b = 0;
					int c = 0;
					int e = 0;
					for (int i = 0; i < b1.length; i++) {
						for (int j = 0; j < b2[i].length; j++) {
							if (b2[i][j].equals(data[6])) {
								a = i;
							}
						}
					}
					for (int i = 0; i < bb.length; i++) {
						for (int j = 0; j < bb1.length; j++) {
							if (bb[i].equals(bb1[j])) {
								if (bb[i].contains(b1[a])) {
									e = j;
									list1.add(e);
									if (d[6] > 24 && bb[i].contains("大")) {
										b = 1;
									}
									if (d[6] < 25 && bb[i].contains("小")) {
										b = 1;
									}
									if (d[6] % 2 != 0 && bb[i].contains("单")) {
										c = 1;
									}
									if (d[6] % 2 == 0 && bb[i].contains("双")) {
										c = 1;
									}
									if (d[6] == 49) {
										list.add("半波");
									}
								}
							}
						}
					}
					double m1 = 0.00;
					double m2 = 0.00;
					if (list1.size() > 0) {
						if (b != 0) {
							m1 = b * oMoney * Double.parseDouble(pv39[list1.get(0)]);
						} else {
							m1 = c * oMoney * Double.parseDouble(pv39[list1.get(0)]);
						}
					}

					if (list1.size() > 1) {
						if (b != 0) {
							m2 = b * oMoney * Double.parseDouble(pv39[list1.get(0 + 1)]);
						} else {
							m2 = c * oMoney * Double.parseDouble(pv39[list1.get(0 + 1)]);
						}
					}

					count39 = b + c;
					money39 = m2 + m1;
				}
				// 半半波
				if (bbb.length != 0 && !bbb[0].equals("")) {
					List<Integer> list1 = new ArrayList<Integer>();
					int a = 0;
					int e = 0;
					int c1 = 0;
					for (int i = 0; i < b1.length; i++) {
						for (int j = 0; j < b2[i].length; j++) {
							if (b2[i][j].equals(data[6])) {
								// 查看开奖号码的颜色
								a = i;
							}
						}
					}
					for (int i = 0; i < bbb.length; i++) {
						for (int j = 0; j < bb1.length; j++) {
							// 下注的匹配上半半波中的某个
							if (bbb[i].equals(bbb1[j])) {
								// 下注的包含了中奖的某一个颜色
								if (bbb[i].contains(b1[a])) {
									if (bbb[i].contains("大单")) {
										if (d[6] > 24 && d[6] % 2 != 0) {
											// e代表中奖的有 赔率中的哪几个
											e = j;
											list1.add(e);
											c1 = 1;
										}
									}
									if (bbb[i].contains("大双")) {
										if (d[6] > 24 && d[6] % 2 == 0) {
											e = j;
											list1.add(e);
											c1 = 1;
										}
									}
									if (bbb[i].contains("小单")) {
										if (d[6] < 25 && d[6] % 2 != 0) {
											e = j;
											list1.add(e);
											c1 = 1;
										}
									}
									if (bbb[i].contains("小双")) {
										if (d[6] < 25 && d[6] % 2 == 0) {
											e = j;
											list1.add(e);
											c1 = 1;
										}
									}
								}
							}
						}
					}
					count40 = c1;
					if (list1.size() > 0) {
						money40 = count40 * oMoney * Double.parseDouble(pv40[list1.get(0)]);
					} else {
						money40 = 0.00;
					}
				}
				break;
			case "bj28":
			case "xy28":
			case "jnd28":
				String [] tms1 = {"0","1","2","3","4","5","6","7","8","9","10","11","12","13","14","15","16","17","18","19","20",
						"21","22","23","24","25","26","27"}; 
				String[] hunhe = order.getStr1().split(",");
				String[] tms = order.getStr2().split(",");
				String[] tmbs = order.getStr3().split(",");
				String[] bs = order.getStr4().split(",");
				String[] bz = order.getStr5().split(",");
				int che = d[0] + d[1] + d[2];
				//混合
				if(hunhe.length!=0&&!"".equals(hunhe[0])) {              //TODO: K111
					int a1 =0;  
					int a2 =0;
					int a3 =0;
					int a4 =0;
					int a5 =0;
					int a6 =0;
					int a7 =0;
					int a8 =0;
					int a9 =0;
					int a10 =0;
					for(int i=0;i<hunhe.length;i++) {
						if("大".equals(hunhe[i])) {
							if(che>13) {
								a1 = 1;
							}
						}
						
						if("小".equals(hunhe[i])) {
							if(che<13) {
								a2 = 1;
							}
						}
						
						if("单".equals(hunhe[i])) {
							if(che % 2 != 0 ) {
								a3 = 1;
							}
						}
						
						if("双".equals(hunhe[i])) {
							if(che % 2 == 0 ) {
								a4 = 1;
							}
							
						}
						if("大单".equals(hunhe[i])) {
							if(che>13 && che % 2 != 0) {
								a5=1;
							}
							
						}
						if("大双".equals(hunhe[i])) {
							if(che>13 && che % 2 == 0) {
								a6=1;
							}
						}
						if("小单".equals(hunhe[i])) {
							if( che<13 && che % 2 != 0) {
								a7=1;
							}
						}
						if("小双".equals(hunhe[i])) {
							if(che<13 &&che % 2 == 0) {
								a8=1;
							}
						}
						if("极大".equals(hunhe[i])) {
							switch (che) {
							case 22:
							case 23:
							case 24:
							case 25:
							case 26:
							case 27:
								a9=1;
								break;
							}
						}
						if("极小".equals(hunhe[i])) {
							switch (che) {
							case 0:
							case 1:
							case 2:
							case 3:
							case 4:
							case 5:
								a10 = 1;
								break;
							}
						}
					}
					count1 = a1+a2+a3+a4+a5+a6+a7+a8+a9+a10;
					money1 = a1 * oMoney * Double.parseDouble(pv1[0])
							+  a2 * oMoney * Double.parseDouble(pv1[1])
							+  a3 * oMoney * Double.parseDouble(pv1[2])
							+  a4 * oMoney * Double.parseDouble(pv1[3])
							+  a5 * oMoney * Double.parseDouble(pv1[4])
							+  a6 * oMoney * Double.parseDouble(pv1[5])
							+  a7 * oMoney * Double.parseDouble(pv1[6])
							+  a8 * oMoney * Double.parseDouble(pv1[7])
							+  a9 * oMoney * Double.parseDouble(pv1[8])
							+  a10 * oMoney * Double.parseDouble(pv1[9]);
				}
				
				//特码
				if(tms.length!=0 && !"".equals(tms[0])) {
					int a1 = 0;
					int b = 0;
					for(int i=0;i<tms.length;i++) {
						for(int j=0;j<tms1.length;j++) {
							if(tms[i].equals(tms1[j])&&tms[i].equals(che+"")) {
								b = i;
								a1=1;
							}
						}
					}
					count2 = a1;
					money2 = a1 * oMoney * Double.parseDouble(pv2[b]);
				}
				
				//特码包三
				if(tmbs.length!=0 && !"".equals(tmbs[0])) {
					int a1 =0;
					int b =0;
					for(int i=0;i<tmbs.length;i++) {
						for(int j=0;j<tms1.length;j++) {
							if(tmbs[i].equals(tms1[j])&&tmbs[i].equals(che+"")) {
								b = i;
								a1=1;
							}
						}
					}
					count3 = a1;
					money3 = a1 * oMoney * Double.parseDouble(pv3[b]);
				}
				
				//波色
				String [][] bose = {{"3","6","9","12","15","18","21","24"},{"1","4","7","10","16","19","22","25"},{"2","5","8","11","17","20","23","26"}};//TODO: K3
				String[] bse = {"红波","绿波","蓝波"}; 
				if(bs.length!=0 && !"".equals(bs[0])) {
					int a1 = 0;
					int b = 0;
					for(int i=0;i<bse.length;i++) {
						for(int j=0;j<bose[i].length;j++) {
							for(int k =0;k<bs.length;k++) {
								if(bs[k].equals(bse[i])&&bose[i][j].equals(che+"")) {
									b = i;
									a1 = 1;
								}
							}
						}
					}
					count4 = a1;
					money4 = a1 * oMoney * Double.parseDouble(pv4[b]);
				}
				
				//豹子
				if(bz.length!=0 && !"".equals(bz[0])) {
					int a1 =0;
					if(d[0]==d[1]&&d[0]==d[2]&&d[1]==d[2]) {
						a1 = 1;
					}
					count5 =a1;
					money4 = a1 * oMoney * Double.parseDouble(pv5[0]);
				}
				break;
			}
			/** 计算中奖注数和金额 */
			count = count1 + count2 + count3 + count4 + count5 + count6 + count7 + count8 + count9 + count10 + count11
					+ count12 + count13 + count14 + count15 + count16 + count17 + count18 + count19 + count20 + count21
					+ count22 + count23 + count24 + count25 + count26 + count27 + count28 + count29 + count30 + count31
					+ count32 + count33 + count34 + count35 + count36 + count37 + count38 + count39 + count40;
			gMoney = money1 + money2 + money3 + money4 + money5 + money6 + money7 + money8 + money9 + money10 + money11
					+ money12 + money13 + money14 + money15 + money16 + money17 + money18 + money19 + money20 + money21
					+ money22 + money23 + money24 + money25 + money26 + money27 + money28 + money29 + money30 + money31
					+ money32 + money33 + money34 + money35 + money36 + money37 + money38 + money39 + money40;

			/** 修改中奖状态 */
			int state = 0;
			if (gMoney != 0.00) {
				/** 中奖 */
				state = 3;
			} else if (list.size() > 0) {
				/** 中奖和局 */
				state = 6;
			} else {
				/** 未中奖 */
				state = 2;
			}
			System.err.println("用户：" + order.getHuiyuanzh() + "在彩种：" + order.getCname() + "第" + order.getPeriod()
					+ "期,中了:" + count + "注 ,中奖:" + gMoney + "元");
			order.setMoney1(money1);
			order.setMoney2(money2);
			order.setMoney3(money3);
			order.setMoney4(money4);
			order.setMoney5(money5);
			order.setMoney6(money6);
			order.setMoney7(money7);
			order.setMoney8(money8);
			order.setMoney9(money9);
			order.setMoney10(money10);
			order.setMoney11(money11);
			order.setMoney12(money12);
			order.setMoney13(money13);
			order.setMoney14(money14);
			order.setMoney15(money15);
			order.setMoney16(money16);
			order.setMoney17(money17);
			order.setMoney18(money18);
			order.setMoney19(money19);
			order.setMoney20(money20);
			order.setMoney21(money21);
			order.setMoney22(money22);
			order.setMoney23(money23);
			order.setMoney24(money24);
			order.setMoney25(money25);
			order.setMoney26(money26);
			order.setMoney27(money27);
			order.setMoney28(money28);
			order.setMoney29(money29);
			order.setMoney30(money30);
			order.setMoney31(money31);
			order.setMoney32(money32);
			order.setMoney33(money33);
			order.setMoney34(money34);
			order.setMoney35(money35);
			order.setMoney36(money36);
			order.setMoney37(money37);
			order.setMoney38(money38);
			order.setMoney39(money39);
			order.setMoney40(money40);
			order.setLottertime(ss.format(new Date()));
			order.setState(state);
			order.setGoalmoney(gMoney);
			order.setLotternum(datas.getLotternumber());
			
			/**
			 * TODO: 和局 中奖
			 */
			DecimalFormat dec = new DecimalFormat("#0.00");
			double returnMoney = 0.00;
			String tcPlay = "";
			String reMoney = "";
			if (list.size() > 0) {
				for (String key : list) {
					switch (key) {
					case "特码A":
						returnMoney = order.getCount1() * oMoney;
						order.setAcount(returnMoney);
						order.setTcplay(key);
						orderService.returnCheckMoney(user, order);
						break;
					case "特码B":
						returnMoney = order.getCount2() * oMoney;
						order.setAcount(returnMoney);
						order.setTcplay(key);
						orderService.returnCheckMoney(user, order);
						break;
					case "大小单双":
						returnMoney = order.getCount4() * oMoney;
						order.setAcount(returnMoney);
						order.setTcplay(key);
						orderService.returnCheckMoney(user, order);
						break;
					case "家禽野兽":
						returnMoney = order.getCount5() * oMoney;
						order.setAcount(returnMoney);
						order.setTcplay(key);
						orderService.returnCheckMoney(user, order);
						break;
					case "尾数":
						returnMoney = order.getCount7() * oMoney;
						order.setAcount(returnMoney);
						order.setTcplay(key);
						orderService.returnCheckMoney(user, order);
						break;
					case "合数":
						returnMoney = order.getCount10() * oMoney;
						order.setAcount(returnMoney);
						order.setTcplay(key);
						orderService.returnCheckMoney(user, order);
						break;
					case "半波":
						returnMoney = order.getCount39() * oMoney;
						order.setAcount(returnMoney);
						order.setTcplay(key);
						orderService.returnCheckMoney(user, order);
						break;
					}
					tcPlay = key += ",";
					reMoney = dec.format(returnMoney);
					reMoney += ",";
				}
				tcPlay = tcPlay + "&" + reMoney;
				orderService.updateReturnCheckMoney(order.getId(), tcPlay);
			}
				orderService.checkLotterMoney(order, user);
		}catch (Exception e) {
			e.printStackTrace();
			logger.error("CheckOrder类开奖出现的异常："+e.toString());
			continue;
		}
		}
	}
	
	/**
	 * 方法名：checkLotter 
	 * 描述：     查询订单和开奖有关的数据                 
	 * 参数：    @param datas 
	 * @return: void
	 */
	public void checkLotter2(Data datas) {
		/*	datas.setCname("2fft");
			datas.setPeriod("20190326072");
			datas.setLotternumber("05,07,03,10,01,04,09,08,09,06");
		*/
		Order orderInfo = new Order();
		orderInfo.setCname(datas.getCname());
		orderInfo.setPeriod(datas.getPeriod());
		List<Order> orders = orderService.findCheckOrder(orderInfo);
		List<String> list = new ArrayList<>();
		SimpleDateFormat ss = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		String p1 = ss.format(new Date());
		if (orders.size() < 1) {
			return; 
		}
		CheckOrder co = new CheckOrder();
		for (Order order : orders) {
				try {
					User user = userService.getUserByid(order.getUserid());//用户信息
					double userMoney = user.getBalance();
					String userName = user.getName();
					int count = 0;//总注数
					double gMoney = 0.00;//总中奖金额
					String game = order.getCname();//彩种名称
					Double oMoney = order.getLottermoney();//单注金额
					String[] data = datas.getLotternumber().split(",");//开奖号码
					int[] d = new int[data.length];
					for (int i = 0; i < data.length; i++) {
						d[i] = Integer.parseInt(data[i]);
					}
					String[] pv1 = order.getRebate1().split(",");//赔率
					String[] pv2 = order.getRebate2().split(",");
					String[] pv3 = order.getRebate3().split(",");
					String[] pv4 = order.getRebate4().split(",");
					String[] pv5 = order.getRebate5().split(",");
					String[] pv6 = order.getRebate6().split(",");
					String[] pv7 = order.getRebate7().split(",");
					String[] pv8 = order.getRebate8().split(",");
					String[] pv9 = order.getRebate9().split(",");
					String[] pv10 = order.getRebate10().split(",");
					String[] pv11 = order.getRebate11().split(",");
					String[] pv12 = order.getRebate12().split(",");
					String[] pv13 = order.getRebate13().split(",");
					String[] pv14 = order.getRebate14().split(",");
					String[] pv15 = order.getRebate15().split(",");
					String[] pv16 = order.getRebate16().split(",");
					String[] pv17 = order.getRebate17().split(",");
					String[] pv18 = order.getRebate18().split(",");
					String[] pv19 = order.getRebate19().split(",");
					String[] pv20 = order.getRebate20().split(",");
					String[] pv21 = order.getRebate21().split(",");
					String[] pv22 = order.getRebate22().split(",");
					String[] pv23 = order.getRebate23().split(",");
					String[] pv24 = order.getRebate24().split(",");
					String[] pv25 = order.getRebate25().split(",");
					String[] pv26 = order.getRebate26().split(",");
					String[] pv27 = order.getRebate27().split(",");
					String[] pv28 = order.getRebate28().split(",");
					String[] pv29 = order.getRebate29().split(",");
					String[] pv30 = order.getRebate30().split(",");
					String[] pv31 = order.getRebate31().split(",");
					String[] pv32 = order.getRebate32().split(",");
					String[] pv33 = order.getRebate33().split(",");
					String[] pv34 = order.getRebate34().split(",");
					String[] pv35 = order.getRebate35().split(",");
					String[] pv36 = order.getRebate36().split(",");
					String[] pv37 = order.getRebate37().split(",");
					String[] pv38 = order.getRebate38().split(",");
					String[] pv39 = order.getRebate39().split(",");
					String[] pv40 = order.getRebate40().split(",");
		
					int count1 = 0;//各自注数
					int count2 = 0;
					int count3 = 0;
					int count4 = 0;
					int count5 = 0;
					int count6 = 0;
					int count7 = 0;
					int count8 = 0;
					int count9 = 0;
					int count10 = 0;
					int count11 = 0;
					int count12 = 0;
					int count13 = 0;
					int count14 = 0;
					int count15 = 0;
					int count16 = 0;
					int count17 = 0;
					int count18 = 0;
					int count19 = 0;
					int count20 = 0;
					int count21 = 0;
					int count22 = 0;
					int count23 = 0;
					int count24 = 0;
					int count25 = 0;
					int count26 = 0;
					int count27 = 0;
					int count28 = 0;
					int count29 = 0;
					int count30 = 0;
					int count31 = 0;
					int count32 = 0;
					int count33 = 0;
					int count34 = 0;
					int count35 = 0;
					int count36 = 0;
					int count37 = 0;
					int count38 = 0;
					int count39 = 0;
					int count40 = 0;
					
					double money1 = 0.00;// 各自中奖金额
					double money2 = 0.00;
					double money3 = 0.00;
					double money4 = 0.00;
					double money5 = 0.00;
					double money6 = 0.00;
					double money7 = 0.00;
					double money8 = 0.00;
					double money9 = 0.00;
					double money10 = 0.00;
					double money11 = 0.00;
					double money12 = 0.00;
					double money13 = 0.00;
					double money14 = 0.00;
					double money15 = 0.00;
					double money16 = 0.00;
					double money17 = 0.00;
					double money18 = 0.00;
					double money19 = 0.00;
					double money20 = 0.00;
					double money21 = 0.00;
					double money22 = 0.00;
					double money23 = 0.00;
					double money24 = 0.00;
					double money25 = 0.00;
					double money26 = 0.00;
					double money27 = 0.00;
					double money28 = 0.00;
					double money29 = 0.00;
					double money30 = 0.00;
					double money31 = 0.00;
					double money32 = 0.00;
					double money33 = 0.00;
					double money34 = 0.00;
					double money35 = 0.00;
					double money36 = 0.00;
					double money37 = 0.00;
					double money38 = 0.00;
					double money39 = 0.00;
					double money40 = 0.00;
					List<Double> lm1 = new ArrayList<Double>();//彩种下注金额
					switch (game) {
					case "bjpk10":
					case "2fpk10":
					case "xyft":
					case "xysm":
					case "2fft":
						String[] gyhz = order.getStr1().split(",");
						String[] d1m = order.getStr2().split(",");
						String[] d2m = order.getStr3().split(",");
						String[] d3m = order.getStr4().split(",");
						String[] d4m = order.getStr5().split(",");
						String[] d5m = order.getStr6().split(",");
						String[] d6m = order.getStr7().split(",");
						String[] d7m = order.getStr8().split(",");
						String[] d8m = order.getStr9().split(",");
						String[] d9m = order.getStr10().split(",");
						String[] d10m = order.getStr11().split(",");
						String[] qiu = { "单", "双", "大", "小", "龙", "虎", "01", "02", "03", "04", "05", "06", "07", "08", "09",
								"10" };
						String[] qiu1 = { "单", "双", "大", "小", "01", "02", "03", "04", "05", "06", "07", "08", "09", "10" };
						// 冠亚和值
						if (gyhz.length != 0 && !"".equals(gyhz[0])) {
							int a1 = 0;
							int a2 = 0;
							int a3 = 0;
							int a4 = 0;
							int c = d[0] + d[1];
							for (int i = 0; i < gyhz.length; i++) {
								if (gyhz[i].equals("单")) {
									if (c % 2 != 0) {
										a1 = 1;
									}
								}
								if (gyhz[i].equals("双")) {
									if (c % 2 == 0) {
										a2 = 1;
									}
								}
								if (gyhz[i].equals("大")) {
									if (c > 11) {
										a3 = 1;
									}
								}
								if (gyhz[i].equals("小")) {
									if (c < 12) {
										a4 = 1;
									}
								}
							}
							count1 = a1 + a2 + a3 + a4;
							System.out.println("赔率1："+co.ratio(user,pv1[0]));
							System.out.println("赔率:2："+co.ratio(user,pv1[1]));
							System.out.println("赔率:3："+co.ratio(user,pv1[2]));
							System.out.println("赔率:4："+co.ratio(user,pv1[3]));
							money1 = a1 * oMoney * co.ratio(user,pv1[0]) + a2 * oMoney * co.ratio(user,pv1[1])
							+ a3 * oMoney * co.ratio(user,pv1[2]) + a4 * oMoney * co.ratio(user,pv1[3]);
						}
						// 冠军
						if (d1m.length != 0 && !"".equals(d1m[0])) {
							int a1 = 0;
							int a2 = 0;
							int a3 = 0;
							int a4 = 0;
							int a5 = 0;
							int a6 = 0;
							int a7 = 0;
							int b = 0;
							int c = d[0];
							String c1 = data[0];
							for (int i = 0; i < d1m.length; i++) {
								if (d1m[i].equals("单")) {
									if (c % 2 != 0) {
										a1 = 1;
									}
								}
								if (d1m[i].equals("双")) {
									if (c % 2 == 0) {
										a2 = 1;
									}
								}
								if (d1m[i].equals("大")) {
									if (c >= 6) {
										a3 = 1;
									}
								}
								if (d1m[i].equals("小")) {
									if (c <= 5) {
										a4 = 1;
									}
								}
								if (d1m[i].equals("龙")) {
									if (c > d[9]) {
										a5 = 1;
									}
								}
								if (d1m[i].equals("虎")) {
									if (c < d[9]) {
										a6 = 1;
									}
								}
								for (int j = 0; j < qiu.length; j++) {
									if (d1m[i].equals(c1) && d1m[i].equals(qiu[j])) {
										a7 = 1;
										b = j;
									}
								}
							}
							count2 = a1 + a2 + a3 + a4 + a5 + a6 + a7;
								money2 = a1 * oMoney * co.ratio(user,pv2[0]) + a2 * oMoney * co.ratio(user,pv2[1])
								+ a3 * oMoney * co.ratio(user,pv2[2]) + a4 * oMoney * co.ratio(user,pv2[3])
								+ a5 * oMoney * co.ratio(user,pv2[4]) + a6 * oMoney * co.ratio(user,pv2[5])
								+ a7 * oMoney * co.ratio(user,pv2[b]);
						}
						// 亚军
						if (d2m.length != 0 && !"".equals(d2m[0])) {
							int a1 = 0;
							int a2 = 0;
							int a3 = 0;
							int a4 = 0;
							int a5 = 0;
							int a6 = 0;
							int a7 = 0;
							int b = 0;
							int c = d[1];
							String c1 = data[1];
							for (int i = 0; i < d2m.length; i++) {
								if (d2m[i].equals("单")) {
									if (c % 2 != 0) {
										a1 = 1;
									}
								}
								if (d2m[i].equals("双")) {
									if (c % 2 == 0) {
										a2 = 1;
									}
		
								}
								if (d2m[i].equals("大")) {
									if (c >= 6) {
										a3 = 1;
									}
								}
								if (d2m[i].equals("小")) {
									if (c <= 5) {
										a4 = 1;
									}
								}
								if (d2m[i].equals("龙")) {
									if (c > d[8]) {
										a5 = 1;
									}
								}
								if (d2m[i].equals("虎")) {
									if (c < d[8]) {
										a6 = 1;
									}
								}
								for (int j = 0; j < qiu.length; j++) {
									if (d2m[i].equals(c1) && d2m[i].equals(qiu[j])) {
										a7 = 1;
										b = j;
									}
								}
							}
							count3 = a1 + a2 + a3 + a4 + a5 + a6 + a7;
								money3 = a1 * oMoney * co.ratio(user,pv3[0]) + a2 * oMoney * co.ratio(user,pv3[1])
								+ a3 * oMoney * co.ratio(user,pv3[2]) + a4 * oMoney * co.ratio(user,pv3[3])
								+ a5 * oMoney * co.ratio(user,pv3[4]) + a6 * oMoney * co.ratio(user,pv3[5])
								+ a7 * oMoney * co.ratio(user,pv3[b]);
						}
						// 第3名
						if (d3m.length != 0 && !"".equals(d3m[0])) {
							int a1 = 0;
							int a2 = 0;
							int a3 = 0;
							int a4 = 0;
							int a5 = 0;
							int a6 = 0;
							int a7 = 0;
							int b = 0;
							int c = d[2];
							String c1 = data[2];
							for (int i = 0; i < d3m.length; i++) {
								if (d3m[i].equals("单")) {
									if (c % 2 != 0) {
										a1 = 1;
									}
								}
								if (d3m[i].equals("双")) {
									if (c % 2 == 0) {
										a2 = 1;
									}
								}
								if (d3m[i].equals("大")) {
									if (c >= 6) {
										a3 = 1;
									}
								}
								if (d3m[i].equals("小")) {
									if (c <= 5) {
										a4 = 1;
									}
								}
								if (d3m[i].equals("龙")) {
									if (c > d[7]) {
										a5 = 1;
									}
								}
								if (d3m[i].equals("虎")) {
									if (c < d[7]) {
										a6 = 1;
									}
								}
								for (int j = 0; j < qiu.length; j++) {
									if (d3m[i].equals(c1) && d3m[i].equals(qiu[j])) {
										a7 = 1;
										b = j;
									}
								}
							}
							count4 = a1 + a2 + a3 + a4 + a5 + a6 + a7;
								money4 = a1 * oMoney * co.ratio(user,pv4[0]) + a2 * oMoney * co.ratio(user,pv4[1])
								+ a3 * oMoney * co.ratio(user,pv4[2]) + a4 * oMoney * co.ratio(user,pv4[3])
								+ a5 * oMoney * co.ratio(user,pv4[4]) + a6 * oMoney * co.ratio(user,pv4[5])
								+ a7 * oMoney * co.ratio(user,pv4[b]);
						}
						// 第4名
						if (d4m.length != 0 && !"".equals(d4m[0])) {
							int a1 = 0;
							int a2 = 0;
							int a3 = 0;
							int a4 = 0;
							int a5 = 0;
							int a6 = 0;
							int a7 = 0;
							int b = 0;
							int c = d[3];
							String c1 = data[3];
							for (int i = 0; i < d4m.length; i++) {
								if (d4m[i].equals("单")) {
									if (c % 2 != 0) {
										a1 = 1;
									}
								}
								if (d4m[i].equals("双")) {
									if (c % 2 == 0) {
										a2 = 1;
									}
								}
								if (d4m[i].equals("大")) {
									if (c >= 6) {
										a3 = 1;
									}
								}
								if (d4m[i].equals("小")) {
									if (c <= 5) {
										a4 = 1;
									}
								}
								if (d4m[i].equals("龙")) {
									if (c > d[6]) {
										a5 = 1;
									}
								}
								if (d4m[i].equals("虎")) {
									if (c < d[6]) {
										a6 = 1;
									}
								}
								for (int j = 0; j < qiu.length; j++) {
									if (d4m[i].equals(c1) && d4m[i].equals(qiu[j])) {
										a7 = 1;
										b = j;
									}
								}
							}
							count5 = a1 + a2 + a3 + a4 + a5 + a6 + a7;
								money5 = a1 * oMoney * co.ratio(user,pv5[0]) + a2 * oMoney * co.ratio(user,pv5[1])
								+ a3 * oMoney * co.ratio(user,pv5[2]) + a4 * oMoney * co.ratio(user,pv5[3])
								+ a5 * oMoney * co.ratio(user,pv5[4]) + a6 * oMoney * co.ratio(user,pv5[5])
								+ a7 * oMoney * co.ratio(user,pv5[b]);
						}
						// 第5名
						if (d5m.length != 0 && !"".equals(d5m[0])) {
							int a1 = 0;
							int a2 = 0;
							int a3 = 0;
							int a4 = 0;
							int a5 = 0;
							int a6 = 0;
							int a7 = 0;
							int b = 0;
							int c = d[4];
							String c1 = data[4];
							for (int i = 0; i < d5m.length; i++) {
								if (d5m[i].equals("单")) {
									if (c % 2 != 0) {
										a1 = 1;
									}
								}
								if (d5m[i].equals("双")) {
									if (c % 2 == 0) {
										a2 = 1;
									}
								}
								if (d5m[i].equals("大")) {
									if (c >= 6) {
										a3 = 1;
									}
								}
								if (d5m[i].equals("小")) {
									if (c <= 5) {
										a4 = 1;
									}
								}
								if (d5m[i].equals("龙")) {
									if (c > d[5]) {
										a5 = 1;
									}
								}
								if (d5m[i].equals("虎")) {
									if (c < d[5]) {
										a6 = 1;
									}
								}
								for (int j = 0; j < qiu.length; j++) {
									if (d5m[i].equals(c1) && d5m[i].equals(qiu[j])) {
										a7 = 1;
										b = j;
									}
								}
							}
							count6 = a1 + a2 + a3 + a4 + a5 + a6 + a7;
								money6 = a1 * oMoney * co.ratio(user,pv6[0]) + a2 * oMoney * co.ratio(user,pv6[1])
								+ a3 * oMoney * co.ratio(user,pv6[2]) + a4 * oMoney * co.ratio(user,pv6[3])
								+ a5 * oMoney * co.ratio(user,pv6[4]) + a6 * oMoney * co.ratio(user,pv6[5])
								+ a7 * oMoney * co.ratio(user,pv6[b]);
						}
						// 第6名
						if (d6m.length != 0 && !"".equals(d6m[0])) {
							int a1 = 0;
							int a2 = 0;
							int a3 = 0;
							int a4 = 0;
							int a5 = 0;
							int b = 0;
							int c = d[5];
							String c1 = data[5];
							for (int i = 0; i < d6m.length; i++) {
								if (d6m[i].equals("单")) {
									if (c % 2 != 0) {
										a1 = 1;
									}
								}
								if (d6m[i].equals("双")) {
									if (c % 2 == 0) {
										a2 = 1;
									}
								}
								if (d6m[i].equals("大")) {
									if (c >= 6) {
										a3 = 1;
									}
								}
								if (d6m[i].equals("小")) {
									if (c <= 5) {
										a4 = 1;
									}
								}
								for (int j = 0; j < qiu1.length; j++) {
									if (d6m[i].equals(c1) && d6m[i].equals(qiu1[j])) {
										a5 = 1;
										b = j;
									}
								}
							}
							count7 = a1 + a2 + a3 + a4 + a5;
								money7 = a1 * oMoney * co.ratio(user,pv7[0]) + a2 * oMoney * co.ratio(user,pv7[1])
								+ a3 * oMoney * co.ratio(user,pv7[2]) + a4 * oMoney * co.ratio(user,pv7[3])
								+ a5 * oMoney * co.ratio(user,pv7[b]);
						}
						// 第7名
						if (d7m.length != 0 && !"".equals(d7m[0])) {
							int a1 = 0;
							int a2 = 0;
							int a3 = 0;
							int a4 = 0;
							int a5 = 0;
							int b = 0;
							int c = d[6];
							String c1 = data[6];
							for (int i = 0; i < d7m.length; i++) {
								if (d7m[i].equals("单")) {
									if (c % 2 != 0) {
										a1 = 1;
									}
								}
								if (d7m[i].equals("双")) {
									if (c % 2 == 0) {
										a2 = 1;
									}
								}
								if (d7m[i].equals("大")) {
									if (c >= 6) {
										a3 = 1;
									}
								}
								if (d7m[i].equals("小")) {
									if (c <= 5) {
										a4 = 1;
									}
								}
								for (int j = 0; j < qiu1.length; j++) {
									if (d7m[i].equals(c1) && d7m[i].equals(qiu1[j])) {
										a5 = 1;
										b = j;
									}
								}
							}
							count8 = a1 + a2 + a3 + a4 + a5;
								money8 = a1 * oMoney * co.ratio(user,pv8[0]) + a2 * oMoney * co.ratio(user,pv8[1])
								+ a3 * oMoney * co.ratio(user,pv8[2]) + a4 * oMoney * co.ratio(user,pv8[3])
								+ a5 * oMoney * co.ratio(user,pv8[b]);
						}
						// 第8名
						if (d8m.length != 0 && !"".equals(d8m[0])) {
							int a1 = 0;
							int a2 = 0;
							int a3 = 0;
							int a4 = 0;
							int a5 = 0;
							int b = 0;
							int c = d[7];
							String c1 = data[7];
							for (int i = 0; i < d8m.length; i++) {
								if (d8m[i].equals("单")) {
									if (c % 2 != 0) {
										a1 = 1;
									}
								}
								if (d8m[i].equals("双")) {
									if (c % 2 == 0) {
										a2 = 1;
									}
								}
								if (d8m[i].equals("大")) {
									if (c >= 6) {
										a3 = 1;
									}
								}
								if (d8m[i].equals("小")) {
									if (c <= 5) {
										a4 = 1;
									}
								}
								for (int j = 0; j < qiu1.length; j++) {
									if (d8m[i].equals(c1) && d8m[i].equals(qiu1[j])) {
										a5 = 1;
										b = j;
									}
								}
							}
							count9 = a1 + a2 + a3 + a4 + a5;
								money9 = a1 * oMoney * co.ratio(user,pv9[0]) + a2 * oMoney * co.ratio(user,pv9[1])
								+ a3 * oMoney * co.ratio(user,pv9[2]) + a4 * oMoney * co.ratio(user,pv9[3])
								+ a5 * oMoney * co.ratio(user,pv9[b]);
						}
						// 第9名
						if (d9m.length != 0 && !"".equals(d9m[0])) {
							int a1 = 0;
							int a2 = 0;
							int a3 = 0;
							int a4 = 0;
							int a5 = 0;
							int b = 0;
							int c = d[8];
							String c1 = data[8];
							for (int i = 0; i < d9m.length; i++) {
								if (d9m[i].equals("单")) {
									if (c % 2 != 0) {
										a1 = 1;
									}
								}
								if (d9m[i].equals("双")) {
									if (c % 2 == 0) {
										a2 = 1;
									}
								}
								if (d9m[i].equals("大")) {
									if (c >= 6) {
										a3 = 1;
									}
								}
								if (d9m[i].equals("小")) {
									if (c <= 5) {
										a4 = 1;
									}
								}
								for (int j = 0; j < qiu1.length; j++) {
									if (d9m[i].equals(c1) && d9m[i].equals(qiu1[j])) {
										a5 = 1;
										b = j;
									}
								}
							}
							count10 = a1 + a2 + a3 + a4 + a5;
								money10 = a1 * oMoney * co.ratio(user,pv10[0]) + a2 * oMoney * co.ratio(user,pv10[1])
								+ a3 * oMoney * co.ratio(user,pv10[2]) + a4 * oMoney * co.ratio(user,pv10[3])
								+ a5 * oMoney * co.ratio(user,pv10[b]);
						}
						// 第10名
						if (d10m.length != 0 && !"".equals(d10m[0])) {
							int a1 = 0;
							int a2 = 0;
							int a3 = 0;
							int a4 = 0;
							int a5 = 0;
							int b = 0;
							int c = d[9];
							String c1 = data[9];
							for (int i = 0; i < d10m.length; i++) {
								if (d10m[i].equals("单")) {
									if (c % 2 != 0) {
										a1 = 1;
									}
								}
								if (d10m[i].equals("双")) {
									if (c % 2 == 0) {
										a2 = 1;
									}
								}
								if (d10m[i].equals("大")) {
									if (c >= 6) {
										a3 = 1;
									}
								}
								if (d10m[i].equals("小")) {
									if (c <= 5) {
										a4 = 1;
									}
								}
								for (int j = 0; j < qiu1.length; j++) {
									if (d10m[i].equals(c1) && d10m[i].equals(qiu1[j])) {
										a5 = 1;
										b = j;
									}
								}
							}
							count11 = a1 + a2 + a3 + a4 + a5;
								money11 = a1 * oMoney * co.ratio(user,pv11[0]) + a2 * oMoney * co.ratio(user,pv11[1])
								+ a3 * oMoney * co.ratio(user,pv11[2]) + a4 * oMoney * co.ratio(user,pv11[3])
								+ a5 * oMoney * co.ratio(user,pv11[b]);
						}
						break;
					case "cqssc":
					case "2fssc":
					case "tjssc":
					case "xjssc":
						String[] zh = order.getStr1().split(",");
						String[] d1q = order.getStr2().split(",");
						String[] d2q = order.getStr3().split(",");
						String[] d3q = order.getStr4().split(",");
						String[] d4q = order.getStr5().split(",");
						String[] d5q = order.getStr6().split(",");
						String[] q3 = order.getStr7().split(",");
						String[] z3 = order.getStr8().split(",");
						String[] h3 = order.getStr9().split(",");
						String[] q2zhx0 = order.getStr10().split(",");
						String[] q2zhx1 = order.getStr11().split(",");
						String[] h2zhx0 = order.getStr12().split(",");
						String[] h2zhx1 = order.getStr13().split(",");
						String[] q3zhxx0 = order.getStr14().split(",");
						String[] q3zhxx1 = order.getStr15().split(",");
						String[] q3zhxx2 = order.getStr16().split(",");
						String[] z3zhx0 = order.getStr17().split(",");
						String[] z3zhx1 = order.getStr18().split(",");
						String[] z3zhx2 = order.getStr19().split(",");
						String[] h3zhx0 = order.getStr20().split(",");
						String[] h3zhx1 = order.getStr21().split(",");
						String[] h3zhx2 = order.getStr22().split(",");
						String[] q2zxx = order.getStr23().split(",");
						String[] h2zxx = order.getStr24().split(",");
						String[] q3z6 = order.getStr25().split(",");
						String[] z3z6 = order.getStr26().split(",");
						String[] h3z6 = order.getStr27().split(",");
						String[] q3z3 = order.getStr28().split(",");
						String[] z3z3 = order.getStr29().split(",");
						String[] h3z3 = order.getStr30().split(",");
						String[] qiu2 = { "单", "双", "大", "小", "0", "1", "2", "3", "4", "5", "6", "7", "8", "9" };
						// 总和
						if (zh.length != 0 && !"".equals(zh[0])) {
							int a1 = 0;
							int a2 = 0;
							int a3 = 0;
							int a4 = 0;
							int a5 = 0;
							int a6 = 0;
							int a7 = 0;
							int k = d[0] + d[1] + d[2] + d[3] + d[4];
							for (int i = 0; i < zh.length; i++) {
								if ("单".equals(zh[i])) {
									if (k % 2 != 0) {
										a1 = 1;
									}
								}
								if ("双".equals(zh[i])) {
									if (k % 2 == 0) {
										a2 = 1;
									}
								}
								if ("大".equals(zh[i])) {
									if (k > 22) {
										a3 = 1;
									}
								}
								if ("小".equals(zh[i])) {
									if (k < 23) {
										a4 = 1;
									}
								}
								if ("龙".equals(zh[i])) {
									if (d[0] > d[4]) {
										a5 = 1;
									}
								}
								if ("虎".equals(zh[i])) {
									if (d[0] < d[4]) {
										a6 = 1;
									}
								}
								if ("和".equals(zh[i])) {
									if (d[0] == d[4]) {
										a7 = 1;
									}
								}
							}
							count1 = a1 + a2 + a3 + a4 + a5 + a6 + a7;
								money1 = a1 * oMoney * co.ratio(user,pv1[0]) + a2 * oMoney * co.ratio(user,pv1[1])
								+ a3 * oMoney * co.ratio(user,pv1[2]) + a4 * oMoney * co.ratio(user,pv1[3])
								+ a5 * oMoney * co.ratio(user,pv1[4]) + a6 * oMoney * co.ratio(user,pv1[5])
								+ a7 * oMoney * co.ratio(user,pv1[6]);
						}
						// 第1球
						if (d1q.length != 0 && !"".equals(d1q[0])) {
							int a1 = 0;
							int a2 = 0;
							int a3 = 0;
							int a4 = 0;
							int a5 = 0;
							int b = 0;
							int c = d[0];
							for (int i = 0; i < d1q.length; i++) {
								if (d1q[i].equals("单")) {
									if (c % 2 != 0) {
										a1 = 1;
									}
								}
								if (d1q[i].equals("双")) {
									if (c % 2 == 0) {
										a2 = 1;
									}
								}
								if (d1q[i].equals("大")) {
									if (c > 4 && c < 10) {
										a3 = 1;
									}
								}
								if (d1q[i].equals("小")) {
									if (c >= 0 && c < 5) {
										a4 = 1;
									}
								}
								for (int j = 0; j < qiu2.length; j++) {
									if (d1q[i].equals("" + c) && d1q[i].equals(qiu2[j])) {
										a5 = 1;
										b = j;
									}
								}
							}
							count2 = a1 + a2 + a3 + a4 + a5;
								money2 = a1 * oMoney * co.ratio(user,pv2[0]) + a2 * oMoney * co.ratio(user,pv2[1])
								+ a3 * oMoney * co.ratio(user,pv2[2]) + a4 * oMoney * co.ratio(user,pv2[3])
								+ a5 * oMoney * co.ratio(user,pv2[b]);
						}
						// 第2球
						if (d2q.length != 0 && !"".equals(d2q[0])) {
							int a1 = 0;
							int a2 = 0;
							int a3 = 0;
							int a4 = 0;
							int a5 = 0;
							int b = 0;
							int c = d[1];
							for (int i = 0; i < d2q.length; i++) {
								if (d2q[i].equals("单")) {
									if (c % 2 != 0) {
										a1 = 1;
									}
								}
								if (d2q[i].equals("双")) {
									if (c % 2 == 0) {
										a2 = 1;
									}
								}
								if (d2q[i].equals("大")) {
									if (c > 4 && c < 10) {
										a3 = 1;
									}
								}
								if (d2q[i].equals("小")) {
									if (c >= 0 && c < 5) {
										a4 = 1;
									}
								}
								for (int j = 0; j < qiu2.length; j++) {
									if (d2q[i].equals("" + c) && d2q[i].equals(qiu2[j])) {
										a5 = 1;
										b = j;
									}
								}
							}
							count3 = a1 + a2 + a3 + a4 + a5;
								money3 = a1 * oMoney * co.ratio(user,pv3[0]) + a2 * oMoney * co.ratio(user,pv3[1]) 
								+ a3 * oMoney * co.ratio(user,pv3[2])  + a4 * oMoney * co.ratio(user,pv3[3]) 
								+ a5 * oMoney * co.ratio(user,pv3[b]) ;
						}
						// 第3球
						if (d3q.length != 0 && !"".equals(d3q[0])) {
							int a1 = 0;
							int a2 = 0;
							int a3 = 0;
							int a4 = 0;
							int a5 = 0;
							int b = 0;
							int c = d[2];
							for (int i = 0; i < d3q.length; i++) {
								if (d3q[i].equals("单")) {
									if (c % 2 != 0) {
										a1 = 1;
									}
								}
								if (d3q[i].equals("双")) {
									if (c % 2 == 0) {
										a2 = 1;
									}
								}
								if (d3q[i].equals("大")) {
									if (c > 4 && c < 10) {
										a3 = 1;
									}
								}
								if (d3q[i].equals("小")) {
									if (c >= 0 && c < 5) {
										a4 = 1;
									}
								}
								for (int j = 0; j < qiu2.length; j++) {
									if (d3q[i].equals("" + c) && d3q[i].equals(qiu2[j])) {
										a5 = 1;
										b = j;
									}
								}
							}
							count4 = a1 + a2 + a3 + a4 + a5;
								money4 = a1 * oMoney * co.ratio(user,pv4[0])  + a2 * oMoney * co.ratio(user,pv4[1])
								+ a3 * oMoney * co.ratio(user,pv4[2]) + a4 * oMoney * co.ratio(user,pv4[3])
								+ a5 * oMoney * co.ratio(user,pv4[b]);
						}
						// 第4球
						if (d4q.length != 0 && !"".equals(d4q[0])) {
							int a1 = 0;
							int a2 = 0;
							int a3 = 0;
							int a4 = 0;
							int a5 = 0;
							int b = 0;
							int c = d[3];
							for (int i = 0; i < d4q.length; i++) {
								if (d4q[i].equals("单")) {
									if (c % 2 != 0) {
										a1 = 1;
									}
								}
								if (d4q[i].equals("双")) {
									if (c % 2 == 0) {
										a2 = 1;
									}
								}
								if (d4q[i].equals("大")) {
									if (c > 4 && c < 10) {
										a3 = 1;
									}
								}
								if (d4q[i].equals("小")) {
									if (c >= 0 && c < 5) {
										a4 = 1;
									}
								}
								for (int j = 0; j < qiu2.length; j++) {
									if (d4q[i].equals("" + c) && d4q[i].equals(qiu2[j])) {
										a5 = 1;
										b = j;
									}
								}
							}
							count5 = a1 + a2 + a3 + a4 + a5;
								money5 = a1 * oMoney * co.ratio(user,pv5[0]) + a2 * oMoney * co.ratio(user,pv5[1])
								+ a3 * oMoney * co.ratio(user,pv5[2]) + a4 * oMoney * co.ratio(user,pv5[3])
								+ a5 * oMoney * co.ratio(user,pv5[b]);
						}
						// 第5球
						if (d5q.length != 0 && !"".equals(d5q[0])) {
							int a1 = 0;
							int a2 = 0;
							int a3 = 0;
							int a4 = 0;
							int a5 = 0;
							int b = 0;
							int c = d[4];
							for (int i = 0; i < d5q.length; i++) {
								if (d5q[i].equals("单")) {
									if (c % 2 != 0) {
										a1 = 1;
									}
								}
								if (d5q[i].equals("双")) {
									if (c % 2 == 0) {
										a2 = 1;
									}
								}
								if (d5q[i].equals("大")) {
									if (c > 4 && c < 10) {
										a3 = 1;
									}
								}
								if (d5q[i].equals("小")) {
									if (c >= 0 && c < 5) {
										a4 = 1;
									}
								}
								for (int j = 0; j < qiu2.length; j++) {
									if (d5q[i].equals("" + c) && d5q[i].equals(qiu2[j])) {
										a5 = 1;
										b = j;
									}
								}
							}
							count6 = a1 + a2 + a3 + a4 + a5;
								money6 = a1 * oMoney * co.ratio(user,pv6[0]) + a2 * oMoney * co.ratio(user,pv6[1])
								+ a3 * oMoney * co.ratio(user,pv6[2]) + a4 * oMoney * co.ratio(user,pv6[3])
								+ a5 * oMoney * co.ratio(user,pv6[b]);
						}
						String[] rule = { "890", "809", "901", "910", "908", "980", "091", "019", "089", "098", "109", "190" };
						String[] rule2 = { "902", "903", "904", "905", "906", "907", "029", "092", "039", "093", "049", "094",
								"059", "095", "069", "096", "079", "097", "209", "309", "409", "509", "609", "709", "290",
								"390", "490", "590", "690", "790", "920", "930", "940", "950", "960", "970" };
						// 前三
						if (q3.length != 0 && !"".equals(q3[0])) {
							int a = 0;
							int b = 0;
							int c = 0;
							int e = 0;
							int f = 0;
							for (int i = 0; i < q3.length; i++) {
								if ("豹子".equals(q3[i])) {
									if (d[0] == d[1] && d[0] == d[2]) {
										a = 1;
									}
								}
								if ("顺子".equals(q3[i])) {
									if (d[0] + 1 == d[1] && d[0] + 2 == d[2]) {
										b = 1;
									} else if (d[0] + 2 == d[1] && d[0] + 1 == d[2]) {
										b = 1;
									} else if (d[0] - 1 == d[1] && d[0] + 1 == d[2]) {
										b = 1;
									} else if (d[0] + 1 == d[1] && d[0] - 1 == d[2]) {
										b = 1;
									} else if (d[0] - 2 == d[1] && d[0] - 1 == d[2]) {
										b = 1;
									} else if (d[0] - 1 == d[1] && d[0] - 2 == d[2]) {
										b = 1;
									}
									for (int i1 = 0; i1 < rule.length; i1++) {
										if (("" + d[0] + d[1] + d[2]).equals(rule[i1])) {
											b = 1;
										}
									}
								}
								if ("对子".equals(q3[i])) {
									if ((d[0] != d[1] || d[0] != d[2])) {
										if (d[0] == d[1] || d[0] == d[2] || d[1] == d[2]) {
											c = 1;
										}
									}
								}
								if ("半顺".equals(q3[i])) {
									boolean flag1 = !(d[0] + 1 == d[1] && d[0] + 2 == d[2]);
									boolean flag2 = !(d[0] + 2 == d[1] && d[0] + 1 == d[2]);
									boolean flag3 = !(d[0] - 1 == d[1] && d[0] + 1 == d[2]);
									boolean flag4 = !(d[0] + 1 == d[1] && d[0] - 1 == d[2]);
									boolean flag5 = !(d[0] - 2 == d[1] && d[0] - 1 == d[2]);
									boolean flag6 = !(d[0] - 1 == d[1] && d[0] - 2 == d[2]);
									boolean flag13 = d[0] != d[1] && d[0] != d[2];
									boolean flag14 = d[0] != d[1];
									boolean flag15 = d[0] != d[2];
									boolean flag16 = d[1] != d[2];
									for (int p = 0; p < rule.length; p++) {
										boolean flag17 = !("" + d[0] + d[1] + d[2]).equals(rule[p]);
										if (flag1 && flag2 && flag3 && flag4 && flag5 && flag6 && flag13 && flag14 && flag15
												&& flag16) {
											if (d[0] + 1 == d[1] || d[0] + 1 == d[2] || d[0] - 1 == d[1] || d[0] - 1 == d[2]
													|| d[1] + 1 == d[2] || d[1] - 1 == d[2]) {
												if (flag17) {
													e = 1;
												}
												if (flag17 == false) {
													e = 0;
													break;
												}
											}
										}
									}
									for (int x = 0; x < rule2.length; x++) {
										if (("" + d[0] + d[1] + d[2]).equals(rule2[x])) {
											e = 1;
										}
									}
								}
		
								if (("杂六").equals(q3[i])) {
									boolean flag1 = d[0] + 1 != d[1];
									boolean flag2 = d[0] + 1 != d[2];
									boolean flag3 = d[0] - 1 != d[1];
									boolean flag4 = d[0] - 1 != d[2];
									boolean flag5 = d[1] - 1 != d[2];
									boolean flag6 = d[1] + 1 != d[2];
									boolean flag7 = d[0] != d[1];
									boolean flag8 = d[0] != d[2];
									boolean flag9 = d[1] != d[2];
									boolean flag17 = true;
									boolean flag18 = true;
									String qius = "" + d[0] + d[1] + d[2];
									for (int m = 0; m < rule.length; m++) {
										if (rule[m].equals(qius)) {
											flag17 = false;
										}
									}
									for (int m = 0; m < rule2.length; m++) {
										if (rule2[m].equals(qius)) {
											flag18 = false;
										}
		
									}
									boolean flag = flag1 && flag2 && flag3 && flag4 && flag5 && flag6 && flag7 && flag8 && flag9
											&& flag17 && flag18;
									if (flag) {
										f = 1;
									}
								}
		
							}
							count7 = a + b + c + e + f;
								money7 = a * oMoney * co.ratio(user,pv7[0]) + b * oMoney * co.ratio(user,pv7[1])
								+ c * oMoney * co.ratio(user,pv7[2]) + e * oMoney * co.ratio(user,pv7[3])
								+ f * oMoney * co.ratio(user,pv7[4]);
						}
						// 中三
						if (z3.length != 0 && !"".equals(z3[0])) {
							int a = 0;
							int b = 0;
							int c = 0;
							int e = 0;
							int f = 0;
							for (int i = 0; i < z3.length; i++) {
								if ("豹子".equals(z3[i])) {
									if (d[1] == d[2] && d[1] == d[3]) {
										a = 1;
									}
								}
								if ("顺子".equals(z3[i])) {
									if (d[1] + 1 == d[2] && d[1] + 2 == d[3]) {
										b = 1;
									} else if (d[1] + 2 == d[2] && d[1] + 1 == d[3]) {
										b = 1;
									} else if (d[1] - 1 == d[2] && d[1] + 1 == d[3]) {
										b = 1;
									} else if (d[1] + 1 == d[2] && d[1] - 1 == d[3]) {
										b = 1;
									} else if (d[1] - 2 == d[2] && d[1] - 1 == d[3]) {
										b = 1;
									} else if (d[1] - 1 == d[2] && d[1] - 2 == d[3]) {
										b = 1;
									}
									for (int i1 = 0; i1 < rule.length; i1++) {
										if (("" + d[1] + d[2] + d[3]).equals(rule[i1])) {
											b = 1;
										}
									}
								}
								if ("对子".equals(z3[i])) {
									if (d[1] != d[2] || d[1] != d[3]) {
										if (d[1] == d[2] || d[1] == d[3] || d[2] == d[3]) {
											c = 1;
										}
									}
								}
		
								if ("半顺".equals(z3[i])) {
									boolean flag1 = !(d[1] + 1 == d[2] && d[1] + 2 == d[3]);
									boolean flag2 = !(d[1] + 2 == d[2] && d[1] + 1 == d[3]);
									boolean flag3 = !(d[1] - 1 == d[2] && d[1] + 1 == d[3]);
									boolean flag4 = !(d[1] + 1 == d[2] && d[1] - 1 == d[3]);
									boolean flag5 = !(d[1] - 2 == d[2] && d[1] - 1 == d[3]);
									boolean flag6 = !(d[1] - 1 == d[2] && d[1] - 2 == d[3]);
									boolean flag13 = d[1] != d[2] && d[1] != d[3];
									boolean flag14 = d[1] != d[2];
									boolean flag15 = d[1] != d[3];
									boolean flag16 = d[2] != d[3];
									for (int p = 0; p < rule.length; p++) {
										boolean flag17 = !("" + d[1] + d[2] + d[3]).equals(rule[p]);
										if (flag1 && flag2 && flag3 && flag4 && flag5 && flag6 && flag13 && flag14 && flag15
												&& flag16) {
											if (d[1] + 1 == d[2] || d[1] + 1 == d[3] || d[1] - 1 == d[2] || d[1] - 1 == d[3]
													|| d[2] + 1 == d[3] || d[2] - 1 == d[3]) {
												if (flag17) {
													e = 1;
												}
												if (flag17 == false) {
													e = 0;
													break;
												}
											}
										}
									}
									for (int x = 0; x < rule2.length; x++) {
										if (("" + d[1] + d[2] + d[3]).equals(rule2[x])) {
											e = 1;
										}
									}
								}
								if ("杂六".equals(z3[i])) {
									boolean flag1 = d[1] + 1 != d[2];
									boolean flag2 = d[1] + 1 != d[3];
									boolean flag3 = d[1] - 1 != d[2];
									boolean flag4 = d[1] - 1 != d[3];
									boolean flag5 = d[2] - 1 != d[3];
									boolean flag6 = d[2] + 1 != d[3];
									boolean flag7 = d[1] != d[2];
									boolean flag8 = d[1] != d[3];
									boolean flag9 = d[2] != d[3];
									boolean flag17 = true;
									boolean flag18 = true;
									String qius = "" + d[1] + d[2] + d[3];
									for (int m = 0; m < rule.length; m++) {
										if (rule[m].equals(qius)) {
											flag17 = false;
										}
									}
									for (int m = 0; m < rule2.length; m++) {
										if (rule2[m].equals(qius)) {
											flag18 = false;
										}
		
									}
									boolean flag = flag1 && flag2 && flag3 && flag4 && flag5 && flag6 && flag7 && flag8 && flag9
											&& flag17 && flag18;
									if (flag) {
										f = 1;
									}
								}
							}
							count8 = a + b + c + e + f;
								money8 = a * oMoney * co.ratio(user,pv8[0]) + b * oMoney * co.ratio(user,pv8[1])
								+ c * oMoney * co.ratio(user,pv8[2]) + e * oMoney * co.ratio(user,pv8[3])
								+ f * oMoney * co.ratio(user,pv8[4]);
						}
						// 后三
						if (h3.length != 0 && !"".equals(h3[0])) {
							int a = 0;
							int b = 0;
							int c = 0;
							int e = 0;
							int f = 0;
							for (int i = 0; i < h3.length; i++) {
								if ("豹子".equals(h3[i])) {
									if (d[2] == d[3] && d[2] == d[4]) {
										a = 1;
									}
								}
								if ("顺子".equals(h3[i])) {
									if (d[2] + 1 == d[3] && d[2] + 2 == d[4]) {
										b = 1;
									} else if (d[2] + 2 == d[3] && d[2] + 1 == d[4]) {
										b = 1;
									} else if (d[2] - 1 == d[3] && d[2] + 1 == d[4]) {
										b = 1;
									} else if (d[2] + 1 == d[3] && d[2] - 1 == d[4]) {
										b = 1;
									} else if (d[2] - 2 == d[3] && d[2] - 1 == d[4]) {
										b = 1;
									} else if (d[2] - 1 == d[3] && d[2] - 2 == d[4]) {
										b = 1;
									}
									for (int i1 = 0; i1 < rule.length; i1++) {
										if (("" + d[2] + d[3] + d[4]).equals(rule[i1])) {
											b = 1;
										}
									}
								}
								if ("对子".equals(h3[i])) {
									if (d[2] != d[3] || d[2] != d[4]) {
										if (d[2] == d[3] || d[2] == d[4] || d[3] == d[4]) {
											c = 1;
										}
									}
								}
								if ("半顺".equals(h3[i])) {
									boolean flag1 = !(d[2] + 1 == d[3] && d[2] + 2 == d[4]);
									boolean flag2 = !(d[2] + 2 == d[3] && d[2] + 1 == d[4]);
									boolean flag3 = !(d[2] - 1 == d[3] && d[2] + 1 == d[4]);
									boolean flag4 = !(d[2] + 1 == d[3] && d[2] - 1 == d[4]);
									boolean flag5 = !(d[2] - 2 == d[3] && d[2] - 1 == d[4]);
									boolean flag6 = !(d[2] - 1 == d[3] && d[2] - 2 == d[4]);
									boolean flag13 = d[2] != d[3] && d[2] != d[4];
									boolean flag14 = d[2] != d[3];
									boolean flag15 = d[2] != d[4];
									boolean flag16 = d[3] != d[4];
									for (int p = 0; p < rule.length; p++) {
										boolean flag17 = !("" + d[2] + d[3] + d[4]).equals(rule[p]);
										if (flag1 && flag2 && flag3 && flag4 && flag5 && flag6 && flag13 && flag14 && flag15
												&& flag16) {
											if (d[2] + 1 == d[3] || d[2] + 1 == d[4] || d[2] - 1 == d[3] || d[2] - 1 == d[4]
													|| d[3] + 1 == d[4] || d[3] - 1 == d[4]) {
												if (flag17) {
													e = 1;
												}
												if (flag17 == false) {
													e = 0;
													break;
												}
											}
										}
									}
									for (int x = 0; x < rule2.length; x++) {
										if (("" + d[2] + d[3] + d[4]).equals(rule2[x])) {
											e = 1;
										}
									}
								}
								if ("杂六".equals(h3[i])) {
									boolean flag1 = d[2] + 1 != d[3];
									boolean flag2 = d[2] + 1 != d[4];
									boolean flag3 = d[2] - 1 != d[3];
									boolean flag4 = d[2] - 1 != d[4];
									boolean flag5 = d[3] - 1 != d[4];
									boolean flag6 = d[3] + 1 != d[4];
									boolean flag7 = d[2] != d[3];
									boolean flag8 = d[2] != d[4];
									boolean flag9 = d[3] != d[4];
									boolean flag17 = true;
									boolean flag18 = true;
									String qius = "" + d[2] + d[3] + d[4];
									for (int m = 0; m < rule.length; m++) {
										if (rule[m].equals(qius)) {
											flag17 = false;
										}
									}
									for (int m = 0; m < rule2.length; m++) {
										if (rule2[m].equals(qius)) {
											flag18 = false;
										}
		
									}
									boolean flag = flag1 && flag2 && flag3 && flag4 && flag5 && flag6 && flag7 && flag8 && flag9
											&& flag17 && flag18;
									if (flag) {
										f = 1;
									}
								}
							}
							count9 = a + b + c + e + f;
								money9 = a * oMoney * co.ratio(user,pv9[0]) + b * oMoney * co.ratio(user,pv9[1])
								+ c * oMoney * co.ratio(user,pv9[2]) + e * oMoney * co.ratio(user,pv9[3])
								+ f * oMoney * co.ratio(user,pv9[4]);
						}
						// 前二直选
						if (q2zhx0.length != 0 && !"".equals(q2zhx0[0])) {
							if (q2zhx1.length != 0 && !"".equals(q2zhx1[0])) {
								for (int i = 0; i < q2zhx0.length; i++) {
									for (int j = 0; j < q2zhx1.length; j++) {
										if (q2zhx0[i].equals(data[0]) && q2zhx1[j].equals(data[1])) {
											count10 = 1;
										}
									}
								}
							}
								money10 = count10 * oMoney * co.ratio(user,pv10[0]);
						}
						// 后二直选
						if (h2zhx0.length != 0 && !"".equals(h2zhx0[0])) {
							if (h2zhx1.length != 0 && !"".equals(h2zhx1[0])) {
								for (int i = 0; i < h2zhx0.length; i++) {
									for (int j = 0; j < h2zhx1.length; j++) {
										if (h2zhx0[i].equals(data[3]) && h2zhx1[j].equals(data[4])) {
											count11 = 1;
										}
									}
								}
							}
								money11 = count11 * oMoney * co.ratio(user,pv11[0]);
						}
						// 前三直选
						if (q3zhxx0.length != 0 && !"".equals(q3zhxx0[0])) {
							if (q3zhxx1.length != 0 && !"".equals(q3zhxx1[0])) {
								if (q3zhxx2.length != 0 && !"".equals(q3zhxx2[0])) {
									for (int i = 0; i < q3zhxx0.length; i++) {
										for (int j = 0; j < q3zhxx1.length; j++) {
											for (int k = 0; k < q3zhxx2.length; k++) {
												if (q3zhxx0[i].equals(data[0]) && q3zhxx1[j].equals(data[1])
														&& q3zhxx2[k].equals(data[2])) {
													count12 = 1;
												}
											}
										}
									}
								}
							}
								money12 = count12 * oMoney * co.ratio(user,pv12[0]);
						}
						// 中三直选
						if (z3zhx0.length != 0 && !"".equals(z3zhx0[0])) {
							if (z3zhx1.length != 0 && !"".equals(z3zhx1[0])) {
								if (z3zhx2.length != 0 && !"".equals(z3zhx2[0])) {
									for (int i = 0; i < z3zhx0.length; i++) {
										for (int j = 0; j < z3zhx1.length; j++) {
											for (int k = 0; k < z3zhx2.length; k++) {
												if (z3zhx0[i].equals(data[1]) && z3zhx1[j].equals(data[2])
														&& z3zhx2[k].equals(data[3])) {
													count13 = 1;
												}
											}
										}
									}
								}
							}
								money13 = count13 * oMoney * co.ratio(user,pv13[0]);
						}
						// 后三直选
						if (h3zhx0.length != 0 && !"".equals(h3zhx0[0])) {
							if (h3zhx1.length != 0 && !"".equals(h3zhx1[0])) {
								if (h3zhx2.length != 0 && !"".equals(h3zhx2[0])) {
									for (int i = 0; i < h3zhx0.length; i++) {
										for (int j = 0; j < h3zhx1.length; j++) {
											for (int k = 0; k < h3zhx2.length; k++) {
												if (h3zhx0[i].equals(data[2]) && h3zhx1[j].equals(data[3])
														&& h3zhx2[k].equals(data[4])) {
													count14 = 1;
												}
											}
										}
									}
								}
							}
								money14 = count14 * oMoney * co.ratio(user,pv14[0]);
						}
						// 前二组选
						if (q2zxx.length != 0 && !"".equals(q2zxx[0])) {
							for (int i = 0; i < q2zxx.length; i++) {
								for (int j = 0; j < q2zxx.length; j++) {
									if (q2zxx[i].equals(data[0]) && q2zxx[j].equals(data[1]) && !data[0].equals(data[1])) {
										count15 = 1;
									}
								}
							}
								money15 = count15 * oMoney * co.ratio(user,pv15[0]);
						}
						// 后二组选
						if (h2zxx.length != 0 && !"".equals(h2zxx[0])) {
							for (int i = 0; i < h2zxx.length; i++) {
								for (int j = 0; j < h2zxx.length; j++) {
									if (h2zxx[i].equals(data[3]) && h2zxx[j].equals(data[4]) && !data[0].equals(data[1])) {
										count16 = 1;
									}
								}
							}
								money16 = count16 * oMoney * co.ratio(user,pv16[0]);
						}
						// 前三组六
						if (q3z6.length != 0 && !"".equals(q3z6[0])) {
							for (int i = 0; i < q3z6.length; i++) {
								for (int j = 0; j < q3z6.length; j++) {
									for (int k = 0; k < q3z6.length; k++) {
										if (data[0].equals(q3z6[i]) && data[1].equals(q3z6[j]) && data[2].equals(q3z6[k])) {
											if (!data[0].equals(data[1]) && !data[0].equals(data[2])
													&& !data[1].equals(data[2])) {
												count17 = 1;
											}
										}
									}
								}
							}
								money17 = count17 * oMoney * co.ratio(user,pv17[0]);
						}
						// 中三组六
						if (z3z6.length != 0 && !"".equals(z3z6[0])) {
							for (int i = 0; i < z3z6.length; i++) {
								for (int j = 0; j < z3z6.length; j++) {
									for (int k = 0; k < z3z6.length; k++) {
										if (data[1].equals(z3z6[i]) && data[2].equals(z3z6[j]) && data[3].equals(z3z6[k])) {
											if (!data[0].equals(data[1]) && !data[0].equals(data[2])
													&& !data[1].equals(data[2])) {
												count18 = 1;
											}
										}
									}
								}
							}
								money18 = count18 * oMoney * co.ratio(user,pv18[0]);
						}
						// 后三组六
						if (h3z6.length != 0 && !"".equals(h3z6[0])) {
							for (int i = 0; i < h3z6.length; i++) {
								for (int j = 0; j < h3z6.length; j++) {
									for (int k = 0; k < h3z6.length; k++) {
										if (data[2].equals(h3z6[i]) && data[3].equals(h3z6[j]) && data[4].equals(h3z6[k])) {
											if (!data[0].equals(data[1]) && !data[0].equals(data[2])
													&& !data[1].equals(data[2])) {
												count19 = 1;
											}
										}
									}
								}
							}
								money19 = count19 * oMoney * co.ratio(user,pv19[0]);
						}
						// 前三组三
						if (q3z3.length != 0 && !"".equals(q3z3[0])) {
							for (int i = 0; i < q3z3.length; i++) {
								for (int j = 0; j < q3z3.length; j++) {
									for (int k = 0; k < q3z3.length; k++) {
										if (q3z3[i].equals(data[0]) && q3z3[j].equals(data[1]) && q3z3[k].equals(data[2])) {
											if (d[0] == d[1] || d[0] == d[2] || d[1] == d[2]) {
												count20 = 1;
											}
										}
									}
								}
							}
								money20 = count20 * oMoney * co.ratio(user,pv20[0]);
						}
						// 中三组三
						if (z3z3.length != 0 && !"".equals(z3z3[0])) {
							for (int i = 0; i < z3z3.length; i++) {
								for (int j = 0; j < z3z3.length; j++) {
									for (int k = 0; k < z3z3.length; k++) {
										if (z3z3[i].equals(data[1]) && z3z3[j].equals(data[2]) && z3z3[k].equals(data[3])) {
											if (d[1] == d[2] || d[1] == d[3] || d[2] == d[3]) {
												count21 = 1;
											}
										}
									}
								}
							}
								money21 = count21 * oMoney * co.ratio(user,pv21[0]);
						}
						// 后三组三
						if (h3z3.length != 0 && !"".equals(h3z3[0])) {
							for (int i = 0; i < h3z3.length; i++) {
								for (int j = 0; j < h3z3.length; j++) {
									for (int k = 0; k < h3z3.length; k++) {
										if (h3z3[i].equals(data[2]) && h3z3[j].equals(data[3]) && h3z3[k].equals(data[4])) {
											if (d[2] == d[3] || d[2] == d[4] || d[3] == d[4]) {
												count22 = 1;
											}
										}
									}
								}
							}
								money22 = count22 * oMoney * co.ratio(user,pv22[0]);
						}
		
						break;
					case "ahk3":
					case "gxk3":
					case "jsk3":
					case "bjk3":
					case "jlk3":
					case "3fk3":
					case "2fk3":
						String[] c1gh = order.getStr1().split(",");
						String[] slhtx = order.getStr2().split(",");
						String[] ethfx = order.getStr3().split(",");
						String[] ethdx0 = order.getStr4().split(",");
						String[] ethdx1 = order.getStr5().split(",");
						String[] ebth = order.getStr6().split(",");
						String[] ebthdt0 = order.getStr7().split(",");
						String[] ebthdt1 = order.getStr8().split(",");
						String[] sthtx = order.getStr9().split(",");
						String[] sthdx = order.getStr10().split(",");
						String[] sbth = order.getStr11().split(",");
						String[] xt = order.getStr12().split(",");
						String[] zhhz = order.getStr13().split(",");
						String[] qiu3 = { "11", "22", "33", "44", "55", "66" };
						String[] qiu4 = { "111", "222", "333", "444", "555", "666", };
						String[] qiu5 = { "3", "4", "5", "6", "7", "8", "9", "10", "11", "12", "13", "14", "15", "16", "17",
								"18", "大", "小", "单", "双" };
						// 猜一个号
						if (c1gh.length != 0 && !"".equals(c1gh[0])) {
							int a1 = 0;
							int a2 = 0;
							int a3 = 0;
							int a4 = 0;
							int a5 = 0;
							int a6 = 0;
							int b1 = 0;
							int b2 = 0;
							int b3 = 0;
							int c1 = 0;
							int c2 = 0;
							int c3 = 0;
							int m = 0;
							int lc = order.getLottercount();
							for (int i = 0; i < c1gh.length; i++) {
								if (c1gh[i].equals(data[0])) {
									m += 1;
								}
								if (c1gh[i].equals(data[1])) {
									m += 1;
								}
								if (c1gh[i].equals(data[2])) {
									m += 1;
								}
							}
							if (m == 3 && (d[0] == d[1]) && d[0] == d[2]) {
								a1 = 1;
							} else if (d[0] == d[1] || d[0] == d[2] || d[1] == d[2]) {
								if (m == 3) {
									b1 = 1;
								} else if (m == 2) {
									b2 = 1;
								} else if (m == 1) {
									b3 = 1;
								}
							} else {
								if (m == 3) {
									c1 = 1;
								} else if (m == 2) {
									c2 = 1;
								} else if (m == 1) {
									c3 = 1;
								}
							}
							double plv1 = Double.parseDouble(pv1[0]);
							double plv2 = Double.parseDouble(pv1[1]);
							double plv3 = Double.parseDouble(pv1[2]);
							count1 = a1 + b1 + b2 + b3 + c1 + c2 + c3;
								money1 = oMoney * a1 * co.ratio(user,plv1+"") + oMoney * b1 * co.ratio(user,plv2+"") + oMoney * b2 * co.ratio(user,plv2+"") + oMoney * b3 * co.ratio(user,plv2+"")
										+ oMoney * c1 * co.ratio(user,plv3+"") + oMoney * c2 * co.ratio(user,plv3+"") + oMoney * c3 * co.ratio(user,plv3+"");
						}
						// 三连号通选
						if (slhtx.length != 0 && !"".equals(slhtx[0])) {
							if ("三连号通选".equals(slhtx[0])) {
								if (d[0] + 1 == d[1] && d[0] + 2 == d[2]) {
									count2 = 1;
								}
							}
								money2 = count2 * oMoney * co.ratio(user,pv2[0]);
						}
						// 二同号复选
						if (ethfx.length != 0 && !"".equals(ethfx[0])) {
							int b = 0;
							for (int i = 0; i < ethfx.length; i++) {
								for (int j = 0; j < qiu3.length; j++) {
									int s = (Integer.parseInt(ethfx[i])) / 11;
									if (ethfx[i].equals(qiu3[j]) && (s == d[0] && s == d[1] && d[0] == d[1])) {
										count3 = 1;
										b = j;
									}
									if (ethfx[i].equals(qiu3[j]) && (s == d[1] && s == d[2] && d[1] == d[2])) {
										count3 = 1;
										b = j;
									}
								}
							}
								money3 = count3 * oMoney * co.ratio(user,pv3[b]);
						}
						// 二同号单选
						if (ethdx0.length != 0 && !"".equals(ethdx0[0])) {
							if (ethdx1.length != 0 && !"".equals(ethdx1[0])) {
								for (int i = 0; i < ethdx0.length; i++) {
									for (int j = 0; j < ethdx1.length; j++) {
										int x1 = Integer.parseInt(ethdx0[i]) / 11;
										int x2 = Integer.parseInt(ethdx1[j]);
										if (d[0] == d[1] && x1 == d[0] && x1 == d[1] && x2 == d[2]) {
											count4 = 1;
										}
										if (d[1] == d[2] && x2 == d[0] && x1 == d[1] && x1 == d[2]) {
											count4 = 1;
										}
									}
								}
							}
								money4 = count4 * oMoney * co.ratio(user,pv4[0]);
						}
						// 二不同号
						if (ebth.length != 0 && !"".equals(ebth[0])) {
							for (int i = 0; i < data.length; i++) {
								for (int j = 0; j < ebth.length; j++) {
									if (ebth[j].equals(data[i])) {
										count5++;
									}
								}
							}
							if (count5 > 1) {
								count5 = 1;
							} else {
								count5 = 0;
							}
								money5 = count5 * oMoney * co.ratio(user,pv5[0]);
						}
						// 二不同号胆拖
						if (ebthdt0.length != 0 && !"".equals(ebthdt0[0])) {
							if (ebthdt1.length != 0 && !"".equals(ebthdt1[0])) {
								for (int j = 0; j < ebthdt0.length; j++) {
									for (int k = 0; k < ebthdt1.length; k++) {
										for (int i = 0; i < data.length; i++) {
											if (ebthdt0[j].equals(data[i]) || ebthdt1[k].equals(data[i])) {
												count6++;
											}
										}
									}
								}
								if (count6 > 1) {
									count6 = 1;
								} else {
									count6 = 0;
								}
							}
								money6 = count6 * oMoney * co.ratio(user,pv6[0]);
						}
						// 三同号通选
						if (sthtx.length != 0 && !"".equals(sthtx[0])) {
							if (d[0] == d[1] && d[0] == d[2]) {
								count7 = 1;
							}
								money7 = count7 * oMoney * co.ratio(user,pv7[0]);
						}
						// 三同号单选
						if (sthdx.length != 0 && !"".equals(sthdx[0])) {
							int b = 0;
							for (int i = 0; i < sthdx.length; i++) {
								for (int j = 0; j < qiu4.length; j++) {
									int x1 = Integer.parseInt(sthdx[i]) / 111;
									if (sthdx[i].equals(qiu4[j]) && (d[0] == d[1]) && (d[0] == d[2]) && (x1 == d[0])
											&& (x1 == d[1]) && (x1 == d[2])) {
										count8 = 1;
										b = j;
									}
								}
							}
								money8 = count8 * oMoney *co.ratio(user,pv8[b]);
						}
						// 三不同号
						if (sbth.length != 0 && !"".equals(sbth[0])) {
							for (int i = 0; i < sbth.length; i++) {
								int x1 = Integer.parseInt(sbth[i]);
								for (int j = 0; j < d.length; j++) {
									if (d[0] != d[1] && d[0] != d[2] && d[1] != d[2]) {
										if (x1 == d[j]) {
											count9++;
										}
									}
								}
							}
							if (count9 == 3) {
								count9 = 1;
							} else {
								count9 = 0;
							}
								money9 = count9 * oMoney * co.ratio(user,pv9[0]);
						}
						// 形态
						if (xt.length != 0 && !"".equals(xt[0])) {
							int a = 0;
							int b = 0;
							int c = 0;
							int e = 0;
							int m = 0;
							for (int i = 0; i < xt.length; i++) {
								if ("豹子".equals(xt[i])) {
									if (d[0] == d[1] && d[0] == d[2]) {
										a = 1;
									}
								} else if ("顺子".equals(xt[i])) {
									if (d[0] + 1 == d[1] && d[0] + 2 == d[2]) {
										b = 1;
									} else if (d[0] + 2 == d[1] && d[0] + 1 == d[2]) {
										b = 1;
									} else if (d[0] - 1 == d[1] && d[0] + 1 == d[2]) {
										b = 1;
									} else if (d[0] + 1 == d[1] && d[0] - 1 == d[2]) {
										b = 1;
									} else if (d[0] - 2 == d[1] && d[0] - 1 == d[2]) {
										b = 1;
									} else if (d[0] - 1 == d[1] && d[0] - 2 == d[2]) {
										b = 1;
									}
								} else if ("对子".equals(xt[i])) {
									if ((d[0] != d[1] || d[0] != d[2])) {
										if (d[0] == d[1] || d[0] == d[2] || d[1] == d[2]) {
											c = 1;
										}
									}
								} else if ("半顺".equals(xt[i])) {
									boolean flag1 = !(d[0] + 1 == d[1] && d[0] + 2 == d[2]);
									boolean flag2 = !(d[0] + 2 == d[1] && d[0] + 1 == d[2]);
									boolean flag3 = !(d[0] - 1 == d[1] && d[0] + 1 == d[2]);
									boolean flag4 = !(d[0] + 1 == d[1] && d[0] - 1 == d[2]);
									boolean flag5 = !(d[0] - 2 == d[1] && d[0] - 1 == d[2]);
									boolean flag6 = !(d[0] - 1 == d[1] && d[0] - 2 == d[2]);
									boolean flag13 = d[0] != d[1] && d[0] != d[2];
									boolean flag14 = d[0] != d[1];
									boolean flag15 = d[0] != d[2];
									boolean flag16 = d[1] != d[2];
									if (flag1 && flag2 && flag3 && flag4 && flag5 && flag6 && flag13 && flag14 && flag15
											&& flag16) {
										if (d[0] + 1 == d[1] || d[0] + 1 == d[2] || d[0] - 1 == d[1] || d[0] - 1 == d[2]
												|| d[1] + 1 == d[2] || d[1] - 1 == d[2]) {
											e = 1;
										}
									}
								} else if ("杂六".equals(xt[i])) {
									boolean flag1 = d[0] + 1 != d[1];
									boolean flag2 = d[0] + 1 != d[2];
									boolean flag3 = d[1] + 1 != d[2];
									boolean flag4 = d[0] - 1 != d[1];
									boolean flag5 = d[0] - 1 != d[2];
									boolean flag6 = d[1] - 1 != d[2];
									boolean flag13 = d[0] != d[1] && d[0] != d[2];
									boolean flag14 = d[0] != d[1];
									boolean flag15 = d[0] != d[2];
									boolean flag16 = d[1] != d[2];
									if (flag1 && flag2 && flag3 && flag4 && flag5 && flag6) {
										if (flag13 && (flag14 || flag15 || flag16)) {
											m = 1;
										}
									}
								}
							}
							count10 = a + b + c + e + m;
								money10 = a * oMoney * co.ratio(user,pv10[0]) + b * oMoney * co.ratio(user,pv10[1])
								+ c * oMoney * co.ratio(user,pv10[2]) + e * oMoney * co.ratio(user,pv10[3])
								+ m * oMoney * co.ratio(user,pv10[4]);
						}
						// 总和-和值
						if (zhhz.length != 0 && !"".equals(zhhz[0])) {
							int o = (d[0] + d[1] + d[2]);
							int a1 = 0;
							int a2 = 0;
							int a3 = 0;
							int a4 = 0;
							int a5 = 0;
							int b = 0;
							for (int i = 0; i < zhhz.length; i++) {
								for (int j = 0; j < qiu5.length; j++) {
									if (zhhz[i].equals(o + "") && zhhz[i].equals(qiu5[j])) {
										a1 = 1;
										b = j;
									}
									if (zhhz[i].equals("大")) {
										if (o  > 10 && o < 19) {
											a2 = 1;
										}
									}
									if (zhhz[i].equals("小")) {
										if (o < 11 && o > 2) {
											a3 = 1;
										}
									}
									if (zhhz[i].equals("单")) {
										if (o % 2 != 0) {
											a4 = 1;
										}
									}
									if (zhhz[i].equals("双")) {
										if (o % 2 == 0) {
											a5 = 1;
										}
									}
		
								}
							}
							count11 = a1 + a2 + a3 + a4 + a5;
								money11 = a1 * oMoney * co.ratio(user,pv11[b]) + a2 * oMoney * co.ratio(user,pv11[16])
								+ a3 * oMoney * co.ratio(user,pv11[17]) + a4 * oMoney * co.ratio(user,pv11[18])
								+ a5 * oMoney * co.ratio(user,pv11[19]);
						}
						break;
					case "gdkl10f":
					case "cqkl10f":
						String[] swst = order.getStr1().split(",");
						String[] swht = order.getStr2().split(",");
						String[] elzhix0 = order.getStr3().split(",");
						String[] elzhix1 = order.getStr4().split(",");
						String[] elzx = order.getStr5().split(",");
						String[] q3zhix0 = order.getStr6().split(",");
						String[] q3zhix1 = order.getStr7().split(",");
						String[] q3zhix2 = order.getStr8().split(",");
						String[] q3zx = order.getStr9().split(",");
						String[] kl2 = order.getStr10().split(",");
						String[] kl3 = order.getStr11().split(",");
						String[] kl4 = order.getStr12().split(",");
						String[] kl5 = order.getStr13().split(",");
						String[] qiu6 = { "01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12", "13", "14",
								"15", "16", "17", "18" };
						// 首位数投
						if (swst.length != 0 && !"".equals(swst[0])) {
							int b = 0;
							for (int i = 0; i < swst.length; i++) {
								for (int j = 0; j < qiu6.length; j++) {
									if (data[0].equals(swst[i]) && swst[i].equals(qiu6[j])) {
										count1 = 1;
										b = j;
									}
								}
							}
								money1 = count1 * oMoney * co.ratio(user,pv1[b]);
						}
						// 首位红投
						if (swht.length != 0 && !"".equals(swht[0])) {
							int a1 = 0;
							int a2 = 0;
							for (int i = 0; i < swht.length; i++) {
								if (swht[i].equals("19")) {
									if (swht[i].equals(data[0])) {
										a1 = 1;
									}
								}
								if (swht[i].equals("20")) {
									if (swht[i].equals(data[0])) {
										a2 = 1;
									}
								}
							}
							count2 = a1 + a2;
								money2 = a1 * oMoney * co.ratio(user,pv2[0]) + a2 * oMoney * co.ratio(user,pv2[1]);
						}
						// 二连直选
						if (elzhix0.length != 0 && !"".equals(elzhix0[0])) {
							if (elzhix1.length != 0 && !"".equals(elzhix1[0])) {
								for (int i = 1; i < data.length; i++) {
									for (int j = 0; j < elzhix0.length; j++) {
										for (int k = 0; k < elzhix1.length; k++) {
											if (data[i - 1].equals(elzhix0[j])) {
												if (data[i].equals(elzhix1[k])) {
													count3++;
												}
											}
										}
									}
								}
							}
							if (count3 > 0) {
								count3 = 1;
							} else {
								count3 = 0;
							}
								money3 = count3 * oMoney * co.ratio(user,pv3[0]);
						}
						// 二连组选
						if (elzx.length != 0 && !"".equals(elzx[0])) {
							for (int j = 0; j < elzx.length; j++) {
								for (int k = 0; k < elzx.length; k++) {
									for (int i = 0; i < data.length - 1; i++) {
										if (elzx[j].equals(data[i])) {
											if (j != k) {
												if (elzx[k].equals(data[i + 1])) {
													if (!data[0].equals(data[1])) {
														count4++;
													}
												}
											}
										}
									}
								}
							}
								money4 = count4 * oMoney * co.ratio(user,pv4[0]);
						}
						// 前三直选
						if (q3zhix0.length != 0 && !"".equals(q3zhix0[0])) {
							if (q3zhix1.length != 0 && !"".equals(q3zhix1[0])) {
								if (q3zhix2.length != 0 && !"".equals(q3zhix2[0])) {
									for (int i = 0; i < q3zhix0.length; i++) {
										for (int j = 0; j < q3zhix1.length; j++) {
											for (int k = 0; k < q3zhix2.length; k++) {
												if (q3zhix0[i].equals(data[0]) && q3zhix1[j].equals(data[1])
														&& q3zhix2[k].equals(data[2])) {
													count5 = 1;
												}
											}
										}
									}
								}
							}
								money5 = count5 * oMoney * co.ratio(user,pv5[0]);
						}
						// 前三组选
						if (q3zx.length != 0 && !"".equals(q3zx[0])) {
							for (int i = 0; i < q3zx.length; i++) {
								for (int j = 0; j < q3zx.length; j++) {
									for (int k = 0; k < q3zx.length; k++) {
										if (data[0].equals(q3zx[i]) && data[1].equals(q3zx[j]) && data[2].equals(q3zx[k])) {
											if (!data[0].equals(data[1]) && !data[1].equals(data[2])
													&& !data[0].equals(data[2])) {
												count6 = 1;
											}
										}
		
									}
								}
							}
								money6 = count6 * oMoney * co.ratio(user,pv6[0]);
						}
						// 快乐2
						if (kl2.length != 0 && !"".equals(kl2[0])) {
							ArrayList<String> a1Arr = new ArrayList<>();
							ArrayList<String> a2Arr = new ArrayList<>();
							Combine.combine(0, 2, kl2, a1Arr);
							Combine.combine(0, 2, data, a2Arr);
							for (int i = 0; i < a1Arr.size(); i++) {
								for (int j = 0; j < a2Arr.size(); j++) {
									if (a1Arr.get(i).toString().equals(a2Arr.get(j).toString())) {
										count7++;
									}
								}
							}
								money7 = count7 * oMoney * co.ratio(user,pv7[0]);
						}
						// 快乐3
						if (kl3.length != 0 && !"".equals(kl3[0])) {
							ArrayList<String> a1Arr = new ArrayList<>();
							ArrayList<String> a2Arr = new ArrayList<>();
							Combine.combine(0, 3, kl3, a1Arr);
							Combine.combine(0, 3, data, a2Arr);
							for (int i = 0; i < a1Arr.size(); i++) {
								for (int j = 0; j < a2Arr.size(); j++) {
									if (a1Arr.get(i).toString().equals(a2Arr.get(j).toString())) {
										count8++;
									}
								}
							}
								money8 = count8 * oMoney * co.ratio(user,pv8[0]);
						}
						// 快乐4
						if (kl4.length != 0 && !"".equals(kl4[0])) {
							ArrayList<String> a1Arr = new ArrayList<>();
							ArrayList<String> a2Arr = new ArrayList<>();
							Combine.combine(0, 4, kl4, a1Arr);
							Combine.combine(0, 4, data, a2Arr);
							for (int i = 0; i < a1Arr.size(); i++) {
								for (int j = 0; j < a2Arr.size(); j++) {
									if (a1Arr.get(i).toString().equals(a2Arr.get(j).toString())) {
										count9++;
									}
								}
							}
								money9 = count9 * oMoney * co.ratio(user,pv9[0]);
						}
						// 快乐5
						if (kl5.length != 0 && !"".equals(kl5[0])) {
							ArrayList<String> a1Arr = new ArrayList<>();
							ArrayList<String> a2Arr = new ArrayList<>();
							Combine.combine(0, 5, kl5, a1Arr);
							Combine.combine(0, 5, data, a2Arr);
							for (int i = 0; i < a1Arr.size(); i++) {
								for (int j = 0; j < a2Arr.size(); j++) {
									if (a1Arr.get(i).toString().equals(a2Arr.get(j).toString())) {
										count10++;
									}
								}
							}
								money10 = count10 * oMoney * co.ratio(user,pv10[0]);
						}
						break;
		
					case "shssl":
					case "pl3":
					case "fc3d":
						String[] q2zhix0 = order.getStr1().split(",");
						String[] q2zhix1 = order.getStr2().split(",");
						String[] q2zx = order.getStr3().split(",");
						String[] h2zhix0 = order.getStr4().split(",");
						String[] h2zhix1 = order.getStr5().split(",");
						String[] h2zx = order.getStr6().split(",");
						String[] sxzhix0 = order.getStr7().split(",");
						String[] sxzhix1 = order.getStr8().split(",");
						String[] sxzhix2 = order.getStr9().split(",");
						String[] sxhz = order.getStr10().split(",");
						String[] sxz3 = order.getStr11().split(",");
						String[] z3hz = order.getStr12().split(",");
						String[] sxz6 = order.getStr13().split(",");
						String[] z6hz = order.getStr14().split(",");
						// 前二直选
						if (q2zhix0.length != 0 && !"".equals(q2zhix0[0])) {
							if (q2zhix1.length != 0 && !"".equals(q2zhix1[0])) {
								for (int i = 0; i < q2zhix0.length; i++) {
									for (int j = 0; j < q2zhix1.length; j++) {
										if (data[0].equals(q2zhix0[i])) {
											if (data[1].equals(q2zhix1[j])) {
												count1 = 1;
											}
										}
									}
								}
							}
								money1 = count1 * oMoney * co.ratio(user,pv1[0]);
						}
						// 前二组选
						if (q2zx.length != 0 && !"".equals(q2zx[0])) {
							for (int i = 0; i < q2zx.length; i++) {
								for (int j = 0; j < q2zx.length; j++) {
									if (data[0].equals(q2zx[i]) && data[1].equals(q2zx[j])) {
										if (!data[0].equals(data[1])) {
											count2 = 1;
										}
									}
								}
							}
								money2 = count2 * oMoney * co.ratio(user,pv2[0]);
						}
						// 后二直选
						if (h2zhix0.length != 0 && !"".equals(h2zhix0[0])) {
							if (h2zhix1.length != 0 && !"".equals(h2zhix1[0])) {
								for (int i = 0; i < h2zhix0.length; i++) {
									for (int j = 0; j < h2zhix1.length; j++) {
										if (data[1].equals(h2zhix0[i])) {
											if (data[2].equals(h2zhix1[j])) {
												count3 = 1;
											}
										}
									}
								}
							}
								money3 = count3 * oMoney * co.ratio(user,pv3[0]);
						}
						// 后二组选
						if (h2zx.length != 0 && !"".equals(h2zx[0])) {
							for (int i = 0; i < h2zx.length; i++) {
								for (int j = 0; j < h2zx.length; j++) {
									if (data[1].equals(h2zx[i]) && data[2].equals(h2zx[j])) {
										if (!data[1].equals(data[2])) {
											count4 = 1;
										}
									}
								}
							}
								money4 = count4 * oMoney * co.ratio(user,pv4[0]);
						}
						// 三星直选
						if (sxzhix0.length != 0 && !"".equals(sxzhix0[0])) {
							if (sxzhix1.length != 0 && !"".equals(sxzhix1[0])) {
								if (sxzhix2.length != 0 && !"".equals(sxzhix2[0])) {
									for (int i = 0; i < sxzhix0.length; i++) {
										for (int j = 0; j < sxzhix1.length; j++) {
											for (int k = 0; k < sxzhix2.length; k++) {
												if (data[0].equals(sxzhix0[i])) {
													if (data[1].equals(sxzhix1[j])) {
														if (data[2].equals(sxzhix2[k])) {
															count5 = 1;
														}
													}
												}
											}
										}
									}
								}
							}
								money5 = count5 * oMoney * co.ratio(user,pv5[0]);
						}
						// 三星直选和值
						if (sxhz.length != 0 && !"".equals(sxhz[0])) {
							for (int i = 0; i < sxhz.length; i++) {
								String s = (d[0] + d[1] + d[2]) + "";
								if (s.equals(sxhz[i])) {
									count6 = 1;
								}
							}
								money6 = count6 * oMoney * co.ratio(user,pv6[0]);
						}
						// 三星组三
						if (sxz3.length != 0 && !"".equals(sxz3[0])) {
							for (int j = 0; j < sxz3.length; j++) {
								for (int i = 0; i < sxz3.length; i++) {
									for (int k = 0; k < sxz3.length; k++) {
										if (data[0].equals(sxz3[j]) && data[1].equals(sxz3[i]) && data[2].equals(sxz3[k])) {
											if (d[0] == d[1] || d[0] == d[2] || d[1] == d[2]) {
												count7 = 1;
											}
										}
									}
								}
							}
								money7 = count7 * oMoney * co.ratio(user,pv7[0]);
						}
						// 组三和值
						if (z3hz.length != 0 && !"".equals(z3hz[0])) {
							int a = 0;
							String s = (d[0] + d[1] + d[2]) + "";
							for (int i = 0; i < z3hz.length; i++) {
								for (int j = 0; j < data.length; j++) {
									if (z3hz[i].equals(data[j])) {
										a++;
									}
								}
								if (s.equals(z3hz[i]) && a >= 3) {
									count8 = 1;
								}
							}
								money8 = count8 * oMoney * co.ratio(user,pv8[0]);
						}
						// 三星组六
						if (sxz6.length != 0 && !"".equals(sxz6[0])) {
							int a = 0;
							for (int i = 0; i < sxz6.length; i++) {
								if (sxz6[i].equals(data[0]) || sxz6[i].equals(data[1]) || sxz6[i].equals(data[2])) {
									if (d[0] != d[1] || d[0] != d[2] || d[1] != d[2]) {
										a++;
									}
								}
							}
							if (a > 2) {
								count9 = 1;
							}
								money9 = count9 * oMoney * co.ratio(user,pv9[0]);
						}
						// 组六和值
						if (z6hz.length != 0 && !"".equals(z6hz[0])) {
							String s = (d[0] + d[1] + d[2]) + "";
							int a = 0;
							for (int i = 0; i < z6hz.length; i++) {
								if (z6hz[i].equals(data[0]) || z6hz[i].equals(data[1]) || z6hz[i].equals(data[2])) {
									if (d[0] != d[1] || d[0] != d[2] || d[1] != d[2]) {
										a++;
									}
								}
								if (s.equals(z6hz[i]) && a > 2) {
									count10 = 1;
								}
							}
								money10 = count10 * oMoney * co.ratio(user,pv10[0]);
						}
						break;
					case "ah11x5":
					case "gd11x5":
					case "jx11x5":
					case "sd11x5":
					case "sh11x5":
						String[] d1qq = order.getStr1().split(",");
						String[] d2qq = order.getStr2().split(",");
						String[] d3qq = order.getStr3().split(",");
						String[] d4qq = order.getStr4().split(",");
						String[] d5qq = order.getStr5().split(",");
						String[] zh1 = order.getStr6().split(",");
						String[] q1zhix = order.getStr7().split(",");
						String[] q2zhix01 = order.getStr8().split(",");
						String[] q2zhix02 = order.getStr9().split(",");
						String[] q3zhix01 = order.getStr10().split(",");
						String[] q3zhix02 = order.getStr11().split(",");
						String[] q3zhix03 = order.getStr12().split(",");
						String[] rx1 = order.getStr13().split(",");
						String[] rx2 = order.getStr14().split(",");
						String[] rx3 = order.getStr15().split(",");
						String[] rx4 = order.getStr16().split(",");
						String[] rx5 = order.getStr17().split(",");
						String[] rx6 = order.getStr18().split(",");
						String[] rx7 = order.getStr19().split(",");
						String[] rx8 = order.getStr20().split(",");
						String[] qiu7 = { "单", "双", "大", "小", "01", "02", "03", "04", "05", "06", "07", "08", "09", "10",
								"11" };
						String[] qiu8 = { "01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11" };
						// 第1球
						if (d1qq.length != 0 && !"".equals(d1qq[0])) {
							int a1 = 0;
							int a2 = 0;
							int a3 = 0;
							int a4 = 0;
							int a5 = 0;
							int b = 0;
							int c = d[0];
							String c1 = data[0];
							for (int i = 0; i < d1qq.length; i++) {
								if (d1qq[i].equals("单")) {
									if (c % 2 != 0) {
										a1 = 1;
									}
								}
								if (d1qq[i].equals("双")) {
									if (c % 2 == 0) {
										a2 = 1;
									}
								}
								if (d1qq[i].equals("大")) {
									if (c >= 6) {
										a3 = 1;
									}
								}
								if (d1qq[i].equals("小")) {
									if (c <= 5) {
										a4 = 1;
									}
								}
								for (int j = 0; j < qiu7.length; j++) {
									if (d1qq[i].equals(c1) && d1qq[i].equals(qiu7[j])) {
										a5 = 1;
										b = j;
									}
								}
							}
							count1 += a1 + a2 + a3 + a4 + a5;
								money1 = a1 * oMoney * co.ratio(user,pv1[0]) + a2 * oMoney * co.ratio(user,pv1[1])
								+ a3 * oMoney * co.ratio(user,pv1[2]) + a4 * oMoney * co.ratio(user,pv1[3])
								+ a5 * oMoney * co.ratio(user,pv1[b]);
						}
						// 第2球
						if (d2qq.length != 0 && !"".equals(d2qq[0])) {
							int a1 = 0;
							int a2 = 0;
							int a3 = 0;
							int a4 = 0;
							int a5 = 0;
							int b = 0;
							int c = d[1];
							String c1 = data[1];
							for (int i = 0; i < d2qq.length; i++) {
								if (d2qq[i].equals("单")) {
									if (c % 2 != 0) {
										a1 = 1;
									}
								}
								if (d2qq[i].equals("双")) {
									if (c % 2 == 0) {
										a2 = 1;
									}
								}
								if (d2qq[i].equals("大")) {
									if (c >= 6) {
										a3 = 1;
									}
								}
								if (d2qq[i].equals("小")) {
									if (c <= 5) {
										a4 = 1;
									}
								}
								for (int j = 0; j < qiu7.length; j++) {
									if (d2qq[i].equals(c1) && d2qq[i].equals(qiu7[j])) {
										a5 = 1;
										b = j;
									}
								}
							}
							count2 += a1 + a2 + a3 + a4 + a5;
								money2 = a1 * oMoney * co.ratio(user,pv2[0]) + a2 * oMoney * co.ratio(user,pv2[1])
								+ a3 * oMoney * co.ratio(user,pv2[2]) + a4 * oMoney * co.ratio(user,pv2[3])
								+ a5 * oMoney * co.ratio(user,pv2[b]);
						}
						// 第3球
						if (d3qq.length != 0 && !"".equals(d3qq[0])) {
							int a1 = 0;
							int a2 = 0;
							int a3 = 0;
							int a4 = 0;
							int a5 = 0;
							int b = 0;
							int c = d[2];
							String c1 = data[2];
							for (int i = 0; i < d3qq.length; i++) {
								if (d3qq[i].equals("单")) {
									if (c % 2 != 0) {
										a1 = 1;
									}
								}
								if (d3qq[i].equals("双")) {
									if (c % 2 == 0) {
										a2 = 1;
									}
								}
								if (d3qq[i].equals("大")) {
									if (c >= 6) {
										a3 = 1;
									}
								}
								if (d3qq[i].equals("小")) {
									if (c <= 5) {
										a4 = 1;
									}
								}
								for (int j = 0; j < qiu7.length; j++) {
									if (d3qq[i].equals(c1) && d3qq[i].equals(qiu7[j])) {
										a5 = 1;
										b = j;
									}
								}
							}
							count3 += a1 + a2 + a3 + a4 + a5;
								money3 = a1 * oMoney * co.ratio(user,pv3[0]) + a2 * oMoney * co.ratio(user,pv3[1])
								+ a3 * oMoney * co.ratio(user,pv3[2]) + a4 * oMoney * co.ratio(user,pv3[3])
								+ a5 * oMoney * co.ratio(user,pv3[b]);
						}
						// 第4球
						if (d4qq.length != 0 && !"".equals(d4qq[0])) {
							int a1 = 0;
							int a2 = 0;
							int a3 = 0;
							int a4 = 0;
							int a5 = 0;
							int b = 0;
							int c = d[3];
							String c1 = data[3];
							for (int i = 0; i < d4qq.length; i++) {
								if (d4qq[i].equals("单")) {
									if (c % 2 != 0) {
										a1 = 1;
									}
								}
								if (d4qq[i].equals("双")) {
									if (c % 2 == 0) {
										a2 = 1;
									}
								}
								if (d4qq[i].equals("大")) {
									if (c >= 6) {
										a3 = 1;
									}
								}
								if (d4qq[i].equals("小")) {
									if (c <= 5) {
										a4 = 1;
									}
								}
								for (int j = 0; j < qiu7.length; j++) {
									if (d4qq[i].equals(c1) && d4qq[i].equals(qiu7[j])) {
										a5 = 1;
										b = j;
									}
								}
							}
							count4 += a1 + a2 + a3 + a4 + a5;
								money4 = a1 * oMoney * co.ratio(user,pv4[0]) + a2 * oMoney * co.ratio(user,pv4[1])
								+ a3 * oMoney * co.ratio(user,pv4[2]) + a4 * oMoney * co.ratio(user,pv4[3])
								+ a5 * oMoney * co.ratio(user,pv4[b]);
						}
						// 第5球
						if (d5qq.length != 0 && !"".equals(d5qq[0])) {
							int a1 = 0;
							int a2 = 0;
							int a3 = 0;
							int a4 = 0;
							int a5 = 0;
							int b = 0;
							int c = d[4];
							String c1 = data[4];
							for (int i = 0; i < d5qq.length; i++) {
								if (d5qq[i].equals("单")) {
									if (c % 2 != 0) {
										a1 = 1;
									}
								}
								if (d5qq[i].equals("双")) {
									if (c % 2 == 0) {
										a2 = 1;
									}
								}
								if (d5qq[i].equals("大")) {
									if (c >= 6) {
										a3 = 1;
									}
								}
								if (d5qq[i].equals("小")) {
									if (c <= 5) {
										a4 = 1;
									}
								}
								for (int j = 0; j < qiu7.length; j++) {
									if (d5qq[i].equals(c1) && d5qq[i].equals(qiu7[j])) {
										a5 = 1;
										b = j;
									}
								}
							}
							count5 += a1 + a2 + a3 + a4 + a5;
								money5 = a1 * oMoney * co.ratio(user,pv5[0]) + a2 * oMoney * co.ratio(user,pv5[1])
								+ a3 * oMoney * co.ratio(user,pv5[2]) + a4 * oMoney * co.ratio(user,pv5[3])
								+ a5 * oMoney * co.ratio(user,pv5[b]);
						}
						// 总和
						if (zh1.length != 0 && !"".equals(zh1[0])) {
							int a1 = 0;
							int a2 = 0;
							int a3 = 0;
							int a4 = 0;
							int b = 0;
							int c = d[0] + d[1] + d[2] + d[3] + d[4];
							for (int i = 0; i < zh1.length; i++) {
								if ("单".equals(zh1[i])) {
									if (c % 2 != 0) {
										a1 = 1;
									}
								}
								if ("双".equals(zh1[i])) {
									if (c % 2 == 0) {
										a2 = 1;
									}
								}
								if ("大".equals(zh1[i])) {
									if (c > 30) {
										a3 = 1;
									}
								}
								if ("小".equals(zh1[i])) {
									if (c < 30) {
										a4 = 1;
									}
								}
							}
							count6 = a1 + a2 + a3 + a4;
								money6 = a1 * oMoney * co.ratio(user,pv6[0]) + a2 * oMoney * co.ratio(user,pv6[1])
								+ a3 * oMoney * co.ratio(user,pv6[2]) + a4 * oMoney * co.ratio(user,pv6[3]);
						}
						// 前一直选
						if (q1zhix.length != 0 && !"".equals(q1zhix[0])) {
							int b = 0;
							for (int j = 0; j < q1zhix.length; j++) {
								for (int i = 0; i < qiu8.length; i++) {
									if (data[0].equals(q1zhix[j]) && q1zhix[j].equals(qiu8[j])) {
										count7 = 1;
										b = j;
									}
								}
							}
								money7 = count7 * oMoney * co.ratio(user,pv7[b]);
						}
						// 前二直选
						if (q2zhix01.length != 0 && !"".equals(q2zhix01[0])) {
							if (q2zhix02.length != 0 && !"".equals(q2zhix02[0])) {
								for (int j = 0; j < q2zhix01.length; j++) {
									if (data[0].equals(q2zhix01[j])) {
										for (int i = 0; i < q2zhix02.length; i++) {
											if (data[1].equals(q2zhix02[i])) {
												count8 = 1;
											}
										}
									}
								}
							}
								money8 = count8 * oMoney * co.ratio(user,pv8[0]);
						}
		
						// 前三直选
						if (q3zhix01.length != 0 && !"".equals(q3zhix01[0])) {
							if (q3zhix02.length != 0 && !"".equals(q3zhix02[0])) {
								if (q3zhix03.length != 0 && !"".equals(q3zhix03[0])) {
									for (int i = 0; i < q3zhix01.length; i++) {
										if (data[0].equals(q3zhix01[i])) {
											for (int j = 0; j < q3zhix02.length; j++) {
												if (data[1].equals(q3zhix02[j])) {
													for (int k = 0; k < q3zhix03.length; k++) {
														if (data[2].equals(q3zhix03[k])) {
															count9 = 1;
														}
													}
												}
											}
										}
									}
								}
							}
								money9 = count9 * oMoney * co.ratio(user,pv9[0]);
						}
						// 任选1
						if (rx1.length != 0 && !"".equals(rx1[0])) {
							int b = 0;
							for (int i = 0; i < rx1.length; i++) {
								for (int j = 0; j < data.length; j++) {
									for (int k = 0; k < qiu8.length; k++) {
										if (rx1[i].equals(data[j]) && rx1[i].equals(qiu8[k])) {
											count10++;
											b = j;
										}
									}
								}
							}
							if (count10 > 0) {
								count10 = 1;
							} else {
								count10 = 0;
							}
								money10 = count10 * oMoney * co.ratio(user,pv10[b]);
						}
						// 任选2
						if (rx2.length != 0 && !"".equals(rx2[0])) {
							ArrayList<String> a1Arr = new ArrayList<>();
							Combine.combine(0, 2, rx2, a1Arr);
							for (int i = 0; i < a1Arr.size(); i++) {
								int a1 = 0;
								String[] arrs = a1Arr.get(i).split(",");
								for (int j = 0; j < arrs.length; j++) {
									for (int k = 0; k < data.length; k++) {
										if (arrs[j].equals(data[k])) {
											a1++;
										}
									}
								}
								if (a1 == 2) {
									count11++;
								}
							}
								money11 = count11 * oMoney * co.ratio(user,pv11[0]);
						}
						// 任选3
						if (rx3.length != 0 && !"".equals(rx3[0])) {
							ArrayList<String> a1Arr = new ArrayList<>();
							Combine.combine(0, 3, rx3, a1Arr);
							for (int i = 0; i < a1Arr.size(); i++) {
								int a1 = 0;
								String[] arrs = a1Arr.get(i).split(",");
								for (int j = 0; j < arrs.length; j++) {
									for (int k = 0; k < data.length; k++) {
										if (arrs[j].equals(data[k])) {
											a1++;
										}
									}
								}
								if (a1 == 3) {
									count12++;
								}
							}
								money12 = count12 * oMoney * co.ratio(user,pv12[0]);
						}
						// 任选4
						if (rx4.length != 0 && !"".equals(rx4[0])) {
							ArrayList<String> a1Arr = new ArrayList<>();
							Combine.combine(0, 4, rx4, a1Arr);
							for (int i = 0; i < a1Arr.size(); i++) {
								int a1 = 0;
								String[] arrs = a1Arr.get(i).split(",");
								for (int j = 0; j < arrs.length; j++) {
									for (int k = 0; k < data.length; k++) {
										if (arrs[j].equals(data[k])) {
											a1++;
										}
									}
								}
								if (a1 == 4) {
									count13++;
								}
							}
								money13 = count13 * oMoney * co.ratio(user,pv13[0]);
						}
		
						// 任选5
						if (rx5.length != 0 && !"".equals(rx5[0])) {
							ArrayList<String> a1Arr = new ArrayList<>();
							Combine.combine(0, 5, rx5, a1Arr);
							for (int i = 0; i < a1Arr.size(); i++) {
								int a1 = 0;
								String[] arrs = a1Arr.get(i).split(",");
								for (int j = 0; j < arrs.length; j++) {
									for (int k = 0; k < data.length; k++) {
										if (arrs[j].equals(data[k])) {
											a1++;
										}
									}
								}
								if (a1 == 5) {
									count14++;
								}
							}
								money14 = count14 * oMoney * co.ratio(user,pv14[0]);
						}
		
						// 任选6
						if (rx6.length != 0 && !"".equals(rx6[0])) {
							ArrayList<String> a1Arr = new ArrayList<>();
							Combine.combine(0, 6, rx6, a1Arr);
							for (int i = 0; i < a1Arr.size(); i++) {
								int a1 = 0;
								String[] arrs = a1Arr.get(i).split(",");
								for (int j = 0; j < arrs.length; j++) {
									for (int k = 0; k < data.length; k++) {
										if (arrs[j].equals(data[k])) {
											a1++;
										}
									}
								}
								if (a1 == 5) {
									count15++;
								}
							}
								money15 = count15 * oMoney * co.ratio(user,pv15[0]);
						}
		
						// 任选7
						if (rx7.length != 0 && !"".equals(rx7[0])) {
							ArrayList<String> a1Arr = new ArrayList<>();
							Combine.combine(0, 7, rx7, a1Arr);
							for (int i = 0; i < a1Arr.size(); i++) {
								int a1 = 0;
								String[] arrs = a1Arr.get(i).split(",");
								for (int j = 0; j < arrs.length; j++) {
									for (int k = 0; k < data.length; k++) {
										if (arrs[j].equals(data[k])) {
											a1++;
										}
									}
								}
								if (a1 == 5) {
									count16++;
								}
							}
								money16 = count16 * oMoney * co.ratio(user,pv16[0]);
						}
		
						// 任选8
						if (rx8.length != 0 && !"".equals(rx8[0])) {
							ArrayList<String> a1Arr = new ArrayList<>();
							Combine.combine(0, 8, rx8, a1Arr);
							for (int i = 0; i < a1Arr.size(); i++) {
								int a1 = 0;
								String[] arrs = a1Arr.get(i).split(",");
								for (int j = 0; j < arrs.length; j++) {
									for (int k = 0; k < data.length; k++) {
										if (arrs[j].equals(data[k])) {
											a1++;
										}
									}
								}
								if (a1 == 5) {
									count17++;
								}
							}
								money17 = count17 * oMoney * co.ratio(user,pv17[0]);
						}
						break;
					case "xg6hc":
					case "5f6hc":
						String[] tma = order.getStr1().split(",");
						String[] tmb = order.getStr2().split(",");
						String[] tmsx = order.getStr3().split(",");
						String[] dxds = order.getStr4().split(",");
						String[] jqys = order.getStr5().split(",");
						String[] ts = order.getStr6().split(",");
						String[] ws = order.getStr7().split(",");
						String[] wx = order.getStr8().split(",");
						String[] zh2 = order.getStr9().split(",");
						String[] hs = order.getStr10().split(",");
						String[] dp = order.getStr11().split(",");
						String[] p2z2 = order.getStr12().split(",");
						String[] p3z3 = order.getStr13().split(",");
						String[] p3z2 = order.getStr14().split(",");
						String[] sxzt = order.getStr15().split(",");
						String[] wxzt = order.getStr16().split(",");
						String[] lxzt = order.getStr17().split(",");
						String[] pt1x = order.getStr18().split(",");
						String[] pt2x = order.getStr19().split(",");
						String[] pt3x = order.getStr20().split(",");
						String[] pt4x = order.getStr21().split(",");
						String[] pt1w = order.getStr22().split(",");
						String[] pt2w = order.getStr23().split(",");
						String[] pt3w = order.getStr24().split(",");
						String[] pt4w = order.getStr25().split(",");
						String[] wbz = order.getStr26().split(",");
						String[] lbz = order.getStr27().split(",");
						String[] qbz = order.getStr28().split(",");
						String[] bbz = order.getStr29().split(",");
						String[] jbz = order.getStr30().split(",");
						String[] shbz = order.getStr31().split(",");
						String[] sh1bz = order.getStr32().split(",");
						String[] sh2bz = order.getStr33().split(",");
						String[] sh3bz = order.getStr34().split(",");
						String[] sh4bz = order.getStr35().split(",");
						String[] sh5bz = order.getStr36().split(",");
						String[] zx = order.getStr37().split(",");
						String[] sb = order.getStr38().split(",");
						String[] bb = order.getStr39().split(",");
						String[] bbb = order.getStr40().split(",");
		
						/** tmab */
						String[] tm = { "01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12", "13", "14",
								"15", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25", "26", "27", "28", "29", "30",
								"31", "32", "33", "34", "35", "36", "37", "38", "39", "40", "41", "42", "43", "44", "45", "46",
								"47", "48", "49" };
						/** 生肖 1 */
						CheckOrder orc = new CheckOrder();
						Map<String, Object> map = orc.attribute1();
						String[] sx1 = (String[]) map.get("attr");
						String[][] sx2 = (String[][]) map.get("content");
						/** 总和合数 */
						int dh = d[0] + d[1] + d[2] + d[3] + d[4] + d[5] + d[6];
						/** 家禽野兽 */
						String jiax = "牛马羊鸡狗猪";
						String yex = "鼠虎兔龙蛇猴";
						String tianx = "牛兔龙马侯猪";
						String dix = "鼠虎蛇羊鸡狗";
						String[][][] jqyss = new String[4][6][5];
						List<Integer> idss = new ArrayList<Integer>();
						String[] sxss = { "鼠", "牛", "虎", "兔", "龙", "蛇", "马", "羊", "猴", "鸡", "狗", "猪" };
						for (int i10 = 0; i10 < sxss.length; i10++) {
							for (int j10 = 0; j10 < sx1.length; j10++) {
								if (sxss[i10].equals(sx1[j10])) {
									idss.add(j10);
								}
							}
						}
		
						String[] jqysss = { "家肖", "野肖", "天肖", "地肖" };
						/** jiax */
						jqyss[0][0] = sx2[idss.get(1)];
						jqyss[0][1] = sx2[idss.get(6)];
						jqyss[0][2] = sx2[idss.get(7)];
						jqyss[0][3] = sx2[idss.get(9)];
						jqyss[0][4] = sx2[idss.get(10)];
						jqyss[0][5] = sx2[idss.get(11)];
						/** yex */
						jqyss[1][0] = sx2[idss.get(0)];
						jqyss[1][1] = sx2[idss.get(2)];
						jqyss[1][2] = sx2[idss.get(3)];
						jqyss[1][3] = sx2[idss.get(4)];
						jqyss[1][4] = sx2[idss.get(5)];
						jqyss[1][5] = sx2[idss.get(8)];
						/** tianx */
						jqyss[2][0] = sx2[idss.get(1)];
						jqyss[2][1] = sx2[idss.get(3)];
						jqyss[2][2] = sx2[idss.get(4)];
						jqyss[2][3] = sx2[idss.get(6)];
						jqyss[2][4] = sx2[idss.get(8)];
						jqyss[2][5] = sx2[idss.get(11)];
						/** dix */
						jqyss[3][0] = sx2[idss.get(0)];
						jqyss[3][1] = sx2[idss.get(2)];
						jqyss[3][2] = sx2[idss.get(5)];
						jqyss[3][3] = sx2[idss.get(7)];
						jqyss[3][4] = sx2[idss.get(9)];
						jqyss[3][5] = sx2[idss.get(10)];
						/** 头数 */
						String[] t1 = { "0头", "1头", "2头", "3头", "4头" };
						String[][] t2 = { { "01", "02", "03", "04", "05", "06", "07", "08", "09" },
								{ "10", "11", "12", "13", "14", "15", "16", "17", "18", "19" },
								{ "20", "21", "22", "23", "24", "25", "26", "27", "28", "29" },
								{ "30", "31", "32", "33", "34", "35", "36", "37", "38", "39" },
								{ "40", "41", "42", "43", "44", "45", "46", "47", "48", "49" } };
						/** 尾数 */
						String[] w1 = { "0尾", "1尾", "2尾", "3尾", "4尾", "5尾", "6尾", "7尾", "8尾", "9尾" };
						String[][] w2 = { { "10", "20", "30", "40", "50" }, { "01", "11", "21", "31", "41" },
								{ "02", "12", "22", "32", "42" }, { "03", "13", "23", "33", "43" },
								{ "04", "14", "24", "34", "44" }, { "05", "15", "25", "35", "45" },
								{ "06", "16", "26", "36", "46" }, { "07", "17", "27", "37", "47" },
								{ "08", "18", "28", "38", "48" }, { "09", "19", "29", "39", "49" } };
						String[] w3 = { "0", "1", "2", "3", "4", "5", "6", "7", "8", "9" };
						/** 五行 */
						Map<String, Object> maps = orc.attribute2();
						String[] x1 = (String[]) maps.get("attrs");
						String[][] x2 = (String[][]) maps.get("contents");
						/** 合数 */
						int hss = (d[6] % 100) / 10 + d[6] % 10;
						/** 总肖 */
						String[] z1 = { "2肖", "3肖", "4肖", "5肖", "6肖", "7肖" };
						/** 波色-红波-蓝波-绿波 */
						String[] hob = { "01", "02", "07", "08", "12", "13", "18", "19", "23", "24", "29", "30", "34", "35",
								"40", "45", "46" };
						String[] lab = { "03", "04", "09", "10", "14", "15", "20", "25", "26", "31", "36", "37", "41", "42",
								"47", "48" };
						String[] lvb = { "05", "06", "11", "16", "17", "21", "22", "27", "28", "32", "33", "38", "39", "43",
								"44", "49" };
						String[] b1 = { "红", "蓝", "绿" };
						String[][] b2 = {
								{ "01", "02", "07", "08", "12", "13", "18", "19", "23", "24", "29", "30", "34", "35", "40",
										"45", "46" },
								{ "03", "04", "09", "10", "14", "15", "20", "25", "26", "31", "36", "37", "41", "42", "47",
										"48" },
								{ "05", "06", "11", "16", "17", "21", "22", "27", "28", "32", "33", "38", "39", "43", "44",
										"49" } };
						/** 半波 */
						String[] bb1 = { "红大", "红小", "红单", "红双", "蓝大", "蓝小", "蓝单", "蓝双", "绿大", "绿小", "绿单", "绿双" };
						/** 半半波 */
						String[] bbb1 = { "红大单", "红大双", "红小单", "红小双", "蓝大单", "蓝大双", "蓝小单", "蓝小双", "绿大单", "绿大双", "绿小单", "绿小双" };
						// 特码A
						if (tma.length != 0 && !tma[0].equals("")) {
							int a = 0;
							for (int i = 0; i < tma.length; i++) {
								for (int j = 0; j < tm.length; j++) {
									if (tma[i].equals(data[6]) && tm[j].equals(tma[i]) && data[6].equals(tm[j])) {
										if (d[6] == 49) {
											list.add("特码A");
										} else {
											count1 = 1;
											a = j;
										}
									}
								}
							}
								money1 = count1 * oMoney * co.ratio(user,pv1[a]);
						}
						// 特码B
						if (tmb.length != 0 && !tmb[0].equals("")) {
							int a = 0;
							for (int i = 0; i < tmb.length; i++) {
								for (int j = 0; j < tm.length; j++) {
									if (tmb[i].equals(data[6]) && tm[j].equals(tmb[i]) && data[6].equals(tm[j])) {
										if (d[6] == 49) {
											list.add("特码B");
										} else {
											count2 = 1;
											a = j;
										}
									}
								}
							}
								money2 = count2 * oMoney * co.ratio(user,pv2[a]);
							List<GcRebate> gcRebate = orderService.findAllGcRebate(game);
							if (gcRebate.size() > 0) {
								double tmb_money = order.getCount2() * order.getLottermoney();
								Order ors = new Order();
								ors.setOrdernum(order.getOrdernum());
								double gc_rebate = 0.00;
								for (GcRebate gc : gcRebate) {
									if (gc.getGc_state() == 1) {
											if (gc.getGc_rebate() > gc_rebate) {
												gc_rebate = gc.getGc_rebate();
											}
										}
									}
								double rebate_money = tmb_money * gc_rebate;
								ors.setAcount(rebate_money);
								if(game.equals("xg6hc")) {
									ors.setCname1("香港六合彩");
								}else {
									ors.setCname1("五分六合彩");
								}
								// 反水金额
								orderService.GcBettingRebate(user, ors);
							}
						}
		
						// 特码生肖
						if (tmsx.length != 0 && !tmsx[0].equals("")) {
							int a = 0;
							for (int i = 0; i < sx1.length; i++) {
								for (int j = 0; j < sx2[i].length; j++) {
									for (int k = 0; k < tmsx.length; k++) {
										if (sx1[i].equals(tmsx[k]) && sx2[i][j].equals(data[6])) {
											count3 = 1;
											a = i;
										}
									}
								}
							}
								money3 = count3 * oMoney * co.ratio(user,pv3[a]);
						}
						// 大小单双
						if (dxds.length != 0 && !dxds[0].equals("")) {
							int a1 = 0;
							int a2 = 0;
							int a3 = 0;
							int a4 = 0;
							for (int i = 0; i < dxds.length; i++) {
								if (d[6] % 2 != 0 && dxds[i].equals("单")) {
									a1++;
								}
								if (d[6] % 2 == 0 && dxds[i].equals("双")) {
									a2++;
								}
								if (d[6] > 24 && dxds[i].equals("大")) {
									a3++;
								}
								if (d[6] < 25 && dxds[i].equals("小")) {
									a4++;
								}
								if (d[6] == 49) {
									list.add("大小单双");
								}
							}
							count4 = a1 + a2 + a3 + a4;
								money4 = a1 * oMoney * co.ratio(user,pv4[0]) + a2 * oMoney * co.ratio(user,pv4[1])
								+ a3 * oMoney * co.ratio(user,pv4[2]) + a4 * oMoney * co.ratio(user,pv4[3]);
						}
						// 家禽野兽
						if (jqys.length != 0 && !jqys[0].equals("")) {
							int a1 = 0;
							int a2 = 0;
							int a3 = 0;
							int a4 = 0;
		
							for (int i = 0; i < jqyss.length; i++) {
								for (int j = 0; j < jqyss[i].length; j++) {
									for (int k = 0; k < jqyss[i][j].length; k++) {
										for (int m = 0; m < jqys.length; m++) {
											if (d[6] == 49) {
												list.add("家禽野兽");
											} else {
												if (jqyss[i][j][k].equals(data[6]) && jqysss[i].equals(jqys[m])
														&& jqys[m].equals("家肖")) {
													a1 = 1;
												}
												if (jqyss[i][j][k].equals(data[6]) && jqysss[i].equals(jqys[m])
														&& jqys[m].equals("野肖")) {
													a2 = 1;
												}
												if (jqyss[i][j][k].equals(data[6]) && jqysss[i].equals(jqys[m])
														&& jqys[m].equals("天肖")) {
													a3 = 1;
												}
												if (jqyss[i][j][k].equals(data[6]) && jqysss[i].equals(jqys[m])
														&& jqys[m].equals("地肖")) {
													a4 = 1;
												}
											}
										}
									}
								}
							}
							count5 = a1 + a2 + a3 + a4;
								money5 = a1 * oMoney * co.ratio(user,pv5[0]) + a2 * oMoney * co.ratio(user,pv5[1])
								+ a3 * oMoney * co.ratio(user,pv5[2]) + a4 * oMoney * co.ratio(user,pv5[3]);
						}
						// 头数
						if (ts.length != 0 && !ts[0].equals("")) {
							int b = 0;
							for (int i = 0; i < t2.length; i++) {
								for (int j = 0; j < t2[i].length; j++) {
									for (int k = 0; k < t1.length; k++) {
										for (int m = 0; m < ts.length; m++) {
											if (t2[i][j].equals(data[6]) && t1[k].equals(ts[m]) && (t1[i].equals(ts[m]))) {
												b = i;
												count6++;
											}
										}
									}
								}
							}
								money6 = count6 * oMoney * co.ratio(user,pv6[b]);
						}
						// 尾数
						if (ws.length != 0 && !ws[0].equals("")) {
							int a1 = 0;
							int a2 = 0;
							int a3 = 0;
							int a4 = 0;
							int a5 = 0;
							int g = 0;
							for (int i = 0; i < w2.length; i++) {
								for (int j = 0; j < w2[i].length; j++) {
									for (int k = 0; k < w1.length; k++) {
										for (int m = 0; m < ws.length; m++) {
											if (w2[i][j].equals(data[6])) {
												if (d[6] == 49) {
													list.add("尾数");
												} else {
													if (w1[k].equals(ws[m])) {
														g = i;
														a1 = 1;
													}
													if (ws[m].equals("大")) {
														if (d[6] % 10 > 4 && d[6] % 10 < 10) {
															a2 = 1;
														}
													}
													if (ws[m].equals("小")) {
														if (d[6] % 10 < 5) {
															a3 = 1;
														}
													}
													if (ws[m].equals("单")) {
														if (d[6] % 2 != 0) {
															a4 = 1;
														}
													}
													if (ws[m].equals("双")) {
														if (d[6] % 2 == 0) {
															a5 = 1;
														}
													}
												}
											}
										}
									}
								}
							}
							count7 = a1 + a2 + a3 + a4 + a5;
								money7 = a1 * oMoney * co.ratio(user,pv7[g]) + a2 * oMoney * co.ratio(user,pv7[10])
								+ a3 * oMoney * co.ratio(user,pv7[11]) + a4 * oMoney * co.ratio(user,pv7[12])
								+ a5 * oMoney * co.ratio(user,pv7[13]);
						}
						// 五行
						if (wx.length != 0 && !wx[0].equals("")) {
							int b = 0;
							for (int i = 0; i < x1.length; i++) {
								for (int j = 0; j < x2[i].length; j++) {
									for (int k = 0; k < wx.length; k++) {
										if (wx[k].equals(x1[i]) && x2[i][j].equals(data[6])) {
											count8 = 1;
											b = i;
										}
									}
								}
							}
								money8 = count8 * oMoney * co.ratio(user,pv8[b]);
						}
						// 总和
						if (zh2.length != 0 && !zh2[0].equals("")) {
							int a1 = 0;
							int a2 = 0;
							int a3 = 0;
							int a4 = 0;
							for (int i = 0; i < zh2.length; i++) {
								if (zh2[i].equals("单")) {
									if (dh % 2 != 0) {
										a1 = 1;
									}
								}
								if (zh2[i].equals("双")) {
									if (dh % 2 == 0) {
										a2 = 1;
									}
								}
								if (zh2[i].equals("大")) {
									if (dh > 174) {
										a3 = 1;
									}
								}
								if (zh2[i].equals("小")) {
									if (dh < 175) {
										a4 = 1;
									}
								}
							}
							count9 = a1 + a2 + a3 + a4;
								money9 = a1 * oMoney * co.ratio(user,pv9[0]) + a2 * oMoney * co.ratio(user,pv9[1])
								+ a3 * oMoney * co.ratio(user,pv9[2]) + a4 * oMoney * co.ratio(user,pv9[3]);
						}
						// 合数
						if (hs.length != 0 && !hs[0].equals("")) {
							int a1 = 0;
							int a2 = 0;
							int a3 = 0;
							int a4 = 0;
							for (int i = 0; i < hs.length; i++) {
								if (hs[i].equals("单")) {
									if (hss % 2 != 0) {
										a1 = 1;
									}
								}
								if (hs[i].equals("双")) {
									if (hss % 2 == 0) {
										a2 = 1;
									}
								}
								if (hs[i].equals("大")) {
									if (hss > 6) {
										a3 = 1;
									}
								}
								if (hs[i].equals("小")) {
									if (hss < 7) {
										a4 = 1;
									}
								}
								if (d[6] == 49) {
									list.add("合数");
								}
							}
							count10 = a1 + a2 + a3 + a4;
								money10 = a1 * oMoney * co.ratio(user,pv10[0]) + a2 * oMoney * co.ratio(user,pv10[1])
								+ a3 * oMoney * co.ratio(user,pv10[2]) + a4 * oMoney * co.ratio(user,pv10[3]);
						}
						// 独平
						if (dp.length != 0 && !dp[0].equals("")) {
							int a = 0;
							for (int i = 0; i < dp.length; i++) {
								for (int j = 0; j < tm.length; j++) {
									for (int k = 0; k < data.length; k++) {
										if (dp[i].equals(data[k]) && tm[j].equals(dp[i])) {
											count11 = 1;
										}
									}
								}
							}
								money11 = count11 * oMoney * co.ratio(user,pv11[0]);
						}
						// 平二中二
						if (p2z2.length != 0 && !p2z2[0].equals("")) {
							int a = 0;
							for (int i = 0; i < p2z2.length; i++) {
								for (int j = 0; j < data.length - 1; j++) {
									if (p2z2[i].equals(data[j])) {
										a++;
									}
								}
							}
							if (a > 1) {
								count12 = 1;
							}
								money12 = count12 * oMoney * co.ratio(user,pv12[0]);
						}
						// 平三中三
						if (p3z3.length != 0 && !p3z3[0].equals("")) {
							int a = 0;
							for (int i = 0; i < p3z3.length; i++) {
								for (int j = 0; j < data.length - 1; j++) {
									if (p3z3[i].equals(data[j])) {
										a++;
									}
								}
							}
							if (a > 2) {
								count13 = 1;
							}
								money13 = count13 * oMoney * co.ratio(user,pv13[0]);
						}
						// 平三中二
						if (p3z2.length != 0 && !p3z2[0].equals("")) {
							int a = 0;
							for (int i = 0; i < p3z2.length; i++) {
								for (int j = 0; j < data.length - 1; j++) {
									if (p3z2[i].equals(data[j])) {
										a++;
									}
								}
							}
							if (a > 1) {
								count14 = 1;
							}
								money14 = count14 * oMoney * co.ratio(user,pv14[0]);
						}
						// 四肖中特
						if (sxzt.length != 0 && !sxzt[0].equals("")) {
							int a = 0;
							for (int i = 0; i < sx1.length; i++) {
								for (int j = 0; j < sx2[i].length; j++) {
									for (int k = 0; k < sxzt.length; k++) {
										if (sx2[i][j].equals(data[6]) && sxzt[k].equals(sx1[i])) {
											count15 = 1;
											a = i;
										}
									}
								}
							}
								money15 = count15 * oMoney * co.ratio(user,pv15[a]);
						}
						// 五肖中特
						if (wxzt.length != 0 && !wxzt[0].equals("")) {
							int a = 0;
							for (int i = 0; i < sx1.length; i++) {
								for (int j = 0; j < sx2[i].length; j++) {
									for (int k = 0; k < wxzt.length; k++) {
										if (sx2[i][j].equals(data[6]) && wxzt[k].equals(sx1[i])) {
											count16 = 1;
											a = i;
										}
									}
								}
							}
								money16 = count16 * oMoney * co.ratio(user,pv16[a]);
						}
						// 六肖中特
						if (lxzt.length != 0 && !lxzt[0].equals("")) {
							int a = 0;
							for (int i = 0; i < sx1.length; i++) {
								for (int j = 0; j < sx2[i].length; j++) {
									for (int k = 0; k < lxzt.length; k++) {
										if (sx2[i][j].equals(data[6]) && lxzt[k].equals(sx1[i])) {
											count17 = 1;
											a = i;
										}
									}
								}
							}
								money17 = count17 * oMoney * co.ratio(user,pv17[a]);
						}
						// 平特1肖
						if (pt1x.length != 0 && !pt1x[0].equals("")) {
							int a = 0;
							List<Integer> list1 = new ArrayList<Integer>();
							List<Double> list2 = new ArrayList<Double>();
							for (int i = 0; i < sx1.length; i++) {
								for (int j = 0; j < sx2[i].length; j++) {
									for (int k = 0; k < pt1x.length; k++) {
										for (int n = 0; n < data.length; n++) {
											if (sx2[i][j].equals(data[n]) && pt1x[k].equals(sx1[i])) {// i就是data中对应的生肖
												count18 = 1;
												a = i;
												list1.add(a);
											}
										}
									}
								}
							}
							for (int i = 0; i < list1.size() - 1; i++) {
								for (int j = list1.size() - 1; j > i; j--) {
									if (list1.get(j).equals(list1.get(i))) {
										list1.remove(j);
									}
								}
							}
							for (int i = 0; i < list1.size(); i++) {
								Double a1 = Double.parseDouble(pv18[list1.get(i)]);
								list2.add(a1);
							}
							try {
								Double a3 = Collections.min(list2);// 获取最小值 本命肖
								Double a4 = Collections.max(list2);// 获取最大值 中奖的 二选1
								if (list2.size() > 1) {
									if (a3 != null) {
											money18 = count18 * oMoney * co.ratio(user,a3+"");
									} else {
											money18 = count18 * oMoney * co.ratio(user,a4+"");
									}
								} else {
										money18 = count18 * oMoney * co.ratio(user,pv18[list1.get(0)]);
								}
							} catch (Exception e) {
									money18 = count18 * oMoney * co.ratio(user,pv18[list1.get(0)]);
							}
						}
						// 平特2肖
						if (pt2x.length != 0 && !pt2x[0].equals("")) {
							List<Integer> list1 = new ArrayList<Integer>();
							List<Double> list2 = new ArrayList<Double>();
							int a = 0;
							for (int i = 0; i < sx1.length; i++) {
								for (int j = 0; j < sx2[i].length; j++) {
									for (int k = 0; k < pt2x.length; k++) {
										for (int n = 0; n < data.length; n++) {
											if (sx2[i][j].equals(data[n]) && pt2x[k].equals(sx1[i])) {
												list1.add(a);
												a = i;
											}
										}
									}
								}
							}
							for (int i = 0; i < list1.size() - 1; i++) {
								for (int j = list1.size() - 1; j > i; j--) {
									if (list1.get(j).equals(list1.get(i))) {
										list1.remove(j);
									}
								}
							}
							if (list1.size() > 1) {
								count19 = 1;
							}
							for (int i = 0; i < list1.size(); i++) {
								Double a1 = Double.parseDouble(pv19[list1.get(i)]);
								list2.add(a1);
							}
							try {
								Double a3 = Collections.min(list2);
								Double a4 = Collections.max(list2);
								if (list2.size() > 1) {
									if (a3 != null) {
											money19 = count19 * oMoney * co.ratio(user,a3+"");
									} else {
											money19 = count19 * oMoney * co.ratio(user,a4+"");
									}
								} else {
										money19 = count19 * oMoney * co.ratio(user,pv19[list1.get(0)]+"");
								}
							} catch (Exception e) {
									money19 = count19 * oMoney * co.ratio(user,pv19[list1.get(0)]+"");
							}
						}
						// 平特3肖
						if (pt3x.length != 0 && !pt3x[0].equals("")) {
							List<Integer> list1 = new ArrayList<Integer>();
							List<Double> list2 = new ArrayList<Double>();
							int a = 0;
							for (int i = 0; i < sx1.length; i++) {
								for (int j = 0; j < sx2[i].length; j++) {
									for (int k = 0; k < pt3x.length; k++) {
										for (int n = 0; n < data.length; n++) {
											if (sx2[i][j].equals(data[n]) && pt3x[k].equals(sx1[i])) {
												a = i;
												list1.add(a);
											}
										}
									}
								}
							}
							for (int i = 0; i < list1.size() - 1; i++) {
								for (int j = list1.size() - 1; j > i; j--) {
									if (list1.get(j).equals(list1.get(i))) {
										list1.remove(j);
									}
								}
							}
							if (list1.size() > 2) {
								count20 = 1;
							}
							for (int i = 0; i < list1.size(); i++) {
								Double a1 = Double.parseDouble(pv20[list1.get(i)]);
								list2.add(a1);
							}
							try {
								Double a3 = Collections.min(list2);
								Double a4 = Collections.max(list2);
								if (list2.size() > 1) {
									if (a3 != null) {
											money20 = count20 * oMoney * co.ratio(user,a3+"");
									} else {
											money20 = count20 * oMoney * co.ratio(user,a4+"");
									}
								} else {
										money20 = count20 * oMoney * co.ratio(user,pv20[list1.get(0)]);
								}
							} catch (Exception e) {
									money20 = count20 * oMoney * co.ratio(user,pv20[list1.get(0)]);
							}
						}
						// 平特4肖
						if (pt4x.length != 0 && !pt4x[0].equals("")) {
		
							List<Integer> list1 = new ArrayList<Integer>();
							List<Double> list2 = new ArrayList<Double>();
							int a = 0;
							for (int i = 0; i < sx1.length; i++) {
								for (int j = 0; j < sx2[i].length; j++) {
									for (int k = 0; k < pt4x.length; k++) {
										for (int n = 0; n < data.length; n++) {
											if (sx2[i][j].equals(data[n]) && pt4x[k].equals(sx1[i])) {
												a = i;
												list1.add(a);
											}
										}
									}
								}
							}
							for (int i = 0; i < list1.size() - 1; i++) {
								for (int j = list1.size() - 1; j > i; j--) {
									if (list1.get(j).equals(list1.get(i))) {
										list1.remove(j);
									}
								}
							}
							if (list1.size() > 3) {
								count21 = 1;
							}
							for (int i = 0; i < list1.size(); i++) {
								Double a1 = Double.parseDouble(pv21[list1.get(i)]);
								list2.add(a1);
							}
							try {
								Double a3 = Collections.min(list2);
								Double a4 = Collections.max(list2);
								if (list2.size() > 1) {
									if (a3 != null) {
											money21 = count21 * oMoney * co.ratio(user,a3+"");
									} else {
											money21 = count21 * oMoney * co.ratio(user,a4+"");
									}
								} else {
										money21 = count21 * oMoney * co.ratio(user,pv21[list1.get(0)]);
								}
							} catch (Exception e) {
									money21 = count21 * oMoney * co.ratio(user,pv21[list1.get(0)]);
							}
						}
						// 平特1尾
						if (pt1w.length != 0 && !pt1w[0].equals("")) {
							List<Integer> list1 = new ArrayList<Integer>();
							List<Double> list2 = new ArrayList<Double>();
							int a = 0;
							for (int i = 0; i < w3.length; i++) {
								for (int j = 0; j < w2[i].length; j++) {
									for (int k = 0; k < pt1w.length; k++) {
										for (int n = 0; n < data.length; n++) {
											if (w2[i][j].equals(data[n]) && pt1w[k].equals(w3[i])) {
												count22 = 1;
												a = i;
												list1.add(a);
											}
										}
									}
								}
							}
							for (int i = 0; i < list1.size() - 1; i++) {
								for (int j = list1.size() - 1; j > i; j--) {
									if (list1.get(j).equals(list1.get(i))) {
										list1.remove(j);
									}
								}
							}
							for (int i = 0; i < list1.size(); i++) {
								Double a1 = Double.parseDouble(pv22[list1.get(i)]);
								list2.add(a1);
							}
							try {
								Double a3 = Collections.max(list2);
								Double a4 = Collections.min(list2);
								if (list2.size() > 1) {
									if (a3 != null) {
											money22 = count22 * oMoney * co.ratio(user,a3+"");
									} else {
											money22 = count22 * oMoney * co.ratio(user,a4+"");
									}
								} else {
										money22 = count22 * oMoney * co.ratio(user,pv22[list1.get(0)]);
								}
							} catch (Exception e) {
									money22 = count22 * oMoney * co.ratio(user,pv22[list1.get(0)]);
							}
						}
						// 平特2尾
						if (pt2w.length != 0 && !pt2w[0].equals("")) {
							List<Integer> list1 = new ArrayList<Integer>();
							List<Double> list2 = new ArrayList<Double>();
							int a = 0;
							for (int i = 0; i < w3.length; i++) {
								for (int j = 0; j < w2[i].length; j++) {
									for (int k = 0; k < pt2w.length; k++) {
										for (int n = 0; n < data.length; n++) {
											if (w2[i][j].equals(data[n]) && pt2w[k].equals(w3[i])) {
												a = i;
												list1.add(a);
											}
										}
									}
								}
							}
							for (int i = 0; i < list1.size() - 1; i++) {
								for (int j = list1.size() - 1; j > i; j--) {
									if (list1.get(j).equals(list1.get(i))) {
										list1.remove(j);
									}
								}
							}
							if (list1.size() > 1) {
								count23 = 1;
							}
							for (int i = 0; i < list1.size(); i++) {
								Double a1 = Double.parseDouble(pv23[list1.get(i)]);
								list2.add(a1);
							}
							try {
								Double a3 = Collections.max(list2);
								Double a4 = Collections.min(list2);
								if (list2.size() > 1) {
									if (a3 != null) {
											money23 = count23 * oMoney * co.ratio(user,a3+"");
									} else {
											money23 = count23 * oMoney * co.ratio(user,a4+"");
									}
								} else {
										money23 = count23 * oMoney * co.ratio(user,pv23[list1.get(0)]);
								}
							} catch (Exception e) {
									money23 = count23 * oMoney * co.ratio(user,pv23[list1.get(0)]);
							}
						}
						// 平特3尾
						if (pt3w.length != 0 && !pt3w[0].equals("")) {
							List<Integer> list1 = new ArrayList<Integer>();
							List<Double> list2 = new ArrayList<Double>();
							int a = 0;
							for (int i = 0; i < w3.length; i++) {
								for (int j = 0; j < w2[i].length; j++) {
									for (int k = 0; k < pt3w.length; k++) {
										for (int n = 0; n < data.length; n++) {
											if (w2[i][j].equals(data[n]) && pt3w[k].equals(w3[i])) {
												a = i;
												list1.add(a);
											}
										}
									}
								}
							}
							for (int i = 0; i < list1.size() - 1; i++) {
								for (int j = list1.size() - 1; j > i; j--) {
									if (list1.get(j).equals(list1.get(i))) {
										list1.remove(j);
									}
								}
							}
							if (list1.size() > 2) {
								count24 = 1;
							}
							for (int i = 0; i < list1.size(); i++) {
								Double a1 = Double.parseDouble(pv24[list1.get(i)]);
								list2.add(a1);
							}
							try {
								Double a3 = Collections.max(list2);
								Double a4 = Collections.min(list2);
								if (list2.size() > 1) {
									if (a3 != null) {
											money24 = count24 * oMoney * co.ratio(user,a3+"");
									} else {
											money24 = count24 * oMoney * co.ratio(user,a4+"");
									}
								} else {
										money24 = count24 * oMoney * co.ratio(user,pv24[list1.get(0)]);
								}
							} catch (Exception e) {
									money24 = count24 * oMoney * co.ratio(user,pv24[list1.get(0)]);
							}
						}
						// 平特4尾
						if (pt4w.length != 0 && !pt4w[0].equals("")) {
							List<Integer> list1 = new ArrayList<Integer>();
							List<Double> list2 = new ArrayList<Double>();
							int a = 0;
							for (int i = 0; i < w3.length; i++) {
								for (int j = 0; j < w2[i].length; j++) {
									for (int k = 0; k < pt4w.length; k++) {
										for (int n = 0; n < data.length; n++) {
											if (w2[i][j].equals(data[n]) && pt4w[k].equals(w3[i])) {
												a = i;
												list1.add(a);
											}
										}
									}
								}
							}
							for (int i = 0; i < list1.size() - 1; i++) {
								for (int j = list1.size() - 1; j > i; j--) {
									if (list1.get(j).equals(list1.get(i))) {
										list1.remove(j);
									}
								}
							}
							if (list1.size() > 3) {
								count25 = 1;
							}
							for (int i = 0; i < list1.size(); i++) {
								Double a1 = Double.parseDouble(pv24[list1.get(i)]);
								list2.add(a1);
							}
							try {
								Double a3 = Collections.max(list2);
								Double a4 = Collections.min(list2);
								if (list2.size() > 1) {
									if (a3 != null) {
											money25 = count25 * oMoney * a3;
									} else {
											money25 = count25 * oMoney * co.ratio(user,a4+"");
									}
								} else {
										money25 = count25 * oMoney * co.ratio(user,pv25[list1.get(0)]);
								}
							} catch (Exception e) {
									money25 = count25 * oMoney * co.ratio(user,pv25[list1.get(0)]);
							}
						}
						// 五不中
						if (wbz.length != 0 && !wbz[0].equals("")) {
							int a = 0;
							for (int i = 0; i < wbz.length; i++) {
								for (int j = 0; j < data.length; j++) {
									if (wbz[i].equals(data[j])) {
										a++;
									}
								}
							}
							if (a == 0) {
								count26 = 1;
							}
								money26 = count26 * oMoney * co.ratio(user,pv26[0]);
						}
						// 六不中
						if (lbz.length != 0 && !lbz[0].equals("")) {
							int a = 0;
							for (int i = 0; i < lbz.length; i++) {
								for (int j = 0; j < data.length; j++) {
									if (lbz[i].equals(data[j])) {
										a++;
									}
								}
							}
							if (a == 0) {
								count27 = 1;
							} else {
								count27 = 0;
							}
								money27 = count27 * oMoney * co.ratio(user,pv27[0]);
						}
						// 七不中
						if (qbz.length != 0 && !qbz[0].equals("")) {
							int a = 0;
							for (int i = 0; i < qbz.length; i++) {
								for (int j = 0; j < data.length; j++) {
									if (qbz[i].equals(data[j])) {
										a++;
									}
								}
							}
							if (a == 0) {
								count28 = 1;
							} else {
								count28 = 0;
							}
								money28 = count28 * oMoney * co.ratio(user,pv28[0]);
						}
						// 八不中
						if (bbz.length != 0 && !bbz[0].equals("")) {
							int a = 0;
							for (int i = 0; i < bbz.length; i++) {
								for (int j = 0; j < data.length; j++) {
									if (bbz[i].equals(data[j])) {
										a++;
									}
								}
							}
							if (a == 0) {
								count29 = 1;
							} else {
								count29 = 0;
							}
								money29 = count29 * oMoney * co.ratio(user,pv29[0]);
						}
						// 九不中
						if (jbz.length != 0 && !jbz[0].equals("")) {
							int a = 0;
							for (int i = 0; i < jbz.length; i++) {
								for (int j = 0; j < data.length; j++) {
									if (jbz[i].equals(data[j])) {
										a++;
									}
								}
							}
							if (a == 0) {
								count30 = 1;
							} else {
								count30 = 0;
							}
								money30 = count30 * oMoney * co.ratio(user,pv30[0]);
						}
						// 十不中
						if (shbz.length != 0 && !shbz[0].equals("")) {
							int a = 0;
							for (int i = 0; i < shbz.length; i++) {
								for (int j = 0; j < data.length; j++) {
									if (shbz[i].equals(data[j])) {
										a++;
									}
								}
							}
							if (a == 0) {
								count31 = 1;
							} else {
								count31 = 0;
							}
								money31 = count31 * oMoney * co.ratio(user,pv31[0]);
						}
						// 十一不中
						if (sh1bz.length != 0 && !sh1bz[0].equals("")) {
							int a = 0;
							for (int i = 0; i < sh1bz.length; i++) {
								for (int j = 0; j < data.length; j++) {
									if (sh1bz[i].equals(data[j])) {
										a++;
									}
								}
							}
							if (a == 0) {
								count32 = 1;
							} else {
								count32 = 0;
							}
								money32 = count32 * oMoney * co.ratio(user,pv32[0]);
						}
						// 十二不中
						if (sh2bz.length != 0 && !sh2bz[0].equals("")) {
							int a = 0;
							for (int i = 0; i < sh2bz.length; i++) {
								for (int j = 0; j < data.length; j++) {
									if (sh2bz[i].equals(data[j])) {
										a++;
									}
								}
							}
							if (a == 0) {
								count33 = 1;
							} else {
								count33 = 0;
							}
								money33 = count33 * oMoney * co.ratio(user,pv33[0]);
						}
						// 十三不中
						if (sh3bz.length != 0 && !sh3bz[0].equals("")) {
							int a = 0;
							for (int i = 0; i < sh3bz.length; i++) {
								for (int j = 0; j < data.length; j++) {
									if (sh3bz[i].equals(data[j])) {
										a++;
									}
								}
							}
							if (a == 0) {
								count34 = 1;
							} else {
								count34 = 0;
							}
								money34 = count34 * oMoney * co.ratio(user,pv34[0]);
						}
						// 十四不中
						if (sh4bz.length != 0 && !sh4bz[0].equals("")) {
							int a = 0;
							for (int i = 0; i < sh4bz.length; i++) {
								for (int j = 0; j < data.length; j++) {
									if (sh4bz[i].equals(data[j])) {
										a++;
									}
								}
							}
							if (a == 0) {
								count35 = 1;
							} else {
								count35 = 0;
							}
								money35 = count35 * oMoney * co.ratio(user,pv35[0]);
						}
						// 十五不中
						if (sh5bz.length != 0 && !sh5bz[0].equals("")) {
							int a = 0;
							for (int i = 0; i < sh5bz.length; i++) {
								for (int j = 0; j < data.length; j++) {
									if (sh5bz[i].equals(data[j])) {
										a++;
									}
								}
							}
							if (a == 0) {
								count36 = 1;
							} else {
								count36 = 0;
							}
								money36 = count36 * oMoney * co.ratio(user,pv36[0]);
						}
						// 总肖
						if (zx.length != 0 && !zx[0].equals("")) {
							List<Integer> list1 = new ArrayList<Integer>();
							int a = 0;
							int b = 0;
							int c = 0;
							int e = 0;
							for (int i = 0; i < sx1.length; i++) {
								for (int j = 0; j < sx2[i].length; j++) {
									for (int n = 0; n < data.length; n++) {
										if (sx2[i][j].equals(data[n])) {
											a = i;
											list1.add(a);
										}
									}
								}
							}
							for (int i = 0; i < list1.size() - 1; i++) {
								for (int j = list1.size() - 1; j > i; j--) {
									if (list1.get(j).equals(list1.get(i))) {
										list1.remove(j);
									}
								}
							}
							if (list1.size() > 1) {
								for (int i = 0; i < z1.length; i++) {
									for (int k = 0; k < zx.length; k++) {
										if (z1[i].contains(list1.size() + "") && zx[k].contains(list1.size() + "")) {
											a = i;
											b = 1;
										}
									}
								}
							}
							for (int i = 0; i < zx.length; i++) {
								if ((list1.size() % 2 != 0) && (zx[i].equals("单"))) {
									c = 1;
								} else if ((list1.size() % 2 == 0) && (zx[i].equals("双"))) {
									e = 1;
								}
							}
							count37 = b + c + e;
								money37 = b * oMoney * co.ratio(user,pv37[a]) + c * oMoney * co.ratio(user,pv37[6])
								+ e * oMoney * co.ratio(user,pv37[7]);
						}
						// 色波
						if (sb.length != 0 && !sb[0].equals("")) {
							int a = 0;
							for (int i = 0; i < b1.length; i++) {
								for (int j = 0; j < b2[i].length; j++) {
									for (int m = 0; m < sb.length; m++) {
										if (b2[i][j].equals(data[6]) && sb[m].contains(b1[i])) {
											count38 = 1;
											a = i;
										}
									}
								}
							}
								money38 = count38 * oMoney * co.ratio(user,pv38[a]);
						}
						// 半波
						if (bb.length != 0 && !bb[0].equals("")) {
							List<Integer> list1 = new ArrayList<Integer>();
							int a = 0;
							int b = 0;
							int c = 0;
							int e = 0;
							for (int i = 0; i < b1.length; i++) {
								for (int j = 0; j < b2[i].length; j++) {
									if (b2[i][j].equals(data[6])) {
										a = i;
									}
								}
							}
							for (int i = 0; i < bb.length; i++) {
								for (int j = 0; j < bb1.length; j++) {
									if (bb[i].equals(bb1[j])) {
										if (bb[i].contains(b1[a])) {
											e = j;
											list1.add(e);
											if (d[6] > 24 && bb[i].contains("大")) {
												b = 1;
											}
											if (d[6] < 25 && bb[i].contains("小")) {
												b = 1;
											}
											if (d[6] % 2 != 0 && bb[i].contains("单")) {
												c = 1;
											}
											if (d[6] % 2 == 0 && bb[i].contains("双")) {
												c = 1;
											}
											if (d[6] == 49) {
												list.add("半波");
											}
										}
									}
								}
							}
							double m1 = 0.00;
							double m2 = 0.00;
							if (list1.size() > 0) {
								if (b != 0) {
										m1 = b * oMoney * co.ratio(user,pv39[list1.get(0)]);
								} else {
										m1 = c * oMoney * co.ratio(user,pv39[list1.get(0)]);
								}
							}
		
							if (list1.size() > 1) {
								if (b != 0) {
										m2 = b * oMoney * co.ratio(user,pv39[list1.get(0 + 1)]);
								} else {
										m2 = c * oMoney * co.ratio(user,pv39[list1.get(0 + 1)]);
								}
							}
		
							count39 = b + c;
							money39 = m2 + m1;
						}
						// 半半波
						if (bbb.length != 0 && !bbb[0].equals("")) {
							List<Integer> list1 = new ArrayList<Integer>();
							int a = 0;
							int e = 0;
							int c1 = 0;
							for (int i = 0; i < b1.length; i++) {
								for (int j = 0; j < b2[i].length; j++) {
									if (b2[i][j].equals(data[6])) {
										// 查看开奖号码的颜色
										a = i;
									}
								}
							}
							for (int i = 0; i < bbb.length; i++) {
								for (int j = 0; j < bb1.length; j++) {
									// 下注的匹配上半半波中的某个
									if (bbb[i].equals(bbb1[j])) {
										// 下注的包含了中奖的某一个颜色
										if (bbb[i].contains(b1[a])) {
											if (bbb[i].contains("大单")) {
												if (d[6] > 24 && d[6] % 2 != 0) {
													// e代表中奖的有 赔率中的哪几个
													e = j;
													list1.add(e);
													c1 = 1;
												}
											}
											if (bbb[i].contains("大双")) {
												if (d[6] > 24 && d[6] % 2 == 0) {
													e = j;
													list1.add(e);
													c1 = 1;
												}
											}
											if (bbb[i].contains("小单")) {
												if (d[6] < 25 && d[6] % 2 != 0) {
													e = j;
													list1.add(e);
													c1 = 1;
												}
											}
											if (bbb[i].contains("小双")) {
												if (d[6] < 25 && d[6] % 2 == 0) {
													e = j;
													list1.add(e);
													c1 = 1;
												}
											}
										}
									}
								}
							}
							count40 = c1;
							if (list1.size() > 0) {
									money40 = count40 * oMoney * co.ratio(user,pv40[list1.get(0)]);
							} else {
								money40 = 0.00;
							}
						}
						break;
					case "bj28":
					case "xy28":
					case "jnd28":
						String [] tms1 = {"0","1","2","3","4","5","6","7","8","9","10","11","12","13","14","15","16","17","18","19","20",
								"21","22","23","24","25","26","27"}; 
						String[] hunhe = order.getStr1().split(",");
						String[] tms = order.getStr2().split(",");
						String[] tmbs = order.getStr3().split(",");
						String[] bs = order.getStr4().split(",");
						String[] bz = order.getStr5().split(",");
						int che = d[0] + d[1] + d[2];
						//混合
						if(hunhe.length!=0&&!"".equals(hunhe[0])) {              //TODO: K111
							int a1 =0;  
							int a2 =0;
							int a3 =0;
							int a4 =0;
							int a5 =0;
							int a6 =0;
							int a7 =0;
							int a8 =0;
							int a9 =0;
							int a10 =0;
							for(int i=0;i<hunhe.length;i++) {
								if("大".equals(hunhe[i])) {
									if(che>13) {
										a1 = 1;
									}
								}
								
								if("小".equals(hunhe[i])) {
									if(che<13) {
										a2 = 1;
									}
								}
								
								if("单".equals(hunhe[i])) {
									if(che % 2 != 0 ) {
										a3 = 1;
									}
								}
								
								if("双".equals(hunhe[i])) {
									if(che % 2 == 0 ) {
										a4 = 1;
									}
									
								}
								if("大单".equals(hunhe[i])) {
									if(che>13 && che % 2 != 0) {
										a5=1;
									}
									
								}
								if("大双".equals(hunhe[i])) {
									if(che>13 && che % 2 == 0) {
										a6=1;
									}
								}
								if("小单".equals(hunhe[i])) {
									if( che<13 && che % 2 != 0) {
										a7=1;
									}
								}
								if("小双".equals(hunhe[i])) {
									if(che<13 &&che % 2 == 0) {
										a8=1;
									}
								}
								if("极大".equals(hunhe[i])) {
									switch (che) {
									case 22:
									case 23:
									case 24:
									case 25:
									case 26:
									case 27:
										a9=1;
										break;
									}
								}
								if("极小".equals(hunhe[i])) {
									switch (che) {
									case 0:
									case 1:
									case 2:
									case 3:
									case 4:
									case 5:
										a10 = 1;
										break;
									}
								}
							}
							count1 = a1+a2+a3+a4+a5+a6+a7+a8+a9+a10;
								money1 = a1 * oMoney * co.ratio(user,pv1[0])
										+  a2 * oMoney * co.ratio(user,pv1[1])
										+  a3 * oMoney * co.ratio(user,pv1[2])
										+  a4 * oMoney * co.ratio(user,pv1[3])
										+  a5 * oMoney * co.ratio(user,pv1[4])
										+  a6 * oMoney * co.ratio(user,pv1[5])
										+  a7 * oMoney * co.ratio(user,pv1[6])
										+  a8 * oMoney * co.ratio(user,pv1[7])
										+  a9 * oMoney * co.ratio(user,pv1[8])
										+  a10 * oMoney * co.ratio(user,pv1[9]);
						}
						
						//特码
						if(tms.length!=0 && !"".equals(tms[0])) {
							int a1 = 0;
							int b = 0;
							for(int i=0;i<tms.length;i++) {
								for(int j=0;j<tms1.length;j++) {
									if(tms[i].equals(tms1[j])&&tms[i].equals(che+"")) {
										b = i;
										a1=1;
									}
								}
							}
							count2 = a1;
								money2 = a1 * oMoney * co.ratio(user,pv2[b]);
						}
						
						//特码包三
						if(tmbs.length!=0 && !"".equals(tmbs[0])) {
							int a1 =0;
							int b =0;
							for(int i=0;i<tmbs.length;i++) {
								for(int j=0;j<tms1.length;j++) {
									if(tmbs[i].equals(tms1[j])&&tmbs[i].equals(che+"")) {
										b = i;
										a1=1;
									}
								}
							}
							count3 = a1;
								money3 = a1 * oMoney * co.ratio(user,pv3[b]);
						}
						
						//波色
						String [][] bose = {{"3","6","9","12","15","18","21","24"},{"1","4","7","10","16","19","22","25"},{"2","5","8","11","17","20","23","26"}};//TODO: K3
						String[] bse = {"红波","绿波","蓝波"}; 
						if(bs.length!=0 && !"".equals(bs[0])) {
							int a1 = 0;
							int b = 0;
							for(int i=0;i<bse.length;i++) {
								for(int j=0;j<bose[i].length;j++) {
									for(int k =0;k<bs.length;k++) {
										if(bs[k].equals(bse[i])&&bose[i][j].equals(che+"")) {
											b = i;
											a1 = 1;
										}
									}
								}
							}
							count4 = a1;
								money4 = a1 * oMoney * co.ratio(user,pv4[b]);
						}
						
						//豹子
						if(bz.length!=0 && !"".equals(bz[0])) {
							int a1 =0;
							if(d[0]==d[1]&&d[0]==d[2]&&d[1]==d[2]) {
								a1 = 1;
							}
							count5 =a1;
								money4 = a1 * oMoney * co.ratio(user,pv5[0]);
						}
						break;
					}
					/** 计算中奖注数和金额 */
					count = count1 + count2 + count3 + count4 + count5 + count6 + count7 + count8 + count9 + count10 + count11
							+ count12 + count13 + count14 + count15 + count16 + count17 + count18 + count19 + count20 + count21
							+ count22 + count23 + count24 + count25 + count26 + count27 + count28 + count29 + count30 + count31
							+ count32 + count33 + count34 + count35 + count36 + count37 + count38 + count39 + count40;
					gMoney = money1 + money2 + money3 + money4 + money5 + money6 + money7 + money8 + money9 + money10 + money11
							+ money12 + money13 + money14 + money15 + money16 + money17 + money18 + money19 + money20 + money21
							+ money22 + money23 + money24 + money25 + money26 + money27 + money28 + money29 + money30 + money31
							+ money32 + money33 + money34 + money35 + money36 + money37 + money38 + money39 + money40;
		
					/** 修改中奖状态 */
					int state = 0;
					if (gMoney != 0.00) {
						/** 中奖 */
						state = 3;
					} else if (list.size() > 0) {
						/** 中奖和局 */
						state = 6;
					} else {
						/** 未中奖 */
						state = 2;
					}
					System.err.println("用户：" + order.getHuiyuanzh() + "在彩种：" + order.getCname() + "第" + order.getPeriod()
							+ "期,中了:" + count + "注 ,中奖:" + gMoney + "元");
					order.setMoney1(money1);
					order.setMoney2(money2);
					order.setMoney3(money3);
					order.setMoney4(money4);
					order.setMoney5(money5);
					order.setMoney6(money6);
					order.setMoney7(money7);
					order.setMoney8(money8);
					order.setMoney9(money9);
					order.setMoney10(money10);
					order.setMoney11(money11);
					order.setMoney12(money12);
					order.setMoney13(money13);
					order.setMoney14(money14);
					order.setMoney15(money15);
					order.setMoney16(money16);
					order.setMoney17(money17);
					order.setMoney18(money18);
					order.setMoney19(money19);
					order.setMoney20(money20);
					order.setMoney21(money21);
					order.setMoney22(money22);
					order.setMoney23(money23);
					order.setMoney24(money24);
					order.setMoney25(money25);
					order.setMoney26(money26);
					order.setMoney27(money27);
					order.setMoney28(money28);
					order.setMoney29(money29);
					order.setMoney30(money30);
					order.setMoney31(money31);
					order.setMoney32(money32);
					order.setMoney33(money33);
					order.setMoney34(money34);
					order.setMoney35(money35);
					order.setMoney36(money36);
					order.setMoney37(money37);
					order.setMoney38(money38);
					order.setMoney39(money39);
					order.setMoney40(money40);
					order.setLottertime(ss.format(new Date()));
					order.setState(state);
					order.setGoalmoney(gMoney);
					order.setLotternum(datas.getLotternumber());
					
					/**
					 * TODO: 和局 中奖
					 */
					DecimalFormat dec = new DecimalFormat("#0.00");
					double returnMoney = 0.00;
					String tcPlay = "";
					String reMoney = "";
					if (list.size() > 0) {
						for (String key : list) {
							switch (key) {
							case "特码A":
								returnMoney = order.getCount1() * oMoney;
								order.setAcount(returnMoney);
								order.setTcplay(key);
								orderService.returnCheckMoney(user, order);
								break;
							case "特码B":
								returnMoney = order.getCount2() * oMoney;
								order.setAcount(returnMoney);
								order.setTcplay(key);
								orderService.returnCheckMoney(user, order);
								break;
							case "大小单双":
								returnMoney = order.getCount4() * oMoney;
								order.setAcount(returnMoney);
								order.setTcplay(key);
								orderService.returnCheckMoney(user, order);
								break;
							case "家禽野兽":
								returnMoney = order.getCount5() * oMoney;
								order.setAcount(returnMoney);
								order.setTcplay(key);
								orderService.returnCheckMoney(user, order);
								break;
							case "尾数":
								returnMoney = order.getCount7() * oMoney;
								order.setAcount(returnMoney);
								order.setTcplay(key);
								orderService.returnCheckMoney(user, order);
								break;
							case "合数":
								returnMoney = order.getCount10() * oMoney;
								order.setAcount(returnMoney);
								order.setTcplay(key);
								orderService.returnCheckMoney(user, order);
								break;
							case "半波":
								returnMoney = order.getCount39() * oMoney;
								order.setAcount(returnMoney);
								order.setTcplay(key);
								orderService.returnCheckMoney(user, order);
								break;
							}
							tcPlay = key += ",";
							reMoney = dec.format(returnMoney);
							reMoney += ",";
						}
						tcPlay = tcPlay + "&" + reMoney;
						orderService.updateReturnCheckMoney(order.getId(), tcPlay);
					}
						orderService.checkLotterMoney(order, user);
				}catch (Exception e) {
					e.printStackTrace();
					logger.error("CheckOrder类开奖出现的异常："+e.toString());
					continue;
				}
		}
	}
	
	public static void main(String[] args) {
		CheckOrder co = new CheckOrder();
		co.checkLotter2(new Data());
		
	}
	
	
}
