package com.ja.dao;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.ja.domain.LuckyRecord;

public interface LuckyRecordMapper {
	
	/**添加会员的抽奖信息*/
	int addLuckyRecord(@Param("o")LuckyRecord record);

	/**根据id查询当前用户的抽奖信息*/
	List<LuckyRecord> getOneLuckyRecord(Integer id);
	
	/**查询所有的用户抽奖信息*/
	List<LuckyRecord> getAllLuckyRecord();
	
	/**最新5条*/
	List<LuckyRecord> getMathLuckyRecord();
}
