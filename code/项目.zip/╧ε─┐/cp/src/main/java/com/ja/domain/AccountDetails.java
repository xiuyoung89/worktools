package com.ja.domain;

import java.io.Serializable;

public class AccountDetails implements Serializable{
    /**
	 * 
	 */
	private static final long serialVersionUID = -1685901904686237631L;

	private Integer id;

    private String name;

    private String ordernum;

    private String bettingtime;

    private String cpnum;

    private Double betAncount;

    private Double income;

    private String state;

    private Integer cpstate;

    private Integer lid;
    

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name == null ? null : name.trim();
    }

    public String getOrdernum() {
        return ordernum;
    }

    public void setOrdernum(String ordernum) {
        this.ordernum = ordernum == null ? null : ordernum.trim();
    }

    public String getBettingtime() {
        return bettingtime;
    }

    public void setBettingtime(String bettingtime) {
        this.bettingtime = bettingtime == null ? null : bettingtime.trim();
    }

    public String getCpnum() {
        return cpnum;
    }

    public void setCpnum(String cpnum) {
        this.cpnum = cpnum == null ? null : cpnum.trim();
    }

    public Double getBetAncount() {
        return betAncount;
    }

    public void setBetAncount(Double betAncount) {
        this.betAncount = betAncount;
    }

    public Double getIncome() {
        return income;
    }

    public void setIncome(Double income) {
        this.income = income;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state == null ? null : state.trim();
    }

    public Integer getCpstate() {
        return cpstate;
    }

    public void setCpstate(Integer cpstate) {
        this.cpstate = cpstate;
    }

    public Integer getLid() {
        return lid;
    }

    public void setLid(Integer lid) {
        this.lid = lid;
    }
}