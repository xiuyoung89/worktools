package com.ja.domain;

import java.io.Serializable;
import java.util.Date;

/**
 * 
 * @author CY
 * @date 31,Mar,2018
 */
public class Activity implements Serializable {

	private static final long serialVersionUID = -55311576995433233L;
	
	private Integer id;
	
	private String name;//活动名称
	
	private String photo_path;//图片地址
	
	private Integer type;//活动类型 0为新用户活动，1为老用户活动，2为全部活动
	
	private Double present;//赠送金额-人工加宽或银行卡转账
	
	private Double present1;//赠送金额1-在线充值
	
	private Double present2;//
	
	private String alert1; //内容
	
	private String qq; //qq
	
	private Integer sort; //排序
	
	private Integer status;//状态
	
	private String created_user;//创建人
	
	private Date created_time;//创建时间
	
	public Activity() {
		super();
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getPhoto_path() {
		return photo_path;
	}

	public void setPhoto_path(String photo_path) {
		this.photo_path = photo_path;
	}

	public Integer getType() {
		return type;
	}

	public void setType(Integer type) {
		this.type = type;
	}

	public Double getPresent() {
		return present;
	}

	public void setPresent(Double present) {
		this.present = present;
	}

	public Double getPresent1() {
		return present1;
	}

	public void setPresent1(Double present1) {
		this.present1 = present1;
	}

	public Double getPresent2() {
		return present2;
	}

	public void setPresent2(Double present2) {
		this.present2 = present2;
	}

	public String getAlert1() {
		return alert1;
	}

	public void setAlert1(String alert1) {
		this.alert1 = alert1;
	}

	public String getQq() {
		return qq;
	}

	public void setQq(String qq) {
		this.qq = qq;
	}

	public Integer getSort() {
		return sort;
	}

	public void setSort(Integer sort) {
		this.sort = sort;
	}

	public Integer getStatus() {
		return status;
	}

	public void setStatus(Integer status) {
		this.status = status;
	}

	public String getCreated_user() {
		return created_user;
	}

	public void setCreated_user(String created_user) {
		this.created_user = created_user;
	}

	public Date getCreated_time() {
		return created_time;
	}

	public void setCreated_time(Date created_time) {
		this.created_time = created_time;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	@Override
	public String toString() {
		return "Activity [id=" + id + ", name=" + name + ", photo_path=" + photo_path + ", type=" + type + ", present="
				+ present + ", present1=" + present1 + ", present2=" + present2 + ", alert1=" + alert1 + ", qq=" + qq
				+ ", sort=" + sort + ", status=" + status + ", created_user=" + created_user + ", created_time="
				+ created_time + "]";
	}
	
}
