package com.ja.dao;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.ja.domain.Dama;
import com.ja.domain.TodayRecord;

public interface DamaMapper {
	
	/**查询所有打码记录
	 * @param i 
	 * @param integer2 
	 * @param integer */
	List<Dama> getAllDama(@Param("startIndex")Integer integer, @Param("lineCount")Integer integer2, @Param("model")int i);
	
	/**根据条件查询打码记录
	 * @param model 
	 * @param integer2 
	 * @param integer */
	List<Dama> getMhdama(@Param("startIndex")Integer integer, @Param("lineCount")Integer integer2, @Param("d")Dama d,@Param(value="date1")String date1,@Param("date2")String date2,  @Param("model")int model);

	/**增加当前用户的打码记录*/
	int addDama(@Param("d")Dama d);
	
	/**查询用户今日打码量
	 * @param time */
	double getDmTodyJl1(@Param("id")Integer id, @Param("time")String time);
	double getDmTodyJl2(@Param("id")Integer id, @Param("time")String time);
	
	/**查询用户本月打码量*/
	double getDmMonthJl1(@Param("id")Integer id);
	double getDmMonthJl2(@Param("id")Integer id);
	
	/**上月打码量*/
	double getDmLastMonthJl1(@Param("id")Integer id, @Param("time")String time);
	double getDmLastMonthJl2(@Param("id")Integer id, @Param("time")String time);
	
	/**根据id查询打码量*/
    Dama getOneDamaJl(@Param("id")Integer id, @Param("time")String time);

    /**
     *   方法名：findUserByTimeDamal   
     *   描述：    根据时间查询用户的打码量                   TODO   
     *   参数：    @param user_id 用户id
     *   参数：    @param time 查询时间 
     *   参数：    @param type 查询类型 
     *   参数：    @return 
     * @return: double
     */
	Double findUserByTimeCodeCount(@Param("user_id")Integer user_id, @Param("time")String time, @Param("type")int type);

	/**
	 * 方法名：findUserCodeCountManualChange 
	 * 描述：    根据时间查询用户人工增加或扣除的打码量                   TODO
	 * 参数：    @param user_id
	 * 参数：    @param time
	 * 参数：    @return 
	 * @return: TodayRecord
	 */
	TodayRecord findUserCodeCountManualChange(@Param("user_id")Integer user_id, @Param("time")String time);


}
