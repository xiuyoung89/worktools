package com.ja.sevice.impl;

import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.ja.dao.FanshuiJlMapper;
import com.ja.dao.FanshuiMapper;
import com.ja.dao.LiushuiMapper;
import com.ja.dao.UserMapper;
import com.ja.domain.AdminUser;
import com.ja.domain.Fanshui;
import com.ja.domain.FanshuiJl;
import com.ja.domain.Liushui;
import com.ja.domain.TodayRecord;
import com.ja.domain.User;
import com.ja.sevice.FanshuiJlService;
import com.ja.sevice.YunyingbbService;
import com.ja.util.DateUtil;

@Service
/**
 * @author GL 反水记录-
 * @DATE 2018年1月15日 18:03:40
 */
public class FanshuiJlServiceImpl implements FanshuiJlService {

	@Autowired
	private FanshuiJlMapper fanshuiJlMapper;

	@Autowired
	private FanshuiMapper fanshuiMapper;

	@Autowired
	private UserMapper userMapper;

	@Autowired
	private LiushuiMapper liushuiMapper;
	
	@Autowired
	private YunyingbbService yunyingbbService;

	/** 根据时间和id去查询日反水记录 */
	@Override
	public FanshuiJl getOneFanshui(Integer id, String time) {
		return fanshuiJlMapper.getOneFanshui(id, time);
	}

	/** 根据时间和id去查询月反水记录 */
	@Override
	public FanshuiJl getTowFanshui(Integer id, String time) {
		return fanshuiJlMapper.getTowFanshui(id, time);
	}

	@Transactional
	@Override
	public int rebateRecord(int type) {
		AdminUser admin = new AdminUser();
		admin.setName("系统自动");
		List<User> list = userMapper.getAllUsers();
		for (User user : list) {
			if (user.getState() == 1) {
				FanshuiJl waters = fanshuiJlMapper.getOneFanshui(user.getId(), DateUtil.findFormatDate());
				if (waters != null) {
					continue;
				}
				try {
					double rebate = 0.00;
					TodayRecord record = yunyingbbService.findOperateRecord("", "", user.getName(),2);
					double money = record.getTouzhu();
					if (type == 1) {
						List<Fanshui> lists = fanshuiMapper.getTypefanshui(type);
						TodayRecord record1 = yunyingbbService.findOperateRecord(DateUtil.findLatelyDate(-1), "", user.getName(),1);//昨日
						Double moneys = record1.getChongzhi();//用户的充值总计
						Double damal = record1.getTouzhu();//用户的打码总计
						if (lists.size() > 0) {
							for (Fanshui water : lists) {
								if (water.getState() == 1) {
									if (water.getJine() != 0.00) {
										if (moneys >= water.getJine() && damal >= water.getDamal()) {
											if (water.getFdianlv() > rebate) {
												rebate = water.getFdianlv();
											}
										}
									} else {
										if (water.getDamal() != 0.00) {
											if (damal >= water.getDamal()) {
												if (water.getFdianlv() > rebate) {
													rebate = water.getFdianlv();
												}
											}
										}
									}
								}
							}
							if (rebate != 0.00) {
								double rebateMoney = money * rebate;
								flowChange(user, admin, rebateMoney, "每日返水", moneys);
							}
						}
					} else {
						List<Fanshui> months = fanshuiMapper.getTypefanshui(type);
						TodayRecord record2 = yunyingbbService.findOperateRecord(DateUtil.getLast12Months(1), "", user.getName(),1);//本月
						Double moneys = record2.getChongzhi();//用户的充值总计
						Double damal = record2.getTouzhu();//用户的打码总计
						if (months.size() > 0) {
							for (Fanshui water : months) {
								if (water.getState() == 1) {
									if (water.getJine() != 0.00) {
										if (moneys >= water.getJine() && damal >= water.getDamal()) {
											if (water.getFdianlv() > rebate) {
												rebate = water.getFdianlv();
											}
										}
									} else {
										if (water.getDamal() != 0.00) {
											if (damal >= water.getDamal()) {
												if (water.getFdianlv() > rebate) {
													rebate = water.getFdianlv();
												}
											}
										}
									}
								}
							}
							if (rebate != 0.00) {
								double rebateMoney = money * rebate;
								flowChange(user, admin, rebateMoney, "每月返水", moneys);
							}
						}
					}
				} catch (Exception e) {
					continue;
				}
			}
		}
		return 0;

	}

	public int flowChange(User user, AdminUser admin, double total, String model, double record) {
		SimpleDateFormat sf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		SimpleDateFormat ff = new SimpleDateFormat("yyyyMMddHHmmss");
		user = userMapper.getUserByid(user.getId());
		double amount = user.getBalance() + total;
		Liushui flow = new Liushui();
		flow.setHuiyuanzh(user.getName());
		flow.setBdtype(model);
		flow.setBdqjine(user.getBalance());
		flow.setBdjine(total);
		flow.setBdhjine(amount);
		flow.setCreatetime(sf.format(new Date()));
		flow.setOrdernum("FS" + ff.format(new Date())+user.getId());
		flow.setPeriod("-");
		flow.setCname("-");
		flow.setCzname(admin.getName());
		flow.setBeizhu(model);
		flow.setState(true);
		flow.setStatu(0);
		flow.setUser_type(user.getState());
		flow.setUserid(user.getId());
		user.setBalance(amount);
		user.setCreatetime(DateUtil.getCurrTime());
		liushuiMapper.addUserFlowingWaterRecrod(flow);
		userMapper.updateUserInfo(user);
		// 反水记录
		FanshuiJl fanshui = new FanshuiJl();
		fanshui.setName(user.getName());
		fanshui.setRichongzhi(record);
		fanshui.setRifanshui(total);
		fanshui.setCreatetime(DateUtil.getCurrTime());
		fanshui.setState(1);
		fanshui.setUserid(user.getId());
		fanshuiJlMapper.add(fanshui);
		return 1;
	}
	
	@Override
	public List<String> findUserWaterCount(User user) {
		DecimalFormat dec = new DecimalFormat("#0.00");
		TodayRecord record1 = yunyingbbService.findOperateRecord(DateUtil.findFormatDate(), "", user.getName(),1);//今日
		Double chongzhi1 = record1.getChongzhi();//用户的充值总计
		Double touzhu1 = record1.getTouzhu();//用户的打码总计
		TodayRecord record2 = yunyingbbService.findOperateRecord(DateUtil.getLast12Months(0), "", user.getName(),1);//本月
		Double chongzhi2 = record2.getChongzhi();//用户的充值总计
		Double touzhu2 = record2.getTouzhu();//用户的打码总计
		List<String> list = new ArrayList<String>();
		list.add(dec.format(chongzhi1));
		list.add(dec.format(touzhu1));
		list.add(dec.format(chongzhi2));
		list.add(dec.format(touzhu2));
		return list;
	}

}