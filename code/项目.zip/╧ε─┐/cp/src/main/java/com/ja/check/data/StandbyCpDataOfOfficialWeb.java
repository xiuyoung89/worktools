package com.ja.check.data;

/**
 * @DESC: 从彩票控网站爬取彩票数据的备用类
 * @AUTH: qhzh 
 * @DATE: 2018年9月3日 下午3:44:04
 */
public class StandbyCpDataOfOfficialWeb {

	
	
	public static void main(String[] args) {
	}
}
