package com.ja.domain;

import java.io.Serializable;

public class Yunyingbb implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 4341704431293496744L;

	private Integer id;// 运营管理报表

	private String huiyuanzh;// 会员帐号

	private String huiyuanlx;// 会员类型

	private Double touzhuzj;// 投注总记

	private Double zhongjiangzj;// 中奖总记

	private Double cunkuanzj;// 存款总记

	private Double cunkuanzszj;// 存款赠送总记

	private Double zhucezszj;// 注册赠送总记

	private Double huodongzj;// 注册赠送总记

	private Double tikuanzj;// 提款总记

	private Double fandianzj;// 返点总记

	private Double fanshuizj;// 返水总记

	private Double sdjiakuan;// 手动加款总记

	private Double sdkoukuan;// 手动扣款总记

	private Double yunyingky;// 运营亏盈

	private Double cpxiazhuzj;// 彩票下注

	private Double cppaijiangzj;// 彩票派奖

	private Double xtxiazhuzj;// 系统彩下注

	private Double xtpaijiangzj;// 系统彩派奖
	
	private Double ytouzhuzj;// 系统彩派奖
	
	private Double yzhongjiangzj;// 已中奖总计
	
	private String createtime;// 创建时间

	private Integer userid; // 用户id

	private String month; // 月份

    
    public static long getSerialversionuid() {
		return serialVersionUID;
	}
	public String getMonth() {
		return month;
	}

	public void setMonth(String month) {
		this.month = month;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getHuiyuanzh() {
		return huiyuanzh;
	}

	public void setHuiyuanzh(String huiyuanzh) {
		this.huiyuanzh = huiyuanzh == null ? null : huiyuanzh.trim();
	}

	public Double getFanshuizj() {
		return fanshuizj;
	}

	public void setFanshuizj(Double fanshuizj) {
		this.fanshuizj = fanshuizj;
	}

	public String getHuiyuanlx() {
		return huiyuanlx;
	}

	public void setHuiyuanlx(String huiyuanlx) {
		this.huiyuanlx = huiyuanlx == null ? null : huiyuanlx.trim();
	}

	public Double getTouzhuzj() {
		return touzhuzj;
	}

	public void setTouzhuzj(Double touzhuzj) {
		this.touzhuzj = touzhuzj;
	}

	public Double getZhongjiangzj() {
		return zhongjiangzj;
	}

	public void setZhongjiangzj(Double zhongjiangzj) {
		this.zhongjiangzj = zhongjiangzj;
	}

	public Double getCunkuanzj() {
		return cunkuanzj;
	}

	public void setCunkuanzj(Double cunkuanzj) {
		this.cunkuanzj = cunkuanzj;
	}

	public Double getCunkuanzszj() {
		return cunkuanzszj;
	}

	public Double getYtouzhuzj() {
		return ytouzhuzj;
	}

	public void setYtouzhuzj(Double ytouzhuzj) {
		this.ytouzhuzj = ytouzhuzj;
	}

	public void setCunkuanzszj(Double cunkuanzszj) {
		this.cunkuanzszj = cunkuanzszj;
	}

	public Double getZhucezszj() {
		return zhucezszj;
	}

	public void setZhucezszj(Double zhucezszj) {
		this.zhucezszj = zhucezszj;
	}

	public Double getHuodongzj() {
		return huodongzj;
	}

	public void setHuodongzj(Double huodongzj) {
		this.huodongzj = huodongzj;
	}

	public Double getTikuanzj() {
		return tikuanzj;
	}

	public void setTikuanzj(Double tikuanzj) {
		this.tikuanzj = tikuanzj;
	}

	public Double getFandianzj() {
		return fandianzj;
	}

	public void setFandianzj(Double fandianzj) {
		this.fandianzj = fandianzj;
	}

	public Double getSdjiakuan() {
		return sdjiakuan;
	}

	public void setSdjiakuan(Double sdjiakuan) {
		this.sdjiakuan = sdjiakuan;
	}

	public Double getSdkoukuan() {
		return sdkoukuan;
	}

	public void setSdkoukuan(Double sdkoukuan) {
		this.sdkoukuan = sdkoukuan;
	}

	public Double getYunyingky() {
		return yunyingky;
	}

	public void setYunyingky(Double yunyingky) {
		this.yunyingky = yunyingky;
	}

	public Integer getUserid() {
		return userid;
	}

	public void setUserid(Integer userid) {
		this.userid = userid;
	}

	public String getCreatetime() {
		return createtime;
	}

	public void setCreatetime(String createtime) {
		this.createtime = createtime;
	}

	public Double getCpxiazhuzj() {
		return cpxiazhuzj;
	}

	public void setCpxiazhuzj(Double cpxiazhuzj) {
		this.cpxiazhuzj = cpxiazhuzj;
	}

	public Double getCppaijiangzj() {
		return cppaijiangzj;
	}

	public void setCppaijiangzj(Double cppaijiangzj) {
		this.cppaijiangzj = cppaijiangzj;
	}

	public Double getXtxiazhuzj() {
		return xtxiazhuzj;
	}

	public void setXtxiazhuzj(Double xtxiazhuzj) {
		this.xtxiazhuzj = xtxiazhuzj;
	}

	public Double getXtpaijiangzj() {
		return xtpaijiangzj;
	}

	public void setXtpaijiangzj(Double xtpaijiangzj) {
		this.xtpaijiangzj = xtpaijiangzj;
	}

	public Double getYzhongjiangzj() {
		return yzhongjiangzj;
	}

	public void setYzhongjiangzj(Double yzhongjiangzj) {
		this.yzhongjiangzj = yzhongjiangzj;
	}

	@Override
	public String toString() {
		return "Yunyingbb [id=" + id + ", huiyuanzh=" + huiyuanzh + ", huiyuanlx=" + huiyuanlx + ", touzhuzj="
				+ touzhuzj + ", zhongjiangzj=" + zhongjiangzj + ", cunkuanzj=" + cunkuanzj + ", cunkuanzszj="
				+ cunkuanzszj + ", zhucezszj=" + zhucezszj + ", huodongzj=" + huodongzj + ", tikuanzj=" + tikuanzj
				+ ", fandianzj=" + fandianzj + ", fanshuizj=" + fanshuizj + ", sdjiakuan=" + sdjiakuan + ", sdkoukuan="
				+ sdkoukuan + ", yunyingky=" + yunyingky + ", cpxiazhuzj=" + cpxiazhuzj + ", cppaijiangzj="
				+ cppaijiangzj + ", xtxiazhuzj=" + xtxiazhuzj + ", xtpaijiangzj=" + xtpaijiangzj + ", ytouzhuzj="
				+ ytouzhuzj + ", yzhongjiangzj=" + yzhongjiangzj + ", createtime=" + createtime + ", userid=" + userid
				+ ", month=" + month + "]";
	}

	public Yunyingbb() {
		super();
	}
}