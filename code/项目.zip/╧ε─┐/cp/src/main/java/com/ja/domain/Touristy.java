package com.ja.domain;

public class Touristy {
	
	private int id;
	
	private String ip;
	//最近访问时间
	private String accessTime;
	//访问次数
	private int frequency;
	//上次访问时间
	private String lastVisitTime;
	//第一次访问时间
	private String firstVisitTime;
	public String getFirstVisitTime() {
		return firstVisitTime;
	}
	public void setFirstVisitTime(String firstVisitTime) {
		this.firstVisitTime = firstVisitTime;
	}
	//访问了哪些页面
	private String whichPagesWereVisited;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getIp() {
		return ip;
	}
	public void setIp(String ip) {
		this.ip = ip;
	}
	public String getAccessTime() {
		return accessTime;
	}
	public void setAccessTime(String accessTime) {
		this.accessTime = accessTime;
	}
	public int getFrequency() {
		return frequency;
	}
	public void setFrequency(int frequency) {
		this.frequency = frequency;
	}
	public String getLastVisitTime() {
		return lastVisitTime;
	}
	public void setLastVisitTime(String lastVisitTime) {
		this.lastVisitTime = lastVisitTime;
	}
	public String getWhichPagesWereVisited() {
		return whichPagesWereVisited;
	}
	public void setWhichPagesWereVisited(String whichPagesWereVisited) {
		this.whichPagesWereVisited = whichPagesWereVisited;
	}
	@Override
	public String toString() {
		return "Touristy [id=" + id + ", ip=" + ip + ", accessTime=" + accessTime + ", frequency=" + frequency
				+ ", lastVisitTime=" + lastVisitTime + ", whichPagesWereVisited=" + whichPagesWereVisited
				+ ", whichPagesWereVisitedLastTime= + ]";
	}
	
}
