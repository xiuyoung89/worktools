package com.ja.util;

import java.io.File;

import javax.servlet.http.HttpServletRequest;

import org.springframework.web.multipart.MultipartFile;

/**
 * @AUTH LBQ
 * @DATE 2017年11月10日 下午2:35:02
 * @DESC 
 */
public class UploadUtil {
	public String upload(MultipartFile file,HttpServletRequest request,String name,String path){  
        File dir = new File(path,name);  
        if(!dir.exists()){  
            dir.mkdirs();  
        }
        try {
			file.transferTo(dir);
		} catch (Exception e) {
			System.out.println(e);
		}
        return name;
    }  
}
