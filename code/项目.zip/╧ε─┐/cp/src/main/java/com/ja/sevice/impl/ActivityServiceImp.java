package com.ja.sevice.impl;

import java.util.Date;
import java.util.List;

import javax.annotation.Resource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;

import com.ja.dao.ActivityMapper;
import com.ja.dao.ActivitySurveyMapper;
import com.ja.dao.LiushuiMapper;
import com.ja.dao.UserMapper;
import com.ja.domain.Activity;
import com.ja.domain.ActivitySurvey;
import com.ja.domain.AdminUser;
import com.ja.domain.Liushui;
import com.ja.domain.User;
import com.ja.sevice.IActivityService;
import com.ja.util.DateUtil;
public class ActivityServiceImp implements IActivityService {

	@Resource(name="activityMapper")
	private ActivityMapper activityMapper; 
	
	@Autowired
	private ActivitySurveyMapper activitySurveyMapper;
	
	@Autowired
	private LiushuiMapper liushuiMapper;
	
	@Autowired
	private UserMapper userMapper;	
	
	
	@Override
	public int Recharge(User user, String orderNum,double money,String rechargeType) {
		//double amount = 0.00;
		AdminUser admin = new AdminUser();
		admin.setName("管理员后台赠送");
		//List<Activity> active = activityMapper.findEnableActivity();
		//if (active.size() > 0) {
			//for (int i = 0; i < active.size(); i++) {
				/*if ("人工加款".equals(rechargeType) && active.get(i).getType() == 1) {
					amount = money * active.get(0).getPresent2();
					flowChange(user, admin, orderNum, amount, "充值赠送", 1);
				} else if ("在线充值".equals(rechargeType) && active.get(i).getType() == 1) {
					amount = money * active.get(0).getPresent1();
					flowChange(user, admin, orderNum, amount, "充值赠送", 1);
				} else if ("注册赠送".equals(rechargeType) && active.get(i).getType() == 0) {
					flowChange(user, admin, orderNum, money, "注册赠送", 1);
				}else*/ 
				if("活动赠送".equals(rechargeType)) {
					flowChange(user, admin, orderNum, money, "活动赠送", 1);
				}
		//	}
		//}
		return 1;
	}
	/**
	 * 
	   *   方法名：flowChange   
	   *   描述：     充值和注册活动 进行  添加流水记录                  TODO   
	   *   参数：    @param user 用户信息
	   *   参数：    @param admin 管理员信息
	   *   参数：    @param orderNum 操作订单号
	   *   参数：    @param total 变动金额
	   *   参数：    @param model 变动类型 代号
	   *   参数：    @param type 变动类型 具体
	   *   参数：    @return 
	 * @return: int
	 */
	@Transactional
	public int flowChange(User user, AdminUser admin, String orderNum,double total, String model, int type) {
		user = userMapper.getUserByid(user.getId());
		if(total<=0.00) {
        	return 1; 
        }
		double amount = user.getBalance() + total;
		Liushui flow = new Liushui();
		flow.setHuiyuanzh(user.getName());
		flow.setBdtype(model);
		flow.setBdqjine(user.getBalance());
		flow.setBdjine(total);
		flow.setBdhjine(amount);
		flow.setCreatetime(DateUtil.getCurrTime());
		flow.setOrdernum(orderNum);
		flow.setPeriod("-");
		flow.setCname("-");
		flow.setCzname(admin.getName());
		flow.setBeizhu(model);
		flow.setState(true);
		flow.setStatu(0);
		flow.setUser_type(user.getState());
		flow.setUserid(user.getId());
		user.setBalance(amount);
		user.setCreatetime(DateUtil.getCurrTime());
		liushuiMapper.addUserFlowingWaterRecrod(flow);
		userMapper.updateUserInfo(user);
		return 1;
	}
	
	
	@Override
	public List<Activity> findEnableActivity() {
		return activityMapper.findEnableActivity();
	}
	
	@Override
	public List<Activity> findAllActivity() {
		return activityMapper.findAllActivity();
	}

	@Override
	public Activity findOneActivity(Integer id) {
		return activityMapper.findOneActivity(id);
	}
	
	@Override
	public List<Activity> findActivityByType(int type) {
		return activityMapper.findActivityByType(type);
	}
	
	@Override
	public Integer addtianjiahuodong(String name) {
		return activityMapper.addtianjiahuodong(name,new Date());
	}
	
	@Override
	public Integer insertActivity(Activity activity) {
		activityMapper.insertActivity(activity);
		return activity.getId();
	}

	public Integer updateActivity(Activity activity){
		activity.setCreated_time(new Date());
		return activityMapper.updateActivity(activity);
	}
	
	@Override
	public Integer updateAlter(Activity activity) {
		return activityMapper.updateAlter(activity);
	}
	
	@Override
	public int deletehd(Integer id) {
		return activityMapper.deletehd(id);
	}
	
	@Override
	public int sortActivity(Integer sort, Integer id) {
		return activityMapper.sortActivity(sort, id);
	}
	
	@Override
	public int addActivitySurvey(ActivitySurvey survey) {
		return activitySurveyMapper.addActivitySurvey(survey);
	}

	@Override
	public ActivitySurvey getOneSurvey(Integer userid, Integer id) {
		return activitySurveyMapper.getOneSurvey(userid,id);
	}

}
