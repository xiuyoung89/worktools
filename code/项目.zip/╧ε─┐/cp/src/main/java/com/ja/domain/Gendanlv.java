package com.ja.domain;

import java.io.Serializable;

public class Gendanlv implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -6737350001519629776L;

	private Integer id;//跟单推荐费赔率设置

	private Integer severalTime;//跟单推荐费赔率设置
	
	private Double rebate1;//推荐费比例
	
	private Double rebate2;//推荐费比例
	
	private Double rebate3;//推荐费比例
	
	private Double rebate4;//推荐费比例
	
	private Double rebate5;//推荐费比例
	
	private Double rebate6;//推荐费比例
	
	private Double rebate7;//推荐费比例
	
	private Double rebate8;//推荐费比例
	
	private Double rebate9;//推荐费比例
	
	private Double rebate10;//推荐费比例
	
	private String czname; //操作管理员
	
	private String createTime;//操作时间

    public static long getSerialversionuid() {
		return serialVersionUID;
	}
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Integer getSeveralTime() {
		return severalTime;
	}

	public void setSeveralTime(Integer severalTime) {
		this.severalTime = severalTime;
	}

	public Double getRebate1() {
		return rebate1;
	}

	public void setRebate1(Double rebate1) {
		this.rebate1 = rebate1;
	}

	public Double getRebate2() {
		return rebate2;
	}

	public void setRebate2(Double rebate2) {
		this.rebate2 = rebate2;
	}

	public Double getRebate3() {
		return rebate3;
	}

	public void setRebate3(Double rebate3) {
		this.rebate3 = rebate3;
	}

	public Double getRebate4() {
		return rebate4;
	}

	public void setRebate4(Double rebate4) {
		this.rebate4 = rebate4;
	}

	public Double getRebate5() {
		return rebate5;
	}

	public void setRebate5(Double rebate5) {
		this.rebate5 = rebate5;
	}

	public Double getRebate6() {
		return rebate6;
	}

	public void setRebate6(Double rebate6) {
		this.rebate6 = rebate6;
	}

	public Double getRebate7() {
		return rebate7;
	}

	public void setRebate7(Double rebate7) {
		this.rebate7 = rebate7;
	}

	public Double getRebate8() {
		return rebate8;
	}

	public void setRebate8(Double rebate8) {
		this.rebate8 = rebate8;
	}

	public Double getRebate9() {
		return rebate9;
	}

	public void setRebate9(Double rebate9) {
		this.rebate9 = rebate9;
	}

	public Double getRebate10() {
		return rebate10;
	}

	public void setRebate10(Double rebate10) {
		this.rebate10 = rebate10;
	}

	public String getCzname() {
		return czname;
	}

	public void setCzname(String czname) {
		this.czname = czname;
	}

	public String getCreateTime() {
		return createTime;
	}

	public void setCreateTime(String createTime) {
		this.createTime = createTime;
	}

	@Override
	public String toString() {
		return "Gendanlv [id=" + id + ", severalTime=" + severalTime + ", rebate1=" + rebate1 + ", rebate2=" + rebate2
				+ ", rebate3=" + rebate3 + ", rebate4=" + rebate4 + ", rebate5=" + rebate5 + ", rebate6=" + rebate6
				+ ", rebate7=" + rebate7 + ", rebate8=" + rebate8 + ", rebate9=" + rebate9 + ", rebate10=" + rebate10
				+ ", czname=" + czname + ", createTime=" + createTime + "]";
	}

	public Gendanlv() {
		super();
	}
	
}