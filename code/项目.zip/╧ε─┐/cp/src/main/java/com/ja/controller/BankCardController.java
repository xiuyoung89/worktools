package com.ja.controller;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.ja.domain.Activity;
import com.ja.domain.BankCard;
import com.ja.domain.User;
import com.ja.sevice.IActivityService;
import com.ja.sevice.IBankService;
import com.ja.sevice.IUserService;
import com.ja.util.JsonResult;

/**
 * @AUTH LBQ 银行卡信息
 * @DATE 2017年11月1日 下午5:24:35
 */
@Controller
@RequestMapping("/bank")
public class BankCardController {

	@Autowired
	private IBankService bankService;

	@Autowired
	private IActivityService activityService;
	
	@Autowired
	private IUserService userService;
	
	@RequestMapping("/bank")
	public String bank() {
		return "u/bank";
	}

	/** 添加以及修改-银行卡信息以及支付密码 */
	@RequestMapping("/save")
	public ModelAndView save(HttpSession session, BankCard bank) {
		User user = (User) session.getAttribute("user");
		bank.setUserid(user.getId());
		bank.setName(user.getName());
		int a  = bankService.save(bank);
		String message ="";
		if(a==1) {
			message = "恭喜你,添加银行卡成功!";
		}else if(a==2) {
			message = "你已经添加过银行卡了,不要重复添加哦!";
		}else {
			message = "银行卡信息修改成功!";
		}
		return new ModelAndView("u/bank").addObject("bank", bank).addObject("message",message);
	}
	
	/**
	 * 
	   *   方法名：save1   
	   *   描述：     添加以及修改-银行卡信息以及支付密码                  TODO   
	   *   参数：    @param session
	   *   参数：    @param bank
	   *   参数：    @return 
	 * @return: JsonResult
	 */
	@ResponseBody
	@RequestMapping("/save1")
	public JsonResult save1(HttpSession session, BankCard bank) {
		User users = (User) session.getAttribute("user");
		User user = userService.getUserByid(users.getId());
		SimpleDateFormat ss = new SimpleDateFormat("yyyyMMddHHmmss");
		if(user.getState() == 2) {
			return new JsonResult("0","试玩账号不能绑定银行卡");
		}
		BankCard bankcard = bankService.getBankByUid(user.getId());
		String message = "9";
		Integer data = 9;
		if (bankcard == null) {
			bank.setName(user.getName());
			bank.setUserid(user.getId());
			int num = bankService.save(bank);
			if (num == 1) {
				/** 查询赠送活动是否还在进行、以及查询赠送金额 */
				List<Activity> activity = activityService.findActivityByType(0);
				if (activity.size() == 1) {
					if(activity.get(0).getStatus() == 1) {
						double money = activity.get(0).getPresent();
						activityService.Recharge(user,"HD"+ss.format(new Date())+user.getId() ,money, "注册赠送");
					}
				}
			}
			message = "1";
			data = num;
		} else {
			bankcard.setZhifupass(bank.getZhifupass());
			bankService.save(bankcard);
		}
		return new JsonResult(message, data);
	}

	/** 根据用户id查询银行卡信息 */
	@ResponseBody
	@RequestMapping("/getBankid")
	public JsonResult getBankid(HttpSession session) {
		User user = (User) session.getAttribute("user");
		BankCard bank = bankService.getBankByUid(user.getId());
		try {
			bank.getName();
			bank.setYue(user.getBalance());
			return new JsonResult("xinxi", bank);
		} catch (Exception e) {
			return new JsonResult("id", 0);
		}
	}


}
