package com.ja.sevice.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ja.dao.BankMapper;
import com.ja.domain.BankCard;
import com.ja.domain.User;
import com.ja.sevice.IBankService;

/**
 * @DESC
 * @AUTH LBQ
 * @DATE 2018年1月18日 下午11:05:40
 */
@Service("bankService")
public class BankServiceImpl implements IBankService {

	@Autowired
	private BankMapper bankMapper;

	@Override
	public int save(BankCard bank) {
		if (bank.getId() != null) {
			bankMapper.upd(bank);
			return 3;
		} else {
			return bankMapper.add(bank);
		}
	}

	@Override
	public BankCard getBankByUid(Integer id) {
		return bankMapper.getBankByUid(id);
	}

	@Override
	public List<BankCard> getAll() {
		return bankMapper.getAll();
	}

	@Override
	public BankCard checkPass(String pass, Integer id) {
		return bankMapper.checkPass(pass, id);
	}
	
	@Override
	public User queryUser(User user) {
		return bankMapper.queryUser(user);
	}
	
	@Override
	public int updataUser(User user) {
		return bankMapper.updataUser(user);
	}

	@Override
	public BankCard inquiryBankCard(String str) {
		return bankMapper.inquiryBankCard(str);
	}
}
