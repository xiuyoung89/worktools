package com.ja.domain;

import java.io.Serializable;

public class Lotter implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = -123262077254280777L;

	private Integer id;

	private String name;

	private String cname;

	private String timespace;

	private String img;

	private String color;

	private String classt;
	
	private Integer whetherOrNotToCode;//判断当前彩种是否开启打码

	private String helpurl;

	private Integer types;
	
	private Integer type; 

	private String startTime;

	private String endTime;

	private Integer zoushitu;
	
	private String des;

	private String rename;

	private String rebate1;

	private String rebate2;

	private String rebate3;

	private String rebate4;

	private String rebate5;

	private String rebate6;

	private String rebate7;

	private String rebate8;

	private String rebate9;

	private String rebate10;

	private String rebate11;

	private String rebate12;

	private String rebate13;

	private String rebate14;

	private String rebate15;

	private String rebate16;

	private String rebate17;

	private String rebate18;

	private String rebate19;

	private String rebate20;

	private String rebate21;

	private String rebate22;

	private String rebate23;

	private String rebate24;

	private String rebate25;

	private String rebate26;

	private String rebate27;

	private String rebate28;

	private String rebate29;

	private String rebate30;

	private String rebate31;

	private String rebate32;

	private String rebate33;

	private String rebate34;

	private String rebate35;

	private String rebate36;

	private String rebate37;

	private String rebate38;

	private String rebate39;

	private String rebate40;

	private Integer state;

    
    public static long getSerialversionuid() {
		return serialVersionUID;
	}
	public Integer getId() {

		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name == null ? null : name.trim();
	}

	public String getCname() {
		return cname;
	}

	public void setCname(String cname) {
		this.cname = cname == null ? null : cname.trim();
	}

	public String getTimespace() {
		return timespace;
	}

	public void setTimespace(String timespace) {
		this.timespace = timespace == null ? null : timespace.trim();
	}

	public String getImg() {
		return img;
	}

	public void setImg(String img) {
		this.img = img == null ? null : img.trim();
	}

	public String getColor() {
		return color;
	}

	public String getClasst() {
		return classt;
	}

	public void setClasst(String classt) {
		this.classt = classt;
	}

	public void setColor(String color) {
		this.color = color == null ? null : color.trim();
	}

	public String getHelpurl() {
		return helpurl;
	}

	public void setHelpurl(String helpurl) {
		this.helpurl = helpurl == null ? null : helpurl.trim();
	}

	public Integer getState() {
		return state;
	}

	public void setState(Integer state) {
		this.state = state;
	}

	public Integer getType() {
		return type;
	}

	public void setType(Integer type) {
		this.type = type;
	}

	public String getStartTime() {
		return startTime;
	}

	public void setStartTime(String startTime) {
		this.startTime = startTime;
	}

	public Integer getZoushitu() {
		return zoushitu;
	}

	public void setZoushitu(Integer zoushitu) {
		this.zoushitu = zoushitu;
	}

	public String getRebate40() {
		return rebate40;
	}

	public void setRebate40(String rebate40) {
		this.rebate40 = rebate40;
	}

	public String getEndTime() {
		return endTime;
	}

	public void setEndTime(String endTime) {
		this.endTime = endTime;
	}

	public String getRebate1() {
		return rebate1;
	}

	public void setRebate1(String rebate1) {
		this.rebate1 = rebate1;
	}

	public String getRebate2() {
		return rebate2;
	}

	public void setRebate2(String rebate2) {
		this.rebate2 = rebate2;
	}

	public String getRebate3() {
		return rebate3;
	}

	public void setRebate3(String rebate3) {
		this.rebate3 = rebate3;
	}

	public String getRebate4() {
		return rebate4;
	}

	public void setRebate4(String rebate4) {
		this.rebate4 = rebate4;
	}

	public String getRebate5() {
		return rebate5;
	}

	public void setRebate5(String rebate5) {
		this.rebate5 = rebate5;
	}

	public String getRebate6() {
		return rebate6;
	}

	public void setRebate6(String rebate6) {
		this.rebate6 = rebate6;
	}

	public String getRebate7() {
		return rebate7;
	}

	public void setRebate7(String rebate7) {
		this.rebate7 = rebate7;
	}

	public String getRebate8() {
		return rebate8;
	}

	public void setRebate8(String rebate8) {
		this.rebate8 = rebate8;
	}

	public String getRebate9() {
		return rebate9;
	}

	public void setRebate9(String rebate9) {
		this.rebate9 = rebate9;
	}

	public String getRebate10() {
		return rebate10;
	}

	public void setRebate10(String rebate10) {
		this.rebate10 = rebate10;
	}

	public String getRebate11() {
		return rebate11;
	}

	public void setRebate11(String rebate11) {
		this.rebate11 = rebate11;
	}

	public String getRebate12() {
		return rebate12;
	}

	public void setRebate12(String rebate12) {
		this.rebate12 = rebate12;
	}

	public String getRebate13() {
		return rebate13;
	}

	public void setRebate13(String rebate13) {
		this.rebate13 = rebate13;
	}

	public String getRebate14() {
		return rebate14;
	}

	public void setRebate14(String rebate14) {
		this.rebate14 = rebate14;
	}

	public String getRebate15() {
		return rebate15;
	}

	public void setRebate15(String rebate15) {
		this.rebate15 = rebate15;
	}

	public String getRebate16() {
		return rebate16;
	}

	public void setRebate16(String rebate16) {
		this.rebate16 = rebate16;
	}

	public String getRebate17() {
		return rebate17;
	}

	public void setRebate17(String rebate17) {
		this.rebate17 = rebate17;
	}

	public String getRebate18() {
		return rebate18;
	}

	public void setRebate18(String rebate18) {
		this.rebate18 = rebate18;
	}

	public String getRebate19() {
		return rebate19;
	}

	public void setRebate19(String rebate19) {
		this.rebate19 = rebate19;
	}

	public String getRebate20() {
		return rebate20;
	}

	public void setRebate20(String rebate20) {
		this.rebate20 = rebate20;
	}

	public String getRebate21() {
		return rebate21;
	}

	public void setRebate21(String rebate21) {
		this.rebate21 = rebate21;
	}

	public String getRebate22() {
		return rebate22;
	}

	public void setRebate22(String rebate22) {
		this.rebate22 = rebate22;
	}

	public String getRebate23() {
		return rebate23;
	}

	public void setRebate23(String rebate23) {
		this.rebate23 = rebate23;
	}

	public String getRebate24() {
		return rebate24;
	}

	public void setRebate24(String rebate24) {
		this.rebate24 = rebate24;
	}

	public String getRebate25() {
		return rebate25;
	}

	public void setRebate25(String rebate25) {
		this.rebate25 = rebate25;
	}

	public String getRebate26() {
		return rebate26;
	}

	public void setRebate26(String rebate26) {
		this.rebate26 = rebate26;
	}

	public String getRebate27() {
		return rebate27;
	}

	public void setRebate27(String rebate27) {
		this.rebate27 = rebate27;
	}

	public String getRebate28() {
		return rebate28;
	}

	public void setRebate28(String rebate28) {
		this.rebate28 = rebate28;
	}

	public String getRebate29() {
		return rebate29;
	}

	public void setRebate29(String rebate29) {
		this.rebate29 = rebate29;
	}

	public String getRebate30() {
		return rebate30;
	}

	public void setRebate30(String rebate30) {
		this.rebate30 = rebate30;
	}

	public String getRebate31() {
		return rebate31;
	}

	public void setRebate31(String rebate31) {
		this.rebate31 = rebate31;
	}

	public String getRebate32() {
		return rebate32;
	}

	public void setRebate32(String rebate32) {
		this.rebate32 = rebate32;
	}

	public String getRebate33() {
		return rebate33;
	}

	public void setRebate33(String rebate33) {
		this.rebate33 = rebate33;
	}

	public String getRebate34() {
		return rebate34;
	}

	public void setRebate34(String rebate34) {
		this.rebate34 = rebate34;
	}

	public String getRebate35() {
		return rebate35;
	}

	public void setRebate35(String rebate35) {
		this.rebate35 = rebate35;
	}

	public String getRebate36() {
		return rebate36;
	}

	public void setRebate36(String rebate36) {
		this.rebate36 = rebate36;
	}

	public String getRebate37() {
		return rebate37;
	}

	public void setRebate37(String rebate37) {
		this.rebate37 = rebate37;
	}

	public String getRebate38() {
		return rebate38;
	}

	public void setRebate38(String rebate38) {
		this.rebate38 = rebate38;
	}

	public String getRebate39() {
		return rebate39;
	}

	public void setRebate39(String rebate39) {
		this.rebate39 = rebate39;
	}

	public Integer getTypes() {
		return types;
	}

	public void setTypes(Integer types) {
		this.types = types;
	}

	public String getRename() {
		return rename;
	}

	public void setRename(String rename) {
		this.rename = rename;
	}

	public String getDes() {
		return des;
	}

	public void setDes(String des) {
		this.des = des;
	}
	public Integer getWhetherOrNotToCode() {
		return whetherOrNotToCode;
	}

	public void setWhetherOrNotToCode(Integer whetherOrNotToCode) {
		this.whetherOrNotToCode = whetherOrNotToCode;
	}

	@Override
	public String toString() {
		return "Lotter [id=" + id + ", name=" + name + ", cname=" + cname + ", timespace=" + timespace + ", img=" + img
				+ ", color=" + color + ", classt=" + classt + ", whetherOrNotToCode=" + whetherOrNotToCode
				+ ", helpurl=" + helpurl + ", types=" + types + ", type=" + type + ", startTime=" + startTime
				+ ", endTime=" + endTime + ", zoushitu=" + zoushitu + ", des=" + des + ", rename=" + rename
				+ ", rebate1=" + rebate1 + ", rebate2=" + rebate2 + ", rebate3=" + rebate3 + ", rebate4=" + rebate4
				+ ", rebate5=" + rebate5 + ", rebate6=" + rebate6 + ", rebate7=" + rebate7 + ", rebate8=" + rebate8
				+ ", rebate9=" + rebate9 + ", rebate10=" + rebate10 + ", rebate11=" + rebate11 + ", rebate12="
				+ rebate12 + ", rebate13=" + rebate13 + ", rebate14=" + rebate14 + ", rebate15=" + rebate15
				+ ", rebate16=" + rebate16 + ", rebate17=" + rebate17 + ", rebate18=" + rebate18 + ", rebate19="
				+ rebate19 + ", rebate20=" + rebate20 + ", rebate21=" + rebate21 + ", rebate22=" + rebate22
				+ ", rebate23=" + rebate23 + ", rebate24=" + rebate24 + ", rebate25=" + rebate25 + ", rebate26="
				+ rebate26 + ", rebate27=" + rebate27 + ", rebate28=" + rebate28 + ", rebate29=" + rebate29
				+ ", rebate30=" + rebate30 + ", rebate31=" + rebate31 + ", rebate32=" + rebate32 + ", rebate33="
				+ rebate33 + ", rebate34=" + rebate34 + ", rebate35=" + rebate35 + ", rebate36=" + rebate36
				+ ", rebate37=" + rebate37 + ", rebate38=" + rebate38 + ", rebate39=" + rebate39 + ", rebate40="
				+ rebate40 + ", state=" + state + "]";
	}

	public Lotter() {
		super();
	}

}