package com.ja.sevice;

import com.ja.domain.Gendanlv;

public interface GendanlvService {
	
	/**查询跟单推荐费比率*/
	Gendanlv getFindRebate();

	/**修改跟单的推荐比率*/
	int updateGendanlv(Gendanlv gendan);
	
	/**添加跟单的推荐费规则*/
	int addGendanlv(Gendanlv gendan);

	/**刪除跟单的推荐费规则*/
	int delGendanlv(Integer id);

}
