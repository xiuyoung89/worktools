package com.ja.controller;

import java.io.IOException;
import java.util.Map;
import java.util.concurrent.CopyOnWriteArraySet;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.socket.CloseStatus;
import org.springframework.web.socket.TextMessage;
import org.springframework.web.socket.WebSocketSession;
import org.springframework.web.socket.handler.TextWebSocketHandler;

import com.ja.sevice.IDataService;
import com.ja.sevice.JineService;
import com.ja.util.WebSocketJson;
/**
 * WebSocket后台处理类
 * @author Administrator
 *
 */
public class ChatWebSocketHandlerht extends TextWebSocketHandler{
	
	@Autowired
	private JineService jineService;
	
	@Autowired
	private IDataService dataService;
	
	public static CopyOnWriteArraySet<WebSocketSession> sessions = new CopyOnWriteArraySet<WebSocketSession>();
    /**
     * 接收文本消息，并发送出去
     * js调用websocket.send时候，会调用该方法
     * 
     * 接收消息并处理
     */
    @Override
    protected void handleTextMessage(WebSocketSession session, TextMessage message) throws Exception {
    	//chatTextMessageHandler(message.getPayload());
        //super.handleTextMessage(session, message);
    }
    /**
     * 连接成功以后触发这个方法
     * 可在这里处理离线的信息
     * 
     */
    @Override
    public void afterConnectionEstablished(WebSocketSession session) throws Exception {
		Map<String, Object> attributes = session.getAttributes();
		String admin = (String) attributes.get("admin");
		System.out.println("admin 后台建立连接成功"+ admin);
		sessions.add(session);
        //处理离线消息
		//把充值信息和提款信息 和在线人数 发送给后台
		int count = jineService.getCount();//充值
		if(count > 0) {
			WebSocketJson w = new WebSocketJson(0,admin,count);
			w.sendHt();
		}
		int countTk = jineService.getCountTk();//提款
		if(countTk > 0) {
			WebSocketJson w = new WebSocketJson(1,admin,countTk);
			w.sendHt();
		}
		int countAbnormalData = dataService.getAbnormalData();
		if(countAbnormalData > 0) {
			WebSocketJson w = new WebSocketJson(5,admin,1);//开奖数据异常   传0 没有异常数据  传1 有异常数据
			w.sendHt();
		}
    }
    /**
     * 抛出异常时处理
     * 抛出异常时关闭连接
     */
    @Override
    public void handleTransportError(WebSocketSession session, Throwable exception) throws Exception {
        if(session.isOpen()){
            session.close();
        }
        sessions.remove(session);
    }
    
    /**
     * 发送给指定用户
     * @param name  用户名
     * @param data  具体数据
     */
    public void send(String name,String data) {
    	ChatWebSocketHandlerht c = new ChatWebSocketHandlerht();
    	TextMessage t = new TextMessage(data);
    	c.sendMessageToUser(name,t);
    }
    /**
     * 当服务器关闭前调用次方法关闭所有websocket 连接以防止从新启动时出现错误
     */
    public void removes() {
    	System.out.println("我进来啦");
    	for (WebSocketSession user : sessions) {
    		try {
				user.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
    	}
    	sessions.clear();
    }
    
    
    /**
     * 当用户被强制下线时从websocket里面去掉这个用户
     */
    public static void removeName(String admin) {
    	System.out.println("我进来啦删除这个用户啦");
        for (WebSocketSession adminuser : sessions) {
            if (adminuser.getAttributes().get("admin").equals(admin)) {
            	try {
            		adminuser.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
            	sessions.remove(adminuser);
            	break;
            }
        }
    }
    
    /**
     * 给某个用户发送消息
     * @param userName会员名
     * @param message
     */
    public void sendMessageToUser(String adminName, TextMessage message) {
        for (WebSocketSession adminuser : sessions) {
            if (adminuser.getAttributes().get("admin").equals(adminName)) {
                try {
                    if (adminuser.isOpen()) {
                    	adminuser.sendMessage(message);
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                }
                break;
            }
        }
    }
    /**
     *给所有在线用户发送消息
     * @param data  具体数据
     */
    public void sendAll(String data) {
    	ChatWebSocketHandlerht c = new ChatWebSocketHandlerht();
    	TextMessage t = new TextMessage(data);
    	c.sendMessageToUsers(t);
    }
    /**
     * 给所有在线用户发送消息
     * @param message
     */
    public void sendMessageToUsers(TextMessage message) {
        for (WebSocketSession adminName : sessions) {
            try {
                if (adminName.isOpen()) {
                	adminName.sendMessage(message);
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
    /**
     * 关闭连接时触发 
     * 连接关闭后处理
     */
    @Override
    public void afterConnectionClosed(WebSocketSession session, CloseStatus closeStatus) throws Exception {
    	System.out.println(session.getAttributes().get("admin")+"断开了连接");
    	sessions.remove(session);
    }

    @Override
    public boolean supportsPartialMessages() {
        return false;
    }


}
