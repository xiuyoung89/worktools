package com.ja.controller;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.util.DigestUtils;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.ja.domain.Activity;
import com.ja.domain.BankCard;
import com.ja.domain.Jine;
import com.ja.domain.Liushui;
import com.ja.domain.PagingData;
import com.ja.domain.User;
import com.ja.sevice.AddPaymentService;
import com.ja.sevice.DepositBankService;
import com.ja.sevice.IActivityService;
import com.ja.sevice.IBankService;
import com.ja.sevice.IUserService;
import com.ja.sevice.JineService;
import com.ja.sevice.LiushuiService;
import com.ja.util.JsonResult;

@Controller
@RequestMapping("users")
public class PC_UserController {

	@Autowired
	private IUserService userService;
	
	@Autowired
	private IBankService bankService;

	@Autowired
	private IActivityService activityService;
	
	@Autowired
	private DepositBankService depositBankService;

	@Autowired
	private JineService jineService;

	@Autowired
	private LiushuiService liushuiService;

	@Autowired
	private AddPaymentService addPaymentService;

	
	/**
	 * 查询用户的信息
	 * @param session
	 * @return
	 */
	@RequestMapping("/userInfos")
	@ResponseBody
	public JsonResult userInfo(HttpSession session) { 
		User user = (User) session.getAttribute("user");
		User u = userService.getUserByid(user.getId());
		return new JsonResult("",u);
	}
	
	/**
	 * 查询用户的余额 
	 * @param session
	 * @return
	 */
	@RequestMapping("/userMoney")
	@ResponseBody
	public JsonResult userMoney(HttpSession session) { 
		User user = (User) session.getAttribute("user");
		User u = userService.getUserByid(user.getId());
		session.setAttribute("user", u);
		return new JsonResult(user.getStatu()+"", user.getBalance());
	}
	
	/**
	 * 修改用户密码
	 * @param pass 原密码
	 * @param npass 新密码
	 * @param session session对象
	 * @return
	 */
	@RequestMapping("/changePass")
	@ResponseBody
	public JsonResult changePass(String pass, String npass, HttpSession session) {
		User user = (User) session.getAttribute("user");
		npass = DigestUtils.md5DigestAsHex(DigestUtils.md5DigestAsHex(npass.getBytes()).getBytes());
		pass = DigestUtils.md5DigestAsHex(DigestUtils.md5DigestAsHex(pass.getBytes()).getBytes());
		if (pass.equals(user.getPass())) {
			user.setPass(pass);
			userService.updateUserInfo(user);
			User admin = userService.login(user.getName(), npass);
			session.setAttribute("user", admin);
			return new JsonResult("1", "修改成功");
		} else {
			return new JsonResult("0", "旧密码输入错误");
		}
	}
	

	/** 根据用户id查询银行卡信息 */
	@ResponseBody
	@RequestMapping("/getBankid")
	public JsonResult getBankid(HttpSession session) {
		User user = (User) session.getAttribute("user");
		BankCard bank = bankService.getBankByUid(user.getId());
		try {
			bank.getName();
			bank.setYue(user.getBalance());
			return new JsonResult("xinxi", bank);
		} catch (Exception e) {
			return new JsonResult("id", 0);
		}
	}
	
	
	/**
	 * 
	   *   方法名：save1   
	   *   描述：      添加用户以及修改-银行卡信息以及支付密码                 TODO   
	   *   参数：    @param session
	   *   参数：    @param bank
	   *   参数：    @return 
	 * @return: JsonResult
	 */
	@ResponseBody
	@RequestMapping("/save1")
	public JsonResult save1(HttpSession session, BankCard bank) {
		User users = (User) session.getAttribute("user");
		User user = userService.getUserByid(users.getId());
		SimpleDateFormat ss = new SimpleDateFormat("yyyyMMddHHmmss");
		BankCard bankcard = bankService.getBankByUid(user.getId());
		String message = "9";
		Integer data = 9;
		if (bankcard == null) {
			bank.setName(user.getName());
			bank.setUserid(user.getId());
			int num = bankService.save(bank);
			if (num == 1) {
				/** 查询赠送活动是否还在进行、以及查询赠送金额 */
				List<Activity> activity = activityService.findActivityByType(0);
				if (activity.size() == 1) {
					double money = activity.get(0).getPresent();
					activityService.Recharge(user,"HD"+ss.format(new Date())+user.getId(), money, "注册赠送");
				}
			}
			message = "1";
			data = num;
		} else {
			bankcard.setZhifupass(bank.getZhifupass());
			bankService.save(bankcard);
		}
		return new JsonResult(message, data);
	}
	
	/**
	 * 
	   *   方法名：acountBank   
	   *   描述：     查询所有的平台入款账号                  TODO   
	   *   参数：    @return 
	 * @return: JsonResult
	 */
	@ResponseBody
	@RequestMapping("/acountBank")
	public JsonResult acountBank() {
		return new JsonResult("", depositBankService.getAllDepositBank());
	}
	
	/**
	 * 
	   *   方法名：shoudongcz   
	   *   描述：      用户充值申请                 TODO   
	   *   参数：    @param jine 充值信息
	   *   参数：    @param session 
	   *   参数：    @param code 验证码
	   *   参数：    @return 
	 * @return: JsonResult
	 */
	@ResponseBody
	@RequestMapping("/shoudongcz")
	public JsonResult quickRecharge(Jine jine, HttpSession session,String code) {
		JsonResult jsonResult = jineService.quickRecharge(jine,session,code);
		return jsonResult;
	}

	/**
	 * 
	   *   方法名：userDamal   
	   *   描述：     客户提款申请 判断打码量                  TODO   
	   *   参数：    @param money
	   *   参数：    @param session
	   *   参数：    @return 
	 * @return: JsonResult
	 */
	@ResponseBody
	@RequestMapping("/userDamal")
	public JsonResult findUserCodeCount(Double money, HttpSession session) {
		User user = (User) session.getAttribute("user");
		JsonResult jsonResult = jineService.findUserCodeCount(user,money);
		return jsonResult;
	}

	/** 客户提款申请 */
	@ResponseBody
	@RequestMapping("/tikuansq")
	public JsonResult quickDrawing(Jine jine, String zhifupass, HttpSession session) {
		User user = (User) session.getAttribute("user");
		JsonResult jsonResult = jineService.quickDrawing(jine, user, zhifupass);
		return jsonResult;
	}

	/** 查询用户的充值记录 */
	@ResponseBody
	@RequestMapping("/onechongzhi")
	public JsonResult oneCzJl(HttpSession session) {
		User user = (User) session.getAttribute("user");
		List<Jine> list = jineService.onechongzhi(user.getId());
		return new JsonResult("onechongzhi", list);
	}

	/** 查询用户提款记录 */
	@ResponseBody
	@RequestMapping("/onetikuan")
	public JsonResult oneTkjl(HttpSession session) {
		User user = (User) session.getAttribute("user");
		List<Jine> list = jineService.onetikuan(user.getId());
		return new JsonResult("onetikuan", list);
	}

	/***
	 * 二维码支付
	   *   方法名：scavengingPayment   
	   *   描述：                       TODO   
	   *   参数：    @return 
	 * @return: JsonResult
	 */
	@ResponseBody
	@RequestMapping("/scavengingPayment")
	public JsonResult scavengingPayment() {
		return new JsonResult(null, addPaymentService.QueryPaymentInformation());
	}
	
	/**
	 * 查询用户的流水记录
	 * @param session
	 * @return
	 */
	@ResponseBody
	@RequestMapping("/details")
	public String details(PagingData paging,Liushui liushui, HttpSession session) {
		User user = (User) session.getAttribute("user");
		liushui.setUserid(user.getId());
		paging.setAllCount(liushuiService.getLiushuiCounts(liushui));
		paging.setList(liushuiService.getLiushuis(paging,liushui));
		return PagingData.pagingData(paging);
	}
	
	
	@ResponseBody
	@RequestMapping("/pcUserWhetherLogin")
	public JsonResult pcUserWhetherLogin(HttpSession session) {
		User user1 = (User) session.getAttribute("user");
		if(user1 == null) {
			return new JsonResult(null,0);//未登陆
		}
		if(user1.getState()== 0) {
			return new JsonResult(null,-1);//账号被禁用
		}
		User user = userService.getUserByid(user1.getId());
		if(user.getState()== 1||user.getState() == 2||user.getState() == 3) {//1.正规玩家 // 2.试玩玩家 /3.//内部玩家
			return new JsonResult(null,user.getState(),user.getBalance(),user.getName(),user.getVip(),user.getGamePlayer());
		}
		return new JsonResult(null,user.getState());  
	}
	
	
	
	
	
	
	
	
}

