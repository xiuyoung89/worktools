package com.ja.dao;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.ja.domain.Data;
import com.ja.domain.Joint;
import com.ja.domain.JointVo;

public interface JointMapper {
	// 增加合买
	int insertJoint(@Param("jo") Joint jo);

	// 所有订单号
	List<String> getFindJoint();

	// 发起的合买
	JointVo getAllJoint(String num);

	// 剩下的分数
	Integer getScountJoint(@Param("num") String num);

	// 个人发起的合买
	List<JointVo> getOneJoint(@Param("num") String num, @Param("userid") Integer userid);
	
	// 个人参与的合买
	List<JointVo> getOneJoint1(@Param("num") String num, @Param("userid") Integer userid);

	/** 实际的合买分数 */
	int getHfenshu(String orderNum);
	
	/**当前发起人合买信息*/
	Joint getFaqiJoint(String orderNum);
	
	/**根据当前订单号查询合买的用户信息*/
	List<Integer> getNumJoint(String orderNum);
	
	/**修改订单生效状态*/
	int upDingDan(@Param("ids")List<Integer> ids);
	
	/**修改实际保底分数
	 * @param sjine */
	int upBaodi(@Param("sjbdfs")int sjbdfs, @Param("sjine")double sjine, @Param("id")Integer id);
	
	/**修改退钱状态*/
	int upTuiQian(@Param("ids")List<Integer> ids);
	
	/**修改剩余分数*/
	int upSyCount(@Param("scount")int scount, @Param("id")Integer id, @Param("orderNum")String orderNum);
	
	/**历史记录*/
	List<Joint> getLishiJl();
	
	//查询所有的发起人
	List<Joint> chaxunfqr();

	//查询发起人的所有发起次数
	int chaxunsycs(String user);

	//查询发起人的中奖次数
	int chaxunzjcs(String user);
	
	//查询有没有参加合买
	Joint checkhm(@Param("orderNum")String orderNum, @Param("id")Integer id);
	
	//查询发起和参与的订单号
	List<String> getOrderNum(int i);

	/**某个彩种某期退钱*/
	List<Joint> getAllUser(@Param("d")Data data);
	
	/**官方开奖异常*/
	int chedan(@Param("o")Joint or);
	
}
