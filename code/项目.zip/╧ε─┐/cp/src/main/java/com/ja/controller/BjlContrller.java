package com.ja.controller;

import java.text.SimpleDateFormat;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.ja.domain.Bjl;
import com.ja.domain.Bjldata;
import com.ja.domain.Lotter;
import com.ja.domain.PagingData;
import com.ja.domain.Records;
import com.ja.domain.User;
import com.ja.domain.Yb;
import com.ja.sevice.BjlService;
import com.ja.sevice.BjlhtglService;
import com.ja.util.JsonResult;

/**
 * 百家乐
 * 
 * @author 
 */
@Controller
@RequestMapping("/b")
public class BjlContrller {
	@Autowired
	private BjlService bjlService;
	
	@Autowired
	BjlhtglService bjl;
	/**
	 * key返投注金额，value为用户名。
	 */
	public static Map<String, Integer> map1 = Collections.synchronizedMap(new HashMap<String, Integer>());

	@RequestMapping("/tableNumber")
	@ResponseBody
	public JsonResult tableNumber() {
		return new JsonResult(null, bjlService.tableNumber());
	}
	/**
	 * 查询历史开奖数据
	 * @param tableNumber
	 * @return
	 */
	@RequestMapping("/history")
	@ResponseBody
	public JsonResult history(Integer tableNumber) {
		if (tableNumber == null) {
			return new JsonResult(null, "桌号不能为空");
		}
		return new JsonResult("", bjlService.history(tableNumber));
	}
	/**
	 * 获取假硬币
	 * @param data
	 * @return
	 */
	@RequestMapping("/coin")
	@ResponseBody
	public JsonResult coin(Yb data,Integer tableNumber) {
		return new JsonResult(null, bjlService.coin(data,tableNumber));
	}

	@RequestMapping("/Record")
	@ResponseBody
	public JsonResult Record(HttpSession session) {
		User user = (User) session.getAttribute("user");
		List<Records> list = bjlService.hRecords1(user.getId());
		return new JsonResult(null, list);
	}
	/***
	 * 用户下注以及中奖的金额信息
	 * @param table_num 桌号
	 * @param period 期号
	 * @param session session对象
	 * @return
	 */
	@ResponseBody
	@RequestMapping("/findUserMoneyInfo")
	public JsonResult findUserMoneyInfo(String tableNumber, String issueNumber, HttpSession session) {
		User user = (User) session.getAttribute("user");
		return new JsonResult("findUserMoneyInfo",bjlService.findUserMoneyInfo(user.getId(), tableNumber, issueNumber));
	}
	/**
	 * 获取百家乐全部开奖数据
	 * @return
	 */
	@ResponseBody
	@RequestMapping("/bjlRoom")
	public JsonResult bjlRoom() {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
		List<Bjldata> bjldata = bjlService.bjlRoom();
		return new JsonResult(sdf.format(new Date()),bjldata);
	}
	
	/**
	 * 根据期号桌号查询开奖数据
	 * @return
	 */
	@ResponseBody
	@RequestMapping("/takeAwayTheAwardData")
	public JsonResult takeAwayTheAwardData(Bjl b) {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
		return new JsonResult(sdf.format(new Date()),bjlService.takeAwayTheAwardData(b));
	}
	/**
	 * 查询百家乐最新开奖的一期数据   
	 * @param b 需要的参数
	 * @return 查询到结果则返回Bjldata对象 如果没有查询到则返回null
	 */
	@ResponseBody
	@RequestMapping("/bjlLotter")
	public JsonResult bjlLotter(Bjl b) {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
		return new JsonResult(sdf.format(new Date()),bjlService.bjlLotter(b));
	}
	/**
	 * 下注接口
	 * @param b
	 * @param session
	 * @return
	 */
	@RequestMapping("/bjlBets")
	@ResponseBody
	public JsonResult bjlBets(Bjl b,HttpSession session) {
		User user = (User) session.getAttribute("user");
		return new JsonResult(null,bjlService.bjlBets(b,user),bjlService.Money(user.getId()));
	}
	/**
	 * 获取用户账户余额
	 * @param session
	 * @return
	 */
	@RequestMapping("/Money")
	@ResponseBody
	public JsonResult Money(HttpSession session) {
		User user = (User) session.getAttribute("user");
		Double Money = bjlService.Money(user.getId());
		return new JsonResult(null, Money);
	}
	/**
	 * 查询百家乐赔率
	 * @return 查询到则返回Lotter对象如果没有查询到则返回null
	 */
	@RequestMapping("/baccaratOdds")
	@ResponseBody
	public JsonResult bjlindex() {
		Lotter lotter = bjlService.bjlpl("百家乐", "bjl");
		return new JsonResult(null,lotter);
	}
	/**
	 *   方法名：kaijiangjilu   
	 *   描述：    百家乐开奖记录  默认查询前50条 
	 *   参数：    @param tableNumber 房间号
	 *   参数：    @return  查询到则返回list集合包含bjldata数据对象 如果没有查询到则返回一个空集合
	 * @return: JsonResult 查询到则返回list集合包含bjldata数据对象 如果没有查询到则返回一个空集
	 */
	@RequestMapping("/bjlkaijiangjilu")
	@ResponseBody
	public JsonResult bjlkaijiangjilu(Integer tableNumber) {
		return new JsonResult("success",bjlService.bjlkaijiangjilu(tableNumber));
	}
	/**
	 * 查询用户百家乐下注数据
	 * @param session 获取会员对象信息
	 * @param paging 分页对象
	 * @param time1
	 * @param time2
	 * @param period 
	 * @param state 开奖状态
	 * @param id
	 * @return 查询到数据则返回list集合里面包含bjl数据对象 如果没有查询到则返回一个空集合
	 */
	@RequestMapping(value="/historicalDownloads",produces="text/json;charset=UTF-8")
	@ResponseBody
	public String historicalDownloads(HttpSession session,PagingData paging,Integer status){
		User user = (User)session.getAttribute("user");
		paging.setAllCount(bjl.xiazjlCounts(user.getName(), null, null, null, status,null));
		paging.setList(bjl.xiazjl(paging,user.getName(), null, null, null, status,null,null));
		return PagingData.pagingData(paging);
	}
	
	@RequestMapping("/bettingRecord")
	@ResponseBody
	public JsonResult bettingRecord(HttpSession session,Integer id){
		User user = (User)session.getAttribute("user");
		return new JsonResult(null,bjlService.bettingRecord(user.getName(), id));
	}
	
}