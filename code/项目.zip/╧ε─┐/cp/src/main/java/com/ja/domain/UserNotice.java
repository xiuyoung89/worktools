package com.ja.domain;

import java.io.Serializable;

public class UserNotice implements Serializable{
	
  /**
	 * 
	 */
	private static final long serialVersionUID = 4469358084939749504L;

private Integer id; //平台用户内功公告
  
  private String title; //公告标题
  
  private String content; //公告内容
  
  private String contents; //带标题的公告内容
  
  private String  picture; //公告图片
  
  private String created_time; // 创建时间
  
  private Integer state; // 公告状态

  
  public static long getSerialversionuid() {
		return serialVersionUID;
	}
public Integer getId() {
	return id;
}

public void setId(Integer id) {
	this.id = id;
}

public String getTitle() {
	return title;
}

public void setTitle(String title) {
	this.title = title;
}

public String getContent() {
	return content;
}

public void setContent(String content) {
	this.content = content;
}

public String getPicture() {
	return picture;
}

public void setPicture(String picture) {
	this.picture = picture;
}

public String getCreated_time() {
	return created_time;
}

public void setCreated_time(String created_time) {
	this.created_time = created_time;
}

public Integer getState() {
	return state;
}

public void setState(Integer state) {
	this.state = state;
}

public String getContents() {
	return contents;
}
public void setContents(String contents) {
	this.contents = contents;
}
@Override
public String toString() {
	return "UserNotice [id=" + id + ", title=" + title + ", content=" + content + ", contents=" + contents
			+ ", picture=" + picture + ", created_time=" + created_time + ", state=" + state + "]";
}

public UserNotice() {
	super();
}
  
}
