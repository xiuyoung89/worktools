package com.ja.sevice;

import java.util.List;

import com.ja.domain.FootBallMatch;
import com.ja.util.JsonResult;

public interface FootBallMatchService {

	/**
	 * @param play
	 *            玩法
	 * @param type
	 *            投注类型
	 * @return 根据玩法以及投注类型查询赛事信息
	 */
	List<FootBallMatch> findTypeMatch(String play, String type, String time);

	/**
	 * @param cname
	 *            赛事目录英文名
	 * @param play
	 *            玩法
	 * @param type
	 *            投注类型
	 * @param time
	 *            时间
	 * @return 根据类型查询具体的赛事信息
	 */
	List<FootBallMatch> findMatchInfo(String cname, String play, String type, String time);

	/**
	 * @param id
	 *            赛事id
	 * @return 单条的赛事信息
	 */
	FootBallMatch findOneMatchInfo(Integer id);

	/**
	 * 爬取比赛数据
	 * @return
	 */
	JsonResult getFootballData();
	
	/**
	 * 爬取赛果数据
	 * @return
	 */
	JsonResult getFootballResult();

	/**
	 * 根据条件查询比赛的开始时间
	 * @param league
	 * @param team_h
	 * @param team_c
	 * @param date
	 * @return
	 */
	String findStartTime(String league, String team_h, String team_c, String date);

	/**
	 * 根据时间查询赛事结果
	 * @param date 查询时间
	 * @return
	 */
	List<FootBallMatch> findMatchResult(String date);
	
}
