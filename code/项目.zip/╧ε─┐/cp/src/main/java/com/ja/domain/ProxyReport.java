package com.ja.domain;

import java.io.Serializable;

public class ProxyReport extends TodayRecord implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1389627924560571022L;

	private Double defeatOrVictory;//投注输赢
	
	private Double teamBalance;//团队余额
	
	private Integer theNumberOfBets;//投注人数

	private Double tikuanzongji;//提款总计
	
    
    public static long getSerialversionuid() {
		return serialVersionUID;
	}
	public Double getTikuanzongji() {
		return tikuanzongji;
	}

	public void setTikuanzongji(Double tikuanzongji) {
		this.tikuanzongji = tikuanzongji;
	}

	public Double getDefeatOrVictory() {
		return defeatOrVictory;
	}

	public void setDefeatOrVictory(Double defeatOrVictory) {
		this.defeatOrVictory = defeatOrVictory;
	}

	public Double getTeamBalance() {
		return teamBalance;
	}

	public void setTeamBalance(Double teamBalance) {
		this.teamBalance = teamBalance;
	}

	public Integer getTheNumberOfBets() {
		return theNumberOfBets;
	}

	public void setTheNumberOfBets(Integer theNumberOfBets) {
		this.theNumberOfBets = theNumberOfBets;
	}

	@Override
	public String toString() {
		return "ProxyReport [defeatOrVictory=" + defeatOrVictory + ", teamBalance=" + teamBalance + ", theNumberOfBets="
				+ theNumberOfBets + ", tikuanzongji=" + tikuanzongji + "]";
	}
	
	
}
