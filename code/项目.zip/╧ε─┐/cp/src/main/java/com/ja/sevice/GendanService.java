package com.ja.sevice;

import java.util.List;

import com.ja.domain.Data;
import com.ja.domain.Gendan;
import com.ja.domain.JointVo;

public interface GendanService {
	
	/**添加跟单订单*/
	int addGendan(Gendan g);
	
	/**判断测试单 */
	int getTestState(Integer id, String times);

	/**查询可以购买的所有跟单订单号*/
	List<String> getFindGendan();
	
	/**查询跟单订单*/
	List<JointVo> getAllGendan();

	/**查询发起和参与的订单号*/
	List<String> getOrderNum(int i);
	
	/**查询自己发起的跟单*/
	List<JointVo> getFQGendan(Integer id);

	/**查询自己参与的跟单*/
	List<JointVo> getCYGendan(Integer id);
	
	//查询最新一条的id
	Gendan getByOrderId(Integer id);

	//插入胜率
	int updateShenglv(Gendan g);

	/**查看某一条跟单的信息*/
	List<JointVo> getOneData(Integer id);

	/**统计购买测试单*/
	int getShopGendan(Integer id);

	/**某个彩种某期退钱*/
	List<Gendan> getAllUser(Data data);

	/**跟单退钱状态修改*/
	int chedan(Gendan gendan);

	/**查看已经失效的订单*/
	List<JointVo> gdInvalid();

	/**根据条件查询排名*/
	List<JointVo> getIncomdeGendan(String time);

	/**查询每周排名*/
	List<JointVo> getIncomdeWeek(String time);
	
	/**查询某一条跟单*/
	Gendan findGendan(Integer id);

	/**修改下注人数*/
	int updateCounts(Integer gid, int a);
	
      
}
