package com.ja.sevice;

import java.util.List;

import com.ja.domain.Admin;
import com.ja.domain.Agent;
import com.ja.domain.FastIncomeSetting;
import com.ja.domain.IncomeSetting;
import com.ja.domain.ParkedDomains;
import com.ja.domain.UpDataPage;
import com.ja.domain.User;
import com.ja.domain.WhiteList;
import com.ja.util.JsonResult;
/**
 * 项目名称：cp   
 * 类名称：ISystemConfigService.java   
 * 类描述：   网站系统配置业务层接口
 * 创建人：   GL
 * 创建时间：2019年2月13日 下午2:33:22   
 * @version v1.0.0
 */
public interface ISystemConfigService {

	/**
	 * 方法名：findAllConfig 
	 * 描述：    查询所有的系统配置                   TODO
	 * 参数：    @return 
	 * @return: Admin
	 */
	Admin findAllConfig();
	
	/**
	 * 方法名：findWebState 
	 * 描述：    查询网页状态                   TODO
	 * 参数：    @return 
	 * @return: Integer
	 */
	Integer findWebState();
	
	/**
	 * 方法名：updateAllConfig 
	 * 描述：      修改网站所有的配置                 TODO
	 * 参数：    @param admin 配置信息
	 * 参数：    @return 
	 * @return: Integer
	 */
	Integer updateAllConfig(Admin admin);
	
	/**
	 * 方法名：ipCheck 
	 * 描述：    通过ip检查能否注册        
	 * 参数：    @param state 用户状态
	 * 参数：    @return 
	 * @return: boolean
	 */
	boolean ipCheck(String ip,Integer state);
	
	/**
	 * 查找所有的入款设置
	 * @return 入款设置集合
	 */
	List<IncomeSetting> findAllIncomeSetting();
	
	/**
	 * 查询所有的快速入款设置
	 * @return 快速入款设置集合
	 */
	List<FastIncomeSetting> findAllFastIncomeSetting();

	/**
	 * 修改收款设置
	 * @param incomeSetting
	 * @return 影响的行数
	 */
	Integer updateIncomeSetting(IncomeSetting incomeSetting);
	
	/**
	 * 插入收款设置新数据
	 * @param incomeSetting
	 * @return 影响的行数
	 */
	Integer insertIncomeSetting(IncomeSetting incomeSetting);
	
	/**
	 * 通过id找到入款设置对象
	 * @param id
	 * @return 入款设置
	 */
	IncomeSetting findIncomeSettingById(Integer id);
	
	/**
	 * 修改快速收款设置
	 * @param fastIncomeSetting
	 * @return 修改数据影响数据库的行数
	 */
	Integer updateFastIncomeSetting(FastIncomeSetting fastIncomeSetting);
	
	/**
	 * 插入快速收款设置的数据
	 * @param fastIncomeSetting
	 * @return 插入数据影响数据库的行数
	 */
	Integer insertFastIncomeSetting(FastIncomeSetting fastIncomeSetting);
	
	/**
	 * 通过id找到快速入款设置对象
	 * @param id
	 * @return 快速入款设置
	 */
	FastIncomeSetting findFastIncomeSettingById(Integer id);
	
	/** 根据条件找到所有的用户
	 * @param type
	 * @return 用户
	 */
	List<User> findUser(String type);
	
	/**
	 * 插入白名单
	 * @return 插入数据库影响的行数
	 */
	Integer insertWhiteList(WhiteList whiteList);
	
	/**
	 * 查找所有的白名单
	 * @return WhiteList集合
	 */
	List<WhiteList> findAllWhiteList();
	
	/**
	 * 更新白名单状态
	 * @param id
	 * @param status
	 * @return
	 */
	Integer updateWhiteListStatus(Integer id, Integer status);
	
	/**
	 * 通过ip寻找白名单对象
	 * @param ip
	 * @return WhiteList
	 */
	WhiteList findWhiteListByIP(String ip);
	
	/**
	 * 根据id删除白名单
	 * @param id
	 * @return 影响数据库的行数
	 * @exception RuntimeException 如果删除不正常会抛出该异常
	 */
	Integer deleteWhiteList(Integer id);
	
	/**
	 * 添加绑定域名的数据
	 * @param parkedDomains
	 * @return 影响的行数
	 */
	Integer insertParkedDomains(ParkedDomains parkedDomains);
	
	/**
	 * 可以添加域名的代理
	 * @return
	 */
	List<String> canAddAgent();
	
	/**
	 * 根据条件查询所有的绑定域名
	 * @param domain
	 * @param agency
	 * @return 绑定域名的集合
	 */
	List<ParkedDomains> findAllParkedDomains(Integer id,String domain,String agency);
	

	/**
	 * 根据条件查询所有的绑定域名
	 * @param domain
	 * @param agency
	 * @return 绑定域名的集合
	 */
	List<ParkedDomains> findAllParkedDomains1(Integer id,String domain,String agency);
	
	/**
	 * 修改代理的状态
	 * @param id
	 * @param status
	 * @return 影响数据库的行数
	 */
	Integer updateDomainStatus(Integer id,Integer status);
	
	/**
	 * 修改代理
	 * @param id
	 * @return 影响数据库行数
	 */
	Integer updateDomain(ParkedDomains parkedDomains);
	
	/**
	 * 删除绑定的域名
	 * @param id
	 * @return
	 */
	Integer deleteDomain(Integer id);
	
	/**
	 * 根据条件找到所有的用户
	 * @param type
	 * @param account
	 * @param icode
	 * @return
	 */
	List<User> findUserList(String type,String account,String icode);
	
	  
	/**
	 * 用户注册
	 * @param agent
	 * @return
	 */
	JsonResult addGeneralAgent(Agent agent);
	
	/**
	 * 根据用户名找到Agent对象
	 * @param username
	 * @return
	 */
	Agent findAgentByUsername(String username);
	
	/**
	 * 查找所有的总代理
	 * @return 代理列表
	 */
	List<Agent> allAgentList();
	
	/**
	 * 根据id查总代理
	 * @return 代理列表
	 */
	Agent findAgentById(Integer id);
	
	/**
	 * 编辑代理
	 * @param agent
	 * @return
	 */
	Integer editAgent(Agent agent);

	/**
	 * 删除总代理帐号
	 * @param id 用户id
	 * @return
	 */
	Integer deleteGeneralAgent(Integer id);
	/**
	 * 修改代理领取最低金额
	 * @param receiveAReturnPoint
	 * @return
	 */
	Integer receiveAReturnPoint(Double receiveAReturnPoint);

	/**
	 * 方法名：findByStateGeneralAgentList 
	 * 描述：     查询可以添加域名的代理                 
	 * 参数：    @return 
	 * @return: List<String>
	 */
	List<String> findByStateGeneralAgentList();

	/**
	 * 方法名：findSystemUpdatePage 
	 * 描述：     查询手机端页面更新配置                 
	 * 参数：    @return 
	 * @return: List<UpdataTable>
	 */
	List<UpDataPage> findSystemUpdatePage();

	/**
	 * 方法名：updateSystemPage 
	 * 描述：    修改手机端页面更新配置                  
	 * 参数：    @return 
	 * @return: int
	 */
	int updateSystemPage(List<UpDataPage> upDataPage);

}
