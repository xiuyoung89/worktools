package com.ja.dao;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.ja.domain.DepositBank;

public interface DepositBankMapper {
	
	/**查询银行卡信息*/
    List<DepositBank> getAllDepositBank(); 
    
    /**修改银行卡信息*/
    int updateDepositInfo(@Param("bank")DepositBank bank); 
    
    /**添加银行卡信息*/
    int addDepositInfo(@Param("bank")DepositBank bank); 
    
    /**删除银行卡信息*/
 	int delDepositInfo(Integer id); 
    
	

}