package com.ja.controller;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.ja.domain.AdminUser;
import com.ja.domain.Bjldata;
import com.ja.domain.PagingData;
import com.ja.sevice.BjlService;
import com.ja.sevice.BjlhtglService;
import com.ja.util.JsonResult;
@RequestMapping("/bjlhtgl")
@Controller
public class BjlhtglController {
	@Autowired
	BjlhtglService bjl;

	@Autowired
	BjlService bjlService;

	/**
	 * 
	 * ----TODO: 百家乐管理
	 * 
	 */
	
	/**
	 * 方法名：baccaratPage 
	 * 描述：    百家乐管理页面                  
	 * 参数：    @return 
	 * @return: String
	 */
	@RequestMapping("/baccaratPage")
	public String baccaratPage(){
		return "htgl/baijialeguanli"; 
	}
	
	/**
	 * 查询百家乐用户下注记录   根据传入的参数条件进行查询
	 * @param user  用户名  后台用
	 * @param time1 开始时间 后台用
	 * @param time2 结束时间 后台用
	 * @param period 根据期号查询 后台用
	 * @param state 根据开奖未开奖查询 后台用
	 * @return 查询到数据则返回list集合包含bjl对象数据 没有查询到则返回一个空集合
	 */
	@RequestMapping(value="/findUserbettingRecord",produces="text/json;charset=UTF-8")
	@ResponseBody
	public String findUserbettingRecord(PagingData paging,String user,String time1,String time2,String period,Integer state,Integer id){
		paging.setAllCount(bjl.xiazjlCounts(user, time1, time2, period,null, state));
		paging.setList(bjl.xiazjl(paging,user, time1, time2, period, null,state,id));
		return PagingData.pagingData(paging);
	}
	
	/**
	 * 方法名：tableNumerAttributeSetup 
	 * 描述：    根据桌号查询当前桌的基本设置数据                  
	 * 参数：    @param tableNumber 桌号
	 * 参数：    @return 
	 * @return: JsonResult 查询到则返回 BaccaratBulletin对象 如果没有查询到则返回null
	 */
	@RequestMapping("/tableNumerAttributeSetup")
	@ResponseBody
	public JsonResult tableNumerAttributeSetup(int tableNumber){
		return new JsonResult("sucess",bjl.basicSettingsOfBaccarat(tableNumber));
	}

	/**
	 * 方法名：findBaccaratRatio 
	 * 描述：     查询百家乐赔率                 
	 * 参数：    @return 
	 * @return: JsonResult
	 */
	@RequestMapping("/findBaccaratRatio")
	@ResponseBody
	public JsonResult findBaccaratRatio(){
		return new JsonResult("sucess",bjl.pailu()); 
	} 
	
	
	
	@RequestMapping("/deletexzjl")
	@ResponseBody
	public JsonResult deletexzjl(String id){
		if(id == null || "".equals(id)){
			return new JsonResult(null,0);
		}
		return new JsonResult(null,bjl.deletexzjl(new Integer(id)));
	}
	
	
	/**
	 * 查询百家乐开奖记录
	 * @param paging  分页对象
	 * @param time1 开始时间
	 * @param time2 结束时间
	 * @param period  期号
	 * @return 查询到则返回list集合 里面包含bjldata对象数据 没有查询到则为空
	 */
	@RequestMapping(value="/lotteryRecord",produces="text/json;charset=UTF-8")
	@ResponseBody
	public String lotteryRecord(PagingData paging,String time1,String time2,String period,Integer tableNumber){
		paging.setAllCount(bjl.lotteryRecord(time1, time2, period,tableNumber));
		paging.setList(bjl.lotteryRecords(paging,time1, time2, period,tableNumber));
		return PagingData.pagingData(paging);
	}
	
	/**
	 * 修改百家乐百分比控制
	 * @param tableNumber  桌号
	 * @param percentage  百分比
	 * @return  修改成功返回 1  不成功则是别的值 有可能是0
	 */
	@RequestMapping("/updateBjlControl")
	@ResponseBody
	public JsonResult updateBjlControl(int tableNumber,int percentage){
		return new JsonResult(null,bjl.updateBjlControl(tableNumber, percentage));
	}
	
	
	 /**
	  * 修改百家乐8遇到9 返点百分之几
	  * @param percent  返点比例
	  * @return
	  */
	@RequestMapping("/percent")
	@ResponseBody
	public JsonResult percent(Double percent1){
		System.out.println(percent1);
		if(percent1 == null) {
			return new JsonResult(null,"比例不能为空");
		}
		return new JsonResult(null,bjl.fandian(percent1));
	}
	/**
	 * 修改百家乐房间金额 就是进入房间时显示的金额
	 * @param tableNumber 桌号
	 * @param maximumAmount 最大金额
	 * @param minimumSum 最小金额
	 * @return  修改成功则返回1 
	 */
	@RequestMapping("/updateBjlRoomMoney")
	@ResponseBody
	public JsonResult updateBjlRoomMoney(int tableNumber,String maximumAmount,String minimumSum){
		return new JsonResult(null,bjl.updateBjlRoomMoney(tableNumber, maximumAmount, minimumSum));
	}
	/**
	 * 	 修改百家乐开奖赔率
	 * @param rebate1   rebate1 庄家的赔率
	 * @param rebate2   rebate2 闲家的赔率
	 * @param rebate3  rebate3闲对的赔率
	 * @param rebate4  rebate4庄对的赔率
	 * @param rebate5  rebate5和局的赔率
	 * @param rebate6  rebate6大的赔率
	 * @param rebate7  rebate7小的赔率
	 * @param rebate8  rebate8完美对子的赔率
	 * @param rebate9  rebate9任意对子的赔率
	 * @param name  彩种名
	 * @return 修改成功则返回1 
	 */
	@RequestMapping("/upDateOdds")
	@ResponseBody
	public JsonResult upDateOdds(String rebate1,String rebate2,String rebate3,String rebate4,String rebate5,String rebate6,String rebate7,String rebate8,String rebate9,String name){
		if(rebate1==null && "".equals(rebate1)){
			return new JsonResult(null,"修改赔率不能为空");
		}
		if(rebate2==null && "".equals(rebate2)){
			return new JsonResult(null,"修改赔率不能为空");
		}
		if(rebate3==null && "".equals(rebate3)){
			return new JsonResult(null,"修改赔率不能为空");
		}
		if(rebate4==null && "".equals(rebate4)){
			return new JsonResult(null,"修改赔率不能为空");
		}
		if(rebate5==null && "".equals(rebate5)){
			return new JsonResult(null,"修改赔率不能为空");
		}
		if(rebate6==null && "".equals(rebate6)){
			return new JsonResult(null,"修改赔率不能为空");
		}
		if(rebate7==null && "".equals(rebate7)){
			return new JsonResult(null,"修改赔率不能为空");
		}
		if(rebate8==null && "".equals(rebate8)){
			return new JsonResult(null,"修改赔率不能为空");
		}
		if(rebate9==null && "".equals(rebate9)){
			return new JsonResult(null,"修改赔率不能为空");
		}
		return new JsonResult(null,bjl.upDateOdds(rebate1, rebate2, rebate3, rebate4, rebate5, rebate6, rebate7, rebate8, rebate9, name));
	}
	/**
	 * 百家乐开奖数据预设接口 
	 * @param Bjldata  预设数据
	 * @return  预设成功则返回1
	 */
	@RequestMapping("/baccaratPresupposition")
	@ResponseBody
	public JsonResult baccaratPresupposition(Bjldata data) {
		return new JsonResult("",bjl.baccaratPresupposition(data));
	}
	/**
	 * 百家乐退款接口
	 * @param tableNumber 退款的桌号
	 * @param issueNumber 退款的期号
	 * @return
	 */
	@RequestMapping("/baccaratRefund")
	@ResponseBody
	public JsonResult baccaratRefund(HttpSession session,Integer tableNumber,String issueNumber) {
		AdminUser admin = (AdminUser)session.getAttribute("admin1");
		return new JsonResult(null,bjl.baccaratRefund(tableNumber, issueNumber,admin));
	}
	
}
