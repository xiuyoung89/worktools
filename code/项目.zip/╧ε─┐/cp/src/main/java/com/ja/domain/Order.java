package com.ja.domain;

import java.io.Serializable;

public class Order implements Serializable{
    /**
	 * 
	 */
	private static final long serialVersionUID = 581907827345587255L;

	private Integer id;//订单表
    
    private String huiyuanzh;//会员名称

    private String cname;//彩种名

    private String cname1;//彩种中文名

    private String str1;//玩法1-40

    private String str2;

    private String str3;

    private String str4;

    private String str5;

    private String str6;

    private String str7;

    private String str8;

    private String str9;

    private String str10;

    private String str11;

    private String str12;

    private String str13;

    private String str14;

    private String str15;

    private String str16;

    private String str17;

    private String str18;

    private String str19;

    private String str20;

    private String str21;

    private String str22;

    private String str23;

    private String str24;

    private String str25;

    private String str26;

    private String str27;

    private String str28;

    private String str29;

    private String str30;

    private String str31;

    private String str32;

    private String str33;

    private String str34;

    private String str35;

    private String str36;

    private String str37;

    private String str38;

    private String str39;

    private String str40;
    
    private String cplay1;//玩法

    private String cplay2;

    private String cplay3;

    private String cplay4;

    private String cplay5;

    private String cplay6;

    private String cplay7;

    private String cplay8;

    private String cplay9;

    private String cplay10;

    private String cplay11;

    private String cplay12;

    private String cplay13;

    private String cplay14;

    private String cplay15;

    private String cplay16;

    private String cplay17;

    private String cplay18;

    private String cplay19;

    private String cplay20;

    private String cplay21;

    private String cplay22;

    private String cplay23;

    private String cplay24;

    private String cplay25;

    private String cplay26;

    private String cplay27;

    private String cplay28;

    private String cplay29;

    private String cplay30;

    private String cplay31;

    private String cplay32;

    private String cplay33;

    private String cplay34;

    private String cplay35;

    private String cplay36;

    private String cplay37;

    private String cplay38;

    private String cplay39;

    private String cplay40;

    private Integer count1;

    private Integer count2;

    private Integer count3;

    private Integer count4;

    private Integer count5;

    private Integer count6;

    private Integer count7;

    private Integer count8;

    private Integer count9;

    private Integer count10;

    private Integer count11;

    private Integer count12;

    private Integer count13;

    private Integer count14;

    private Integer count15;

    private Integer count16;

    private Integer count17;

    private Integer count18;

    private Integer count19;

    private Integer count20;

    private Integer count21;

    private Integer count22;

    private Integer count23;

    private Integer count24;

    private Integer count25;

    private Integer count26;

    private Integer count27;

    private Integer count28;

    private Integer count29;

    private Integer count30;

    private Integer count31;

    private Integer count32;

    private Integer count33;

    private Integer count34;

    private Integer count35;

    private Integer count36;

    private Integer count37;

    private Integer count38;

    private Integer count39;

    private Integer count40;

    private Double money1;

    private Double money2;

    private Double money3;

    private Double money4;

    private Double money5;

    private Double money6;

    private Double money7;

    private Double money8;

    private Double money9;

    private Double money10;

    private Double money11;

    private Double money12;

    private Double money13;

    private Double money14;

    private Double money15;

    private Double money16;

    private Double money17;

    private Double money18;

    private Double money19;

    private Double money20;

    private Double money21;

    private Double money22;

    private Double money23;

    private Double money24;

    private Double money25;

    private Double money26;

    private Double money27;

    private Double money28;

    private Double money29;

    private Double money30;

    private Double money31;

    private Double money32;

    private Double money33;

    private Double money34;

    private Double money35;

    private Double money36;

    private Double money37;

    private Double money38;

    private Double money39;

    private Double money40;
    
    private String ordernum;

    private String orderdate;

    private Integer state;

    private String lotternum;

    private String lottertime;

    private Integer lottercount;

    private Double lottermoney;

    private String goalnum;

    private Double acount;

    private String odds;

    private Double rebate;

    private Double goalmoney;
    
    private String tcplay;

    private Integer lotterid;

    private Integer userid;

    private String period;

    private Integer ocount;
    
    private String rebate1;

	private String rebate2;

	private String rebate3;

	private String rebate4;

	private String rebate5;

	private String rebate6;

	private String rebate7;

	private String rebate8;

	private String rebate9;

	private String rebate10;

	private String rebate11;

	private String rebate12;

	private String rebate13;

	private String rebate14;

	private String rebate15;

	private String rebate16;

	private String rebate17;

	private String rebate18;

	private String rebate19;

	private String rebate20;

	private String rebate21;

	private String rebate22;

	private String rebate23;

	private String rebate24;

	private String rebate25;

	private String rebate26;

	private String rebate27;

	private String rebate28;

	private String rebate29;

	private String rebate30;

	private String rebate31;

	private String rebate32;

	private String rebate33;

	private String rebate34;

	private String rebate35;

	private String rebate36;

	private String rebate37;

	private String rebate38;

	private String rebate39;

	private String rebate40;
    
    public static long getSerialversionuid() {
		return serialVersionUID;
	}

    public String getRebate1() {
		return rebate1;
	}

	public void setRebate1(String rebate1) {
		this.rebate1 = rebate1;
	}

	public String getRebate2() {
		return rebate2;
	}

	public void setRebate2(String rebate2) {
		this.rebate2 = rebate2;
	}

	public String getRebate3() {
		return rebate3;
	}

	public void setRebate3(String rebate3) {
		this.rebate3 = rebate3;
	}

	public String getRebate4() {
		return rebate4;
	}

	public void setRebate4(String rebate4) {
		this.rebate4 = rebate4;
	}

	public String getRebate5() {
		return rebate5;
	}

	public void setRebate5(String rebate5) {
		this.rebate5 = rebate5;
	}

	public String getRebate6() {
		return rebate6;
	}

	public void setRebate6(String rebate6) {
		this.rebate6 = rebate6;
	}

	public String getRebate7() {
		return rebate7;
	}

	public void setRebate7(String rebate7) {
		this.rebate7 = rebate7;
	}

	public String getRebate8() {
		return rebate8;
	}

	public void setRebate8(String rebate8) {
		this.rebate8 = rebate8;
	}

	public String getRebate9() {
		return rebate9;
	}

	public void setRebate9(String rebate9) {
		this.rebate9 = rebate9;
	}

	public String getRebate10() {
		return rebate10;
	}

	public void setRebate10(String rebate10) {
		this.rebate10 = rebate10;
	}

	public String getRebate11() {
		return rebate11;
	}

	public void setRebate11(String rebate11) {
		this.rebate11 = rebate11;
	}

	public String getRebate12() {
		return rebate12;
	}

	public void setRebate12(String rebate12) {
		this.rebate12 = rebate12;
	}

	public String getRebate13() {
		return rebate13;
	}

	public void setRebate13(String rebate13) {
		this.rebate13 = rebate13;
	}

	public String getRebate14() {
		return rebate14;
	}

	public void setRebate14(String rebate14) {
		this.rebate14 = rebate14;
	}

	public String getRebate15() {
		return rebate15;
	}

	public void setRebate15(String rebate15) {
		this.rebate15 = rebate15;
	}

	public String getRebate16() {
		return rebate16;
	}

	public void setRebate16(String rebate16) {
		this.rebate16 = rebate16;
	}

	public String getRebate17() {
		return rebate17;
	}

	public void setRebate17(String rebate17) {
		this.rebate17 = rebate17;
	}

	public String getRebate18() {
		return rebate18;
	}

	public void setRebate18(String rebate18) {
		this.rebate18 = rebate18;
	}

	public String getRebate19() {
		return rebate19;
	}

	public void setRebate19(String rebate19) {
		this.rebate19 = rebate19;
	}

	public String getRebate20() {
		return rebate20;
	}

	public void setRebate20(String rebate20) {
		this.rebate20 = rebate20;
	}

	public String getRebate21() {
		return rebate21;
	}

	public void setRebate21(String rebate21) {
		this.rebate21 = rebate21;
	}

	public String getRebate22() {
		return rebate22;
	}

	public void setRebate22(String rebate22) {
		this.rebate22 = rebate22;
	}

	public String getRebate23() {
		return rebate23;
	}

	public void setRebate23(String rebate23) {
		this.rebate23 = rebate23;
	}

	public String getRebate24() {
		return rebate24;
	}

	public void setRebate24(String rebate24) {
		this.rebate24 = rebate24;
	}

	public String getRebate25() {
		return rebate25;
	}

	public void setRebate25(String rebate25) {
		this.rebate25 = rebate25;
	}

	public String getRebate26() {
		return rebate26;
	}

	public void setRebate26(String rebate26) {
		this.rebate26 = rebate26;
	}

	public String getRebate27() {
		return rebate27;
	}

	public void setRebate27(String rebate27) {
		this.rebate27 = rebate27;
	}

	public String getRebate28() {
		return rebate28;
	}

	public void setRebate28(String rebate28) {
		this.rebate28 = rebate28;
	}

	public String getRebate29() {
		return rebate29;
	}

	public void setRebate29(String rebate29) {
		this.rebate29 = rebate29;
	}

	public String getRebate30() {
		return rebate30;
	}

	public void setRebate30(String rebate30) {
		this.rebate30 = rebate30;
	}

	public String getRebate31() {
		return rebate31;
	}

	public void setRebate31(String rebate31) {
		this.rebate31 = rebate31;
	}

	public String getRebate32() {
		return rebate32;
	}

	public void setRebate32(String rebate32) {
		this.rebate32 = rebate32;
	}

	public String getRebate33() {
		return rebate33;
	}

	public void setRebate33(String rebate33) {
		this.rebate33 = rebate33;
	}

	public String getRebate34() {
		return rebate34;
	}

	public void setRebate34(String rebate34) {
		this.rebate34 = rebate34;
	}

	public String getRebate35() {
		return rebate35;
	}

	public void setRebate35(String rebate35) {
		this.rebate35 = rebate35;
	}

	public String getRebate36() {
		return rebate36;
	}

	public void setRebate36(String rebate36) {
		this.rebate36 = rebate36;
	}

	public String getRebate37() {
		return rebate37;
	}

	public void setRebate37(String rebate37) {
		this.rebate37 = rebate37;
	}

	public String getRebate38() {
		return rebate38;
	}

	public void setRebate38(String rebate38) {
		this.rebate38 = rebate38;
	}

	public String getRebate39() {
		return rebate39;
	}

	public void setRebate39(String rebate39) {
		this.rebate39 = rebate39;
	}

	public String getRebate40() {
		return rebate40;
	}

	public void setRebate40(String rebate40) {
		this.rebate40 = rebate40;
	}

	public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getCname() {
        return cname;
    }

    public void setCname(String cname) {
        this.cname = cname == null ? null : cname.trim();
    }

    public String getCname1() {
        return cname1;
    }

    public void setCname1(String cname1) {
        this.cname1 = cname1 == null ? null : cname1.trim();
    }

    public String getStr1() {
        return str1;
    }

    public void setStr1(String str1) {
        this.str1 = str1 == null ? null : str1.trim();
    }

    public String getStr2() {
        return str2;
    }

    public void setStr2(String str2) {
        this.str2 = str2 == null ? null : str2.trim();
    }

    public String getStr3() {
        return str3;
    }

    public void setStr3(String str3) {
        this.str3 = str3 == null ? null : str3.trim();
    }

    public String getStr4() {
        return str4;
    }

    public void setStr4(String str4) {
        this.str4 = str4 == null ? null : str4.trim();
    }

    public String getStr5() {
        return str5;
    }

    public void setStr5(String str5) {
        this.str5 = str5 == null ? null : str5.trim();
    }

    public String getStr6() {
        return str6;
    }

    public void setStr6(String str6) {
        this.str6 = str6 == null ? null : str6.trim();
    }

    public String getStr7() {
        return str7;
    }

    public void setStr7(String str7) {
        this.str7 = str7 == null ? null : str7.trim();
    }

    public String getStr8() {
        return str8;
    }

    public void setStr8(String str8) {
        this.str8 = str8 == null ? null : str8.trim();
    }

    public String getStr9() {
        return str9;
    }

    public void setStr9(String str9) {
        this.str9 = str9 == null ? null : str9.trim();
    }

    public String getStr10() {
        return str10;
    }

    public void setStr10(String str10) {
        this.str10 = str10 == null ? null : str10.trim();
    }

    public String getStr11() {
        return str11;
    }

    public void setStr11(String str11) {
        this.str11 = str11 == null ? null : str11.trim();
    }

    public String getStr12() {
        return str12;
    }

    public void setStr12(String str12) {
        this.str12 = str12 == null ? null : str12.trim();
    }

    public String getStr13() {
        return str13;
    }

    public void setStr13(String str13) {
        this.str13 = str13 == null ? null : str13.trim();
    }

    public String getStr14() {
        return str14;
    }

    public void setStr14(String str14) {
        this.str14 = str14 == null ? null : str14.trim();
    }

    public String getStr15() {
        return str15;
    }

    public void setStr15(String str15) {
        this.str15 = str15 == null ? null : str15.trim();
    }

    public String getStr16() {
        return str16;
    }

    public void setStr16(String str16) {
        this.str16 = str16 == null ? null : str16.trim();
    }

    public String getStr17() {
        return str17;
    }

    public void setStr17(String str17) {
        this.str17 = str17 == null ? null : str17.trim();
    }

    public String getStr18() {
        return str18;
    }

    public void setStr18(String str18) {
        this.str18 = str18 == null ? null : str18.trim();
    }

    public String getHuiyuanzh() {
		return huiyuanzh;
	}

	public void setHuiyuanzh(String huiyuanzh) {
		this.huiyuanzh = huiyuanzh;
	}

	public String getStr19() {
        return str19;
    }

    public void setStr19(String str19) {
        this.str19 = str19 == null ? null : str19.trim();
    }

    public String getStr20() {
        return str20;
    }

    public void setStr20(String str20) {
        this.str20 = str20 == null ? null : str20.trim();
    }

    public String getStr21() {
        return str21;
    }

    public void setStr21(String str21) {
        this.str21 = str21 == null ? null : str21.trim();
    }

    public String getStr22() {
        return str22;
    }

    public void setStr22(String str22) {
        this.str22 = str22 == null ? null : str22.trim();
    }

    public String getStr23() {
        return str23;
    }

    public void setStr23(String str23) {
        this.str23 = str23 == null ? null : str23.trim();
    }

    public String getStr24() {
        return str24;
    }

    public void setStr24(String str24) {
        this.str24 = str24 == null ? null : str24.trim();
    }

    public String getStr25() {
        return str25;
    }

    public void setStr25(String str25) {
        this.str25 = str25 == null ? null : str25.trim();
    }

    public String getStr26() {
        return str26;
    }

    public void setStr26(String str26) {
        this.str26 = str26 == null ? null : str26.trim();
    }

    public String getStr27() {
        return str27;
    }

    public void setStr27(String str27) {
        this.str27 = str27 == null ? null : str27.trim();
    }

    public String getStr28() {
        return str28;
    }

    public void setStr28(String str28) {
        this.str28 = str28 == null ? null : str28.trim();
    }

    public String getStr29() {
        return str29;
    }

    public void setStr29(String str29) {
        this.str29 = str29 == null ? null : str29.trim();
    }

    public String getStr30() {
        return str30;
    }

    public void setStr30(String str30) {
        this.str30 = str30 == null ? null : str30.trim();
    }

    public String getStr31() {
        return str31;
    }

    public void setStr31(String str31) {
        this.str31 = str31 == null ? null : str31.trim();
    }

    public String getStr32() {
        return str32;
    }

    public void setStr32(String str32) {
        this.str32 = str32 == null ? null : str32.trim();
    }

    public String getStr33() {
        return str33;
    }

    public void setStr33(String str33) {
        this.str33 = str33 == null ? null : str33.trim();
    }

    public String getStr34() {
        return str34;
    }

    public void setStr34(String str34) {
        this.str34 = str34 == null ? null : str34.trim();
    }

    public String getStr35() {
        return str35;
    }

    public void setStr35(String str35) {
        this.str35 = str35 == null ? null : str35.trim();
    }

    public String getStr36() {
        return str36;
    }

    public void setStr36(String str36) {
        this.str36 = str36 == null ? null : str36.trim();
    }

    public String getStr37() {
        return str37;
    }

    public void setStr37(String str37) {
        this.str37 = str37 == null ? null : str37.trim();
    }

    public String getStr38() {
        return str38;
    }

    public void setStr38(String str38) {
        this.str38 = str38 == null ? null : str38.trim();
    }

    public String getStr39() {
        return str39;
    }

    public void setStr39(String str39) {
        this.str39 = str39 == null ? null : str39.trim();
    }

	public String getStr40() {
		return str40;
	}

	public void setStr40(String str40) {
		this.str40 = str40;
	}

	public Integer getCount40() {
		return count40;
	}

	public void setCount40(Integer count40) {
		this.count40 = count40;
	}

	public Double getMoney40() {
		return money40;
	}

	public void setMoney40(Double money40) {
		this.money40 = money40;
	}

	public Integer getCount1() {
        return count1;
    }

    public void setCount1(Integer count1) {
        this.count1 = count1;
    }

    public Integer getCount2() {
        return count2;
    }

    public void setCount2(Integer count2) {
        this.count2 = count2;
    }

    public Integer getCount3() {
        return count3;
    }

    public void setCount3(Integer count3) {
        this.count3 = count3;
    }

    public Integer getCount4() {
        return count4;
    }

    public void setCount4(Integer count4) {
        this.count4 = count4;
    }

    public Integer getCount5() {
        return count5;
    }

    public void setCount5(Integer count5) {
        this.count5 = count5;
    }

    public Integer getCount6() {
        return count6;
    }

    public void setCount6(Integer count6) {
        this.count6 = count6;
    }

    public Integer getCount7() {
        return count7;
    }

    public void setCount7(Integer count7) {
        this.count7 = count7;
    }

    public Integer getCount8() {
        return count8;
    }

    public void setCount8(Integer count8) {
        this.count8 = count8;
    }

    public Integer getCount9() {
        return count9;
    }

    public void setCount9(Integer count9) {
        this.count9 = count9;
    }

    public Integer getCount10() {
        return count10;
    }

    public void setCount10(Integer count10) {
        this.count10 = count10;
    }

    public Integer getCount11() {
        return count11;
    }

    public void setCount11(Integer count11) {
        this.count11 = count11;
    }

    public Integer getCount12() {
        return count12;
    }

    public void setCount12(Integer count12) {
        this.count12 = count12;
    }

    public Integer getCount13() {
        return count13;
    }

    public void setCount13(Integer count13) {
        this.count13 = count13;
    }

    public Integer getCount14() {
        return count14;
    }

    public void setCount14(Integer count14) {
        this.count14 = count14;
    }

    public Integer getCount15() {
        return count15;
    }

    public void setCount15(Integer count15) {
        this.count15 = count15;
    }

    public Integer getCount16() {
        return count16;
    }

    public void setCount16(Integer count16) {
        this.count16 = count16;
    }

    public Integer getCount17() {
        return count17;
    }

    public void setCount17(Integer count17) {
        this.count17 = count17;
    }

    public Integer getCount18() {
        return count18;
    }

    public void setCount18(Integer count18) {
        this.count18 = count18;
    }

    public Integer getCount19() {
        return count19;
    }

    public void setCount19(Integer count19) {
        this.count19 = count19;
    }

    public Integer getCount20() {
        return count20;
    }

    public void setCount20(Integer count20) {
        this.count20 = count20;
    }

    public Integer getCount21() {
        return count21;
    }

    public void setCount21(Integer count21) {
        this.count21 = count21;
    }

    public Integer getCount22() {
        return count22;
    }

    public void setCount22(Integer count22) {
        this.count22 = count22;
    }

    public Integer getCount23() {
        return count23;
    }

    public void setCount23(Integer count23) {
        this.count23 = count23;
    }

    public Integer getCount24() {
        return count24;
    }

    public void setCount24(Integer count24) {
        this.count24 = count24;
    }

    public Integer getCount25() {
        return count25;
    }

    public void setCount25(Integer count25) {
        this.count25 = count25;
    }

    public Integer getCount26() {
        return count26;
    }

    public void setCount26(Integer count26) {
        this.count26 = count26;
    }

    public Integer getCount27() {
        return count27;
    }

    public void setCount27(Integer count27) {
        this.count27 = count27;
    }

    public Integer getCount28() {
        return count28;
    }

    public void setCount28(Integer count28) {
        this.count28 = count28;
    }

    public Integer getCount29() {
        return count29;
    }

    public void setCount29(Integer count29) {
        this.count29 = count29;
    }

    public Integer getCount30() {
        return count30;
    }

    public void setCount30(Integer count30) {
        this.count30 = count30;
    }

    public Integer getCount31() {
        return count31;
    }

    public void setCount31(Integer count31) {
        this.count31 = count31;
    }

    public Integer getCount32() {
        return count32;
    }

    public void setCount32(Integer count32) {
        this.count32 = count32;
    }

    public Integer getCount33() {
        return count33;
    }

    public void setCount33(Integer count33) {
        this.count33 = count33;
    }

    public Integer getCount34() {
        return count34;
    }

    public void setCount34(Integer count34) {
        this.count34 = count34;
    }

    public Integer getCount35() {
        return count35;
    }

    public void setCount35(Integer count35) {
        this.count35 = count35;
    }

    public Integer getCount36() {
        return count36;
    }

    public void setCount36(Integer count36) {
        this.count36 = count36;
    }

    public Integer getCount37() {
        return count37;
    }

    public void setCount37(Integer count37) {
        this.count37 = count37;
    }

    public Integer getCount38() {
        return count38;
    }

    public void setCount38(Integer count38) {
        this.count38 = count38;
    }

    public Integer getCount39() {
        return count39;
    }

    public void setCount39(Integer count39) {
        this.count39 = count39;
    }

    public Double getMoney1() {
        return money1;
    }

    public void setMoney1(Double money1) {
        this.money1 = money1;
    }

    public Double getMoney2() {
        return money2;
    }

    public void setMoney2(Double money2) {
        this.money2 = money2;
    }

    public Double getMoney3() {
        return money3;
    }

    public void setMoney3(Double money3) {
        this.money3 = money3;
    }

    public Double getMoney4() {
        return money4;
    }

    public void setMoney4(Double money4) {
        this.money4 = money4;
    }

    public Double getMoney5() {
        return money5;
    }

    public void setMoney5(Double money5) {
        this.money5 = money5;
    }

    public Double getMoney6() {
        return money6;
    }

    public void setMoney6(Double money6) {
        this.money6 = money6;
    }

    public Double getMoney7() {
        return money7;
    }

    public void setMoney7(Double money7) {
        this.money7 = money7;
    }

    public Double getMoney8() {
        return money8;
    }

    public void setMoney8(Double money8) {
        this.money8 = money8;
    }

    public Double getMoney9() {
        return money9;
    }

    public void setMoney9(Double money9) {
        this.money9 = money9;
    }

    public Double getMoney10() {
        return money10;
    }

    public void setMoney10(Double money10) {
        this.money10 = money10;
    }

    public Double getMoney11() {
        return money11;
    }

    public void setMoney11(Double money11) {
        this.money11 = money11;
    }

    public Double getMoney12() {
        return money12;
    }

    public void setMoney12(Double money12) {
        this.money12 = money12;
    }

    public Double getMoney13() {
        return money13;
    }

    public void setMoney13(Double money13) {
        this.money13 = money13;
    }

    public Double getMoney14() {
        return money14;
    }

    public void setMoney14(Double money14) {
        this.money14 = money14;
    }

    public Double getMoney15() {
        return money15;
    }

    public void setMoney15(Double money15) {
        this.money15 = money15;
    }

    public Double getMoney16() {
        return money16;
    }

    public void setMoney16(Double money16) {
        this.money16 = money16;
    }

    public Double getMoney17() {
        return money17;
    }

    public void setMoney17(Double money17) {
        this.money17 = money17;
    }

    public Double getMoney18() {
        return money18;
    }

    public void setMoney18(Double money18) {
        this.money18 = money18;
    }

    public Double getMoney19() {
        return money19;
    }

    public void setMoney19(Double money19) {
        this.money19 = money19;
    }

    public Double getMoney20() {
        return money20;
    }

    public void setMoney20(Double money20) {
        this.money20 = money20;
    }

    public Double getMoney21() {
        return money21;
    }

    public void setMoney21(Double money21) {
        this.money21 = money21;
    }

    public Double getMoney22() {
        return money22;
    }

    public void setMoney22(Double money22) {
        this.money22 = money22;
    }

    public Double getMoney23() {
        return money23;
    }

    public void setMoney23(Double money23) {
        this.money23 = money23;
    }

    public Double getMoney24() {
        return money24;
    }

    public void setMoney24(Double money24) {
        this.money24 = money24;
    }

    public Double getMoney25() {
        return money25;
    }

    public void setMoney25(Double money25) {
        this.money25 = money25;
    }

    public Double getMoney26() {
        return money26;
    }

    public void setMoney26(Double money26) {
        this.money26 = money26;
    }

    public Double getMoney27() {
        return money27;
    }

    public void setMoney27(Double money27) {
        this.money27 = money27;
    }

    public Double getMoney28() {
        return money28;
    }

    public void setMoney28(Double money28) {
        this.money28 = money28;
    }

    public Double getMoney29() {
        return money29;
    }

    public void setMoney29(Double money29) {
        this.money29 = money29;
    }

    public Double getMoney30() {
        return money30;
    }

    public void setMoney30(Double money30) {
        this.money30 = money30;
    }

    public Double getMoney31() {
        return money31;
    }

    public void setMoney31(Double money31) {
        this.money31 = money31;
    }

    public Double getMoney32() {
        return money32;
    }

    public void setMoney32(Double money32) {
        this.money32 = money32;
    }

    public Double getMoney33() {
        return money33;
    }

    public void setMoney33(Double money33) {
        this.money33 = money33;
    }

    public Double getMoney34() {
        return money34;
    }

    public void setMoney34(Double money34) {
        this.money34 = money34;
    }

    public Double getMoney35() {
        return money35;
    }

    public void setMoney35(Double money35) {
        this.money35 = money35;
    }

    public Double getMoney36() {
        return money36;
    }

    public void setMoney36(Double money36) {
        this.money36 = money36;
    }

    public Double getMoney37() {
        return money37;
    }

    public void setMoney37(Double money37) {
        this.money37 = money37;
    }

    public Double getMoney38() {
        return money38;
    }

    public void setMoney38(Double money38) {
        this.money38 = money38;
    }

    public Double getMoney39() {
        return money39;
    }

    public void setMoney39(Double money39) {
        this.money39 = money39;
    }

    public String getOrdernum() {
        return ordernum;
    }

    public void setOrdernum(String ordernum) {
        this.ordernum = ordernum == null ? null : ordernum.trim();
    }

    public String getOrderdate() {
        return orderdate;
    }

    public void setOrderdate(String orderdate) {
        this.orderdate = orderdate == null ? null : orderdate.trim();
    }

    public Integer getState() {
        return state;
    }

    public void setState(Integer state) {
        this.state = state;
    }

    public String getLotternum() {
        return lotternum;
    }

    public void setLotternum(String lotternum) {
        this.lotternum = lotternum == null ? null : lotternum.trim();
    }

    public String getLottertime() {
        return lottertime;
    }

    public void setLottertime(String lottertime) {
        this.lottertime = lottertime == null ? null : lottertime.trim();
    }

    public Integer getLottercount() {
        return lottercount;
    }

    public void setLottercount(Integer lottercount) {
        this.lottercount = lottercount;
    }

    public Double getLottermoney() {
        return lottermoney;
    }

    public void setLottermoney(Double lottermoney) {
        this.lottermoney = lottermoney;
    }

    public String getGoalnum() {
        return goalnum;
    }

    public void setGoalnum(String goalnum) {
        this.goalnum = goalnum == null ? null : goalnum.trim();
    }

    public Double getAcount() {
        return acount;
    }

    public void setAcount(Double acount) {
        this.acount = acount;
    }

    public String getOdds() {
        return odds;
    }

    public void setOdds(String odds) {
        this.odds = odds;
    }

    public Double getRebate() {
        return rebate;
    }

    public void setRebate(Double rebate) {
        this.rebate = rebate;
    }

    public Double getGoalmoney() {
        return goalmoney;
    }

    public void setGoalmoney(Double goalmoney) {
        this.goalmoney = goalmoney;
    }

    public Integer getLotterid() {
        return lotterid;
    }

    public void setLotterid(Integer lotterid) {
        this.lotterid = lotterid;
    }

    public Integer getUserid() {
        return userid;
    }

    public void setUserid(Integer userid) {
        this.userid = userid;
    }

    public String getPeriod() {
        return period;
    }

    public void setPeriod(String period) {
        this.period = period == null ? null : period.trim();
    }

    public Integer getOcount() { 
        return ocount;
    }

    public void setOcount(Integer ocount) {
        this.ocount = ocount;
    }

	public String getCplay1() {
		return cplay1;
	}

	public void setCplay1(String cplay1) {
		this.cplay1 = cplay1;
	}

	public String getCplay2() {
		return cplay2;
	}

	public void setCplay2(String cplay2) {
		this.cplay2 = cplay2;
	}

	public String getCplay3() {
		return cplay3;
	}

	public void setCplay3(String cplay3) {
		this.cplay3 = cplay3;
	}

	public String getCplay4() {
		return cplay4;
	}

	public void setCplay4(String cplay4) {
		this.cplay4 = cplay4;
	}

	public String getCplay5() {
		return cplay5;
	}

	public void setCplay5(String cplay5) {
		this.cplay5 = cplay5;
	}

	public String getCplay6() {
		return cplay6;
	}

	public void setCplay6(String cplay6) {
		this.cplay6 = cplay6;
	}

	public String getCplay7() {
		return cplay7;
	}

	public void setCplay7(String cplay7) {
		this.cplay7 = cplay7;
	}

	public String getCplay8() {
		return cplay8;
	}

	public void setCplay8(String cplay8) {
		this.cplay8 = cplay8;
	}

	public String getCplay9() {
		return cplay9;
	}

	public void setCplay9(String cplay9) {
		this.cplay9 = cplay9;
	}

	public String getCplay10() {
		return cplay10;
	}

	public void setCplay10(String cplay10) {
		this.cplay10 = cplay10;
	}

	public String getCplay11() {
		return cplay11;
	}

	public void setCplay11(String cplay11) {
		this.cplay11 = cplay11;
	}

	public String getCplay12() {
		return cplay12;
	}

	public void setCplay12(String cplay12) {
		this.cplay12 = cplay12;
	}

	public String getCplay13() {
		return cplay13;
	}

	public void setCplay13(String cplay13) {
		this.cplay13 = cplay13;
	}

	public String getCplay14() {
		return cplay14;
	}

	public void setCplay14(String cplay14) {
		this.cplay14 = cplay14;
	}

	public String getCplay15() {
		return cplay15;
	}

	public void setCplay15(String cplay15) {
		this.cplay15 = cplay15;
	}

	public String getCplay16() {
		return cplay16;
	}

	public void setCplay16(String cplay16) {
		this.cplay16 = cplay16;
	}

	public String getCplay17() {
		return cplay17;
	}

	public void setCplay17(String cplay17) {
		this.cplay17 = cplay17;
	}

	public String getCplay18() {
		return cplay18;
	}

	public void setCplay18(String cplay18) {
		this.cplay18 = cplay18;
	}

	public String getCplay19() {
		return cplay19;
	}

	public void setCplay19(String cplay19) {
		this.cplay19 = cplay19;
	}

	public String getCplay20() {
		return cplay20;
	}

	public void setCplay20(String cplay20) {
		this.cplay20 = cplay20;
	}

	public String getCplay21() {
		return cplay21;
	}

	public void setCplay21(String cplay21) {
		this.cplay21 = cplay21;
	}

	public String getCplay22() {
		return cplay22;
	}

	public void setCplay22(String cplay22) {
		this.cplay22 = cplay22;
	}

	public String getCplay23() {
		return cplay23;
	}

	public void setCplay23(String cplay23) {
		this.cplay23 = cplay23;
	}

	public String getCplay24() {
		return cplay24;
	}

	public void setCplay24(String cplay24) {
		this.cplay24 = cplay24;
	}

	public String getCplay25() {
		return cplay25;
	}

	public void setCplay25(String cplay25) {
		this.cplay25 = cplay25;
	}

	public String getCplay26() {
		return cplay26;
	}

	public void setCplay26(String cplay26) {
		this.cplay26 = cplay26;
	}

	public String getCplay27() {
		return cplay27;
	}

	public void setCplay27(String cplay27) {
		this.cplay27 = cplay27;
	}

	public String getCplay28() {
		return cplay28;
	}

	public void setCplay28(String cplay28) {
		this.cplay28 = cplay28;
	}

	public String getCplay29() {
		return cplay29;
	}

	public void setCplay29(String cplay29) {
		this.cplay29 = cplay29;
	}

	public String getCplay30() {
		return cplay30;
	}

	public void setCplay30(String cplay30) {
		this.cplay30 = cplay30;
	}

	public String getCplay31() {
		return cplay31;
	}

	public void setCplay31(String cplay31) {
		this.cplay31 = cplay31;
	}

	public String getCplay32() {
		return cplay32;
	}

	public void setCplay32(String cplay32) {
		this.cplay32 = cplay32;
	}

	public String getCplay33() {
		return cplay33;
	}

	public void setCplay33(String cplay33) {
		this.cplay33 = cplay33;
	}

	public String getCplay34() {
		return cplay34;
	}

	public void setCplay34(String cplay34) {
		this.cplay34 = cplay34;
	}

	public String getCplay35() {
		return cplay35;
	}

	public void setCplay35(String cplay35) {
		this.cplay35 = cplay35;
	}

	public String getCplay36() {
		return cplay36;
	}

	public void setCplay36(String cplay36) {
		this.cplay36 = cplay36;
	}

	public String getCplay37() {
		return cplay37;
	}

	public void setCplay37(String cplay37) {
		this.cplay37 = cplay37;
	}

	public String getCplay38() {
		return cplay38;
	}

	public void setCplay38(String cplay38) {
		this.cplay38 = cplay38;
	}

	public String getCplay39() {
		return cplay39;
	}

	public void setCplay39(String cplay39) {
		this.cplay39 = cplay39;
	}

	public String getCplay40() {
		return cplay40;
	}

	public void setCplay40(String cplay40) {
		this.cplay40 = cplay40;
	}

	public String getTcplay() {
		return tcplay;
	}

	public void setTcplay(String tcplay) {
		this.tcplay = tcplay;
	}

	@Override
	public String toString() {
		return "Order [id=" + id + ", huiyuanzh=" + huiyuanzh + ", cname=" + cname + ", cname1=" + cname1 + ", str1="
				+ str1 + ", str2=" + str2 + ", str3=" + str3 + ", str4=" + str4 + ", str5=" + str5 + ", str6=" + str6
				+ ", str7=" + str7 + ", str8=" + str8 + ", str9=" + str9 + ", str10=" + str10 + ", str11=" + str11
				+ ", str12=" + str12 + ", str13=" + str13 + ", str14=" + str14 + ", str15=" + str15 + ", str16=" + str16
				+ ", str17=" + str17 + ", str18=" + str18 + ", str19=" + str19 + ", str20=" + str20 + ", str21=" + str21
				+ ", str22=" + str22 + ", str23=" + str23 + ", str24=" + str24 + ", str25=" + str25 + ", str26=" + str26
				+ ", str27=" + str27 + ", str28=" + str28 + ", str29=" + str29 + ", str30=" + str30 + ", str31=" + str31
				+ ", str32=" + str32 + ", str33=" + str33 + ", str34=" + str34 + ", str35=" + str35 + ", str36=" + str36
				+ ", str37=" + str37 + ", str38=" + str38 + ", str39=" + str39 + ", str40=" + str40 + ", cplay1="
				+ cplay1 + ", cplay2=" + cplay2 + ", cplay3=" + cplay3 + ", cplay4=" + cplay4 + ", cplay5=" + cplay5
				+ ", cplay6=" + cplay6 + ", cplay7=" + cplay7 + ", cplay8=" + cplay8 + ", cplay9=" + cplay9
				+ ", cplay10=" + cplay10 + ", cplay11=" + cplay11 + ", cplay12=" + cplay12 + ", cplay13=" + cplay13
				+ ", cplay14=" + cplay14 + ", cplay15=" + cplay15 + ", cplay16=" + cplay16 + ", cplay17=" + cplay17
				+ ", cplay18=" + cplay18 + ", cplay19=" + cplay19 + ", cplay20=" + cplay20 + ", cplay21=" + cplay21
				+ ", cplay22=" + cplay22 + ", cplay23=" + cplay23 + ", cplay24=" + cplay24 + ", cplay25=" + cplay25
				+ ", cplay26=" + cplay26 + ", cplay27=" + cplay27 + ", cplay28=" + cplay28 + ", cplay29=" + cplay29
				+ ", cplay30=" + cplay30 + ", cplay31=" + cplay31 + ", cplay32=" + cplay32 + ", cplay33=" + cplay33
				+ ", cplay34=" + cplay34 + ", cplay35=" + cplay35 + ", cplay36=" + cplay36 + ", cplay37=" + cplay37
				+ ", cplay38=" + cplay38 + ", cplay39=" + cplay39 + ", cplay40=" + cplay40 + ", count1=" + count1
				+ ", count2=" + count2 + ", count3=" + count3 + ", count4=" + count4 + ", count5=" + count5
				+ ", count6=" + count6 + ", count7=" + count7 + ", count8=" + count8 + ", count9=" + count9
				+ ", count10=" + count10 + ", count11=" + count11 + ", count12=" + count12 + ", count13=" + count13
				+ ", count14=" + count14 + ", count15=" + count15 + ", count16=" + count16 + ", count17=" + count17
				+ ", count18=" + count18 + ", count19=" + count19 + ", count20=" + count20 + ", count21=" + count21
				+ ", count22=" + count22 + ", count23=" + count23 + ", count24=" + count24 + ", count25=" + count25
				+ ", count26=" + count26 + ", count27=" + count27 + ", count28=" + count28 + ", count29=" + count29
				+ ", count30=" + count30 + ", count31=" + count31 + ", count32=" + count32 + ", count33=" + count33
				+ ", count34=" + count34 + ", count35=" + count35 + ", count36=" + count36 + ", count37=" + count37
				+ ", count38=" + count38 + ", count39=" + count39 + ", count40=" + count40 + ", money1=" + money1
				+ ", money2=" + money2 + ", money3=" + money3 + ", money4=" + money4 + ", money5=" + money5
				+ ", money6=" + money6 + ", money7=" + money7 + ", money8=" + money8 + ", money9=" + money9
				+ ", money10=" + money10 + ", money11=" + money11 + ", money12=" + money12 + ", money13=" + money13
				+ ", money14=" + money14 + ", money15=" + money15 + ", money16=" + money16 + ", money17=" + money17
				+ ", money18=" + money18 + ", money19=" + money19 + ", money20=" + money20 + ", money21=" + money21
				+ ", money22=" + money22 + ", money23=" + money23 + ", money24=" + money24 + ", money25=" + money25
				+ ", money26=" + money26 + ", money27=" + money27 + ", money28=" + money28 + ", money29=" + money29
				+ ", money30=" + money30 + ", money31=" + money31 + ", money32=" + money32 + ", money33=" + money33
				+ ", money34=" + money34 + ", money35=" + money35 + ", money36=" + money36 + ", money37=" + money37
				+ ", money38=" + money38 + ", money39=" + money39 + ", money40=" + money40 + ", ordernum=" + ordernum
				+ ", orderdate=" + orderdate + ", state=" + state + ", lotternum=" + lotternum + ", lottertime="
				+ lottertime + ", lottercount=" + lottercount + ", lottermoney=" + lottermoney + ", goalnum=" + goalnum
				+ ", acount=" + acount + ", odds=" + odds + ", rebate=" + rebate + ", goalmoney=" + goalmoney
				+ ", tcplay=" + tcplay + ", lotterid=" + lotterid + ", userid=" + userid + ", period=" + period
				+ ", ocount=" + ocount + ", rebate1=" + rebate1 + ", rebate2=" + rebate2 + ", rebate3=" + rebate3
				+ ", rebate4=" + rebate4 + ", rebate5=" + rebate5 + ", rebate6=" + rebate6 + ", rebate7=" + rebate7
				+ ", rebate8=" + rebate8 + ", rebate9=" + rebate9 + ", rebate10=" + rebate10 + ", rebate11=" + rebate11
				+ ", rebate12=" + rebate12 + ", rebate13=" + rebate13 + ", rebate14=" + rebate14 + ", rebate15="
				+ rebate15 + ", rebate16=" + rebate16 + ", rebate17=" + rebate17 + ", rebate18=" + rebate18
				+ ", rebate19=" + rebate19 + ", rebate20=" + rebate20 + ", rebate21=" + rebate21 + ", rebate22="
				+ rebate22 + ", rebate23=" + rebate23 + ", rebate24=" + rebate24 + ", rebate25=" + rebate25
				+ ", rebate26=" + rebate26 + ", rebate27=" + rebate27 + ", rebate28=" + rebate28 + ", rebate29="
				+ rebate29 + ", rebate30=" + rebate30 + ", rebate31=" + rebate31 + ", rebate32=" + rebate32
				+ ", rebate33=" + rebate33 + ", rebate34=" + rebate34 + ", rebate35=" + rebate35 + ", rebate36="
				+ rebate36 + ", rebate37=" + rebate37 + ", rebate38=" + rebate38 + ", rebate39=" + rebate39
				+ ", rebate40=" + rebate40 + "]";
	}

	public Order() {
		super();
	}
	
}