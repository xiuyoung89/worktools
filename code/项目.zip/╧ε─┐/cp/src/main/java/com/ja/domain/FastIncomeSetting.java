package com.ja.domain;

import java.io.Serializable;

/**
 * 
 * @author CY
 *@date 2018.3.20
 */
public class FastIncomeSetting implements Serializable {
	
	private static final long serialVersionUID = 4442589407889424469L;
	
	private Integer id;
	private String interfaceName;
	private String belongCompany;
	private String payAccount;
	private String accountName;
	private Double minAmount;
	private Double maxAmount;
	private String QRcodePath;
	private Integer state;
	private String sort;
	private String operation;
	private String createdUser;
	
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getInterfaceName() {
		return interfaceName;
	}
	public void setInterfaceName(String interfaceName) {
		this.interfaceName = interfaceName;
	}
	public String getBelongCompany() {
		return belongCompany;
	}
	public void setBelongCompany(String belongCompany) {
		this.belongCompany = belongCompany;
	}
	public String getPayAccount() {
		return payAccount;
	}
	public void setPayAccount(String payAccount) {
		this.payAccount = payAccount;
	}
	public String getAccountName() {
		return accountName;
	}
	public void setAccountName(String accountName) {
		this.accountName = accountName;
	}
	public Double getMinAmount() {
		return minAmount;
	}
	public void setMinAmount(Double minAmount) {
		this.minAmount = minAmount;
	}
	public Double getMaxAmount() {
		return maxAmount;
	}
	public void setMaxAmount(Double maxAmount) {
		this.maxAmount = maxAmount;
	}
	public String getQRcodePath() {
		return QRcodePath;
	}
	public void setQRcodePath(String qRcodePath) {
		QRcodePath = qRcodePath;
	}
	public Integer getState() {
		return state;
	}
	public void setState(Integer state) {
		this.state = state;
	}
	public String getSort() {
		return sort;
	}
	public void setSort(String sort) {
		this.sort = sort;
	}
	public String getOperation() {
		return operation;
	}
	public void setOperation(String operation) {
		this.operation = operation;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((QRcodePath == null) ? 0 : QRcodePath.hashCode());
		result = prime * result + ((accountName == null) ? 0 : accountName.hashCode());
		result = prime * result + ((belongCompany == null) ? 0 : belongCompany.hashCode());
		result = prime * result + ((id == null) ? 0 : id.hashCode());
		result = prime * result + ((interfaceName == null) ? 0 : interfaceName.hashCode());
		result = prime * result + ((maxAmount == null) ? 0 : maxAmount.hashCode());
		result = prime * result + ((minAmount == null) ? 0 : minAmount.hashCode());
		result = prime * result + ((operation == null) ? 0 : operation.hashCode());
		result = prime * result + ((payAccount == null) ? 0 : payAccount.hashCode());
		result = prime * result + ((sort == null) ? 0 : sort.hashCode());
		result = prime * result + ((state == null) ? 0 : state.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		FastIncomeSetting other = (FastIncomeSetting) obj;
		if (QRcodePath == null) {
			if (other.QRcodePath != null)
				return false;
		} else if (!QRcodePath.equals(other.QRcodePath))
			return false;
		if (accountName == null) {
			if (other.accountName != null)
				return false;
		} else if (!accountName.equals(other.accountName))
			return false;
		if (belongCompany == null) {
			if (other.belongCompany != null)
				return false;
		} else if (!belongCompany.equals(other.belongCompany))
			return false;
		if (id == null) {
			if (other.id != null)
				return false;
		} else if (!id.equals(other.id))
			return false;
		if (interfaceName == null) {
			if (other.interfaceName != null)
				return false;
		} else if (!interfaceName.equals(other.interfaceName))
			return false;
		if (maxAmount == null) {
			if (other.maxAmount != null)
				return false;
		} else if (!maxAmount.equals(other.maxAmount))
			return false;
		if (minAmount == null) {
			if (other.minAmount != null)
				return false;
		} else if (!minAmount.equals(other.minAmount))
			return false;
		if (operation == null) {
			if (other.operation != null)
				return false;
		} else if (!operation.equals(other.operation))
			return false;
		if (payAccount == null) {
			if (other.payAccount != null)
				return false;
		} else if (!payAccount.equals(other.payAccount))
			return false;
		if (sort == null) {
			if (other.sort != null)
				return false;
		} else if (!sort.equals(other.sort))
			return false;
		if (state == null) {
			if (other.state != null)
				return false;
		} else if (!state.equals(other.state))
			return false;
		return true;
	}
	
	public String getCreatedUser() {
		return createdUser;
	}
	public void setCreatedUser(String createdUser) {
		this.createdUser = createdUser;
	}
	@Override
	public String toString() {
		return "FastIncomeSetting [id=" + id + ", interfaceName=" + interfaceName + ", belongCompany=" + belongCompany
				+ ", payAccount=" + payAccount + ", accountName=" + accountName + ", minAmount=" + minAmount
				+ ", maxAmount=" + maxAmount + ", QRcodePath=" + QRcodePath + ", state=" + state + ", sort=" + sort
				+ ", operation=" + operation + ", createdUser=" + createdUser + "]";
	}
	
	
}
