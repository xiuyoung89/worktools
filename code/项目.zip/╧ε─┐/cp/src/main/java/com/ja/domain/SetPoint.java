package com.ja.domain;

import java.io.Serializable;

public class SetPoint implements Serializable{
		/**
	 * 
	 */
	private static final long serialVersionUID = -7816079264952279070L;
		private Integer id;
		//一级返点
		private String arebate;
		//二级返点
		private String tworebate;
		//三级返点
		private String threerebate;
		
	    
	    public static long getSerialversionuid() {
			return serialVersionUID;
		}
	    
		public Integer getId() {
			return id;
		}
		public void setId(Integer id) {
			this.id = id;
		}
		public String getArebate() {
			return arebate;
		}
		public void setArebate(String arebate) {
			this.arebate = arebate;
		}
		public String getTworebate() {
			return tworebate;
		}
		public void setTworebate(String tworebate) {
			this.tworebate = tworebate;
		}
		public String getThreerebate() {
			return threerebate;
		}
		public void setThreerebate(String threerebate) {
			this.threerebate = threerebate;
		}
		@Override
		public String toString() {
			return "SetPoint [id=" + id + ", arebate=" + arebate + ", tworebate=" + tworebate + ", threerebate="
					+ threerebate + "]";
		}
		
		
		
}
