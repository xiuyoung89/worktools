package com.ja.dao;

import java.util.List;

import com.ja.domain.KeFuAutomatic;

public interface KeFuAutomaticMapper {

	/**
	 * 查询所有的自动回复
	 * @return
	 */
	List<KeFuAutomatic> findAllKeFuAutomatic();
	
	/**
	 * 根据类型查询自动回复
	 * @param type 回复类型
	 * @return
	 */
	List<KeFuAutomatic> findTypeKeFuAutomatic(Integer type);

	/** 
	 * 添加客服咨询自动回复
	 * @param kefuAutomatic 回复信息
	 * @return
	 */
	int addKeFuAutomatic(KeFuAutomatic kefuAutomatic);

	/** 
	 * 修改客服咨询自动回复
	 * @param kefuAutomatic 回复信息
	 * @return
	 */
	int updateKeFuAutomatic(KeFuAutomatic kefuAutomatic);

	/**
	 * 删除客服咨询自动回复
	 * @param id 删除的id
	 * @return
	 */
	int deleteKeFuAutomatic(Integer id);

}