package com.ja.sevice.impl;

import java.text.DecimalFormat;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ja.dao.LiushuiMapper;
import com.ja.dao.OrderMapper;
import com.ja.dao.TodayRecordMapper;
import com.ja.dao.UserMapper;
import com.ja.domain.TodayRecord;
import com.ja.domain.User;
import com.ja.sevice.YunyingbbService;
import com.ja.util.DateUtil;

@Service
public class YunyingbbServiceImpl implements YunyingbbService {

	@Autowired
	private LiushuiMapper liushuiMapper;
	
	@Autowired
	private UserMapper userMapper;
	
	@Autowired
	private TodayRecordMapper todayRecordMapper;
	
	@Autowired
	private OrderMapper orderMapper;

	@Override
	public TodayRecord findAllGlobalReport(String startTime, String endTime, String userName,Integer type,Integer types) {
		DecimalFormat dec = new DecimalFormat("#0.00");
		double count1 = 0.00;//彩票输赢
		double count2 = 0.00;//系统彩输赢
		double count3 = 0.00;//全部输赢
		double a1 = 0.00;//百家乐输赢
		int count4 = 0; // 投注人数

		TodayRecord record = new TodayRecord();
		TodayRecord record1 = new TodayRecord();
		switch (type) {
			case 1: //今天的
				if(types==0) {
					record = liushuiMapper.findByUserNameTimeTodayRecord(DateUtil.findFormatDate(),userName);
				}else {
					record = liushuiMapper.findByUserNameTimeTodayRecord(DateUtil.findFormatDate(),"");
				}
				record.setZxtikuan(record.getZxtikuan()-record.getTkshibai());
				record.setTkshouxufei(record.getTkshouxufei()-record.getSfxtuihuan());
				count1 = record.getCptouzhu()-record.getCpchedan()-record.getCppaijiang()-record.getCpyichang();
				count2 = record.getXtctouzhu()-record.getXtcchedan()-record.getXitcpaijiang()-record.getXtcyichang();
				count3 = count1+count2 + record.getBjltouzhu() -record.getBjlpaijiang() - record.getHjtuihuan()-record.getTmbfanshui()-record.getMrfanshui()-record.getMyfanshui()-record.getDlfandian()
						-record.getMrqiandao()-record.getXyzhuanpan()-record.getZczengsong()-record.getCzzengsong()-record.getHdzengsong();
				a1 = record.getBjltouzhu() - record.getBjlpaijiang();
				break;
				
			case 2://所有的
				if(types==0) {
					record = liushuiMapper.findByUserNameTimeTodayRecord(DateUtil.findFormatDate(),userName);
					record1 = todayRecordMapper.findByTimeAllGlobalReport(startTime,endTime,userName,2); 
				}else {
					record = liushuiMapper.findByUserNameTimeTodayRecord(DateUtil.findFormatDate(),"");
					record1 = todayRecordMapper.findByTimeAllGlobalReport(startTime,endTime,"",1);
				}
				
				count1 = record.getCptouzhu()-record.getCpchedan()-record.getCppaijiang()-record.getCpyichang();
				count2 = record.getXtctouzhu()-record.getXtcchedan()-record.getXitcpaijiang()-record.getXtcyichang();
				count3 = count1+count2+ record.getBjltouzhu() -record.getBjlpaijiang()-record.getHjtuihuan()-record.getTmbfanshui()-record.getMrfanshui()-record.getMyfanshui()-record.getDlfandian()
						-record.getMrqiandao()-record.getXyzhuanpan()-record.getZczengsong()-record.getCzzengsong()-record.getHdzengsong();
				double count5 = record1.getCptouzhu()-record1.getCpchedan()-record1.getCppaijiang()-record1.getCpyichang();
				double count6 = record1.getXtctouzhu()-record1.getXtcchedan()-record1.getXitcpaijiang()-record1.getXtcyichang();
				double count7 = count5+count6 + record1.getBjltouzhu() -record1.getBjlpaijiang()-record1.getHjtuihuan()-record1.getTmbfanshui()-record1.getMrfanshui()-record1.getMyfanshui()-record1.getDlfandian()
						-record1.getMrqiandao()-record1.getXyzhuanpan()-record1.getZczengsong()-record1.getCzzengsong()-record1.getHdzengsong();
				a1 = record.getBjltouzhu() - record.getBjlpaijiang();
				double a2 = record1.getBjltouzhu()-record1.getBjlpaijiang();
				count1+=count5;
				count2+=count6;
				count3+=count7;
				a1+=a2;
				record.setRgjiakuan(record.getRgjiakuan()+record1.getRgjiakuan());
				record.setZxchongzhi(record.getZxchongzhi()+record1.getZxchongzhi());
				record.setRgkoukuan(record.getRgkoukuan()+record1.getRgkoukuan());
				record.setZxtikuan(record.getZxtikuan()+record1.getZxtikuan()-record.getTkshibai()-record1.getTkshibai());
				record.setTkshouxufei(record.getTkshouxufei()+record1.getTkshouxufei()-record.getSfxtuihuan()-record1.getSfxtuihuan());
				record.setCptouzhu(record.getCptouzhu()+record1.getCptouzhu());
				record.setXtctouzhu(record.getXtctouzhu()+record1.getXtctouzhu());
				record.setCpchedan(record.getCpchedan()+record1.getCpchedan());
				record.setXtcchedan(record.getXtcchedan()+record1.getXtcchedan());
				record.setCppaijiang(record.getCppaijiang()+record1.getCppaijiang());
				record.setXitcpaijiang(record.getXitcpaijiang()+record1.getXitcpaijiang());
				record.setHjtuihuan(record.getHjtuihuan()+record1.getHjtuihuan());
				record.setTmbfanshui(record.getTmbfanshui()+record1.getTmbfanshui());
				record.setCpyichang(record.getCpyichang()+record1.getCpyichang());
				record.setXtcyichang(record.getXtcyichang()+record1.getXtcyichang());
				record.setBjltouzhu(record.getBjltouzhu()+record1.getBjltouzhu());
				record.setBjlpaijiang(record.getBjlpaijiang()+record1.getBjlpaijiang());
				record.setMrfanshui(record.getMrfanshui()+record1.getMrfanshui());
				record.setMyfanshui(record.getMyfanshui()+record1.getMyfanshui());
				record.setDlfandian(record.getDlfandian()+record1.getDlfandian());
				record.setMrqiandao(record.getMrqiandao()+record1.getMrqiandao());
				record.setXyzhuanpan(record.getXyzhuanpan()+record1.getXyzhuanpan());
				record.setHblingqu(record.getHblingqu()+record1.getHblingqu());
				record.setHbkouchu(record.getHbkouchu()+record1.getHbkouchu());
				record.setZczengsong(record.getZczengsong()+record1.getZczengsong());
				record.setCzzengsong(record.getCzzengsong()+record1.getCzzengsong());
				record.setHdzengsong(record.getHdzengsong()+record1.getHdzengsong());
				break;
				   
			case 3://今天之前的
				if(types==0) {
					record = todayRecordMapper.findByTimeAllGlobalReport(startTime,endTime,userName,2);
				}else {
					record = todayRecordMapper.findByTimeAllGlobalReport(startTime,endTime,"",1);
				}
				record.setZxtikuan(record.getZxtikuan()-record.getTkshibai());
				record.setTkshouxufei(record.getTkshouxufei()-record.getSfxtuihuan());
				count1 = record.getCptouzhu()-record.getCpchedan()-record.getCppaijiang()-record.getCpyichang();
				count2 = record.getXtctouzhu()-record.getXtcchedan()-record.getXitcpaijiang()-record.getXtcyichang();
				count3 = count1+count2+ record.getBjltouzhu() -record.getBjlpaijiang()-record.getHjtuihuan()-record.getTmbfanshui()-record.getMrfanshui()-record.getMyfanshui()-record.getDlfandian()
						-record.getMrqiandao()-record.getXyzhuanpan()-record.getZczengsong()-record.getCzzengsong()-record.getHdzengsong();
				a1 = record.getBjltouzhu()-record.getBjlpaijiang();
				break;
		}
		if(!"".equals(userName)) {
			count4 = 1;
		}else {
			count4 = orderMapper.findOrderNumberCount(startTime,endTime,"",-1);
		}
		record.setCaipiaosy(dec.format(count1));
		record.setXitongcaisy(dec.format(count2));
		record.setBjlshuying(dec.format(a1));
		record.setQuanbusy(dec.format(count3));
		record.setOrderCount(count4);
		return record;   
	}
	
	@Override
	public TodayRecord findAllFinanceReport(String startTime, String endTime, String userName,Integer type) {
		TodayRecord record = new TodayRecord();
		switch (type) {
			case 1: //今天
				record = liushuiMapper.findByUserNameTimeTodayRecord(DateUtil.findFormatDate(),userName);
				record.setZxtikuan(record.getZxtikuan()-record.getTkshibai());
				record.setMrfanshui(record.getMrfanshui()+record.getMyfanshui()+record.getTmbfanshui());
				break;
			case 2://所有
				record = liushuiMapper.findByUserNameTimeTodayRecord(DateUtil.findFormatDate(),userName);
				TodayRecord records = todayRecordMapper.findByTimeAllGlobalReport(startTime,endTime,userName,2);
				record.setZxchongzhi(record.getZxchongzhi()+records.getZxchongzhi());
				record.setZxtikuan(record.getZxtikuan()+records.getZxtikuan()-record.getTkshibai()-records.getTkshibai());
				record.setRgjiakuan(record.getRgjiakuan()+records.getRgjiakuan());
				record.setRgkoukuan(record.getRgkoukuan()+records.getRgkoukuan());
				record.setMrfanshui(record.getMrfanshui()+record.getMyfanshui()+record.getTmbfanshui()+records.getMrfanshui()+records.getMyfanshui()+records.getTmbfanshui());
				record.setDlfandian(record.getDlfandian()+records.getDlfandian());
				record.setCzzengsong(record.getCzzengsong()+records.getCzzengsong());
				record.setZczengsong(record.getZczengsong()+records.getZczengsong());
				break;
			case 3://今天之前的
				record = todayRecordMapper.findByTimeAllGlobalReport(startTime,endTime,userName,2);
				record.setZxtikuan(record.getZxtikuan()-record.getTkshibai());
				record.setMrfanshui(record.getMrfanshui()+record.getMyfanshui()+record.getTmbfanshui());
				break;
		}
		Integer ckcishu = liushuiMapper.findAllFinanceReport(startTime,endTime,userName,"1");
		Integer tkcishu = liushuiMapper.findAllFinanceReport(startTime,endTime,userName,"2");
		record.setCkcishu(ckcishu);
		record.setTkcishu(tkcishu);
		return record;   
	}

	@Override
	public TodayRecord findRecentReport(String date,Integer type) {
		DecimalFormat dec = new DecimalFormat("#0.00");
		TodayRecord record = new TodayRecord();
		double touzhu = 0.00;
		double paijiang = 0.00;
		double fandian = 0.00;
		double fanshui = 0.00;
		double huodong = 0.00;
		double kuiyin = 0.00;
		double chongzhi = 0.00;
		double tikuan = 0.00;
		switch (type) {
		case 1://平台每月
			if(DateUtil.findFormatDate().contains(date)) {
				record = liushuiMapper.findByUserNameTimeTodayRecord(date,"");
			}else {
				record = todayRecordMapper.findByTimeAllGlobalReport(date,"","",1);
			}
			break;
		case 2://平台每天
			record = liushuiMapper.findByUserNameTimeTodayRecord(date,""); 
			break;
		}
		touzhu = record.getCptouzhu()+record.getXtctouzhu()+ record.getBjltouzhu() -record.getCpchedan()+record.getXtcchedan()
		-record.getHjtuihuan()-record.getCpyichang()-record.getXtcyichang();
		paijiang = record.getCppaijiang()+record.getXitcpaijiang()+record.getBjlpaijiang();
		fandian = record.getDlfandian();
		fanshui = record.getMrfanshui()+record.getMyfanshui()+record.getTmbfanshui();
		huodong = record.getMrqiandao()+record.getXyzhuanpan()+record.getZczengsong()+record.getCzzengsong()+record.getHdzengsong();
		chongzhi = record.getZxchongzhi()+record.getRgjiakuan();
		tikuan = record.getZxtikuan()+record.getRgkoukuan()-record.getTkshibai();
		kuiyin = touzhu - paijiang - fandian - fanshui - huodong;
		
		record.setTime(date);
		record.setTouzhu(touzhu);
		record.setPaijiang(new Double(dec.format(paijiang)));
		record.setFandian(fandian);
		record.setFanshui(fanshui);
		record.setHuodong(huodong);
		record.setChongzhi(chongzhi);
		record.setTikuan(tikuan);
		record.setKuiyin(new Double(dec.format(kuiyin)));
		return record;
	}

	@Override
	public TodayRecord findOperateRecord(String startTime, String endTime, String userName,Integer type) {
		TodayRecord record = new TodayRecord();
		double touzhu = 0.00;
		double paijiang = 0.00;
		double fandian = 0.00;
		double fanshui = 0.00;
		double huodong = 0.00;
		double chongzhi = 0.00;
		double tikuan = 0.00;
		double qipaitouzhu = 0.00;
		double qipaipaijiang = 0.00;
		double kuiyin = 0.00;
		switch (type) {
		case 1: // 用户 今天的 或者 一个月
			record = liushuiMapper.findByUserNameTimeTodayRecord(startTime,userName);
			touzhu = record.getCptouzhu()+record.getXtctouzhu()+ record.getDmzengjia() - record.getDmkouchu()-record.getCpchedan()
					+record.getXtcchedan() -record.getHjtuihuan()-record.getCpyichang()-record.getXtcyichang();
			paijiang = record.getCppaijiang()+record.getXitcpaijiang();
			fandian = record.getDlfandian();
			fanshui = record.getMrfanshui()+record.getMyfanshui()+record.getTmbfanshui();
			huodong = record.getMrqiandao()+record.getXyzhuanpan()+record.getZczengsong()+record.getCzzengsong()+record.getHdzengsong();
			chongzhi = record.getZxchongzhi()+record.getRgjiakuan();
			tikuan = record.getZxtikuan()+record.getRgkoukuan()-record.getTkshibai();
			qipaitouzhu = record.getBjltouzhu();
			qipaipaijiang = record.getBjlpaijiang();
			kuiyin = touzhu - paijiang - fandian - fanshui - huodong + record.getBjltouzhu() - record.getBjlpaijiang();
			
			record.setTouzhu(touzhu);
			record.setPaijiang(paijiang);
			record.setChongzhi(chongzhi);
			record.setTikuan(tikuan);
			record.setFanshui(fanshui);
			record.setFandian(fandian);
			record.setHuodong(huodong);
			record.setQipaiBetting(qipaitouzhu);
			record.setQipaiAwards(qipaipaijiang);
			record.setKuiyin(kuiyin);
			break;
			
		case 2: //用户 之前到今天的
			record = liushuiMapper.findByUserNameTimeTodayRecord(DateUtil.findFormatDate(),userName);
			TodayRecord records = todayRecordMapper.findByTimeAllGlobalReport(startTime,endTime,userName,2);
			double t1 = record.getCptouzhu()+record.getXtctouzhu() + record.getDmzengjia() - record.getDmkouchu()-record.getCpchedan()+record.getXtcchedan()
			-record.getHjtuihuan()-record.getCpyichang()-record.getXtcyichang();
			double t2 = records.getCptouzhu()+records.getXtctouzhu() + records.getDmzengjia() - records.getDmkouchu()-records.getCpchedan()+records.getXtcchedan()
			-records.getHjtuihuan()-records.getCpyichang()-records.getXtcyichang();
			touzhu = t1+t2;
			double t3 = record.getCppaijiang()+record.getXitcpaijiang();
			double t4 = records.getCppaijiang()+records.getXitcpaijiang();
			paijiang = t3+t4;
			double t5 = record.getMrfanshui()+record.getMyfanshui()+record.getTmbfanshui();
			double t6 = records.getMrfanshui()+records.getMyfanshui()+records.getTmbfanshui();
			fandian = record.getDlfandian()+records.getDlfandian();
			fanshui = t5+t6;
			huodong = record.getMrqiandao()+record.getXyzhuanpan()+record.getZczengsong()+record.getCzzengsong()+record.getHdzengsong()+
					records.getMrqiandao()+records.getXyzhuanpan()+records.getZczengsong()+records.getCzzengsong()+records.getHdzengsong();
			chongzhi = record.getZxchongzhi()+record.getRgjiakuan()+records.getZxchongzhi()+records.getRgjiakuan();
			tikuan = record.getZxtikuan()+record.getRgkoukuan()+records.getZxtikuan()+records.getRgkoukuan()-record.getTkshibai()-records.getTkshibai();
			qipaitouzhu = record.getBjltouzhu()+records.getBjltouzhu();
			qipaipaijiang = record.getBjlpaijiang()+records.getBjlpaijiang();
			kuiyin = touzhu - paijiang - fandian - fanshui - huodong + record.getBjltouzhu() + records.getBjltouzhu() - record.getBjlpaijiang() - records.getBjlpaijiang();
		
			record.setZxchongzhi(record.getZxchongzhi()+records.getZxchongzhi());
			record.setZxtikuan(record.getZxtikuan()+records.getZxtikuan());
			record.setRgjiakuan(record.getRgjiakuan()+records.getRgjiakuan());
			record.setRgkoukuan(record.getRgkoukuan()+records.getRgkoukuan());
			record.setXyzhuanpan(record.getXyzhuanpan()+records.getXyzhuanpan());
			record.setHblingqu(record.getHblingqu()+records.getHblingqu());
			record.setMrqiandao(record.getMrqiandao()+records.getMrqiandao());
			record.setDlfandian(fandian);
			record.setMrfanshui(fanshui);
			record.setCzzengsong(record.getCzzengsong()+records.getCzzengsong());
			record.setZczengsong(record.getZczengsong()+records.getZczengsong());
			record.setBjltouzhu(record.getBjltouzhu()+records.getBjltouzhu());
			record.setBjlpaijiang(record.getBjlpaijiang()+records.getBjlpaijiang());
			
			record.setTouzhu(touzhu);
			record.setPaijiang(paijiang);
			record.setChongzhi(chongzhi);
			record.setTikuan(tikuan);
			record.setFandian(fandian);
			record.setFanshui(fanshui);
			record.setHuodong(huodong);
			record.setQipaiBetting(qipaitouzhu);
			record.setQipaiAwards(qipaipaijiang);
			record.setKuiyin(kuiyin);
			break;
			
		case 3: //用户 之前的
			record = todayRecordMapper.findByTimeAllGlobalReport(startTime,endTime,userName,2);
			touzhu = record.getCptouzhu()+record.getXtctouzhu() + record.getDmzengjia() - record.getDmkouchu()-record.getCpchedan()+record.getXtcchedan()
			-record.getHjtuihuan()-record.getCpyichang()-record.getXtcyichang();
			paijiang = record.getCppaijiang()+record.getXitcpaijiang();
			fandian = record.getDlfandian();
			fanshui = record.getMrfanshui()+record.getMyfanshui()+record.getTmbfanshui();
			huodong = record.getMrqiandao()+record.getXyzhuanpan()+record.getZczengsong()+record.getCzzengsong()+record.getHdzengsong();
			chongzhi = record.getZxchongzhi()+record.getRgjiakuan();
			tikuan = record.getZxtikuan()+record.getRgkoukuan()-record.getTkshibai();
			qipaitouzhu = record.getBjltouzhu();
			qipaipaijiang = record.getBjlpaijiang();
			kuiyin = touzhu - paijiang - fandian - fanshui - huodong + record.getBjltouzhu() - record.getBjlpaijiang();;
			
			record.setTouzhu(touzhu);
			record.setPaijiang(paijiang);
			record.setChongzhi(chongzhi);
			record.setTikuan(tikuan);
			record.setFandian(fandian);
			record.setFanshui(fanshui);
			record.setHuodong(huodong);
			record.setQipaiBetting(qipaitouzhu);
			record.setQipaiAwards(qipaipaijiang);
			record.setKuiyin(kuiyin);
			break;
		}
		return record;
	}

	@Override
	public int censusTodayRecord() {
		List<User> users = userMapper.findAllUserIdOrName();
		for(User user : users) {
			List<TodayRecord> total = todayRecordMapper.findByTimeUserIdYesterdayTotal(DateUtil.findLatelyDate(-1),user.getId());
			if(total.size()==0) {
				TodayRecord todayRecord = liushuiMapper.findByUserIdTimeTodayRecord(user.getId(),DateUtil.findLatelyDate(-1),2);
				todayRecord.setName(user.getName());
				todayRecord.setType(2);
				todayRecord.setCreated_time(DateUtil.findLatelyDate(-1)+" "+DateUtil.getCurrTime().split(" ")[1]);
				todayRecord.setUser_id(user.getId());
				todayRecordMapper.insertTodayRecord(todayRecord);
			}
		}
		List<TodayRecord> total = todayRecordMapper.findByTimeUserIdYesterdayTotal(DateUtil.findLatelyDate(-1),-1);
		if(total.size()==0) {
			TodayRecord todayRecord = liushuiMapper.findByUserIdTimeTodayRecord(-1,DateUtil.findLatelyDate(-1),1);
			todayRecord.setName("平台");
			todayRecord.setType(1);
			todayRecord.setCreated_time(DateUtil.findLatelyDate(-1)+" "+DateUtil.getCurrTime().split(" ")[1]);
			todayRecord.setUser_id(-1);
			todayRecordMapper.insertTodayRecord(todayRecord);
		}
		return 0;
	}

	@Override
	public TodayRecord findByTimeUserRechargeTotal(String findFormatDate, String last12Months, Integer user_id) {
		return liushuiMapper.findByTimeUserRechargeTotal(DateUtil.findFormatDate(),DateUtil.getLast12Months(0),user_id);
	}

	@Override
	public TodayRecord findJuniorStatistics(String startTime, String endTime, String userName, Integer type,Integer model) {
		TodayRecord record = new TodayRecord();
		TodayRecord record1 = new TodayRecord();
		DecimalFormat dec = new DecimalFormat("#0.00");
		double count1 = 0.00;//彩票输赢
		double count2 = 0.00;//系统彩输赢
		double count3 = 0.00;//全部输赢
		double a1 = 0.00;//百家乐输赢
		int count4 = 0; // 投注人数
			switch (type) {
				case 1: //今天
					if(model ==-1) {
						record = liushuiMapper.findByUserNameTimeTodayRecord(DateUtil.findFormatDate(),userName);
					}else {
						record = liushuiMapper.findByIdTimeTodayRecord(DateUtil.findFormatDate(),userName);
					}
					record.setZxtikuan(record.getZxtikuan()-record.getTkshibai());
					record.setMrfanshui(record.getMrfanshui()+record.getMyfanshui()+record.getTmbfanshui());
					count1 = record.getCppaijiang()+record.getCpchedan()+record.getCpyichang()-record.getCptouzhu();
					count2 = record.getXitcpaijiang()+record.getXtcchedan()+record.getXtcyichang() - record.getXtctouzhu();
					a1 = record.getBjlpaijiang() - record.getBjltouzhu();
					count3 = count1 + count2 + a1 +record.getHjtuihuan()+record.getTmbfanshui()+record.getMrfanshui()+record.getMyfanshui()+record.getDlfandian()
							+record.getMrqiandao()+record.getXyzhuanpan()+record.getZczengsong()+record.getCzzengsong()+record.getHdzengsong();
					break;
				case 2://所有
					if(model ==-1) {
						record = liushuiMapper.findByUserNameTimeTodayRecord(DateUtil.findFormatDate(),userName);
						record1 = todayRecordMapper.findByTimeAllGlobalReport(startTime,endTime,userName,2);
					}else {
						record = liushuiMapper.findByIdTimeTodayRecord(DateUtil.findFormatDate(),userName);
						record1 = todayRecordMapper.findByIdTimeAllGlobalReport(startTime,endTime,userName,2);
					}
					count1 = record.getCppaijiang()+record.getCpchedan()+record.getCpyichang()-record.getCptouzhu();
					count2 = record.getXitcpaijiang()+record.getXtcchedan()+record.getXtcyichang() - record.getXtctouzhu();
					a1 = record.getBjlpaijiang() - record.getBjltouzhu();
					count3 = count1 + count2 + a1 +record.getHjtuihuan()+record.getTmbfanshui()+record.getMrfanshui()+record.getMyfanshui()+record.getDlfandian()
					+record.getMrqiandao()+record.getXyzhuanpan()+record.getZczengsong()+record.getCzzengsong()+record.getHdzengsong();
					
					double a2 =record1.getBjlpaijiang() - record1.getBjltouzhu();
					double count5 = record1.getCppaijiang()+record1.getCpchedan()+record1.getCpyichang()-record1.getCptouzhu();
					double count6 = record1.getXitcpaijiang()+record1.getXtcchedan()+record1.getXtcyichang() - record1.getXtctouzhu();
					double count7 = count5+count6 + a2 + record1.getHjtuihuan()+record1.getTmbfanshui()+record1.getMrfanshui()+
							record1.getMyfanshui()+record1.getDlfandian()+record1.getMrqiandao()+record1.getXyzhuanpan()+
							record1.getZczengsong()+record1.getCzzengsong()+record1.getHdzengsong();
					count1+=count5;
					count2+=count6;
					count3+=count7;
					a1+=a2;
					record.setZxchongzhi(record.getZxchongzhi()+record1.getZxchongzhi());
					record.setRgjiakuan(record.getRgjiakuan()+record1.getRgjiakuan());
					record.setZxtikuan(record.getZxtikuan()+record1.getZxtikuan()-record.getTkshibai()-record1.getTkshibai());
					record.setRgkoukuan(record.getRgkoukuan()+record1.getRgkoukuan());
					record.setTkshouxufei(record.getTkshouxufei()+record1.getTkshouxufei());
					record.setTkshibai(record.getTkshibai()+record1.getTkshibai());
		 			record.setSfxtuihuan(record.getSfxtuihuan()+record1.getSfxtuihuan());
					record.setCptouzhu(record.getCptouzhu()+record1.getCptouzhu());
					record.setXtctouzhu(record.getXtctouzhu()+record1.getXtctouzhu());
					record.setCpchedan(record.getCpchedan()+record1.getCpchedan());
					record.setXtcchedan(record.getXtcchedan()+record1.getXtcchedan());
					record.setCppaijiang(record.getCppaijiang()+record1.getCppaijiang());
					record.setXitcpaijiang(record.getXitcpaijiang()+record1.getXitcpaijiang());
					record.setHjtuihuan(record.getHjtuihuan()+record1.getHjtuihuan());
					record.setTmbfanshui(record.getTmbfanshui()+record1.getTmbfanshui());
					record.setCpyichang(record.getCpyichang()+record1.getCpyichang());
					record.setXtcyichang(record.getXtcyichang()+record1.getXtcyichang());
					record.setBjltouzhu(record.getBjltouzhu()+record1.getBjltouzhu());
					record.setBjlpaijiang(record.getBjlpaijiang()+record1.getBjlpaijiang());
					record.setMrfanshui(record.getMrfanshui()+record1.getMrfanshui());
					record.setMyfanshui(record.getMyfanshui()+record1.getMyfanshui());
					record.setDlfandian(record.getDlfandian()+record1.getDlfandian());
					record.setMrqiandao(record.getMrqiandao()+record1.getMrqiandao());
					record.setXyzhuanpan(record.getXyzhuanpan()+record1.getXyzhuanpan());
					record.setHblingqu(record.getHblingqu()+record1.getHblingqu());
					record.setHbkouchu(record.getHbkouchu()+record1.getHbkouchu());
					record.setZczengsong(record.getZczengsong()+record1.getZczengsong());
					record.setCzzengsong(record.getCzzengsong()+record1.getCzzengsong());
					record.setHdzengsong(record.getHdzengsong()+record1.getHdzengsong());
					break;
				case 3://今天之前的
					if(model == -1) {
						record = todayRecordMapper.findByTimeAllGlobalReport(startTime,endTime,userName,2);
					}else {
						record = todayRecordMapper.findByIdTimeAllGlobalReport(startTime,endTime,userName,2);
					}
					record.setZxtikuan(record.getZxtikuan()-record.getTkshibai());
					record.setMrfanshui(record.getMrfanshui()+record.getMyfanshui()+record.getTmbfanshui());
					count1 = record.getCppaijiang()+record.getCpchedan()+record.getCpyichang()-record.getCptouzhu();
					count2 = record.getXitcpaijiang()+record.getXtcchedan()+record.getXtcyichang() - record.getXtctouzhu();
					a1 = record.getBjlpaijiang() - record.getBjltouzhu();
					count3 = count1 + count2 + a1 +record.getHjtuihuan()+record.getTmbfanshui()+record.getMrfanshui()+record.getMyfanshui()+record.getDlfandian()
							+record.getMrqiandao()+record.getXyzhuanpan()+record.getZczengsong()+record.getCzzengsong()+record.getHdzengsong();
					break;
				}
			if(!"".equals(userName)) {
				count4 = 1;
			}else {
				count4 = orderMapper.findOrderNumberCount(startTime,endTime,userName,-2);
			}
			record.setCaipiaosy(dec.format(count1));
			record.setXitongcaisy(dec.format(count2));
			record.setBjlshuying(dec.format(a1));
			record.setQuanbusy(dec.format(count3));
			record.setOrderCount(count4);
		return record;   
	}


}