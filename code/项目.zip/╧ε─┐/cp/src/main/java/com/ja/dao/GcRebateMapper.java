package com.ja.dao;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.ja.domain.GcRebate;

public interface GcRebateMapper {

	/**
	 * 查询港彩投注反水设置
	 * @param cname 
	 * @return
	 */
	List<GcRebate> findAllGcRebate(@Param("name")String cname);
	
	/**
	 * 方法名：findByIdGcRebate 
	 * 描述：     根据id查询特码返水配置                  TODO
	 * 参数：    @param id 配置id
	 * 参数：    @return 
	 * @return: GcRebate
	 */
	GcRebate findByIdGcRebateInfo(Integer id);
	
	/**
	 * 添加港彩反水设置
	 * @param gcRebate 反水设置信息
	 * @return
	 */
	int insertGcRebate(GcRebate gcRebate);
	/**
	 * 修改港彩反水设置
	 * @param gcRebate 反水设置信息
	 * @return
	 */
	int updateByGcRebate(GcRebate gcRebate);
	
	/**
	 * 刪除
	 * @param id
	 * @return
	 */
	int deleteshanchu(Integer id);
	
}