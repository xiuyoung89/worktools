package com.ja.util;

import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.web.servlet.HandlerInterceptor;
import org.springframework.web.servlet.ModelAndView;

import com.ja.domain.User;

/**
 * @AUTH LBQ
 * @DATE 2017年10月27日 下午5:31:57
 * @DESC
 */
public class Interceptor implements HandlerInterceptor {

	@Override
	public void afterCompletion(HttpServletRequest request, HttpServletResponse response, Object object2,
			Exception object3) throws Exception {

	}

	@Override
	public void postHandle(HttpServletRequest request, HttpServletResponse response, Object object2,
			ModelAndView object3) throws Exception {

	}

	@Override
	public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object object2)
			throws Exception {
		HttpSession session = request.getSession();
		User user = (User) session.getAttribute("user");
		boolean flag = true;
		if(user==null) {
			//response.sendRedirect("/login.jsp");
			ServletOutputStream out = response.getOutputStream();
			 out.print(50);//返回给前端页面的未登陆标识
			//response.setStatus(1314520);
			 out.flush();
             out.close();
			flag = false;
		}
		return flag;
		
	}
}
