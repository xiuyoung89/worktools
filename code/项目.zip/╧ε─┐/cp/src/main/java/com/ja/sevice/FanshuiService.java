package com.ja.sevice;

import java.util.List;

import com.ja.domain.Fanshui;

public interface FanshuiService {

	/**查询今日本月反水所需*/
	List<Fanshui> getAllfanshui();

	/**修改反水点率*/
	int upfanshui(Fanshui s);

	/**开启或关闭反水
	 * @param state */
	int kaiqifs(int id, int state);

	/**
	 * 添加日常反水的设置
	 * @param fanshui
	 * @return
	 */
	int insertBackwater(Fanshui fanshui);

	/**
	 * 删除返水功能
	 * @param id
	 */
	 int deleteBackwater(Integer id);

	 /**
	  * 方法名：findOneBackWaterSetup 
	  * 描述：     根据id查询返水设置                  TODO
	  * 参数：    @param id 返水设置id
	  * 参数：    @return 
	  * @return: Fanshui
	  */
	Fanshui findByIdBackWaterSetup(Integer id);
	 
	 
	 
	 


}
