package com.ja.dao;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.ja.domain.Data;
import com.ja.domain.PlayCount;
import com.ja.domain.Product;

public interface DataMapper {

	/** 查找所有最新data */
	List<Data> getLatestData();

	List<Data> getDatasbyCname(String cName);

	Data getNewDataByCname(String key);

	Data getLotteryDate(@Param("period")String period,@Param("cname")String cname);

	/** 查询某个彩种的开奖记录 */
	List<Data> getAllData(@Param("cname")String cname,@Param("date")String date);

	/** 根据条件查询开奖记录 
	 * @param i 
	 * @param integer2 
	 * @param integer */
	List<Data> getMhAllData(@Param("startIndex")Integer startIndex, @Param("lineCount")Integer lineCount,  @Param("d") Data data, @Param("date1") String date1, @Param("date2") String date2, @Param("model")int i);

	/** 查询所有的开奖记录 */
	List<Data> getSouyou();

	/** 某个彩种一天的开奖记录 */
	List<Data> findTodycz(String cname);

	/** 北京pk10 */
	List<Data> findBjpk10();

	/** 六合彩预设记录 */
	List<Data> getAllLiuhePreset();

	/**修改系统彩的开奖状态*/
	int addLiuheCheck(@Param("d") Data data);
	
	/** 批量新增彩票数据 */
	int insertByBatch(@Param("insertDatas") List<Data> insertDatas);

	/** 手动开奖填写开奖号码 */
	int updateCheckNum(@Param("d") Data data);

	/** 手动彩票派奖 */
	int updateCheck(@Param("d") Data data);
	
	/**未开奖的数据*/
	List<Data> findNull();

	/**最大一期的期号*/
	Data getMaxPeriod(String cname);
	
	/**
	 * 
	   *   方法名：updateDate   
	   *   描述：      添加私彩开奖时间                 TODO   
	   *   参数：    @param data
	   *   参数：    @return 
	 * @return: int
	 */
	int updateDate(Data data);
	
	/**香港六合彩*/
	int xg6hc(String cName);
	
	/**删除*/
	int xglhcDelete(@Param("period")String period,@Param("cname")String cname);
	
	Data Verification(@Param("cName")String cName,@Param("period")String period);

	/**官方异常修改状态*/
	int updateFail(@Param("d")Data data);

	/**查询某个彩种的开奖记录 
	 * @param lineCount 
	 * @param startIndex 
	 * @param model
	  */
	List<Data> getCheckData(@Param("startIndex")Integer startIndex, @Param("lineCount")Integer lineCount, @Param("cname")String cname, @Param("model")int model);
	
	/**
	 * 
	 * @return 查询足彩信息
	 */
	Data getFootBall();
	
	/**
	 * 
	 * @param data 足彩赛事信息
	 */
	int addFootBallData(@Param("d")Data data);
	
	/**
	 * 下期开奖时间
	 * @param name 彩种名称
	 * @param time 下注时间
	 * @param time3 下期时间
	 * @return
	 */
	Data findBetsTime(@Param("name")String name, @Param("time")String time, @Param("time3")String time3);

	/**
	 * 批量更新彩票数据
	 * @param updateDatas
	 */
	void updateByBatch(@Param("updateDatas")List<Data> updateDatas);
	
	/**
	 * 插入一条数据
	 * @param updateDatas
	 */
	void insert(@Param("data")Data data);
	
	/**
	 * 查询开奖信息
	 * @param name
	 * @param period
	 * @return
	 */
	List<Data> findDatas(@Param("data") List<Data> data);
	
	/**
	 * 添加私彩期号
	 * @param datas 期号信息
	 * @return
	 */
	int addSystemLotters(@Param("datas")List<Data> datas);
	
	/**
	 * 查询最新的一期开奖信息
	 * @param cname 彩种名称
	 * @param time 今天的时间
	 * @return
	 */
	Data findNewestPeriod(@Param("cname") String cname, @Param("time")String time);
	
	/**
	 * 添加私彩开奖号码
	 * @param data 开奖信息
	 * @return
	 */
	int addSystemLotterInfo(@Param("data")Data data);
	
	/**
	 * 查询期号是否已经插入
	 * @param cname 彩种英文名
	 * @param newPeriod 第一期期号
	 * @return
	 */
	Data findLotterFirstPeriod(@Param("cname") String cname, @Param("period")String newPeriod);

	/**
	 * 查询期数中包含日期信息的彩种的当天最新期数
	 * @return
	 */
	String getTodayLatestPeriodOfNormalCp(@Param("cName") String cName, @Param("period")String period);
	
	/**
	 * 查询期数中不包含日期信息的彩种的当天最新期数
	 * @return
	 */
	String getTodayLatestPeriodOfSpecialCp(@Param("cName") String cName,@Param("startPeriod") String startPeriod,
			@Param("endPeriod") String endPeriod);
	
	/**
	 * 查询最后一期
	 * @param cname 彩种英文名
	 * @param time 当前时间
	 * @return
	 */
	Data findLotterLastPeriod(@Param("name") String cname, @Param("time")String time);

	/**
	 * 根据彩种名称和期数查询相应数据
	 * @param cname
	 * @param period
	 * @return
	 */
	Data findDataByNameAndPeriod(@Param("cname") String cname, @Param("period") String period);

	/**
	 * 根据彩种名称查出已经开奖的最新一期数据
	 * @param cname
	 * @return
	 */
	Data getLatestOpenData(@Param("cname") String cname);

	/**
	 * 更新开奖号码为空串
	 * @param id
	 */
	void updateLotterNumberToEmptyStr(@Param("id") Integer id);
	
	/**
	 * 六合彩添加开奖期号
	 * @param data 彩种信息
	 * @param num 状态量
	 * @return
	 */
	int addLiuheChecks(@Param("d")Data data);

	/**
	 * 根据ID查数据
	 * @param id
	 * @return
	 */
	Data findById(@Param("id")Integer id);
	
	/**
	 * 查询预设的旗号
	 * @param cname
	 * @param time1
	 * @return
	 */
	Data findBySetCname(@Param("cname") String cname, @Param("time") String time);

	/**
	 * 修改开奖信息
	 * @param data 彩种信息
	 * @return
	 */
	int updateCheckState(Data data);
	
	/**
	 * 添加开奖结果
	 * @param data 彩种信息
	 * @return
	 */
	int updatePlayResult(Data data);

	/**
	 * 查询六合的属性
	 * @return
	 */
	List<Data> findLiuHeAttribute(int type);
	
	/**
	 * 查询私彩玩法下注详情
	 * @param data 彩种信息
	 * @return
	 */
	List<PlayCount> findPlayDetails(Data data);
	
	/**
	 * 修改开奖的状态
	 * @param data 彩种信息
	 * @return
	 */
	int changeCheckState(Data data);

	/**
	 * 查询官方下期开奖
	 * @param cname
	 * @return
	 */
	Data findNextPeriod(String cname);
	
	/**
	 * 把爬到的开奖号。更新进去
	 * @param period
	 * @param lotterNumber
	 * @param lotterTime
	 * @return
	 */
	int update(@Param("cname")String cname,@Param("period")String period,@Param("lotterNumber")String lotterNumber,@Param("lotterTime")String lotterTime);
	/**
	 * 根据彩种名称和期号查询当期开奖信息并拿到下期开奖期号
	 * @param cName:彩种名称
	 * @param period：期号
	 * @return
	 */
	Data querynextIssueNumber(@Param("cName")String cName,@Param("nextperiod")String nextperiod);

	/**
	 * 更新当前期号和之前的数据的status为1
	 * @param cname
	 * @param id
	 */
	void updatePreDataStatusTo1(String cname,Integer id);
	
	/**
	 * 更新status为1
	 * @param id
	 */
	void updateStatusTo1(Integer id);
	
	/**
	 * 根据彩种名称和时间查询第一次开奖时间
	 * @param cname
	 * @param time
	 * @return
	 */
	Product selectDateTime(@Param("cname")String cname,@Param("time")String time);
	
	/**
	 * 根据彩种名称和id查询下期开奖时间
	 * @param cname
	 * @param id
	 * @return
	 */
	Product dateTime(@Param("cname")String cname,@Param("id")int id);
	
	/**
	 * 上期的时间
	 * @param id
	 * @param cname
	 * @return
	 */
	String findLastTime(@Param("id")Integer id, @Param("cname")String cname);

	/**
	 * @param nowTime
	 * @return
	 */
	List<Data> findCurrDatas(String nowTime);
	
	
	/**
	 * 分页查询数据
	 * @param iDisplayStart 起始数
	 * @param iDisplayLength结束数
	 * @return
	 */
	List<Data> getPageData(int iDisplayStart, int iDisplayLength);
	
	/**
	 * 根据彩种名称查询最新的信息
	 * @param cname 彩种名称
	 * @return
	 */
	List<Data> getLimitDataInfo(String cname); 
	
	/**
	 * 获取数据库总条数
	 * @return
	 */
	Integer count();
	/**
	 * 查询上周数据
	 * @return
	 */
	List<Data> lastWeek();
	/**
	 * 查询上月数据
	 * @return
	 */
	List<Data> lastMonth();
	
	/**
	 * 批量删除Data表数据
	 * @param data
	 * @return
	 */
	int deletedata(@Param("data")List<Data> data);
	
	/**
	 * 
	    *   方法名：getCheckDataCounts   
	    *   描述：    根据彩种名称查询开奖记录数                   TODO   
	    *   参数：    @param cname
	    *   参数：    @return 
	 * @return: Integer
	 */
	Integer getCheckDataCounts(String cname);
	
	/**
	 * 
	    *   方法名：getMhAllDataCounts   
	    *   描述：                       TODO   
	    *   参数：    @param data
	    *   参数：    @param date1
	    *   参数：    @param date2
	    *   参数：    @return 
	 * @return: Integer
	 */
	Integer getMhAllDataCounts(@Param("d")Data data, @Param("date1")String date1, @Param("date2")String date2);
	
	/**
	 * 
	   *   方法名：lotterDatas   
	   *   描述：    根据时间查询开奖信息                   TODO   
	   *   参数：    @param cname 彩种名称
	   *   参数：    @param date 查询类型
	   *   参数：    @return 
	 * @return: List<Data>
	 */
	List<Data> lotterDatas(@Param("cname")String cname, @Param("date")String date);
	
	/**
	 * 
	   *   方法名：findNextNextPeriod   
	   *   描述：     下下期时间             TODO   
	   *   参数：    @param cname 彩种名称
	   *   参数：    @return 
	 * @return: Data
	 */
	Data findNextNextPeriod(@Param("cname")String cname, @Param("type")Integer type);
	 /**
	  * 查询香港六合彩最新一期id
	  * @return
	  */
	Integer xg6hcId();
	
	/**
	 * 根据彩种名期号修改当期 开奖时间和下期开奖时间 修改字段则是 nextStopOrderTimeEpoch  openTime
	 * @param cName  彩种名
	 * @param period 期号 
	 * @param openTime 开奖时间
	 * @param status 开奖时间
	 * @param nextStopOrderTimeEpoch  下期开奖时间
	 * @return  修改成功则返回1  只要返回别的都是不成功
	 */
	int  updataNextDate(@Param("cName")String cName,@Param("period")String period,@Param("openTime")String openTime,@Param("nextStopOrderTimeEpoch")String nextStopOrderTimeEpoch,@Param("status")int status);
	

	/**
	 * 
	   *   方法名：findTrend   
	   *   描述：     查询近期的走势图                  TODO   
	   *   参数：    @param time
	   *   参数：    @return 
	 * @param cname 
	 * @return: List<Data>
	 */
	List<Data> findTrend(@Param("time")String time, @Param("cname")String cname); 
	
	/**查询香港六合彩根据期号查询当前的数据*/
	Data xg6hcchax(@Param("period")String period);
	
	/**
	 * 
	   *   方法名：statusXg6hc   
	   *   描述：    修改香港六合彩开奖status状态                   TODO   
	   *   参数：    @param data 修改信息
	   *   参数：    @return 
	 * @return: int
	 */
	int statusXg6hc(Data data);
	
	/**
	 * 根据传入的期号查询当期的整条数据
	 * @param cname 彩种名称
	 * @param period 需要查询的期号
	 * @return
	 */
	Data pueryCurrentPeriod(@Param("cName")String cName,@Param("period")String period);
	/**
	 * 查询当前全部彩种没有开出来的数据
	 * @param cName
	 * @return
	 */
	List<Data> queryData(@Param("cName")String cName);
	
	/**
	 * 查询数据库里面异常的数据 
	 * @return
	 */
	List<Data> databaseExceptionData();
	/**
	 * 查询每个彩种最后一条开奖数据
	 * @param cName 彩种名称
	 * @return
	 */
	Data theLastItem(String cName);
	/**
	 * 根据当前期号查询上期期号 如果查询到返回Data对象 如果没有查询到则返回null
	 * @param cName  彩种名称
	 * @param period   当期期号
	 * @return  如果查询到就返回Data对象 如果没有查询到则返回null
	 */
	Data previousIssue(@Param("cName")String cName,@Param("period")String period);
	/**
	 * 统计数据库里面开奖异常的数据有多少条
	 * @return 返回异常数据的总条数
	 */
	Integer getAbnormalData();
	
	
	/**
	 * 根据彩种名称和期号修改开奖状态     把status状态修改成1
	 * @param cname  彩种名称
	 * @param period  期号
	 * @return 修改成则返回1 返回别的都是不成功的
	 */
	int updataCnameStatus(String cname,String period);
	
	/**
	 * 根据彩种名和期号修改下期开奖时间  修改字段为 nextStopOrderTimeEpoch
	 * @param cname  彩种名
	 * @param period 期号  是当期期号不是下期期号 
	 * @param nextStopOrderTimeEpoch 修改时间的值
	 * @return 修改成功则返回1 返回其他的都是错误的
	 */
	int upDataNextTime(@Param("cName")String cName,@Param("period")String period,@Param("nextStopOrderTimeEpoch")String nextStopOrderTimeEpoch);
	
	/**
	 * 查询彩种中文名和英文名，
	 * @return 查询到则 返回list集合包含data实体类 
	 */
	List<Data> wholeLot();
	
	/**
	 * 根据id查询他下期开奖数据
	 * @param id 
	 * @param cname 彩种名 
	 * @return 返回比他id还大的数据
	 */
	Data Id(@Param("id")Integer id,@Param("cname")String cname);
	/**
	 * 保存计划的开奖数据
	 * @param d  开奖数据对象
	 * @return 成功则返回0
	 */
	int Preservation(@Param("d")Data d);
	
	/**
	 * 查询排列的计划
	 * @param cName 彩种名称 
	 * @param period 开奖期号
	 * @return 如果后台预设了 在一期 则返回当期开奖数据  如果没有预设则返回null
	 */
	Data lotteryData(@Param("cName")String cName,@Param("period")String period);
	/**
	 * 修改系统彩 预设号码
	 * @param d
	 * @return 成功就返回1
	 */
	int systemLotterUpData(@Param("d")Data d);
	/**
	 * 删除计划表里面的计划数据
	 * @param cName 彩种名
	 * @param period 期号
	 * @return 删除成功则返回1 失败则返回0
	 */
	int deleteLotterSystemData(@Param("cName")String cName,@Param("period")String period);
	/**
	 * 查询数据库里面最新的一条数据
	 * @param cName  彩种名称
	 * @return 查询到则返回Data对象数据  没查询到则返回null
	 */
	Data dataLast(@Param("cName")String cName);
}
