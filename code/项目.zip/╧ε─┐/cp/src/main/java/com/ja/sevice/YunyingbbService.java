package com.ja.sevice;

import com.ja.domain.TodayRecord;

public interface YunyingbbService {
	
	/**
	 * 
	 * ----TODO：报表管理
	 * 
	 */
	
	/**
	 *   方法名：findAllGlobalReport   
	 *   描述：    查询相关的全局统计报表                      
	 *   参数：    @param startTime 开始时间
	 *   参数：    @param endTime 结束时间
	 *   参数：    @param name 用户名称
	 *   参数：    @param type 查询的时间类型 1 今天  2 历史 3 今天之前
	 *   参数：    @return 
	 * @return: TodayRecord
	 */
	TodayRecord findAllGlobalReport(String startTime, String endTime, String userName,Integer type,Integer types);

	/**
	 *   方法名：findAllFinanceReport   
	 *   描述：    查询用户的财务报表                      
	 *   参数：    @param startTime 开始时间
	 *   参数：    @param endTime 结束时间
	 *   参数：    @param name 用户名称
	 *   参数：    @param type 查询的时间类型 1 今天  2 历史 3 今天之前
	 *   参数：    @return 
	 * @return: TodayRecord
	 */
	TodayRecord findAllFinanceReport(String startTime, String endTime, String name,Integer type);
	
	/**
	 *   方法名：findRecentReport   
	 *   描述：   查询最近报表                       
	 *   参数：    @param date 时间
	 *   参数：    @return 
	 * @return: TodayRecord
	 */
	TodayRecord findRecentReport(String date,Integer type);

	/**
	 *   方法名：findOperateRecord   
	 *   描述：     查询用户的运营报表                     
	 *   参数：    @param startTime 开始时间
	 *   参数：    @param endTime 结束时间
	 *   参数：    @param name 用户名称
	 *   参数：    @param type 查询的时间类型 1 今天或这个月  2 历史 3 今天之前
	 *   参数：    @return 
	 * @return: TodayRecord
	 */
	TodayRecord findOperateRecord(String startTime, String endTime, String name,Integer type);

	/**
	 *   方法名：censusTodayRecord   
	 *   描述：     统计用户和平台每天的总计                     
	 *   参数：    @return 
	 * @return: int
	 */
	int censusTodayRecord();
	
	/**
	 *   方法名：findByTimeUserRechargeTotal   
	 *   描述：      查询用户 今日和本月的充值金额                    
	 *   参数：    @param findFormatDate 查询时间
	 *   参数：    @param last12Months 查询月份
	 *   参数：    @param id 用户id
	 *   参数：    @return 
	 * @return: TodayRecord
	 */
	TodayRecord findByTimeUserRechargeTotal(String findFormatDate, String last12Months, Integer id);
	
	/**
	 *   方法名：findJuniorStatistics   
	 *   描述：    查询代理下级的全局报表                      
	 *   参数：    @param startTime 开始时间
	 *   参数：    @param endTime 结束时间
	 *   参数：    @param name 用户名称
	 *   参数：    @param type 查询的时间类型 1 今天  2 历史 3 今天之前
	 *   参数：    @param model 查询的用户类型 1 单用户  2 多用户
	 *   参数：    @return 
	 * @return: TodayRecord
	 */
	TodayRecord findJuniorStatistics(String startTime, String endTime, String userName, Integer type, Integer model);
	
	
}
