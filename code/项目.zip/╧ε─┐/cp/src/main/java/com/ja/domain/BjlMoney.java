package com.ja.domain;

import java.io.Serializable;

public class BjlMoney implements Serializable{
     
	/**
	 * 
	 */
	private static final long serialVersionUID = -8775414917693842L;

	private Integer id;// 百家乐中奖金额表

	private String table_num; // 下注桌号

	private String period; //下注期号

	private Double acount;// 下注金额

	private Double lotter_money; // 中奖金额

	private Integer user_id; // 用户id

	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getTable_num() {
		return table_num;
	}

	public void setTable_num(String table_num) {
		this.table_num = table_num;
	}

	public String getPeriod() {
		return period;
	}

	public void setPeriod(String period) {
		this.period = period;
	}

	public Double getAcount() {
		return acount;
	}

	public void setAcount(Double acount) {
		this.acount = acount;
	}

	public Double getLotter_money() {
		return lotter_money;
	}

	public void setLotter_money(Double lotter_money) {
		this.lotter_money = lotter_money;
	}

	public Integer getUser_id() {
		return user_id;
	}

	public void setUser_id(Integer user_id) {
		this.user_id = user_id;
	}

	public BjlMoney() {
		super();
	}

	@Override
	public String toString() {
		return "BjlMoney [id=" + id + ", table_num=" + table_num + ", period=" + period + ", acount=" + acount
				+ ", lotter_money=" + lotter_money + ", user_id=" + user_id + "]";
	}
}
