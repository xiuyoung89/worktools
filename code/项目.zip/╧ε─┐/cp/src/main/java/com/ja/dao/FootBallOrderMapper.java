package com.ja.dao;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.ja.domain.FootBallOrder;

public interface FootBallOrderMapper {
	
	/**
	 * @param footBallOrder 订单信息
	 * @return 添加订单
	 */
	int addFootBallOrder(@Param("m")FootBallOrder matchRebate);
	
	/**
	 * @param footBallOrder 订单信息
	 * @return 修改订单
	 */
	int updateFootBallOrder(@Param("m")FootBallOrder matchRebate);
	
	/**
	 * @return 普通订单信息以及开奖信息
	 */
	List<FootBallOrder> getCheckOrderInfo();
	
	/**
	 * @param id 用户id
	 * @return
	 */
	List<FootBallOrder> findOneAllOrder(Integer id);
	
	/**
	 * @param id 订单id
	 * @return 根据id查询 订单详情
	 */
	FootBallOrder findOrderInfo(Integer id);
	
	/**
	 * @return 综合过关订单以及开奖信息  
	 */
	List<FootBallOrder> getCheckOrderSeries();
	
	/**
	 * 综合过关订单
	 * @param order_num 订单号
	 * @return List集合
	 */
	List<FootBallOrder> getCheckOrderSeriesInfo(String order_num);
	
	/**
	 * 修改综合过关的子订单
	 * @param order 订单信息
	 * @return int 操作行数
	 */
	int updateFootBallSeries(@Param("o") FootBallOrder order);
	
	/**
	 * 添加综合过关子订单
	 * @param fo 订单信息
	 * @return 操作行数
	 */
	int addFootBallSeriesInfo(@Param("o")FootBallOrder fo);
	
	/**
	 * 根据id查询子订单信息
	 * @param statu
	 * @return 子订单信息
	 */
	FootBallOrder getLastMoney(Integer sort);


}