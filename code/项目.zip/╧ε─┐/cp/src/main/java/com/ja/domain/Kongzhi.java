package com.ja.domain;

import java.io.Serializable;

public class Kongzhi implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -7575582456132862494L;

	private Integer id;//玩法下注个数
	
	private String name; //彩种中文名
	
	private String cname;//彩种英文名
	
	private String cplay; //玩法
	
	private String  cplays;//玩法英文名
	
	private Integer kongzhisl;//下注控制数量
	
	private String createTime; //操作时间
	
	private String updateName;//操作人
    
    public static long getSerialversionuid() {
		return serialVersionUID;
	}
	
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getCplay() {
		return cplay;
	}

	public void setCplay(String cplay) {
		this.cplay = cplay;
	}

	public String getCname() {
		return cname;
	}

	public void setCname(String cname) {
		this.cname = cname;
	}

	public Integer getKongzhisl() {
		return kongzhisl;
	}

	public void setKongzhisl(Integer kongzhisl) {
		this.kongzhisl = kongzhisl;
	}

	public String getCplays() {
		return cplays;
	}

	public void setCplays(String cplays) {
		this.cplays = cplays;
	}

	public String getCreateTime() {
		return createTime;
	}

	public void setCreateTime(String createTime) {
		this.createTime = createTime;
	}

	public String getUpdateName() {
		return updateName;
	}

	public void setUpdateName(String updateName) {
		this.updateName = updateName;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	@Override
	public String toString() {
		return "Kongzhi [id=" + id + ", name=" + name + ", cname=" + cname + ", cplay=" + cplay + ", cplays=" + cplays
				+ ", kongzhisl=" + kongzhisl + ", createTime=" + createTime + ", updateName=" + updateName + "]";
	}

	public Kongzhi() {
		super();
	}

}
