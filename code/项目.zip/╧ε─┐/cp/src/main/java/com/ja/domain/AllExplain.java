package com.ja.domain;

import java.io.Serializable;

public class AllExplain implements Serializable{
    /**
	 * 
	 */
	private static final long serialVersionUID = 4609550548355471420L;

	private Integer id; //平台帮助中心

    private String menu;//大类说明
    
    private String doubt;//要说明的问题
    
    private String content;//说明的内容
    
    private String menu_id;//菜单id
    
    private Integer type;// 1 菜单  2帮助说明  3.日常说明
    
    private String created_time; //操作时间

	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getMenu() {
		return menu;
	}

	public void setMenu(String menu) {
		this.menu = menu;
	}

	public String getDoubt() {
		return doubt;
	}

	public void setDoubt(String doubt) {
		this.doubt = doubt;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public String getMenu_id() {
		return menu_id;
	}

	public void setMenu_id(String menu_id) {
		this.menu_id = menu_id;
	}

	public Integer getType() {
		return type;
	}

	public void setType(Integer type) {
		this.type = type;
	}

	public String getCreated_time() {
		return created_time;
	}

	public void setCreated_time(String created_time) {
		this.created_time = created_time;
	}

	@Override
	public String toString() {
		return "AllExplain [id=" + id + ", menu=" + menu + ", doubt=" + doubt + ", content=" + content + ", menu_id="
				+ menu_id + ", type=" + type + ", created_time=" + created_time + "]";
	}
    
}