package com.ja.check.datas;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URL;
import java.net.URLConnection;
import java.security.cert.X509Certificate;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Scanner;

import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;

import org.jsoup.Connection.Response;
import org.jsoup.Jsoup;
import org.springframework.stereotype.Component;
import org.springframework.web.context.ContextLoader;

import com.ja.check.action.CheckOrder;
import com.ja.check.data.CpData;
import com.ja.check.data.SslUtils;
import com.ja.domain.Data;
import com.ja.domain.Product;
import com.ja.sevice.IDataService;
import com.ja.util.WebSocketJson;
@Component
public class Publicmethods {
	
	private IDataService dataService = (IDataService) ContextLoader.getCurrentWebApplicationContext()
			.getBean("dataService");
	/**
	 * 查询最新的一期,并赋值
	 * @param nowTime:查询当前时间的期号
	 * @return
	 */
	public int findCurrDatas(String nowTime){
		return 1;
	}

	/**
	 * 安全证书
	 */
	public static void trustAllHosts() {
	    TrustManager[] trustAllCerts = new TrustManager[] { new X509TrustManager() {  
	        public java.security.cert.X509Certificate[] getAcceptedIssuers() {  
	            return new java.security.cert.X509Certificate[] {};  
	        }  
	        public void checkClientTrusted(X509Certificate[] chain, String authType)  {  
	        }  
	        public void checkServerTrusted(X509Certificate[] chain, String authType) {  
	        }  
	    } };  
	    try {  
	        SSLContext sc = SSLContext.getInstance("TLS");  
	        sc.init(null, trustAllCerts, new java.security.SecureRandom());  
	        HttpsURLConnection.setDefaultSSLSocketFactory(sc.getSocketFactory());  
	    } catch (Exception e) {  
	        e.printStackTrace();  
	    }  
	} 
	
	/**
	 * 获取数据
	 * @param str：连接
	 * @param bm：编码
	 * @param name彩种名称
	 * @return
	 */
	public String Data(String str, String bm, String name) {
		Scanner sc = null;
		try {
//			long start=System.currentTimeMillis(); //获取开始时间
			StringBuffer sb = new StringBuffer();
			Publicmethods.trustAllHosts();
			URL url = new URL(str);
			URLConnection conn = url.openConnection();
			conn.setConnectTimeout(30000);
			conn.setReadTimeout(30000);
			InputStream is = conn.getInputStream();
			InputStreamReader isr =new InputStreamReader(is,bm);
			BufferedReader br = new BufferedReader(isr);
			sc = new Scanner(br);
			while (sc.hasNextLine()) {
				sb.append(sc.nextLine())/*.append("\r\n")*/;
			}
//			long end=System.currentTimeMillis(); //获取结束时间
//			//System.out.println("程序运行时间： "+(end-start)+"ms");
			return sb.toString();
		} catch (IOException e) {
//			//System.out.println("获取数据报错了:"+ str+ name + e);
		} finally {
			if(sc != null) {
				sc.close();
			}
		}
		return null;
	}
	
	/**
	 * 建立远程连接
	 * @param url
	 * @param timeoutMillis
	 * @return
	 */
	public  String getJsonStrUseAgent(String url, int timeoutMillis) {
		try {
			SslUtils.ignoreSsl();
			Response r = Jsoup.connect(url).timeout(timeoutMillis).userAgent(
					"Mozilla/5.0(Macintosh;IntelMacOSX10_7_0)AppleWebKit/535.11(KHTML,likeGecko)Chrome/17.0.963.56Safari/535.11")
					.cookie("auth", "token").ignoreContentType(true).execute();
			return r.body();
		} catch (Exception e) {
			////System.out.println("["+DateUtil.getCurrTime()+"] url="+url+"--Exception--"+e.getMessage());
			////e.printStackTrace();
			//logger.info("老赵爬数据报了一个异常----------------1"+url);
		}catch (Error e) {
			////System.out.println("["+DateUtil.getCurrTime()+"] url="+url+"--Error--"+e.getMessage());
			//e.printStackTrace();
			//logger.info("老赵爬数据报了一个异常----------------2"+url);
		}
		return null;
	}
	
	/**
	 * 执行更新操作语句
	 * @param period：期号
	 * @param lotterNumber：开奖号
	 * @param lotterTime:爬到的时间
	 * @return：返回值
	 */
	public int update(String cname,String period,String lotterNumber,String lotterTime,String acquiredWebsite) {
		if(lotterNumber == null || "".equals(lotterNumber) || cname == null || period == null || lotterTime == null) {
			System.out.println("有为空的参数"+lotterNumber+"---------"+cname+"-----------"+period+"---------------"+lotterTime);
			return 0;
		}
		int i = dataService.update(cname.trim(), period.trim(), lotterNumber.trim(), lotterTime);
		if(i == 1) {
			CheckOrder c = new CheckOrder();
			Data d = new Data();
			d.setCname(cname);
			d.setPeriod(period);
			d.setLotternumber(lotterNumber);
			c.checkLotters(d);
			//System.err.println("----更新了一条数据"+period+"----------------"+lotterNumber+"---------------"+cname+"----------------------"+acquiredWebsite);
		}
		return i;
	}
	/**
	 * 根据彩种名称和期号查询当期开奖信息并拿到下期开奖期号
	 * @param cName:彩种名称
	 * @param period：期号
	 * @return
	 */
	public Data querynextIssueNumber(String cName,String period) {
		return dataService.querynextIssueNumber(cName, period);
	}
	/**
	 * 根据彩种名称和时间查询第一次开奖时间
	 * @param cname
	 * @param time
	 * @return
	 */
	public Product selectDateTime(String cname,String time){
		return dataService.selectDateTime(cname, time);
	}
	/**
	 * 根据彩种名称和id查询下期开奖时间
	 * @param cname
	 * @param id
	 * @return
	 */
	public Product dateTime(String cname,int id) {
		return dataService.dateTime(cname, id);
	}
	/**
	 * 根据传入的期号和彩种名称返回当期的整条数据
	 * @param cname 彩种名称
	 * @param period 需要查询的期号
	 * @return 返回当前传入期号的整个对象  如果有数据则返回一个Data 如果没有则返回null
	 */
	public Data pueryCurrentPeriod(String cname,String period) {
		return dataService.pueryCurrentPeriod(cname, period);
	}
	/**
	 * 查询当前彩种全部没有开出来的数据
	 * @param cName
	 * @return
	 */
	public List<Data> queryData(String cName){
		return dataService.queryData(cName);
	}
	/**
	 * 当对方调用这个方法的时候，证明对方已经插入异常数据，启动一个线程去获取对方插入的异常数据
	 * @param data：对方插入异常数据的相关信息
	 */
	public static void stopTheTask(Data data) {
		//启动一个线程获取对方没有爬到的数据
		GetAbnormalData gad = new GetAbnormalData();
		gad.abnormalData(data);
		//System.err.println("老赵插入了一条没有开出来的数据："+data.toString());
		WebSocketJson w = new WebSocketJson(5,"1");
		w.sendAllHt();
	}
	/**查询到数据库里面的异常数据*/
	public List<Data> databaseExceptionData(){
		return dataService.databaseExceptionData();
	}
	/**
	 * 查询每个彩种的最后一条数据
	 * @param cName 彩种名称
	 * @return
	 */
	public Data theLastItem(String cName) {
		return dataService.theLastItem(cName);
	}
	/**
	 * 根据当前期号查询上期期号 如果查询到返回Data对象 如果没有查询到则返回null
	 * @param cName  彩种名称
	 * @param period   当期期号
	 * @return  如果查询到就返回Data对象 如果没有查询到则返回null
	 */
	public Data previousIssue(String cName,String period) {
		return dataService.previousIssue(cName, period);
	}
	/**
	 * 查询数据库里面这个彩种当期最后的一期数据
	 * @param cName 彩种名称
	 * @return 查询到则返回Data对象数据  如果没有查询到则返回null
	 */
	public Data dataLast(String cName){
		return dataService.dataLast(cName);
	}
	
	/**
	 * 启动爬数据线程
	 */
	public  void startUp(){
		TimedTask tt = new TimedTask();
		tt.thread();
		//获取数据库里面的异常数据信息
		GetAbnormalData.abnormalDataInDatabase();
	}
	
	
 	public String processingData(Data data) {
 		Publicmethods p = new Publicmethods();
		if("".equals(data.getLotternumber()) || data.getLotternumber() == null) {
			return null;
		}
		//爬到数据并且那边没有爬到数据，执行更新操作
		int num = p.update(data.getCname(),data.getPeriod(), data.getLotternumber(), data.getLottertime(),"获取到数据");
		if(num != 1) {
			return null;
		}
		//用的是已经结束的下一期
		CpData.isShotFlags.put(data.getCname(), data.getNextperiod());//更新Map集合
		return data.getNextperiod();
 	}
	/**
	 * 处理异常数据并掉开奖接口
	 * @param data：数据对象
	 */
	public void updataData(Data data) {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		new Publicmethods().update(data.getCname(),data.getPeriod(),data.getLotternumber(),sdf.format(new Date()),"获取到的异常数据");
	}
	/**
	 * 测试的main方法
	 * @param args
	 * @throws ParseException
	 */
	public static void main(String[] args){}
}
