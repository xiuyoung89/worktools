package com.ja.domain;

import java.io.Serializable;

public class YunyingJl implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 510488394926342473L;

	private String id; // 运营记录

	private Double touzhu; // 当天投注

	private Double paijiang;// 当天派奖

	private Double fandian;// 当天返点

	private Double fanshui;// 当天反水

	private Double kuiying;// 当天亏盈

	private Double chongzhi;// 当天充值

	private Double tikuan;// 当天提款

	private String createTime;// 修改时间

	private String month; // 月份

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public Double getTouzhu() {
		return touzhu;
	}

	public void setTouzhu(Double touzhu) {
		this.touzhu = touzhu;
	}

	public Double getPaijiang() {
		return paijiang;
	}

	public void setPaijiang(Double paijiang) {
		this.paijiang = paijiang;
	}

	public Double getFandian() {
		return fandian;
	}

	public void setFandian(Double fandian) {
		this.fandian = fandian;
	}

	public Double getFanshui() {
		return fanshui;
	}

	public void setFanshui(Double fanshui) {
		this.fanshui = fanshui;
	}

	public Double getKuiying() {
		return kuiying;
	}

	public void setKuiying(Double kuiying) {
		this.kuiying = kuiying;
	}

	public Double getChongzhi() {
		return chongzhi;
	}

	public void setChongzhi(Double chongzhi) {
		this.chongzhi = chongzhi;
	}

	public Double getTikuan() {
		return tikuan;
	}

	public void setTikuan(Double tikuan) {
		this.tikuan = tikuan;
	}

	public String getCreateTime() {
		return createTime;
	}

	public void setCreateTime(String createTime) {
		this.createTime = createTime;
	}

	public String getMonth() {
		return month;
	}

	public void setMonth(String month) {
		this.month = month;
	}

	@Override
	public String toString() {
		return "YunyingJl [id=" + id + ", touzhu=" + touzhu + ", paijiang=" + paijiang + ", fandian=" + fandian
				+ ", fanshui=" + fanshui + ", kuiying=" + kuiying + ", chongzhi=" + chongzhi + ", tikuan=" + tikuan
				+ ", createTime=" + createTime + ", month=" + month + "]";
	}
}
