package com.ja.sevice.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ja.dao.GendanMapper;
import com.ja.domain.Data;
import com.ja.domain.Gendan;
import com.ja.domain.JointVo;
import com.ja.sevice.GendanService;

@Service
/**
 * @author GL 跟单系统-
 * @DATE 2018年1月15日 18:03:40
 */
public class GendanServiceImpl implements GendanService {

	@Autowired
	private GendanMapper gendanMapper;

	/**添加跟单跟单订单*/
	@Override
	public int addGendan(Gendan g) {
		return gendanMapper.addGendan(g);
	}

	/**判断测试单*/
	@Override
	public int getTestState(Integer id,String times) {
		return gendanMapper.getTestState(id,times);
	}

	/**查询可以购买的所有跟单订单号*/
	@Override
	public List<String> getFindGendan() {
		return gendanMapper.getFindGendan();
	}

	/**查询跟单订单*/
	@Override
	public List<JointVo> getAllGendan() {
		return gendanMapper.getAllGendan();
	}

	/**查询发起和参与的订单号*/
	@Override
	public List<String> getOrderNum(int i) {
		return gendanMapper.getOrderNum(i);
	}
	
	/**查询自己发起的跟单*/
	@Override
	public List<JointVo> getFQGendan(Integer id) {
		return gendanMapper.getFQGendan(id);
	}

	/**查询自己参与的跟单*/
	@Override
	public List<JointVo> getCYGendan(Integer id) {
		return gendanMapper.getCYGendan(id);
	}

	// 查询最新一条的id
	@Override
	public Gendan getByOrderId(Integer id) {
		return gendanMapper.getByOrderId(id);
	}

	// 插入胜率
	@Override
	public int updateShenglv(Gendan g) {
		return gendanMapper.updateShenglv(g);
	}

	/**查看某一条跟单的信息*/
	@Override
	public List<JointVo> getOneData(Integer id) {
		return gendanMapper.getOneData(id);
	}

	/**统计购买测试单*/
	@Override
	public int getShopGendan(Integer id) {
		return gendanMapper.getShopGendan(id);
	}

	/**某个彩种某期退钱*/
	@Override
	public List<Gendan> getAllUser(Data data) {
		return gendanMapper.getAllUser(data);
	}

	/**跟单退钱状态修改*/
	@Override
	public int chedan(Gendan gendan) {
		return gendanMapper.chedan(gendan);
	}

	/**查看已经失效的订单*/
	@Override
	public List<JointVo> gdInvalid() {
		return gendanMapper.gdInvalid();
	}

	/**根据条件查询排名*/
	@Override
	public List<JointVo> getIncomdeGendan(String time) {
		return gendanMapper.getIncomdeGendan(time);
	}

	/**查询每周排名*/
	@Override
	public List<JointVo> getIncomdeWeek(String time) {
		return gendanMapper.getIncomdeWeek(time);
	}

	/**查询某一条跟单*/
	@Override
	public Gendan findGendan(Integer id) {
		return gendanMapper.findGendan(id);
	}


	/**修改下注人数*/
	@Override
	public int updateCounts(Integer gid, int a) {
		return gendanMapper.updateCounts(gid, a);
	}


}