package com.ja.controller;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpSession;
import javax.websocket.Session;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.util.DigestUtils;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.ja.domain.AdminUser;
import com.ja.domain.KeFuAutomatic;
import com.ja.domain.KeFuChat;
import com.ja.domain.KeFuQuick;
import com.ja.domain.QqKeFu;
import com.ja.sevice.BackManagerService;
import com.ja.sevice.IUserService;
import com.ja.sevice.KeFuService;
import com.ja.sevice.OperationlogService;
import com.ja.sevice.QqKeFuService;
import com.ja.util.JsonResult;

/**
 * 项目名称：cp   
 * 类名称：Ht_KFGLController.java   
 * 类描述：   
 * 创建人：   GL
 * 创建时间：2019年2月22日 下午1:48:50   
 * @version v1.0.0
 */

@Controller
@RequestMapping("/kf")
public class Ht_KFGLController {

	@Autowired
	private KeFuService keFuService;

	@Autowired
	private IUserService userService;
	
	@Autowired
	private BackManagerService managerService;

	@Autowired
	private QqKeFuService qqKeFuService;
	
	@Autowired
	private OperationlogService operationlogService;
	
	
	/**
	 * 
	 * ----TODO：在线客服管理
	 * 
	 */
	
	/**
	 * 方法名：onlineServicePage 
	 * 描述：   在线客服管理页面                   
	 * 参数：    @return 
	 * @return: ModelAndView
	 */
	@RequestMapping("/onlineServicePage")
	public String onlineServicePage() {
		return "htgl/kefu";
	}

	/**
	 * 方法名：findAllKeFuUser 
	 * 描述：    查询所有在线客服                 
	 * 参数：    @return 
	 * @return: JsonResult
	 */
	@RequestMapping("/findAllKeFuUser")
	@ResponseBody
	public JsonResult findAllKeFuUser() {
		return new JsonResult("success", keFuService.findAllKeFuUser());
	}
	
	/**
	 * 方法名：saveKeFuUser 
	 * 描述：    添加在线客服                  
	 * 参数：    @param admin
	 * 参数：    @return 
	 * @return: JsonResult
	 */
	@RequestMapping("/saveKeFuUser")
	@ResponseBody
	public JsonResult saveKeFuUser(HttpSession session,AdminUser admin) {
		AdminUser admins = (AdminUser) session.getAttribute("admin1");
		AdminUser user = managerService.findByAdminUserInfo(admin.getName());
		if("".equals(admin.getPass())) {
			return new JsonResult("0", "请填写密码!");
		}
		if(user!=null){
			return new JsonResult("0", "该账号已存在!");
		}
		admin.setPass(DigestUtils.md5DigestAsHex(DigestUtils.md5DigestAsHex(admin.getPass().getBytes()).getBytes()));
		String type = "";
		if(admin.getAdmin_type()==1) {
			type = "充值提现";
		}else if(admin.getAdmin_type()==2) {
			type = "游戏优惠";
		}else {
			type = "修改信息";
		}
		String remarks = "创建了一个类型为："+type+",账号名为："+admin.getName()+"的在线客服!";
		operationlogService.addOperationlog(admins, remarks, "在线客服管理");
		return new JsonResult("success", keFuService.saveKeFuUser(admin));
	}

	/**
	 * 方法名：updateKeFuUser 
	 * 描述：    修改在线客服的信息                  
	 * 参数：    @param admin 修改的信息
	 * 参数：    @return 
	 * @return: JsonResult
	 */
	@RequestMapping("/updateKeFuUser")
	@ResponseBody
	public JsonResult updateKeFuUser(HttpSession session,AdminUser admin) {
		AdminUser admins = (AdminUser) session.getAttribute("admin1");
		String type = "";
		String state = "禁用了";
		String remarks = "";
		if(null!=admin.getState()) {
			if(admin.getState()==1) {
				state = "启用了";
			}
			remarks = state+"id为："+admin.getId()+"的在线客服!";
		}else {
			if(admin.getAdmin_type()==1) {
				type = "充值提现";
			}else if(admin.getAdmin_type()==2) {
				type = "游戏优惠";
			}else {
				type = "修改信息";
			}
			remarks = "修改了类型为："+type+",昵称为："+admin.getNick_name()+"的在线客服信息!";
		}
		operationlogService.addOperationlog(admins, remarks, "在线客服管理");
		return new JsonResult("success", keFuService.updateKeFuUser(admin));
	}

	/**
	 * 方法名：deleteKeFuUser 
	 * 描述：    删除在线客服                  
	 * 参数：    @param id 删除的id
	 * 参数：    @return 
	 * @return: JsonResult
	 */
	@RequestMapping("/deleteKeFuUser")
	@ResponseBody
	public JsonResult deleteKeFuUser(HttpSession session,Integer id) {
		AdminUser admins = (AdminUser) session.getAttribute("admin1");
		String remarks = "删除了客服id为："+id+"的在线客服信息!";
		operationlogService.addOperationlog(admins, remarks, "在线客服管理");
		return new JsonResult("success", keFuService.deleteKeFuUser(id));
	}

	
	/**
	 * 
	 * ----TODO：QQ客服管理 
	 * 
	 */
	
	/**
	 * 方法名：qqCustomerServicePage 
	 * 描述：     qq客服管理页面                 
	 * 参数：    @return 
	 * @return: String
	 */
	@RequestMapping("/qqCustomerServicePage")
	public String qqCustomerServicePage() {
		return "htgl/qqkefu";
	}
	
	/**
	 * 方法名：findQQCustomerService 
	 * 描述：     查询所有的QQ客服                 
	 * 参数：    @return 
	 * @return: JsonResult
	 */
	@ResponseBody
	@RequestMapping("/findQQCustomerService")
	public JsonResult findQQCustomerService() {
		return new JsonResult("success", qqKeFuService.getAllQqKeFu());
	}

	/**
	 * 方法名：addQQCustomerService 
	 * 描述：     添加QQ客服                 
	 * 参数：    @param qq 客服信息
	 * 参数：    @return 
	 * @return: JsonResult
	 */
	@ResponseBody
	@RequestMapping("/addQQCustomerService")
	public JsonResult addQQCustomerService(HttpSession session,QqKeFu qq) {
		AdminUser admins = (AdminUser) session.getAttribute("admin1");
		if("".equals(qq.getName())||"".equals(qq.getNumber())||"".equals(qq.getNote())) {
			return new JsonResult("-1", "请填写完整信息!");
		}
		String remarks = "添加了一个姓名为："+qq.getName()+",QQ号为："+qq.getNumber()+"的QQ客服!";
		operationlogService.addOperationlog(admins, remarks, "QQ客服管理 ");
		return new JsonResult("success", qqKeFuService.addQqKeFuInfo(qq));
	}

	/**
	 * 方法名：updateQQCustomerService 
	 * 描述：    修改QQ客服信息                  
	 * 参数：    @param qq 修改信息
	 * 参数：    @return 
	 * @return: JsonResult
	 */
	@ResponseBody
	@RequestMapping("/updateQQCustomerService")
	public JsonResult updateQQCustomerService(HttpSession session,QqKeFu qq) {
		AdminUser admins = (AdminUser) session.getAttribute("admin1");
		if("".equals(qq.getName())||"".equals(qq.getNumber())||"".equals(qq.getNote())) {
			return new JsonResult("-1", "请填写完整信息!");
		}
		String remarks = "修改了姓名为："+qq.getName()+"的QQ客服信息!";
		operationlogService.addOperationlog(admins, remarks, "QQ客服管理 ");
		return new JsonResult("success", qqKeFuService.updateQqKeFuInfo(qq));
	}

	/**
	 * 方法名：deleteQQCustomerService 
	 * 描述：    删除QQ客服                  
	 * 参数：    @param id 删除id
	 * 参数：    @return 
	 * @return: JsonResult
	 */
	@ResponseBody
	@RequestMapping("/deleteQQCustomerService")
	public JsonResult deleteQQCustomerService(HttpSession session,Integer id) {
		AdminUser admins = (AdminUser) session.getAttribute("admin1");
		String remarks = "删除了客服id为："+id+"的QQ客服信息!";
		operationlogService.addOperationlog(admins, remarks, "QQ客服管理");
		return new JsonResult("success", qqKeFuService.delQqKeFuInfo(id));
	}

	
	/**
	 * 
	 * ----TODO：客服聊天系统
	 * 
	 */
	
	/**
	 * 方法名：myKeFu 
	 * 描述：     客服聊天系统页面                 
	 * 参数：    @return 
	 * @return: ModelAndView
	 */
	@RequestMapping("/kefu")
	public ModelAndView myKeFu() {
		return new ModelAndView("kefu");
	}
	
	/**
	 * 方法名：findAdminUserInfo 
	 * 描述：    获取当前客服的信息                  
	 * 参数：    @param session
	 * 参数：    @return 
	 * @return: JsonResult
	 */
	@RequestMapping("/findAdminUserInfo")
	@ResponseBody
	public JsonResult findAdminUserInfo(HttpSession session) {
		return new JsonResult("success", (AdminUser) session.getAttribute("admin1"));
	}
	
	/**
	 * 方法名：findByTypeCustomerService 
	 * 描述：    根据类型获取当前在线的所有客服                  
	 * 参数：    @param type 查询类型
	 * 参数：    @param session
	 * 参数：    @return 
	 * @return: JsonResult
	 */
	@ResponseBody
	@RequestMapping("/kefuht")
	public JsonResult findByTypeCustomerService(Integer type,HttpSession session) {
		Map<String, Session> map = ChatController2.map;
		List<AdminUser> kefus = new ArrayList<AdminUser>();
		for (Map.Entry<String, Session> kefu : map.entrySet()) {
				if(kefu.getKey().contains("kefu")) {
				AdminUser admins = keFuService.findByIdAmdinUser(Integer.parseInt(kefu.getKey().replace("kefu", "")));
					if (type == admins.getAdmin_type()) {
						kefus.add(admins);
					}
				}
			}
		return new JsonResult("success", kefus);
	}

	/**
	 * 方法名：findByIdKeFuUser 
	 * 描述：   根据id查询在线客服的信息                   
	 * 参数：    @param id 客服id
	 * 参数：    @return 
	 * @return: JsonResult
	 */
	@RequestMapping("/findByIdAmdinUser")
	@ResponseBody
	public JsonResult findByIdKeFuUser(Integer id) {
		return new JsonResult("success", keFuService.findByIdAmdinUser(id));
	}

	/**
	 * 方法名：findByTypeKeFuUser 
	 * 描述：    根据类型查询在线客服的信息                  
	 * 参数：    @param type 客服类型
	 * 参数：    @return 
	 * @return: JsonResult
	 */
	@RequestMapping("/findByTypeKeFuUser")
	@ResponseBody
	public JsonResult findByTypeKeFuUser(Integer type) {
		return new JsonResult("success", keFuService.findByTypeKeFuUser(type));
	}

	/**
	 * 方法名：getUserById 
	 * 描述：    根据id查询用户信息                  
	 * 参数：    @param id
	 * 参数：    @return 
	 * @return: JsonResult
	 */
	@RequestMapping("/getUserById")
	@ResponseBody
	public JsonResult getUserById(Integer id) {
		return new JsonResult("success", userService.getUserByid(id));
	}

	/**
	 * 方法名：findChatRecord 
	 * 描述：   查询客服咨询聊天记录                   
	 * 参数：    @param kefu_id 客服id
	 * 参数：    @param user_id 用户id
	 * 参数：    @param type 查询时间类型 1 历史  2 今天
	 * 参数：    @return 
	 * @return: JsonResult
	 */
	@RequestMapping("/findChatRecord")
	@ResponseBody
	public JsonResult findChatRecord(Integer kefu_id, Integer user_id,Integer type) {
		SimpleDateFormat ss = new SimpleDateFormat("MM-dd");
		KeFuChat chat = new KeFuChat();
		chat.setId(type);
		chat.setKefu_id(kefu_id);
		chat.setUser_id(user_id);
		chat.setCreated_time(ss.format(new Date()));
		return new JsonResult(String.valueOf(kefu_id), keFuService.findChatRecord(chat));
	}
	
	/**
	 * 方法名：findChatLinkman 
	 * 描述：    查询客服的最近联系人                  
	 * 参数：    @param session
	 * 参数：    @param type 查询时间类型 1 历史  2 今天
	 * 参数：    @return 
	 * @return: JsonResult
	 */
	@RequestMapping("/findChatLinkman")
	@ResponseBody
	public JsonResult findChatLinkman(HttpSession session,Integer type) {
		AdminUser admin = (AdminUser) session.getAttribute("admin1");
		return new JsonResult("success", keFuService.findChatLinkman(admin.getId(),type));
	}
	
	/**
	 * 方法名：updateChatRecord 
	 * 描述：    删除客服最近联系人                  
	 * 参数：    @param chat 删除信息
	 * 参数：    @return 
	 * @return: JsonResult
	 */
	@RequestMapping("/updateChatRecord")
	@ResponseBody
	public JsonResult updateChatRecord(KeFuChat chat) {
		return new JsonResult("success",keFuService.updateChatStatu(chat));
	}
	
	/**
	 * 
	 * ----TODO：自动回复管理
	 * 
	 */

	/**
	 * 方法名：keFuAutomatic 
	 * 描述：    自动回复管理页面                  
	 * 参数：    @return 
	 * @return: String
	 */
	@RequestMapping("/keFuAutomatic")
	public String keFuAutomatic() {
		return "htgl/keFuAutomatic";
	}

	/**
	 * 方法名：findAllKeFuAutomatic 
	 * 描述：     查询所有的自动回复                 
	 * 参数：    @return 
	 * @return: JsonResult
	 */

	@RequestMapping("/findAllKeFuAutomatic")
	@ResponseBody
	public JsonResult findAllKeFuAutomatic() {
		return new JsonResult("success", keFuService.findAllKeFuAutomatic());
	}

	/**
	 * 方法名：addKeFuAutomatic 
	 * 描述：     添加自动回复语句                 
	 * 参数：    @param kefuAutomatic 回复语句
	 * 参数：    @return 
	 * @return: JsonResult
	 */
	@RequestMapping("/addKeFuAutomatic")
	@ResponseBody
	public JsonResult addKeFuAutomatic(HttpSession session,KeFuAutomatic kefuAutomatic) {
		String type = "第一次与客服进行对话";
		if(kefuAutomatic.getType()==0) {
			type = "长时间没有与客服对话";
		}
		String remarks = "新增了一条类型为："+type+"的客服聊天系统自动回复语句！";
		operationlogService.addOperationlog((AdminUser)session.getAttribute("admin1"),remarks,"自动回复管理");
		return new JsonResult("success", keFuService.addKeFuAutomatic(kefuAutomatic));
	}

	/**
	 * 方法名：updateKeFuAutomatic 
	 * 描述：    修改自动回复语句                  
	 * 参数：    @param kefuAutomatic 回复语句
	 * 参数：    @return 
	 * @return: JsonResult
	 */
	@RequestMapping("/updateKeFuAutomatic")
	@ResponseBody
	public JsonResult updateKeFuAutomatic(HttpSession session,KeFuAutomatic kefuAutomatic) {
		String remarks = "";
		if(null!=kefuAutomatic.getState()) {
			String type = "启用了";
			if(kefuAutomatic.getState()==0) {
				type = "禁用了";
			}
			remarks = type+"一条id为："+kefuAutomatic.getId()+"的客服聊天系统自动回复语句！";
		}else {
			
			remarks = "修改了一条id为："+kefuAutomatic.getId()+"的客服聊天系统自动回复语句！";
		}
		operationlogService.addOperationlog((AdminUser)session.getAttribute("admin1"),remarks,"自动回复管理");
		return new JsonResult("success", keFuService.updateKeFuAutomatic(kefuAutomatic));
	}

	/**
	 * 方法名：deleteKeFuAutomatic 
	 * 描述：    删除自动回复                  
	 * 参数：    @param id 删除的id
	 * 参数：    @return 
	 * @return: JsonResult
	 */
	@RequestMapping("/deleteKeFuAutomatic")
	@ResponseBody
	public JsonResult deleteKeFuAutomatic(HttpSession session,Integer id) {
		String remarks = "删除了一条id为："+id+"的客服聊天系统自动回复语句！";
		operationlogService.addOperationlog((AdminUser)session.getAttribute("admin1"),remarks,"自动回复管理");
		return new JsonResult("success", keFuService.deleteKeFuAutomatic(id));
	}

	/**
	 * 
	 * ----TODO：快捷回复管理
	 * 
	 */

	/**
	 * 方法名：kefuQuick 
	 * 描述：    快捷回复管理页面                  
	 * 参数：    @return 
	 * @return: String
	 */
	@RequestMapping("/kefuQuick")
	public String kefuQuick() {
		return "htgl/kefuQuick";
	}

	/**
	 * 方法名：findAllKeFuQuick 
	 * 描述：    查询所有的快捷回复                  
	 * 参数：    @return 
	 * @return: JsonResult
	 */
	@RequestMapping("/findAllKeFuQuick")
	@ResponseBody
	public JsonResult findAllKeFuQuick() {
		return new JsonResult("success", keFuService.findAllKeFuQuick());
	}
	/**
	 * 方法名：findByTypeKeFuQuick 
	 * 描述：     查询客服的快捷回复                 
	 * 参数：    @return 
	 * @return: JsonResult
	 */
	@RequestMapping("/findByTypeKeFuQuick")
	@ResponseBody
	public JsonResult findByTypeKeFuQuick() {
		return new JsonResult("success", keFuService.findTypeKeFuQuick(0));
	}

	/**
	 * 方法名：addKeFuQuick 
	 * 描述：     添加快捷回复语句                 
	 * 参数：    @param keFuQuick 快捷语句
	 * 参数：    @return 
	 * @return: JsonResult
	 */
	@RequestMapping("/addKeFuQuick")
	@ResponseBody
	public JsonResult addKeFuQuick(HttpSession session,KeFuQuick keFuQuick) {
		String type = "平台客服";
		if(keFuQuick.getType()==1) {
			type = "会员用户";
		}
		String remarks = "新增了一跳类型为：" + type + "的客服聊天系统快捷回复语句！";
		operationlogService.addOperationlog((AdminUser)session.getAttribute("admin1"),remarks,"快捷回复管理");
		return new JsonResult("success", keFuService.addKeFuQuick(keFuQuick));
	}

	/**
	 * 方法名：updateKeFuAutomatic 
	 * 描述：    修改快捷回复语句                  
	 * 参数：    @param keFuQuick 快捷语句
	 * 参数：    @return 
	 * @return: JsonResult
	 */
	@RequestMapping("/updateKeFuQuick")
	@ResponseBody
	public JsonResult updateKeFuAutomatic(HttpSession session,KeFuQuick keFuQuick) {
		String remarks = "";
		if(null!=keFuQuick.getState()) {
			String type = "启用了";
			if(keFuQuick.getState()==0) {
				type = "禁用了";
			}
			remarks = type+"一条id为："+keFuQuick.getId()+"的客服聊天系统快捷回复语句！";
		}else {
			
			remarks = "修改了一条id为："+keFuQuick.getId()+"的客服聊天系统快捷回复语句！";
		}
		operationlogService.addOperationlog((AdminUser)session.getAttribute("admin1"),remarks,"快捷回复管理");
		return new JsonResult("success", keFuService.updateKeFuQuick(keFuQuick));
	}

	/**
	 * 方法名：deleteKeFuQuick 
	 * 描述：    删除快捷回复语句                  
	 * 参数：    @param id 删除的id
	 * 参数：    @return 
	 * @return: JsonResult
	 */
	@RequestMapping("/deleteKeFuQuick")
	@ResponseBody
	public JsonResult deleteKeFuQuick(HttpSession session,Integer id) {
		String remarks = "删除了一条id为："+id+"的客服聊天系统快捷回复语句！";
		operationlogService.addOperationlog((AdminUser)session.getAttribute("admin1"),remarks,"快捷回复管理");
		return new JsonResult("success", keFuService.deleteKeFuQuick(id)); 
	}
	

}
