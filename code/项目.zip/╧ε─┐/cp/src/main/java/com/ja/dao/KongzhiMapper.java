package com.ja.dao;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.ja.domain.Kongzhi;

public interface KongzhiMapper {
	
	/**查询下注控制信息*/
	List<Kongzhi> getAllKongzhi();
	
	/**修改控制数量*/
	int updateKongzhiCount(@Param("id")int id,@Param("kongzhisl")int count);
	
	/**获取球数量*/
	List<Kongzhi> getOneKongzhi(String cname);
	
	/**根据id查询控制信息*/
	Kongzhi getOneKongzhiById(Integer id);
	
}
