package com.ja.sevice.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ja.dao.XitongcaiJlMapper;
import com.ja.domain.Data;
import com.ja.domain.XitongcaiJl;
import com.ja.sevice.XitongcaiJlService;

@Service
public class XitongcaiJlServiceImpl implements XitongcaiJlService {

	@Autowired
	private XitongcaiJlMapper xitongcaiJlMapper;

	@Override
	public List<XitongcaiJl> getPageData(Integer startIndex, Integer lineCount,int model) {
		return xitongcaiJlMapper.getPageData(startIndex, lineCount,model);
	}

	@Override
	public List<XitongcaiJl> findSystemJl(Integer startIndex, Integer lineCount, String cname, String period,
			String date1,String date2,int model) {
		return xitongcaiJlMapper.findSystemJl(startIndex, lineCount, cname, period, date1,date2,model);
	}

	@Override
	public Integer getPageDataCounts() {
		return xitongcaiJlMapper.getPageDataCounts();
	}

	@Override
	public Integer findSystemJlCounts(Data data,String date1,String date2) {
		return xitongcaiJlMapper.findSystemJlCounts(data,date1,date2);
	}
}