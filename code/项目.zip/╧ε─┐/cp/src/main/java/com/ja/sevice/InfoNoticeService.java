package com.ja.sevice;

import java.util.List;

import com.ja.domain.IndexPicture;
import com.ja.domain.InfoNotice;
import com.ja.domain.UpDataPage;
import com.ja.domain.UserNotice;

public interface InfoNoticeService {

	/**查询所有的公告信息*/
	List<InfoNotice> getAllInfoNotice();

	/**添加公告信息*/
	int addInfoNotice(InfoNotice info);

	/**修改公告信息*/
	int updInfoNotice(InfoNotice info);

	/**删除公告信息*/
	int delInfoNotice(Integer id);

	/**查询所有的轮播图*/
	List<IndexPicture> getAllIndexPicture();

	/**添加轮播图*/
	int addIndexPicture(IndexPicture info);
	
	/**修改轮播图*/
	int updIndexPicture(IndexPicture info);

	/**删除轮播图*/
	int delIndexPicture(Integer id);

	/**根据id去查询信息*/
	IndexPicture getOneByIdIndexPicture(Integer id);

	/**禁用启用*/
	int updIndexPictureState(Integer id,Integer state);

	/**删除某一张图片*/
	int delIndexPictures(Integer id, String countPicture);

	/**根据id查询*/
	InfoNotice getOneByIdNotice(Integer id);
	
	/**查询最新的一条公告*/
	InfoNotice getOneByNoticeDesc(String type);
	
	/**查询最新的一组轮播*/
	IndexPicture getOneByPictureDesc();

	/**禁用公告*/
	int updInfoNoticeState(Integer state,Integer id);

	/**
	 * 
	   *   方法名：findAllUserNotices   
	   *   描述：    查询所有平台内部用户公告                   TODO   
	   *   参数：    @return 
	 * @return: List<UserNotice>
	 */
	List<UserNotice> findAllUserNotices();

	/**
	 * 根据id查询内部公告
	   *   方法名：findByIdAllUserNotices   
	   *   描述：                       TODO   
	   *   参数：    @param id
	   *   参数：    @return 
	 * @return: UserNotice
	 */
	UserNotice findByIdAllUserNotices(Integer id);
	
	/**
	 * 添加或修改内部公告
	   *   方法名：saveUserNotice   
	   *   描述：                       TODO   
	   *   参数：    @param notice
	   *   参数：    @return 
	 * @return: Integer
	 */
	String saveUserNotice(UserNotice notice);

	/**
	 * 		删除用户内部信息公告
	   *   方法名：deleteUserNotice   
	   *   描述：                       TODO   
	   *   参数：    @param id
	   *   参数：    @return 
	 * @return: String
	 */
	String deleteUserNotice(Integer id);

	/**
	 * 方法名：更新页面
	 * @return
	 */
	List<UpDataPage>   updatePage();
	/**
	 * 方法名：更新页面
	 * @param 页面名字
	 * @return 返回当前页面的相关数据
	 */
	UpDataPage  updatePages(String name);
	/**
	 * 方法名：更新页面 查询
	 * @param status 根据状态查询
	 * @return
	 */
	List<UpDataPage>   updatePagesc(int status);
	/**
	 * 客服提示语
	 * @return
	 */
	int Tips(String tips);
	/**
	 * 查询网址开启还是关闭状态
	 * @return
	 */
	Integer Maintain();
	
	/**
	 * 查询网站维护公告
	 */
	String whNotice();
}
