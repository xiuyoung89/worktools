package com.ja.domain;
/**
 * 返回用户下注记录 用于前端展示
 * @author Administrator
 *
 */
public class Orders {
	 private String huiyuanzh;//会员名称
	
	 private String cname1;//彩种中文名
	 
	 private Double acount;//下注总额

	public String getHuiyuanzh() {
		return huiyuanzh;
	}

	public void setHuiyuanzh(String huiyuanzh) {
		this.huiyuanzh = huiyuanzh;
	}

	public String getCname1() {
		return cname1;
	}

	public void setCname1(String cname1) {
		this.cname1 = cname1;
	}

	public Double getAcount() {
		return acount;
	}

	public void setAcount(Double acount) {
		this.acount = acount;
	}

}
