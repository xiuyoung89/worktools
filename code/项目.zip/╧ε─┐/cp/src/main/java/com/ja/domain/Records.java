package com.ja.domain;

import java.io.Serializable;

public class Records implements Serializable{
/**
	 * 
	 */
	private static final long serialVersionUID = -5272701930689892733L;
//	id
	private Integer id;
//	用户id
	private Integer userid;
//	开奖数据
	private String lotteryrecord;
//	下注金额
	private String amountofnote;
//	中奖金额
	private String winningamount;
//	下注时间
	private String bettingtime;
//	桌号
	private String zh;
//	期号
	private String qihao;
//	玩法
	private String cname;
    
    public static long getSerialversionuid() {
		return serialVersionUID;
	}
    
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public Integer getUserid() {
		return userid;
	}
	public void setUserid(Integer userid) {
		this.userid = userid;
	}
	public String getLotteryrecord() {
		return lotteryrecord;
	}
	public void setLotteryrecord(String lotteryrecord) {
		this.lotteryrecord = lotteryrecord;
	}
	public String getAmountofnote() {
		return amountofnote;
	}
	public void setAmountofnote(String amountofnote) {
		this.amountofnote = amountofnote;
	}
	public String getWinningamount() {
		return winningamount;
	}
	public void setWinningamount(String winningamount) {
		this.winningamount = winningamount;
	}
	public String getBettingtime() {
		return bettingtime;
	}
	public void setBettingtime(String bettingtime) {
		this.bettingtime = bettingtime;
	}
	public String getZh() {
		return zh;
	}
	public void setZh(String zh) {
		this.zh = zh;
	}
	public String getQihao() {
		return qihao;
	}
	public void setQihao(String qihao) {
		this.qihao = qihao;
	}
	public String getCname() {
		return cname;
	}
	public void setCname(String cname) {
		this.cname = cname;
	}
	@Override
	public String toString() {
		return "Records [id=" + id + ", userid=" + userid + ", lotteryrecord=" + lotteryrecord + ", amountofnote="
				+ amountofnote + ", winningamount=" + winningamount + ", bettingtime=" + bettingtime + ", zh=" + zh
				+ ", qihao=" + qihao + ", cname=" + cname + "]";
	}
	
	
}
