package com.ja.domain;

import java.io.Serializable;

public class Operationlog implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 7527408581127525630L;

	private Integer id;

	private String name; // 用户名

	private String operationtype;// 操作类型

	private String remarks; // 备注

	private String operationtime; // 操作时间
	
	private String time; // 操作时间

    
    public static long getSerialversionuid() {
		return serialVersionUID;
	}
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getOperationtype() {
		return operationtype;
	}

	public void setOperationtype(String operationtype) {
		this.operationtype = operationtype;
	}

	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	public String getOperationtime() {
		return operationtime;
	}

	public void setOperationtime(String operationtime) {
		this.operationtime = operationtime;
	}

	public String getTime() {
		return time;
	}

	public void setTime(String time) {
		this.time = time;
	}
	
	@Override
	public String toString() {
		return "Operationlog [id=" + id + ", name=" + name + ", operationtype=" + operationtype + ", remarks=" + remarks
				+ ", operationtime=" + operationtime + ", time=" + time + "]";
	}


}
