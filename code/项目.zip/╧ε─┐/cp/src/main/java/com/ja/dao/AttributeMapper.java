package com.ja.dao;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.ja.domain.Attribute;

public interface AttributeMapper {
	
	/**修改香港六合彩属性*/
	int updateAttributes(@Param("a")Attribute attribute);
	
	/**查看所有的属性*/
	List<Attribute> findAllAttribute();
	
	
	
}



