package com.ja.sevice.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ja.dao.IndexPictureMapper;
import com.ja.dao.InfoNoticeMapper;
import com.ja.domain.IndexPicture;
import com.ja.domain.InfoNotice;
import com.ja.domain.UpDataPage;
import com.ja.domain.UserNotice;
import com.ja.sevice.InfoNoticeService;
import com.ja.util.DateUtil;
/**
 * 
 * @author CY
 * @date 31.Mar.2018
 */
@Service
public class InfoNoticeServiceImpl implements InfoNoticeService {

	@Autowired
	private InfoNoticeMapper infoNoticeMapper;
	
	@Autowired
	private IndexPictureMapper indexPictureMapper;
	
	
	/**查询所有的公告信息*/
	@Override
	public List<InfoNotice> getAllInfoNotice() {
		return infoNoticeMapper.getAllInfoNotice();
	}

	/**添加公告信息*/
	@Override
	public int addInfoNotice(InfoNotice info) {
		return infoNoticeMapper.addInfoNotice(info);
	}

	/**修改公告信息*/
	@Override
	public int updInfoNotice(InfoNotice info) {
		return infoNoticeMapper.updInfoNotice(info);
	}

	/**删除公告信息*/
	@Override
	public int delInfoNotice(Integer id) {
		return infoNoticeMapper.delInfoNotice(id);
	}

	/**查询所有的轮播图*/
	@Override
	public List<IndexPicture> getAllIndexPicture() {
		return indexPictureMapper.getAllIndexPicture();
	}

	/**添加轮播图*/
	@Override
	public int addIndexPicture(IndexPicture info) {
		return indexPictureMapper.addIndexPicture(info);
	}

	/**修改轮播图*/
	@Override
	public int updIndexPicture(IndexPicture info) {
		return indexPictureMapper.updIndexPicture(info);
	}

	/**删除轮播图*/
	@Override
	public int delIndexPicture(Integer id) {
		return indexPictureMapper.delIndexPicture(id);
	}

	/**根据id去查询信息*/
	@Override
	public IndexPicture getOneByIdIndexPicture(Integer id) {
		return indexPictureMapper.getOneByIdIndexPicture(id);
	}

	/**禁用启用*/
	@Override
	public int updIndexPictureState(Integer id,Integer state) {
		return indexPictureMapper.updIndexPictureState(id,state);
	}

	/**删除某一张图片*/
	@Override
	public int delIndexPictures(Integer id, String countPicture) {
		return indexPictureMapper.delIndexPictures(id, countPicture);
	}

	/**根据id查询*/
	@Override
	public InfoNotice getOneByIdNotice(Integer id) {
		return infoNoticeMapper.getOneByIdNotice(id);
	}

	/**查询最新的一条公告*/
	@Override
	public InfoNotice getOneByNoticeDesc(String type) {
		return infoNoticeMapper.getOneByNoticeDesc(type);
	}
	/**查询最新的一组轮播*/
	@Override
	public IndexPicture getOneByPictureDesc() {
		return indexPictureMapper.getOneByPictureDesc();
	}

	/**禁用公告*/
	@Override
	public int updInfoNoticeState(Integer state,Integer id) {
		return infoNoticeMapper.updInfoNoticeState(state,id);
	}

	@Override
	public List<UserNotice> findAllUserNotices() {
		return infoNoticeMapper.findAllUserNotices();
	}

	@Override
	public UserNotice findByIdAllUserNotices(Integer id) {
		return infoNoticeMapper.findByIdAllUserNotices(id);
	}

	@Override
	public String saveUserNotice(UserNotice notice) {
		int line = 0;
		String message = "操作失败,请稍后再进行操作!";
		notice.setCreated_time(DateUtil.getCurrTime());
		if(notice.getId()==-1) {
			line = infoNoticeMapper.saveUserNotice(notice);
		}else {
			line = infoNoticeMapper.updateUserNotice(notice);
		}
		if(line==1) {
			message = "操作成功!";
		}
		return message;
	}

	@Override
	public String deleteUserNotice(Integer id) {
		String message = "操作失败,请稍后再试!";
		int data = infoNoticeMapper.deleteUserNotice(id);
		if(data==1){
			message = "操作成功!";
		}		
		return message;
	}

	@Override
	public List<UpDataPage> updatePage() {
		return infoNoticeMapper.updatePage();
	}

	@Override
	public int Tips(String tips) {
		return infoNoticeMapper.Tips(tips);
	}

	@Override
	public Integer Maintain() {
		return infoNoticeMapper.Maintain();
	}

	@Override
	public String whNotice() {
		return infoNoticeMapper.whNotice();
	}

	@Override
	public UpDataPage updatePages(String name) {
		return infoNoticeMapper.updatePages(name);
	}

	@Override
	public List<UpDataPage> updatePagesc(int status) {
		return infoNoticeMapper.updatePagesc(status);
	}

}
