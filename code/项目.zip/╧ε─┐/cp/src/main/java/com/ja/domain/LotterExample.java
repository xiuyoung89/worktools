package com.ja.domain;

/**
 * @AUTH LBQ
 * @DATE 2017年11月1日 下午3:06:58
 * @DESC
 */
public class LotterExample extends Lotter {
	/**
	 * 
	 */
	private static final long serialVersionUID = 4276535395862010483L;

	private Integer id;

	private String lottertime;

	private String period;

	private String lotternumber;

	private String cname;

	private Integer type; // 系统彩和国彩的区别

	private String gameUniqueld;// 投注状态

	private String gameNamelnChinese;// 投注状态

	private String offcialOpenTimeEpoch;// 投注状态

	private String nextStopOrderTimeEpoch;// 投注状态
	
	private String touzhuzt;
	
	private int xg6hcstate;
	
	private String playResult;
	
	private String nextperiod;// 投注状态
	
    
    public static long getSerialversionuid() {
		return serialVersionUID;
	}
	public int getXg6hcstate() {
		return xg6hcstate;
	}

	public void setXg6hcstate(int xg6hcstate) {
		this.xg6hcstate = xg6hcstate;
	}

	public String getNextperiod() {
		return nextperiod;
	}

	public void setNextperiod(String nextperiod) {
		this.nextperiod = nextperiod;
	}

	public String getTouzhuzt() {
		return touzhuzt;
	}

	public void setTouzhuzt(String touzhuzt) {
		this.touzhuzt = touzhuzt;
	}

	public String getPlayResult() {
		return playResult;
	}

	public void setPlayResult(String playResult) {
		this.playResult = playResult;
	}

	@Override
	public Integer getId() {
		return id;
	}

	@Override
	public void setId(Integer id) {
		this.id = id;
	}

	public String getLottertime() {
		return lottertime;
	}

	public void setLottertime(String lottertime) {
		this.lottertime = lottertime;
	}

	public String getPeriod() {
		return period;
	}

	public void setPeriod(String period) {
		this.period = period;
	}

	public String getLotternumber() {
		return lotternumber;
	}

	public void setLotternumber(String lotternumber) {
		this.lotternumber = lotternumber;
	}

	@Override
	public String getCname() {
		return cname;
	}

	@Override
	public void setCname(String cname) {
		this.cname = cname;
	}

	public Integer getType() {
		return type;
	}

	public void setType(Integer type) {
		this.type = type;
	}

	public String getGameUniqueld() {
		return gameUniqueld;
	}

	public void setGameUniqueld(String gameUniqueld) {
		this.gameUniqueld = gameUniqueld;
	}

	public String getGameNamelnChinese() {
		return gameNamelnChinese;
	}

	public void setGameNamelnChinese(String gameNamelnChinese) {
		this.gameNamelnChinese = gameNamelnChinese;
	}

	public String getOffcialOpenTimeEpoch() {
		return offcialOpenTimeEpoch;
	}

	public void setOffcialOpenTimeEpoch(String offcialOpenTimeEpoch) {
		this.offcialOpenTimeEpoch = offcialOpenTimeEpoch;
	}

	public String getNextStopOrderTimeEpoch() {
		return nextStopOrderTimeEpoch;
	}

	public void setNextStopOrderTimeEpoch(String nextStopOrderTimeEpoch) {
		this.nextStopOrderTimeEpoch = nextStopOrderTimeEpoch;
	}
	@Override
	public String toString() {
		return "LotterExample [id=" + id + ", lottertime=" + lottertime + ", period=" + period + ", lotternumber="
				+ lotternumber + ", cname=" + cname + ", type=" + type + ", gameUniqueld=" + gameUniqueld
				+ ", gameNamelnChinese=" + gameNamelnChinese + ", offcialOpenTimeEpoch=" + offcialOpenTimeEpoch
				+ ", nextStopOrderTimeEpoch=" + nextStopOrderTimeEpoch + ", touzhuzt=" + touzhuzt + ", xg6hcstate="
				+ xg6hcstate + ", playResult=" + playResult + ", nextperiod=" + nextperiod + ", getName()=" + getName()
				+ ", getTimespace()=" + getTimespace() + ", getImg()=" + getImg() + ", getColor()=" + getColor()
				+ ", getClasst()=" + getClasst() + ", getHelpurl()=" + getHelpurl() + ", getState()=" + getState()
				+ ", getStartTime()=" + getStartTime() + ", getZoushitu()=" + getZoushitu() + ", getRebate40()="
				+ getRebate40() + ", getEndTime()=" + getEndTime() + ", getRebate1()=" + getRebate1()
				+ ", getRebate2()=" + getRebate2() + ", getRebate3()=" + getRebate3() + ", getRebate4()=" + getRebate4()
				+ ", getRebate5()=" + getRebate5() + ", getRebate6()=" + getRebate6() + ", getRebate7()=" + getRebate7()
				+ ", getRebate8()=" + getRebate8() + ", getRebate9()=" + getRebate9() + ", getRebate10()="
				+ getRebate10() + ", getRebate11()=" + getRebate11() + ", getRebate12()=" + getRebate12()
				+ ", getRebate13()=" + getRebate13() + ", getRebate14()=" + getRebate14() + ", getRebate15()="
				+ getRebate15() + ", getRebate16()=" + getRebate16() + ", getRebate17()=" + getRebate17()
				+ ", getRebate18()=" + getRebate18() + ", getRebate19()=" + getRebate19() + ", getRebate20()="
				+ getRebate20() + ", getRebate21()=" + getRebate21() + ", getRebate22()=" + getRebate22()
				+ ", getRebate23()=" + getRebate23() + ", getRebate24()=" + getRebate24() + ", getRebate25()="
				+ getRebate25() + ", getRebate26()=" + getRebate26() + ", getRebate27()=" + getRebate27()
				+ ", getRebate28()=" + getRebate28() + ", getRebate29()=" + getRebate29() + ", getRebate30()="
				+ getRebate30() + ", getRebate31()=" + getRebate31() + ", getRebate32()=" + getRebate32()
				+ ", getRebate33()=" + getRebate33() + ", getRebate34()=" + getRebate34() + ", getRebate35()="
				+ getRebate35() + ", getRebate36()=" + getRebate36() + ", getRebate37()=" + getRebate37()
				+ ", getRebate38()=" + getRebate38() + ", getRebate39()=" + getRebate39() + ", getTypes()=" + getTypes()
				+ ", getRename()=" + getRename() + ", getDes()=" + getDes() + ", getWhetherOrNotToCode()="
				+ getWhetherOrNotToCode() + ", toString()=" + super.toString() + ", getClass()=" + getClass()
				+ ", hashCode()=" + hashCode() + "]";
	}

}
