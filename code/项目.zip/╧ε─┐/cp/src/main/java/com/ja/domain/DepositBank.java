package com.ja.domain;

import java.io.Serializable;

public class DepositBank implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = -7032015678814949074L;

	private Integer id;// 收款银行帐号

	private String bankName;// 银行名称

	private String bankAcount;// 收款帐号

	private String acountName;// 收款人姓名

	private String acountBranch;// 收款支行

	private String createTime;// 创建时间

	private String operationName;// 操作人姓名

	private Integer state;// 开关

	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getBankName() {
		return bankName;
	}

	public void setBankName(String bankName) {
		this.bankName = bankName;
	}

	public String getBankAcount() {
		return bankAcount;
	}

	public void setBankAcount(String bankAcount) {
		this.bankAcount = bankAcount;
	}

	public String getAcountName() {
		return acountName;
	}

	public void setAcountName(String acountName) {
		this.acountName = acountName;
	}

	public String getAcountBranch() {
		return acountBranch;
	}

	public void setAcountBranch(String acountBranch) {
		this.acountBranch = acountBranch;
	}

	public String getCreateTime() {
		return createTime;
	}

	public void setCreateTime(String createTime) {
		this.createTime = createTime;
	}

	public String getOperationName() {
		return operationName;
	}

	public void setOperationName(String operationName) {
		this.operationName = operationName;
	}

	public Integer getState() {
		return state;
	}

	public void setState(Integer state) {
		this.state = state;
	}

	@Override
	public String toString() {
		return "DepositBank [id=" + id + ", bankName=" + bankName + ", bankAcount=" + bankAcount + ", acountName="
				+ acountName + ", acountBranch=" + acountBranch + ", createTime=" + createTime + ", operationName="
				+ operationName + ", state=" + state + "]";
	}

	public DepositBank() {
		super();
	}
}