package com.ja.domain;

import java.io.Serializable;

/**
 * 百家乐
 * @author WCH
 *
 */
public class Bjl implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 3953848092100196236L;
	private Integer id;
	
	private String zhuang;//庄家
	
	private String xian;//闲家
	
	private String zhuangdui;//庄对
	
	private String xiandui;//闲对
	
	private String he;//和
	
	private String large;//大
	
	private String small;//小
	
	private String arbitraryPairsx;//任意对子
	
	private String perfectPairx;//完美对子
	
	//、、、、、、、、、、、、、用户下注类型、、、、、、、、、、、、、、、、、、、、、//
	
	
	
	private Double amountOfMoney;//庄家下注金额
	
	private Double cashDownAmount;//闲家下注金额
	
	private Double cashPairDownAmount;//闲对下注金额
	
	private Double zhuangdusBetOnTheAmount;//庄对下注金额
	
	private Double andTheAmountOfTheBet;//和局下注金额
	
	private Double largeBetAmount;//大下注金额
	
	private Double smallBetAmount;//小下注金额
	
	private Double perfectPairAmount;//完美对子下注金额
	
	private Double arbitraryPairAmount;//任意对子下注金额

	private Double totalBet;//下注总额
	
	
	//、、、、、、、、、、、、、、用户下注金额、、、、、、、、、、、、、、、、、、、、、、、//
	
	
	private String zhuang1;//庄家第一张牌
	
	private String zhuang2;//庄家第二张牌
	
	private String dealerCard;//庄家补牌
	
	private Integer frontPointsOfZhuangshi;//庄家补牌前点数
	
	private Integer makerSFinalPoints;//庄家最终点数
	
	private String leisure1;//闲家第一张牌
	
	private String leisure2;//闲家第二张牌
	
	private String leisureCard;//闲家补牌
	
	private Integer frontPointsofIdleReplacementCards;//闲家补牌前点数
	
	private Integer leisureHomePoints;//闲家最终点数

	private Integer size;// '0-小   1-大',
	
	private Integer arbitraryPairs;//任意对子 0-没有任意对子  1有任意对子',
	
	private Integer perfectPair;//'完美对子 0-没有完美对子   1-有完美对子',
	
	private Integer winner;//开奖状态  0-闲家赢 1-庄家赢  2-和局
	
	private Integer idleTime;//闲对 0-没有闲对 1-有闲对
	
	private Integer zhuangPairs;//庄对 0-没有庄对 1-有庄对
	
	//、、、、、、、、、、、、、、开奖结果、、、、、、、、、、、、、、、、、、、、、、、、//
	
	
	
	private String issueNumber;//期号
	
	private Integer tableNumber;//桌号
	
	private String bettingtime;//下注时间
	
	private Integer userid;//用户id
	
	private String name;//用户名
	
	private Double winningAmount;//中奖金额
	
	private Integer userstate;//用户状态，判断是试玩账号还是正规玩家账号
	
	private Integer status;//中奖状态 0-未中奖  1-中奖 2-未开奖
	
	private Integer state;//状态-1开奖-0未开奖  -2-官方开奖异常退款

	
	
	public Double getLargeBetAmount() {
		return largeBetAmount;
	}

	public void setLargeBetAmount(Double largeBetAmount) {
		this.largeBetAmount = largeBetAmount;
	}

	public Double getSmallBetAmount() {
		return smallBetAmount;
	}

	public void setSmallBetAmount(Double smallBetAmount) {
		this.smallBetAmount = smallBetAmount;
	}

	public Double getPerfectPairAmount() {
		return perfectPairAmount;
	}

	public void setPerfectPairAmount(Double perfectPairAmount) {
		this.perfectPairAmount = perfectPairAmount;
	}

	public Double getArbitraryPairAmount() {
		return arbitraryPairAmount;
	}

	public void setArbitraryPairAmount(Double arbitraryPairAmount) {
		this.arbitraryPairAmount = arbitraryPairAmount;
	}
	
	public String getLarge() {
		return large;
	}

	public void setLarge(String large) {
		this.large = large;
	}

	public String getSmall() {
		return small;
	}

	public void setSmall(String small) {
		this.small = small;
	}

	
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}
	public Double getWinningAmount() {
		return winningAmount;
	}

	public void setWinningAmount(Double winningAmount) {
		this.winningAmount = winningAmount;
	}
	public String getZhuang() {
		return zhuang;
	}


	@Override
	public String toString() {
		return "Bjl [id=" + id + ", zhuang=" + zhuang + ", xian=" + xian + ", zhuangdui=" + zhuangdui + ", xiandui="
				+ xiandui + ", he=" + he + ", large=" + large + ", small=" + small + ", arbitraryPairsx="
				+ arbitraryPairsx + ", perfectPairx=" + perfectPairx + ", amountOfMoney=" + amountOfMoney
				+ ", cashDownAmount=" + cashDownAmount + ", cashPairDownAmount=" + cashPairDownAmount
				+ ", zhuangdusBetOnTheAmount=" + zhuangdusBetOnTheAmount + ", andTheAmountOfTheBet="
				+ andTheAmountOfTheBet + ", largeBetAmount=" + largeBetAmount + ", smallBetAmount=" + smallBetAmount
				+ ", perfectPairAmount=" + perfectPairAmount + ", arbitraryPairAmount=" + arbitraryPairAmount
				+ ", totalBet=" + totalBet + ", zhuang1=" + zhuang1 + ", zhuang2=" + zhuang2 + ", dealerCard="
				+ dealerCard + ", frontPointsOfZhuangshi=" + frontPointsOfZhuangshi + ", makerSFinalPoints="
				+ makerSFinalPoints + ", leisure1=" + leisure1 + ", leisure2=" + leisure2 + ", leisureCard="
				+ leisureCard + ", frontPointsofIdleReplacementCards=" + frontPointsofIdleReplacementCards
				+ ", leisureHomePoints=" + leisureHomePoints + ", Size=" + size + ", arbitraryPairs=" + arbitraryPairs
				+ ", perfectPair=" + perfectPair + ", winner=" + winner + ", idleTime=" + idleTime + ", zhuangPairs="
				+ zhuangPairs + ", issueNumber=" + issueNumber + ", tableNumber=" + tableNumber + ", bettingtime="
				+ bettingtime + ", userid=" + userid + ", name=" + name + ", winningAmount=" + winningAmount
				+ ", userstate=" + userstate + ", status=" + status + ", state=" + state + "]";
	}

	public String getArbitraryPairsx() {
		return arbitraryPairsx;
	}

	public void setArbitraryPairsx(String arbitraryPairsx) {
		this.arbitraryPairsx = arbitraryPairsx;
	}

	public String getPerfectPairx() {
		return perfectPairx;
	}

	public void setPerfectPairx(String perfectPairx) {
		this.perfectPairx = perfectPairx;
	}

	public Integer getSize() {
		return size;
	}

	public void setSize(Integer size) {
		this.size = size;
	}

	public Integer getArbitraryPairs() {
		return arbitraryPairs;
	}

	public void setArbitraryPairs(Integer arbitraryPairs) {
		this.arbitraryPairs = arbitraryPairs;
	}

	public Integer getPerfectPair() {
		return perfectPair;
	}

	public void setPerfectPair(Integer perfectPair) {
		this.perfectPair = perfectPair;
	}

	public Integer getWinner() {
		return winner;
	}

	public void setWinner(Integer winner) {
		this.winner = winner;
	}

	public Integer getIdleTime() {
		return idleTime;
	}

	public void setIdleTime(Integer idleTime) {
		this.idleTime = idleTime;
	}

	public Integer getZhuangPairs() {
		return zhuangPairs;
	}

	public void setZhuangPairs(Integer zhuangPairs) {
		this.zhuangPairs = zhuangPairs;
	}

	public void setZhuang(String zhuang) {
		this.zhuang = zhuang;
	}

	public String getXian() {
		return xian;
	}

	public void setXian(String xian) {
		this.xian = xian;
	}

	public String getZhuangdui() {
		return zhuangdui;
	}

	public void setZhuangdui(String zhuangdui) {
		this.zhuangdui = zhuangdui;
	}

	public String getXiandui() {
		return xiandui;
	}

	public void setXiandui(String xiandui) {
		this.xiandui = xiandui;
	}

	public String getHe() {
		return he;
	}

	public void setHe(String he) {
		this.he = he;
	}

	public Double getAmountOfMoney() {
		return amountOfMoney;
	}

	public void setAmountOfMoney(Double amountOfMoney) {
		this.amountOfMoney = amountOfMoney;
	}

	public Double getCashDownAmount() {
		return cashDownAmount;
	}

	public void setCashDownAmount(Double cashDownAmount) {
		this.cashDownAmount = cashDownAmount;
	}

	public Double getCashPairDownAmount() {
		return cashPairDownAmount;
	}

	public void setCashPairDownAmount(Double cashPairDownAmount) {
		this.cashPairDownAmount = cashPairDownAmount;
	}

	public Double getZhuangdusBetOnTheAmount() {
		return zhuangdusBetOnTheAmount;
	}

	public void setZhuangdusBetOnTheAmount(Double zhuangdusBetOnTheAmount) {
		this.zhuangdusBetOnTheAmount = zhuangdusBetOnTheAmount;
	}

	public Double getAndTheAmountOfTheBet() {
		return andTheAmountOfTheBet;
	}

	public void setAndTheAmountOfTheBet(Double andTheAmountOfTheBet) {
		this.andTheAmountOfTheBet = andTheAmountOfTheBet;
	}

	public Double getTotalBet() {
		return totalBet;
	}

	public void setTotalBet(Double totalBet) {
		this.totalBet = totalBet;
	}

	public String getZhuang1() {
		return zhuang1;
	}

	public void setZhuang1(String zhuang1) {
		this.zhuang1 = zhuang1;
	}

	public String getZhuang2() {
		return zhuang2;
	}

	public void setZhuang2(String zhuang2) {
		this.zhuang2 = zhuang2;
	}

	public String getDealerCard() {
		return dealerCard;
	}

	public void setDealerCard(String dealerCard) {
		this.dealerCard = dealerCard;
	}

	public Integer getFrontPointsOfZhuangshi() {
		return frontPointsOfZhuangshi;
	}

	public void setFrontPointsOfZhuangshi(Integer frontPointsOfZhuangshi) {
		this.frontPointsOfZhuangshi = frontPointsOfZhuangshi;
	}

	public Integer getMakerSFinalPoints() {
		return makerSFinalPoints;
	}

	public void setMakerSFinalPoints(Integer makerSFinalPoints) {
		this.makerSFinalPoints = makerSFinalPoints;
	}

	public String getLeisure1() {
		return leisure1;
	}

	public void setLeisure1(String leisure1) {
		this.leisure1 = leisure1;
	}

	public String getLeisure2() {
		return leisure2;
	}

	public void setLeisure2(String leisure2) {
		this.leisure2 = leisure2;
	}

	public String getLeisureCard() {
		return leisureCard;
	}

	public void setLeisureCard(String leisureCard) {
		this.leisureCard = leisureCard;
	}

	public Integer getFrontPointsofIdleReplacementCards() {
		return frontPointsofIdleReplacementCards;
	}

	public void setFrontPointsofIdleReplacementCards(Integer frontPointsofIdleReplacementCards) {
		this.frontPointsofIdleReplacementCards = frontPointsofIdleReplacementCards;
	}

	public Integer getLeisureHomePoints() {
		return leisureHomePoints;
	}

	public void setLeisureHomePoints(Integer leisureHomePoints) {
		this.leisureHomePoints = leisureHomePoints;
	}

	public String getIssueNumber() {
		return issueNumber;
	}

	public void setIssueNumber(String issueNumber) {
		this.issueNumber = issueNumber;
	}

	public Integer getTableNumber() {
		return tableNumber;
	}

	public void setTableNumber(Integer tableNumber) {
		this.tableNumber = tableNumber;
	}

	public String getBettingtime() {
		return bettingtime;
	}

	public void setBettingtime(String bettingtime) {
		this.bettingtime = bettingtime;
	}

	public Integer getUserid() {
		return userid;
	}

	public void setUserid(Integer userid) {
		this.userid = userid;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Integer getUserstate() {
		return userstate;
	}

	public void setUserstate(Integer userstate) {
		this.userstate = userstate;
	}

	public Integer getStatus() {
		return status;
	}

	public void setStatus(Integer status) {
		this.status = status;
	}

	public Integer getState() {
		return state;
	}

	public void setState(Integer state) {
		this.state = state;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	
}
