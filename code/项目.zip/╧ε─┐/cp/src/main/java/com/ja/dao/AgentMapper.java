package com.ja.dao;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.ja.domain.AgentRecord;
import com.ja.domain.AgentTotal;
import com.ja.domain.Agents;
import com.ja.domain.PagingData;
import com.ja.domain.SetupAgent;
import com.ja.domain.TodayRecord;
import com.ja.domain.User;

public interface AgentMapper {
	
	

	
	/**
	 * 
	 * 
	 * 
	 * --------------------------TODO: 代理第1套 后台返点设置
	 * 
	 * 
	 * 
	 */
	
	/**
	  * 方法名：findAgentSetup 
	  * 描述：    查询代理返点设置                  
	  * 参数：    @return 
	 * @return: List<SetupAgent>
	 */
	List<SetupAgent> findAgentSetup(); 
	
	/**
	 * 方法名：findByIdAgentSetup 
	 * 描述：     根据id查询代理返点设置                  
	 * 参数：    @param id
	 * 参数：    @return 
	 * @return: SetupAgent
	 */
	SetupAgent findByIdAgentSetup(Integer id);
	
	/**
	  * 方法名：insertAgentSetup 
	  * 描述：    添加返点设置                  
	  * 参数：    @param setupAgent 返点设置信息
	  * 参数：    @return 
	 * @return: int
	 */
	int insertAgentSetup(SetupAgent setupAgent);
	
	/**
	  * 方法名：updateAgentSetup 
	  * 描述：    修改返点设置                  
	  * 参数：    @param setupAgent 返点设置信息
	  * 参数：    @return 
	 * @return: int
	 */
	int updateAgentSetup(SetupAgent setupAgent);
	
	/**
	  * 方法名：deleteAgentSetup 
	  * 描述：    删除返点设置                  
	  * 参数：    @param id 删除的id
	  * 参数：    @return 
	 * @return: int
	 */
	int deleteAgentSetup(Integer id);

	/**
	 * 方法名：updateDailiRule 
	 * 描述：     修改代理返点和用户返水说明                 
	 * 参数：    @param rule 代理返点说明
	 * 参数：    @param rules 用户返水说明
	 * 参数：    @return 
	 * @return: int
	 */
	int updateDailiRule(@Param("rule") String rule, @Param("rules")String rules);
	
	/**
	 * 
	 * 
	 * 
	 * --------------------------TODO: 后台代理返点记录管理
	 * 
	 * 
	 * 
	 */
	
	/**
	  * 方法名：findAgentRecordCount 
	  * 描述：     查询代理返点总记录数                 
	  * 参数：    @param startDate
	  * 参数：    @param endDate
	  * 参数：    @param userName
	  * 参数：    @param agentName
	  * 参数：    @return 
	 * @return: Integer
	 */
	Integer findAgentRecordCount(String startDate, String endDate, String userName, String agentName);
	
	/**
	  * 方法名：findAgentRecord 
	  * 描述：    查询代理返点记录                  
	  * 参数：    @param startIndex 起始数
	  * 参数：    @param lineCount 行数
	  * 参数：    @param startDate 开始时间
	  * 参数：    @param endDate 结束时间
	  * 参数：    @param userName 下级名称
	  * 参数：    @param agentName 代理名称
	  * 参数：    @return 
	 * @return: List<AgentRecord>
	 */
	List<AgentRecord> findAgentRecord(@Param("startIndex")Integer startIndex, @Param("lineCount")Integer lineCount, @Param("startDate")String startDate,
			@Param("endDate")String endDate, @Param("userName")String userName, @Param("agentName")String agentName);
	
	/**
	 * 
	 * 
	 * 
	 * --------------------------TODO: 后台代理管理
	 * 
	 * 
	 * 
	 */
	
	/**
	  * 方法名：findAllAgentsCounts 
	  * 描述：    查询所有的代理数量                   
	  * 参数：    @return 
	 * @return: Integer
	 */
	Integer findAllAgentsCounts();

	/**
	  * 方法名：findAllAgents 
	  * 描述：    分页查询所有的代理信息                  
	  * 参数：    @param paging
	  * 参数：    @return 
	 * @return: List<User>
	 */
	List<User> findAllAgents(@Param("paging")PagingData paging); 
	
	
	/**
	 * 
	 * 
	 * 
	 * --------------------------TODO: 代理第1套
	 * 
	 * 
	 * 
	 */
	
	/**
	  * 方法名：findAllSuperior 
	  * 描述：    查询用户的所有上级                 
	  * 参数：    @param userid 用户id
	  * 参数：    @return 
	 * @return: List<User>
	 */
	List<User> findAllSuperior(Integer userid);
	
	/**
	  * 方法名：findAllNodes 
	  * 描述：    查询代理的所有下级                  
	  * 参数：    @param parent_id 代理id
	  * 参数：    @return 
	 * @return: Agents
	 */
	Agents findAllNodes(Integer parent_id); 
	
	/**
	  * 方法名：findAllOneAgent 
	  * 描述：    查询所有的一级下级                  
	  * 参数：    @param startIndex 起始记录数
	  * 参数：    @param lineCount 行数
	  * 参数：    @param agent_id 代理id
	  * 参数：    @param model 查询类型
	  * 参数：    @return 
	 * @return: List<User>
	 */
	List<User> findAllOneAgent(@Param("startIndex")Integer startIndex, @Param("lineCount")Integer lineCount,  @Param("agent_id")Integer agent_id,  @Param("model")int model); 
	
	/**
	  * 方法名：findAgentInfo 
	  * 描述：     查询代理下级返点总计的详情                  
	  * 参数：    @param name 下级名称
	  * 参数：    @param agent_id 代理id
	  * 参数：    @return 
	 * @return: AgentTotal
	 */
	AgentTotal findAgentInfo(String name, Integer agent_id);
	
	/**
	  * 方法名：findAgentDetails 
	  * 描述：   查询下级消费详情                       
	  * 参数：    @param paging
	  * 参数：    @return 
	 * @return: List<TodayRecord>
	 */
	List<TodayRecord> findAgentDetails(@Param("paging")PagingData paging);
	
	/**
	  * 方法名：findAgentSumRebate 
	  * 描述：    查询代理的返点总计                  
	  * 参数：    @param user_id 下级id
	  * 参数：    @param agent_id 
	  * 参数：    @return 
	 * @return: Double
	 */
	Double findAgentSumRebate(Integer user_id, int agent_id);
	
	/**
	  * 方法名：findAgentTotal 
	  * 描述：    查询代理下级的所有总计                  
	  * 参数：    @param user_id 下级id
	  * 参数：    @param agent_id 代理id
	  * 参数：    @return 
	 * @return: AgentTotal
	 */
	AgentTotal findAgentTotal(Integer user_id, Integer agent_id);
	
	/**
	  * 方法名：findAgentRebateInfo 
	  * 描述：    查询代理返点总计某个区间                  
	  * 参数：    @param startIndex 起始记录数
	  * 参数：    @param lineCount 行数
	  * 参数：    @param startDate 开始时间
	  * 参数：    @param endDate 结束时间
	  * 参数：    @param agent_id 代理id
	  * 参数：    @param model 查询类型
	  * 参数：    @return 
	 * @return: List<AgentTotal>
	 */
	List<AgentRecord> findAgentRebateInfo(@Param("startIndex")Integer startIndex, @Param("lineCount")Integer lineCount,  @Param("startDate")String startDate,  @Param("endDate")String endDate,  @Param("agent_id")Integer agent_id,  @Param("model")int model);

	/**
	  * 方法名：findAgentRebateSum 
	  * 描述：    查询代理所有下级的返点总额                  
	  * 参数：    @param startDate 开始时间
	  * 参数：    @param endDate 结束时间
	  * 参数：    @param agent_id 代理id
	  * 参数：    @return 
	 * @return: AgentTotal
	 */
	AgentTotal findAgentRebateSum(@Param("startDate")String startDate,  @Param("endDate")String endDate,  @Param("agent_id")Integer agent_id);
	
	/**
	  * 方法名：findSumAgentTotal 
	  * 描述：    查询代理团队各项总计                  
	  * 参数：    @param startDate 开始时间
	  * 参数：    @param endDate 结束时间
	  * 参数：    @param id 代理id
	  * 参数：    @return 
	 * @return: TodayRecord
	 */
	TodayRecord findSumAgentTotal(@Param("startDate")String startDate, @Param("endDate")String endDate,@Param("id") Integer id);

	/**
	  * 方法名：receiveAReturnPoint 
	  * 描述：     查询代理领取返点最低金额                 
	  * 参数：    @return 
	 * @return: Double
	 */
	Double receiveAReturnPoint();
	
	/**
	 *   方法名：findAgentRebateInfoCounts   
	 *   描述：     代理返点记录数量                     
	 *   参数：    @param paging
	 *   参数：    @return 
	 * @return: Integer 
	 */
	Integer findAgentRebateInfoCounts(PagingData paging);
	
	/**
	   *   方法名：findAgentTotalCounts   
	   *   描述：   查询下级返点总计的个数                     
	   *   参数：    @param id 上级id
	   *   参数：    @return 
	 * @return: Integer
	 */
	Integer findAgentTotalCounts(Integer id);
	/**
	 * 查询这个下级的代理
	 * @param paging 分页对象  包含代理id
	 * @return 查询到则返回这个代理的下级  如果没有查询到则返回一个空集合
	 */
	List<User> findAgentTotals(PagingData paging);
	
	/**
	   *   方法名：findAgentDetailsCounts   
	   *   描述：    查询下级详情的个数                      
	   *   参数：    @param user_id
	   *   参数：    @param type
	   *   参数：    @return 
	 * @return: Integer
	 */
	Integer findAgentDetailsCounts(@Param("user_id")Integer user_id, @Param("types")String types);
	
	/**
	  * 方法名：findOpenAgentSetup 
	  * 描述：    查询开启的代理设置                  
	  * 参数：    @param type 返点类型 1是充值 2打码
	  * 参数：    @return 
	 * @return: List<SetupAgent>
	 */
	List<SetupAgent> findOpenAgentSetup(int type);
	
	/**
	  * 方法名：insertAgentRecord 
	  * 描述：     添加代理返点记录                 
	  * 参数：    @param commonAgent 返点记录信息  
	  * 参数：    @return 
	 * @return: int
	 */
	int insertAgentRecord(AgentRecord commonAgent);  
	
	/**
	 * 方法名：insertAgentTotal 
	  * 描述：    添加代理总计                  
	  * 参数：    @param total 总计信息
	  * 参数：    @return 
	 * @return: int
	 */
	int insertAgentTotal(AgentTotal total);
	
	/**
	  * 方法名：updateAgentTotal 
	  * 描述：    修改代理总计                  
	  * 参数：    @param total 总计信息
	  * 参数：    @return 
	 * @return: int
	 */
	int updateAgentTotal(AgentTotal total);
	
	
	/**
	 * 
	 * 
	 * 
	 * --------------------------TODO: 代理第2套
	 * 
	 * 
	 * 
	 */
	
	/**
	  *  方法名：findByIdTimeAgentRebateTotal 
	  * 描述：    查询代理昨日和今日的返点总计                  
	  * 参数：    @param user_id 代理id
	  * 参数：    @param yesterday 昨天的时间
	  * 参数：    @param today 今天的时间
	  * 参数：    @return 
	 * @return: AgentRecord
	 */
	List<AgentRecord> findByIdTimeAgentRebateTotalTwo(@Param("user_id")Integer user_id, @Param("yesterday")String yesterday, 
			@Param("today")String today,@Param("startTime")String stratTime,@Param("endTime")String endTime );
	
	/**
	  *  方法名：findAgentRecordCountTwo 
	  * 描述：    根据区间范围查询返点记录数                  
	  * 参数：    @param startTime 开始时间
	  * 参数：    @param endTime 结束时间
	  * 参数：    @param userName 用户名
	  * 参数：    @param agentName 代理名称
	  * 参数：    @return 
	 * @return: int
	 */
	int findAgentRecordCountTwo(@Param("startTime")String startTime, @Param("endTime")String endTime, @Param("userName")String userName,
			@Param("agentName")String agentName);
	
	/**
	  * 方法名：findAgentRecordTwo 
	  * 描述：    查询代理返点记录                  
	  * 参数：    @param startIndex 起始数
	  * 参数：    @param lineCount 行数
	  * 参数：    @param startDate 开始时间
	  * 参数：    @param endDate 结束时间
	  * 参数：    @param userName 下级名称
	  * 参数：    @param agentName 代理名称
	  * 参数：    @param model 查询类型
	  * 参数：    @return 
	 * @return: List<AgentRecord>
	 */
	List<AgentRecord> findAgentRecordTwo(@Param("startIndex")Integer startIndex, @Param("lineCounts")Integer lineCount,
			@Param("startTime")String startTime, @Param("endTime")String endTime,
			 @Param("userName")String userName, @Param("agentName")String agentName);
	   
	/**
	 * 方法名：findByTimeAndIdRechargeCount 
	 * 描述：    查询团队充值人数                  
	 * 参数：    @param time 查询时间
	 * 参数：    @param ids 下级id
	 * 参数：    @return 
	 * @return: int
	 */
	int findByTimeAndIdRechargeCount(@Param("time")String time, @Param("ids")String ids);

	/**
	 * 方法名：findByTimeAndIdRegisterCount 
	 * 描述：    查询团队注册人数                  
	 * 参数：    @param time 查询时间
	 * 参数：    @param ids 下级id
	 * 参数：    @return 
	 * @return: int
	 */
	int findByTimeAndIdRegisterCount(@Param("time")String time, @Param("ids")String ids);

	/**
	 * 方法名：findByTimeAndIdBettingCount 
	 * 描述：    查询团队投注人数                  
	 * 参数：    @param time 查询时间
	 * 参数：    @param ids 下级id
	 * 参数：    @return 
	 * @return: int
	 */
	int findByTimeAndIdBettingCount(@Param("time")String time, @Param("ids")String ids);
	
	/**
	 * 方法名：findTeamRebateTwo 
	 * 描述：    查询团队返佣                  
	 * 参数：    @param time 查询时间
	 * 参数：    @param ids 下级id
	 * 参数：    @return 
	 * @return: double
	 */
	double findTeamRebateTwo(@Param("time")String time, @Param("ids")String ids);
	
	/**
	 * 方法名：findByIdTimeAgentRebateTotalTwo 
	 * 描述：    查询代理返佣                  
	 * 参数：    @param agent_id 代理id
	 * 参数：    @param time 查询时间
	 * 参数：    @return 
	 * @return: double
	 */
	double findByIdTimeAgentRebateTwo(@Param("agent_id")int agent_id, @Param("time")String time);
	
	/**
	  * 方法名：findAgentTotalTow 
	  * 描述：    查询代理下级的所有总计                     
	  * 参数：    @param userid 下级id
	  * 参数：    @param agent_id 代理id
	  * 参数：    @return 
	 * @return: AgentTotal
	 */
	AgentTotal findAgentTotalTow(Integer userid, Integer agent_id);
	
	/**
	 *   方法名：insertAgentRecordTow   
	 *   描述：    添加代理的返点记录                      
	 *   参数：    @param agentRecord
	 *   参数：    @return 
	 * @return: int
	 */
	int insertAgentRecordTwo(AgentRecord agentRecord);

	/**
	 *   方法名：insertAgentTotalTwo   
	 *   描述：      添加代理的返点总计                    
	 *   参数：    @param agentTotal
	 *   参数：    @return 
	 * @return: int
	 */
	int insertAgentTotalTwo(AgentTotal agentTotal);

	/**
	 *   方法名：updateAgentTotalTwo   
	 *   描述：    修改代理的返点总计                       
	 *   参数：    @param agentTotal
	 *   参数：    @return 
	 * @return: int
	 */
	int updateAgentTotalTwo(AgentTotal agentTotal);

	

	
}
