package com.ja.domain;

import java.io.Serializable;

public class TodayRecord implements Serializable {

	private static final long serialVersionUID = -3834479134149069058L;

	private Integer id; // 每日运营记录详情

	private String name;// 用户帐号

	private String user_type;// 用户类型

	private Double balance;// 用户余额

	private Double cptouzhu;// 彩票投注 1
	
	private Double xtctouzhu;// 系统彩投注 2

	private Double cpchedan;// 彩票撤单 3
	
	private Double xtcchedan; // 系统彩撤单 4
	
	private Double cppaijiang;// 彩票派奖  5

	private Double xitcpaijiang;// 系统彩派奖  6

	private Double hjtuihuan;// 和局退还本金 7

	private Double tmbfanshui;// 特码B返水 8
	
	private Double cpyichang;// 彩票开奖异常 9
	
	private Double xtcyichang;// 系统彩开奖异常 9
	
	private Double dmzengjia;// 打码增加 10
	
	private Double dmkouchu;// 打码扣除 11
	
	private Double mrfanshui;// 每日反水 12

	private Double myfanshui;// 每月反水 13
	
	private Double dlfandian;// 代理返点 14
	
	private Double mrqiandao;// 每日签到 15
	
	private Double xyzhuanpan;// 幸运转盘 16
	
	private Double hblingqu;// 红包领取 17
	
	private Double hbkouchu;// 红包扣除 18
	
	private Double zczengsong;// 注册赠送  19
	
	private Double czzengsong;// 充值赠送 20

	private Double hdzengsong; // 活动赠送 21

	private Double zxchongzhi; // 在线充值  22

	private Double rgjiakuan;// 人工加款 23

	private Double zxtikuan;// 在线提款  24
	
	private Double rgkoukuan;// 人工扣款  25

	private Double tkshouxufei;// 提款手续费  26

	private Double tkshibai;// 提款失败 27

	private Double sfxtuihuan;// 手续费退还 28

	private Integer ckcishu; // 存款次数 29

	private Integer tkcishu; // 提款次数 30

	private Double bjltouzhu;// 百家乐投注 28
	
	private Double bjlpaijiang;// 百家乐派奖 28
	
	private String bjlshuying; //百家乐输赢
	
	private Double touzhu; //投注总计
	
	private Double paijiang;//派奖总计
	
	private Double fandian;//返点总计
	
	private Double fanshui;//返水总计
	
	private Double huodong;//活动总计
	
	private Double chongzhi;//充值总计
	
	private Double tikuan;//提款总计
	
	private Double qipaiBetting;//棋牌投注总计
	
	private Double qipaiAwards;//棋牌派奖总计
	
	private String caipiaosy;// 彩票输赢统计

	private String xitongcaisy;// 系统彩输赢统计
	
	private String qipaisy;// 棋牌输赢总计
	
	private String quanbusy;// 全部输赢统计
	
	private Integer orderCount;// 投注人数
	
	private Integer registerCount;//注册人数
	
	private Integer rechargeCount;//充值人数
	
	private Double tuanduiyue;// 团队余额
	
	private Integer agentCount; //下级人数
	
	private Double teamRebate; //团队返佣
	
	private Double teamTotal; //团队亏盈
	
	private Double agentRebate; //代理返点
	
	private Double kuiyin; //运营亏盈
	
	private String time; //时间
	
	private Double bd_money; //变动金额

	private Integer type;// 变动类型
	
	private String model; // 变动中文类型

	private String created_time;// 操作时间

	private Integer state;// 开关

	private Integer user_id;// 用户id

	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	
	public TodayRecord() {
		super();
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getUser_type() {
		return user_type;
	}

	public void setUser_type(String user_type) {
		this.user_type = user_type;
	}

	public Double getBalance() {
		return balance;
	}

	public void setBalance(Double balance) {
		this.balance = balance;
	}

	public Double getCptouzhu() {
		return cptouzhu;
	}

	public void setCptouzhu(Double cptouzhu) {
		this.cptouzhu = cptouzhu;
	}

	public Double getXtctouzhu() {
		return xtctouzhu;
	}

	public void setXtctouzhu(Double xtctouzhu) {
		this.xtctouzhu = xtctouzhu;
	}

	public Double getCpchedan() {
		return cpchedan;
	}

	public void setCpchedan(Double cpchedan) {
		this.cpchedan = cpchedan;
	}

	public Double getXtcchedan() {
		return xtcchedan;
	}

	public void setXtcchedan(Double xtcchedan) {
		this.xtcchedan = xtcchedan;
	}

	public Double getCppaijiang() {
		return cppaijiang;
	}

	public void setCppaijiang(Double cppaijiang) {
		this.cppaijiang = cppaijiang;
	}

	public Double getXitcpaijiang() {
		return xitcpaijiang;
	}

	public void setXitcpaijiang(Double xitcpaijiang) {
		this.xitcpaijiang = xitcpaijiang;
	}

	public Double getHjtuihuan() {
		return hjtuihuan;
	}

	public void setHjtuihuan(Double hjtuihuan) {
		this.hjtuihuan = hjtuihuan;
	}

	public Double getTmbfanshui() {
		return tmbfanshui;
	}

	public void setTmbfanshui(Double tmbfanshui) {
		this.tmbfanshui = tmbfanshui;
	}

	public Double getCpyichang() {
		return cpyichang;
	}

	public void setCpyichang(Double cpyichang) {
		this.cpyichang = cpyichang;
	}

	public Double getXtcyichang() {
		return xtcyichang;
	}

	public void setXtcyichang(Double xtcyichang) {
		this.xtcyichang = xtcyichang;
	}

	public Double getDmzengjia() {
		return dmzengjia;
	}

	public void setDmzengjia(Double dmzengjia) {
		this.dmzengjia = dmzengjia;
	}

	public Double getDmkouchu() {
		return dmkouchu;
	}

	public void setDmkouchu(Double dmkouchu) {
		this.dmkouchu = dmkouchu;
	}

	public Double getMrfanshui() {
		return mrfanshui;
	}

	public void setMrfanshui(Double mrfanshui) {
		this.mrfanshui = mrfanshui;
	}

	public Double getMyfanshui() {
		return myfanshui;
	}

	public void setMyfanshui(Double myfanshui) {
		this.myfanshui = myfanshui;
	}

	public Double getDlfandian() {
		return dlfandian;
	}

	public void setDlfandian(Double dlfandian) {
		this.dlfandian = dlfandian;
	}

	public Double getMrqiandao() {
		return mrqiandao;
	}

	public void setMrqiandao(Double mrqiandao) {
		this.mrqiandao = mrqiandao;
	}

	public Double getXyzhuanpan() {
		return xyzhuanpan;
	}

	public void setXyzhuanpan(Double xyzhuanpan) {
		this.xyzhuanpan = xyzhuanpan;
	}

	public Double getHblingqu() {
		return hblingqu;
	}

	public void setHblingqu(Double hblingqu) {
		this.hblingqu = hblingqu;
	}

	public Double getHbkouchu() {
		return hbkouchu;
	}

	public void setHbkouchu(Double hbkouchu) {
		this.hbkouchu = hbkouchu;
	}

	public Double getZczengsong() {
		return zczengsong;
	}

	public void setZczengsong(Double zczengsong) {
		this.zczengsong = zczengsong;
	}

	public Double getCzzengsong() {
		return czzengsong;
	}

	public void setCzzengsong(Double czzengsong) {
		this.czzengsong = czzengsong;
	}

	public Double getHdzengsong() {
		return hdzengsong;
	}

	public void setHdzengsong(Double hdzengsong) {
		this.hdzengsong = hdzengsong;
	}

	public Double getZxchongzhi() {
		return zxchongzhi;
	}

	public void setZxchongzhi(Double zxchongzhi) {
		this.zxchongzhi = zxchongzhi;
	}

	public Double getRgjiakuan() {
		return rgjiakuan;
	}

	public void setRgjiakuan(Double rgjiakuan) {
		this.rgjiakuan = rgjiakuan;
	}

	public Double getZxtikuan() {
		return zxtikuan;
	}

	public void setZxtikuan(Double zxtikuan) {
		this.zxtikuan = zxtikuan;
	}

	public Double getRgkoukuan() {
		return rgkoukuan;
	}

	public void setRgkoukuan(Double rgkoukuan) {
		this.rgkoukuan = rgkoukuan;
	}

	public Double getTkshouxufei() {
		return tkshouxufei;
	}

	public void setTkshouxufei(Double tkshouxufei) {
		this.tkshouxufei = tkshouxufei;
	}

	public Double getTkshibai() {
		return tkshibai;
	}

	public void setTkshibai(Double tkshibai) {
		this.tkshibai = tkshibai;
	}

	public Double getSfxtuihuan() {
		return sfxtuihuan;
	}

	public void setSfxtuihuan(Double sfxtuihuan) {
		this.sfxtuihuan = sfxtuihuan;
	}

	public Integer getCkcishu() {
		return ckcishu;
	}

	public void setCkcishu(Integer ckcishu) {
		this.ckcishu = ckcishu;
	}

	public Integer getTkcishu() {
		return tkcishu;
	}

	public void setTkcishu(Integer tkcishu) {
		this.tkcishu = tkcishu;
	}

	public Double getBjltouzhu() {
		return bjltouzhu;
	}

	public void setBjltouzhu(Double bjltouzhu) {
		this.bjltouzhu = bjltouzhu;
	}

	public Double getBjlpaijiang() {
		return bjlpaijiang;
	}

	public void setBjlpaijiang(Double bjlpaijiang) {
		this.bjlpaijiang = bjlpaijiang;
	}

	public String getBjlshuying() {
		return bjlshuying;
	}

	public void setBjlshuying(String bjlshuying) {
		this.bjlshuying = bjlshuying;
	}

	public Double getTouzhu() {
		return touzhu;
	}

	public void setTouzhu(Double touzhu) {
		this.touzhu = touzhu;
	}

	public Double getPaijiang() {
		return paijiang;
	}

	public void setPaijiang(Double paijiang) {
		this.paijiang = paijiang;
	}

	public Double getFandian() {
		return fandian;
	}

	public void setFandian(Double fandian) {
		this.fandian = fandian;
	}

	public Double getFanshui() {
		return fanshui;
	}

	public void setFanshui(Double fanshui) {
		this.fanshui = fanshui;
	}

	public Double getHuodong() {
		return huodong;
	}

	public void setHuodong(Double huodong) {
		this.huodong = huodong;
	}

	public Double getChongzhi() {
		return chongzhi;
	}

	public void setChongzhi(Double chongzhi) {
		this.chongzhi = chongzhi;
	}

	public Double getTikuan() {
		return tikuan;
	}

	public void setTikuan(Double tikuan) {
		this.tikuan = tikuan;
	}

	public Double getQipaiBetting() {
		return qipaiBetting;
	}

	public void setQipaiBetting(Double qipaiBetting) {
		this.qipaiBetting = qipaiBetting;
	}

	public Double getQipaiAwards() {
		return qipaiAwards;
	}

	public void setQipaiAwards(Double qipaiAwards) {
		this.qipaiAwards = qipaiAwards;
	}

	public String getCaipiaosy() {
		return caipiaosy;
	}

	public void setCaipiaosy(String caipiaosy) {
		this.caipiaosy = caipiaosy;
	}

	public String getXitongcaisy() {
		return xitongcaisy;
	}

	public void setXitongcaisy(String xitongcaisy) {
		this.xitongcaisy = xitongcaisy;
	}

	public String getQipaisy() {
		return qipaisy;
	}

	public void setQipaisy(String qipaisy) {
		this.qipaisy = qipaisy;
	}

	public String getQuanbusy() {
		return quanbusy;
	}

	public void setQuanbusy(String quanbusy) {
		this.quanbusy = quanbusy;
	}

	public Integer getOrderCount() {
		return orderCount;
	}

	public void setOrderCount(Integer orderCount) {
		this.orderCount = orderCount;
	}

	public Integer getRegisterCount() {
		return registerCount;
	}

	public void setRegisterCount(Integer registerCount) {
		this.registerCount = registerCount;
	}

	public Integer getRechargeCount() {
		return rechargeCount;
	}

	public void setRechargeCount(Integer rechargeCount) {
		this.rechargeCount = rechargeCount;
	}

	public Double getTuanduiyue() {
		return tuanduiyue;
	}

	public void setTuanduiyue(Double tuanduiyue) {
		this.tuanduiyue = tuanduiyue;
	}

	public Integer getAgentCount() {
		return agentCount;
	}

	public void setAgentCount(Integer agentCount) {
		this.agentCount = agentCount;
	}

	public Double getTeamRebate() {
		return teamRebate;
	}

	public void setTeamRebate(Double teamRebate) {
		this.teamRebate = teamRebate;
	}

	public Double getTeamTotal() {
		return teamTotal;
	}

	public void setTeamTotal(Double teamTotal) {
		this.teamTotal = teamTotal;
	}

	public Double getAgentRebate() {
		return agentRebate;
	}

	public void setAgentRebate(Double agentRebate) {
		this.agentRebate = agentRebate;
	}

	public Double getKuiyin() {
		return kuiyin;
	}

	public void setKuiyin(Double kuiyin) {
		this.kuiyin = kuiyin;
	}

	public String getTime() {
		return time;
	}

	public void setTime(String time) {
		this.time = time;
	}

	public Double getBd_money() {
		return bd_money;
	}

	public void setBd_money(Double bd_money) {
		this.bd_money = bd_money;
	}

	public Integer getType() {
		return type;
	}

	public void setType(Integer type) {
		this.type = type;
	}

	public String getModel() {
		return model;
	}

	public void setModel(String model) {
		this.model = model;
	}

	public String getCreated_time() {
		return created_time;
	}

	public void setCreated_time(String created_time) {
		this.created_time = created_time;
	}

	public Integer getState() {
		return state;
	}

	public void setState(Integer state) {
		this.state = state;
	}

	public Integer getUser_id() {
		return user_id;
	}

	public void setUser_id(Integer user_id) {
		this.user_id = user_id;
	}

	@Override
	public String toString() {
		return "TodayRecord [id=" + id + ", name=" + name + ", user_type=" + user_type + ", balance=" + balance
				+ ", cptouzhu=" + cptouzhu + ", xtctouzhu=" + xtctouzhu + ", cpchedan=" + cpchedan + ", xtcchedan="
				+ xtcchedan + ", cppaijiang=" + cppaijiang + ", xitcpaijiang=" + xitcpaijiang + ", hjtuihuan="
				+ hjtuihuan + ", tmbfanshui=" + tmbfanshui + ", cpyichang=" + cpyichang + ", xtcyichang=" + xtcyichang
				+ ", dmzengjia=" + dmzengjia + ", dmkouchu=" + dmkouchu + ", mrfanshui=" + mrfanshui + ", myfanshui="
				+ myfanshui + ", dlfandian=" + dlfandian + ", mrqiandao=" + mrqiandao + ", xyzhuanpan=" + xyzhuanpan
				+ ", hblingqu=" + hblingqu + ", hbkouchu=" + hbkouchu + ", zczengsong=" + zczengsong + ", czzengsong="
				+ czzengsong + ", hdzengsong=" + hdzengsong + ", zxchongzhi=" + zxchongzhi + ", rgjiakuan=" + rgjiakuan
				+ ", zxtikuan=" + zxtikuan + ", rgkoukuan=" + rgkoukuan + ", tkshouxufei=" + tkshouxufei + ", tkshibai="
				+ tkshibai + ", sfxtuihuan=" + sfxtuihuan + ", ckcishu=" + ckcishu + ", tkcishu=" + tkcishu
				+ ", bjltouzhu=" + bjltouzhu + ", bjlpaijiang=" + bjlpaijiang + ", bjlshuying=" + bjlshuying
				+ ", touzhu=" + touzhu + ", paijiang=" + paijiang + ", fandian=" + fandian + ", fanshui=" + fanshui
				+ ", huodong=" + huodong + ", chongzhi=" + chongzhi + ", tikuan=" + tikuan + ", qipaiBetting="
				+ qipaiBetting + ", qipaiAwards=" + qipaiAwards + ", caipiaosy=" + caipiaosy + ", xitongcaisy="
				+ xitongcaisy + ", qipaisy=" + qipaisy + ", quanbusy=" + quanbusy + ", orderCount=" + orderCount
				+ ", registerCount=" + registerCount + ", rechargeCount=" + rechargeCount + ", tuanduiyue=" + tuanduiyue
				+ ", agentCount=" + agentCount + ", teamRebate=" + teamRebate + ", teamTotal=" + teamTotal
				+ ", agentRebate=" + agentRebate + ", kuiyin=" + kuiyin + ", time=" + time + ", bd_money=" + bd_money
				+ ", type=" + type + ", model=" + model + ", created_time=" + created_time + ", state=" + state
				+ ", user_id=" + user_id + "]";
	}

}