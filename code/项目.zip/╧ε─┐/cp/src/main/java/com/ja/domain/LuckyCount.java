package com.ja.domain;

import java.io.Serializable;

public class LuckyCount implements Serializable{
	
    /**
	 * 
	 */
	private static final long serialVersionUID = 7715159739094411997L;

	private Integer id;

    private String name;//会员帐号

    private Integer count;//转盘摇奖次数
   
    private String createTime;//创建时间

    private Integer userid;//用户id

    
    public static long getSerialversionuid() {
		return serialVersionUID;
	}
    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Integer getCount() {
		return count;
	}

	public void setCount(Integer count) {
		this.count = count;
	}

	public String getCreateTime() {
		return createTime;
	}

	public void setCreateTime(String createTime) {
		this.createTime = createTime;
	}

	public Integer getUserid() {
		return userid;
	}

	public void setUserid(Integer userid) {
		this.userid = userid;
	}

	public LuckyCount() {
		super();
	}

	@Override
	public String toString() {
		return "LuckyCount [id=" + id + ", name=" + name + ", count=" + count + ", createTime=" + createTime
				+ ", userid=" + userid + "]";
	}


}