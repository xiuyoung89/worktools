package com.ja.domain;

import java.io.Serializable;

public class AgentRecord implements Serializable{

	private static final long serialVersionUID = 9144516536201331708L;

	private Integer id; //普通代理返点记录表

    private String agent_name; //代理名称 
    
    private Integer agent_grade; //代理等级

    private String user_name; //会员名称 
    
    private Double consume; //消费金额
    
    private String order_number; //消费订单号
    
    private Integer rebate_type; //返点类型 

    private Double rebate_ratio; //代理返点率 
    
    private Double rebate_money; //代理返点金额 
    
    private String created_time; //创建-操作时间
    
    private Integer state; //0已读  1未读 状态
    
    private Integer agent_id; //代理id
    
    private Integer user_id; //会员id

	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getAgent_name() {
		return agent_name;
	}

	public void setAgent_name(String agent_name) {
		this.agent_name = agent_name;
	}

	public Integer getAgent_grade() {
		return agent_grade;
	}

	public void setAgent_grade(Integer agent_grade) {
		this.agent_grade = agent_grade;
	}

	public String getUser_name() {
		return user_name;
	}

	public void setUser_name(String user_name) {
		this.user_name = user_name;
	}

	public Double getConsume() {
		return consume;
	}

	public void setConsume(Double consume) {
		this.consume = consume;
	}

	public String getOrder_number() {
		return order_number;
	}

	public void setOrder_number(String order_number) {
		this.order_number = order_number;
	}

	public Integer getRebate_type() {
		return rebate_type;
	}

	public void setRebate_type(Integer rebate_type) {
		this.rebate_type = rebate_type;
	}

	public Double getRebate_ratio() {
		return rebate_ratio;
	}

	public void setRebate_ratio(Double rebate_ratio) {
		this.rebate_ratio = rebate_ratio;
	}

	public Double getRebate_money() {
		return rebate_money;
	}

	public void setRebate_money(Double rebate_money) {
		this.rebate_money = rebate_money;
	}

	public String getCreated_time() {
		return created_time;
	}

	public void setCreated_time(String created_time) {
		this.created_time = created_time;
	}

	public Integer getState() {
		return state;
	}

	public void setState(Integer state) {
		this.state = state;
	}

	public Integer getAgent_id() {
		return agent_id;
	}

	public void setAgent_id(Integer agent_id) {
		this.agent_id = agent_id;
	}

	public Integer getUser_id() {
		return user_id;
	}

	public void setUser_id(Integer user_id) {
		this.user_id = user_id;
	}

	
	public AgentRecord() {
		super();
	}

	@Override
	public String toString() {
		return "CommonAgent [id=" + id + ", agent_name=" + agent_name + ", agent_grade=" + agent_grade + ", user_name="
				+ user_name + ", consume=" + consume + ", order_number=" + order_number + ", rebate_type=" + rebate_type
				+ ", rebate_ratio=" + rebate_ratio + ", rebate_money=" + rebate_money + ", created_time=" + created_time
				+ ", state=" + state + ", agent_id=" + agent_id + ", user_id=" + user_id + "]";
	}
}