package com.ja.domain;

import java.io.Serializable;

public class PayMoney implements Serializable{
	
	private static final long serialVersionUID = -5041210796683764823L;

	private Integer id;// id
	
	private String version;//版本号

	private String userId;// 商户编号

	private String orderNum;// 平台订单编号
	
	private String merchantOrderNum; //商户订单号

	private String cardId;// 卡类充值编号

	private String cardPass;// 卡类充值密码
	
	private String money; // 实际支付金额 
	
	private String money_order; //订单金额

	private String faceValue;//实际支付金额
	
	private String channelId; // 支付方式

	private String goodsName;// 商品名称

	private String goodsPrice;// 商品单价

	private String goodsCount;// 商品数量

	private String bankId;// 网银-银行编码

	private String remarks;// 商户备注信息

	private String payInterfaceURL;// 充值地址
	
	private String notifyURL;// 支付后异步回调地址
	
	private String resultURL;// 支付后跳转地址
	
	private String postKey;// MD5加密后的签名
	
	private String timestamp; //当前时间戳
	
	private String errCode; // 交易状态码

	private String errMsg; // 交易状态解释
	
	private Integer status; // 交易状态 
	
	private Integer state;// 充值状态
	
	private Integer rechargeType;// 接口类型
	
	private String createTime;// 创建时间
	
	private Integer uid;// 用户id
	
	public PayMoney() {
		super();
	}
	
    public static long getSerialversionuid() {
		return serialVersionUID;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getVersion() {
		return version;
	}

	public void setVersion(String version) {
		this.version = version;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getOrderNum() {
		return orderNum;
	}

	public void setOrderNum(String orderNum) {
		this.orderNum = orderNum;
	}

	public String getCardId() {
		return cardId;
	}

	public void setCardId(String cardId) {
		this.cardId = cardId;
	}

	public String getCardPass() {
		return cardPass;
	}

	public void setCardPass(String cardPass) {
		this.cardPass = cardPass;
	}

	public String getFaceValue() {
		return faceValue;
	}

	public void setFaceValue(String faceValue) {
		this.faceValue = faceValue;
	}

	public String getChannelId() {
		return channelId;
	}

	public void setChannelId(String channelId) {
		this.channelId = channelId;
	}

	public String getGoodsName() {
		return goodsName;
	}

	public void setGoodsName(String goodsName) {
		this.goodsName = goodsName;
	}

	public String getGoodsPrice() {
		return goodsPrice;
	}

	public void setGoodsPrice(String goodsPrice) {
		this.goodsPrice = goodsPrice;
	}

	public String getGoodsCount() {
		return goodsCount;
	}

	public void setGoodsCount(String goodsCount) {
		this.goodsCount = goodsCount;
	}

	public String getBankId() {
		return bankId;
	}

	public void setBankId(String bankId) {
		this.bankId = bankId;
	}

	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	public String getPayInterfaceURL() {
		return payInterfaceURL;
	}

	public void setPayInterfaceURL(String payInterfaceURL) {
		this.payInterfaceURL = payInterfaceURL;
	}

	public String getNotifyURL() {
		return notifyURL;
	}

	public void setNotifyURL(String notifyURL) {
		this.notifyURL = notifyURL;
	}

	public String getResultURL() {
		return resultURL;
	}

	public void setResultURL(String resultURL) {
		this.resultURL = resultURL;
	}

	public String getPostKey() {
		return postKey;
	}

	public void setPostKey(String postKey) {
		this.postKey = postKey;
	}

	public String getTimestamp() {
		return timestamp;
	}

	public void setTimestamp(String timestamp) {
		this.timestamp = timestamp;
	}

	public String getErrCode() {
		return errCode;
	}

	public void setErrCode(String errCode) {
		this.errCode = errCode;
	}

	public String getErrMsg() {
		return errMsg;
	}

	public void setErrMsg(String errMsg) {
		this.errMsg = errMsg;
	}

	public Integer getStatus() {
		return status;
	}

	public void setStatus(Integer status) {
		this.status = status;
	}

	public Integer getState() {
		return state;
	}

	public void setState(Integer state) {
		this.state = state;
	}

	public Integer getRechargeType() {
		return rechargeType;
	}

	public void setRechargeType(Integer rechargeType) {
		this.rechargeType = rechargeType;
	}

	public String getCreateTime() {
		return createTime;
	}

	public void setCreateTime(String createTime) {
		this.createTime = createTime;
	}

	public Integer getUid() {
		return uid;
	}

	public void setUid(Integer uid) {
		this.uid = uid;
	}

	public String getMerchantOrderNum() {
		return merchantOrderNum;
	}

	public void setMerchantOrderNum(String merchantOrderNum) {
		this.merchantOrderNum = merchantOrderNum;
	}

	public String getMoney() {
		return money;
	}

	public void setMoney(String money) {
		this.money = money;
	}

	public String getMoney_order() {
		return money_order;
	}

	public void setMoney_order(String money_order) {
		this.money_order = money_order;
	}

	@Override
	public String toString() {
		return "PayMoney [id=" + id + ", version=" + version + ", userId=" + userId + ", orderNum=" + orderNum
				+ ", merchantOrderNum=" + merchantOrderNum + ", cardId=" + cardId + ", cardPass=" + cardPass
				+ ", money=" + money + ", money_order=" + money_order + ", faceValue=" + faceValue + ", channelId="
				+ channelId + ", goodsName=" + goodsName + ", goodsPrice=" + goodsPrice + ", goodsCount=" + goodsCount
				+ ", bankId=" + bankId + ", remarks=" + remarks + ", payInterfaceURL=" + payInterfaceURL
				+ ", notifyURL=" + notifyURL + ", resultURL=" + resultURL + ", postKey=" + postKey + ", timestamp="
				+ timestamp + ", errCode=" + errCode + ", errMsg=" + errMsg + ", status=" + status + ", state=" + state
				+ ", rechargeType=" + rechargeType + ", createTime=" + createTime + ", uid=" + uid + "]";
	}

}