package com.ja.dao;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.ja.domain.BaccaratBulletin;
import com.ja.domain.Bjl;
import com.ja.domain.Bjldata;
import com.ja.domain.Lotter;
import com.ja.domain.PagingData;

public interface BjlhtglMapper {
	/**
	 * 修改百家乐百分比控制
	 * @param tableNumber  桌号
	 * @param percentage  百分比
	 * @return  修改成功返回 1  不成功则是别的值 有可能是0
	 */
	int updateBjlControl(@Param("tableNumber")int tableNumber,@Param("percentage")int percentage);
	/**
	 * 修改百家乐房间金额 就是进入房间时显示的金额
	 * @param tableNumber 桌号
	 * @param maximumAmount 最大金额
	 * @param minimumSum 最小金额
	 * @return  修改成功则返回1 
	 */
	int updateBjlRoomMoney(@Param("tableNumber")int tableNumber,@Param("maximumAmount")String maximumAmount,@Param("minimumSum")String minimumSum);
	/**
	 * 	 修改百家乐开奖赔率
	 * @param rebate1   rebate1 庄家的赔率
	 * @param rebate2   rebate2 闲家的赔率
	 * @param rebate3  rebate3闲对的赔率
	 * @param rebate4  rebate4庄对的赔率
	 * @param rebate5  rebate5和局的赔率
	 * @param rebate6  rebate6大的赔率
	 * @param rebate7  rebate7小的赔率
	 * @param rebate8  rebate8完美对子的赔率
	 * @param rebate9  rebate9任意对子的赔率
	 * @param name  彩种名
	 * @return 修改成功则返回1 
	 */
	int upDateOdds(@Param("rebate1") String rebate1, @Param("rebate2")String rebate2,@Param("rebate3") String rebate3, @Param("rebate4")String rebate4, @Param("rebate5")String rebate5,@Param("rebate6")String rebate6,@Param("rebate7")String rebate7,
			@Param("rebate8")String rebate8,@Param("rebate9")String rebate9,@Param("name") String name);
	/**
	 * 查询百家乐用户下注记录
	 * @param paging  页数
	 * @param name  会员账号 根据会员账号查询
	 * @param date1 根据开始日期 
	 * @param date2 根据结束日期   查询
	 * @param period 根据期号查询
	 * @param state  开奖状态  0-未开奖  1-已开奖
	 * @param status 根据中将状态查询 主要前台查询
	 * @param id  根据id查询
	 * @return 返回list集合里面包含Bjl对象  查询到则有数据 没有查询到则返回一个空集合
	 */
	 List<Bjl> xiazjl(@Param("paging")PagingData paging, @Param("name")String name,@Param("date1")String date1,@Param("date2")String date2,@Param("period")String period,@Param("status")Integer status,@Param("state")Integer state,@Param("id")Integer id);
	 /**
	  * 根据桌号查询当前桌的基本设置数据
	  * @param tableNumber  桌号
	  * @return 查询到则返回 BaccaratBulletin对象 如果没有查询到则返回null
	  */
	 BaccaratBulletin basicSettingsOfBaccarat(@Param("tableNumber")Integer tableNumber);
	 
	 Lotter pailu();

	 int deletexzjl(int id);
	 /**
	  * 修改百家乐8遇到9 返点百分之几
	  * @param percent  返点比例
	  * @return
	  */
	 int fandian(@Param("percent")Double percent);
	 

		/**
		 * 查询百家乐用户下注记录   根据传入的参数条件进行查询
		 * @param user  用户名  后台用
		 * @param time1 开始时间 后台用
		 * @param time2 结束时间 后台用
		 * @param period 根据期号查询 后台用
		 * @param state 根据开奖未开奖查询 后台用
		 * @param status 根据开奖状态查询  前台用
		 * @return  查询到则返回数据库里面数据的条数 没有查询到则返回0
		 */
		Integer xiazjlCounts(@Param("name")String name,@Param("date1")String date1,@Param("date2")String date2,@Param("period")String period,@Param("status")Integer status,@Param("state")Integer state);
		/**
		 * 统计百家乐开奖数据
		 * @param date1 开始时间
		 * @param date2 结束时间 
		 * @param period 期号
		 * @param tableNumber 桌号
		 * @return 返回当前数据库里面数据的总数
		 */
		Integer lotteryRecord(@Param("date1")String date1,@Param("date2")String date2,@Param("period")String period,@Param("tableNumber")Integer tableNumber);
		/**
		 * 查询百家乐开奖数据
		 * @param paging  分页对象
		 * @param date1 开始时间
		 * @param date2 结束时间
		 * @param period  期号
		 * @param tableNumber 桌号
		 * @return
		 */
		List<Bjldata> lotteryRecords(@Param("paging")PagingData paging, @Param("date1")String date1,@Param("date2")String date2,@Param("period")String period,@Param("tableNumber")Integer tableNumber);

		/**
		 * 百家乐开奖数据预设接口 
		 * @param data  预设数据
		 * @return  预设成功则返回1
		 */
		int baccaratPresupposition(@Param("b") Bjldata data);

		/**
		 * 查询退款的下注记录
		 * @param tableNumber 退款房间号
		 * @param issueNumber 退款期号
		 * @return
		 */
		List<Bjl> QueryAnnotationRecord(@Param("tableNumber")Integer tableNumber, @Param("issueNumber")String issueNumber);
		
		/**
		 * 根据下注记录id修改下注状态
		 * @param id 下注id
		 * @return 成功则返回1
		 */
		int upDataBetState(@Param("status")Integer status,@Param("id")Integer id);
		
}
