package com.ja.dao;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.ja.domain.AllExplain;

/**
 * 
    * 项目名称：cp   
    * 类名称：ExplainService.java   
    * 类描述：   平台说明
    * 创建人：   Administrator
    * 创建时间：2018年12月6日 下午4:20:13   
 * @version v1.0.0
 */
public interface AllExplainMapper {
	/**
	 * 
	   *   方法名：insertExplain   
	   *   描述：     添加帮助说明                  TODO   
	   *   参数：    @param explain
	   *   参数：    @return 
	 * @return: int
	 */
	int insertExplain(AllExplain explain);
	
	
	/**
	 * 
	   *   方法名：updateExplain   
	   *   描述：    修改平台说明                   TODO   
	   *   参数：    @param explain
	   *   参数：    @return 
	 * @return: int
	 */
	int updateExplain(AllExplain explain);
	
	/**
	 * 
	   *   方法名：findAllExplain   
	   *   描述：     查询菜单说明                  TODO   
	   *   参数：    @param type 1 是所有的菜单 2是所有的帮助说明 3是日常说明
	   *   参数：    @return 
	 * @return: List<AllExplain>
	 */
	List<AllExplain> findAllExplain(@Param("type")Integer type); 
	
	/**
	 * 
	   *   方法名：findByIdExplain   
	   *   描述：    根据id查询平台说明                   TODO   
	   *   参数：    @param id
	   *   参数：    @return 
	 * @return: AllExplain
	 */
	AllExplain findByIdExplain(Integer id);

	/**
	 * 
	   *   方法名：finMeunByDeleteId   
	   *   描述：    根据菜单查出菜单分类的id                   TODO   
	   *   参数：    @param id
	   *   参数：    @return 
	 * @return: List<Integer>
	 */
	List<Integer> finMeunByDeleteId(Integer id);

	/**
	 * 
	   *   方法名：deleteExplain   
	   *   描述：     删除说明或者菜单                  TODO   
	   *   参数：    @param id
	   *   参数：    @return 
	 * @return: int
	 */
	int deleteExplain(@Param("id") Integer id,@Param("ids") String ids,@Param("type") Integer type);

}
