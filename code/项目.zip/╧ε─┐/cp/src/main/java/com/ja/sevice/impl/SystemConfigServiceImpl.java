package com.ja.sevice.impl;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.DigestUtils;

import com.ja.config.WebsiteStateConfig;
import com.ja.dao.SystemConfigMapper;
import com.ja.dao.UserMapper;
import com.ja.domain.Admin;
import com.ja.domain.Agent;
import com.ja.domain.FastIncomeSetting;
import com.ja.domain.IncomeSetting;
import com.ja.domain.ParkedDomains;
import com.ja.domain.UpDataPage;
import com.ja.domain.User;
import com.ja.domain.WhiteList;
import com.ja.sevice.ISystemConfigService;
import com.ja.util.DateUtil;
import com.ja.util.JsonResult;

@Service
public class SystemConfigServiceImpl implements ISystemConfigService {

	@Autowired
	private SystemConfigMapper systemConfigMapper;
	
	@Autowired
	private UserMapper userMapper;

	@Override
	public Admin findAllConfig() {
		return systemConfigMapper.findAllConfig();
	}
	
	@Override
	public Integer findWebState() {
		return systemConfigMapper.findWebState();
	}

	@Override
	public Integer updateAllConfig(Admin admin) {
		return systemConfigMapper.updateAllConfig(admin);
		
	}

	@Override
	public boolean ipCheck(String ip,Integer state) {
		boolean flag = true;
		List<User> users = systemConfigMapper.findUserByIp(ip,state,DateUtil.findFormatDate());
		if(users.size()> Integer.parseInt(WebsiteStateConfig.configs.get("zhuceipcount"))) {
			flag = false;
		}
		return flag;
	}

	@Override
	public List<IncomeSetting> findAllIncomeSetting() {
		return systemConfigMapper.findAllIncomeSetting();
	}

	@Override
	public List<FastIncomeSetting> findAllFastIncomeSetting() {
		return systemConfigMapper.findAllFastIncomeSetting();
	}
	
	@Override
	public Integer updateIncomeSetting(IncomeSetting incomeSetting) {
		return systemConfigMapper.updateIncomeSetting(incomeSetting);
	}

	@Override
	public Integer updateFastIncomeSetting(FastIncomeSetting fastIncomeSetting) {
		return systemConfigMapper.updateFastIncomeSetting(fastIncomeSetting);
	}

	@Override
	public Integer insertIncomeSetting(IncomeSetting incomeSetting) {
		return systemConfigMapper.insertIncomeSetting(incomeSetting);
	}

	@Override
	public Integer insertFastIncomeSetting(FastIncomeSetting fastIncomeSetting) {
		return systemConfigMapper.insertFastIncomeSetting(fastIncomeSetting);
	}

	@Override
	public IncomeSetting findIncomeSettingById(Integer id) {
		return systemConfigMapper.findIncomeSettingById(id);
	}

	@Override
	public FastIncomeSetting findFastIncomeSettingById(Integer id) {
		return systemConfigMapper.findFastIncomeSettingById(id);
	}

	@Override
	public List<User> findUser(String type) {
		
		return systemConfigMapper.findUser(type);
	}

	@Override
	public Integer insertWhiteList(WhiteList whiteList) {
		Date date = new Date();
		whiteList.setCreatedTime(date);
		whiteList.setCreatedUser("admin");
		WhiteList  wl = systemConfigMapper.findWhiteListByIP(whiteList.getIp());
		if(wl!=null)
			throw new RuntimeException("该ip已经被设置过，请重新更换");
		return systemConfigMapper.insertWhiteList(whiteList);
	}

	@Override
	public List<WhiteList> findAllWhiteList() {
		return systemConfigMapper.findAllWhiteList();
	}

	@Override
	public Integer updateWhiteListStatus(Integer id, Integer status) {
		return systemConfigMapper.updateWhiteListStatus(id, status);
	}

	@Override
	public WhiteList findWhiteListByIP(String ip) {
		return systemConfigMapper.findWhiteListByIP(ip);
	}
	
	@Override
	@Transactional
	public Integer deleteWhiteList(Integer id) {
		Integer affectRow = systemConfigMapper.deleteWhiteList(id);
		if(affectRow!=1){
			throw new RuntimeException("删除白名单异常!");
		}
		return affectRow;
	}
	
	
	@Override
	public Integer insertParkedDomains(ParkedDomains domain) {
		domain.setCreatedTime(new Date());
		List<ParkedDomains> domains = systemConfigMapper.findOneParkedDomains(domain);
		if(domains.size()>0){
			return -1;
		} 
		return systemConfigMapper.insertParkedDomains(domain);
	}

	/**
	 * 可以添加域名的代理
	 * @return
	 */
	public List<String> canAddAgent(){
		return systemConfigMapper.findOpenAgent();
	}
	
	
	@Override
	public List<ParkedDomains> findAllParkedDomains(Integer id,String domain, String agency) {
		return systemConfigMapper.findAllParkedDomains(id,domain, agency);
	}

	@Override
	public Integer updateDomainStatus(Integer id, Integer status) {
		return systemConfigMapper.updateDomainStatus(id, status);
	}

	@Override
	public Integer updateDomain(ParkedDomains domain) {
		domain.setCreatedTime(new Date());
		List<ParkedDomains> domains = systemConfigMapper.findOneParkedDomains(domain);
		if(domains.size()>0){
			return -1;
		} 
		return systemConfigMapper.updateDomain(domain);
	}

	@Override
	@Transactional
	public Integer deleteDomain(Integer id) {
		Integer affectRow = systemConfigMapper.deleteDomain(id);
		if(affectRow != 1){
			throw new RuntimeException("删除绑定域名异常");
		}
		return affectRow;
	}


	@Override
	public List<User> findUserList(String type, String account, String icode) {
		return systemConfigMapper.findUserList(type, account, icode);
	}


	@Override
	public Agent findAgentByUsername(String username) {
		return systemConfigMapper.findAgentByUsername(username);
	}


	@Override
	@Transactional
	public JsonResult addGeneralAgent(Agent agent) {
		Agent agents = findAgentByUsername(agent.getUsername());
		if(agents!=null){
			return new JsonResult("-1","改账号已存在!");
		}
		String pass = DigestUtils.md5DigestAsHex(DigestUtils.md5DigestAsHex(agent.getPassword().getBytes()).getBytes());
		agent.setPassword(pass);
		agent.setCreatedTime(new Date());
		Integer affectRow = systemConfigMapper.register(agent);
		if(affectRow!=0){
			User user = userMapper.checkUser(agent.getUsername());
			if(user!=null) {
				user.setAgent_type(2);
				userMapper.updateUserInfo(user);
				List<User> users = userMapper.findFristAgent(user.getId());
				Agent agent1 = systemConfigMapper.findDescLimit();
				for(User u : users) {
					u.setAgent_id(agent1.getId());
					userMapper.updateUserInfo(u);
				}
			}
			return new JsonResult("1","添加成功!");
		}
		return new JsonResult("0","添加失败!");
	}

	@Override
	public List<Agent> allAgentList() {
		return systemConfigMapper.allAgentList();
	}

	@Override
	public Agent findAgentById(Integer id) {
		return systemConfigMapper.findAgentById(id);
	}
	
	@Override
	public Integer editAgent(Agent agent) {
		return systemConfigMapper.editAgent(agent);
	}

	@Override
	public Integer deleteGeneralAgent(Integer id) {
		Agent agent = systemConfigMapper.findAgentById(id);
		List<Integer> ids = systemConfigMapper.findByIdAllParkedDomainsId(agent.getUsername());
		if(ids.size()>0) {
			systemConfigMapper.deleteBatchDomain(ids);
		}
		return systemConfigMapper.deleteGeneralAgent(id);
	}

	@Override
	public List<ParkedDomains> findAllParkedDomains1(Integer id, String domain, String agency) {
		return systemConfigMapper.findAllParkedDomains1(id, domain, agency);
	}

	@Override
	public Integer receiveAReturnPoint(Double receiveAReturnPoint) {
		return systemConfigMapper.receiveAReturnPoint(receiveAReturnPoint);
	}

	@Override
	public List<String> findByStateGeneralAgentList() {
		return systemConfigMapper.findByStateGeneralAgentList();
	}

	@Override
	public List<UpDataPage> findSystemUpdatePage() {
		return systemConfigMapper.findSystemUpdatePage();
	}

	@Override
	public int updateSystemPage(List<UpDataPage> upDataPage) {
		return systemConfigMapper.updateSystemPage(upDataPage,DateUtil.getCurrTime());
	}

}
