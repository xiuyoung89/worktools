package com.ja.domain;

public class UserInvitationLink {
	
	private Integer id; //用户邀请链接生成
	
	private String user_name;//用户名
	
	private String invitation_link;//邀请链接
	
	private Double pk10;//PK10返点

	private Double ssc;//时时彩返点

	private Double k3;//快三返点

	private Double kl10f;//快乐十分返点

	private Double ssl;//时时乐返点

	private Double s1x5;//十一选5返点

	private Double lhc;//六合彩返点

	private Double er8;//二8返点
	
	private String created_time;//操作时间
	
	private Integer type;//账户类型
	
	private Integer user_id; //用户id
	
	private Integer state;//账户状态

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getUser_name() {
		return user_name;
	}

	public void setUser_name(String user_name) {
		this.user_name = user_name;
	}

	public String getInvitation_link() {
		return invitation_link;
	}

	public void setInvitation_link(String invitation_link) {
		this.invitation_link = invitation_link;
	}

	public Double getPk10() {
		return pk10;
	}

	public void setPk10(Double pk10) {
		this.pk10 = pk10;
	}

	public Double getSsc() {
		return ssc;
	}

	public void setSsc(Double ssc) {
		this.ssc = ssc;
	}

	public Double getK3() {
		return k3;
	}

	public void setK3(Double k3) {
		this.k3 = k3;
	}

	public Double getKl10f() {
		return kl10f;
	}

	public void setKl10f(Double kl10f) {
		this.kl10f = kl10f;
	}

	public Double getSsl() {
		return ssl;
	}

	public void setSsl(Double ssl) {
		this.ssl = ssl;
	}

	public Double getS1x5() {
		return s1x5;
	}

	public void setS1x5(Double s1x5) {
		this.s1x5 = s1x5;
	}

	public Double getLhc() {
		return lhc;
	}

	public void setLhc(Double lhc) {
		this.lhc = lhc;
	}

	public Double getEr8() {
		return er8;
	}

	public void setEr8(Double er8) {
		this.er8 = er8;
	}

	public String getCreated_time() {
		return created_time;
	}

	public void setCreated_time(String created_time) {
		this.created_time = created_time;
	}

	public Integer getUser_id() {
		return user_id;
	}

	public void setUser_id(Integer user_id) {
		this.user_id = user_id;
	}

	public Integer getType() {
		return type;
	}

	public void setType(Integer type) {
		this.type = type;
	}

	public Integer getState() {
		return state;
	}

	public void setState(Integer state) {
		this.state = state;
	}

	@Override
	public String toString() {
		return "UserInvitationLink [id=" + id + ", user_name=" + user_name + ", invitation_link=" + invitation_link
				+ ", created_time=" + created_time + ", user_id=" + user_id + ", state=" + state + "]";
	}
	
}
