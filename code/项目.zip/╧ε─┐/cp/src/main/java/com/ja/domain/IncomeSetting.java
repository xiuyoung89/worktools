package com.ja.domain;

import java.io.Serializable;

public class IncomeSetting implements Serializable {
	
	private static final long serialVersionUID = -5049277902380009927L;
	
	private Integer id;
	private String interfaceName;
	private String belongCompany;
	private	Double minAmount;
	private Double maxAmount;
	private String companyDomain;
	private String payType;
	private String rechargeType;
	private String displayType;
	private String payGateway;
	private Integer state;
	private Integer isDefault;
	private String sort;
	private String operation;
	private String createdUser;
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getInterfaceName() {
		return interfaceName;
	}
	public void setInterfaceName(String interfaceName) {
		this.interfaceName = interfaceName;
	}
	public String getBelongCompany() {
		return belongCompany;
	}
	public void setBelongCompany(String belongCompany) {
		this.belongCompany = belongCompany;
	}
	public Double getMinAmount() {
		return minAmount;
	}
	public void setMinAmount(Double minAmount) {
		this.minAmount = minAmount;
	}
	public Double getMaxAmount() {
		return maxAmount;
	}
	public void setMaxAmount(Double maxAmount) {
		this.maxAmount = maxAmount;
	}
	public String getCompanyDomain() {
		return companyDomain;
	}
	public void setCompanyDomain(String companyDomain) {
		this.companyDomain = companyDomain;
	}
	public String getPayType() {
		return payType;
	}
	public void setPayType(String payType) {
		this.payType = payType;
	}
	public String getRechargeType() {
		return rechargeType;
	}
	public void setRechargeType(String rechargeType) {
		this.rechargeType = rechargeType;
	}
	public String getDisplayType() {
		return displayType;
	}
	public void setDisplayType(String displayType) {
		this.displayType = displayType;
	}
	public String getPayGateway() {
		return payGateway;
	}
	public void setPayGateway(String payGateway) {
		this.payGateway = payGateway;
	}
	public Integer getState() {
		return state;
	}
	public void setState(Integer state) {
		this.state = state;
	}
	public Integer getIsDefault() {
		return isDefault;
	}
	public void setIsDefault(Integer isDefault) {
		this.isDefault = isDefault;
	}
	public String getSort() {
		return sort;
	}
	public void setSort(String sort) {
		this.sort = sort;
	}
	public String getOperation() {
		return operation;
	}
	public void setOperation(String operation) {
		this.operation = operation;
	}
	public String getCreatedUser() {
		return createdUser;
	}
	public void setCreatedUser(String createdUser) {
		this.createdUser = createdUser;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((belongCompany == null) ? 0 : belongCompany.hashCode());
		result = prime * result + ((companyDomain == null) ? 0 : companyDomain.hashCode());
		result = prime * result + ((createdUser == null) ? 0 : createdUser.hashCode());
		result = prime * result + ((displayType == null) ? 0 : displayType.hashCode());
		result = prime * result + ((id == null) ? 0 : id.hashCode());
		result = prime * result + ((interfaceName == null) ? 0 : interfaceName.hashCode());
		result = prime * result + ((isDefault == null) ? 0 : isDefault.hashCode());
		result = prime * result + ((maxAmount == null) ? 0 : maxAmount.hashCode());
		result = prime * result + ((minAmount == null) ? 0 : minAmount.hashCode());
		result = prime * result + ((operation == null) ? 0 : operation.hashCode());
		result = prime * result + ((payGateway == null) ? 0 : payGateway.hashCode());
		result = prime * result + ((payType == null) ? 0 : payType.hashCode());
		result = prime * result + ((rechargeType == null) ? 0 : rechargeType.hashCode());
		result = prime * result + ((sort == null) ? 0 : sort.hashCode());
		result = prime * result + ((state == null) ? 0 : state.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		IncomeSetting other = (IncomeSetting) obj;
		if (belongCompany == null) {
			if (other.belongCompany != null)
				return false;
		} else if (!belongCompany.equals(other.belongCompany))
			return false;
		if (companyDomain == null) {
			if (other.companyDomain != null)
				return false;
		} else if (!companyDomain.equals(other.companyDomain))
			return false;
		if (createdUser == null) {
			if (other.createdUser != null)
				return false;
		} else if (!createdUser.equals(other.createdUser))
			return false;
		if (displayType == null) {
			if (other.displayType != null)
				return false;
		} else if (!displayType.equals(other.displayType))
			return false;
		if (id == null) {
			if (other.id != null)
				return false;
		} else if (!id.equals(other.id))
			return false;
		if (interfaceName == null) {
			if (other.interfaceName != null)
				return false;
		} else if (!interfaceName.equals(other.interfaceName))
			return false;
		if (isDefault == null) {
			if (other.isDefault != null)
				return false;
		} else if (!isDefault.equals(other.isDefault))
			return false;
		if (maxAmount == null) {
			if (other.maxAmount != null)
				return false;
		} else if (!maxAmount.equals(other.maxAmount))
			return false;
		if (minAmount == null) {
			if (other.minAmount != null)
				return false;
		} else if (!minAmount.equals(other.minAmount))
			return false;
		if (operation == null) {
			if (other.operation != null)
				return false;
		} else if (!operation.equals(other.operation))
			return false;
		if (payGateway == null) {
			if (other.payGateway != null)
				return false;
		} else if (!payGateway.equals(other.payGateway))
			return false;
		if (payType == null) {
			if (other.payType != null)
				return false;
		} else if (!payType.equals(other.payType))
			return false;
		if (rechargeType == null) {
			if (other.rechargeType != null)
				return false;
		} else if (!rechargeType.equals(other.rechargeType))
			return false;
		if (sort == null) {
			if (other.sort != null)
				return false;
		} else if (!sort.equals(other.sort))
			return false;
		if (state == null) {
			if (other.state != null)
				return false;
		} else if (!state.equals(other.state))
			return false;
		return true;
	}
	@Override
	public String toString() {
		return "IncomeSetting [id=" + id + ", interfaceName=" + interfaceName + ", belongCompany=" + belongCompany
				+ ", minAmount=" + minAmount + ", maxAmount=" + maxAmount + ", companyDomain=" + companyDomain
				+ ", payType=" + payType + ", rechargeType=" + rechargeType + ", displayType=" + displayType
				+ ", payGateway=" + payGateway + ", state=" + state + ", isDefault=" + isDefault + ", sort=" + sort
				+ ", operation=" + operation + ", createdUser=" + createdUser + "]";
	}
	
	
}
