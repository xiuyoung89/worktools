package com.ja.domain;

import java.io.Serializable;

public class Gendan implements Serializable{
	
    /**
	 * 
	 */
	private static final long serialVersionUID = -5910261570306017791L;

	private Integer id; //跟单订单表
    
    private String huiyuanzh;//会员帐号
    
    private Double shenglv;//胜率
    
    private Double rebate;//推荐费比例
    
    private Double beishu;//跟单倍数
    
    private Double payMoney;//跟单花费的钱
    
    private Double shouru;//中奖金额
    
    private String createTime;//创建时间
    
    private String orderNum;//订单号
    
    private String cname;//彩种名称
    
    private String cpname;//彩种英文名
    
    private String qihao; //期号
    
    private String checkNum;//开奖号码
    
    private Integer testState;// 测试单or正式单
    
    private Integer odd;//订单类型
    
    private Integer orderState;//订单状态
    
    private Integer tqState; //退钱状态
    
    private Integer counts; //退钱状态
    
    private Integer state;//发起人,跟单人

    private Integer userid;//用户id
    
    public static long getSerialversionuid() {
		return serialVersionUID;
	}
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getHuiyuanzh() {
		return huiyuanzh;
	}

	public void setHuiyuanzh(String huiyuanzh) {
		this.huiyuanzh = huiyuanzh;
	}

	public Double getShenglv() {
		return shenglv;
	}

	public void setShenglv(Double shenglv) {
		this.shenglv = shenglv;
	}

	public Double getRebate() {
		return rebate;
	}

	public void setRebate(Double rebate) {
		this.rebate = rebate;
	}

	public Double getBeishu() {
		return beishu;
	}

	public void setBeishu(Double beishu) {
		this.beishu = beishu;
	}

	public Integer getTqState() {
		return tqState;
	}

	public void setTqState(Integer tqState) {
		this.tqState = tqState;
	}

	public Double getPayMoney() {
		return payMoney;
	}

	public void setPayMoney(Double payMoney) {
		this.payMoney = payMoney;
	}

	public Double getShouru() {
		return shouru;
	}

	public void setShouru(Double shouru) {
		this.shouru = shouru;
	}

	public String getCreateTime() {
		return createTime;
	}

	public void setCreateTime(String createTime) {
		this.createTime = createTime;
	}

	public String getOrderNum() {
		return orderNum;
	}

	public void setOrderNum(String orderNum) {
		this.orderNum = orderNum;
	}

	public String getCname() {
		return cname;
	}

	public void setCname(String cname) {
		this.cname = cname;
	}

	public String getQihao() {
		return qihao;
	}

	public void setQihao(String qihao) {
		this.qihao = qihao;
	}

	public String getCheckNum() {
		return checkNum;
	}

	public void setCheckNum(String checkNum) {
		this.checkNum = checkNum;
	}

	public Integer getCounts() {
		return counts;
	}

	public void setCounts(Integer counts) {
		this.counts = counts;
	}

	public Integer getState() {
		return state;
	}

	public void setState(Integer state) {
		this.state = state;
	}

	public Integer getTestState() {
		return testState;
	}

	public void setTestState(Integer testState) {
		this.testState = testState;
	}

	public Integer getOdd() {
		return odd;
	}

	public void setOdd(Integer odd) {
		this.odd = odd;
	}

	public Integer getOrderState() {
		return orderState;
	}

	public void setOrderState(Integer orderState) {
		this.orderState = orderState;
	}

	public Integer getUserid() {
		return userid;
	}

	public void setUserid(Integer userid) {
		this.userid = userid;
	}

	public String getCpname() {
		return cpname;
	}

	public void setCpname(String cpname) {
		this.cpname = cpname;
	}

	@Override
	public String toString() {
		return "Gendan [id=" + id + ", huiyuanzh=" + huiyuanzh + ", shenglv=" + shenglv + ", rebate=" + rebate
				+ ", beishu=" + beishu + ", payMoney=" + payMoney + ", shouru=" + shouru + ", createTime=" + createTime
				+ ", orderNum=" + orderNum + ", cname=" + cname + ", cpname=" + cpname + ", qihao=" + qihao
				+ ", checkNum=" + checkNum + ", testState=" + testState + ", odd=" + odd + ", orderState=" + orderState
				+ ", tqState=" + tqState + ", counts=" + counts + ", state=" + state + ", userid=" + userid + "]";
	}

	public Gendan() {
		super();
	}

}