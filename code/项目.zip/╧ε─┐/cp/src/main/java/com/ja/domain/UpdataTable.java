package com.ja.domain;
/**
 * 更新实体类
 * @author Administrator
 *
 */
public class UpdataTable {
	
	/*private int id;*/
	/**首页*/
	private String  sy;
	/**登录页 */
	private String  login;
	/** 购彩*/
	private String  gc;
	/** 开奖页*/	
	private String  kj;
	/** 走势*/
	private String  zs;
	/** 注册*/
	private String  zhuce;
	/** 免费试玩*/
	private String  tryplay;
	/** 我的地盘*/
	private String  wd;
	/** 代理中心*/
	private String  agent;
	/** 幸运大转盘*/
	private String  zhuanpan;
	/** 充值提现*/
	private String  chongzhi;
	/**下注记录 */
	private String  xiazhuJl;
	/** 账户流水*/
	private String  zhanghuLs;
	/** 绑定银行卡*/
	private String  bankMessage;
	/** 充值反水页面*/
	private String  cZfanshui;
	/** 系统通知*/
	private String  systemNotice;
	/** 修改资料*/
	private String  editMessage;
	/** 账号安全*/
	private String  userSafe;
	/** 打码统计*/
	private String  damaTj;
	/** 代理说明*/
	private String  dailiExplain;
	/** 代理佣金*/
	private String  dailiCommission;
	/** 报表统计*/
	private String  reportStatistic;
	/** 用户管理*/
	private String  userManage;
	/** 优惠活动管理*/
	private String  yHactivity;
	/** 优惠活动详情*/
	private String  yHactivityDetail;
	/** 在线交流*/
	private String  onLineJL;
	/** 联系客服*/
	private String  contactKF;
	/** 签到*/
	private String  qiandao;
	/** 签到记录*/
	private String  kaijiangJl;
	/** 幸运赛马 */
	private String  xysm;
	/** 幸运飞艇 */
	private String  xyft;
	/** 新疆时时彩 */
	private String  xjssc;
	/** 香港六合彩 */
	private String  xg6hc;
	/** 上海11选5 */
	private String  sh11x5;
	/** 山东11选5 */
	private String  sd11x5;
	/** 排列3 */
	private String  pl3;
	/** 江苏快3 */
	private String  jsk3;
	/** 吉林快3 */
	private String  jlk3;
	/** 广西快3 */
	private String  gxk3;
	/** 广东快乐10分 */
	private String  gdkl10f;
	/** 广东11选5 */
	private String  gd11x5;
	/** 福彩3D */
	private String  fc3d;
	/** 重庆时时彩 */
	private String  cqssc;
	/** 重庆快乐十分 */
	private String  cqkl10f;
	/** 北京PK10 */
	private String  bjpk10;
	/** 北京快3 */
	private String  bjk3;
	/** 安徽快3 */
	private String  ahk3;
	/** 安徽11选5 */
	private String  ah11x5;
	/** 三分快3 */
	private String  sfk3;
	/** 2分时时彩 */
	private String  efssc;
	/** 2分PK10 */
	private String  efpk10;
	/** 北京28 */
	private String  bj28;
	/** 幸运28 */
	private String xy28;
	/** 江西11选5 */
	private String jx11x5;
	/** 加拿大28 */
	private String  jnd28;
	/**5分六合彩*/
	private String wf6hc;
	/**天津时时彩*/
	private String tjssc;
	/**上海时时乐*/
	private String shssl;

	private String efk3; //2分快3

	private String efft; //2分飞艇
	
	private String help2fk3; //2分快3 玩法说明
	
	private String help2fft; //2分飞艇 玩法说明
	/**玩法说明 */
	private String  help2fpk10;
	/**玩法说明 */
	private String  help2fssc;
	/**玩法说明 */
	private String  help3fk3;
	/**玩法说明 */
	private String  helpah11x5;
	/**玩法说明 */
	private String  helpahk3;
	/**玩法说明 */
	private String  helpbjk3;
	/**玩法说明 */
	private String  helpbjpk10;
	/**玩法说明 */
	private String  helpcqkl10f;
	/**玩法说明 */
	private String  helpcqssc;
	/**玩法说明 */
	private String  helpfc3d;
	/**玩法说明 */
	private String  helpgd11x5;
	/**玩法说明 */
	private String  helpgdkl10f;
	/**玩法说明 */
	private String  helpgxk3;
	/**玩法说明 */
	private String  helpjlk3;
	/**玩法说明 */
	private String  helpjsk3;
	/**玩法说明 */
	private String  helpjx11x5;
	/**玩法说明 */
	private String  helppl3;
	/**玩法说明 */
	private String  helpsd11x5;
	/**玩法说明 */
	private String  helpsh11x5;
	/**玩法说明 */
	private String  helpshssl;
	/**玩法说明 */
	private String  helptjssc;
	/**玩法说明 */
	private String  helpxg6hc;
	/**玩法说明 */
	private String  helpxjssc;
	/**玩法说明 */
	private String  helpxyft;
	/**玩法说明 */
	private String  helpxysm;
	/**玩法说明 */
	private String  helpbj28;
	/**玩法说明 */
	private String  helpxy28;
	/**玩法说明 */
	private String  helpjnd28;
	/**玩法说明 */
	private String  helpwf6hc;
	/**网站维护开关*/
	private  String error;
	/**百家乐下注页面*/
	private String bjllot;
	/**百家乐大厅*/
	private String bjl;
	
	public String getHelpbj28() {
		return helpbj28;
	}
	public void setHelpbj28(String helpbj28) {
		this.helpbj28 = helpbj28;
	}
	public String getHelpxy28() {
		return helpxy28;
	}
	public void setHelpxy28(String helpxy28) {
		this.helpxy28 = helpxy28;
	}
	public String getHelpjnd28() {
		return helpjnd28;
	}
	public void setHelpjnd28(String helpjnd28) {
		this.helpjnd28 = helpjnd28;
	}
	public String getHelpwf6hc() {
		return helpwf6hc;
	}
	public void setHelpwf6hc(String helpwf6hc) {
		this.helpwf6hc = helpwf6hc;
	}
	public String getBjllot() {
		return bjllot;
	}
	public void setBjllot(String bjllot) {
		this.bjllot = bjllot;
	}
	public String getBjl() {
		return bjl;
	}
	public void setBjl(String bjl) {
		this.bjl = bjl;
	}
	public String getError() {
		return error;
	}
	public void setError(String error) {
		this.error = error;
	}
	public String getTjssc() {
		return tjssc;
	}
	public void setTjssc(String tjssc) {
		this.tjssc = tjssc;
	}
	public String getShssl() {
		return shssl;
	}
	public void setShssl(String shssl) {
		this.shssl = shssl;
	}
	public String getWf6hc() {
		return wf6hc;
	}
	public void setWf6hc(String wf6hc) {
		this.wf6hc = wf6hc;
	}
	
	public String getBj28() {
		return bj28;
	}
	public void setBj28(String bj28) {
		this.bj28 = bj28;
	}
	public String getXy28() {
		return xy28;
	}
	public void setXy28(String xy28) {
		this.xy28 = xy28;
	}
	public String getJx11x5() {
		return jx11x5;
	}
	public void setJx11x5(String jx11x5) {
		this.jx11x5 = jx11x5;
	}
	public String getJnd28() {
		return jnd28;
	}
	public void setJnd28(String jnd28) {
		this.jnd28 = jnd28;
	}
	public String getHelp2fpk10() {
		return help2fpk10;
	}
	public void setHelp2fpk10(String help2fpk10) {
		this.help2fpk10 = help2fpk10;
	}
	public String getHelp2fssc() {
		return help2fssc;
	}
	public void setHelp2fssc(String help2fssc) {
		this.help2fssc = help2fssc;
	}
	public String getHelp3fk3() {
		return help3fk3;
	}
	public void setHelp3fk3(String help3fk3) {
		this.help3fk3 = help3fk3;
	}
	public String getHelpah11x5() {
		return helpah11x5;
	}
	public void setHelpah11x5(String helpah11x5) {
		this.helpah11x5 = helpah11x5;
	}
	public String getHelpahk3() {
		return helpahk3;
	}
	public void setHelpahk3(String helpahk3) {
		this.helpahk3 = helpahk3;
	}
	public String getHelpbjk3() {
		return helpbjk3;
	}
	public void setHelpbjk3(String helpbjk3) {
		this.helpbjk3 = helpbjk3;
	}
	public String getHelpbjpk10() {
		return helpbjpk10;
	}
	public void setHelpbjpk10(String helpbjpk10) {
		this.helpbjpk10 = helpbjpk10;
	}
	public String getHelpcqkl10f() {
		return helpcqkl10f;
	}
	public void setHelpcqkl10f(String helpcqkl10f) {
		this.helpcqkl10f = helpcqkl10f;
	}
	public String getHelpcqssc() {
		return helpcqssc;
	}
	public void setHelpcqssc(String helpcqssc) {
		this.helpcqssc = helpcqssc;
	}
	public String getHelpfc3d() {
		return helpfc3d;
	}
	public void setHelpfc3d(String helpfc3d) {
		this.helpfc3d = helpfc3d;
	}
	public String getHelpgd11x5() {
		return helpgd11x5;
	}
	public void setHelpgd11x5(String helpgd11x5) {
		this.helpgd11x5 = helpgd11x5;
	}
	public String getHelpgdkl10f() {
		return helpgdkl10f;
	}
	public void setHelpgdkl10f(String helpgdkl10f) {
		this.helpgdkl10f = helpgdkl10f;
	}
	public String getHelpgxk3() {
		return helpgxk3;
	}
	public void setHelpgxk3(String helpgxk3) {
		this.helpgxk3 = helpgxk3;
	}
	public String getHelpjlk3() {
		return helpjlk3;
	}
	public void setHelpjlk3(String helpjlk3) {
		this.helpjlk3 = helpjlk3;
	}
	public String getHelpjsk3() {
		return helpjsk3;
	}
	public void setHelpjsk3(String helpjsk3) {
		this.helpjsk3 = helpjsk3;
	}
	public String getHelpjx11x5() {
		return helpjx11x5;
	}
	public void setHelpjx11x5(String helpjx11x5) {
		this.helpjx11x5 = helpjx11x5;
	}
	public String getHelppl3() {
		return helppl3;
	}
	public void setHelppl3(String helppl3) {
		this.helppl3 = helppl3;
	}
	public String getHelpsd11x5() {
		return helpsd11x5;
	}
	public void setHelpsd11x5(String helpsd11x5) {
		this.helpsd11x5 = helpsd11x5;
	}
	public String getHelpsh11x5() {
		return helpsh11x5;
	}
	public void setHelpsh11x5(String helpsh11x5) {
		this.helpsh11x5 = helpsh11x5;
	}
	public String getHelpshssl() {
		return helpshssl;
	}
	public void setHelpshssl(String helpshssl) {
		this.helpshssl = helpshssl;
	}
	public String getHelptjssc() {
		return helptjssc;
	}
	public void setHelptjssc(String helptjssc) {
		this.helptjssc = helptjssc;
	}
	public String getHelpxg6hc() {
		return helpxg6hc;
	}
	public void setHelpxg6hc(String helpxg6hc) {
		this.helpxg6hc = helpxg6hc;
	}
	public String getHelpxjssc() {
		return helpxjssc;
	}
	public void setHelpxjssc(String helpxjssc) {
		this.helpxjssc = helpxjssc;
	}
	public String getHelpxyft() {
		return helpxyft;
	}
	public void setHelpxyft(String helpxyft) {
		this.helpxyft = helpxyft;
	}
	public String getHelpxysm() {
		return helpxysm;
	}
	public void setHelpxysm(String helpxysm) {
		this.helpxysm = helpxysm;
	}
	/*	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}*/
	public String getSy() {
		return sy;
	}
	public void setSy(String sy) {
		this.sy = sy;
	}
	public String getLogin() {
		return login;
	}
	public void setLogin(String login) {
		this.login = login;
	}
	public String getGc() {
		return gc;
	}
	public void setGc(String gc) {
		this.gc = gc;
	}
	public String getKj() {
		return kj;
	}
	public void setKj(String kj) {
		this.kj = kj;
	}
	public String getZs() {
		return zs;
	}
	public void setZs(String zs) {
		this.zs = zs;
	}
	public String getZhuce() {
		return zhuce;
	}
	public void setZhuce(String zhuce) {
		this.zhuce = zhuce;
	}
	public String getTryplay() {
		return tryplay;
	}
	public void setTryplay(String tryplay) {
		this.tryplay = tryplay;
	}
	public String getWd() {
		return wd;
	}
	public void setWd(String wd) {
		this.wd = wd;
	}
	public String getAgent() {
		return agent;
	}
	public void setAgent(String agent) {
		this.agent = agent;
	}
	public String getZhuanpan() {
		return zhuanpan;
	}
	public void setZhuanpan(String zhuanpan) {
		this.zhuanpan = zhuanpan;
	}
	public String getChongzhi() {
		return chongzhi;
	}
	public void setChongzhi(String chongzhi) {
		this.chongzhi = chongzhi;
	}
	public String getXiazhuJl() {
		return xiazhuJl;
	}
	public void setXiazhuJl(String xiazhuJl) {
		this.xiazhuJl = xiazhuJl;
	}
	public String getZhanghuLs() {
		return zhanghuLs;
	}
	public void setZhanghuLs(String zhanghuLs) {
		this.zhanghuLs = zhanghuLs;
	}
	public String getBankMessage() {
		return bankMessage;
	}
	public void setBankMessage(String bankMessage) {
		this.bankMessage = bankMessage;
	}
	public String getcZfanshui() {
		return cZfanshui;
	}
	public void setcZfanshui(String cZfanshui) {
		this.cZfanshui = cZfanshui;
	}
	public String getSystemNotice() {
		return systemNotice;
	}
	public void setSystemNotice(String systemNotice) {
		this.systemNotice = systemNotice;
	}
	public String getEditMessage() {
		return editMessage;
	}
	public void setEditMessage(String editMessage) {
		this.editMessage = editMessage;
	}
	public String getUserSafe() {
		return userSafe;
	}
	public void setUserSafe(String userSafe) {
		this.userSafe = userSafe;
	}
	public String getDamaTj() {
		return damaTj;
	}
	public void setDamaTj(String damaTj) {
		this.damaTj = damaTj;
	}
	public String getDailiExplain() {
		return dailiExplain;
	}
	public void setDailiExplain(String dailiExplain) {
		this.dailiExplain = dailiExplain;
	}
	public String getDailiCommission() {
		return dailiCommission;
	}
	public void setDailiCommission(String dailiCommission) {
		this.dailiCommission = dailiCommission;
	}
	public String getReportStatistic() {
		return reportStatistic;
	}
	public void setReportStatistic(String reportStatistic) {
		this.reportStatistic = reportStatistic;
	}
	public String getUserManage() {
		return userManage;
	}
	public void setUserManage(String userManage) {
		this.userManage = userManage;
	}
	public String getyHactivity() {
		return yHactivity;
	}
	public void setyHactivity(String yHactivity) {
		this.yHactivity = yHactivity;
	}
	public String getyHactivityDetail() {
		return yHactivityDetail;
	}
	public void setyHactivityDetail(String yHactivityDetail) {
		this.yHactivityDetail = yHactivityDetail;
	}
	public String getOnLineJL() {
		return onLineJL;
	}
	public void setOnLineJL(String onLineJL) {
		this.onLineJL = onLineJL;
	}
	public String getContactKF() {
		return contactKF;
	}
	public void setContactKF(String contactKF) {
		this.contactKF = contactKF;
	}
	public String getQiandao() {
		return qiandao;
	}
	public void setQiandao(String qiandao) {
		this.qiandao = qiandao;
	}
	public String getKaijiangJl() {
		return kaijiangJl;
	}
	public void setKaijiangJl(String kaijiangJl) {
		this.kaijiangJl = kaijiangJl;
	}
	public String getXysm() {
		return xysm;
	}
	public void setXysm(String xysm) {
		this.xysm = xysm;
	}
	public String getXyft() {
		return xyft;
	}
	public void setXyft(String xyft) {
		this.xyft = xyft;
	}
	public String getXjssc() {
		return xjssc;
	}
	public void setXjssc(String xjssc) {
		this.xjssc = xjssc;
	}
	public String getXg6hc() {
		return xg6hc;
	}
	public void setXg6hc(String xg6hc) {
		this.xg6hc = xg6hc;
	}
	public String getSh11x5() {
		return sh11x5;
	}
	public void setSh11x5(String sh11x5) {
		this.sh11x5 = sh11x5;
	}
	public String getSd11x5() {
		return sd11x5;
	}
	public void setSd11x5(String sd11x5) {
		this.sd11x5 = sd11x5;
	}
	public String getPl3() {
		return pl3;
	}
	public void setPl3(String pl3) {
		this.pl3 = pl3;
	}
	public String getJsk3() {
		return jsk3;
	}
	public void setJsk3(String jsk3) {
		this.jsk3 = jsk3;
	}
	public String getJlk3() {
		return jlk3;
	}
	public void setJlk3(String jlk3) {
		this.jlk3 = jlk3;
	}
	public String getGxk3() {
		return gxk3;
	}
	public void setGxk3(String gxk3) {
		this.gxk3 = gxk3;
	}
	public String getGdkl10f() {
		return gdkl10f;
	}
	public void setGdkl10f(String gdkl10f) {
		this.gdkl10f = gdkl10f;
	}
	public String getGd11x5() {
		return gd11x5;
	}
	public void setGd11x5(String gd11x5) {
		this.gd11x5 = gd11x5;
	}
	public String getFc3d() {
		return fc3d;
	}
	public void setFc3d(String fc3d) {
		this.fc3d = fc3d;
	}
	public String getCqssc() {
		return cqssc;
	}
	public void setCqssc(String cqssc) {
		this.cqssc = cqssc;
	}
	public String getCqkl10f() {
		return cqkl10f;
	}
	public void setCqkl10f(String cqkl10f) {
		this.cqkl10f = cqkl10f;
	}
	public String getBjpk10() {
		return bjpk10;
	}
	public void setBjpk10(String bjpk10) {
		this.bjpk10 = bjpk10;
	}
	public String getBjk3() {
		return bjk3;
	}
	public void setBjk3(String bjk3) {
		this.bjk3 = bjk3;
	}
	public String getAhk3() {
		return ahk3;
	}
	public void setAhk3(String ahk3) {
		this.ahk3 = ahk3;
	}
	public String getAh11x5() {
		return ah11x5;
	}
	public void setAh11x5(String ah11x5) {
		this.ah11x5 = ah11x5;
	}
	public String getSfk3() {
		return sfk3;
	}
	public void setSfk3(String sfk3) {
		this.sfk3 = sfk3;
	}
	public String getEfssc() {
		return efssc;
	}
	public void setEfssc(String efssc) {
		this.efssc = efssc;
	}
	public String getEfpk10() {
		return efpk10;
	}
	public void setEfpk10(String efpk10) {
		this.efpk10 = efpk10;
	}
	public String getEfk3() {
		return efk3;
	}
	public void setEfk3(String efk3) {
		this.efk3 = efk3;
	}
	public String getEfft() {
		return efft;
	}
	public void setEfft(String efft) {
		this.efft = efft;
	}
	public String getHelp2fk3() {
		return help2fk3;
	}
	public void setHelp2fk3(String help2fk3) {
		this.help2fk3 = help2fk3;
	}
	public String getHelp2fft() {
		return help2fft;
	}
	public void setHelp2fft(String help2fft) {
		this.help2fft = help2fft;
	}
	@Override
	public String toString() {
		return "UpdataTable [sy=" + sy + ", login=" + login + ", gc=" + gc + ", kj=" + kj + ", zs=" + zs + ", zhuce="
				+ zhuce + ", tryplay=" + tryplay + ", wd=" + wd + ", agent=" + agent + ", zhuanpan=" + zhuanpan
				+ ", chongzhi=" + chongzhi + ", xiazhuJl=" + xiazhuJl + ", zhanghuLs=" + zhanghuLs + ", bankMessage="
				+ bankMessage + ", cZfanshui=" + cZfanshui + ", systemNotice=" + systemNotice + ", editMessage="
				+ editMessage + ", userSafe=" + userSafe + ", damaTj=" + damaTj + ", dailiExplain=" + dailiExplain
				+ ", dailiCommission=" + dailiCommission + ", reportStatistic=" + reportStatistic + ", userManage="
				+ userManage + ", yHactivity=" + yHactivity + ", yHactivityDetail=" + yHactivityDetail + ", onLineJL="
				+ onLineJL + ", contactKF=" + contactKF + ", qiandao=" + qiandao + ", kaijiangJl=" + kaijiangJl
				+ ", xysm=" + xysm + ", xyft=" + xyft + ", xjssc=" + xjssc + ", xg6hc=" + xg6hc + ", sh11x5=" + sh11x5
				+ ", sd11x5=" + sd11x5 + ", pl3=" + pl3 + ", jsk3=" + jsk3 + ", jlk3=" + jlk3 + ", gxk3=" + gxk3
				+ ", gdkl10f=" + gdkl10f + ", gd11x5=" + gd11x5 + ", fc3d=" + fc3d + ", cqssc=" + cqssc + ", cqkl10f="
				+ cqkl10f + ", bjpk10=" + bjpk10 + ", bjk3=" + bjk3 + ", ahk3=" + ahk3 + ", ah11x5=" + ah11x5
				+ ", sfk3=" + sfk3 + ", efssc=" + efssc + ", efpk10=" + efpk10 + ", bj28=" + bj28 + ", xy28=" + xy28
				+ ", jx11x5=" + jx11x5 + ", jnd28=" + jnd28 + ", wf6hc=" + wf6hc + ", help2fpk10=" + help2fpk10
				+ ", help2fssc=" + help2fssc + ", help3fk3=" + help3fk3 + ", helpah11x5=" + helpah11x5 + ", helpahk3="
				+ helpahk3 + ", helpbjk3=" + helpbjk3 + ", helpbjpk10=" + helpbjpk10 + ", helpcqkl10f=" + helpcqkl10f
				+ ", helpcqssc=" + helpcqssc + ", helpfc3d=" + helpfc3d + ", helpgd11x5=" + helpgd11x5
				+ ", helpgdkl10f=" + helpgdkl10f + ", helpgxk3=" + helpgxk3 + ", helpjlk3=" + helpjlk3 + ", helpjsk3="
				+ helpjsk3 + ", helpjx11x5=" + helpjx11x5 + ", helppl3=" + helppl3 + ", helpsd11x5=" + helpsd11x5
				+ ", helpsh11x5=" + helpsh11x5 + ", helpshssl=" + helpshssl + ", helptjssc=" + helptjssc
				+ ", helpxg6hc=" + helpxg6hc + ", helpxjssc=" + helpxjssc + ", helpxyft=" + helpxyft + ", helpxysm="
				+ helpxysm + ", tjssc=" + tjssc + ", shssl=" + shssl + ", error=" + error + ", bjllot=" + bjllot
				+ ", bjl=" + bjl + "]";
	}
}
