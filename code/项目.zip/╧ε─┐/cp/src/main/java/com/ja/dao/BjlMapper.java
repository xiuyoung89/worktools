package com.ja.dao;
import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.ja.domain.BaccaratBulletin;
import com.ja.domain.Bjl;
import com.ja.domain.Bjldata;
import com.ja.domain.Dama;
import com.ja.domain.Damal;
import com.ja.domain.Liushui;
import com.ja.domain.Lotter;
import com.ja.domain.Records;

/**
 * 百家乐
 * @author Administrator
 */
public interface BjlMapper {
	/**
	 * 根据id查询用户余额
	 * @param id 会员id
	 * @return 
	 */
	 Double Money(@Param("id")Integer id);
	/**
	 * 查询百家乐赔率
	 * @param name彩种名称 中文名
	 * @param cname 彩种名称英文名
	 * @return
	 */
	 Lotter bjlpl(@Param("name") String name,@Param("cname") String cname);
	/**
	 * 根据id修改用户金额
	 * @param money 修改的金额
	 * @param id 用户id
	 * @return 成功则返回1
	 */
	 int Moneyxg(@Param("money") Double money,@Param("id") Integer id);
	/**
	 * 查询下注记录
	 * @param userid
	 * @return
	 */
	 List<Records> hRecords(@Param("userid")Integer userid);
	 /**
	  * 根据桌号查询百家乐基本设置
	  * @param tableNumber 桌号
	  * @return 查询到则返回BaccaratBulletin 对象 没有查询到则返回null
	  */
	 BaccaratBulletin bfb(@Param("tableNumber")Integer tableNumber);
	
	 List<BaccaratBulletin> tableNumber();
	/**
	 * 查询历史开奖记录
	 * @param zh
	 * @return
	 */
	 List<Bjldata> history(@Param("tableNumber")Integer tableNumber);
	 
	/**
	* 删除试玩账号订单
	* @return
	*/
	int deletebjl(Integer userid);
	
	/**
	 * 插入百家乐开奖数据
	 * @param list
	 * @return
	 */
	int insertBjlData(@Param("list")List<Bjldata> list);
	/**
	 * 查询数据库里面百家乐最新开奖的一条数据
	 * @param tableNumber
	 * @param nowTime
	 * @return
	 */
	Bjldata NewestData(@Param("tableNumber")Integer tableNumber,@Param("nowTime")String nowTime);
	/**
	 * 插入用户下注信息
	 * @param b
	 * @return
	 */
	int insertBets(@Param("b")Bjl b);
	/**
	 * 查询下期开奖数据    传入当前期号 返回当期期号的整条数据
	 * @param issueNumber 期号
	 * @param tableNumber桌号
	 * @return  查询到则返回 Bjldata对象  如果没有查询到则返回null
	 */
	Bjldata queryBjlData(@Param("issueNumber")String issueNumber,@Param("tableNumber")Integer tableNumber);
	
	/**
	 * 查询当期开奖数据   传入当前期号 返回当期期号的整条数据
	 * @param issueNumber 期号
	 * @param tableNumber桌号
	 * @return  查询到则返回 Bjldata对象  如果没有查询到则返回null
	 */
	Bjldata queryBjlDatas(@Param("issueNumber")String issueNumber,@Param("tableNumber")Integer tableNumber);
	/**
	 * 查询用户下注信息
	 * @param issueNumber
	 * @param tableNumber
	 * @return
	 */
	List<Bjl> queryBetInformation(@Param("issueNumber")String issueNumber,@Param("tableNumber")Integer tableNumber);
	/**
	 * 更新开奖状态和数据
	 * @param b
	 * @return
	 */
	int updataBjlData(@Param("b")Bjldata b);
	/**
	 * 更新开奖状态  后台已经设置 无需在更新一次开奖数据
	 * @param b 数据对象
	 * @return 成功则返回1
	 */
	int updataBjlDatas(@Param("b")Bjldata b);
	/**
	 * 查询百家乐开奖数据
	 * @param b
	 * @return
	 */
	Bjldata takeAwayTheAwardData(@Param("b")Bjl b);
	/**
	 * 更新控制数据
	 * @param str
	 * @return
	 */
	int updateControl(@Param("control")String control,@Param("tableNumber")Integer tableNumber);
	/**
	 * 
	 * @param lotteryTimes
	 * @param tableNumber
	 * @return
	 */
	int lotteryTimes(@Param("lotteryTimes")Integer lotteryTimes,@Param("tableNumber")Integer tableNumber);
	/**
	 * 更新用户下注信息
	 * @param b
	 * @return
	 */
	int modifyUserNoteInformation(@Param("b")Bjl b);
	/***
	 * 用户下注以及中奖的金额信息
	 * @param table_num 桌号
	 * @param period 期号
	 * @param session session对象
	 * @return
	 */
	List<Bjl> findUserMoneyInfo(@Param("userid")Integer userid,@Param("tableNumber")String tableNumber,@Param("issueNumber")String issueNumber);
	/**
	 * 添加用户流水表
	 * @param liushui 流水对象相关字段
	 * @return
	 */
	int addWater(@Param("liushui")Liushui liushui);
	/**
	 * 添加用户打码记录
	 * @param dama
	 * @return
	 */
	int addCode(@Param("dama")Dama dama);
	/**
	 * 查询用户打码
	 * @param userid 用户ID
	 * @return
	 */
	Damal queryCode(@Param("userid")Integer userid);
	/**
	 * 修改用户打码量   下注前调用   修改new_damaliang字段
	 * @param damal
	 * @return
	 */
	int modifyUserCoding(@Param("damal")Damal damal);
	/**
	 * 修改用户打码量  派奖后调用 修改damaliang字段
	 * @param damal
	 * @return
	 */
	int modifyUserCodings(@Param("damal")Damal damal);
	/**
	 * 新建用户打码量
	 * @param damal
	 * @return
	 */
	int newCode(@Param("damal")Damal damal);
	/**
	 * 查询最新开奖一期的数据
	 * @param tableNumber   卓号
	 * @return 查询到数据则返回Bjldata对象 如果没有查询到则返回null
	 */
	Bjldata QueryTheLatestPrizeOpeningData(@Param("tableNumber")Integer tableNumber);
	/**
	 * 查询百家乐开奖数据 默认查询前50条
	 * @param tableNumber  房间号
	 * @return 查询到数据则返回list集合包含bjl对象 如果没有查询到则返回一个空集合
	 */
	List<Bjldata>  bjlkaijiangjilu(@Param("tableNumber")Integer tableNumber);
	/**
	 * 查询百家乐开奖数据
	 * @param time 查询那一天的 日期
	 * @param tableNumber查询那一桌
	 * @return 查询到数据则返回list集合 没有查询到则返回一个空集合
	 */
	List<Bjldata> findTrendBjl(@Param("time")String time,@Param("tableNumber")Integer tableNumber,@Param("issueNumber")String issueNumber);
	
	/**
	 * 根据数据库下标id查询用户下注记录
	 * @param id  数据库下标id
	 * @return 查询到则返回Bjl对象数据  没有查询到则返回null
	 */
	Bjl bettingRecord(@Param("name")String name,@Param("id")Integer id);
	
}
