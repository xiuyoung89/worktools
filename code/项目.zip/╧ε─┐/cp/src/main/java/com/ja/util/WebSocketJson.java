package com.ja.util;

import java.io.Serializable;

import com.alibaba.fastjson.JSONObject;
import com.ja.controller.ChatWebSocketHandler;
import com.ja.controller.ChatWebSocketHandlerht;

public class WebSocketJson  implements Serializable{
	private static final long serialVersionUID = 1L;
		private String message;//状态信息
		private Object data;//具体数据
		private String name;//用户名
		private Integer type;//数据类型 
		
		/**用户
		 * 0 - 更新页面
		 * 1 - 网站维护 是否开启和关闭
		 * 2 - 聊天室开关 
		 * 3 - 彩种管理 开启还是关闭
		 * 4 - 用户被后台管理员禁用
		 * 5 - 用户密码已修改 从新登陆
		 * 6 - 会员被强制下线
		 * 7 - 账号在另外一个地方登陆，被强制下线
		 * 8 - 用户自己改了密码被强制下线 从新登陆
		 * 9 - 充值成功提示
		 * 10 - 充值失败提示
		 */
		
		/**
		 * 后台
		 * 0 - 用户充值提示
		 * 1 - 用户提款提示
		 * 2 - 在线人数
		 * 3 - 某个会员登陆啦
		 * 4 - 有会员注册并登陆成功
		 * 5 - 开奖数据异常   传0 没有异常数据  传1 有异常数据
		 * 6 - 用户系统彩下注信息
		 */
		
		/**
		 * 构造方法
		 * @param message 信息状态
		 * @param type 数据类型
		 * @param data 具体数据
		 */
		public WebSocketJson(Integer type,Object data){
			//this.message = message;
			//this.name = name;
			this.type = type;
			this.data = data;
		}
		public WebSocketJson(Integer type,String name,Object data){
			//this.message = message;
			this.name = name;
			this.type = type;
			this.data = data;
		}
		public String getMessage() {
			return message;
		}
		public void setMessage(String message) {
			this.message = message;
		}
		public Object getData() {
			return data;
		}
		public void setData(Object data) {
			this.data = data;
		}
		public String getName() {
			return name;
		}
		public void setName(String name) {
			this.name = name;
		}
		public Integer getType() {
			return type;
		}
		public void setType(Integer type) {
			this.type = type;
		}
		public static long getSerialversionuid() {
			return serialVersionUID;
		}
		/**手机端用户
		 * 发送给指定用户
		 */
		public void send() {
			//SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			//data.put("time", sdf.format(new Date()));//当前系统时间
			JSONObject data = new JSONObject();
			//data.put("message", message);//状态信息
			data.put("data", this.data);//具体数据
			data.put("type", type);//数据类型
			ChatWebSocketHandler c = new ChatWebSocketHandler();
			c.send(name, JSONObject.toJSONString(data));
		}
		/**手机端用户
		 * 发送给全部用户
		 */
		public void sendAll() {
			//SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			//data.put("time", sdf.format(new Date()));//当前系统时间
			JSONObject data = new JSONObject();
			//data.put("message", message);//状态信息
			data.put("data", this.data);//具体数据
			data.put("type", type);//数据类型
			ChatWebSocketHandler c = new ChatWebSocketHandler();
			c.sendAll(JSONObject.toJSONString(data));
		}
		
		
		
		/**后台
		 * 发送给指定用户
		 */
		public void sendHt() {
			//SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			//data.put("time", sdf.format(new Date()));//当前系统时间
			JSONObject data = new JSONObject();
			//data.put("message", message);//状态信息
			data.put("data", this.data);//具体数据
			data.put("type", type);//数据类型
			ChatWebSocketHandlerht c = new ChatWebSocketHandlerht();
			c.send(name, JSONObject.toJSONString(data));
		}
		/** 后台
		 * 发送给全部用户
		 */
		public void sendAllHt() {
			//SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			//data.put("time", sdf.format(new Date()));//当前系统时间
			JSONObject data = new JSONObject();
			//data.put("message", message);//状态信息
			data.put("data", this.data);//具体数据
			data.put("type", type);//数据类型
			ChatWebSocketHandlerht c = new ChatWebSocketHandlerht();
			c.sendAll(JSONObject.toJSONString(data));
		}
}
