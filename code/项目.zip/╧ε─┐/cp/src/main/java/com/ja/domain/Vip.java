package com.ja.domain;
/**
 * 会员等级 实体类
 * @author Administrator
 *
 */
public class Vip {
	private Integer id;
	
	private String title;//会员头衔
	
	private String grade;//等级 VIP几
	
	private Double amountOfMoney;//成长值金额

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getGrade() {
		return grade;
	}

	public void setGrade(String grade) {
		this.grade = grade;
	}

	public Double getAmountOfMoney() {
		return amountOfMoney;
	}

	public void setAmountOfMoney(Double amountOfMoney) {
		this.amountOfMoney = amountOfMoney;
	}

	@Override
	public String toString() {
		return "Vip [id=" + id + ", title=" + title + ", grade=" + grade + ", amountOfMoney=" + amountOfMoney + "]";
	}
	
	
}
