package com.ja.dao;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.ja.domain.Jine;
import com.ja.domain.PagingData;
import com.ja.domain.PayMoney;

public interface JineMapper {
	
	/**
	   *   方法名：addJilu   
	   *   描述：      添加充值以及提款记录                 TODO：充值记录    
	   *   参数：    @param jine 充值提款信息
	   *   参数：    @return 
	 * @return: int
	 */
	int addJilu(@Param("z") Jine z);
	

	/** 查询所有充值记录 
	 * @param model 
	 * @param lineCount 
	 * @param startIndex */
	List<Jine> getAllJl(@Param("startIndex")Integer startIndex, @Param("lineCount")int lineCount, @Param("model")int model);

	/** 模糊查询充值记录 
	 * @param lineCount 
	 * @param startIndex */
	List<Jine> getTypeJl(@Param("startIndex")Integer startIndex, @Param("lineCount")Integer lineCount, @Param("z") Jine z, @Param("date1") String date1, @Param("date2") String date2,@Param("model")int model);

	/** 查询所有提款记录 
	 * @param i 
	 * @param integer2 
	 * @param integer */
	List<Jine> getTikuanJl(@Param("startIndex")Integer startIndex, @Param("lineCount")Integer lineCount, @Param("model")int i);

	/** 模糊查询提款记录 
	 * @param i 
	 * @param integer2 
	 * @param integer */
	List<Jine> getTikuanTypeJl(@Param("startIndex")Integer startIndex, @Param("lineCount")Integer lineCount, @Param("z") Jine z, @Param("date1") String date1, @Param("date2") String date2, @Param("model") int i);

	/** 查询今日充值-提款 */
	Jine cxToday(String date);

	/** 最后充值金额-时间 */
	Jine zhCzJineJl(Integer id);

	/** 最后提款金额-时间 */
	Jine zhTkJineJl(Integer id);

	/** 根据用户id查询当前用户的充值信息 */
	List<Jine> getOneCzJl(@Param("z") Jine z, @Param("date1") String date1, @Param("date2") String date2,
			@Param("id") Integer id);

	/** 根据用户id查询当前用户的提款信息 */
	List<Jine> getOneTkJl(@Param("z") Jine z, @Param("date1") String date1, @Param("date2") String date2,
			@Param("id") Integer id);

	/** 查询用户今日充值 */
	double getCzTodyJl(@Param("id") Integer id, @Param("date") String time);

	/** 查询用户本月充值 */
	double getCzMonthJl(Integer id);

	/** 审核提款 */
	int upTikuanSh(@Param("z") Jine z);

	/** 查询用户的充值记录 */
	List<Jine> onechongzhi(Integer id);

	/** 查询用户提款记录 */
	List<Jine> onetikuan(Integer id);

	/** 充值提款记录 */
	List<Jine> getAllJlLimit();

	/** 今日提款次数 */
	int getTikuanCount(@Param("id") Integer id, @Param("date") String time);

	/** 今日提款成功次数 */
	int getTikuanCount1(@Param("id") Integer id, @Param("date") String time);

	/** 锁定 */
	int updateTikuansd(@Param("j") Jine j);

	double getTikuanSum(@Param("id") Integer id, @Param("date") String time);

	double getTikuanSum1(@Param("id") Integer id, @Param("date") String time);

	int getChongzhiCount(@Param("id") Integer id, @Param("date") String time);

	double getChongzhiSum(@Param("id") Integer id, @Param("date") String time);

	/** 充值-提款-语音提示 */
	List<Jine> getByStateAllYuyin();
	
	/**上个月充值金额*/
	double getCzLastMonthJl(@Param("id") Integer id, @Param("date") String times);
	
	/**查询没有显示过的信息*/
	Jine findInfoData();
	
	/**查询没有显示过的信息*/
	int updateInfoData(Integer id);
	
	/**
	 * 修改在线充值状态
	 * @param state 状态信息
	 * @param orderNum 充值订单号
	 * @param time 
	 * @return
	 */
	int updateRechargeState(@Param("state")String state, @Param("orderNum")String orderNum, @Param("time")String time);

	/**
	 * 查询有没有当前充值信息
	 * @param orderNum
	 * @return
	 */
	Jine findJineInfo(String orderNum);
	
	/**
	 * 查询未处理成功的提款订单
	 * @return
	 */
	List<Jine> findJineByState(@Param("id") Integer id);
	
	/**
	 * 查询今日成功提款次数
	 * @return
	 */
	int findJineByStateSuccess(String time,Integer userid);
	
	/**
	 * 查询单条记录的信息
	 * @param id 单条id
	 * @return
	 */
	Jine findByIdJineInfo(Integer id);
	
	/**
	 * 查询今天的充值提款记录
	 * @param currTime 当前时间
	 * @return
	 */
	List<Jine> findByTimeDetails(String currTime);
	
	/**
	 * 查询用户今日的提款次数
	 * @param user_id 用户id
	 * @param date 查询实际
	 * @return
	 */
	List<Jine> findByDateUserIdInfo(@Param("user_id")Integer user_id, @Param("date")String date); 

	/**
	 *   方法名：getAllJlCounts   
	 *   描述：                       TODO   
	 *   参数：    @return 
	 * @return: Integer
	 */
	Integer getAllJlCounts();
	

	/**
	 * 
	 *   方法名：getTypeJlCounts   
	 *   描述：                       TODO   
	 *   参数：    @param jine
	 *   参数：    @param date1
	 *   参数：    @param date2
	 *   参数：    @return 
	 * @return: Integer
	 */
	Integer getTypeJlCounts(@Param("z") Jine z, @Param("date1") String date1, @Param("date2") String date2);
	
	/**
	 * 
	 *   方法名：getTikuanJlCounts   
	 *   描述：                       TODO   
	 *   参数：    @return 
	 * @return: Integer
	 */
	Integer getTikuanJlCounts();

	/**
	 * 
	 *   方法名：getTikuanTypeJlCounts   
	 *   描述：                       TODO   
	 *   参数：    @param jine
	 *   参数：    @param date1
	 *   参数：    @param date2
	 *   参数：    @return 
	 * @return: Integer
	 */
	Integer getTikuanTypeJlCounts(@Param("z") Jine z, @Param("date1") String date1, @Param("date2") String date2);

	/**
	 * 
	   *   方法名：findMoneyRecordCounts   
	   *   描述：     查询充值提现记录数                  TODO   
	   *   参数：    @param jine  
	   *   参数：    @return 
	 * @return: Integer
	 */
	int findMoneyRecordCounts1(@Param("jine")Jine jine);
	int findMoneyRecordCounts2(@Param("jine")Jine jine);
	
	/**
	 * 根据条件查询个人的充值提现记录 
	   *   方法名：findMoneyRecord   
	   *   描述：                       TODO   
	   *   参数：    @param jine
	   *   参数：    @param paging
	   *   参数：    @return 
	 * @return: List<Jine>
	 */
	List<Jine> findMoneyRecord1(@Param("paging")PagingData paging, @Param("jine")Jine jine);
	List<Jine> findMoneyRecord2(@Param("paging")PagingData paging, @Param("jine")Jine jine);
	
	/**
	 * 		
	   *   方法名：findUserTikuanInfo   
	   *   描述：    查询今日提款信息                   TODO   
	   *   参数：    @param id
	   *   参数：    @return 
	 * @return: Jine
	 */
	Integer findUserTikuanInfoCounts(Integer userid);
	Double findUserTikuanInfoSumMoney(Integer userid);

	/**
	 * 
	   *   方法名：findByTimeRechargeMoney   
	   *   描述：    根据时间查询充值金额                   TODO   
	   *   参数：    @param id
	   *   参数：    @param time
	   *   参数：    @return 
	 * @return: Double   
	 */
	Double findByTimeRechargeMoney(@Param("user_id")Integer user_id, @Param("time")String time);

	
	/**
	 * 统计数据库里面还有多少条充值数据没有处理的
	 * @return  返回数据库里面没有处理的充值数据的总条数
	 */
	Integer getCount();
	
	
	/**
	 * 统计数据库里面还有多少条提款数据没有处理的
	 * @return  返回数据库里面没有处理的提款数据的总条数
	 */
	Integer getCountTk();
	/**
	 * 查询数据库里面没有完成的订单  查看是否充值到账 如果没有到账的 则请求查看是否已经支付
	 * @return 返回数据库里面没有交易的订单  就是没有支付的充值订单
	 */
	List<PayMoney> payMoney();
	
}
