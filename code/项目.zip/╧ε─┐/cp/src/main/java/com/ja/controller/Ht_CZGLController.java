package com.ja.controller;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Timer;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.ja.check.action.CheckOrder;
import com.ja.check.action.SystemLotter;
import com.ja.check.data.CpData;
import com.ja.check.data.PeriodData;
import com.ja.check.datas.GetAbnormalData;
import com.ja.check.datas.OpenData;
import com.ja.check.datas.Publicmethods;
import com.ja.config.WebsiteStateConfig;
import com.ja.domain.AdminUser;
import com.ja.domain.Attribute;
import com.ja.domain.ColorVariety;
import com.ja.domain.Data;
import com.ja.domain.GcRebate;
import com.ja.domain.Lotter;
import com.ja.domain.Order;
import com.ja.domain.PagingData;
import com.ja.domain.XitongcaiJl;
import com.ja.sevice.BjlService;
import com.ja.sevice.IDataService;
import com.ja.sevice.ILotteryService;
import com.ja.sevice.IOrderService;
import com.ja.sevice.KongzhiService;
import com.ja.sevice.OperationlogService;
import com.ja.sevice.XitongcaiJlService;
import com.ja.util.DateUtil;
import com.ja.util.ExChangeUtil;
import com.ja.util.JsonResult;
import com.ja.util.WebSocketJson;

/**
 * 项目名称：cp   
 * 类名称：Ht_CZGLController.java   
 * 类描述：   
 * 创建人：   GL
 * 创建时间：2019年2月22日 下午2:13:40   
 * @version v1.0.0
 */
@Controller
@RequestMapping("/czgl")
public class Ht_CZGLController {

	@Autowired
	private ILotteryService lotterService;

	@Autowired
	private IOrderService orderService;

	@Autowired
	private IDataService dataService;

	@Autowired
	private XitongcaiJlService xitongcaiJlService;

	@Autowired
	private KongzhiService kongzhiService;

	@Autowired
	private OperationlogService operationlogService;
	
	@Autowired
	private BjlService bjlService;

	public static int addCount = 0;//生肖属性自增
	
	public static Timer timer = new Timer(); //彩种开启定时器
	
	public static int state = -1; //彩种开启状态1
	
	public static boolean isFirstTime = true; //彩种开启状态2
	
	/**
	 * 
	 * ----TODO: 彩票投注管理
	 * 
	 */
	
	/**
	 * 方法名：lotteryBettingPage 
	 * 描述：    彩种投注页面                   
	 * 参数：    @return 
	 * @return: ModelAndView
	 */
	@RequestMapping("/lotteryBettingPage")
	public ModelAndView lotteryBettingPage() {
		ModelAndView m = new ModelAndView("htgl/cptzjl");
		m.addObject("lottery", lotterService.getAllLotter());
		return m;
	}
	
	/**
	 * 方法名：findUserBettingRecord 
	 * 描述：     根据条件查询用户的投注记录                  
	 * 参数：    @param paging 分页信息
	 * 参数：    @param state 订单状态
	 * 参数：    @param date1 投注时间
	 * 参数：    @param period 投注期号
	 * 参数：    @param cname1 投注彩种名称
	 * 参数：    @param huiyuanzh 投注用户名称
	 * 参数：    @return 
	 * @return: String
	 */
	@ResponseBody 
	@RequestMapping("/findUserBettingRecord")
	public String findUserBettingRecord(PagingData paging,Integer state, String date1,String date2, String period, String cname1,String huiyuanzh) {
		Order order = new Order();
		order.setHuiyuanzh(huiyuanzh);
		order.setCname(cname1);
		order.setPeriod(period);
		order.setState(state);
		paging.setAllCount(orderService.getMhAllJlCounts(order,date1,date2));
		paging.setList(orderService.getMhAllJl(paging.getStartIndex(),paging.getLineCount(),state, date1,date2, period, cname1, huiyuanzh,1));
		return PagingData.pagingData(paging);  
		
	}
	
	/**
	 * 方法名：findByIdUsesrBettingRecord 
	 * 描述：     根据用户id查询用户的投注详情                 
	 * 参数：    @param id 用户id 
	 * 参数：    @return 
	 * @return: JsonResult
	 */
	@ResponseBody 
	@RequestMapping("/findByIdUsesrBettingRecord")
	public JsonResult findByIdUsesrBettingRecord(Integer id) {
		return new JsonResult("success",orderService.getOneOrder(id));  
	}
	
	/**
	 * 方法名：deleteBettingInfo 
	 * 描述：    根据订单id删除用户的投注信息                   
	 * 参数：    @param id 投注id
	 * 参数：    @param session
	 * 参数：    @return 
	 * @return: JsonResult
	 */
	@ResponseBody
	@RequestMapping("/deleteBettingInfo")
	public JsonResult deleteBettingInfo(Integer id, HttpSession session) {
		Order order = orderService.getOneOrder(id);
		int line = lotterService.iddelete(id);
		String remarks = "删除了用户：" + order.getHuiyuanzh() + "的" + order.getCname1() + ",第"+order.getPeriod()+"期的一条投注信息！";
		operationlogService.addOperationlog((AdminUser)session.getAttribute("admin1"),remarks,"彩票投注管理");
		return new JsonResult("success",line);
	}
	
	/**
	 * 
	 * ----TODO: 彩票开奖管理
	 * 
	 * 
	 */
	

	/**
	 * 方法名：lotteryCheckPage 
	 * 描述：    彩票开奖页面                   
	 * 参数：    @param cname
	 * 参数：    @return 
	 * @return: ModelAndView
	 */
	@RequestMapping("/lotteryCheckPage")
	public ModelAndView lotteryCheckPage(String cname) {
		ModelAndView m = new ModelAndView("htgl/kaijiang");
		m.addObject("lottery", lotterService.getAllLotter());
		return m;
	}
	
	/**
	 * 方法名：findSameTypeLottery 
	 * 描述：    查询彩种的分类                 
	 * 参数：    @return 
	 * @return: JsonResult
	 */
	@ResponseBody
	@RequestMapping("/findSameTypeLottery")
	public JsonResult findSameTypeLottery() {
		return new JsonResult("success", lotterService.findSameTypeLottery());
	}

	/**
	 * 方法名：findByCnameCheckRecord 
	 * 描述：    根据彩种名称查询开奖记录                   
	 * 参数：    @param paging 分页信息
	 * 参数：    @param cname 彩种名称
	 * 参数：    @return 
	 * @return: String
	 */
	@ResponseBody
	@RequestMapping("/findByCnameCheckRecord")
	public String findByCnameCheckRecord(PagingData paging,String cname) {
		paging.setAllCount(dataService.getCheckDataCounts(cname));
		paging.setList(dataService.getCheckData(paging.getStartIndex(),paging.getLineCount(),cname,1));
		return PagingData.pagingData(paging);
	}

	/**
	 * 方法名：likeFindByConditionCheckRecord 
	 * 描述：    根据条件查询开奖记录                   
	 * 参数：    @param paging 分页信息
	 * 参数：    @param data 查询条件
	 * 参数：    @param date1 开始时间
	 * 参数：    @param date2 结束时间
	 * 参数：    @return 
	 * @return: String
	 */
	@ResponseBody
	@RequestMapping("/likeFindByConditionCheckRecord")
	public String likeFindByConditionCheckRecord(PagingData paging,Data data, String date1, String date2) {
		paging.setAllCount(dataService.getMhAllDataCounts(data, date1, date2));
		paging.setList(dataService.getMhAllData(paging.getStartIndex(),paging.getLineCount(),data, date1, date2,1));
		return PagingData.pagingData(paging);
	}

	/**
	 *   方法名：oneClickUserRefund   
	 *   描述：    用户投注开奖异常一键点击退钱                      
	 *   参数：    @param session
	 *   参数：    @param data 退钱信息
	 *   参数：    @param cnams 退钱彩种名称
	 *   参数：    @return 
	 * @return: JsonResult
	 */
	@ResponseBody
	@RequestMapping("/oneClickUserRefund")
	public JsonResult oneClickUserRefund(HttpSession session, Data data, String cnams) {
		AdminUser admin = (AdminUser) session.getAttribute("admin1");
		data.setGameNameInChinese(cnams);
		GetAbnormalData.haveBeenAwardedAPrize(data);//删除正在获取异常数据的集合
		JsonResult jsonResult = orderService.oneKeyRefund(data,admin);
		int countAbnormalData = dataService.getAbnormalData();
		if(countAbnormalData <= 0) {
			WebSocketJson w = new WebSocketJson(5,0);//开奖数据异常   传0 没有异常数据  传1 有异常数据
			w.sendAllHt();
		}
		return jsonResult;
	}
	
	
	/**
	 * 
	 * ----TODO: 私彩预设管理 
	 * 
	 */
	
	/**
	 * 方法名：systemLotteryPresetRecordPage 
	 * 描述：    系统彩预设界面                   
	 * 参数：    @return 
	 * @return: ModelAndView
	 */
	@RequestMapping("/systemLotteryPresetRecordPage")
	public ModelAndView systemLotteryPresetRecordPage() {
		ModelAndView m = new ModelAndView("htgl/xitongcaiyushe"); 
		m.addObject("xitongcz", lotterService.xitongcaicz());
		return m; 
	}

	/**
	 * 方法名：findSystemLotteryPresetRecord 
	 * 描述：     查询系统彩预设记录                  
	 * 参数：    @param paging 分页信息
	 * 参数：    @return 
	 * @return: String
	 */
	@ResponseBody
	@RequestMapping("/findSystemLotteryPresetRecord")
	public String findSystemLotteryPresetRecord(PagingData paging) { 
		paging.setAllCount(xitongcaiJlService.getPageDataCounts());
		paging.setList(xitongcaiJlService.getPageData(paging.getStartIndex(), paging.getLineCount(),1));
		return PagingData.pagingData(paging);
	}

	/**
	 * 方法名：findByConditionSystemLotteryPresetRecord 
	 * 描述：     根据条件查询系统彩预设记录                  
	 * 参数：    @param cname 彩种名称
	 * 参数：    @param period 开奖期号
	 * 参数：    @param date 开奖时间
	 * 参数：    @param paging 分页信息
	 * 参数：    @return 
	 * @return: String
	 */
	@ResponseBody
	@RequestMapping("/findByConditionSystemLotteryPresetRecord")  
	public String findByConditionSystemLotteryPresetRecord(String cname,String period,String date1,String date2,PagingData paging) {
		if("".equals(cname) || cname == null){
			cname = "2fpk10";
		}
		Data data = new Data();
		data.setCname(cname);
		data.setPeriod(period);
		paging.setAllCount(xitongcaiJlService.findSystemJlCounts(data,date1,date2));
		List<XitongcaiJl> list = xitongcaiJlService.findSystemJl(paging.getStartIndex(), paging.getLineCount(),cname,period, date1,date2,1);
		for(XitongcaiJl x : list){
			if(x.getLotterNumber() == null){
				Data d = dataService.lotteryData(x.getCname(), x.getPeriod());
				if(d != null){
					x.setLotterNumber(d.getLotternumber());
				}
			}
		}
		paging.setList(list);
		Data d = dataService.findNextNextPeriod(cname,1);
		if(d != null){
			paging.setReplace2(d.getNextStopOrderTimeEpoch());
		}
		return PagingData.pagingData(paging);
	}
	
	/**
	 * 方法名：findByCnameAndPeriodChekcInfo 
	 * 描述：     根据彩种名称和期号查询彩种当前开奖信息                  
	 * 参数：    @param cName 彩种名称
	 * 参数：    @param period 开奖期号
	 * 参数：    @return 
	 * @return: JsonResult
	 */
	@RequestMapping("/findByCnameAndPeriodChekcInfo")
	@ResponseBody
	public JsonResult findByCnameAndPeriodChekcInfo(String cName,String period) {
		return new JsonResult(null,orderService.Inquiries(period,cName));
	}
	
	/**
	 * 方法名：systemLotteryPresetCheckNum 
	 * 描述：     系统彩预设和修改开奖号码                  
	 * 参数：    @param data 预设信息
	 * 参数：    @param cnames 预设彩种英文名
	 * 参数：    @param name 预设彩种中文名
	 * 参数：    @param session
	 * 参数：    @return 
	 * @return: JsonResult
	 */
	@ResponseBody
	@RequestMapping("/systemLotteryPresetCheckNum")
	public JsonResult systemLotteryPresetCheckNum(Data data, String cnames, String name,HttpSession session) {
		Data das = dataService.pueryCurrentPeriod(data.getCname(), data.getPeriod());
		if(das.getLotternumber() != null){
			return new JsonResult("已经开奖了",10);
		}
		Data d1 = dataService.lotteryData(data.getCname(),data.getPeriod());
		if(d1 != null){
			if(d1.getCname().equals(data.getCname()) && d1.getPeriod().equals(data.getPeriod())){
				return new JsonResult("已经预设过了",10);
			}
		}
		data.setStatus(2);
		//修改当期的开奖状态
		dataService.addLiuheCheck(data);
		//保存当期它预设的开奖数据
		dataService.Preservation(data);
		//修改下一期的开奖状态
		Data d = dataService.Id(das.getId(), das.getCname());
		d.setStatus(2);
		int line = dataService.addLiuheCheck(d);
		String remarks ="设置了彩种为：" +data.getGameNameInChinese() + "第：" + data.getPeriod() + "期的开奖号码为："+data.getLotternumber()+"！";
		operationlogService.addOperationlog((AdminUser)session.getAttribute("admin1"),remarks,"私彩预设管理");
		return new JsonResult("success", line);
	}
	/**
	 * 
	 * @param data
	 * @param cnames
	 * @param name
	 * @param session
	 * @return
	 */
	@ResponseBody
	@RequestMapping("/systemLotterUpData")
	public JsonResult systemLotterUpData(Data data,HttpSession session) {
		if(data == null){
			return new JsonResult("-1",-1);//开奖号码数据不能为空
		}
		if(data.getCname() == null || data.getPeriod() == null || data.getLotternumber() == null){
			return new JsonResult("-1",-1);//开奖号码数据不能为空
		}
		data.setCname(data.getCname().trim());
		data.setPeriod(data.getPeriod().trim());
		data.setLotternumber(data.getLotternumber().trim());
		dataService.systemLotterUpData(data);
		String remarks ="修改了彩种为：" +data.getGameNameInChinese() + "第：" + data.getPeriod() + "期的开奖号码为："+data.getLotternumber()+"！";
		operationlogService.addOperationlog((AdminUser)session.getAttribute("admin1"),remarks,"私彩预设管理");
		return new JsonResult("success", 0);
	}
	
	/**
	 * 
	 * ----TODO: 港彩预设管理
	 * 
	 */
	
	
	/**
	 * 方法名：hongKongLotteryPage 
	 * 描述：    港彩预设页面                   
	 * 参数：    @return 
	 * @return: String
	 */
	@RequestMapping("/hongKongLotteryPage")
	public String hongKongLotteryPage() {
		return "/htgl/xianggangliuhecaishezhi";
	}

	/**
	 * 方法名：hongKongLotteryPresetRecord 
	 * 描述：     港彩预设记录                  
	 * 参数：    @return 
	 * @return: JsonResult
	 */
	@ResponseBody
	@RequestMapping("/hongKongLotteryPresetRecord")
	public JsonResult hongKongLotteryPresetRecord() {
		return new JsonResult("success", dataService.getAllLiuhePreset());
	}
	
	/**
	 * 方法名：hongKongLotteryPreset 
	 * 描述：    六合彩预设开奖期号和开奖时间                 
	 * 参数：    @param data 预设信息
	 * 参数：    @param cnames 彩种名称
	 * 参数：    @param session
	 * 参数：    @return 
	 * @return: JsonResult
	 */
	@ResponseBody
	@RequestMapping("/hongKongLotteryPreset")
	public JsonResult hongKongLotteryPreset(Data data, String cnames, HttpSession session) {
		Data data1 = dataService.Verification(data.getCname(), data.getPeriod());
		if (data1 != null) {
			return new JsonResult("success", 10);
		}
		Data d = dataService.previousIssue(data.getCname(),data.getPeriod());
		if(d == null) {
			return new JsonResult("success",11);
		}
		int num = dataService.xg6hc(data.getCname());
		num++;
		data.setGameNameInChinese(cnames);
		data.setXg6hcstate(num);
		String period = Long.parseLong(data.getPeriod()) + "";
		data.setPeriod(period);
		int line = dataService.addLiuheChecks(data);
		String remarks = "预设了彩种为：" + cnames + "第：" + data.getPeriod() + "期的开奖期号和开奖时间！";
		operationlogService.addOperationlog((AdminUser)session.getAttribute("admin1"),remarks,"港彩预设管理");
		return new JsonResult("success", line);
	}

	/**
	 * 方法名：updateHongKongLotteryCheckNum 
	 * 描述：     六合彩预设开奖号码和修改开奖号码                  
	 * 参数：    @param data 开奖信息
	 * 参数：    @param session
	 * 参数：    @return 
	 * @return: JsonResult
	 */
	@ResponseBody
	@RequestMapping("/updateHongKongLotteryCheckNum")
	public JsonResult updateHongKongLotteryCheckNum(Data data, HttpSession session) {
		int line = dataService.updateCheckNum(data);
		String remarks = "设置了彩种为：" + data.getGameNameInChinese() + "第：" + data.getPeriod() + "期的开奖号码为："+data.getLotternumber()+"！";
		operationlogService.addOperationlog((AdminUser)session.getAttribute("admin1"),remarks,"港彩预设管理");
		return new JsonResult("success", line);
	}
	
	/**
	 * 方法名：updateHongKongLotteryChekcInfo 
	 * 描述：     修改开奖期号和时间                  
	 * 参数：    @param nextStopOrderTimeEpoch 开奖时间
	 * 参数：    @param cnames 彩种中文名
	 * 参数：    @param period 彩种期号
	 * 参数：    @param period1 下期期号
	 * 参数：    @param cname 彩种英文名
	 * 参数：    @param session
	 * 参数：    @return 
	 * @return: JsonResult
	 */
	@ResponseBody
	@RequestMapping("/updateHongKongLotteryChekcInfo")
	public JsonResult updateHongKongLotteryChekcInfo(String openTime, String nextStopOrderTimeEpoch, String period,
			String nextperiod,String cname, String cnames,HttpSession session) {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		int status = 1;
		try {
			Long endTime = sdf.parse(openTime).getTime();//开奖时间
			Long startTime = sdf.parse(sdf.format(new Date())).getTime();//当前系统时间
			if(endTime - startTime > 10) {	
				status = 0;
			}
		} catch (ParseException e) {e.printStackTrace();}
		int num = dataService.updataNextDate(cname,period,openTime,nextStopOrderTimeEpoch,status);
		Data d = dataService.previousIssue(cname,period);
		//修改香港六合彩上期的 下期开奖时间   当期开奖时间变动以后  需要修改上期的  下期开间时间   因为前端倒计时的是上期的下期开奖时间  不清楚别乱动 问一下wch 在改动
		if(d != null) {
			dataService.upDataNextTime(cname,d.getPeriod(),openTime);
		}
		String remarks = "修改了彩种为：" + cnames + "第：" + period + "期的开奖期号和开奖时间";
		operationlogService.addOperationlog((AdminUser)session.getAttribute("admin1"),remarks,"港彩预设管理");
		return new JsonResult("success", num);
	}

	/**
	 * 方法名：updateHongKongLotteryCheck
	 * 描述：    六合彩手动派奖                   
	 * 参数：    @param data 派奖信息
	 * 参数：    @param session
	 * 参数：    @return 
	 * @return: JsonResult
	 */
	@ResponseBody
	@RequestMapping("/updateHongKongLotteryCheck")
	public JsonResult updateHongKongLotteryCheck(Data data, HttpSession session) {
		CheckOrder or = new CheckOrder();
		data.setLottertime(DateUtil.getCurrTime());
		data.setStatus(1);
		int line = dataService.updateDate(data);
		Data datas = dataService.findById(data.getId());
		data.setState("已开奖");
		or.checkTime(data);
		if(Integer.parseInt(WebsiteStateConfig.configs.get("agent_flag"))==1) {
			or.checkLotter1(datas);
		}else {
			or.checkLotter2(datas);
		}
		String remarks = "对彩种为：" + datas.getGameNameInChinese() + "第：" + datas.getPeriod() + "期进行了手动派奖！";
		operationlogService.addOperationlog((AdminUser)session.getAttribute("admin1"),remarks,"港彩预设管理");
		return new JsonResult("success", line);
	}
	

	/**
	 * 
	 * ----TODO: 港彩属性管理
	 * 
	 */
	

	/**
	 * 方法名：hongKongLotteryAttrPage 
	 * 描述：     六合彩属性管理页面                  
	 * 参数：    @return 
	 * @return: String
	 */
	@RequestMapping("/hongKongLotteryAttrPage")
	public String hongKongLotteryAttrPage() {
		return "/htgl/shuxingxiugai";
	}

	/**
	 * 方法名：findHongKongLotteryAttr 
	 * 描述：    查询六合彩玩法的属性                   
	 * 参数：    @return 
	 * @return: JsonResult
	 */
	@ResponseBody
	@RequestMapping("/findHongKongLotteryAttribute")
	public JsonResult findHongKongLotteryAttribute() {
		return new JsonResult("success", dataService.findAllAttribute());
	}

	/**
	 * 方法名：updateZodiacAttribute 
	 * 描述：     修改六合彩生肖属性                  
	 * 参数：    @param session
	 * 参数：    @return 
	 * @return: JsonResult
	 */
	@ResponseBody
	@RequestMapping("/updateZodiacAttribute")
	public JsonResult updateZodiacAttribute(HttpSession session) {
		/** 生肖 */
		String[] sx1 = { "鼠", "牛", "虎", "兔", "龙", "蛇", "马", "羊", "猴", "鸡", "狗", "猪" };
		String str[] = { "01,13,25,37,49,", "02,14,26,38,50,", "03,15,27,39,50,", "04,16,28,40,50,", "05,17,29,41,50,",
				"06,18,30,42,50,", "07,19,31,43,50,", "08,20,32,44,50,", "09,21,33,45,50,", "11,23,35,47,50,",
				"10,22,34,46,50,", "12,24,36,48,50," };
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy");
		Integer year = Integer.parseInt(sdf.format(new Date()));
		addCount++;
		String zo = ExChangeUtil.calZodiac(year + addCount).substring(1);
		int line = 0;
		int b = 0;
		for (int i = 0; i < sx1.length; i++) {
			if (sx1[i].equals(zo)) {
				b = i;
			}
		}
		List<Attribute> list = new ArrayList<Attribute>();
		for (int i = 0; i < sx1.length; i++) {
			Attribute atr = new Attribute();
			if (b - i < 0) {
				b += 12;
			}
			atr.setAttribute(sx1[b - i]);
			atr.setContent(str[i]);
			atr.setId(i + 1);
			atr.setUpdateTime(DateUtil.getCurrTime());
			list.add(atr);
		}
		for (int i = 0; i < list.size(); i++) {
			line += dataService.updateAttributes(list.get(i));
		}
		String remarks = "使用了生肖一键更换功能!";
		operationlogService.addOperationlog((AdminUser)session.getAttribute("admin1"),remarks,"港彩属性管理");
		return new JsonResult("success", line);
	}

	/**
	 * 方法名：updateElementsAttribute 
	 * 描述：    修改六合彩五行属性                   
	 * 参数：    @param attr 配置属性
	 * 参数：    @param session
	 * 参数：    @return 
	 * @return: JsonResult
	 */
	@ResponseBody
	@RequestMapping("/updateElementsAttribute")
	public JsonResult updateElementsAttribute(Attribute attr, HttpSession session) {
		attr.setUpdateTime(DateUtil.getCurrTime());
		int line = dataService.updateAttributes(attr);
		String remarks = "修改了五行：" + attr.getAttribute() + "属性的号码为： " + attr.getContent()+"！";
		operationlogService.addOperationlog((AdminUser)session.getAttribute("admin1"),remarks,"港彩属性管理");
		return new JsonResult("success", line);
	}
	
	
	/**
	 * 
	 * ----TODO: 特码返水管理
	 * 
	 */
	
	/**
	 * 方法名：specialCodeRebatePage 
	 * 描述：     特码返水管理页面                  
	 * 参数：    @return 
	 * @return: String
	 */
	@RequestMapping("/specialCodeRebatePage")
	public String specialCodeRebatePage() {
		return "/htgl/gctmbfs";
	}
	
	/**
	 * 方法名：findSpecialCodeRebate 
	 * 描述：     查询港彩特码B玩法投注反水设置                   
	 * 参数：    @return 
	 * @return: JsonResult
	 */
	@ResponseBody
	@RequestMapping("/findSpecialCodeRebate")
	public JsonResult findSpecialCodeRebate() {
		return new JsonResult("success", orderService.findAllGcRebate(""));
	}

	/**
	 * 方法名：insertSpecialCodeRebate 
	 * 描述：     添加港彩特码B玩法投注反水设置                  
	 * 参数：    @param gcRebate 返水设置
	 * 参数：    @param session
	 * 参数：    @return 
	 * @return: JsonResult
	 */
	@ResponseBody
	@RequestMapping("/insertSpecialCodeRebate")
	public JsonResult insertSpecialCodeRebate(GcRebate gcRebate, HttpSession session) {
		int line = orderService.insertGcRebate(gcRebate);
		String remarks = "添加了彩种："+gcRebate.getGc_money()+ "的特码返水投注功能,返水比率为：" + gcRebate.getGc_rebate()+"！";
		operationlogService.addOperationlog((AdminUser)session.getAttribute("admin1"),remarks,"特码返水管理");
		return new JsonResult("success", line);
	}

	/**
	 * 方法名：updateSpecialCodeRebate 
	 * 描述：     修改港彩特码B玩法投注反水设置                  
	 * 参数：    @param gcRebate 返水设置
	 * 参数：    @param session
	 * 参数：    @return 
	 * @return: JsonResult
	 */
	@ResponseBody
	@RequestMapping("/updateSpecialCodeRebate")
	public JsonResult updateSpecialCodeRebate(GcRebate gcRebate, HttpSession session) {
		GcRebate gc = orderService.findByIdGcRebateInfo(gcRebate.getId());
		String remarks = "";
		if(null!=gcRebate.getGc_state()) {
			if(gcRebate.getGc_state()==0){
				remarks = "禁用了彩种："+gc.getGc_money()+"特码投注返水功能！";
			}else if(gcRebate.getGc_state()==1) {
				remarks =  "启用了彩种："+gc.getGc_money()+"特码投注返水功能！";
			}
		}else {
			remarks = "修改了彩种："+gc.getGc_money()+"的特码投注返水比率为：" + gcRebate.getGc_rebate()+"！";
		}
		int line = orderService.updateByGcRebate(gcRebate);
		operationlogService.addOperationlog((AdminUser)session.getAttribute("admin1"),remarks,"特码返水管理");
		return new JsonResult("success", line);
	}
	
	/**
	 * 方法名：deleteSpecialCodeRebate 
	 * 描述：    删除特码返水配置                   
	 * 参数：    @param id 配置id
	 * 参数：    @return 
	 * @return: JsonResult
	 */
	@RequestMapping("/deleteSpecialCodeRebate")
	@ResponseBody
	public JsonResult deleteSpecialCodeRebate(HttpSession session,String name,Integer id) {
		if (id == null) {
			return new JsonResult("success", "id不能为空!");
		}
		int line = orderService.deleteshanchu(id);
		String remarks = "删除了一条彩种："+name+"的特码投注返水配置！";
		operationlogService.addOperationlog((AdminUser)session.getAttribute("admin1"),remarks,"特码返水管理");
		return new JsonResult("success", line);
	}
	
	
	/**
	 * 
	 * ----TODO: 彩票开启管理
	 * 
	 */

	/**
	 * 
	 * 方法名：lotteryPage 
	 * 描述：     彩票管理页面                  
	 * 参数：    @return 
	 * @return: String
	 */
	@RequestMapping("/lotteryPage")
	public String lotteryPage() {
		return "htgl/caizhongshezhi";
	}
	
	/**
	 * 方法名：findAllLotteryInfo 
	 * 描述：     查询所有的彩种信息                  
	 * 参数：    @return 
	 * @return: JsonResult
	 */
	@ResponseBody
	@RequestMapping("/findAllLotteryInfo")
	public JsonResult findAllLotteryInfo() {
		return new JsonResult("success", lotterService.getAllLotter());
	}

	/**
	 * 方法名：updateLotteryState 
	 * 描述：     开启或关闭彩种                  
	 * 参数：    @param id 彩种id
	 * 参数：    @param state 彩种状态
	 * 参数：    @param session
	 * 参数：    @return 
	 * @return: JsonResult
	 */
	@ResponseBody
	@RequestMapping("/updateLotteryState")
	public JsonResult updateLotteryState(Lotter lotter, HttpSession session) {
		Lotter lotters = lotterService.getLotterById(lotter.getId());
		int line = lotterService.updateLotterySetupInfo(lotter);
		if(line==1) {
			WebsiteStateConfig.lotteryStateConfig(lotters.getCname(), lotter.getState());
		}
		String type = "禁用了彩种"; 
		if(lotter.getState()==1){
			type = "启用了彩种";
		}
		String remarks = type + lotters.getName()+"的投注功能！";
		operationlogService.addOperationlog((AdminUser)session.getAttribute("admin1"),remarks,"彩票开启管理");
		new WebSocketJson(3,new ColorVariety(lotters.getCname(),lotter.getState())).sendAll();
		return new JsonResult("success", line);
	}
	
	/**
	 * 方法名：updateLotteryCodeState 
	 * 描述：     开启或关闭彩种                  
	 * 参数：    @param id 彩种id
	 * 参数：    @param state 彩种状态
	 * 参数：    @param session
	 * 参数：    @return 
	 * @return: JsonResult
	 */
	@ResponseBody
	@RequestMapping("/updateLotteryCodeState")
	public JsonResult updateLotteryCodeState(Lotter lotter, HttpSession session) {
		Lotter lotters = lotterService.getLotterById(lotter.getId());
		int line = lotterService.updateLotterySetupInfo(lotter);
		String type = "关闭了彩种"; 
		if(lotter.getWhetherOrNotToCode()==1){
			type = "开启了彩种";
		}
		String remarks = type + lotters.getName()+"的打码功能！";
		operationlogService.addOperationlog((AdminUser)session.getAttribute("admin1"),remarks,"彩票开启管理");
		return new JsonResult("success", line);
	}
	
	/**
	 * 方法名：startCrawlCpData 
	 * 描述：   爬取彩票数据的定时任务                  
	 * 参数：     
	 * @return: void
	 */
	private void startCrawlCpData() {
		CpData cpData = new CpData();
		Thread t = new Thread() {
			@Override
			public void run() {
				cpData.cp();
			}
		};
		t.start();
		try {
			Thread.sleep(500);
		} catch (InterruptedException e) {}
		new OpenData().startReviewTask();
		isFirstTime = false;
	}

	@RequestMapping("/openCrawlingData")
	@ResponseBody
	public JsonResult openCrawlingData(String states,HttpSession session){
		if("".equals(states) || null== states ){
			return new JsonResult("success",state);
		}
		state = Integer.parseInt(states);
		boolean openState = false;
		if(state == 1){
			openState = true;
		}
		if(openState) {
			SystemLotter.checkNums(1);//开启生成系统彩数据
			bjlService.insertbjl();
			if(isFirstTime) {
				Publicmethods p = new Publicmethods();
				PeriodData periodData = new PeriodData();
				periodData.timingTask();
				bjlService.timingTask();//生成百家乐开奖数据
				bjlService.open();//开启百家乐开奖任务
				startCrawlCpData();//爬取彩票数据
				p.startUp();//爬取彩票数据2
				//footBallMatchController.getFootballData();//爬足球比赛数据
				//footBallMatchController.getFootballResult();//爬赛果数据
			}
		}else {
			SystemLotter.checkNums(0);//停止生成系统彩数据
			//stopGetCpData();//停止爬取彩票数据
			//footBallMatchController.stopGetFootballData();//停止爬比赛数据
			//footBallMatchController.stopGetFootballResult();//停止爬赛果数据
		}
		String type = "关闭了"; 
		if(openState==true) {
			type = "开启了";
		}
		String remarks = type+"彩票数据爬取功能！";
		operationlogService.addOperationlog((AdminUser)session.getAttribute("admin1"),remarks,"彩票开启管理");
		return new JsonResult("success",state);
	}
	
	
	/**
	 * 
	 * ----TODO: 彩票赔率管理
	 * 
	 */
	
	/**
	 * 方法名：lotteryRatioPage 
	 * 描述：     彩票赔率管理页面                  
	 * 参数：    @return 
	 * @return: ModelAndView
	 */
	@RequestMapping("/lotteryRatioPage")
	public ModelAndView lotteryRatioPage() {
		ModelAndView m = new ModelAndView("htgl/caizhongpeilvshezhi");
		m.addObject("lottery", lotterService.getAllLotter());
		return m;
	}

	/**
	 * 方法名：findByIdLotteryInfo 
	 * 描述：     根据id查询彩种的信息                  
	 * 参数：    @param id 彩票id
	 * 参数：    @return 
	 * @return: JsonResult
	 */
	@ResponseBody
	@RequestMapping("/findByIdLotteryInfo")
	public JsonResult findByIdLotteryInfo(Integer id) {
		return new JsonResult("success", lotterService.getLotterById(id));
	}

	/**
	 * 方法名：updateLotteryRatio 
	 * 描述：     修改彩种的赔率                  
	 * 参数：    @param lotter 彩种信息
	 * 参数：    @param cplays 修改玩法
	 * 参数：    @param session
	 * 参数：    @return 
	 * @return: JsonResult
	 */
	@ResponseBody
	@RequestMapping("/updateLotteryRatio")
	public JsonResult updateLotteryRatio(Lotter lotter, String play,String name, HttpSession session) {
		int line = lotterService.upczpv(lotter);
		String remarks = "修改了彩种：" + name + ",玩法：" + play + "的赔率！";
		operationlogService.addOperationlog((AdminUser)session.getAttribute("admin1"),remarks,"彩票赔率管理");
		return new JsonResult("success", line);
	}
	
	/**
	 * 
	 * ----TODO: 彩票球数管理
	 * 
	 */
	
	/**
	 * 方法名：lotteryAttributePage 
	 * 描述：    彩票球数管理页面                   
	 * 参数：    @return 
	 * @return: String
	 */
	@RequestMapping("/lotteryAttributePage")
	public String lotteryAttributePage() {
		return "htgl/caizhongqiushukongzhi";
	}

	/**
	 * 方法名：findLotteryAttributeSetup 
	 * 描述：     查询用户下注属性配置                  
	 * 参数：    @return 
	 * @return: JsonResult
	 */
	@ResponseBody
	@RequestMapping("/findLotteryAttributeSetup")
	public JsonResult findLotteryAttributeSetup() {
		return new JsonResult("success", kongzhiService.getAllKongzhi());
	}

	/**
	 * 方法名：updateLotteryAttributeSetup 
	 * 描述：    修改用户下注属性配置                   
	 * 参数：    @param id 配置id
	 * 参数：    @param count 配置数量
	 * 参数：    @param session
	 * 参数：    @return 
	 * @return: JsonResult
	 */
	@ResponseBody
	@RequestMapping("/updateLotteryAttributeSetup")
	public JsonResult updateLotteryAttributeSetup(Integer id, Integer count,String name,String play, HttpSession session) {
		String data = "修改失败,请联系管理员！";
		int line = kongzhiService.updateKongzhiCount(id, count);
		if (line == 1) {
			data = "修改成功！";
		}
		String remarks = "修改了彩种：" + name + ",下注玩法："+play+"的控制球数：" + count + "个！";
		operationlogService.addOperationlog((AdminUser)session.getAttribute("admin1"),remarks,"彩票球数管理");
		return new JsonResult("success", data);
	}
	
	
	/**
	 * 
	 * ----TODO: 彩种开奖数据异常处理 
	 * 
	 */
	
	
	/**
	 * 方法名：findCheckDataIsNull 
	 * 描述：     查询开奖没有爬取到开奖号码的数据                  
	 * 参数：    @return 
	 * @return: JsonResult
	 */
	@ResponseBody
	@RequestMapping("/findCheckDataIsNull")
	public JsonResult findCheckDataIsNull() {
		return new JsonResult("success", dataService.findNull());
	}

	/**
	 * 方法名：updateCheckNum 
	 * 描述：    彩票开奖异常添加开奖号码                
	 * 参数：    @param cName 彩种名称
	 * 参数：    @param period 彩种期号
	 * 参数：    @param lotterNumber 开奖号码
	 * 参数：    @param session
	 * 参数：    @return 
	 * @return: JsonResult
	 */
	@ResponseBody
	@RequestMapping("/updateCheckNum")
	public JsonResult updateCheckNum(String cName, String period, String lotterNumber, HttpSession session) {
		if (lotterNumber == null || cName == null || period == null) {
			return new JsonResult("数据不能为空", "数据不能为空");
		}
		String remarks = "对彩种:" + cName +"第："+ period + "期设置了开奖号码" + lotterNumber;
		operationlogService.addOperationlog((AdminUser)session.getAttribute("admin1"),remarks,"开奖异常管理");
		return new JsonResult(null, lotterService.updataawardnumber(cName, period, lotterNumber));
	}
	
	/**
	 * 方法名：lotterCheckNum 
	 * 描述：    彩票开奖异常进行手动派奖                  
	 * 参数：    @param cName 彩种名称
	 * 参数：    @param period 彩种期号
	 * 参数：    @param session
	 * 参数：    @return 
	 * @return: JsonResult
	 */
	@ResponseBody
	@RequestMapping("/lotterCheckNum")
	public JsonResult lotterCheckNum(String cName, String period, HttpSession session) { 
		CheckOrder c = new CheckOrder();
		Data data = lotterService.inquir(cName, period);
		if (" ".equals(data.getLotternumber()) || data.getLotternumber() == null) {
			return new JsonResult("", "开奖号不存在，请输入开奖号在开奖!");
		}
		data.setStatus(1);
		data.setState("已开奖");
		GetAbnormalData.haveBeenAwardedAPrize(data);
		if(Integer.parseInt(WebsiteStateConfig.configs.get("agent_flag"))==1) {
			c.checkLotter1(data);
		}else {
			c.checkLotter2(data);
		}
		c.checkTime(data);
		String remarks = "对彩种：" + cName +"第："+ period + "期进行了手动派奖!";
		operationlogService.addOperationlog((AdminUser)session.getAttribute("admin1"),remarks,"开奖异常管理");
		return new JsonResult("success", 1);
	}
	
	/**
	 * 方法名：maxPeriod 
	 * 描述：     彩种最大的一期期号                 
	 * 参数：    @param cname 彩种名称
	 * 参数：    @return 
	 * @return: JsonResult
	 */
	@ResponseBody 
	@RequestMapping("/maxPeriod")
	public JsonResult maxPeriod(String cname) {
		Data data = dataService.getMaxPeriod(cname); 
		return new JsonResult("maxPeriod", data); 
	}
	
}
