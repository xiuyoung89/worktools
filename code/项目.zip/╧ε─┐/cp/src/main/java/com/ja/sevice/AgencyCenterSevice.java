package com.ja.sevice;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import com.ja.domain.AgentLink;
import com.ja.domain.Order;
import com.ja.domain.PagingData;
import com.ja.domain.User;

/**
 * 第二套代理系统
 * 代理系统 开户  下级调赔率  以及查询代理相关赔率数据
 * @author Administrator
 *
 */
public interface AgencyCenterSevice {
	
	/**
	 * 实现代理给下级开户
	 * @param user 代理对象
	 *  @param odds 代理设置的赔率
	 * @param u 开户对象
	 * @return 成功则放回1  失败则返回0 返回2则参数不对  返回3则用户名已存在 返回4代表 赔率格式传输错误 5超过了平台规定的最低赔率 6用户名已经存在
	 */
	int openAccount(User user,User u,String odds);
	
	/**
	 * 查询当前 代理的代理连接  第二套代理系统的
	 * @param userName 代理用户的用户名  就是User表里面的用户名  name字段的名字
	 * @return 查到则返回list集合包含AgentLink对象数据 如果没有查询到则返回一个空集合
	 */
	List<AgentLink> pueryProxyLinks(String userName,Integer gamePlayer);
	
	/**
	 * 插入当前代理的代理连接 第二套代理系统的 
	 * @param a 代理连接对象数据
	 * @return 返回0则代表 插入数据库失败 返回1 则代表成功  返回2 则代表赔率设置不对 3赔率大于平台规定的最低赔率 4则代表试玩账号不能申请成为代理
	 * 			5则代表 已经被上级设置成玩家账号不能成为代理  6则代表参数为空
	 */
	int insertProxyLinks(User user, HttpServletRequest request,String odds,Integer gamePlayer);
	
	/**
	 * 查询数据里面最新的一条数据的id保证邀请码的唯一性
	 * @return 返回数据库里面最后一条数据的id
	 */
	Integer agencyId();
	/**
	 * 查询代理下级的投注记录
	 * @param user  当前用户对象
	 * @param xname 代理下级的用户名
	 * @param cname 彩种名
	 * @param date1 开始时间
	 * @param date2 结束时间
	 * @param state 开奖状态 1待开奖-2未中奖-3-已中奖-6-和局中奖-7-8-撤单  状态
	 * @return 查询到责返回List集合  没有查询到则返回一个空集合
	 */
	List<Order> xjcathecticRecord(Integer startIndex, Integer lineCount,User user,String xname,Integer state,String cname,String date1,String date2);

	/**
	 * 根据Fid查询上级的信息
	 * @param Fid 上级的Id
	 * @return 如果是他上级则返回true如果不是他上级则返回false
	 */
	boolean treeData(User u,int Fid);
	/**
	 * 根据Fid查询所有上级 并且防装再一个对象里面返回
	 * @param Fid  Fid 上级的id
	 * @return 如果查询到则返回 没有查询到 则返回一个空集合
	 */
	List<User> treeDataobject(int Fid);
	
	/**
	 *根据动态参数统计代理下级下注记录
	 * @param name  当前的用户名
	 * @param xname 代理下级的用户名
	 * @param cname 彩种名
	 * @param date1 开始时间
	 * @param date2 结束时间
	 * @param userid 代理的id
	 * @param state 开奖状态 1待开奖-2未中奖-3-已中奖-6-和局中奖-7-8-撤单  状态
	 * @return 返回一个int 值 如果有数据则返回 条数  如果没有数据则返回0
	 */
	Integer xjcathecticRecords(User user,String xname,Integer state,String cname,String date1,String date2);
	/**
	 * 查询当前代理的下级 
	 * @param u  当前代理对象的信息
	 * @param name 当前代理查询下级的用户名
	 * @param cname 查询这个代理下面的用户
	 * @return  查询到下级则返回list集合没有查询到则返回一个空集合
	 */
	List<User> subordinate(User u,String name,String cname);
	/**
	 * 查询下级交易记录  包括账户明细 流水表  提款充值 充值提现表 
	 * @param u 代理数据对象
	 * @param name 搜索下级流水的用户名
	 * @param state 查询那个  0-账户明细  1-提现记录  2-充值记录
	 * @param date1 开始时间
	 * @param date2 结束时间
	 * @param paging 分页对象
	 * @return 查询到则返回list集合包含数据对象 如果没有查询到则返回空集合
	 */
	PagingData subordinatePipeline(PagingData paging,User u,String name,String cname,Integer state,String date1,String date2);
	/**
	 * 根据代理删除代理连接以及邀请码
	 * @param u 代理
	 * @param invitationCode 邀请码
	 * @return 删除成功则返回1 删除失败则返回 1一下的数字 0
	 */
	 int deleteAgenLink(User u,String invitationCode);
	 
	 /**
	 * 根据邀请码查询代理
	 * @param invitationCode 邀请码
	 * @return 查询到这个代理则返回 AgentLink对象数据  如果没有查询到则返回null
	 */
	AgentLink pueryagencyInvitationCode(String invitationCode);
	
}
