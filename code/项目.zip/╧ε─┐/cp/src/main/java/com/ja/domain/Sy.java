package com.ja.domain;

public class Sy {
	
	//最新 中奖榜
	private String cname1;

	private Double goalmoney;
	
	private String huiyuanzh;
	
	public String getCname1() {
		return cname1;
	}

	public void setCname1(String cname1) {
		this.cname1 = cname1;
	}

	public Double getGoalmoney() {
		return goalmoney;
	}

	public void setGoalmoney(Double goalmoney) {
		this.goalmoney = goalmoney;
	}

	public String getHuiyuanzh() {
		return huiyuanzh;
	}

	public void setHuiyuanzh(String huiyuanzh) {
		this.huiyuanzh = huiyuanzh;
	}
	
}
