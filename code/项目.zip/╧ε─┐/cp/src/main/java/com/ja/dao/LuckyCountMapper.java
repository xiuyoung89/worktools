package com.ja.dao;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.ja.domain.LuckyCount;

public interface LuckyCountMapper {

	/** 添加会员的抽奖信息 */
	int addLuckyCount(@Param(value = "c") LuckyCount count);

	/** 查询用户的抽奖次数 */
	LuckyCount getOneLuckyCount(Integer id);

	/** 修改用户的抽奖次数 */
	int updateLuckyCount(@Param(value = "c") LuckyCount count);
	

	/**
	 * 根据用户名修改用户摇奖次数
	 * @param counts
	 * @return
	 */
	int updateyaojiang(@Param("counts")LuckyCount counts);
	
	/**
	 * 根据用户名查找用户摇奖次数
	 * @param counts
	 * @return
	 */
	LuckyCount inquiringUsersNumberOfAwards(@Param("name")String name);
	
	/**
	 * 查询全部用户的摇奖次数
	 * @return
	 */
	List<LuckyCount> frequency();

}
