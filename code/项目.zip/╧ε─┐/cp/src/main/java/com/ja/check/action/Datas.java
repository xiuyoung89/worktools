//package com.ja.check.action;
//import java.sql.Connection;
//import java.sql.PreparedStatement;
//import java.sql.ResultSet;
//import java.sql.SQLException;
//import java.util.HashMap;
//import java.util.Map;
//
//import com.ja.check.data.Product;
//import com.ja.util.JdbcUtil;
//
//
///**
// * 把读取回来的数据插入到数据库 和查新数据，验证数据存不存在
// * 
// * @author Administrator
// *
// */
//public class Datas {
//	
//	/**插入读取回来的数据 */
//	public int insertData(Product product){
//		PreparedStatement pds = null;
//		JdbcUtil jdbcUtil = new JdbcUtil();
//		Connection connection = jdbcUtil.getConnection();
//		String sql = "insert into cp_data(lotterTime,period,lotterNumber,cName,nextStopOrderTimeEpoch,gameNameInChinese,nextperiod) values(?,?,?,?,?,?,?)";
//		try {
//			pds = connection.prepareStatement(sql);
//			pds.setString(1, product.getLotterTime());
//			pds.setString(2,product.getPeriod());
//			pds.setString(3, product.getLotterNumber());
//			pds.setString(4, product.getcName());
//			pds.setString(5, product.getDatetime());
//			pds.setString(6, product.getName());
//			pds.setString(7, product.getNextperiod());
//			int num = pds.executeUpdate();
//			return num;
//		} catch (SQLException e) {
//			System.out.println("1: "+e);
//		}finally{
//			closeConn(connection, pds);
//		}
//		return 0; 
//	}
//	//查询期号
//	public Product selectmax(String cname){
//		PreparedStatement ps = null;
//		ResultSet result = null;
//		JdbcUtil jdbcUtil = new JdbcUtil();
//		Connection connection = jdbcUtil.getConnection();
//		String sql = "select * from cp_data  where cName= ? Order by ID DESC LIMIT 1 ";
//		try {
//			Product data = new Product();
//			ps = connection.prepareStatement(sql);
//			ps.setString(1, cname);
//			result =  ps.executeQuery();
//			while (result.next()) {
//				data.setPeriod(result.getString("period"));
//				data.setNextperiod(result.getString("nextperiod"));
//				data.setStatus(result.getInt("status"));
//			}
//			return data;
//		} catch (SQLException e) {
//			System.out.println("2: "+e);
//		}finally{
//			closeConn(connection,ps,result);
//		}
//		return null;
//	}
//	//查询下期开奖时间	
//	public Product datetime1(String cname,String time){
//		PreparedStatement ps = null;
//		ResultSet result = null;
//		JdbcUtil jdbcUtil = new JdbcUtil();
//		Connection connection = jdbcUtil.getConnection();
//		String sql = "select "+cname+",id from cp_datatime where "+cname+" = ?";
//		try {
//			Product pt = new Product();
//		    ps = connection.prepareStatement(sql);
//			ps.setString(1, time);
//			result = ps.executeQuery();
//			while(result.next()){
//				pt.setId(result.getInt("id"));
//				pt.setDatetime(result.getString(cname));
//			}
//			return pt;
//		} catch (SQLException e) {
//			System.out.println("3: "+e);
//		}finally{
//			closeConn(connection,ps,result);
//		}
//		return null;
//		
//	}
//	
//	public Map<Integer,String> query(String cname){
//		PreparedStatement ps = null;
//		ResultSet result = null;
//		JdbcUtil jdbcUtil = new JdbcUtil();
//		Connection connection = jdbcUtil.getConnection();
//		Map<Integer, String> map = new HashMap<Integer,String>();
//		String sql = "select * from cp_datatime";
//		try {
//			ps = connection.prepareStatement(sql);
//			result = ps.executeQuery();
//			while(result.next()){
//				map.put(result.getInt("id"), result.getString(cname));
//			}
//			return map;
//		} catch (SQLException e) {
//			System.out.println("4： "+e);
//		}finally{
//			closeConn(connection,ps,result);
//		}
//		return null;
//	}
//	
//	/**查询开奖时间对比*/
//	public Product datetime(String cname,int num){
//		PreparedStatement ps = null;
//		ResultSet result = null;
//		JdbcUtil jdbcUtil = new JdbcUtil();
//		Connection connection = jdbcUtil.getConnection();
//		String sql = "select "+cname+",id from cp_datatime where id = ?";
//		try {
//			Product pt = new Product();
//			ps = connection.prepareStatement(sql);
//			ps.setInt(1, num);
//			result = ps.executeQuery();
//			while(result.next()){
//				pt.setId(result.getInt("id"));
//				pt.setDatetime(result.getString(cname));
//			}
//			return pt;
//		} catch (SQLException e) {
//			System.out.println("5: "+e);
//		}finally{
//			closeConn(connection,ps,result);
//		}
//		return null;
//	}
//	/**查询数据*/
//	public Product selectData(Product product){
//		PreparedStatement ps = null;
//		ResultSet result = null;
//		JdbcUtil jdbcUtil = new JdbcUtil();
//		Connection connection = jdbcUtil.getConnection();
//		Product pt = new Product();
//		String sql = "select * from cp_data where period = ? and cName = ?";
//		try {
//			ps = connection.prepareStatement(sql);
//			ps.setString(1, product.getPeriod());
//			ps.setString(2, product.getcName());
//			result = ps.executeQuery();
//			while(result.next()){
//				pt.setId(result.getInt("id"));
//				pt.setLotterTime(result.getString("lotterTime"));
//				pt.setPeriod(result.getString("period"));
//				pt.setLotterNumber(result.getString("lotterNumber"));
//				pt.setcName(result.getString("cName"));
//				return pt;
//			}
//		} catch (SQLException e) {
//			System.out.println("6: "+e);
//		}finally{
//			closeConn(connection,ps,result);
//		}
//		return null;
//	}
//	
//
//	/**释放资源*/
//   public static void closeConn(Connection connection,PreparedStatement pstmt,ResultSet resultSet) {  
//        if (resultSet != null) {  
//            try {  
//                resultSet.close();  
//            } catch (SQLException e) {  
//                e.printStackTrace();  
//            }finally {
//            	if (pstmt != null) {  
//            		try {  
//            			pstmt.close();  
//            		} catch (SQLException e) {  
//            			e.printStackTrace();  
//            		}finally {
//            			if (connection != null) {  
//            				try {  
//            					connection.close();  
//            				} catch (SQLException e) {  
//            					e.printStackTrace();  
//            				}  
//            			}  
//            		}  
//            	}  
//			}  
//        }  
//    }
//   /**释放资源*/
//   public static void closeConn(Connection connection,PreparedStatement pstmt) {  
//	   if (pstmt != null) {  
//		   try {  
//			   pstmt.close();  
//		   } catch (SQLException e) {  
//			   e.printStackTrace();  
//		   }finally {
//			   if (connection != null) {  
//				   try {  
//					   connection.close();  
//				   } catch (SQLException e) {  
//					   e.printStackTrace();  
//				   }  
//			   }  
//		   }  
//	   }  
//   }
//   /**释放资源*/
//   public static void closeConn(Connection connection) {  
//	   if (connection != null) {  
//		   try {  
//			   connection.close();  
//		   } catch (SQLException e) {  
//			   e.printStackTrace();  
//		   }  
//	   }  
//   }
//
//}
