package com.ja.sevice.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ja.dao.AllExplainMapper;
import com.ja.domain.AllExplain;
import com.ja.sevice.AllExplainService;
import com.ja.util.DateUtil;

@Service
public class AllExplainServiceImpl implements AllExplainService {

	@Autowired
	private AllExplainMapper allExplainMapper;

	@Override
	public String saveExplaine(AllExplain explain) {
		String message = "操作失败!";
		int line = 0;
		explain.setCreated_time(DateUtil.getCurrTime());
		if(explain.getId()!=null) {
			line = allExplainMapper.updateExplain(explain);
		}else {
			line = allExplainMapper.insertExplain(explain);
		}
		if(line==1) {
			message = "操作成功!";
		}
		return message;
	}

	@Override
	public List<AllExplain> findAllExplain(Integer type) {
		return allExplainMapper.findAllExplain(type);
	}

	@Override
	public AllExplain findByIdExplain(Integer id) {
		return allExplainMapper.findByIdExplain(id);
	}

	@Override
	public String deleteExplain(Integer id) {
		String message = "操作失败!";
		String ids = "";
		int line = 0;
		List<Integer> ids1 = allExplainMapper.finMeunByDeleteId(id);
		if(ids1.size()<1) {
			line = allExplainMapper.deleteExplain(id,"", 1);
		}else {
			for(Integer ids2 : ids1) {
				ids += ids2+",";
			}
			ids = ids.substring(0,ids.length()-1);
			line = allExplainMapper.deleteExplain(id,ids, 2);
		}
		if(line != 1) {
			message = "操作成功!";
		}
		return message;
	}


}
