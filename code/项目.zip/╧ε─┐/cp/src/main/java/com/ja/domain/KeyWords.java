package com.ja.domain;

import java.io.Serializable;

/**
 * TODO 聊天内容关键词替换实体
 * @Title　KeyWords.java
 * @Vers　v1.0
 * @AUTH　Bean
 * @Time　2018年5月23日 上午10:04:00
 */
public class KeyWords implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 96033006586422292L;
	private Integer id;
	private String str;
	private String replaceStr;
	private String state;
    
    public static long getSerialversionuid() {
		return serialVersionUID;
	}
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getStr() {
		return str;
	}
	public void setStr(String str) {
		this.str = str;
	}
	public String getReplaceStr() {
		return replaceStr;
	}
	public void setReplaceStr(String replaceStr) {
		this.replaceStr = replaceStr;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public KeyWords(String str, String replaceStr, String state) {
		super();
		this.str = str;
		this.replaceStr = replaceStr;
		this.state = state;
	}
	public KeyWords() {
		super();
	}
	@Override
	public String toString() {
		return "KeyWords [id=" + id + ", str=" + str + ", replaceStr=" + replaceStr + ", state=" + state + "]";
	}
	
}
