package com.ja.domain;
/**
 * 百家乐开奖数据实体类
 * @author Administrator
 *
 */
public class Bjldata {

	
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	@Override
	public String toString() {
		return "Bjldata [id=" + id + ", zhuang1=" + zhuang1 + ", zhuang2=" + zhuang2 + ", dealerCard=" + dealerCard
				+ ", frontPointsOfZhuangshi=" + frontPointsOfZhuangshi + ", makerSFinalPoints=" + makerSFinalPoints
				+ ", leisure1=" + leisure1 + ", leisure2=" + leisure2 + ", leisureCard=" + leisureCard
				+ ", frontPointsofIdleReplacementCards=" + frontPointsofIdleReplacementCards + ", leisureHomePoints="
				+ leisureHomePoints + ", tableNumber=" + tableNumber + ", issueNumber=" + issueNumber
				+ ", nextIssueNumber=" + nextIssueNumber + ", nextTime=" + nextTime + ", winner=" + winner
				+ ", idleTime=" + idleTime + ", zhuangPairs=" + zhuangPairs + ", size=" + size + ", perfectPair="
				+ perfectPair + ", arbitraryPairs=" + arbitraryPairs + ", state=" + state + ", time=" + time
				+ ", openingTimeOfTheCurrentAward=" + openingTimeOfTheCurrentAward + "]";
	}

	public String getZhuang1() {
		return zhuang1;
	}

	public void setZhuang1(String zhuang1) {
		this.zhuang1 = zhuang1;
	}

	public String getZhuang2() {
		return zhuang2;
	}

	public void setZhuang2(String zhuang2) {
		this.zhuang2 = zhuang2;
	}

	public String getDealerCard() {
		return dealerCard;
	}

	public void setDealerCard(String dealerCard) {
		this.dealerCard = dealerCard;
	}

	public Integer getFrontPointsOfZhuangshi() {
		return frontPointsOfZhuangshi;
	}

	public void setFrontPointsOfZhuangshi(Integer frontPointsOfZhuangshi) {
		this.frontPointsOfZhuangshi = frontPointsOfZhuangshi;
	}

	public Integer getMakerSFinalPoints() {
		return makerSFinalPoints;
	}

	public void setMakerSFinalPoints(Integer makerSFinalPoints) {
		this.makerSFinalPoints = makerSFinalPoints;
	}

	public String getLeisure1() {
		return leisure1;
	}

	public void setLeisure1(String leisure1) {
		this.leisure1 = leisure1;
	}

	public String getLeisure2() {
		return leisure2;
	}

	public void setLeisure2(String leisure2) {
		this.leisure2 = leisure2;
	}

	public String getLeisureCard() {
		return leisureCard;
	}

	public void setLeisureCard(String leisureCard) {
		this.leisureCard = leisureCard;
	}

	public Integer getFrontPointsofIdleReplacementCards() {
		return frontPointsofIdleReplacementCards;
	}

	public void setFrontPointsofIdleReplacementCards(Integer frontPointsofIdleReplacementCards) {
		this.frontPointsofIdleReplacementCards = frontPointsofIdleReplacementCards;
	}

	public Integer getLeisureHomePoints() {
		return leisureHomePoints;
	}

	public void setLeisureHomePoints(Integer leisureHomePoints) {
		this.leisureHomePoints = leisureHomePoints;
	}

	public Integer getTableNumber() {
		return tableNumber;
	}

	public void setTableNumber(Integer tableNumber) {
		this.tableNumber = tableNumber;
	}

	public String getIssueNumber() {
		return issueNumber;
	}

	public void setIssueNumber(String issueNumber) {
		this.issueNumber = issueNumber;
	}

	public String getNextIssueNumber() {
		return nextIssueNumber;
	}

	public void setNextIssueNumber(String nextIssueNumber) {
		this.nextIssueNumber = nextIssueNumber;
	}

	public String getNextTime() {
		return nextTime;
	}

	public void setNextTime(String nextTime) {
		this.nextTime = nextTime;
	}

	public Integer getWinner() {
		return winner;
	}

	public void setWinner(Integer winner) {
		this.winner = winner;
	}

	public Integer getIdleTime() {
		return idleTime;
	}

	public void setIdleTime(Integer idleTime) {
		this.idleTime = idleTime;
	}

	public Integer getZhuangPairs() {
		return zhuangPairs;
	}

	public void setZhuangPairs(Integer zhuangPairs) {
		this.zhuangPairs = zhuangPairs;
	}

	public Integer getState() {
		return state;
	}

	public void setState(Integer state) {
		this.state = state;
	}

	public String getTime() {
		return time;
	}

	public void setTime(String time) {
		this.time = time;
	}
	
	public Integer getSize() {
		return size;
	}

	public void setSize(Integer size) {
		this.size = size;
	}

	public Integer getPerfectPair() {
		return perfectPair;
	}

	public void setPerfectPair(Integer perfectPair) {
		this.perfectPair = perfectPair;
	}

	public Integer getArbitraryPairs() {
		return arbitraryPairs;
	}

	public void setArbitraryPairs(Integer arbitraryPairs) {
		this.arbitraryPairs = arbitraryPairs;
	}

	
	public String getOpeningTimeOfTheCurrentAward() {
		return openingTimeOfTheCurrentAward;
	}

	public void setOpeningTimeOfTheCurrentAward(String openingTimeOfTheCurrentAward) {
		this.openingTimeOfTheCurrentAward = openingTimeOfTheCurrentAward;
	}
	private Integer id;
	
	private String zhuang1;//庄家开奖第一张牌
	
	private String zhuang2;//庄家开奖第二张牌
	
	private String dealerCard;//庄家补牌
	
	private Integer frontPointsOfZhuangshi;//庄家补牌前点数
	
	private int makerSFinalPoints;//庄家最终点数
	
	private String leisure1;//闲家第一张牌
	
	private String leisure2;//闲家第二张牌
	
	private String leisureCard;//闲家补牌
	
	private Integer frontPointsofIdleReplacementCards;//闲家补牌前点数
	
	private int leisureHomePoints;//闲家最终点数
	
	private Integer tableNumber;//开奖桌号
	
	private String issueNumber;//开奖期号
	
	private String nextIssueNumber;//下期开奖期号
	
	private String nextTime;//下期开奖时间
	
	private Integer winner;//开奖状态  0-闲家赢 1-庄家赢  2-和局
	
	private Integer idleTime;//闲对 0-没有闲对 1-有闲对
	
	private Integer zhuangPairs;//庄对 0-没有庄对 1-有庄对
	
	private Integer size;// '0-小   1-大',
	
	private Integer perfectPair;//'完美对子 0-没有完美对子   1-有完美对子',
	
	private Integer arbitraryPairs;//任意对子 0-没有任意对子  1有任意对子',
	
	private Integer state;//在一期开奖还是未开奖 0-未开奖 1-开奖
	
	private String time;//派奖时间
	
	private String openingTimeOfTheCurrentAward;//当期开奖时间
	
}
