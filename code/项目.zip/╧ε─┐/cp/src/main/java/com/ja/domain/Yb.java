package com.ja.domain;

import java.io.Serializable;
import java.util.Arrays;

public class Yb implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = -1513407935291096331L;
	//点数
	private String ds;
	//时间
	private String sj;
	//闲的硬币是哪个地方的
	private String fq1;
	//坐标
	private Integer top1;
	//坐标
	private Integer left1;
	
	private Integer left[];
	private String fq[];
	private Integer top[];
    
    public static long getSerialversionuid() {
		return serialVersionUID;
	}
	public String getDs() {
		return ds;
	}
	public void setDs(String ds) {
		this.ds = ds;
	}
	public String getSj() {
		return sj;
	}
	public void setSj(String sj) {
		this.sj = sj;
	}
	public String getFq1() {
		return fq1;
	}
	public void setFq1(String fq1) {
		this.fq1 = fq1;
	}
	public Integer getTop1() {
		return top1;
	}
	public void setTop1(Integer top1) {
		this.top1 = top1;
	}
	public Integer getLeft1() {
		return left1;
	}
	public void setLeft1(Integer left1) {
		this.left1 = left1;
	}
	public Integer[] getLeft() {
		return left;
	}
	public void setLeft(Integer[] left) {
		this.left = left;
	}
	public String[] getFq() {
		return fq;
	}
	public void setFq(String[] fq) {
		this.fq = fq;
	}
	public Integer[] getTop() {
		return top;
	}
	public void setTop(Integer[] top) {
		this.top = top;
	}
	@Override
	public String toString() {
		return "Yb [ds=" + ds + ", sj=" + sj + ", fq1=" + fq1 + ", top1=" + top1 + ", left1=" + left1 + ", left="
				+ Arrays.toString(left) + ", fq=" + Arrays.toString(fq) + ", top=" + Arrays.toString(top) + "]";
	}

	
}
