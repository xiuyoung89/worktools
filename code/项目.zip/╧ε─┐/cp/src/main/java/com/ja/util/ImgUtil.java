package com.ja.util;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.image.BufferedImage;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;

import javax.imageio.ImageIO;

/**
 * <style>*{font-size: 14px;font-weight: bold;}div{height:28px;margin-bottom:-23px;}img {position: fixed;bottom: 10px;right: 10px;height: 50px;}span{border: 3px solid blue;color: white;background: blue;display: inline-block;box-shadow: 2px 2px gray;margin: 2px 10px;margin-left: 40px;}l div{font-size:40px;display: inline-block;line-height: 16px;position: absolute;margin-top: -3px;font-weight: lighter;color: red;}p{font-weight: lighter;margin-top: 22px;}l{display: inline-block;width: 80px;text-align: right;color: black;margin-top:10px;}</style><img src="https://a3.qpic.cn/psb?/V13i62Dj12ePbQ/NZmahM6aAmswZqIzVUkRHAvJMKUvnBP*ccASpf*fwec!/m/dF4BAAAAAAAAnull&bo=zwGhAAAAAAADB00!&rf=photolist&t=5"></img><div class="me" style="margin-top:-26px;"><p><b>　描述：</b>
 * 图片工具类
 * </p><l>INFO<div>☞</div></l><span>Title：ImgUtil.java　　　Vers：1.0
 * </span><br><l>Date<div>☞</div></l><span>2018年5月16日 下午5:39:03
 * </span><br><l>Author<div>☞</div></l><span>Bean
 * </span></div>
 */
public class ImgUtil {
	public static void main(String[] args) {
		String arr2[]={"特等奖","8888","88882"};
		String arr3[]={"一等奖","8888","88883"};
		String arr4[]={"二等奖","8888","88884"};
		String arr5[]={"三等奖","8888","88885"};
		String arr6[]={"四等奖","8888","88886"};
		String arr7[]={"五等奖","8888","88887"};
		String arr8[]={"六等奖","8888","88888"};
		createImage("祝你好运","d:/20180510174832.png",arr2,arr3,arr4,arr5,arr6,arr7,arr8, "d:/1.png");
		
	}
	static int lv = 5;
	static int size = 480*lv;
	static int fontSize1=22*lv;
	static int fontSize2=40*lv;
	static int fontSize3=17*lv;
	static int hight1=30*lv;
	static int hight2=80*lv;
	static int hight3=84*lv;
	static int hight4=130*lv;
	static Font font1=new Font("等线",Font.BOLD, fontSize1);
	static Font font2=new Font("Myriad Pro Cond",Font.BOLD, fontSize2);
	/**
	 * @Desc 生成扇形
	 * @EG   
	 * @Auth lbq
	 * @param arr1 arr2 arr3 arr4 arr5 arr6 arr7 arr8
	 * @param zhunihaoyun 祝你好运图片路径
	 * @param path 保存路径
	 * @return 如果保存成功返回true 失败返回false
	 */
	public static boolean createImage(String arr1,String zhunihaoyun,String arr2[],String arr3[],String arr4[],String arr5[],String arr6[],String arr7[],String arr8[],String path) {
		BufferedImage image = new BufferedImage(size, size, BufferedImage.TYPE_INT_RGB);
		Graphics2D g = image.createGraphics();
		g.setRenderingHint(RenderingHints.KEY_ANTIALIASING	, RenderingHints.VALUE_ANTIALIAS_ON);
		g.setColor(new Color(0x41BBDF));
		g.fillArc(0,0,size,size,90,45);
		g.setColor(new Color(0xFFF8C4));
		g.fillArc(0,0,size,size,135,45);
		g.setColor(new Color(0xF05D38));
		g.fillArc(0,0,size,size,180,45);
		g.setColor(new Color(0xFFF8C4));
		g.fillArc(0,0,size,size,225,45);
		g.setColor(new Color(0xF66AAA));
		g.fillArc(0,0,size,size,270,45);
		g.setColor(new Color(0xFFF8C4));
		g.fillArc(0,0,size,size,315,45);
		g.setColor(new Color(0x8A80F8));
		g.fillArc(0,0,size,size,360,45);
		g.setColor(new Color(0xFFF8C4));
		g.fillArc(0,0,size,size,45,45);
		try {
			image = rotateImage(image,22.5);
			Graphics2D g1 = image.createGraphics();
			g1.setRenderingHint(RenderingHints.KEY_ANTIALIASING	, RenderingHints.VALUE_ANTIALIAS_ON);
			g1.setFont(font1);
			g1.drawString(arr1, size/2-arr1.length()/2*fontSize1, hight1);
			
			int imageSize=80*lv;
			BufferedImage image1=ImageIO.read(new File(zhunihaoyun));
			g1.drawImage(image1, (size-imageSize)/2, 40*lv,imageSize,imageSize, null);
			
			
			image=name(image, arr2,0xFB5A32);
			image=name(image, arr3,0xFFF8C4);
			image=name(image, arr4,0xFB5A32);
			image=name(image, arr5,0xFFF8C4);
			image=name(image, arr6,0xFB5A32);
			image=name(image, arr7,0xFFF8C4);
			image=name(image, arr8,0xFB5A32);
			image = rotateImage(image,45.0);
			
			image = resizeImage(image, 500, 500);
			File f=new File(path.substring(0, 
					path.lastIndexOf("/")));
			f.mkdirs();
			FileOutputStream fosFileOutputStream=new FileOutputStream(new File(path));
			ByteArrayOutputStream baos = new ByteArrayOutputStream();
			ImageIO.write(image, "PNG", baos);
			byte[] buffer = baos.toByteArray();
			fosFileOutputStream.write(buffer);
			baos.close();
			fosFileOutputStream.close();
			return true;
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
	}
	private static BufferedImage name(BufferedImage image,String arr[],int color) {
		image = rotateImage(image,45.0);
		Graphics2D g = image.createGraphics();
		g.setRenderingHint(RenderingHints.KEY_ANTIALIASING	, RenderingHints.VALUE_ANTIALIAS_ON);
		g.setColor(new Color(color));
		g.setFont(font1);
		g.drawString(arr[0], size/2-(int)(arr[0].length()/2.0*fontSize1), hight1);
		g.setFont(font2);
		g.drawString(arr[1], size/2-(int)(arr[1].length()/2.0*fontSize3), hight2);
		g.fillRect(size/2-2*lv,hight3,4*lv,14*lv);
		g.setFont(font2);
		g.drawString(arr[2], size/2-(int)(arr[2].length()/2.0*fontSize3), hight4);
		g.dispose();
		return image;
	}
	//旋转图片
	private static BufferedImage rotateImage(final BufferedImage bufferedimage, final Double degree) {
        int w = bufferedimage.getWidth();
        int h = bufferedimage.getHeight();
        int type = bufferedimage.getColorModel().getTransparency();
        BufferedImage img;
        Graphics2D graphics2d;
        (graphics2d = (img = new BufferedImage(w, h, type))
                .createGraphics()).setRenderingHint(
                RenderingHints.KEY_INTERPOLATION,
                RenderingHints.VALUE_INTERPOLATION_BILINEAR);
        graphics2d.rotate(Math.toRadians(degree), w / 2, h / 2);
        graphics2d.drawImage(bufferedimage, 0, 0, null);
        graphics2d.dispose();
        return img;
    }
//	缩放图片
	private static BufferedImage resizeImage(final BufferedImage bufferedimage,
            final int w, final int h) {
        int type = bufferedimage.getColorModel().getTransparency();
        BufferedImage img;
        Graphics2D graphics2d;
        (graphics2d = (img = new BufferedImage(w, h, type))
                .createGraphics()).setRenderingHint(
                RenderingHints.KEY_INTERPOLATION,
                RenderingHints.VALUE_INTERPOLATION_BILINEAR);
        graphics2d.drawImage(bufferedimage, 0, 0, w, h, 0, 0, bufferedimage
                .getWidth(), bufferedimage.getHeight(), null);
        graphics2d.dispose();
        return img;
    }
}
