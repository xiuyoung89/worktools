package com.ja.domain;

import java.io.Serializable;
import java.util.Date;

import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.ja.util.JsonDateValue;

/**
 * 关于代理返点率的实体类
 * Created by CY on 28,Feb,2018
 *
 */
public class AgentRebate implements Serializable {

	private static final long serialVersionUID = 8403516722848960377L;
	
	private Integer id;
	private Integer userid;
	private String username;
	private Double deposit;
	private Double rebateRate;
	private Date createdTime;
	private String createdUser;
	public AgentRebate() {
		super();
	}
	public AgentRebate(Integer id, Integer userid, String username, Double deposit, Double rebateRate, Date createdTime,
			String createdUser) {
		super();
		this.id = id;
		this.userid = userid;
		this.username = username;
		this.deposit = deposit;
		this.rebateRate = rebateRate;
		this.createdTime = createdTime;
		this.createdUser = createdUser;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public Integer getUserid() {
		return userid;
	}
	public void setUserid(Integer userid) {
		this.userid = userid;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public Double getDeposit() {
		return deposit;
	}
	public void setDeposit(Double deposit) {
		this.deposit = deposit;
	}
	public Double getRebateRate() {
		return rebateRate;
	}
	public void setRebateRate(Double rebateRate) {
		this.rebateRate = rebateRate;
	}
	@JsonSerialize(using=JsonDateValue.class)
	public Date getCreatedTime() {
		return createdTime;
	}
	public void setCreatedTime(Date createdTime) {
		this.createdTime = createdTime;
	}
	public String getCreatedUser() {
		return createdUser;
	}
	public void setCreatedUser(String createdUser) {
		this.createdUser = createdUser;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((createdTime == null) ? 0 : createdTime.hashCode());
		result = prime * result + ((createdUser == null) ? 0 : createdUser.hashCode());
		result = prime * result + ((deposit == null) ? 0 : deposit.hashCode());
		result = prime * result + ((id == null) ? 0 : id.hashCode());
		result = prime * result + ((rebateRate == null) ? 0 : rebateRate.hashCode());
		result = prime * result + ((userid == null) ? 0 : userid.hashCode());
		result = prime * result + ((username == null) ? 0 : username.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		AgentRebate other = (AgentRebate) obj;
		if (createdTime == null) {
			if (other.createdTime != null)
				return false;
		} else if (!createdTime.equals(other.createdTime))
			return false;
		if (createdUser == null) {
			if (other.createdUser != null)
				return false;
		} else if (!createdUser.equals(other.createdUser))
			return false;
		if (deposit == null) {
			if (other.deposit != null)
				return false;
		} else if (!deposit.equals(other.deposit))
			return false;
		if (id == null) {
			if (other.id != null)
				return false;
		} else if (!id.equals(other.id))
			return false;
		if (rebateRate == null) {
			if (other.rebateRate != null)
				return false;
		} else if (!rebateRate.equals(other.rebateRate))
			return false;
		if (userid == null) {
			if (other.userid != null)
				return false;
		} else if (!userid.equals(other.userid))
			return false;
		if (username == null) {
			if (other.username != null)
				return false;
		} else if (!username.equals(other.username))
			return false;
		return true;
	}
	@Override
	public String toString() {
		return "AgentRebate [id=" + id + ", userid=" + userid + ", username=" + username + ", deposit=" + deposit
				+ ", rebateRate=" + rebateRate + ", createdTime=" + createdTime + ", createdUser=" + createdUser + "]";
	}
	
	
	
}
