package com.ja.dao;

public interface YunyingbbMapper {

}
