package com.ja.sevice;

import java.util.List;

import com.ja.domain.Attribute;
import com.ja.domain.Data;
import com.ja.domain.PlayCount;
import com.ja.domain.Product;

public interface IDataService {

	/**查找所有最新data*/
	List<Data> getLatestData();

	List<Data> getDatasbyCname(String cName);
	
	Data getLotteryDate(String period,String cname);

	/**查询某个彩种的开奖记录 */
	List<Data> getAllData(String cname,String date);
	
	List<Data> getCheckData(Integer startIndex, Integer lineCount, String cname, int model);

	/**根据条件查询开奖记录 
	 * @param i 
	 * @param integer2 
	 * @param integer */
	List<Data> getMhAllData(Integer integer, Integer integer2, Data data, String date1, String date2, int i);

	/**查询所有的开奖记录*/
	List<Data> getSouyou();
	
	/**某个彩种一天的开奖记录*/
	List<Data> findTodycz(String cname);
	
	/**北京pk10*/
	List<Data> findBjpk10();
	
	/**六合彩预设记录*/
	List<Data> getAllLiuhePreset();

	/**修改系统彩的开奖状态*/
	int addLiuheCheck(Data data);

	/** 批量新增彩票数据 */
	int insertByBatch(List<Data> datas);
	
	/** 手动开奖填写开奖号码 */
	int updateCheckNum(Data data);

	/**手动彩票派奖*/
	int updateCheck(Data data);

	/**未开奖的数据*/
	List<Data> findNull();
	
	/**最大一期的期号*/
	Data getMaxPeriod(String cname);

	/**添加开奖时间*/
	int updateDate(Data data);
	
	/**修改香港六合彩属性*/
	int updateAttributes(Attribute attribute);

	/**查看所有的属性*/
	List<Attribute> findAllAttribute();
	
	/**xg6hc*/
	int xg6hc(String cName);
	/**查询香港六合彩最新的两条数据*/
	Data xg6hcchax(String period);
	/**删除*/
	int xglhcDelete(String period,String cname);
	
	Data Verification(String cName,String period);

	/**官方异常修改状态*/
	int updateFail(Data data);
	

	/**
	 * 下期开奖时间
	 * @param name 彩种名称
	 * @param time 下注时间
	 * @param time3 下期时间
	 * @return
	 */
	Data findBetsTime(String name, String time, String time3);
	
	/**
	 * 批量更新
	 * @param updateDatas
	 */
	void updateByBatch(List<Data> updateDatas);
	
	/**
	 * 查询开奖信息
	 * @return
	 */
	List<Data> findDatas(List<Data> data);

	/**
	 * 添加私彩期号
	 * @param datas 期号信息
	 * @return
	 */
	int addSystemLotters(List<Data> datas);

	/**
	 * 查询最新的一期开奖信息
	 * @param cname 彩种名称
	 * @param time 
	 * @return
	 */
	Data findNewestPeriod(String cname, String time);

	/**
	 * 添加私彩开奖号码
	 * @param data 开奖信息
	 * @return
	 */
	int addSystemLotterInfo(Data data);
	
	/**
	 * 私彩控制比例
	 * @return
	 */
	double findSystemLotterRatio();

	/**
	 * 查询期号是否已经插入
	 * @param cname 彩种英文名
	 * @param newPeriod 第一期期号
	 * @return
	 */
	Data findLotterFirstPeriod(String cname, String newPeriod);

	/**
	 * 查询最后一期
	 * @param cname 彩种英文名
	 * @param time 当前时间
	 * @return
	 */
	Data findLotterLastPeriod(String cname, String time);
	
	/**
	 * 查询期数中包含日期信息的彩种的当天最新期数
	 * @param cName
	 * @param periodLike
	 * @return
	 */
	String getTodayLatestPeriodOfNormalCp(String cName, String periodLike);

	/**
	 * 查询期数中不包含日期信息的彩种的当天最新期数
	 * @param cName
	 * @param startPeriod
	 * @param startPeriod
	 * @return
	 */
	String getTodayLatestPeriodOfSpecialCp(String cName, String startPeriod, String endPeriod);
	
	/**
	 * 六合彩添加开奖期号
	 * @param data 彩种信息
	 * @param num 状态量
	 * @return
	 */
	int addLiuheChecks(Data data);

	/**
	 * 根据彩种名称和期数查询相应数据
	 * @param cname
	 * @param period
	 * @return
	 */
	Data findDataByNameAndPeriod(String cname, String period);

	/**
	 * 根据彩种名称查出已经开奖的最新一期数据
	 * @param cname
	 * @return
	 */
	Data getLatestOpenData(String cname);

	/**
	 * 更新开奖号码为空串
	 * @param id
	 */
	void updateLotterNumberToEmptyStr(Integer id);

	/**
	 * 根据ID查数据
	 * @param id
	 * @return
	 */
	Data findById(Integer id);

	/**
	 * 查询预设的旗号
	 * @param cname
	 * @param time1
	 * @return
	 */
	Data findBySetCname(String cname, String time);

	/**
	 * 修改开奖结果
	 * @param data
	 * @return
	 */
	int updateCheckState(Data data);

	/**
	 * 添加开奖结果
	 * @param data 彩种信息
	 * @return
	 */
	int updatePlayResult(Data data);

	/**
	 * 查询六合的属性
	 * @param type 
	 * @return
	 */
	List<Data> findLiuHeAttribute(int type);

	/**
	 * 查询私彩玩法下注详情
	 * @param data 彩种信息
	 * @return
	 */
	List<PlayCount> findPlayDetails(Data data);

	/**
	 * 修改开奖的状态
	 * @param data 彩种信息
	 * @return
	 */
	int changeCheckState(Data data);

	/**
	 * 查询官方下期开奖
	 * @param cname
	 * @return
	 */
	Data findNextPeriod(String cname);


	/**
	 * 把爬到的开奖号。更新进去
	 * @param period
	 * @param lotterNumber
	 * @param lotterTime
	 * @return
	 */
	int update(String cname,String period,String lotterNumber,String lotterTime);
	/**
	 * 根据彩种名称和期号查询当期开奖信息并拿到下期开奖期号
	 * @param cName:彩种名称
	 * @param period：期号
	 * @return
	 */
	Data querynextIssueNumber(String cName,String nextperiod);
	
	/**
	 * 根据彩种名称和时间查询第一次开奖时间
	 * @param cname
	 * @param time
	 * @return
	 */
	Product selectDateTime(String cname,String time);
	/**
	 * 根据彩种名称和id查询下期开奖时间
	 * @param cname
	 * @param id
	 * @return
	 */
	Product dateTime(String cname,int id);

	/**
	 * 更新status为1
	 * @param id
	 */
	void updateStatusTo1(Integer id);
	
	/**
	 * 更新当前期号和之前的数据的status为1
	 * @param cname
	 * @param id
	 */
	void updatePreDataStatusTo1(String cname,Integer id);

	/**
	 * 上期的时间
	 * @param id
	 * @param cname
	 * @return
	 */
	String findLastTime(Integer id, String cname);

	/**
	 * 根据某一个时间点（格式为yyyy-MM-dd HH:mm:ss）获取21-2个彩种的当前期数据
	 * @param nowTime
	 * @return
	 */
	List<Data> findCurrDatas(String nowTime);

	/**
	 * 插入一条数据
	 * @param data
	 */
	void insert(Data data);

	/**
	 * 分页查询数据
	 * @param iDisplayStart 起始数
	 * @param iDisplayLength结束数
	 * @return
	 */
	List<Data> getPageData(int iDisplayStart, int iDisplayLength);

	/**
	 * 根据彩种名称查询最新的信息
	 * @param cname 彩种名称
	 * @return
	 */
	List<Data> getLimitDataInfo(String cname);
	/**
	 * 获取数据库总条数
	 * @return
	 */
	Integer count();
	/**
	 * 查询上周数据
	 * @return
	 */
	List<Data> lastWeek();
	
	/**
	 * 查询上月数据
	 * @return
	 */
	List<Data> lastMonth();
	/**
	 * 批量删除Data表数据
	 * @param data
	 * @return
	 */
	int deletedata(List<Data> data);

	/**
	 * 
	    *   方法名：getCheckDataCounts   
	    *   描述：    根据彩种名称查询开奖记录数                   TODO   
	    *   参数：    @param cname
	    *   参数：    @return 
	 * @return: Integer
	 */
	Integer getCheckDataCounts(String cname);

	/**
	 * 
	    *   方法名：getMhAllDataCounts   
	    *   描述：                       TODO   
	    *   参数：    @param data
	    *   参数：    @param date1
	    *   参数：    @param date2
	    *   参数：    @return 
	 * @return: Integer
	 */
	Integer getMhAllDataCounts(Data data, String date1, String date2);

	/**
	 * 
	   *   方法名：lotterDatas   
	   *   描述：    根据时间查询开奖信息                   TODO   
	   *   参数：    @param cname 彩种名称
	   *   参数：    @param type 查询类型
	   *   参数：    @return 
	 * @return: List<Data>
	 */
	List<Data> lotterDatas(String cname, Integer type);

	/**
	 * 
	   *   方法名：findNextPeriod   
	   *   描述：     下下期时间             TODO   
	   *   参数：    @param cname 彩种名称
	   *   参数：    @param type 查询类型 
	   *   参数：    @return 
	 * @return: Data
	 */
	Data findNextNextPeriod(String cname, Integer type);
	/**
	 * 查询香港六合彩最新一期id
	 * @return
	 */
	Integer xg6hcId();
	/**
	 * 根据彩种名期号修改当期 开奖时间和下期开奖时间 修改字段则是 nextStopOrderTimeEpoch  openTime
	 * @param cName  彩种名
	 * @param period 期号 
	 * @param openTime 开奖时间
	 * @param nextStopOrderTimeEpoch  下期开奖时间
	 * @param status 开奖时间
	 * @return  修改成功则返回1  只要返回别的都是不成功
	 */
	int  updataNextDate(String cName,String period,String openTime,String nextStopOrderTimeEpoch,int status);

	/**
	   *   方法名：findPlayMaxAttr   
	   *   描述：      查询最大玩法下注最多的属性                 TODO   
	   *   参数：    @param data
	   *   参数：    @return 
	 * @return: PlayCount
	 */
	PlayCount findCplay(PlayCount play);

	/**
	 * 
	   *   方法名：findTrend   
	   *   描述：     查询近期的走势图                  TODO   
	   *   参数：    @param time
	   *   参数：    @return 
	 * @param cname 
	 * @return: List<Data>
	 */
	List<Data> findTrend(String time, String cname);
	
	/**
	 * 修改香港六合彩开奖status状态
	 */
	int statusXg6hc(Data data);
	/**
	 * 根据传入的期号查询当期的整条数据
	 * @param cname 彩种名称
	 * @param period 需要查询的期号
	 * @return
	 */
	Data pueryCurrentPeriod(String cname,String period);
	/**
	 * 查询当前全部彩种没有开出来的数据
	 * @param cName
	 * @return
	 */
	List<Data> queryData(String cName);
	/**
	 * 查询数据库里面异常的数据 
	 * @return
	 */
	List<Data> databaseExceptionData();
	/**
	 * 查询每个彩种最后一条数据
	 * @param cName 彩种名称
	 * @return
	 */
	Data theLastItem(String cName);
	/**
	 * 根据当前期号查询上期期号 如果查询到返回Data对象 如果没有查询到则返回null
	 * @param cName  彩种名称
	 * @param period   当期期号
	 * @return  如果查询到就返回Data对象 如果没有查询到则返回null
	 */
	Data previousIssue(String cName,String period);
	/**
	 * 统计数据库里面开奖异常的数据有多少条
	 * @return 返回异常数据的总条数
	 */
	Integer getAbnormalData();
	/**
	 * 根据彩种名称和期号修改开奖状态     把status状态修改成1
	 * @param cname  彩种名称
	 * @param period  期号
	 * @return 修改成则返回1 返回别的都是不成功的
	 */
	int updataCnameStatus(String cname,String period);

	/**
	 * 根据彩种名和期号修改下期开奖时间  修改字段为 nextStopOrderTimeEpoch
	 * @param cname  彩种名
	 * @param period 期号  是当期期号不是下期期号 
	 * @param nextStopOrderTimeEpoch 修改时间的值
	 * @return 修改成功则返回1 返回其他的都是错误的
	 */
	int upDataNextTime(String cname,String period,String nextStopOrderTimeEpoch);
	/**
	 * 查询彩种中文名和英文名，
	 * @return 查询到则 返回list集合包含data实体类 
	 */
	List<Data> wholeLot();
	/**
	 * 根据id查询他下期开奖数据
	 * @param id 
	 * @param cname 彩种名 
	 * @return 返回比他id还大的数据
	 */
	Data Id(Integer id,String cname);
	/**
	 * 保存计划的开奖数据
	 * @param d  开奖数据对象
	 * @return 成功则返回0
	 */
	int Preservation(Data d);
	/**
	 * 查询排列的计划
	 * @param cName 彩种名称 
	 * @param period 开奖期号
	 * @return 如果后台预设了 在一期 则返回当期开奖数据  如果没有预设则返回null
	 */
	Data lotteryData(String cName,String period);
	/**
	 * 修改系统彩 预设号码
	 * @param d
	 * @return
	 */
	int systemLotterUpData(Data d);
	/**
	 * 删除计划表里面的计划数据
	 * @param cName 彩种名
	 * @param period 期号
	 * @return 删除成功则返回1 失败则返回0
	 */
	int deleteLotterSystemData(String cName,String period);
	
	/**
	 * 查询数据库里面最新的一条数据
	 * @param cName  彩种名称
	 * @return 查询到则返回Data对象数据  没查询到则返回null
	 */
	Data dataLast(String cName);
}

