package com.ja.dao;

import java.util.List;

/**
 * @DESC: 
 * @AUTH: qhzh 
 * @DATE: 2018年9月15日 上午9:30:28
 */
public interface CpDataAPIMapper {

	List<String> findValidApiUrls();
}
