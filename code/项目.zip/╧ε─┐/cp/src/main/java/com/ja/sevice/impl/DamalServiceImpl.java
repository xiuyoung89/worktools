package com.ja.sevice.impl;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.ja.dao.DamaMapper;
import com.ja.dao.DamalMapper;
import com.ja.dao.LiushuiMapper;
import com.ja.dao.OperationlogMapper;
import com.ja.dao.UserMapper;
import com.ja.domain.AdminUser;
import com.ja.domain.Dama;
import com.ja.domain.Damal;
import com.ja.domain.Liushui;
import com.ja.domain.Operationlog;
import com.ja.domain.User;
import com.ja.sevice.DamalService;
import com.ja.util.DateUtil;
import com.ja.util.JsonResult;

@Service
/**
 * @author GL 会员打码记录-
 * @DATE 2018年1月15日 18:03:40
 */
public class DamalServiceImpl implements DamalService {

	@Autowired
	private DamalMapper damalMapper;
	
	@Autowired
	private DamaMapper damaMapper;
	
	@Autowired
	private UserMapper userMapper;
	
	@Autowired
	private LiushuiMapper liushuiMapper;
	
	@Autowired
	private OperationlogMapper operationlogMapper;

	@Override
	public List<Damal> getAlldamal() {
		return damalMapper.getAlldamal();
	}

	@Override
	public int upDamal(Integer id,Integer state) {
		Damal dama = new Damal();
		dama.setUserid(id);
		dama.setState(state);
		dama.setCreatetime(DateUtil.getCurrTime());
		return damalMapper.updateDamal(dama);
	}

	@Override
	public int updateDamal(Damal d,Dama d1) {
		int a = damalMapper.updateDamal(d);
		int b = damaMapper.addDama(d1);
		return a+b;
	}

	/**获取当前某个人的打码信息*/
	@Override
	public Damal getOnedamal(Integer id) {
		return damalMapper.getOnedamal(id);
	}

	/**添加某个人的打码信息*/
	@Override
	public int addamal(Damal d) {
		return damalMapper.addamal(d);
	}

	/** 根据条件查询会员打码量及提款所需 */
	@Override
	public List<Damal> mhOneDama(Damal damal) {
		return damalMapper.mhOneDama(damal);
	}
	
	/**
	  *  流水记录变动记录
	 * @param user   用户信息
	 * @param state  true 收入 false 支出
	 * @param cname1 彩种中文名
	 * @param period 彩种期号
	 * @param money  变动金额
	 * @param model  变动类型
	 * @return
	 */
	public int flowChange(User user, boolean state, String cname1, String period, double money, String model,String orderNum) {
		user = userMapper.getUserByid(user.getId());
		double amount = 0.00;
		if (state) {
			amount = user.getBalance() + money;
		} else {
			amount = user.getBalance() - money;
		}
		Liushui flow = new Liushui();
		flow.setHuiyuanzh(user.getName());
		flow.setBdtype(model);
		flow.setBdqjine(user.getBalance());
		flow.setBdjine(money);
		flow.setBdhjine(amount);
		flow.setCreatetime(DateUtil.getCurrTime());
		flow.setOrdernum(orderNum);
		flow.setCname(cname1);
		flow.setPeriod(period);
		flow.setCzname("系统自动");
		flow.setBeizhu(model);
		flow.setState(state);
		flow.setUser_type(user.getState());
		flow.setUserid(user.getId());
		user.setBalance(amount);
		user.setCreatetime(DateUtil.getCurrTime());
		liushuiMapper.addUserFlowingWaterRecrod(flow);
		userMapper.updateUserInfo(user);
		return 1;
	}

	@Transactional
	@Override
	public JsonResult updateCodeCount(Dama dama, AdminUser admin) {
		Damal damal = damalMapper.getOnedamal(dama.getUserid());
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		String date3 = sdf.format(new Date());
		String key = dama.getBdtype();
		String message = "操作失败";
		int b = 0;
		// 人工增加
		User user = userMapper.getUserByid(dama.getUserid());
		if ("人工增加".equals(key)) {
			dama.setBdqcount(damal.getDamaliang());
			dama.setBdhcount(damal.getDamaliang() + dama.getBdcount());
			dama.setCreatetime(date3);
			dama.setBdqtksx(damal.getTikuansx());
			dama.setBdtksx(0.00);
			dama.setBdhtksx(damal.getTikuansx() - 0.00);
			dama.setCzname(admin.getName());
			dama.setBeizhu("人工增加");
			damal.setDamaliang(damal.getDamaliang() + dama.getBdcount());
			damal.setCreatetime(date3);
			
			Liushui flow = new Liushui();
			flow.setHuiyuanzh(user.getName());
			flow.setBdtype("打码增加");
			flow.setBdqjine(0.00);
			flow.setBdjine(dama.getBdcount());
			flow.setBdhjine(0.00);
			flow.setCreatetime(DateUtil.getCurrTime());
			flow.setOrdernum("D"+DateUtil.DateFormatOrderNum()+user.getId());
			flow.setCname("-");
			flow.setPeriod("-");
			flow.setCzname(admin.getName());
			flow.setBeizhu("打码增加");
			flow.setState(true);
			flow.setUser_type(user.getState());
			flow.setUserid(user.getId());
			liushuiMapper.addUserFlowingWaterRecrod(flow);
		}else {
			dama.setBdqcount(damal.getDamaliang());
			dama.setBdhcount(damal.getDamaliang() - dama.getBdcount());
			dama.setCreatetime(date3);
			dama.setBdqtksx(damal.getTikuansx());
			dama.setBdtksx(0.00);
			dama.setBdhtksx(damal.getTikuansx() - 0.00);
			dama.setCzname(admin.getName());
			dama.setBeizhu("人工扣除");
			damal.setDamaliang(damal.getDamaliang() - dama.getBdcount());
			damal.setCreatetime(date3);
			
			Liushui flow = new Liushui();
			flow.setHuiyuanzh(user.getName());
			flow.setBdtype("打码扣除");
			flow.setBdqjine(0.00);
			flow.setBdjine(dama.getBdcount());
			flow.setBdhjine(0.00);
			flow.setCreatetime(DateUtil.getCurrTime());
			flow.setOrdernum("D"+DateUtil.DateFormatOrderNum()+user.getId());
			flow.setCname("-");
			flow.setPeriod("-");
			flow.setCzname(admin.getName());
			flow.setBeizhu("打码扣除");
			flow.setState(true);
			flow.setUser_type(user.getState());
			flow.setUserid(user.getId());
			liushuiMapper.addUserFlowingWaterRecrod(flow);
		}
		int a = damalMapper.updateDamal(damal);
		int c = damaMapper.addDama(dama);
		b = a + c;
		String remarks = "对用户" + user.getName() + key + "打码量" + dama.getBdcount() + "元";
		if (b == 2) {
			message = "操作成功!";
		} 
		Operationlog oper = new Operationlog();
		oper.setName(admin.getName());
		oper.setOperationtime(DateUtil.getCurrTime());
		oper.setRemarks(remarks);
		oper.setOperationtype("用户打码管理");
		operationlogMapper.addOperationlog(oper);
		return new JsonResult("updateDama", message);
	}


}