package com.ja.sevice;

import java.util.List;

import com.ja.domain.Data;
import com.ja.domain.Joint;
import com.ja.domain.JointVo;

public interface IJointService {
	
	int insertJoint(Joint jo);

	/**查询所有的订单号买*/
	List<String> getFindJoint();
	
	JointVo getAllJoint(String num);
	
	Integer getScountJoint(String num);
    
	/**查询个人参与的合买*/
	List<JointVo> getOneJoint(String num, Integer userid);

	/** 合买失效,实际的合买分数 */
	int getHfenshu(String orderNum);

	/**当前发起人合买信息*/
	Joint getFaqiJoint(String ordernum);

	/**根据当前订单号查询合买的用户信息*/
	List<Integer> getNumJoint(String ordernum);

	/**修改订单生效状态*/
	int upDingDan(List<Integer> ids);

	/**修改实际保底分数
	 * @param sjine */
	int upBaodi(int sjbdfs, double sjine, Integer id);

	/**修改退钱状态*/
	int upTuiQian(List<Integer> ids);

	/**修改剩余分数*/
	int upSyCount(int scount, Integer id, String ordernum);

	/**历史记录*/
	List<Joint> getLishiJl();

	//查询所有的发起人
	List<Joint> chaxunfqr();

	//查询发起人的所有发起次数
	int chaxunsycs(String user);

	//查询发起人的中奖次数
	int chaxunzjcs(String user);

	//查看有没有参加合买
	Joint checkhm(String orderNum, Integer id);

	//查询发起和参与的订单号
	List<String> getOrderNum(int i);
	
	// 个人参与的合买
	List<JointVo> getOneJoint1(String num,Integer userid);

	/**某个彩种某期退钱*/
	List<Joint> getAllUser(Data data);

	/**官方开奖异常*/
	int chedan(Joint or);


}
