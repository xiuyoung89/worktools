package com.ja.dao;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.ja.domain.Data;
import com.ja.domain.Order;
import com.ja.domain.Orders;

public interface OrderMapper {
	
    /**
     *   方法名：awards   
     *   描述：     添加下注订单信息                  TODO   
     *   参数：    @param order 订单信息
     *   参数：    @return 
     * @return: Integer
     */
	Integer awards(Order order);
	
	/**
	 *   方法名：findByIdOrderInfo   
	 *   描述：    根据id查询单条订单                   TODO   
	 *   参数：    @param order_id 订单id
	 *   参数：    @return 
	 * @return: Order
	 */
	Order findByIdOrderInfo(Integer order_id);
	
	/**
	 *   方法名：cancelOrder   
	 *   描述：     彩票投注订单撤单                  TODO   
	 *   参数：    @param order 撤单信息
	 *   参数：    @return 
	 * @return: Integer
	 */
	Integer cancelOrder(Order order);
	
	
	
	
	
	
	
	
	
	
	
	
	
	int awards2(@Param("o") Order o);
    
	/**根据id查询自己的订单详情*/
	List<Order> getMyOrders(@Param("id")Integer id,@Param("cname")String cname);
	List<Order> getMyOrdersdkj(@Param("id")Integer id, @Param("cname")String cname);
	List<Order> getMyOrdersyzj(@Param("id")Integer id, @Param("cname")String cname);
	List<Order> getMyOrdersykj(@Param("id")Integer id, @Param("cname")String cname);
	List<Order> getMyOrdersycd(@Param("id")Integer id, @Param("cname")String cname);

	/**根据id删除订单*/
	int delOrderById(int id);

	int getOrdersByUid(@Param("o")Order o, @Param("date")String date);

	Order getOrder(@Param("o")Order o, @Param("date")String date);
	
	/**获取所有的投注记录*/
	List<Order> getAllJl();
	
	/**根据条件进行查询投注记录
	 * @param model */
	List<Order> getMhAllJl(@Param("startIndex")Integer startIndex, @Param("lineCount")Integer lineCount,@Param("state")Integer state,@Param("date1")String date1,@Param("date2")String date2,@Param("period")String period,@Param("cname")String cname,@Param("huiyuanzh")String huiyuanzh, @Param("model")int model);
	
	/**查询六合投注记录*/
	List<Order> getLiuheJl();

	/**根据条件查询六合投注记录*/
	List<Order> getMhLiuheJl(@Param("o")Order o,@Param("date1")String date1,@Param("date2")String date2);
	
	/**彩种分类*/
	List<Order> fenleiorder(Integer id);
	
	/**当期投注总额*/
	double getOrderSum(Order o);

	/**当期中奖数据*/
	List<Order> getzjdata();
	
	/**下注数据*/
	List<Order> getxzdata(String cname);
	
	/**下注数据 用于前端展示使用*/
	List<Orders> getxzdatas(String cname);
	
	/**查询当天前5单*/
	int getCheckMoney(@Param("id")Integer id,@Param("b")Integer b);
	
	/**个人所有中奖次数*/
	int getAllCheckMoney(Integer id);
	
	/**个人发起跟单次数*/
	int getTouZhuCount(@Param("id")Integer id,@Param("times")String times);
	
	/**彩种当期下注用户*/
	List<Order> getOrderUser(@Param("d")Data data);

	List<Order> getMyOrdersAll(@Param("id")Integer id,@Param("i") Integer i);
	
	/**删除某个时间段的订单*/
	int delOrders(String date);
	
	/**合买单条订单信息*/
	Order getOneOrder(Integer id);
	
	/**每个彩种的打码量*/
	List<Order> getCnameDama(@Param("id")Integer id, @Param("time")String time);
	
	/**
	 * 查询当前开奖订单的信息
	 * @param order 订单信息
	 * @return
	 */
	List<Order> findCheckOrder(Order order);

	/**
	 * 修改开奖后的订单信息
	 * @param order 订单信息
	 * @return
	 */
	int updateCheckInfo(Order order);
	
	/**
	 * 更新和局中奖玩法
	 * @param id 订单id
	 * @param tcPlay 和局的玩法以及退还本金
	 * @return
	 */
	int updateReturnCheckMoney(@Param("id") Integer id,@Param("tcPlay") String tcPlay);

	/**
	 * 查询已开奖的投注总和
	 * @return
	 */
	Double findCheckState(Integer id);
	
	/**
	 * 查询下注订单详情
	 * @param findFormatDate
	 * @return
	 */
	List<Order> findByTimeDetails(String date);
	
	/**
	 * 查询用户相关的订单
	 * @param startIndex
	 * @param lineCount
	 * @param id
	 * @param state
	 * @param cname
	 * @param i
	 * @return
	 */
	List<Order> findMyOrders(@Param("startIndex")Integer startIndex, @Param("lineCount")Integer lineCount, @Param("id") Integer id, @Param("state") Integer state, @Param("cname") String cname, @Param("model")int i);

	/**
	 * 
	    *   方法名：getMhAllJlCounts   
	    *   描述：                       TODO   
	    *   参数：    @param order
	    *   参数：    @return 
	 * @return: Integer
	 */
	Integer getMhAllJlCounts(@Param("order")Order order,@Param("date1")String date1,@Param("date2")String date2); 
	
	/**
	 * 
	    *   方法名：findMyOrders   
	    *   描述：                       TODO   
	    *   参数：    @param order
	    *   参数：    @return 
	 * @return: Integer
	 */
	Integer findMyOrdersCounts(Order order);
	
	/**
	 * 查询用户当期下注的系统彩
	 * @return
	 */
	List<Order> Inquiries(@Param("period")String period,@Param("cName")String cName);

	/**
	 * 
	   *   方法名：findOrderNumberCount   
	   *   描述：    查询相应的投注人数                  TODO   
	   *   参数：    @param startTime
	   *   参数：    @param endTime
	   *   参数：    @param type 查询类型
	   *   参数：    @return 
	 * @param ids 
	 * @return: int
	 */
	int findOrderNumberCount(@Param("startTime")String startTime, @Param("endTime")String endTime, @Param("ids")String ids, @Param("type")int type);

	/**
	 * 方法名：deleteOrderInfo 
	 * 描述：    根据id删除订单信息                  
	 * 参数：    @param id
	 * 参数：    @return 
	 * @return: int
	 */
	int deleteOrderInfo(Integer id);


}
