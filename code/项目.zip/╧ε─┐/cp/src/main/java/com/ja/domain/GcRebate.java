package com.ja.domain;

import java.io.Serializable;

public class GcRebate implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 5840098747954437495L;

	private Integer id;// 港彩投注反水设置表

	private String gc_money;// 反水所需金额

	private Double gc_rebate;// 反水比率
	
	private String created_time; //操作时间

	private Integer gc_state;// 反水开关

    
    public static long getSerialversionuid() {
		return serialVersionUID;
	}
	public GcRebate() {
		super();
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getGc_money() {
		return gc_money;
	}

	public void setGc_money(String gc_money) {
		this.gc_money = gc_money;
	}

	public Double getGc_rebate() {
		return gc_rebate;
	}

	public void setGc_rebate(Double gc_rebate) {
		this.gc_rebate = gc_rebate;
	}

	public String getCreated_time() {
		return created_time;
	}

	public void setCreated_time(String created_time) {
		this.created_time = created_time;
	}

	public Integer getGc_state() {
		return gc_state;
	}

	public void setGc_state(Integer gc_state) {
		this.gc_state = gc_state;
	}

	@Override
	public String toString() {
		return "GcRebate [id=" + id + ", gc_money=" + gc_money + ", gc_rebate=" + gc_rebate + ", created_time="
				+ created_time + ", gc_state=" + gc_state + "]";
	}
}