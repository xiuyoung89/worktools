package com.ja.domain;
/**
 * 第二套代理系统的 代理连接
 * @author Administrator
 *
 */
public class AgentLink {

	
	private Integer id;
	
	private String userName;//代理用户名

	private Integer userId;//代理的Id 就是用户表里面的主键
	
	private String invitationCode;//邀请码
	
	private Double inferiorOdds;//代理设置的赔率
	
	private String iCode;//代理连接
	
	private Integer gamePlayer;//玩家还是代理

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getInvitationCode() {
		return invitationCode;
	}

	public void setInvitationCode(String invitationCode) {
		this.invitationCode = invitationCode;
	}

	public Double getInferiorOdds() {
		return inferiorOdds;
	}

	public void setInferiorOdds(Double inferiorOdds) {
		this.inferiorOdds = inferiorOdds;
	}

	public String getiCode() {
		return iCode;
	}

	public void setiCode(String iCode) {
		this.iCode = iCode;
	}

	public Integer getGamePlayer() {
		return gamePlayer;
	}

	public void setGamePlayer(Integer gamePlayer) {
		this.gamePlayer = gamePlayer;
	}
	public Integer getUserId() {
		return userId;
	}

	public void setUserId(Integer userId) {
		this.userId = userId;
	}
	@Override
	public String toString() {
		return "AgentLink [id=" + id + ", userName=" + userName + ", invitationCode=" + invitationCode
				+ ", inferiorOdds=" + inferiorOdds + ", iCode=" + iCode + ", gamePlayer=" + gamePlayer + ", getId()="
				+ getId() + ", getUserName()=" + getUserName() + ", getInvitationCode()=" + getInvitationCode()
				+ ", getInferiorOdds()=" + getInferiorOdds() + ", getiCode()=" + getiCode() + ", getGamePlayer()="
				+ getGamePlayer() + ", getClass()=" + getClass() + ", hashCode()=" + hashCode() + ", toString()="
				+ super.toString() + "]";
	}

}
