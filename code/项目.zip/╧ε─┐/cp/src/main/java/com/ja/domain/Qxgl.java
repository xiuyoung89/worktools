package com.ja.domain;

import java.io.Serializable;

public class Qxgl implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = -5484639610178898628L;
	private Integer id;
	//用户id
	private Integer adminid;
	//用户名
	private String name;
	//财务管理
	private String cwgl;
	//客户充值记录
	private String khczjl;
	//客户提款记录
	private String khtkjl;
	//会员账变管理
	private String hyzbgl;
	//会员加款扣款
	private String hyjkkk;
	//会员加减打码量
	private String hyjjdml;
	//打码量变动记录
	private String dmlbdjl;
	//彩票记录
	private String cpjl;
	//六合彩赔率设置
	private String lhcplsz;
	//彩票小类设置
	private String cpxlsz;
	//彩票大类设置
	private String cpdlsz;
	//彩票管理
	private String cpgl;
	//彩票投注记录
	private String cptzjl;
	//六合彩投注记录
	private String lhctzjl;
	//彩票开奖结果
	private String cpkjjg;
	//系统彩预设结果
	private String xtcysjg;
	//会员管理
	private String hygl;
	//会员搜索功能
	private String hyssgn;
	//全部代理管理
	private String qbdlgl;
	//代理返点记录
	private String dlfdjl;
	//报表管理
	private String bbgl;
	//全局报表管理
	private String qqbbgl;
	//财务报表管理
	private String cwbbgl;
	//统计概况管理
	private String tjgkgl;
	//运营报表管理
	private String yybbgl;
	//系统风险评估
	private String xtfxpg;
	//会员数据概况
	private String hysjgk;
	//信息公告
	private String xxgg;
	//公告发布管理
	private String ggfbgl;
	//优惠活动管理
	private String yhhdgl;
	//轮播图管理
	private String lbtgl;
	//站内信息管理
	private String znxxgl;
	//活动管理
	private String hdgl;
	//存款赠送策略
	private String ckzscl;
	//客服管理
	private String kfgl;
	//系统设置
	private String xtsz;
	//网站基本设置
	private String wzjbsz;
	//注册选项设置
	private String zcxxsz;
	//会员等级权限
	private String hydjqx;
	//网站入款设置
	private String wzrksz;
	//推广链接管理
	private String tgljgl;
	//后台白名单
	private String htbmd;
	//域名绑定
	private String ymbd;
	//管理员管理
	private String glygl;
	//后台用户管理
	private String htyhgl;
	//后台权限设置
	private String htqxsz;
	//后台操作日志
	private String htczrz;
	//会员登录日志
	private String hydlrz;
    
    public static long getSerialversionuid() {
		return serialVersionUID;
	}
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public Integer getAdminid() {
		return adminid;
	}
	public void setAdminid(Integer adminid) {
		this.adminid = adminid;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getCwgl() {
		return cwgl;
	}
	public void setCwgl(String cwgl) {
		this.cwgl = cwgl;
	}
	public String getKhczjl() {
		return khczjl;
	}
	public void setKhczjl(String khczjl) {
		this.khczjl = khczjl;
	}
	public String getKhtkjl() {
		return khtkjl;
	}
	public void setKhtkjl(String khtkjl) {
		this.khtkjl = khtkjl;
	}
	public String getHyzbgl() {
		return hyzbgl;
	}
	public void setHyzbgl(String hyzbgl) {
		this.hyzbgl = hyzbgl;
	}
	public String getHyjkkk() {
		return hyjkkk;
	}
	public void setHyjkkk(String hyjkkk) {
		this.hyjkkk = hyjkkk;
	}
	public String getHyjjdml() {
		return hyjjdml;
	}
	public void setHyjjdml(String hyjjdml) {
		this.hyjjdml = hyjjdml;
	}
	public String getDmlbdjl() {
		return dmlbdjl;
	}
	public void setDmlbdjl(String dmlbdjl) {
		this.dmlbdjl = dmlbdjl;
	}
	public String getCpjl() {
		return cpjl;
	}
	public void setCpjl(String cpjl) {
		this.cpjl = cpjl;
	}
	public String getLhcplsz() {
		return lhcplsz;
	}
	public void setLhcplsz(String lhcplsz) {
		this.lhcplsz = lhcplsz;
	}
	public String getCpxlsz() {
		return cpxlsz;
	}
	public void setCpxlsz(String cpxlsz) {
		this.cpxlsz = cpxlsz;
	}
	public String getCpdlsz() {
		return cpdlsz;
	}
	public void setCpdlsz(String cpdlsz) {
		this.cpdlsz = cpdlsz;
	}
	public String getCpgl() {
		return cpgl;
	}
	public void setCpgl(String cpgl) {
		this.cpgl = cpgl;
	}
	public String getCptzjl() {
		return cptzjl;
	}
	public void setCptzjl(String cptzjl) {
		this.cptzjl = cptzjl;
	}
	public String getLhctzjl() {
		return lhctzjl;
	}
	public void setLhctzjl(String lhctzjl) {
		this.lhctzjl = lhctzjl;
	}
	public String getCpkjjg() {
		return cpkjjg;
	}
	public void setCpkjjg(String cpkjjg) {
		this.cpkjjg = cpkjjg;
	}
	public String getXtcysjg() {
		return xtcysjg;
	}
	public void setXtcysjg(String xtcysjg) {
		this.xtcysjg = xtcysjg;
	}
	public String getHygl() {
		return hygl;
	}
	public void setHygl(String hygl) {
		this.hygl = hygl;
	}
	public String getHyssgn() {
		return hyssgn;
	}
	public void setHyssgn(String hyssgn) {
		this.hyssgn = hyssgn;
	}
	public String getQbdlgl() {
		return qbdlgl;
	}
	public void setQbdlgl(String qbdlgl) {
		this.qbdlgl = qbdlgl;
	}
	public String getDlfdjl() {
		return dlfdjl;
	}
	public void setDlfdjl(String dlfdjl) {
		this.dlfdjl = dlfdjl;
	}
	public String getBbgl() {
		return bbgl;
	}
	public void setBbgl(String bbgl) {
		this.bbgl = bbgl;
	}
	public String getQqbbgl() {
		return qqbbgl;
	}
	public void setQqbbgl(String qqbbgl) {
		this.qqbbgl = qqbbgl;
	}
	public String getCwbbgl() {
		return cwbbgl;
	}
	public void setCwbbgl(String cwbbgl) {
		this.cwbbgl = cwbbgl;
	}
	public String getTjgkgl() {
		return tjgkgl;
	}
	public void setTjgkgl(String tjgkgl) {
		this.tjgkgl = tjgkgl;
	}
	public String getYybbgl() {
		return yybbgl;
	}
	public void setYybbgl(String yybbgl) {
		this.yybbgl = yybbgl;
	}
	public String getXtfxpg() {
		return xtfxpg;
	}
	public void setXtfxpg(String xtfxpg) {
		this.xtfxpg = xtfxpg;
	}
	public String getHysjgk() {
		return hysjgk;
	}
	public void setHysjgk(String hysjgk) {
		this.hysjgk = hysjgk;
	}
	public String getXxgg() {
		return xxgg;
	}
	public void setXxgg(String xxgg) {
		this.xxgg = xxgg;
	}
	public String getGgfbgl() {
		return ggfbgl;
	}
	public void setGgfbgl(String ggfbgl) {
		this.ggfbgl = ggfbgl;
	}
	public String getYhhdgl() {
		return yhhdgl;
	}
	public void setYhhdgl(String yhhdgl) {
		this.yhhdgl = yhhdgl;
	}
	public String getLbtgl() {
		return lbtgl;
	}
	public void setLbtgl(String lbtgl) {
		this.lbtgl = lbtgl;
	}
	public String getZnxxgl() {
		return znxxgl;
	}
	public void setZnxxgl(String znxxgl) {
		this.znxxgl = znxxgl;
	}
	public String getHdgl() {
		return hdgl;
	}
	public void setHdgl(String hdgl) {
		this.hdgl = hdgl;
	}
	public String getCkzscl() {
		return ckzscl;
	}
	public void setCkzscl(String ckzscl) {
		this.ckzscl = ckzscl;
	}
	public String getKfgl() {
		return kfgl;
	}
	public void setKfgl(String kfgl) {
		this.kfgl = kfgl;
	}
	public String getXtsz() {
		return xtsz;
	}
	public void setXtsz(String xtsz) {
		this.xtsz = xtsz;
	}
	public String getWzjbsz() {
		return wzjbsz;
	}
	public void setWzjbsz(String wzjbsz) {
		this.wzjbsz = wzjbsz;
	}
	public String getZcxxsz() {
		return zcxxsz;
	}
	public void setZcxxsz(String zcxxsz) {
		this.zcxxsz = zcxxsz;
	}
	public String getHydjqx() {
		return hydjqx;
	}
	public void setHydjqx(String hydjqx) {
		this.hydjqx = hydjqx;
	}
	public String getWzrksz() {
		return wzrksz;
	}
	public void setWzrksz(String wzrksz) {
		this.wzrksz = wzrksz;
	}
	public String getTgljgl() {
		return tgljgl;
	}
	public void setTgljgl(String tgljgl) {
		this.tgljgl = tgljgl;
	}
	public String getHtbmd() {
		return htbmd;
	}
	public void setHtbmd(String htbmd) {
		this.htbmd = htbmd;
	}
	public String getYmbd() {
		return ymbd;
	}
	public void setYmbd(String ymbd) {
		this.ymbd = ymbd;
	}
	public String getGlygl() {
		return glygl;
	}
	public void setGlygl(String glygl) {
		this.glygl = glygl;
	}
	public String getHtyhgl() {
		return htyhgl;
	}
	public void setHtyhgl(String htyhgl) {
		this.htyhgl = htyhgl;
	}
	public String getHtqxsz() {
		return htqxsz;
	}
	public void setHtqxsz(String htqxsz) {
		this.htqxsz = htqxsz;
	}
	public String getHtczrz() {
		return htczrz;
	}
	public void setHtczrz(String htczrz) {
		this.htczrz = htczrz;
	}
	public String getHydlrz() {
		return hydlrz;
	}
	public void setHydlrz(String hydlrz) {
		this.hydlrz = hydlrz;
	}
	@Override
	public String toString() {
		return "Qxgl [id=" + id + ", adminid=" + adminid + ", name=" + name + ", cwgl=" + cwgl + ", khczjl=" + khczjl
				+ ", khtkjl=" + khtkjl + ", hyzbgl=" + hyzbgl + ", hyjkkk=" + hyjkkk + ", hyjjdml=" + hyjjdml
				+ ", dmlbdjl=" + dmlbdjl + ", cpjl=" + cpjl + ", lhcplsz=" + lhcplsz + ", cpxlsz=" + cpxlsz
				+ ", cpdlsz=" + cpdlsz + ", cpgl=" + cpgl + ", cptzjl=" + cptzjl + ", lhctzjl=" + lhctzjl + ", cpkjjg="
				+ cpkjjg + ", xtcysjg=" + xtcysjg + ", hygl=" + hygl + ", hyssgn=" + hyssgn + ", qbdlgl=" + qbdlgl
				+ ", dlfdjl=" + dlfdjl + ", bbgl=" + bbgl + ", qqbbgl=" + qqbbgl + ", cwbbgl=" + cwbbgl + ", tjgkgl="
				+ tjgkgl + ", yybbgl=" + yybbgl + ", xtfxpg=" + xtfxpg + ", hysjgk=" + hysjgk + ", xxgg=" + xxgg
				+ ", ggfbgl=" + ggfbgl + ", yhhdgl=" + yhhdgl + ", lbtgl=" + lbtgl + ", znxxgl=" + znxxgl + ", hdgl="
				+ hdgl + ", ckzscl=" + ckzscl + ", kfgl=" + kfgl + ", xtsz=" + xtsz + ", wzjbsz=" + wzjbsz + ", zcxxsz="
				+ zcxxsz + ", hydjqx=" + hydjqx + ", wzrksz=" + wzrksz + ", tgljgl=" + tgljgl + ", htbmd=" + htbmd
				+ ", ymbd=" + ymbd + ", glygl=" + glygl + ", htyhgl=" + htyhgl + ", htqxsz=" + htqxsz + ", htczrz="
				+ htczrz + ", hydlrz=" + hydlrz + "]";
	}
	
	
	
}
