package com.ja.dao;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.ja.domain.Damal;

public interface DamalMapper {
	
	/**
	 * 
	   *   方法名：updateDamal   
	   *   描述：      修改打码添加幸运转盘次数的最新打码量                 TODO   
	   *   参数：    @param damal 打码量信息
	   *   参数：    @return 
	 * @return: int
	 */
	int updateDamal(@Param("dama")Damal dadml);
	
	/**查询所有会员的打码量及提款所需*/
	List<Damal> getAlldamal();
	
	/** 根据条件查询会员打码量及提款所需 */
	List<Damal> mhOneDama(@Param("d")Damal d);

	/**根据id查询当前用户的打码信息*/
	Damal getOnedamal(Integer id);
	
	/**添加会员的打码信息*/
	int addamal(Damal damal);

	
}
