package com.ja.sevice;

import java.util.List;

import com.ja.domain.AdminUser;
import com.ja.domain.Data;
import com.ja.domain.GcRebate;
import com.ja.domain.Order;
import com.ja.domain.Orders;
import com.ja.domain.User;
import com.ja.util.JsonResult;

public interface IOrderService {
	
	/**
	  * 方法名：calculateBettingCount 
	  * 描述：    计算投注注数               
	  * 参数：    @param o
	  * 参数：    @return 
	 * @return: JsonResult
	 */
	JsonResult calculateBettingCount(Order order);

    /**
     *   方法名：awards   
     *   描述：     添加用户彩票下注订单                  TODO 用户下注  
     *   参数：    @param order 订单信息
     *   参数：    @param user 用户信息
     *   参数：    @return 
     * @return: JsonResult
     */
   JsonResult awards(Order order, User user);
   
	/**
	 *   方法名：cancelOrder   
	 *   描述：     下注订单撤单                  TODO   用户撤单
	 *   参数：    @param user 用户信息
	 *   参数：    @param order_id 订单id 
	 *   参数：    @return 
	 * @return: JsonResult
	 */
	JsonResult cancelOrder(User user, Integer order_id);

	/**
	  * 方法名：findCheckOrder 
	  * 描述：     查询当前开奖订单的信息                 
	  * 参数：    @param order 订单信息
	  * 参数：    @return 
	 * @return: List<Order>
	 */
	List<Order> findCheckOrder(Order order);
	
	/**
	  * 方法名：checkLotterMoney 
	  * 描述：     彩票开奖修改中奖金额                 
	  * 参数：    @param order 订单信息
	  * 参数：    @param user 用户信息
	  * 参数：    @return  
	 * @return: int
	 */
	int checkLotterMoney(Order order, User user);
   
	/**
	 *   方法名：oneKeyRefund   
	 *   描述：    开奖异常一键退钱                   TODO   开奖异常一键退钱
	 *   参数：    @param data 退钱信息
	 *   参数：    @param admin 管理员信息
	 *   参数：    @return 
	 * @return: JsonResult
	 */
	JsonResult oneKeyRefund(Data data, AdminUser admin);

	/**
	   *   方法名：findOrderNumberCount   
	   *   描述：     查询投注人数                  TODO   
	   *   参数：    @param startTime
	   *   参数：    @param endTime
	   *   参数：    @return 
	 * @return: int
	 */
	int findOrderNumberCount(String startTime, String endTime);

	/**
	 * 方法名：findByIdGcRebate 
	 * 描述：     根据id查询特码返水配置                  TODO
	 * 参数：    @param id 配置id
	 * 参数：    @return 
	 * @return: GcRebate
	 */
	GcRebate findByIdGcRebateInfo(Integer id);
	
	/**
	  * 更新和局中奖玩法
	 * @param id 用户信息
	 * @param tcPlay 和局的玩法以及退还本金
	 * @return
	 */
	int updateReturnCheckMoney(Integer id, String tcPlay);
   
	/**
	  * 和局退还本金
	 * @param user 用户信息
	 * @param order 订单信息
	 * @return
	 */
	int returnCheckMoney(User user, Order order);

	/**
	 * 查询港彩投注反水设置
	 * @param game 
	 * @return
	 */
	List<GcRebate> findAllGcRebate(String game);

	/**
	 * 添加港彩反水记录
	 * @param user 用户信息
	 * @param ors 变动信息
	 * @return
	 */
	int GcBettingRebate(User user, Order ors);

	/**
	 * 添加港彩反水设置
	 * @param gcRebate 反水设置信息
	 * @return
	 */
	int insertGcRebate(GcRebate gcRebate);
	
	/**
	 * 修改港彩反水设置
	 * @param gcRebate 反水设置信息
	 * @return
	 */
	int updateByGcRebate(GcRebate gcRebate);

   
   
   
	/**修改合买订单*/
	int awards2(Order o);

	/**根据彩种和开奖状态来查询个人订单*/
	List<Order> getMyOrders(String key, String cname, Integer id);

	/**删除某条订单*/
	public int delOrderById(int id);

	/**查询id*/
	int getOrdersByUid(Order o,String date);

	/**获取所有的投注记录*/
	public List<Order> getAllJl();

	/**根据条件进行查询投注记录
	 * @param model 
	 * @param state2 
	 * @param integer */
	public List<Order> getMhAllJl(Integer startIndex, Integer lineCount,Integer state, String date1,String date2, String period,String cname1,String huiyuanzh, int model);
 
	/**查询六合投注记录*/
	public List<Order> getLiuheJl();

	/**根据条件查询六合投注记录*/
	public List<Order> getMhLiuheJl(Order order, String date1, String date2);

	
	/**彩种分类*/
	List<Order> fenleiorder(Integer id);

	/**当期投注总额*/
	double getOrderSum(Order o);

	/**当期中奖数据*/
	List<Order> getzjdata();

	/**下注数据*/
	List<Order> getxzdata(String cname);

	/**查询当天前x单*/
	int getCheckMoney(Integer id, Integer b3);

	/**个人所有中奖次数*/
	int getAllCheckMoney(Integer id);

	/**个人发起跟单次数*/
	int getTouZhuCount(Integer id, String times);
	
	/**最大一起的期号*/
	Data getMaxPeriod(String cname);

	/**彩种当期下注用户*/
	List<Order> getOrderUser(Data data);

	public List<Order> getMyOrdersAll(Integer id, Integer i);

	/**删除某个时间段的订单*/
	int delOrders(String date);

	/**合买单条订单信息*/
	Order getOneOrder(Integer id);

	/**每个彩种的打码量*/
	List<Order> getCnameDama(Integer id, String time);

	
	/**
	 * 刪除
	 * @param id
	 * @return
	 */
	int deleteshanchu(Integer id);

	/**
	 * 查询下注订单详情
	 * @param findFormatDate
	 * @return
	 */
	List<Order> findByTimeDetails(String findFormatDate);

	/**
	 * 
	 * @param money
	 * @param model
	 * @param qihao 
	 * @param b
	 * @param user
	 * @return
	 */
	int awardsBJL(Double money, String model, String qihao, boolean b, User user);

	/**
	 * 查询用户相关的订单
	 * @param startIndex
	 * @param lineCount
	 * @param id
	 * @param state
	 * @param cname
	 * @param i
	 * @return
	 */
	List<Order> findMyOrders(Integer startIndex, Integer lineCount, Integer id, Integer state, String cname, int i);

	/**
	    *   方法名：getMhAllJlCounts   
	    *   描述：                       TODO   
	    *   参数：    @param order
	    *   参数：    @return 
	 * @return: Integer
	 */
	Integer getMhAllJlCounts(Order order,String date1,String date2);

	/**
	    *   方法名：findMyOrders   
	    *   描述：                       TODO   
	    *   参数：    @param order
	    *   参数：    @return 
	 * @return: Integer
	 */
	Integer findMyOrdersCounts(Order order);
	/**
	 * 查询用户当期下注的系统彩
	 * @return
	 */
	List<Order> Inquiries(String period,String cName);
	
	/**下注数据 用于前端展示使用*/
	List<Orders> getxzdatas(String cname);
	
}