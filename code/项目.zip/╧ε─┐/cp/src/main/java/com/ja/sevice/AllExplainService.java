package com.ja.sevice;

import java.util.List;

import com.ja.domain.AllExplain;

/**
 * 
    * 项目名称：cp   
    * 类名称：ExplainService.java   
    * 类描述：   平台说明
    * 创建人：   Administrator
    * 创建时间：2018年12月6日 下午4:20:13   
 * @version v1.0.0
 */
public interface AllExplainService {

	/**
	 * 
	   *   方法名：save   
	   *   描述：    添加和修改平台说明                   TODO   
	   *   参数：    @param explain
	   *   参数：    @return 
	 * @return: int
	 */
	String saveExplaine(AllExplain explain);
	

	/**
	 * 
	   *   方法名：findAllExplain   
	   *   描述：     查询菜单说明                  TODO   
	   *   参数：    @param type 1 是所有的菜单 2是所有的说明
	   *   参数：    @return 
	 * @return: List<AllExplain>
	 */
	List<AllExplain> findAllExplain(Integer type);
	
	/**
	 * 
	   *   方法名：findByIdExplain   
	   *   描述：    根据id查询平台说明                   TODO   
	   *   参数：    @param id
	   *   参数：    @return 
	 * @return: AllExplain
	 */
	AllExplain findByIdExplain(Integer id);

	/**
	 * 
	   *   方法名：deleteExplain   
	   *   描述：     删除说明或者菜单                  TODO   
	   *   参数：    @param id
	   *   参数：    @return 
	 * @return: int
	 */
	String deleteExplain(Integer id);


}
