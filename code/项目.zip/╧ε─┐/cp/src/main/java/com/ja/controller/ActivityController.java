package com.ja.controller;

/**
 * 
 * 优惠活动
 * 
 */
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.ja.domain.Activity;
import com.ja.sevice.IActivityService;
import com.ja.util.JsonResult;

@Controller
@RequestMapping("/act")
public class ActivityController {

	@Autowired
	private IActivityService activityService;
	
	/**
	 * 优惠活动界面
	 */

	/**
	 * 查询所有开启的活动
	 * @return
	 */
	@RequestMapping("/allActivity")
	@ResponseBody
	public JsonResult allActivity() {
		List<Activity> activity = activityService.findEnableActivity();
		return new JsonResult("", activity);
	}
	
	/**
	 * 根据id查询活动
	 * @param id 活动id
	 * @return
	 */
	@RequestMapping("/oneActivity")
	@ResponseBody
	public JsonResult oneActivity(Integer id) {
		Activity activity = activityService.findOneActivity(id);
		Activity acts = new Activity(); 
		acts.setAlert1(activity.getAlert1());
		return new JsonResult("", acts);
	}

	
}
