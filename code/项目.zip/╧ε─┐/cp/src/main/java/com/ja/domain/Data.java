package com.ja.domain;

import java.io.Serializable;

public class Data implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1190988656095597439L;

	private Integer id;// 开奖数据表

	private String lottertime;// 开奖时间

	private String period;// 开奖期号

	private String lotternumber;// 开奖号码

	private String cname;// 彩种名称

	private String paijtime;// 派奖时间

	private String state;// 开奖状态

	private String touzhuzt;// 投注状态

	private Integer type; // 系统彩和国彩的区别  彩种类型 0 是国彩  1是系统彩

	private String gameNameInChinese;// 彩种中文名

	private String playResult;// 上期开奖时间
	
	private String nextperiod; //下期期号

	private String nextStopOrderTimeEpoch;// 下期开奖时间
	
	private Integer status;// 号码状态
	
	private String openTime;//本期开奖时间

	private Integer xg6hcstate; //香港六合彩状态
	
	public Integer getColorStatus() {
		return colorStatus;
	}
	public void setColorStatus(Integer colorStatus) {
		this.colorStatus = colorStatus;
	}

	private Integer colorStatus;//彩种启用和禁用  
	
	private  Integer classify;//PC高频彩   热门彩  分类字段
	
	public Integer getClassify() {
		return classify;
	}
	public void setClassify(Integer classify) {
		this.classify = classify;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	public Integer getType() {
		return type;
	}

	public void setType(Integer type) {
		this.type = type;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getLottertime() {
		return lottertime;
	}

	public void setLottertime(String lottertime) {
		this.lottertime = lottertime;
	}

	public String getPeriod() {
		return period;
	}

	public Integer getStatus() {
		return status;
	}

	public void setStatus(Integer status) {
		this.status = status;
	}

	public void setPeriod(String period) {
		this.period = period;
	}

	public String getNextperiod() {
		return nextperiod;
	}

	public void setNextperiod(String nextperiod) {
		this.nextperiod = nextperiod;
	}

	public String getLotternumber() {
		return lotternumber;
	}

	public void setLotternumber(String lotternumber) {
		this.lotternumber = lotternumber;
	}

	public String getCname() {
		return cname;
	}

	public void setCname(String cname) {
		this.cname = cname;
	}

	public String getPaijtime() {
		return paijtime;
	}

	public void setPaijtime(String paijtime) {
		this.paijtime = paijtime;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getTouzhuzt() {
		return touzhuzt;
	}

	public void setTouzhuzt(String touzhuzt) {
		this.touzhuzt = touzhuzt;
	}

	public String getNextStopOrderTimeEpoch() {
		return nextStopOrderTimeEpoch;
	}

	public void setNextStopOrderTimeEpoch(String nextStopOrderTimeEpoch) {
		this.nextStopOrderTimeEpoch = nextStopOrderTimeEpoch;
	}

	public String getGameNameInChinese() {
		return gameNameInChinese;
	}

	public void setGameNameInChinese(String gameNameInChinese) {
		this.gameNameInChinese = gameNameInChinese;
	}

	public String getPlayResult() {
		return playResult;
	}

	public void setPlayResult(String playResult) {
		this.playResult = playResult;
	}

	public String getOpenTime() {
		return openTime;
	}

	public void setOpenTime(String openTime) {
		this.openTime = openTime;
	}

	public Integer getXg6hcstate() {
		return xg6hcstate;
	}

	public void setXg6hcstate(Integer xg6hcstate) {
		this.xg6hcstate = xg6hcstate;
	}

	public Data() {
		super();
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((cname == null) ? 0 : cname.hashCode());
		result = prime * result + ((period == null) ? 0 : period.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Data other = (Data) obj;
		if (cname == null) {
			if (other.cname != null)
				return false;
		} else if (!cname.equals(other.cname))
			return false;
		if (period == null) {
			if (other.period != null)
				return false;
		} else if (!period.equals(other.period))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "Data [id=" + id + ", lottertime=" + lottertime + ", period=" + period + ", lotternumber=" + lotternumber
				+ ", cname=" + cname + ", paijtime=" + paijtime + ", state=" + state + ", touzhuzt=" + touzhuzt
				+ ", type=" + type + ", gameNameInChinese=" + gameNameInChinese + ", playResult=" + playResult
				+ ", nextperiod=" + nextperiod + ", nextStopOrderTimeEpoch=" + nextStopOrderTimeEpoch + ", status="
				+ status + ", openTime=" + openTime + ", xg6hcstate=" + xg6hcstate + "]";
	}

}