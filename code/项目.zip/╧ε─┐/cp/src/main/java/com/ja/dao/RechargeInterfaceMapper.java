package com.ja.dao;

import java.util.List;

import com.ja.domain.RechargeInterface;

public interface RechargeInterfaceMapper {

	/**
	 * 方法名：getRecharge 
	 * 描述：    查询在线支付接口信息                  
	 * 参数：    @return 
	 * @return: List<RechargeInterface>
	 */
	List<RechargeInterface> getRecharge();
	
	/**
	 * 方法名：insertRecharge 
	 * 描述：    添加在线接口信息                  
	 * 参数：    @param recharge
	 * 参数：    @return 
	 * @return: int
	 */
	int insertRecharge(RechargeInterface recharge);
	
	/**
	 * 方法名：updateRecharge 
	 * 描述：    修改在线接口信息                  
	 * 参数：    @param recharge
	 * 参数：    @return 
	 * @return: int
	 */
	int updateRecharge(RechargeInterface recharge);
	

	
}


