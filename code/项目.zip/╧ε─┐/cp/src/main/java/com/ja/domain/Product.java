package com.ja.domain;

import java.io.Serializable;

public class Product implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 7898070176935138128L;
	private Integer id;
	// 开奖日期
	private String lotterTime;
	// 期号
	private String period;
	// 开奖号码
	private String lotterNumber;
	// 采种
	private String cName;
	//采种中文名
	private String name;

	private Integer type;// 彩种类别
	
	private String datetime;//下期时间
	
	private Integer status;//下期时间
	
	private String gameNameInChinese;// 彩种中文名

	private String officialOpenTimeEpoch;// 上期开奖时间

	private String nextStopOrderTimeEpoch;// 下期开奖时间
	
	private String nextperiod;//下期开奖时间
	
    
    public static long getSerialversionuid() {
		return serialVersionUID;
	}
	public String getNextperiod() {
		return nextperiod;
	}

	public void setNextperiod(String nextperiod) {
		this.nextperiod = nextperiod;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
	public Integer getId() {
		return id;
	}

	public Integer getStatus() {
		return status;
	}

	public void setStatus(Integer status) {
		this.status = status;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getLotterTime() {
		return lotterTime;
	}

	public void setLotterTime(String lotterTime) {
		this.lotterTime = lotterTime;
	}

	public String getPeriod() {
		return period;
	}

	public void setPeriod(String period) {
		this.period = period;
	}

	public String getLotterNumber() {
		return lotterNumber;
	}

	public void setLotterNumber(String lotterNumber) {
		this.lotterNumber = lotterNumber;
	}

	public String getcName() {
		return cName;
	}

	public void setcName(String cName) {
		this.cName = cName;
	}

	public Integer getType() {
		return type;
	}

	public void setType(Integer type) {
		this.type = type;
	}

	public String getGameNameInChinese() {
		return gameNameInChinese;
	}

	public void setGameNameInChinese(String gameNameInChinese) {
		this.gameNameInChinese = gameNameInChinese;
	}

	public String getOfficialOpenTimeEpoch() {
		return officialOpenTimeEpoch;
	}

	public void setOfficialOpenTimeEpoch(String officialOpenTimeEpoch) {
		this.officialOpenTimeEpoch = officialOpenTimeEpoch;
	}

	public String getNextStopOrderTimeEpoch() {
		return nextStopOrderTimeEpoch;
	}

	public void setNextStopOrderTimeEpoch(String nextStopOrderTimeEpoch) {
		this.nextStopOrderTimeEpoch = nextStopOrderTimeEpoch;
	}

	public String getDatetime() {
		return datetime;
	}

	public void setDatetime(String datetime) {
		this.datetime = datetime;
	}
	
	@Override
	public String toString() {
		return "Product [id=" + id + ", lotterTime=" + lotterTime + ", period=" + period + ", lotterNumber="
				+ lotterNumber + ", cName=" + cName + ", name=" + name + ", type=" + type + ", datetime=" + datetime
				+ ", status=" + status + ", gameNameInChinese=" + gameNameInChinese + ", officialOpenTimeEpoch="
				+ officialOpenTimeEpoch + ", nextStopOrderTimeEpoch=" + nextStopOrderTimeEpoch + ", nextperiod="
				+ nextperiod + "]";
	}

}
