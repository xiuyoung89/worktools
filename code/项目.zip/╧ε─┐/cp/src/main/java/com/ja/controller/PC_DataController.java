package com.ja.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.ja.sevice.BjlService;
import com.ja.sevice.IDataService;
import com.ja.util.DateUtil;
import com.ja.util.JsonResult;
/**
 * 
 * 项目名称：cp   
 * 类名称：PC_DataController.java   
 * 类描述：   pc首页 页面
 * 创建人：   GL
 * 创建时间：2018年10月29日 上午11:08:36   
 * @version v1.0.0
 */
@RequestMapping("/datas")
@Controller
public class PC_DataController {
	
	@Autowired
	private BjlService bjlService;
	
	@Autowired
	private IDataService dataService;

	@RequestMapping("/findTrend")
	@ResponseBody
	public JsonResult findTrend(Integer type,String cname) { 
		String time = "";
		switch (type) {
			case 1:
				//今天
				time = DateUtil.findFormatDate();
				break;
			case 2:
				time = DateUtil.findLatelyDate(-1);
				//昨天
				break;
			case 3:
				time = DateUtil.findLatelyDate(-2);
				//前天
				break;
			case 4:
				time = "20";
				break;
			case 5:
				time = "30";
				break;
			case 6:
				time = "50";
				break;
			case 7:
				time = "100";
				break;
		}
		return new JsonResult("",dataService.findTrend(time,cname)); 
	} 
	/**
	 * 查询百家乐开奖记录
	 * @param type 查询那天的数据
	 * @param tableNumber  查询那个卓号的数据
	 * @param issueNumber  根据期号查询在一期的数据
	 * @return 查询到数据则返回list集合包含bjldata对象数据  没有查询到则返回空集合
	 */
	@RequestMapping("/findTrendBjl")
	@ResponseBody
	public JsonResult findTrendBjl(Integer type,Integer tableNumber,String issueNumber) { 
		String time = "";
		switch (type) {
			case 1:
				//今天
				time = DateUtil.findFormatDate().replaceAll("-", "/");
				break;
			case 2:
				time = DateUtil.findLatelyDate(-1).replaceAll("-", "/");
				//昨天
				break;
			case 3:
				time = DateUtil.findLatelyDate(-2).replaceAll("-", "/");
				//前天
				break;
		}
		System.out.println(time+"----"+tableNumber);
		return new JsonResult("",bjlService.findTrendBjl(time,tableNumber,issueNumber)); 
	} 
	
	/**
	 * 查询所有彩种名
	 * @return  返回一个list集合 包含每一个彩种名 以及彩种英文名
	 */
	@ResponseBody
	@RequestMapping("/wholeLot")
	public JsonResult wholeLot() {
		return new JsonResult(null,dataService.wholeLot());
	}
	
}
