package com.ja.domain;

public class Notice {
		// 首页图片
		private String picturePath1;
		
		private String picturePath2;
		
		private String picturePath3;
		
		private String picturePath4;
		
		private String picturePath5;
		public String getKefusbtime() {
			return kefusbtime;
		}

		public void setKefusbtime(String kefusbtime) {
			this.kefusbtime = kefusbtime;
		}

		public String getKefuxbtime() {
			return kefuxbtime;
		}

		public void setKefuxbtime(String kefuxbtime) {
			this.kefuxbtime = kefuxbtime;
		}

		private String wangzhantitle;//网站标题
		
		private String pc_welcome;//Pc网站标题
		
		private String pc_wechat;//PC微信图标
		
		private String logo;//PClogo
		
		public String getPc_welcome() {
			return pc_welcome;
		}

		public void setPc_welcome(String pc_welcome) {
			this.pc_welcome = pc_welcome;
		}

		public String getPc_wechat() {
			return pc_wechat;
		}

		public void setPc_wechat(String pc_wechat) {
			this.pc_wechat = pc_wechat;
		}

		public String getLogo() {
			return logo;
		}

		public void setLogo(String logo) {
			this.logo = logo;
		}

		private String notice;//公告
		
		private String noticePicture;//首页公告弹窗内容
		
		private String noticeName;//首页公告弹窗内容 标题
		
		private String kefusbtime;//客服时间
		
		private String kefuxbtime;//客服时间

		public String getPicturePath1() {
			return picturePath1;
		}

		public void setPicturePath1(String picturePath1) {
			this.picturePath1 = picturePath1;
		}

		public String getPicturePath2() {
			return picturePath2;
		}

		public void setPicturePath2(String picturePath2) {
			this.picturePath2 = picturePath2;
		}

		public String getPicturePath3() {
			return picturePath3;
		}

		public void setPicturePath3(String picturePath3) {
			this.picturePath3 = picturePath3;
		}

		public String getPicturePath4() {
			return picturePath4;
		}

		public void setPicturePath4(String picturePath4) {
			this.picturePath4 = picturePath4;
		}

		public String getPicturePath5() {
			return picturePath5;
		}

		public void setPicturePath5(String picturePath5) {
			this.picturePath5 = picturePath5;
		}

		public String getWangzhantitle() {
			return wangzhantitle;
		}

		public void setWangzhantitle(String wangzhantitle) {
			this.wangzhantitle = wangzhantitle;
		}

		public String getNotice() {
			return notice;
		}

		public void setNotice(String notice) {
			this.notice = notice;
		}

		public String getNoticePicture() {
			return noticePicture;
		}

		public void setNoticePicture(String noticePicture) {
			this.noticePicture = noticePicture;
		}

		public String getNoticeName() {
			return noticeName;
		}

		public void setNoticeName(String noticeName) {
			this.noticeName = noticeName;
		}
}
