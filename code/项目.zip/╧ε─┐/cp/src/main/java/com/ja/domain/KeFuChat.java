package com.ja.domain;

import java.io.Serializable;

public class KeFuChat implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 8967396278794283067L;

	private Integer id; // 客服咨询聊天记录表

	private String kefu_name; // 客服昵称

	private String user_name; // 客服昵称

	private String content; // 聊天内容

	private String kefu_avatar; // 客服头像

	private String user_avatar; // 用户头像

	private Integer kefu_id; // 客服id

	private Integer user_id; // 用户id
	
	private Integer sender; // 1会员 0客服

	private String created_time; // 操作时间
	
	private Integer state; // 消息 1未读 0已读
	
	private Integer statu; // 联系人 1显示 2不显示
	
	private String name;//用户名称
    
    public static long getSerialversionuid() {
		return serialVersionUID;
	}

    public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getKefu_name() {
		return kefu_name;
	}

	public void setKefu_name(String kefu_name) {
		this.kefu_name = kefu_name;
	}

	public String getUser_name() {
		return user_name;
	}

	public void setUser_name(String user_name) {
		this.user_name = user_name;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public String getKefu_avatar() {
		return kefu_avatar;
	}

	public void setKefu_avatar(String kefu_avatar) {
		this.kefu_avatar = kefu_avatar;
	}

	public String getUser_avatar() {
		return user_avatar;
	}

	public void setUser_avatar(String user_avatar) {
		this.user_avatar = user_avatar;
	}

	public Integer getKefu_id() {
		return kefu_id;
	}

	public void setKefu_id(Integer kefu_id) {
		this.kefu_id = kefu_id;
	}

	public Integer getUser_id() {
		return user_id;
	}

	public void setUser_id(Integer user_id) {
		this.user_id = user_id;
	}
	
	public Integer getSender() {
		return sender;
	}

	public void setSender(Integer sender) {
		this.sender = sender;
	}

	public String getCreated_time() {
		return created_time;
	}

	public void setCreated_time(String created_time) {
		this.created_time = created_time;
	}

	public Integer getState() {
		return state;
	}

	public void setState(Integer state) {
		this.state = state;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Integer getStatu() {
		return statu;
	}

	public void setStatu(Integer statu) {
		this.statu = statu;
	}

	public KeFuChat() {
		super();
	}

	@Override
	public String toString() {
		return "KeFuChat [id=" + id + ", kefu_name=" + kefu_name + ", user_name=" + user_name + ", content=" + content
				+ ", kefu_avatar=" + kefu_avatar + ", user_avatar=" + user_avatar + ", kefu_id=" + kefu_id
				+ ", user_id=" + user_id + ", sender=" + sender + ", created_time=" + created_time + ", state=" + state
				+ ", statu=" + statu + ", name=" + name + "]";
	}
	
}