package com.ja.domain;

import java.io.Serializable;

public class Admin implements Serializable {

	public static final long serialVersionUID = 3494548175983615004L;

	public Integer id; // 所有 系统设置

	/**
	 * 
	 * 系统配置
	 * 
	 */

	public Integer weihukaiguan; // 网站维护开关

	public String weihuyuanyin;// 网站维护原因

	public Integer zhangbiankaiguan;// 帐变开关 -- 暂时没有使用

	public Integer baimingdankaiguan;// 白名单开关 -- 暂时没有使用

	public Integer chatroomFlag; // 聊天室开关

	public Double receiveAReturnPoint;// 代理返点最低领取金额 ---暂时没用

	public String notice; // 手机端喇叭通知

	public String pc_notice; // PC端喇叭通知

	/**
	 * 
	 * 下注单注金额配置
	 * 
	 */
	public Integer buy1;// 单注金额1

	public Integer buy2;// 单注金额2

	public Integer buy3;// 单注金额3

	public Integer buy4;// 单注金额4

	public Integer buy5;// 单注金额5

	/**
	 * 
	 * 租户配置
	 * 
	 */

	public String wangzhantitle; // 网站顶部名称

	public Integer zhuceipcount; // 同一iP每日限制注册次数

	public String logo; // 网站顶部logo标志

	public String pc_welcome; // PC端界面欢迎语

	public String pc_wechat; // PC端微信客服二维码

	/**
	 * 
	 * 幸运转盘配置
	 * 
	 */

	public Integer luckyFlag;// 幸运转盘开关 1是开启 0是关闭

	public Double rechargeMoney;// 充值金额达到数量增加一次摇奖机会

	public Integer returnMoney;// 抽奖次数

	public String luckyTitle;// 幸运转盘顶部标题

	public Double dluckCount; // 打码量达到数量增加一次摇奖机会

	public Integer dluckFlag; // 打码量摇奖次数 开关

	/**
	 * 
	 * 每日签到配置
	 * 
	 */

	public Integer qiandaoflag;// 每日签到 1开启 0禁用

	public Double meiriMoney;// 签到所需每日充值金额

	public Double meiyueMoney;// 签到所需每月充值金额

	public Double lishiMoney;// 签到所需历史充值金额

	public Double yueMoney;// 签到所需余额

	public Integer moneyType;// 签到金额类型

	public Double moneySuiji;// 签到随机金额

	public Double moneyGuding;// 签到固定金额

	/**
	 * 
	 * 系统红包配置
	 * 
	 */

	public Double meiriJine;// 领取红包所需每日充值金额

	public Double meiyueJine;// 领取红包所需每月充值金额

	public Double lishiJine;// 领取红包所需历史充值金额

	public Double yueJine;// 领取红包所需账户余额

	public Integer hongbaoflag;// 系统红包开关

	public Integer jineType;// 发红包类型

	public Double jineSuiji;// 随机红包金额

	public Double jineGuding;// 固定红包金额

	public String time;// 发红包时间

	public String redenvelopes;// 红包金额

	public String leavingamessage;// 留言

	public String typeofredenvelopes;// 红包类型

	public int numberofredpackets;// 红包个数

	/**
	 * 
	 * 用户提款配置
	 * 
	 */

	public String stratchulitime;// 提款、入款开始处理时间

	public String endchulitime;// 提款、入款结束处理时间

	public Double maxtikuanjine;// 提款最大金额

	public Double mintikuanjine;// 提款最小金额

	public Integer meiritikuancount;// 每日提款免费次数

	public Double drawingRatio; // 普通提款比例设置

	public Integer drawingFlag; // 提款手续费开关

	public Double drawingMoney; // 提款手续费比率

	public Double dcountMoney; // 提款次数超出手续费比率

	/**
	 * 
	 * 用户存款配置
	 * 
	 */

	public Integer kuaisucunkuanflag;// 人工存款开关

	public Integer disanfangcunkuanflag;// 第三方存款开关

	public String kuaisucunkuannote;// 人工存款说明

	public String disanfangcunkuannote;// 第三方存款说明

	/**
	 * 
	 * 在线客服配置
	 * 
	 */
	public String tips; // 在线客服首次提示语

	public String kefusbtime;// 客服上班时间

	public String kefuxbtime;// 客服下班时间

	/**
	 * 
	 * 彩票配置
	 * 
	 */

	public String xitongcaizjratio;// 系统彩中奖比率

	/**
	 * 
	 * 试玩站点配置
	 * 
	 */

	public Double huiyuanchushijine;// 注册会员初始金额

	public Integer shiwanzhucekaiqi;// 注册试玩账号开启

	public Double shiwanchushijine;// 试玩账号初始金额

	/**
	 * 
	 * 聊天室配置
	 * 
	 */

	public String money;// 聊天室 用户发言所需最小余额

	public Integer messageFlag;// 聊天室 显示充值提款信息

	/**
	 * 
	 * 代理配置
	 * 
	 */
	
	public Integer agent_flag; // 代理选择开关 1是第一套代理系统    2是第二套代理系统
	
	public  Double minimumOdds; //设置代理最低赔率
	

	/**
	 * 
	 */
	
	public Integer zuhuipkaiguan;// 租户ip变动开关

	public String wangzhandomain;// 网站域名

	public Integer dcountFlag; // 日常提款次数超出开关

	public Integer tikuanshifousuccess;// 提款只记录成功次数

	public Double tikuanxiaofeibili;// 提款所需打码量比率

	public String tikuanshixiaotime;// 提款未处理记录失效时间

	public String cunkuanshixiaotime;// 存款记录失效时间

	public String kefuurl;// 在线客服的url地址

	public Integer kefuloginxianshi;// 在线客服登录页面显示开关

	public String xitongcaicheckms;// 系统彩开奖模式

	public String caipiaotouzhums;// 彩票投注模式

	public String registType;// 注册验证码类型

	public String loginType;// 登录验证码

	public String chongzhiType;// 充值验证码类型

	public Integer hemai;// 合买开关

	public Integer gendan;// 跟单开关

	public Integer gendancs;// 第几单开始跟单

	public String gendanbs;// 跟单倍数

	public String fanshuiContent;// 代理说明内容

	public String fanshuiPicture;// 代理规则图片

	public String url;// app下载地址

	public Double xluckCount; // 消费多少达到多少增加一次摇奖机会

	public Integer xluckFlag; // 消费多少达到多少增加一次摇奖机会 开关

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Integer getWeihukaiguan() {
		return weihukaiguan;
	}

	public void setWeihukaiguan(Integer weihukaiguan) {
		this.weihukaiguan = weihukaiguan;
	}

	public String getWeihuyuanyin() {
		return weihuyuanyin;
	}

	public void setWeihuyuanyin(String weihuyuanyin) {
		this.weihuyuanyin = weihuyuanyin;
	}

	public Integer getZhangbiankaiguan() {
		return zhangbiankaiguan;
	}

	public void setZhangbiankaiguan(Integer zhangbiankaiguan) {
		this.zhangbiankaiguan = zhangbiankaiguan;
	}

	public Integer getBaimingdankaiguan() {
		return baimingdankaiguan;
	}

	public void setBaimingdankaiguan(Integer baimingdankaiguan) {
		this.baimingdankaiguan = baimingdankaiguan;
	}

	public Integer getChatroomFlag() {
		return chatroomFlag;
	}

	public void setChatroomFlag(Integer chatroomFlag) {
		this.chatroomFlag = chatroomFlag;
	}

	public Double getReceiveAReturnPoint() {
		return receiveAReturnPoint;
	}

	public void setReceiveAReturnPoint(Double receiveAReturnPoint) {
		this.receiveAReturnPoint = receiveAReturnPoint;
	}

	public String getNotice() {
		return notice;
	}

	public void setNotice(String notice) {
		this.notice = notice;
	}

	public String getPc_notice() {
		return pc_notice;
	}

	public void setPc_notice(String pc_notice) {
		this.pc_notice = pc_notice;
	}

	public Integer getBuy1() {
		return buy1;
	}

	public void setBuy1(Integer buy1) {
		this.buy1 = buy1;
	}

	public Integer getBuy2() {
		return buy2;
	}

	public void setBuy2(Integer buy2) {
		this.buy2 = buy2;
	}

	public Integer getBuy3() {
		return buy3;
	}

	public void setBuy3(Integer buy3) {
		this.buy3 = buy3;
	}

	public Integer getBuy4() {
		return buy4;
	}

	public void setBuy4(Integer buy4) {
		this.buy4 = buy4;
	}

	public Integer getBuy5() {
		return buy5;
	}

	public void setBuy5(Integer buy5) {
		this.buy5 = buy5;
	}

	public String getWangzhantitle() {
		return wangzhantitle;
	}

	public void setWangzhantitle(String wangzhantitle) {
		this.wangzhantitle = wangzhantitle;
	}

	public Integer getZhuceipcount() {
		return zhuceipcount;
	}

	public void setZhuceipcount(Integer zhuceipcount) {
		this.zhuceipcount = zhuceipcount;
	}

	public String getLogo() {
		return logo;
	}

	public void setLogo(String logo) {
		this.logo = logo;
	}

	public String getPc_welcome() {
		return pc_welcome;
	}

	public void setPc_welcome(String pc_welcome) {
		this.pc_welcome = pc_welcome;
	}

	public String getPc_wechat() {
		return pc_wechat;
	}

	public void setPc_wechat(String pc_wechat) {
		this.pc_wechat = pc_wechat;
	}

	public Integer getLuckyFlag() {
		return luckyFlag;
	}

	public void setLuckyFlag(Integer luckyFlag) {
		this.luckyFlag = luckyFlag;
	}

	public Double getRechargeMoney() {
		return rechargeMoney;
	}

	public void setRechargeMoney(Double rechargeMoney) {
		this.rechargeMoney = rechargeMoney;
	}

	public Integer getReturnMoney() {
		return returnMoney;
	}

	public void setReturnMoney(Integer returnMoney) {
		this.returnMoney = returnMoney;
	}

	public String getLuckyTitle() {
		return luckyTitle;
	}

	public void setLuckyTitle(String luckyTitle) {
		this.luckyTitle = luckyTitle;
	}

	public Double getDluckCount() {
		return dluckCount;
	}

	public void setDluckCount(Double dluckCount) {
		this.dluckCount = dluckCount;
	}

	public Integer getDluckFlag() {
		return dluckFlag;
	}

	public void setDluckFlag(Integer dluckFlag) {
		this.dluckFlag = dluckFlag;
	}

	public Integer getQiandaoflag() {
		return qiandaoflag;
	}

	public void setQiandaoflag(Integer qiandaoflag) {
		this.qiandaoflag = qiandaoflag;
	}

	public Double getMeiriMoney() {
		return meiriMoney;
	}

	public void setMeiriMoney(Double meiriMoney) {
		this.meiriMoney = meiriMoney;
	}

	public Double getMeiyueMoney() {
		return meiyueMoney;
	}

	public void setMeiyueMoney(Double meiyueMoney) {
		this.meiyueMoney = meiyueMoney;
	}

	public Double getLishiMoney() {
		return lishiMoney;
	}

	public void setLishiMoney(Double lishiMoney) {
		this.lishiMoney = lishiMoney;
	}

	public Double getYueMoney() {
		return yueMoney;
	}

	public void setYueMoney(Double yueMoney) {
		this.yueMoney = yueMoney;
	}

	public Integer getMoneyType() {
		return moneyType;
	}

	public void setMoneyType(Integer moneyType) {
		this.moneyType = moneyType;
	}

	public Double getMoneySuiji() {
		return moneySuiji;
	}

	public void setMoneySuiji(Double moneySuiji) {
		this.moneySuiji = moneySuiji;
	}

	public Double getMoneyGuding() {
		return moneyGuding;
	}

	public void setMoneyGuding(Double moneyGuding) {
		this.moneyGuding = moneyGuding;
	}

	public Double getMeiriJine() {
		return meiriJine;
	}

	public void setMeiriJine(Double meiriJine) {
		this.meiriJine = meiriJine;
	}

	public Double getMeiyueJine() {
		return meiyueJine;
	}

	public void setMeiyueJine(Double meiyueJine) {
		this.meiyueJine = meiyueJine;
	}

	public Double getLishiJine() {
		return lishiJine;
	}

	public void setLishiJine(Double lishiJine) {
		this.lishiJine = lishiJine;
	}

	public Double getYueJine() {
		return yueJine;
	}

	public void setYueJine(Double yueJine) {
		this.yueJine = yueJine;
	}

	public Integer getHongbaoflag() {
		return hongbaoflag;
	}

	public void setHongbaoflag(Integer hongbaoflag) {
		this.hongbaoflag = hongbaoflag;
	}

	public Integer getJineType() {
		return jineType;
	}

	public void setJineType(Integer jineType) {
		this.jineType = jineType;
	}

	public Double getJineSuiji() {
		return jineSuiji;
	}

	public void setJineSuiji(Double jineSuiji) {
		this.jineSuiji = jineSuiji;
	}

	public Double getJineGuding() {
		return jineGuding;
	}

	public void setJineGuding(Double jineGuding) {
		this.jineGuding = jineGuding;
	}

	public String getTime() {
		return time;
	}

	public void setTime(String time) {
		this.time = time;
	}

	public String getRedenvelopes() {
		return redenvelopes;
	}

	public void setRedenvelopes(String redenvelopes) {
		this.redenvelopes = redenvelopes;
	}

	public String getLeavingamessage() {
		return leavingamessage;
	}

	public void setLeavingamessage(String leavingamessage) {
		this.leavingamessage = leavingamessage;
	}

	public String getTypeofredenvelopes() {
		return typeofredenvelopes;
	}

	public void setTypeofredenvelopes(String typeofredenvelopes) {
		this.typeofredenvelopes = typeofredenvelopes;
	}

	public int getNumberofredpackets() {
		return numberofredpackets;
	}

	public void setNumberofredpackets(int numberofredpackets) {
		this.numberofredpackets = numberofredpackets;
	}

	public String getStratchulitime() {
		return stratchulitime;
	}

	public void setStratchulitime(String stratchulitime) {
		this.stratchulitime = stratchulitime;
	}

	public String getEndchulitime() {
		return endchulitime;
	}

	public void setEndchulitime(String endchulitime) {
		this.endchulitime = endchulitime;
	}

	public Double getMaxtikuanjine() {
		return maxtikuanjine;
	}

	public void setMaxtikuanjine(Double maxtikuanjine) {
		this.maxtikuanjine = maxtikuanjine;
	}

	public Double getMintikuanjine() {
		return mintikuanjine;
	}

	public void setMintikuanjine(Double mintikuanjine) {
		this.mintikuanjine = mintikuanjine;
	}

	public Integer getMeiritikuancount() {
		return meiritikuancount;
	}

	public void setMeiritikuancount(Integer meiritikuancount) {
		this.meiritikuancount = meiritikuancount;
	}

	public Double getDrawingRatio() {
		return drawingRatio;
	}

	public void setDrawingRatio(Double drawingRatio) {
		this.drawingRatio = drawingRatio;
	}

	public Integer getDrawingFlag() {
		return drawingFlag;
	}

	public void setDrawingFlag(Integer drawingFlag) {
		this.drawingFlag = drawingFlag;
	}

	public Double getDrawingMoney() {
		return drawingMoney;
	}

	public void setDrawingMoney(Double drawingMoney) {
		this.drawingMoney = drawingMoney;
	}

	public Double getDcountMoney() {
		return dcountMoney;
	}

	public void setDcountMoney(Double dcountMoney) {
		this.dcountMoney = dcountMoney;
	}

	public Integer getKuaisucunkuanflag() {
		return kuaisucunkuanflag;
	}

	public void setKuaisucunkuanflag(Integer kuaisucunkuanflag) {
		this.kuaisucunkuanflag = kuaisucunkuanflag;
	}

	public Integer getDisanfangcunkuanflag() {
		return disanfangcunkuanflag;
	}

	public void setDisanfangcunkuanflag(Integer disanfangcunkuanflag) {
		this.disanfangcunkuanflag = disanfangcunkuanflag;
	}

	public String getKuaisucunkuannote() {
		return kuaisucunkuannote;
	}

	public void setKuaisucunkuannote(String kuaisucunkuannote) {
		this.kuaisucunkuannote = kuaisucunkuannote;
	}

	public String getDisanfangcunkuannote() {
		return disanfangcunkuannote;
	}

	public void setDisanfangcunkuannote(String disanfangcunkuannote) {
		this.disanfangcunkuannote = disanfangcunkuannote;
	}

	public String getTips() {
		return tips;
	}

	public void setTips(String tips) {
		this.tips = tips;
	}

	public String getKefusbtime() {
		return kefusbtime;
	}

	public void setKefusbtime(String kefusbtime) {
		this.kefusbtime = kefusbtime;
	}

	public String getKefuxbtime() {
		return kefuxbtime;
	}

	public void setKefuxbtime(String kefuxbtime) {
		this.kefuxbtime = kefuxbtime;
	}

	public String getXitongcaizjratio() {
		return xitongcaizjratio;
	}

	public void setXitongcaizjratio(String xitongcaizjratio) {
		this.xitongcaizjratio = xitongcaizjratio;
	}

	public Double getHuiyuanchushijine() {
		return huiyuanchushijine;
	}

	public void setHuiyuanchushijine(Double huiyuanchushijine) {
		this.huiyuanchushijine = huiyuanchushijine;
	}

	public Integer getShiwanzhucekaiqi() {
		return shiwanzhucekaiqi;
	}

	public void setShiwanzhucekaiqi(Integer shiwanzhucekaiqi) {
		this.shiwanzhucekaiqi = shiwanzhucekaiqi;
	}

	public Double getShiwanchushijine() {
		return shiwanchushijine;
	}

	public void setShiwanchushijine(Double shiwanchushijine) {
		this.shiwanchushijine = shiwanchushijine;
	}

	public String getMoney() {
		return money;
	}

	public void setMoney(String money) {
		this.money = money;
	}

	public Integer getMessageFlag() {
		return messageFlag;
	}

	public void setMessageFlag(Integer messageFlag) {
		this.messageFlag = messageFlag;
	}

	public Integer getAgent_flag() {
		return agent_flag;
	}

	public void setAgent_flag(Integer agent_flag) {
		this.agent_flag = agent_flag;
	}

	public Integer getZuhuipkaiguan() {
		return zuhuipkaiguan;
	}

	public void setZuhuipkaiguan(Integer zuhuipkaiguan) {
		this.zuhuipkaiguan = zuhuipkaiguan;
	}

	public String getWangzhandomain() {
		return wangzhandomain;
	}

	public void setWangzhandomain(String wangzhandomain) {
		this.wangzhandomain = wangzhandomain;
	}

	public Integer getDcountFlag() {
		return dcountFlag;
	}

	public void setDcountFlag(Integer dcountFlag) {
		this.dcountFlag = dcountFlag;
	}

	public Integer getTikuanshifousuccess() {
		return tikuanshifousuccess;
	}

	public void setTikuanshifousuccess(Integer tikuanshifousuccess) {
		this.tikuanshifousuccess = tikuanshifousuccess;
	}

	public Double getTikuanxiaofeibili() {
		return tikuanxiaofeibili;
	}

	public void setTikuanxiaofeibili(Double tikuanxiaofeibili) {
		this.tikuanxiaofeibili = tikuanxiaofeibili;
	}

	public String getTikuanshixiaotime() {
		return tikuanshixiaotime;
	}

	public void setTikuanshixiaotime(String tikuanshixiaotime) {
		this.tikuanshixiaotime = tikuanshixiaotime;
	}

	public String getCunkuanshixiaotime() {
		return cunkuanshixiaotime;
	}

	public void setCunkuanshixiaotime(String cunkuanshixiaotime) {
		this.cunkuanshixiaotime = cunkuanshixiaotime;
	}

	public String getKefuurl() {
		return kefuurl;
	}

	public void setKefuurl(String kefuurl) {
		this.kefuurl = kefuurl;
	}

	public Integer getKefuloginxianshi() {
		return kefuloginxianshi;
	}

	public void setKefuloginxianshi(Integer kefuloginxianshi) {
		this.kefuloginxianshi = kefuloginxianshi;
	}

	public String getXitongcaicheckms() {
		return xitongcaicheckms;
	}

	public void setXitongcaicheckms(String xitongcaicheckms) {
		this.xitongcaicheckms = xitongcaicheckms;
	}

	public String getCaipiaotouzhums() {
		return caipiaotouzhums;
	}

	public void setCaipiaotouzhums(String caipiaotouzhums) {
		this.caipiaotouzhums = caipiaotouzhums;
	}

	public String getRegistType() {
		return registType;
	}

	public void setRegistType(String registType) {
		this.registType = registType;
	}

	public String getLoginType() {
		return loginType;
	}

	public void setLoginType(String loginType) {
		this.loginType = loginType;
	}

	public String getChongzhiType() {
		return chongzhiType;
	}

	public void setChongzhiType(String chongzhiType) {
		this.chongzhiType = chongzhiType;
	}

	public Integer getHemai() {
		return hemai;
	}

	public void setHemai(Integer hemai) {
		this.hemai = hemai;
	}

	public Integer getGendan() {
		return gendan;
	}

	public void setGendan(Integer gendan) {
		this.gendan = gendan;
	}

	public Integer getGendancs() {
		return gendancs;
	}

	public void setGendancs(Integer gendancs) {
		this.gendancs = gendancs;
	}

	public String getGendanbs() {
		return gendanbs;
	}

	public void setGendanbs(String gendanbs) {
		this.gendanbs = gendanbs;
	}

	public String getFanshuiContent() {
		return fanshuiContent;
	}

	public void setFanshuiContent(String fanshuiContent) {
		this.fanshuiContent = fanshuiContent;
	}

	public String getFanshuiPicture() {
		return fanshuiPicture;
	}

	public void setFanshuiPicture(String fanshuiPicture) {
		this.fanshuiPicture = fanshuiPicture;
	}

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	public Double getXluckCount() {
		return xluckCount;
	}

	public void setXluckCount(Double xluckCount) {
		this.xluckCount = xluckCount;
	}

	public Integer getXluckFlag() {
		return xluckFlag;
	}

	public void setXluckFlag(Integer xluckFlag) {
		this.xluckFlag = xluckFlag;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	public Double getMinimumOdds() {
		return minimumOdds;
	}

	public void setMinimumOdds(Double minimumOdds) {
		this.minimumOdds = minimumOdds;
	}
	@Override
	public String toString() {
		return "Admin [id=" + id + ", weihukaiguan=" + weihukaiguan + ", weihuyuanyin=" + weihuyuanyin
				+ ", zhangbiankaiguan=" + zhangbiankaiguan + ", baimingdankaiguan=" + baimingdankaiguan
				+ ", chatroomFlag=" + chatroomFlag + ", receiveAReturnPoint=" + receiveAReturnPoint + ", notice="
				+ notice + ", pc_notice=" + pc_notice + ", buy1=" + buy1 + ", buy2=" + buy2 + ", buy3=" + buy3
				+ ", buy4=" + buy4 + ", buy5=" + buy5 + ", wangzhantitle=" + wangzhantitle + ", zhuceipcount="
				+ zhuceipcount + ", logo=" + logo + ", pc_welcome=" + pc_welcome + ", pc_wechat=" + pc_wechat
				+ ", luckyFlag=" + luckyFlag + ", rechargeMoney=" + rechargeMoney + ", returnMoney=" + returnMoney
				+ ", luckyTitle=" + luckyTitle + ", dluckCount=" + dluckCount + ", dluckFlag=" + dluckFlag
				+ ", qiandaoflag=" + qiandaoflag + ", meiriMoney=" + meiriMoney + ", meiyueMoney=" + meiyueMoney
				+ ", lishiMoney=" + lishiMoney + ", yueMoney=" + yueMoney + ", moneyType=" + moneyType + ", moneySuiji="
				+ moneySuiji + ", moneyGuding=" + moneyGuding + ", meiriJine=" + meiriJine + ", meiyueJine="
				+ meiyueJine + ", lishiJine=" + lishiJine + ", yueJine=" + yueJine + ", hongbaoflag=" + hongbaoflag
				+ ", jineType=" + jineType + ", jineSuiji=" + jineSuiji + ", jineGuding=" + jineGuding + ", time="
				+ time + ", redenvelopes=" + redenvelopes + ", leavingamessage=" + leavingamessage
				+ ", typeofredenvelopes=" + typeofredenvelopes + ", numberofredpackets=" + numberofredpackets
				+ ", stratchulitime=" + stratchulitime + ", endchulitime=" + endchulitime + ", maxtikuanjine="
				+ maxtikuanjine + ", mintikuanjine=" + mintikuanjine + ", meiritikuancount=" + meiritikuancount
				+ ", drawingRatio=" + drawingRatio + ", drawingFlag=" + drawingFlag + ", drawingMoney=" + drawingMoney
				+ ", dcountMoney=" + dcountMoney + ", kuaisucunkuanflag=" + kuaisucunkuanflag
				+ ", disanfangcunkuanflag=" + disanfangcunkuanflag + ", kuaisucunkuannote=" + kuaisucunkuannote
				+ ", disanfangcunkuannote=" + disanfangcunkuannote + ", tips=" + tips + ", kefusbtime=" + kefusbtime
				+ ", kefuxbtime=" + kefuxbtime + ", xitongcaizjratio=" + xitongcaizjratio + ", huiyuanchushijine="
				+ huiyuanchushijine + ", shiwanzhucekaiqi=" + shiwanzhucekaiqi + ", shiwanchushijine="
				+ shiwanchushijine + ", money=" + money + ", messageFlag=" + messageFlag + ", agent_flag=" + agent_flag
				+ ", zuhuipkaiguan=" + zuhuipkaiguan + ", wangzhandomain=" + wangzhandomain + ", dcountFlag="
				+ dcountFlag + ", tikuanshifousuccess=" + tikuanshifousuccess + ", tikuanxiaofeibili="
				+ tikuanxiaofeibili + ", tikuanshixiaotime=" + tikuanshixiaotime + ", cunkuanshixiaotime="
				+ cunkuanshixiaotime + ", kefuurl=" + kefuurl + ", kefuloginxianshi=" + kefuloginxianshi
				+ ", xitongcaicheckms=" + xitongcaicheckms + ", caipiaotouzhums=" + caipiaotouzhums + ", registType="
				+ registType + ", loginType=" + loginType + ", chongzhiType=" + chongzhiType + ", hemai=" + hemai
				+ ", gendan=" + gendan + ", gendancs=" + gendancs + ", gendanbs=" + gendanbs + ", fanshuiContent="
				+ fanshuiContent + ", fanshuiPicture=" + fanshuiPicture + ", url=" + url + ", xluckCount=" + xluckCount
				+ ", xluckFlag=" + xluckFlag + "]";
	}

}