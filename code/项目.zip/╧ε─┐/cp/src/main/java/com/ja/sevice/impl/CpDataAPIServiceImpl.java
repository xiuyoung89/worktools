package com.ja.sevice.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.ja.dao.CpDataAPIMapper;
import com.ja.sevice.ICpDataAPIService;

/**
 * @DESC: 
 * @AUTH: qhzh 
 * @DATE: 2018年9月15日 上午9:37:39
 */
public class CpDataAPIServiceImpl implements ICpDataAPIService{

	@Autowired
	private CpDataAPIMapper apiMapper;
	
	@Override
	public List<String> findValidApiUrls() {
		return apiMapper.findValidApiUrls();
	}

}
