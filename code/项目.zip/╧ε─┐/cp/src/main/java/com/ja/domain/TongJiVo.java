package com.ja.domain;

import java.io.Serializable;

public class TongJiVo implements Serializable{
	
    /**
	 * 
	 */
	private static final long serialVersionUID = -5929387344250203264L;

	private Integer id;//统计概况

    private Integer yonghusl;//用户总数

    private Integer dailisl;//代理数量

    private Integer huiyuansl;//会员数量

    private Integer zuorizc;//昨日注册数量

    private Integer jinrizc;//今日注册数量

    private Double jinritz;//今日投注

    private Double jinrizj;//今日中奖

    private Double jinricz;//今日充值

    private Double jinritk;//今日提款

    private Double jinrifd;//今日返点
    
    private Double jinrifs; //今日反水

    private Integer zaixianrs;//在线会员人数

    private Double yuezs;//余额总数

    
    public static long getSerialversionuid() {
		return serialVersionUID;
	}
    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }
	
	public Integer getYonghusl() {
		return yonghusl;
	}

	public Double getJinrifs() {
		return jinrifs;
	}

	public void setJinrifs(Double jinrifs) {
		this.jinrifs = jinrifs;
	}

	public void setYonghusl(Integer yonghusl) {
		this.yonghusl = yonghusl;
	}

	public Integer getDailisl() {
		return dailisl;
	}

	public void setDailisl(Integer dailisl) {
		this.dailisl = dailisl;
	}

	public Integer getHuiyuansl() {
		return huiyuansl;
	}

	public void setHuiyuansl(Integer huiyuansl) {
		this.huiyuansl = huiyuansl;
	}

	public Integer getZuorizc() {
		return zuorizc;
	}

	public void setZuorizc(Integer zuorizc) {
		this.zuorizc = zuorizc;
	}

	public Integer getJinrizc() {
		return jinrizc;
	}

	public void setJinrizc(Integer jinrizc) {
		this.jinrizc = jinrizc;
	}

	public Double getJinritz() {
		return jinritz;
	}

	public void setJinritz(Double jinritz) {
		this.jinritz = jinritz;
	}

	public Double getJinrizj() {
		return jinrizj;
	}

	public void setJinrizj(Double jinrizj) {
		this.jinrizj = jinrizj;
	}

	public Double getJinricz() {
		return jinricz;
	}

	public void setJinricz(Double jinricz) {
		this.jinricz = jinricz;
	}

	public Double getJinritk() {
		return jinritk;
	}

	public void setJinritk(Double jinritk) {
		this.jinritk = jinritk;
	}

	public Double getJinrifd() {
		return jinrifd;
	}

	public void setJinrifd(Double jinrifd) {
		this.jinrifd = jinrifd;
	}

	public Integer getZaixianrs() {
		return zaixianrs;
	}

	public void setZaixianrs(Integer zaixianrs) {
		this.zaixianrs = zaixianrs;
	}

	public Double getYuezs() {
		return yuezs;
	}

	public void setYuezs(Double yuezs) {
		this.yuezs = yuezs;
	}

	@Override
	public String toString() {
		return "TongJiVo [id=" + id + ", yonghusl=" + yonghusl + ", dailisl=" + dailisl + ", huiyuansl=" + huiyuansl
				+ ", zuorizc=" + zuorizc + ", jinrizc=" + jinrizc + ", jinritz=" + jinritz + ", jinrizj=" + jinrizj
				+ ", jinricz=" + jinricz + ", jinritk=" + jinritk + ", jinrifd=" + jinrifd + ", jinrifs=" + jinrifs
				+ ", zaixianrs=" + zaixianrs + ", yuezs=" + yuezs + "]";
	}

	public TongJiVo() {
		super();
	}
}