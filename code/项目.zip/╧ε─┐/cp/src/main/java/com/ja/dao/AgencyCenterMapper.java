package com.ja.dao;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.ja.domain.AgentLink;
import com.ja.domain.Jine;
import com.ja.domain.Liushui;
import com.ja.domain.Order;
import com.ja.domain.User;

public interface AgencyCenterMapper {
	
	
	/**
	 * 查询当前 代理的代理连接  第二套代理系统的
	 * @param userName 代理用户的用户名  就是User表里面的用户名  name字段的名字
	 * @return 查到则返回list集合包含AgentLink对象数据 如果没有查询到则返回一个空集合
	 */
	List<AgentLink> pueryProxyLinks(@Param("userName")String userName,@Param("gamePlayer")Integer gamePlayer);
	
	/**
	 * 插入当前代理的代理连接 第二套代理系统的 
	 * @param a 代理连接对象数据
	 * @return 成功则返回1 失败应该返回1一下的数字
	 */
	int insertProxyLinks(AgentLink a);
	/**
	 * 查询数据里面最新的一条数据的id保证邀请码的唯一性
	 * @return 返回数据库里面最后一条数据的id
	 */
	Integer agencyId();
	/**
	 * 根据邀请码查询代理
	 * @param invitationCode 邀请码
	 * @return 查询到这个代理则返回 AgentLink对象数据  如果没有查询到则返回null
	 */
	AgentLink pueryagencyInvitationCode(String invitationCode);
	
	
	/**
	 * 根据推广链接查询代理
	 * @param iCode 推广链接
	 * @return 查询到这个代理则返回 AgentLink对象数据  如果没有查询到则返回null
	 */
	AgentLink pueryagencyLinks(String iCode);
	
	/**
	 *根据动态参数查询代理下级下注记录
	 * @param name  当前的用户名
	 * @param xname 代理下级的用户名
	 * @param cname 彩种名
	 * @param date1 开始时间
	 * @param date2 结束时间
	 * @param userid 代理的id
	 * @param state 开奖状态 1待开奖-2未中奖-3-已中奖-6-和局中奖-7-8-撤单  状态
	 * @return 查询到责返回List集合  没有查询到则返回一个空集合
	 */
	List<Order> xjcathecticRecord(@Param("startIndex")Integer startIndex,@Param("lineCount")Integer lineCount,@Param("name")String name,@Param("userid")Integer userid,@Param("xname")String xname,@Param("state")Integer state,@Param("cname")String cname,@Param("date1")String date1,@Param("date2")String date2);
	
	/**
	 * 根据Fid查询上级的信息
	 * @param Fid 上级的Id
	 * @return 返回当前的上级对象
	 */
	User treeData(int Fid);
	
	
	/**
	 *根据动态参数统计代理下级下注记录
	 * @param name  当前的用户名
	 * @param xname 代理下级的用户名
	 * @param cname 彩种名
	 * @param date1 开始时间
	 * @param date2 结束时间
	 * @param userid 代理的id
	 * @param state 开奖状态 1待开奖-2未中奖-3-已中奖-6-和局中奖-7-8-撤单  状态
	 * @return 返回一个int 值 如果有数据则返回 条数  如果没有数据则返回0
	 */
	Integer xjcathecticRecords(@Param("name")String name,@Param("userid")Integer userid,@Param("xname")String xname,@Param("state")Integer state,@Param("cname")String cname,@Param("date1")String date1,@Param("date2")String date2);
	/**
	 * 根据代理的id查询所有直属下级
	 * @param u 代理对象数据 
	 * @return 查询到则返回当前代理的全部下级 如果没有查询到则返回一个空集合
	 */
	List<User> subordinate(User u);
	/**
	 * 根据用户名查询当前用户的账户流水
	 * @param name 用户名
	 * @param startIndex  起始页
	 * @param lineCount 每页多少条
	 * @return 查询到则返回当前用户的账户流水  没有查询到则返回一个空集合
	 */
	List<Liushui> subordinatePipeline(@Param("name")String name,@Param("startIndex")Integer startIndex,@Param("lineCount")Integer lineCount,@Param("date1")String date1,@Param("date2")String date2);
	/**
	 * 根据用户名统计当前用户的账户流水的条数
	 * @param name 用户名
	 * @return 返回当前会员的账户流水总条数 如果没有则返回0
	 */
	Integer subordinatePipelines(@Param("name")String name,@Param("date1")String date1,@Param("date2")String date2);
	/**
	 * 根据当前用户名查找该会员的充值提款记录
	 * @param name 用户名
	 * @param date1 开始时间
	 * @param date2 结束时间
	 * @param state 状态 1-提现记录  2-充值记录
	 * @return 查询到则返回 list集合  如果没有查询到则返回一个空集合
	 */
	List<Jine> subordinateRecharge(@Param("startIndex")Integer startIndex,@Param("lineCount")Integer lineCount,@Param("name")String name,@Param("date1")String date1,@Param("date2")String date2,@Param("state")Integer state);
	/**
	 * 根据当前用户名查找该会员的充值提款记录的总条数
	 * @param name 用户名
	 * @param 间
	 * @param date2 结束时间date1 开始时
	 * @param state 状态 1-提现记录  2-充值记录
	 * @return 返回当前会员的 充值 或者是 提现的总条数
	 */
	Integer subordinateRecharges(@Param("name")String name,@Param("date1")String date1,@Param("date2")String date2,@Param("state")Integer state);
	/**
	 * 查询直属下级的账户流水
	 * @param startIndex 起始页
	 * @param lineCount 每页多少条
	 * @param userid 代理的id 
	 * @param date1 开始时间
	 * @param date2 结束时间
	 * @return 查询到则返回 这个代理所有的下级流水 如果没有查询到则返回一个空集合
	 */
	List<Liushui> directlyUnder(@Param("startIndex")Integer startIndex,@Param("lineCount")Integer lineCount,@Param("userid")Integer userid,@Param("date1")String date1,@Param("date2")String date2);
	/**
	 * 查询直属下级的账户流水的总条数
	 * @param userid 代理的id
	 * @param date1 开始时间
	 * @param date2 结束时间
	 * @return 返回当前代理直属下级的流水总条数
	 */
	Integer directlyUnders(@Param("userid")Integer userid,@Param("date1")String date1,@Param("date2")String date2);
	/**
	 * 查询直属下级的 充值提款 记录
	 * @param startIndex 起始页
	 * @param lineCount 每页多少条
	 * @param userid 代理的id
	 * @param date1 开始时间 
	 * @param date2 结束时间
	 * @param state 1-提现记录  2-充值记录
	 * @return 查询到则返回list集合  如果没有查询到则返回一个空集合
	 */
	List<Jine> rechargeWithdrawal(@Param("startIndex")Integer startIndex,@Param("lineCount")Integer lineCount,@Param("userid")Integer userid,@Param("date1")String date1,@Param("date2")String date2,@Param("state")Integer state);
	/**
	 * 查询直属下级的 充值提现 总条数
	 * @param userid 代理的id
	 * @param date1 开始时间
	 * @param date2 结束时间
	 * @param state 1-提现记录  2-充值记录
	 * @return 返回当前代理下级的充值提现总条数
	 */
	Integer rechargeWithdrawals(@Param("userid")Integer userid,@Param("date1")String date1,@Param("date2")String date2,@Param("state")Integer state);

	/**
	 * 根据代理删除代理连接以及邀请码
	 * @param u 代理
	 * @param invitationCode 邀请码
	 * @return 删除成功则返回1 删除失败则返回 1一下的数字 0
	 */
	 int deleteAgenLink(@Param("u")User u,@Param("invitationCode")String invitationCode);
	
}
