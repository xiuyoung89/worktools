package com.ja.domain;

import java.io.Serializable;

public class Jine implements Serializable{
    /**
	 * 
	 */
	private static final long serialVersionUID = -8084776407584211840L;

	private Integer id;//用户充值-提款记录

    private String name;//会员帐号

    private String ordernum;//订单号

    private String zhifupt;//支付平台

    private Double fukuanje;//付款金额

    private String ckname;//存款人姓名

    private String zhifuzh;//支付帐号

    private String hydengji;//会员等级

    private String skname;//收款人姓名

    private String skbankzh;//收款人银行卡帐号

    private Double tikuanje;//提款金额

    private Double tikuansxf;//提款打码量

    private String sqtime;//申请时间

    private String cltime;//处理时间

    private String type;//资金来源类型

    private String state;//处理状态

    private String caozuo;//是否操作

    private String czname;//操作员

    private String beizhu;//备注

    private Integer status;//显示状态

    private Integer userid;//用户id

    
    public static long getSerialversionuid() {
		return serialVersionUID;
	}
    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name == null ? null : name.trim();
    }

    public String getOrdernum() {
        return ordernum;
    }

    public void setOrdernum(String ordernum) {
        this.ordernum = ordernum == null ? null : ordernum.trim();
    }

	public Integer getStatus() {
		return status;
	}

	public void setStatus(Integer status) {
		this.status = status;
	}

	public String getZhifupt() {
        return zhifupt;
    }

    public void setZhifupt(String zhifupt) {
        this.zhifupt = zhifupt == null ? null : zhifupt.trim();
    }

    public Double getFukuanje() {
        return fukuanje;
    }

    public void setFukuanje(Double fukuanje) {
        this.fukuanje = fukuanje;
    }

    public String getCkname() {
        return ckname;
    }

    public void setCkname(String ckname) {
        this.ckname = ckname == null ? null : ckname.trim();
    }

    public String getZhifuzh() {
        return zhifuzh;
    }

    public void setZhifuzh(String zhifuzh) {
        this.zhifuzh = zhifuzh == null ? null : zhifuzh.trim();
    }

    public String getHydengji() {
        return hydengji;
    }

    public void setHydengji(String hydengji) {
        this.hydengji = hydengji == null ? null : hydengji.trim();
    }

    public String getSkname() {
        return skname;
    }

    public void setSkname(String skname) {
        this.skname = skname == null ? null : skname.trim();
    }

    public String getSkbankzh() {
        return skbankzh;
    }

    public void setSkbankzh(String skbankzh) {
        this.skbankzh = skbankzh == null ? null : skbankzh.trim();
    }

    public Double getTikuanje() {
        return tikuanje;
    }

    public void setTikuanje(Double tikuanje) {
        this.tikuanje = tikuanje;
    }

    public Double getTikuansxf() {
		return tikuansxf;
	}

	public void setTikuansxf(Double tikuansxf) {
		this.tikuansxf = tikuansxf;
	}

	public String getSqtime() {
        return sqtime;
    }

    public void setSqtime(String sqtime) {
        this.sqtime = sqtime == null ? null : sqtime.trim();
    }

    public String getCltime() {
        return cltime;
    }

    public void setCltime(String cltime) {
        this.cltime = cltime == null ? null : cltime.trim();
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type == null ? null : type.trim();
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state == null ? null : state.trim();
    }

    public String getCaozuo() {
        return caozuo;
    }

    public void setCaozuo(String caozuo) {
        this.caozuo = caozuo == null ? null : caozuo.trim();
    }

    public String getCzname() {
        return czname;
    }

    public void setCzname(String czname) {
        this.czname = czname == null ? null : czname.trim();
    }

    public String getBeizhu() {
        return beizhu;
    }

    public void setBeizhu(String beizhu) {
        this.beizhu = beizhu == null ? null : beizhu.trim();
    }

    public Integer getUserid() {
        return userid;
    }

    public void setUserid(Integer userid) {
        this.userid = userid;
    }
    
    public Jine() {
		super();
	}

	@Override
	public String toString() {
		return "Jine [id=" + id + ", name=" + name + ", ordernum=" + ordernum + ", zhifupt=" + zhifupt + ", fukuanje="
				+ fukuanje + ", ckname=" + ckname + ", zhifuzh=" + zhifuzh + ", hydengji=" + hydengji + ", skname="
				+ skname + ", skbankzh=" + skbankzh + ", tikuanje=" + tikuanje + ", tikuansxf=" + tikuansxf
				+ ", sqtime=" + sqtime + ", cltime=" + cltime + ", type=" + type + ", state=" + state + ", caozuo="
				+ caozuo + ", czname=" + czname + ", beizhu=" + beizhu + ", status=" + status + ", userid=" + userid
				+ "]";
	}

}