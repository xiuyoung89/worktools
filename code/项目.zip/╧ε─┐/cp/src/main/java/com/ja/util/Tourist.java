package com.ja.util;

import java.util.ArrayList;
import java.util.List;

import com.ja.domain.Touristy;

public class Tourist {
	//在线游客
	public static List<Touristy> tourist= new ArrayList<Touristy>();
	
}
