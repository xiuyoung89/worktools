package com.ja.controller;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.ja.domain.AdminUser;
import com.ja.domain.AllExplain;
import com.ja.sevice.AllExplainService;
import com.ja.sevice.OperationlogService;
import com.ja.util.JsonResult;

/**
 * 项目名称：cp   
 * 类名称：PC_ExplainController   
 * 类描述：   平台的说明类
 * 创建人：GL   
 * 创建时间：2018年10月10日 上午11:27:43   
 * @version
 */
@Controller
@RequestMapping("/explain")
public class Ht_ExplainController {  

	@Autowired
	private AllExplainService allExplainService;  

	@Autowired
	private OperationlogService operationlogService;

	/**
	 * 方法名：explainPage 
	 * 描述：     平台说明管理页面                 
	 * 参数：    @return 
	 * @return: String
	 */
	@RequestMapping("/explainPage")
	public String explainPage() {
		return "/htgl/explain";
	}

	/**
	 *   方法名：findAllExplain   
	 *   描述：     查询所有帮助的说明                  TODO   
	 *   参数：    type 1 是所有的菜单 2是所有的帮助说明 3是日常说明
	 *   参数：    @return 
	 * @return: JsonResult
	 */
	@RequestMapping("/findAllExplain")
	@ResponseBody
	public JsonResult findAllExplain() {
		return new JsonResult("success", allExplainService.findAllExplain(0));
	}
	
	/**
	 *   方法名：findTypeExplain 
	 *   描述：     查询所有的说明                  TODO   
	 *   参数：    type 1 是所有的菜单 2是所有的帮助说明 3是日常说明
	 *   参数：    @return 
	 * @return: JsonResult
	 */
	@RequestMapping("/findTypeExplain")
	@ResponseBody
	public JsonResult findTypeExplain(Integer type) {
		return new JsonResult("success", allExplainService.findAllExplain(type));
	}
	
	/**
	 *   方法名：findByIdExplain   
	 *   描述：     根据id查询说明                TODO   
	 *   参数：    @param id
	 *   参数：    @return 
	 * @return: JsonResult
	 */
	@RequestMapping("/findByIdExplain")
	@ResponseBody
	public JsonResult findByIdExplain(Integer id) {
		return new JsonResult("success", allExplainService.findByIdExplain(id));
	}
	
	/**
	 *   方法名：saveExplain   
	 *   描述：    添加或修改说明                   TODO   
	 *   参数：    @param explain
	 *   参数：    @return 
	 * @return: JsonResult
	 */
	@RequestMapping("/saveExplaine")
	@ResponseBody
	public JsonResult saveExplain(HttpSession session,AllExplain explain) {
		String remarks = "";
		if(null!=explain.getId()){
			if(null!=explain.getMenu()) {
				remarks = "修改了标题为："+explain.getMenu()+"的说明信息!";
			}else {
				remarks = "修改了标题为："+explain.getDoubt()+"的说明信息!";
			}
		}else {
			remarks = "增加了一条标题为："+explain.getMenu()+"的说明信息!";
		}
		remarks = "修改了App下载页面的配置信息!";
		AdminUser admins = (AdminUser)session.getAttribute("admin1");
		operationlogService.addOperationlog(admins, remarks, "说明页面管理");
		return new JsonResult("success", allExplainService.saveExplaine(explain)); 
	}
	
	/**
	 * 方法名：deleteExplain 
	 * 描述：     删除说明                    
	 * 参数：    @param id
	 * 参数：    @return 
	 * @return: JsonResult
	 */
	@RequestMapping("/deleteExplain")
	@ResponseBody
	public JsonResult deleteExplain(HttpSession session,Integer id) {
		String remarks = "删除了id编号为："+id+"的说明信息!";
		AdminUser admins = (AdminUser)session.getAttribute("admin1");
		operationlogService.addOperationlog(admins, remarks, "说明页面管理");
		return new JsonResult("success", allExplainService.deleteExplain(id)); 
	}
	
}
