package com.ja.sevice.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.ja.config.WebsiteStateConfig;
import com.ja.dao.AttributeMapper;
import com.ja.dao.DataMapper;
import com.ja.dao.PlayCountMapper;
import com.ja.domain.Attribute;
import com.ja.domain.Data;
import com.ja.domain.PlayCount;
import com.ja.domain.Product;
import com.ja.sevice.IDataService;
import com.ja.util.DateUtil;

public class DataServiceImpl implements IDataService{

	@Autowired
	private AttributeMapper attributeMapper;
	
	@Autowired
	private DataMapper dataMapper;
	
	@Autowired
	private PlayCountMapper playCountMapper;
	
	@Override
	public List<Data> getLatestData() {
		return dataMapper.getLatestData();
	}
	@Override
	public List<Data> getDatasbyCname(String cName) {
		return dataMapper.getDatasbyCname(cName);
	}
	
	@Override
	public Data getLotteryDate(String period,String cname) {
		return dataMapper.getLotteryDate(period,cname);
	}
	
	/**根据彩种查询开奖记录*/
	@Override
	public List<Data> getAllData(String cname,String date) {
		return dataMapper.getAllData(cname,date);
	}
	
	/**根据条件查询开奖记录*/
	@Override
	public List<Data> getMhAllData(Integer integer, Integer integer2, Data data, String date1, String date2,int i) {
		return dataMapper.getMhAllData(integer,integer2,data,date1,date2,i);
	}
	
	/**查询所有的开奖记录*/
	@Override
	public List<Data> getSouyou() {
		return dataMapper.getSouyou();
	}
	
	@Override
	public List<Data> findTodycz(String cname) {
		return dataMapper.findTodycz(cname);
	}
	
	@Override
	public List<Data> findBjpk10() {
		return dataMapper.findBjpk10();
	}
	
	/**六合彩预设记录*/
	@Override
	public List<Data> getAllLiuhePreset() {
		return dataMapper.getAllLiuhePreset();
	}
	
	@Override
	public int addLiuheCheck(Data data) {
		return dataMapper.addLiuheCheck(data);
	}
	
	/** 手动开奖填写开奖号码 */
	@Override
	public int updateCheckNum(Data data) {
		return dataMapper.updateCheckNum(data);
	}
	
	/**手动彩票派奖*/
	@Override
	public int updateCheck(Data data) {
		return dataMapper.updateCheck(data);
	}
	
	/**未开奖的数据*/
	@Override
	public List<Data> findNull() {
		return dataMapper.findNull();
	}
	
	/**最大一期的期号*/
	@Override
	public Data getMaxPeriod(String cname) {
		return dataMapper.getMaxPeriod(cname);
	}
	
	/**添加开奖时间*/
	@Override
	public int updateDate(Data data) {
		return dataMapper.updateDate(data);
	}
	@Override
	public int xg6hc(String cName) {
		return dataMapper.xg6hc(cName);
	}
	@Override
	public int xglhcDelete(String period, String cname) {
		dataMapper.xglhcDelete(period, cname);
		return 0;
	}
	@Override
	public Data Verification(String cName,String period) {
		return dataMapper.Verification(cName,period);
	}
	
	/**修改香港六合彩属性*/
	@Override
	public int updateAttributes(Attribute attribute) {
		return attributeMapper.updateAttributes(attribute);
	}
	
	/**查看所有的属性*/
	@Override
	public List<Attribute> findAllAttribute() {
		return attributeMapper.findAllAttribute();
	}
	
	/**官方异常修改状态*/
	@Override
	public int updateFail(Data data) {
		return dataMapper.updateFail(data);
	}
	
	/**查询某个彩种的开奖记录 */
	@Override
	public List<Data> getCheckData(Integer startIndex, Integer lineCount,String cname,int model) {
		return dataMapper.getCheckData(startIndex,lineCount,cname,model);
	}
	
	@Override
	public int insertByBatch(List<Data> datas) {
		return dataMapper.insertByBatch(datas);
	}
	@Override
	public Data findBetsTime(String name, String time, String time3) {
		return dataMapper.findBetsTime(name, time, time3);
	}
	
	@Override
	public void updateByBatch(List<Data> updateDatas) {
		dataMapper.updateByBatch(updateDatas);
	}
	@Override
	public List<Data> findDatas(List<Data> data) {
		return dataMapper.findDatas(data);
	}
	@Override
	public int addSystemLotters(List<Data> datas) {
		return dataMapper.addSystemLotters(datas);
	}
	@Override
	public Data findNewestPeriod(String cname,String time) {
		String times = time.split(" ")[0];
		return dataMapper.findNewestPeriod(cname,times);
	}
	@Override
	public int addSystemLotterInfo(Data data) {
		return dataMapper.addSystemLotterInfo(data);
	}
	
	@Override
	public double findSystemLotterRatio() {
		int r1 = Integer.parseInt(WebsiteStateConfig.configs.get("xitongcaizjratio"));
		double ratio = (double)r1 / (double)100;
		return ratio;
	}
	@Override
	public Data findLotterFirstPeriod(String cname, String newPeriod) {
		return dataMapper.findLotterFirstPeriod(cname, newPeriod);
	}
	
	@Override
	public Data findLotterLastPeriod(String cname,String time) {
		String times = time.split(" ")[0];
		return dataMapper.findLotterLastPeriod(cname,times);
	}
	
	@Override
	public String getTodayLatestPeriodOfNormalCp(String cName, String periodLike) {
		return dataMapper.getTodayLatestPeriodOfNormalCp(cName, periodLike);
	}
	
	@Override
	public String getTodayLatestPeriodOfSpecialCp(String cName, String startPeriod, String endPeriod) {
		return dataMapper.getTodayLatestPeriodOfSpecialCp(cName, startPeriod, endPeriod);
	}
	@Override
	public int addLiuheChecks(Data data) {
		return dataMapper.addLiuheChecks(data);
	}
	@Override
	public Data findDataByNameAndPeriod(String cname, String period) {
		return dataMapper.findDataByNameAndPeriod(cname,period);
	}
	@Override
	public Data getLatestOpenData(String cname) {
		return dataMapper.getLatestOpenData(cname);
	}
	@Override
	public void updateLotterNumberToEmptyStr(Integer id) {
		dataMapper.updateLotterNumberToEmptyStr(id);
	}
	@Override
	public Data findById(Integer id) {
		return dataMapper.findById(id);
	}
	@Override
	public Data findBySetCname(String cname, String time) {
		return dataMapper.findBySetCname(cname, time);
	}
	@Override
	public int updateCheckState(Data data) {
		return dataMapper.updateCheckState(data);
	}
	@Override
	public int updatePlayResult(Data data) {
		return dataMapper.updatePlayResult(data);
	}
	@Override
	public List<Data> findLiuHeAttribute(int type) {
		return dataMapper.findLiuHeAttribute(type);
	}
	@Override
	public List<PlayCount> findPlayDetails(Data data) {
		return dataMapper.findPlayDetails(data);
	}
	@Override
	public int changeCheckState(Data data) {
		return dataMapper.changeCheckState(data);
	}
	@Override
	public Data findNextPeriod(String cname) {
		return dataMapper.findNextPeriod(cname);
	}
	
	@Override
	public int update(String cname,String period, String lotterNumber, String lotterTime) {
		return dataMapper.update(cname, period, lotterNumber, lotterTime);
	}
	@Override
	public Data querynextIssueNumber(String cName, String nextperiod) {
		return dataMapper.querynextIssueNumber(cName, nextperiod);
	}
	@Override
	public Product selectDateTime(String cname, String time) {
		Product p = dataMapper.selectDateTime(cname, time);
		return p;
	}
	@Override
	public Product dateTime(String cname, int id) {
		return dataMapper.dateTime(cname, id);
	}
	@Override
	public void updateStatusTo1(Integer id) {
		dataMapper.updateStatusTo1(id);
	}
	@Override
	public void updatePreDataStatusTo1(String cname, Integer id) {
		dataMapper.updatePreDataStatusTo1(cname,id);
	}
	@Override
	public String findLastTime(Integer id, String cname) {
		return dataMapper.findLastTime(id, cname);
	}
	@Override
	public List<Data> findCurrDatas(String nowTime) {
		return dataMapper.findCurrDatas(nowTime);
	}
	@Override
	public void insert(Data data) {
		dataMapper.insert(data);
	}
	@Override
	public List<Data> getPageData(int iDisplayStart, int iDisplayLength) {
		return dataMapper.getPageData(iDisplayStart, iDisplayLength);
	}
	@Override
	public List<Data> getLimitDataInfo(String cname) {
		return dataMapper.getLimitDataInfo(cname);
	}
	@Override
	public Integer count() {
		return dataMapper.count();
	}
	@Override
	public List<Data> lastWeek() {
		return dataMapper.lastWeek();
	}
	@Override
	public List<Data> lastMonth() {
		return dataMapper.lastMonth();
	}
	@Override
	public int deletedata(List<Data> data) {
		return dataMapper.deletedata(data);
	}
	@Override
	public Integer getCheckDataCounts(String cname) {
		return dataMapper.getCheckDataCounts(cname);
	}
	@Override
	public Integer getMhAllDataCounts(Data data, String date1, String date2) {
		return dataMapper.getMhAllDataCounts(data, date1, date2);
	}
	@Override
	public List<Data> lotterDatas(String cname, Integer type) {
		String date = "";
		switch (type) {
		case 1:
			date = DateUtil.findFormatDate();
			break;
		case 2:
			date = DateUtil.findLatelyDate(-1);
			break;
		case 3:
			date = DateUtil.findLatelyDate(-2);
			break;
		}
		List<Data> data = dataMapper.lotterDatas(cname, date);
		return data;
	}
	
	@Override
	public Data findNextNextPeriod(String cname, Integer type) {
		return dataMapper.findNextNextPeriod(cname,type);
	}
	@Override
	public Integer xg6hcId() {
		return dataMapper.xg6hcId();
	}
	@Override
	public PlayCount findCplay(PlayCount play) {
		return playCountMapper.getCplay(play);
	}
	@Override
	public List<Data> findTrend(String time,String cname) {
		return dataMapper.findTrend(time,cname);
	}
	@Override
	public Data xg6hcchax(String period) {
		return dataMapper.xg6hcchax(period);
	}
	@Override
	public int statusXg6hc(Data data) {
		return dataMapper.statusXg6hc(data);
	}
	@Override
	public Data pueryCurrentPeriod(String cname, String period) {
		return dataMapper.pueryCurrentPeriod(cname, period);
	}
	@Override
	public List<Data> queryData(String cName) {
		return dataMapper.queryData(cName);
	}
	@Override
	public List<Data> databaseExceptionData() {
		return dataMapper.databaseExceptionData();
	}
	@Override
	public Data theLastItem(String cName) {
		return dataMapper.theLastItem(cName);
	}
	

	@Override
	public Data previousIssue(String cName, String period) {
		return dataMapper.previousIssue(cName, period);
	}
	@Override
	public Integer getAbnormalData() {
		return dataMapper.getAbnormalData();
	}
	@Override
	public int updataCnameStatus(String cname, String period) {
		return dataMapper.updataCnameStatus(cname, period);
	}
	@Override
	public int upDataNextTime(String cname, String period, String nextStopOrderTimeEpoch) {
		return dataMapper.upDataNextTime(cname, period, nextStopOrderTimeEpoch);
	}
	@Override
	public int updataNextDate(String cName, String period, String openTime, String nextStopOrderTimeEpoch,int status) {
		return dataMapper.updataNextDate(cName, period, openTime, nextStopOrderTimeEpoch,status);
	}
	@Override
	public List<Data> wholeLot() {
		return dataMapper.wholeLot();
	}
	@Override
	public Data Id(Integer id, String cname) {
		return dataMapper.Id(id, cname);
	}
	@Override
	public int Preservation(Data d) {
		return dataMapper.Preservation(d);
	}
	@Override
	public Data lotteryData(String cName, String period) {
		return dataMapper.lotteryData(cName, period);
	}
	@Override
	public int systemLotterUpData(Data d) {
		return dataMapper.systemLotterUpData(d);
	}
	@Override
	public int deleteLotterSystemData(String cName, String period) {
		return dataMapper.deleteLotterSystemData(cName, period);
	}
	@Override
	public Data dataLast(String cName) {
		return dataMapper.dataLast(cName);
	}

}
