package com.ja.util;

import org.jsoup.Connection.Response;
import org.jsoup.Jsoup;

import com.ja.check.data.SslUtils;

/**
 * @DESC:
 * @AUTH: qhzh
 * @DATE: 2018年9月5日 下午4:06:22
 */
public class JsoupUtil {
	//private static Logger logger = (Logger) LogManager.getLogger(JsoupUtil.class);
	/**
	 * 通过Jsoup建立远程连接获取json数据
	 * 
	 * @param url
	 * @param timeoutMillis
	 * @return
	 */
	public static String getJsonStrUseAgent(String url, int timeoutMillis) {
		try {
			SslUtils.ignoreSsl();
			Response r = Jsoup.connect(url).timeout(timeoutMillis).userAgent(
					"Mozilla/5.0(Macintosh;IntelMacOSX10_7_0)AppleWebKit/535.11(KHTML,likeGecko)Chrome/17.0.963.56Safari/535.11")
					.cookie("auth", "token").ignoreContentType(true).execute();
			return r.body();
		} catch (Exception e) {
			//System.out.println("["+DateUtil.getCurrTime()+"] url="+url+"--Exception--"+e.getMessage());
			////e.printStackTrace();
			//logger.info("老赵爬数据报了一个异常----------------1"+url);
		}catch (Error e) {
			//System.out.println("["+DateUtil.getCurrTime()+"] url="+url+"--Error--"+e.getMessage());
			//e.printStackTrace();
			//logger.info("老赵爬数据报了一个异常----------------2"+url);
		}
		return null;
	}
	
	/**
	 * 通过Jsoup建立远程连接获取json数据
	 * 
	 * @param url
	 * @param timeoutMillis
	 * @return
	 */
	public static String getJsonStrNotUseAgent(String url, int timeoutMillis) {
		try {
			SslUtils.ignoreSsl();
			Response r = Jsoup.connect(url).timeout(timeoutMillis).ignoreContentType(true).execute();
			return r.body();
		} catch (Exception e) {
			// System.out.println("url="+url);
			// System.out.println("["+DateUtil.getCurrTime()+"]
			// JsoupUtil.getJsonStr()--"+e.getMessage());
			e.printStackTrace();
		}
		return null;
	}
	
	public static void main(String[] args) {
		String string = getJsonStrUseAgent("http://api.caipiaokong.cn/lottery/?name=ahsyxw&format=json&uid=1022056&token=44873288b8c4630316861b3c75260dc073d56863",500);
		System.out.println(string);
	}

}
