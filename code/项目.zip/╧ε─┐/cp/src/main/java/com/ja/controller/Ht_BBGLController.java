package com.ja.controller;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.ja.domain.Damal;
import com.ja.domain.HYdataVo;
import com.ja.domain.Jine;
import com.ja.domain.TodayRecord;
import com.ja.domain.TongJiVo;
import com.ja.domain.User;
import com.ja.sevice.AgentService;
import com.ja.sevice.DamalService;
import com.ja.sevice.IUserService;
import com.ja.sevice.JineService;
import com.ja.sevice.YunyingbbService;
import com.ja.util.DateUtil;
import com.ja.util.JsonResult;
import com.ja.util.SessionListenerUtil;

/**
 * 项目名称：cp   
 * 类名称：Ht_BBGLController.java   
 * 类描述：   
 * 创建人：   GL
 * 创建时间：2019年2月22日 下午1:45:59   
 * @version v1.0.0
 */
@Controller
@RequestMapping("/bbgl")
public class Ht_BBGLController {

	@Autowired
	private YunyingbbService yunyingbbService;

	@Autowired
	private IUserService userService;

	@Autowired
	private AgentService agentService;

	@Autowired
	private DamalService damalService;
	
	@Autowired
	private JineService jineService;

	/**
	 * 
	 * ---- TODO：全局报表管理
	 * 
	 */

	/**
	 * 方法名：globalReportPage 
	 * 描述：     全局报表管理页面                 
	 * 参数：    @return 
	 * @return: String
	 */
	@RequestMapping("/globalReportPage")
	public String globalReportPage() {
		return "htgl/quanjubaobiaoguanli";
	}

	/**
	 *   方法名：findAllGlobalReport   
	 *   描述：     查询所有的全局报表数据                     
	 *   参数：    @param startTime 开始时间
	 *   参数：    @param endTime 结束时间
	 *   参数：    @param userName 用户名
	 *   参数：    @return 
	 * @return: JsonResult
	 */
	@ResponseBody
	@RequestMapping("/findAllGlobalReport")
	public JsonResult findAllGlobalReport(String startTime,String endTime,String userName) {
		TodayRecord record = new TodayRecord();
		if(!"".equals(userName)) {
			if(DateUtil.findFormatDate().equals(startTime)&&DateUtil.findFormatDate().equals(endTime)) {
				record = yunyingbbService.findAllGlobalReport(startTime, endTime, userName,1,0);
			}else if(DateUtil.findFormatDate().equals(startTime)||DateUtil.findFormatDate().equals(endTime)) {
				record = yunyingbbService.findAllGlobalReport(startTime, endTime, userName,2,0);
			}else if("".equals(startTime)&&"".equals(endTime)){
				record = yunyingbbService.findAllGlobalReport(startTime, endTime, userName,2,0);
			}else {
				record = yunyingbbService.findAllGlobalReport(startTime, endTime, userName,3,0);
			}
			User user = userService.checkUser(userName);
			if(user==null) {
				record.setOrderCount(0);
			}
		}else {
			if(DateUtil.findFormatDate().equals(startTime)&&DateUtil.findFormatDate().equals(endTime)) {
				record = yunyingbbService.findAllGlobalReport(startTime, endTime, userName,1,1);
			}else if(DateUtil.findFormatDate().equals(startTime)||DateUtil.findFormatDate().equals(endTime)) {
				record = yunyingbbService.findAllGlobalReport(startTime, endTime, userName,2,1);
			}else if("".equals(startTime)&&"".equals(endTime)){
				record = yunyingbbService.findAllGlobalReport(startTime, endTime, userName,2,1);
			}else {
				record = yunyingbbService.findAllGlobalReport(startTime, endTime, userName,3,1);
			}
		} 
		return new JsonResult("success", record);
	}
	
	/**
	 * 
	 * ---- TODO：财务报表管理
	 * 
	 */
	
	
	/**
	 * 方法名：financeReportPage 
	 * 描述：     财务报表管理页面                 
	 * 参数：    @return 
	 * @return: String
	 */
	@RequestMapping("/financeReportPage")
	public String financeReportPage() {
		return "htgl/caiwubaobiaoguanli";
	}

	/**
	 *   方法名：findAllFinanceReport   
	 *   描述：     查询所有的财务报表                    
	 *   参数：    @param startTime 开始时间
	 *   参数：    @param endTime 结束时间
	 *   参数：    @param userName 用户名 
	 *   参数：    @return 
	 * @return: JsonResult
	 */
	@ResponseBody
	@RequestMapping("/findAllFinanceReport")
	public JsonResult findAllFinanceReport(String startTime,String endTime,String userName) {
		List<User> users = userService.getAllUsers();
		List<TodayRecord> records = new ArrayList<>();
		TodayRecord record = new TodayRecord();
		if(!"".equals(userName)) {
			User user = userService.checkUser(userName);
			if(user==null) {
				return new JsonResult("", records);
			}
			if(DateUtil.findFormatDate().equals(startTime)&&DateUtil.findFormatDate().equals(endTime)) {
				record = yunyingbbService.findAllFinanceReport(startTime,endTime,user.getName(),1);
			}else if(DateUtil.findFormatDate().equals(startTime)||DateUtil.findFormatDate().equals(endTime)) {
				record = yunyingbbService.findAllFinanceReport(startTime,endTime,user.getName(),2);
			}else if("".equals(startTime)&&"".equals(endTime)){
				record = yunyingbbService.findAllFinanceReport(startTime,endTime,user.getName(),2);
			}else {
				record = yunyingbbService.findAllFinanceReport(startTime,endTime,user.getName(),3);
			}
			if(user.getAgent_type()==1) {
				record.setUser_type("代理");
			}else {
				record.setUser_type("会员");
			}
			record.setName(user.getName());
			records.add(record);
		}else {
			for(User user : users) {
				if(DateUtil.findFormatDate().equals(startTime)&&DateUtil.findFormatDate().equals(endTime)) {
					record = yunyingbbService.findAllFinanceReport(startTime,endTime,user.getName(),1);
				}else if(DateUtil.findFormatDate().equals(startTime)||DateUtil.findFormatDate().equals(endTime)) {
					record = yunyingbbService.findAllFinanceReport(startTime,endTime,user.getName(),2);
				}else if("".equals(startTime)&&"".equals(endTime)){
					record = yunyingbbService.findAllFinanceReport(startTime,endTime,user.getName(),2);
				}else {
					record = yunyingbbService.findAllFinanceReport(startTime,endTime,user.getName(),3);
				}
				if(user.getAgent_type()==1) {
					record.setUser_type("代理");
				}else {
					record.setUser_type("会员");
				}
				record.setName(user.getName());
				records.add(record);
			}
		}
		return new JsonResult("success", records);
	}

	/**
	 * 
	 * ---- TODO：统计概况管理
	 * 
	 */

	/**
	 *   方法名：findStatisticsReport   
	 *   描述：     查询近期的统计详情                     
	 *   参数：    @param request
	 *   参数：    @return 
	 * @return: ModelAndView
	 */
	@RequestMapping("/findStatisticsReport")
	public ModelAndView findStatisticsReport(HttpServletRequest request) {
		ModelAndView m = new ModelAndView("htgl/tongjigaikuangguanli");
		List<String> month = new ArrayList<String>();
		SimpleDateFormat matter = new SimpleDateFormat("yyyyMM");
		Calendar calendar = Calendar.getInstance();
		calendar.add(Calendar.MONTH, -0);
		Date d2 = calendar.getTime();
		BigDecimal time = new BigDecimal(matter.format(d2));
		String t2 = time + "";
		StringBuffer s2 = new StringBuffer(t2);
		s2.insert(4, "-");
		String str = s2 + "";
		month.add(str);
		for (int i = 0; i < 6; i++) {
			calendar.add(Calendar.MONTH, -1);
			Date d3 = calendar.getTime();
			BigDecimal time3 = new BigDecimal(matter.format(d3));
			String t3 = time3 + "";
			StringBuffer s3 = new StringBuffer(t3);
			s3.insert(4, "-");
			String str3 = s3 + "";
			month.add(str3);
		}
		// 查询最近6个月
		int[] ids = { 0, 1, 2, 3, 4};
		List<TodayRecord> records = new ArrayList<TodayRecord>();
		for (int i = 0; i < ids.length; i++) {
			TodayRecord record = yunyingbbService.findRecentReport(month.get(i),1);
			records.add(record);
		}
		// 今日亏盈
		TodayRecord record1 = yunyingbbService.findRecentReport(DateUtil.findFormatDate(),2);
		// 昨日亏盈
		TodayRecord record2 = yunyingbbService.findRecentReport(DateUtil.findLatelyDate(-1),2);
		
		// 查询用户总会员代理注册人数
		int[] agent = userService.getUserCount();
		TongJiVo tongji = new TongJiVo();
		tongji.setDailisl(agent[0]);
		tongji.setHuiyuansl(agent[1]);
		tongji.setYonghusl(agent[2]);
		tongji.setJinrizc(agent[3]);
		tongji.setZuorizc(agent[4]);
		tongji.setJinritz(record1.getTouzhu());
		tongji.setJinrizj(record1.getPaijiang());
		tongji.setJinricz(record1.getChongzhi());
		tongji.setJinritk(record1.getTikuan());
		tongji.setJinrifd(record1.getFandian());
		tongji.setJinrifs(record1.getFanshui());
		tongji.setZaixianrs(SessionListenerUtil.onlineNum(request).size());
		tongji.setYuezs((double)agent[5]);
		m.addObject("jinritj", record1);
		m.addObject("zuoritj", record2);
		m.addObject("zuijintj", records);
		m.addObject("tongji", tongji);
		return m;
	}

	/**
	 * 
	 * 
	 * ---- TODO：运营报表管理
	 * 
	 * 
	 * 
	 */

	/**
	 * 方法名：operateReportPage 
	 * 描述：     运营报表管理页面                 
	 * 参数：    @return 
	 * @return: String
	 */
	@RequestMapping("/operateReportPage")
	public String operateReportPage() {
		return "htgl/yunyingbaobiaoguanli";
	}

	/**
	 *   方法名：operateRecord   
	 *   描述：     查询用户的运营报表                     
	 *   参数：    startTime 开始时间 
	 *   参数：    endTime 结束时间
	 *   参数：    userName 用户名称
	 *   参数：    @return 
	 * @return: JsonResult
	 */
	@ResponseBody
	@RequestMapping("/operateRecord")
	public JsonResult operateRecord(String startTime,String endTime,String userName) {
		List<User> users = userService.getAllUsers();
		List<TodayRecord> records = new ArrayList<>();
		TodayRecord record = new TodayRecord();
		if(!"".equals(userName)) {
			User user = userService.checkUser(userName);
			if(user==null) {
				return new JsonResult("", records);
			}
			if(DateUtil.findFormatDate().equals(startTime)&&DateUtil.findFormatDate().equals(endTime)) {
				record = yunyingbbService.findOperateRecord(DateUtil.findFormatDate(),endTime,user.getName(),1);
			}else if(DateUtil.findFormatDate().equals(startTime)||DateUtil.findFormatDate().equals(endTime)) {
				record = yunyingbbService.findOperateRecord(startTime,endTime,user.getName(),2);
			}else if("".equals(startTime)&&"".equals(endTime)){
				record = yunyingbbService.findOperateRecord(startTime,endTime,user.getName(),2);
			}else {
				record = yunyingbbService.findOperateRecord(startTime,endTime,user.getName(),3);
			}
			if(user.getAgent_type()==0) {
				record.setUser_type("会员");
			}else if(user.getAgent_type()==1){
				record.setUser_type("代理");
			}
			record.setName(user.getName());
			record.setBalance(user.getBalance());
			record.setMrfanshui(record.getMrfanshui());
			record.setName(user.getName());
			records.add(record);
		}else {
			for(User user : users) {
				if(DateUtil.findFormatDate().equals(startTime)&&DateUtil.findFormatDate().equals(endTime)) {
					record = yunyingbbService.findOperateRecord(DateUtil.findFormatDate(),endTime,user.getName(),1);
				}else if(DateUtil.findFormatDate().equals(startTime)||DateUtil.findFormatDate().equals(endTime)) {
					record = yunyingbbService.findOperateRecord(startTime,endTime,user.getName(),2);
				}else if("".equals(startTime)&&"".equals(endTime)){
					record = yunyingbbService.findOperateRecord(startTime,endTime,user.getName(),2);
				}else {
					record = yunyingbbService.findOperateRecord(startTime,endTime,user.getName(),3);
				}
				if(user.getAgent_type()==0) {
					record.setUser_type("会员");
				}else if(user.getAgent_type()==1){
					record.setUser_type("代理");
				}
				record.setName(user.getName());
				record.setBalance(user.getBalance());
				record.setMrfanshui(record.getMrfanshui());
				record.setName(user.getName());
				records.add(record);
			}
		}
		return new JsonResult("", records);
	}

	/**
	 * 
	 * ---- TODO：风险评估管理
	 * 
	 */

	/**
	 * 方法名：riskAssessmentPage 
	 * 描述：     风险评估管理页面                 
	 * 参数：    @return 
	 * @return: String
	 */
	@RequestMapping("/riskAssessmentPage")
	public String riskAssessmentPage() {
		return "htgl/xitongfengxianpinggu";
	}

	/**
	 *   方法名：findRiskAssess   
	 *   描述：    查询所有的会员登录情况                      
	 *   参数：    @return 
	 * @return: JsonResult
	 */
	@ResponseBody
	@RequestMapping("/findRiskAssess")
	public JsonResult findRiskAssess(String startTime,String endTime,String userName) {
		List<User> users = userService.findByTimeOrNameAllUsers(startTime,endTime,userName);
		for(User user : users) {
			if(user.getAgent_type()==0) {
				user.setNicheng("会员");
			}else if(user.getAgent_type()==1) {
				user.setNicheng("代理");
			}else if(user.getAgent_type()==2) {
				user.setNicheng("总代理");
			}
		}
		return new JsonResult("", users);
	} 

	/**
	 * 
	 * ---- TODO：用户概况管理
	 * 
	 */

	/**
	 * 方法名：userDataPage 
	 * 描述：     用户数据概况管理页面                 
	 * 参数：    @return 
	 * @return: String
	 */
	@RequestMapping("/userDataPage")
	public String userDataPage() {
		return "htgl/huiyuanshujugaikuang";
	}
	
	/**
	 *   方法名：findAllUesrInfo   
	 *   描述：     查询所有的用户                     
	 *   参数：    @return 
	 * @return: JsonResult
	 */
	@RequestMapping("/findAllUesrInfo")
	@ResponseBody
	public JsonResult findAllUesrInfo(String userName){
		List<User> users = new ArrayList<>();
		if(!"".equals(userName)) {
			User user = userService.checkUser(userName);
			if(user !=null) {
				users.add(user);
			}
		}else {
			users = userService.getAllUsers();
		}
		return new JsonResult("",users);
	}

	/**
	 *   方法名：userData   
	 *   描述：     查询会员的数据概况                     
	 *   参数：    @param huiyuanzh
	 *   参数：    @return 
	 * @return: JsonResult
	 */
	@ResponseBody
	@RequestMapping("/userData")
	public JsonResult userData(String user_name) {
		//查询所有相关的全局报表
		HYdataVo data = new HYdataVo();
		User user = userService.checkUser(user_name);
		if("".equals(user_name)||user==null) {
			return new JsonResult("", data);
		}
		TodayRecord record = yunyingbbService.findOperateRecord("","",user.getName(),2);
		User agent = agentService.findUserSuperior(user.getFid());
		String agentName = "-";
		if(agent!=null) {
			agentName = agent.getName();
		}
		//最后充值金额-最后充值时间-
		//最后提款金额-最后提款时间
		Damal damal = damalService.getOnedamal(user.getId());
		Jine jine4 = jineService.zhTkJineJl(user.getId());
		Jine jine3 = jineService.zhCzJineJl(user.getId());
		data.setName(user.getName());
		data.setSsdaili(agentName);
		data.setZctime(user.getRegisterTime());
		data.setYue(user.getBalance());
		data.setDqdamal(damal.getDamaliang());
		data.setCksxdamal(damal.getTikuansx());
		data.setZxcunkuanzj(record.getZxchongzhi());
		data.setSdjiakuanzj(record.getRgjiakuan());
		data.setZhchongzhije(jine3.getFukuanje());
		data.setZhchongzhisj("0".equals(jine3.getCltime())?"-":jine3.getCltime());
		data.setZxtikuanzj(record.getZxtikuan());
		data.setSdkoukuanzj(record.getRgkoukuan());
		data.setZhtikuanje(jine4.getTikuanje());
		data.setZhtikuansj("0".equals(jine4.getCltime())?"-":jine3.getCltime());
		data.setZczengsongzj(record.getZczengsong());
		data.setCkzengsongzj(record.getCzzengsong());
		data.setRcfanshuizj(record.getMrfanshui()+record.getMyfanshui()+record.getTmbfanshui());
		data.setDlfandianzj(record.getDlfandian());
		return new JsonResult("", data);
	}

}
