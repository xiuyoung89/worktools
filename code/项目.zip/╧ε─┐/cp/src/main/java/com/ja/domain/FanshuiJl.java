package com.ja.domain;

import java.io.Serializable;

public class FanshuiJl implements Serializable{
    /**
	 * 
	 */
	private static final long serialVersionUID = 270033314495815372L;

	private Integer id;//返水记录
    
    private String name;//返水记录

    private Double rifanshui;//日返水
    
    private Double yuefanshui;//月返水

    private Double richongzhi;//日充值
    
    private Double yuechongzhi;//月充值
    
    private String createtime;//创建时间
    
    private Integer state;//状态
    
    private Integer statu;//状态
    
    private int userid;//用户id
    
    public static long getSerialversionuid() {
		return serialVersionUID;
	}
    public Integer getId() {
        return id;
    }

    public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public void setId(Integer id) {
        this.id = id;
    }
	public Double getRifanshui() {
		return rifanshui;
	}

	public void setRifanshui(Double rifanshui) {
		this.rifanshui = rifanshui;
	}

	public Double getYuefanshui() {
		return yuefanshui;
	}

	public void setYuefanshui(Double yuefanshui) {
		this.yuefanshui = yuefanshui;
	}

	public Double getRichongzhi() {
		return richongzhi;
	}

	public void setRichongzhi(Double richongzhi) {
		this.richongzhi = richongzhi;
	}

	public Double getYuechongzhi() {
		return yuechongzhi;
	}

	public void setYuechongzhi(Double yuechongzhi) {
		this.yuechongzhi = yuechongzhi;
	}

	public String getCreatetime() {
		return createtime;
	}

	public void setCreatetime(String createtime) {
		this.createtime = createtime;
	}

	public Integer getStatu() {
		return statu;
	}

	public void setStatu(Integer statu) {
		this.statu = statu;
	}

	public int getUserid() {
		return userid;
	}

	public void setUserid(int userid) {
		this.userid = userid;
	}

	public Integer getState() {
		return state;
	}

	public void setState(Integer state) {
		this.state = state;
	}

	public FanshuiJl() {
		super();
	}

	@Override
	public String toString() {
		return "FanshuiJl [id=" + id + ", name=" + name + ", rifanshui=" + rifanshui + ", yuefanshui=" + yuefanshui
				+ ", richongzhi=" + richongzhi + ", yuechongzhi=" + yuechongzhi + ", createtime=" + createtime
				+ ", state=" + state + ", statu=" + statu + ", userid=" + userid + "]";
	}

}