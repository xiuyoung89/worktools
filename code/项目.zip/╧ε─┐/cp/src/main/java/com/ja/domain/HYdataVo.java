package com.ja.domain;

import java.io.Serializable;

public class HYdataVo implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1608870350666041934L;

	private Integer id;// 全局

	private String name; // 会员名称

	private String ssdaili;// 所属代理

	private String zctime;// 注册时间

	private Double yue;// 余额

	private Double dqdamal;// 当前打码量

	private Double cksxdamal;// 提款所需打码量

	private Double zxcunkuanzj;// 在线存款总计 1

	private Double sdjiakuanzj;// 手动加款总计 1

	private Double sdquerenje;// 手动确认金额

	private Double zhchongzhije;// 最后充值金额

	private String zhchongzhisj;// 最后充值时间

	private Double zxtikuanzj;// 在线提款总计 1

	private Double sdkoukuanzj;// 手动扣款总计 1

	private Double zhtikuanje;// 最后提款金额

	private String zhtikuansj;// 最后提款时间

	private Double ckzengsongzj;// 存款赠送总计 1

	private Double zczengsongzj;// 注册总送总计 1

	private Double hdzhongjiangzj;// 活动中奖总计 1

	private Double dlfandianzj;// 代理返点总计 1
	
	private Double rcfanshuizj;// 日常总计 1

	private Integer touzhuzrs;// 投注人数总计

	private Double caipiaoxzzj;// 彩票下注总计

	private Double caipiaopjzj;// 彩票派奖总计 1

	private Double xitongcxzzj;// 系统彩下注总计

	private Double xitongcpjzj;// 系统彩派奖总计
	
	private Double caipiaosy;// 彩票输赢总计

	private Double xitongcsy;// 系统彩票输赢总计
	
	private Double quanbusy;// 全局输赢总计
	
	private Double cpchedan;// 彩票撤单
	
	private Double hjtuihuan;// 彩票撤单
	
	private Double tmbfanshui;// 彩票撤单
	
	private Double xtcchedan; //系统彩撤单18
	
	private Double tkshouxufei; //提款手续费11
    
    public static long getSerialversionuid() {
		return serialVersionUID;
	}
	
	public Double getTkshouxufei() {
		return tkshouxufei;
	}

	public void setTkshouxufei(Double tkshouxufei) {
		this.tkshouxufei = tkshouxufei;
	}

	public Double getXtcchedan() {
		return xtcchedan;
	}

	public void setXtcchedan(Double xtcchedan) {
		this.xtcchedan = xtcchedan;
	}

	public Double getCpchedan() {
		return cpchedan;
	}

	public void setCpchedan(Double cpchedan) {
		this.cpchedan = cpchedan;
	}

	public Double getHjtuihuan() {
		return hjtuihuan;
	}

	public void setHjtuihuan(Double hjtuihuan) {
		this.hjtuihuan = hjtuihuan;
	}

	public Double getTmbfanshui() {
		return tmbfanshui;
	}

	public void setTmbfanshui(Double tmbfanshui) {
		this.tmbfanshui = tmbfanshui;
	}

	public Integer getId() {
		return id;
	}

	public Integer getTouzhuzrs() {
		return touzhuzrs;
	}

	public Double getRcfanshuizj() {
		return rcfanshuizj;
	}

	public void setRcfanshuizj(Double rcfanshuizj) {
		this.rcfanshuizj = rcfanshuizj;
	}

	public void setTouzhuzrs(Integer touzhuzrs) {
		this.touzhuzrs = touzhuzrs;
	}

	public Double getCaipiaoxzzj() {
		return caipiaoxzzj;
	}

	public void setCaipiaoxzzj(Double caipiaoxzzj) {
		this.caipiaoxzzj = caipiaoxzzj;
	}

	public Double getCaipiaopjzj() {
		return caipiaopjzj;
	}

	public void setCaipiaopjzj(Double caipiaopjzj) {
		this.caipiaopjzj = caipiaopjzj;
	}

	public Double getXitongcxzzj() {
		return xitongcxzzj;
	}

	public void setXitongcxzzj(Double xitongcxzzj) {
		this.xitongcxzzj = xitongcxzzj;
	}

	public Double getXitongcpjzj() {
		return xitongcpjzj;
	}

	public void setXitongcpjzj(Double xitongcpjzj) {
		this.xitongcpjzj = xitongcpjzj;
	}

	public Double getCaipiaosy() {
		return caipiaosy;
	}

	public void setCaipiaosy(Double caipiaosy) {
		this.caipiaosy = caipiaosy;
	}

	public Double getXitongcsy() {
		return xitongcsy;
	}

	public void setXitongcsy(Double xitongcsy) {
		this.xitongcsy = xitongcsy;
	}

	public Double getQuanbusy() {
		return quanbusy;
	}

	public void setQuanbusy(Double quanbusy) {
		this.quanbusy = quanbusy;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getSsdaili() {
		return ssdaili;
	}

	public void setSsdaili(String ssdaili) {
		this.ssdaili = ssdaili;
	}

	public String getZctime() {
		return zctime;
	}

	public void setZctime(String zctime) {
		this.zctime = zctime;
	}

	public Double getYue() {
		return yue;
	}

	public void setYue(Double yue) {
		this.yue = yue;
	}

	public Double getDqdamal() {
		return dqdamal;
	}

	public void setDqdamal(Double dqdamal) {
		this.dqdamal = dqdamal;
	}

	public Double getCksxdamal() {
		return cksxdamal;
	}

	public void setCksxdamal(Double cksxdamal) {
		this.cksxdamal = cksxdamal;
	}

	public Double getZxcunkuanzj() {
		return zxcunkuanzj;
	}

	public void setZxcunkuanzj(Double zxcunkuanzj) {
		this.zxcunkuanzj = zxcunkuanzj;
	}

	public Double getSdjiakuanzj() {
		return sdjiakuanzj;
	}

	public void setSdjiakuanzj(Double sdjiakuanzj) {
		this.sdjiakuanzj = sdjiakuanzj;
	}

	public Double getSdquerenje() {
		return sdquerenje;
	}

	public void setSdquerenje(Double sdquerenje) {
		this.sdquerenje = sdquerenje;
	}

	public Double getZhchongzhije() {
		return zhchongzhije;
	}

	public void setZhchongzhije(Double zhchongzhije) {
		this.zhchongzhije = zhchongzhije;
	}

	public String getZhchongzhisj() {
		return zhchongzhisj;
	}

	public void setZhchongzhisj(String zhchongzhisj) {
		this.zhchongzhisj = zhchongzhisj;
	}

	public Double getZxtikuanzj() {
		return zxtikuanzj;
	}

	public void setZxtikuanzj(Double zxtikuanzj) {
		this.zxtikuanzj = zxtikuanzj;
	}

	public Double getSdkoukuanzj() {
		return sdkoukuanzj;
	}

	public void setSdkoukuanzj(Double sdkoukuanzj) {
		this.sdkoukuanzj = sdkoukuanzj;
	}

	public Double getZhtikuanje() {
		return zhtikuanje;
	}

	public void setZhtikuanje(Double zhtikuanje) {
		this.zhtikuanje = zhtikuanje;
	}

	public String getZhtikuansj() {
		return zhtikuansj;
	}

	public void setZhtikuansj(String zhtikuansj) {
		this.zhtikuansj = zhtikuansj;
	}

	public Double getCkzengsongzj() {
		return ckzengsongzj;
	}

	public void setCkzengsongzj(Double ckzengsongzj) {
		this.ckzengsongzj = ckzengsongzj;
	}

	public Double getZczengsongzj() {
		return zczengsongzj;
	}

	public void setZczengsongzj(Double zczengsongzj) {
		this.zczengsongzj = zczengsongzj;
	}

	public Double getHdzhongjiangzj() {
		return hdzhongjiangzj;
	}

	public void setHdzhongjiangzj(Double hdzhongjiangzj) {
		this.hdzhongjiangzj = hdzhongjiangzj;
	}

	public Double getDlfandianzj() {
		return dlfandianzj;
	}

	public void setDlfandianzj(Double dlfandianzj) {
		this.dlfandianzj = dlfandianzj;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	@Override
	public String toString() {
		return "HYdataVo [id=" + id + ", name=" + name + ", ssdaili=" + ssdaili + ", zctime=" + zctime + ", yue=" + yue
				+ ", dqdamal=" + dqdamal + ", cksxdamal=" + cksxdamal + ", zxcunkuanzj=" + zxcunkuanzj
				+ ", sdjiakuanzj=" + sdjiakuanzj + ", sdquerenje=" + sdquerenje + ", zhchongzhije=" + zhchongzhije
				+ ", zhchongzhisj=" + zhchongzhisj + ", zxtikuanzj=" + zxtikuanzj + ", sdkoukuanzj=" + sdkoukuanzj
				+ ", zhtikuanje=" + zhtikuanje + ", zhtikuansj=" + zhtikuansj + ", ckzengsongzj=" + ckzengsongzj
				+ ", zczengsongzj=" + zczengsongzj + ", hdzhongjiangzj=" + hdzhongjiangzj + ", dlfandianzj="
				+ dlfandianzj + ", rcfanshuizj=" + rcfanshuizj + ", touzhuzrs=" + touzhuzrs + ", caipiaoxzzj="
				+ caipiaoxzzj + ", caipiaopjzj=" + caipiaopjzj + ", xitongcxzzj=" + xitongcxzzj + ", xitongcpjzj="
				+ xitongcpjzj + ", caipiaosy=" + caipiaosy + ", xitongcsy=" + xitongcsy + ", quanbusy=" + quanbusy
				+ ", cpchedan=" + cpchedan + ", hjtuihuan=" + hjtuihuan + ", tmbfanshui=" + tmbfanshui + ", xtcchedan="
				+ xtcchedan + ", tkshouxufei=" + tkshouxufei + "]";
	}

	public HYdataVo() {
		super();
	}

}