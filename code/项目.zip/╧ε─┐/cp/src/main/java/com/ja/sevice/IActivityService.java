package com.ja.sevice;

import java.util.List;

import com.ja.domain.Activity;
import com.ja.domain.ActivitySurvey;
import com.ja.domain.User;

/**
 * 
 * @author CY
 * @date 31.Mar.2018
 */
public interface IActivityService {
	
	/**
	 * 	在线充值-人工加款 充值赠送和绑定银行卡赠送彩金活动
	 * @param user 用户信息
	 * @param orderNum 充值订单号
	 * @param money 充值金额
	 * @param rechargeType 充值类型
	 */
	int Recharge(User user, String orderNum, double money, String rechargeType);
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	/**
	 * 查询所有开启的活动
	 * @return
	 */
	List<Activity> findEnableActivity();
	
	/**
	 * 查询全部活动
	 */
	List<Activity> findAllActivity();
	
	/**
	 * 根据id查询活动详情
	 * @param id 活动id
	 * @return
	 */
	Activity findOneActivity(Integer id);
	
	/**
	 * 根据条件找出活动
	 * @param type 活动类型
	 * @return
	 */
	List<Activity> findActivityByType(int type);
	
	/**
	 * 添加活动名称
	 * @param name 活动名称
	 * @param date 操作时间
	 * @return
	 */
	Integer addtianjiahuodong(String name);
	
	/**
	 * 添加活动信息
	 * @param activity 活动对象
	 * @return
	 */
	Integer insertActivity(Activity activity);
	
	/**
	 * 修改活动内容
	 * @param activity 活动对象
	 * @return
	 */
	Integer updateActivity(Activity activity);
	
	/**
	 * 修改弹窗内容
	 * @param activity 活动对象
	 * @return
	 */
	Integer updateAlter(Activity activity);

	/**
	 * 删除活动
	 * @param id
	 * @return
	 */
	int deletehd(Integer id);

	/**
	 * 对活动进行排序
	 * @param sort 排序号
	 * @param id 活动id
	 * @return
	 */
	int sortActivity(Integer sort, Integer id);
	
	/**
	 * 添加用户活动参加情况
	 * @param survey 参加信息
	 * @return
	 */
	int addActivitySurvey(ActivitySurvey survey);

	/**
	 * 查询是否已参加活动 
	 * @param userid 用户id
	 * @param id 活动id
	 * @return
	 */
	ActivitySurvey getOneSurvey(Integer userid, Integer id);


}
