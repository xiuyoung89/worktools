package com.ja.controller;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.ja.domain.AdminUser;
import com.ja.domain.PagingData;
import com.ja.domain.SetupAgent;
import com.ja.sevice.AgentService;
import com.ja.sevice.OperationlogService;
import com.ja.util.JsonResult;
@RequestMapping("/agents")
@Controller
public class Ht_AgentController {
	
	@Autowired
	private AgentService agentService;
	
	@Autowired
	private OperationlogService operationlogService;

	
	/**
	 * 
	 * ---- TODO：平台代理管理
	 * 
	 */
	
	/**
	 * 方法名：agentPage 
	 * 描述：   平台代理管理页面                     
	 * 参数：    @return 
	 * @return: String
	 */
	@RequestMapping("agentPage")
	public String agentPage() {
		return "htgl/dailiguanli";
	}
	
	/**
	 * 方法名：gradeDetail 
	 * 描述：    代理下级页面                   
	 * 参数：    @return 
	 * @return: String
	 */
	@RequestMapping("gradeDetail")
	public String gradeDetail() {
		return "htgl/dailixiaji";
	}
	
	/**
	 * 方法名：agentDetail 
	 * 描述：     下级详情页面                  
	 * 参数：    @return 
	 * @return: String
	 */
	@RequestMapping("agentDetail")
	public String agentDetail() {
		return "htgl/dailixiangqing";
	}
	
	/**
	 * 方法名：findAllAgents 
	 * 描述：     根据条件查询平台的代理用户                  
	 * 参数：    @param paging 分页信息
	 * 参数：    @param name 代理名称
	 * 参数：    @return 
	 * @return: String
	 */
	@ResponseBody
	@RequestMapping("/findAllAgents")
	public String findAllAgents(PagingData paging,String name) {
		paging.setReplace1(name);
		paging.setAllCount(agentService.findAllAgentsCounts());
		paging.setList(agentService.findAllAgents(paging));
		return PagingData.pagingData(paging);
	}
	
	/**
	 * 方法名：findAgentTotal 
	 * 描述：    根据条件查询代理下级的返点总计                   
	 * 参数：    @param paging 分页信息
	 * 参数：    @param id 上级id
	 * 参数：    @return 
	 * @return: String
	 */
	@RequestMapping("/findAgentTotal")
	@ResponseBody
	public String findAgentTotal(PagingData paging,Integer id){
		paging.setReplace3(id);
		paging.setAllCount(agentService.findAgentTotalCounts(id));
		paging.setList(agentService.findAgentTotals(paging));
		return PagingData.pagingData(paging);
	}
	
	/**
	 * 方法名：findAgentDetails 
	 * 描述：    查询代理下级的操作详情                   
	 * 参数：    @param paging 分页信息
	 * 参数：    @param user_id 下级用户id
	 * 参数：    @param type 详情类型
	 * 参数：    @return 
	 * @return: String
	 */
	@RequestMapping("/findAgentDetails")
	@ResponseBody
	public String findAgentDetails(PagingData paging,Integer user_id,String type){
		paging.setReplace1(type);
		paging.setReplace3(user_id);
		paging.setAllCount(agentService.findAgentDetailsCounts(user_id,type));
		paging.setList(agentService.findAgentDetails(paging));
		return PagingData.pagingData(paging);
	}
	
	
	/**
	 * 
	 * ---- TODO：代理返点记录
	 * 
	 */

	/**
	 * 方法名：agentRebatePage 
	 * 描述：    代理返点记录页面                   
	 * 参数：    @param model
	 * 参数：    @return 
	 * @return: ModelAndView
	 */
	@RequestMapping("/agentRecordPage")
	public ModelAndView agentRebatePage(ModelAndView model){
		model.setViewName("htgl/dlfdjl");
		return model;
	}
	
	/**
	 * 根据条件查询代理返点记录
	 * @param startIndex 起始数
	 * @param lineCount 行数
	 * @param startDate 开始时间
	 * @param endDate 结束时间
	 * @param cname 代理名称
	 * @param model 查询下类型
	 * @return
	 */
	@RequestMapping("/findAgentRecord")
	@ResponseBody
	public String findAgentRecord(PagingData paging,String startDate,String endDate,String userName,String agentName){
		String jsonResult = agentService.findAgentRecord(paging,startDate,endDate,userName,agentName);
		return jsonResult;
	}
	
	/**
	 * 
	 * ---- TODO：代理返点管理
	 * 
	 */
	
	
	/**
	 * 方法名：setupAgentPage 
	 * 描述：    代理返点管理页面                   
	 * 参数：    @param model
	 * 参数：    @return 
	 * @return: ModelAndView
	 */
	@RequestMapping("/setupAgentPage")
	public ModelAndView setupAgentPage(ModelAndView model){
		model.setViewName("htgl/dlfdlxg");
		return model;
	}
	
	/**
	 * 方法名：findAgentSetup 
	 * 描述：     查询代理返点设置                  
	 * 参数：    @return 
	 * @return: JsonResult
	 */
	@RequestMapping("/findAgentSetup")
	@ResponseBody 
	public JsonResult findAgentSetup(){
		return new JsonResult(null,agentService.findAgentSetup()); 
	}

	/**
	 * 方法名：insertAgentSetup 
	 * 描述：    添加返点设置                   
	 * 参数：    @param session
	 * 参数：    @param setupAgent 返点配置信息
	 * 参数：    @return 
	 * @return: JsonResult
	 */
	@RequestMapping("/insertAgentSetup")
	@ResponseBody
	public JsonResult insertAgentSetup(HttpSession session,SetupAgent setupAgent){
		AdminUser admin1 = (AdminUser)session.getAttribute("admin1");
		String rebate_type = "充值返点";
		if(setupAgent.getRebate_type()==2) {
			rebate_type = "打码返点";
		}
		String remarks = "添加了"+rebate_type+"代理等级："+setupAgent.getAgent_grade()+"级的返点率为："+setupAgent.getRebate_ratio();
		operationlogService.addOperationlog(admin1, remarks, "代理返点管理");
		setupAgent.setOperator_name(admin1.getName()); 
		return new JsonResult("success",agentService.insertAgentSetup(setupAgent));
	}
	
	/**
	 * 方法名：updateAgentSetup 
	 * 描述：     修改返点设置                  
	 * 参数：    @param session
	 * 参数：    @param setupAgent 返点配置信息
	 * 参数：    @return 
	 * @return: JsonResult
	 */
	@RequestMapping("/updateAgentSetup")
	@ResponseBody 
	public JsonResult updateAgentSetup(HttpSession session,SetupAgent setupAgent){ 
		String remarks = "";
		AdminUser admin1 = (AdminUser)session.getAttribute("admin1");
		SetupAgent agent = agentService.findByIdAgentSetup(setupAgent.getId());
		String rebate_type = "充值返点";
		if(agent.getRebate_type()==2) {
			rebate_type = "打码返点";
		}
		if(null!=setupAgent.getState()) {
			remarks = "启用了"+rebate_type+"代理等级："+agent.getAgent_grade()+"级的返点设置!";
			if(setupAgent.getState()==0) {
				remarks = "禁用了"+rebate_type+"代理等级："+agent.getAgent_grade()+"级的返点设置!";
			}
		}else {
			remarks = "修改了"+rebate_type+"代理等级："+agent.getAgent_grade()+"级的返点率为："+setupAgent.getRebate_ratio()+"！";
		}
		operationlogService.addOperationlog(admin1, remarks, "代理返点管理");
		setupAgent.setOperator_name(admin1.getName());
		return new JsonResult("success",agentService.updateAgentSetup(setupAgent));
	}
	
	/**
	 * 方法名：deleteAgentSetup 
	 * 描述：    删除代理返点设置                    
	 * 参数：    @param session
	 * 参数：    @param id
	 * 参数：    @return 
	 * @return: JsonResult
	 */
	@RequestMapping("/deleteAgentSetup")
	@ResponseBody
	public JsonResult deleteAgentSetup(HttpSession session,Integer id){
		SetupAgent agent = agentService.findByIdAgentSetup(id);
		String rebate_type = "充值返点";
		if(agent.getRebate_type()==2) {
			rebate_type = "打码返点";
		}
		String remarks = "删除了"+rebate_type+"一条代理等级"+agent.getAgent_grade()+"的返点设置！";
		operationlogService.addOperationlog((AdminUser)session.getAttribute("admin1"), remarks, "代理返点管理");
		return new JsonResult("success",agentService.deleteAgentSetup(id));
	}
	
	/**
	 * 
	 * ---- TODO：代理说明管理
	 * 
	 */
	
	/**
	 * 方法名：agentRule 
	 * 描述：    代理说明管理页面                   
	 * 参数：    @return 
	 * @return: String
	 */
	@RequestMapping("/dailiRulePage")
	public String agentRule() {
		return "htgl/dailishuomin";
	}
	
	/**
	 * 修改代理规则说明
	 * @param rule 规则说明
	 * @return
	 */
	@ResponseBody
	@RequestMapping("/updateDailiRule")
	public JsonResult updateDailiRule(HttpSession session,String rule,String rules) {
		String remarks = "";
		if(null!=rule) {
			remarks = "修改了用户代理中心代理规则说明!";
			operationlogService.addOperationlog((AdminUser)session.getAttribute("admin1"), remarks, "代理说明管理");
		}
		if(null!=rules) {
			remarks = "修改了用户返水中心返水规则说明!";
			operationlogService.addOperationlog((AdminUser)session.getAttribute("admin1"), remarks, "代理说明管理");
		}
		return new JsonResult("success",agentService.updateDailiRule(rule,rules)); 
	}
	
	
	
	
	
	
}
