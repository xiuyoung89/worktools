package com.ja.dao;

import org.apache.ibatis.annotations.Param;

import com.ja.domain.PlayCount;

/**
 * @AUTH LBQ
 * @DATE 2017年11月10日 上午9:33:00
 * @DESC 
 */
public interface PlayCountMapper {

	/**查询当前这一期有没有下注*/
	PlayCount getCplay(@Param("p") PlayCount p);
	
	/**添加下注人数以及金额*/
	int addPlayCount(@Param("p") PlayCount cplay);

	/**修改这一期玩法的下注次数*/
	int updatePlayCount(@Param("p") PlayCount p);
	
	/**统计这期玩法下注多少*/
	int getCplayCount(String period, String cname);

	
}


