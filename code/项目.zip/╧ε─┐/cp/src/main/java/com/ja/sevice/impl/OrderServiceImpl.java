package com.ja.sevice.impl;

import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.ja.config.WebsiteStateConfig;
import com.ja.dao.AgentMapper;
import com.ja.dao.DamaMapper;
import com.ja.dao.DamalMapper;
import com.ja.dao.DataMapper;
import com.ja.dao.GcRebateMapper;
import com.ja.dao.LiushuiMapper;
import com.ja.dao.LotteryMapper;
import com.ja.dao.LuckyCountMapper;
import com.ja.dao.OperationlogMapper;
import com.ja.dao.OrderMapper;
import com.ja.dao.PlayCountMapper;
import com.ja.dao.UserMapper;
import com.ja.domain.AdminUser;
import com.ja.domain.AgentTotal;
import com.ja.domain.AgentRecord;
import com.ja.domain.Dama;
import com.ja.domain.Damal;
import com.ja.domain.Data;
import com.ja.domain.GcRebate;
import com.ja.domain.Liushui;
import com.ja.domain.Lotter;
import com.ja.domain.LotterExample;
import com.ja.domain.LuckyCount;
import com.ja.domain.Operationlog;
import com.ja.domain.Order;
import com.ja.domain.Orders;
import com.ja.domain.PlayCount;
import com.ja.domain.SetupAgent;
import com.ja.domain.TodayRecord;
import com.ja.domain.User;
import com.ja.sevice.IOrderService;
import com.ja.sevice.YunyingbbService;
import com.ja.util.DateUtil;
import com.ja.util.ExChangeUtil;
import com.ja.util.JsonResult;
import com.ja.util.WebSocketJson;

@Service
public class OrderServiceImpl implements IOrderService {

	@Autowired
	private OrderMapper orderMapper;

	@Autowired
	private DataMapper dataMapper;

	@Autowired
	private PlayCountMapper playCountMapper;

	@Autowired
	private LotteryMapper lotterMapper;

	@Autowired
	private LiushuiMapper liushuiMapper;

	@Autowired
	private UserMapper userMapper;

	@Autowired
	private DamalMapper damalMapper;

	@Autowired
	private DamaMapper damaMapper;

	@Autowired
	private GcRebateMapper gcRebateMapper;

	@Autowired
	private LuckyCountMapper luckyCountMapper;

	@Autowired
	private AgentMapper agentMapper;
	
	@Autowired
	private OperationlogMapper operationlogMapper;
	
	@Autowired
	private YunyingbbService yunyingbbService;
	
	/**
	 * 	计算打码
	 * @param user   用户信息
	 * @param cname  彩种英文名
	 * @param period 彩种期号
	 * @param cname1  彩种中文名
	 * @param state  true 收入 false 支出
	 * @param money  变动金额
	 * @param type   1投注 2派奖 3撤单 4特码B反水 5和局退还本金
	 * @param model  变动类型
	 * @return
	 */
	public int codeRecord(User user, String cname, String period, String cname1, boolean state, double money, int type,
			String model) {
				Lotter lotter = lotterMapper.findLotterByCname(cname);
				Damal damal = damalMapper.getOnedamal(user.getId());
				if (lotter.getWhetherOrNotToCode() == 1 && damal.getState() == 1) {
					double counts = 0.00;
					double count = damal.getDamaliang();
					double need = damal.getTikuansx();
					if (state) {
						counts = count + money;
					} else {
						counts = count - money;
					}
					Dama da = new Dama();
					da.setHuiyuanzh(user.getName());
					da.setBdtype(model);
					da.setBdqcount(count);
					da.setBdcount(money);
					da.setBdhcount(counts);
					da.setCreatetime(DateUtil.getCurrTime());
					da.setBdqtksx(need);
					da.setBdtksx(need);
					da.setBdhtksx(need);
					da.setCzname("系统自动");
					da.setBeizhu(cname1);
					da.setUserid(user.getId());
					damal.setDamaliang(counts);
					damal.setNew_damaliang(counts);
					damal.setCreatetime(DateUtil.getCurrTime());
					damaMapper.addDama(da);
					damalMapper.updateDamal(damal);
				}
		return 1;
	}

	/**
	  *   彩票 投注 派奖 撤单 -流水记录变动记录
	 * @param user   用户信息
	 * @param state  true 收入 false 支出
	 * @param cname1 彩种中文名
	 * @param period 彩种期号
	 * @param money  变动金额
	 * @param model  变动类型
	 * @return
	 */
	public int flowChange(User user, boolean state, String cname1, String period, double money, String model,String orderNum) {
		double amount = 0.00;
		user = userMapper.getUserByid(user.getId());
		if (state) {
			amount = user.getBalance() + money;
		} else {
			amount = user.getBalance() - money;
		}
		Liushui flow = new Liushui();
		flow.setHuiyuanzh(user.getName());
		flow.setBdtype(model);
		flow.setBdqjine(user.getBalance());
		flow.setBdjine(money);
		flow.setBdhjine(amount);
		flow.setCreatetime(DateUtil.getCurrTime());
		flow.setOrdernum(orderNum);
		flow.setCname(cname1);
		flow.setPeriod(period);
		flow.setCzname("系统自动");
		flow.setBeizhu(model);
		flow.setState(state);
		flow.setUser_type(user.getState());
		flow.setUserid(user.getId());
		user.setBalance(amount);
		user.setCreatetime(DateUtil.getCurrTime());
		liushuiMapper.addUserFlowingWaterRecrod(flow);
		userMapper.updateUserInfo(user);
		return 1;
	}
	
	@Transactional
	@Override
	public JsonResult awards(Order order, User user) {
		List<Lotter> lotterState = WebsiteStateConfig.lotteryState;
		for (Lotter state : lotterState) {
			if (order.getCname().equals(state.getCname())) {
				if (state.getState() == 0) {
					return new JsonResult("当前彩种已关闭，无法进行下单!", 10);
				}
			}
		}
		Data data = dataMapper.findNextPeriod(order.getCname());// 下注期号
		Long period1 = Long.parseLong(order.getPeriod().trim());// 下期期号
		Long period2 = Long.parseLong(data.getNextperiod().trim());
		if (period1 < period2) {
			return new JsonResult("本期已开奖，无法进行下单!", 10);
		}
		SimpleDateFormat sf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		long currents = 0;
		try {
			currents = (sf.parse(data.getNextStopOrderTimeEpoch()).getTime()-new Date().getTime())/1000;
			System.err.println("当前彩种： "+order.getCname1()+"第"+order.getPeriod()+"期,距下期还有："+currents+"秒,当前系统时间："+DateUtil.getCurrTime());
		} catch (ParseException e) {
			e.printStackTrace();
		}
		if(currents<30) {
			return new JsonResult("已封盘，无法进行下单!", 10); 
		}
		String cname = order.getCname();
		List<Integer> counts = new ArrayList<Integer>();
	
	switch (cname) {
	case "bjpk10":
	case "2fpk10":
	case "xyft":
	case "2fft":
	case "xysm":
		/** 下注号码 */
		String gyhz[] = order.getStr1().split(",");
		String gj[] = order.getStr2().split(",");
		String yj[] = order.getStr3().split(",");
		String d3m[] = order.getStr4().split(",");
		String d4m[] = order.getStr5().split(",");
		String d5m[] = order.getStr6().split(",");
		String d6m[] = order.getStr7().split(",");
		String d7m[] = order.getStr8().split(",");
		String d8m[] = order.getStr9().split(",");
		String d9m[] = order.getStr10().split(",");
		String d10m[] = order.getStr11().split(",");
		// 冠亚和值
		if (gyhz.length != 0 && !"".equals(gyhz[0])) {
			counts.add(gyhz.length);
			order.setCount1(gyhz.length);
			order.setCplay1("冠亚和值");
			
			if (cname.equals("2fpk10") || cname.equals("xysm")||"2fft".equals(cname)) {
				playCounts(order, "gyhz",user);
			}
		}
		// 冠军
		if (gj.length != 0 && !"".equals(gj[0])) {
			counts.add(gj.length);
			order.setCount2(gj.length);
			order.setCplay2("冠军");
			
			if (cname.equals("2fpk10") || cname.equals("xysm")||"2fft".equals(cname)) {
				playCounts(order, "gj",user);
			}
		}
		// 亚军
		if (yj.length != 0 && !"".equals(yj[0])) {
			counts.add(yj.length);
			order.setCount3(yj.length);
			order.setCplay3("亚军");
			
			if (cname.equals("2fpk10") || cname.equals("xysm")||"2fft".equals(cname)) {
				playCounts(order, "yj",user);
			}

		}
		// 第3名
		if (d3m.length != 0 && !"".equals(d3m[0])) {
			counts.add(d3m.length);
			order.setCount4(d3m.length);
			order.setCplay4("第3名");
			
			if (cname.equals("2fpk10") || cname.equals("xysm")||"2fft".equals(cname)) {
				playCounts(order, "d3m",user);
			}

		}
		// 第4名
		if (d4m.length != 0 && !"".equals(d4m[0])) {
			counts.add(d4m.length);
			order.setCount5(d4m.length);
			order.setCplay5("第4名");
			
			if (cname.equals("2fpk10") || cname.equals("xysm")||"2fft".equals(cname)) {
				playCounts(order, "d4m",user);
			}

		}
		// 第5名
		if (d5m.length != 0 && !"".equals(d5m[0])) {
			counts.add(d5m.length);
			order.setCount6(d5m.length);
			order.setCplay6("第5名");
			
			if (cname.equals("2fpk10") || cname.equals("xysm")||"2fft".equals(cname)) {
				playCounts(order, "d5m",user);
			}

		}
		// 第6名
		if (d6m.length != 0 && !"".equals(d6m[0])) {
			counts.add(d6m.length);
			order.setCount7(d6m.length);
			order.setCplay7("第6名");
			
			if (cname.equals("2fpk10") || cname.equals("xysm")||"2fft".equals(cname)) {
				playCounts(order, "d6m",user);
			}

		}
		// 第7名
		if (d7m.length != 0 && !"".equals(d7m[0])) {
			counts.add(d7m.length);
			order.setCount8(d7m.length);
			order.setCplay8("第7名");
			
			if (cname.equals("2fpk10") || cname.equals("xysm")||"2fft".equals(cname)) {
				playCounts(order, "d7m",user);
			}

		}
		// 第8名
		if (d8m.length != 0 && !"".equals(d8m[0])) {
			counts.add(d8m.length);
			order.setCount9(d8m.length);
			order.setCplay9("第8名");
			
			if (cname.equals("2fpk10") || cname.equals("xysm")||"2fft".equals(cname)) {
				playCounts(order, "d8m",user);
			}

		}
		// 第9名
		if (d9m.length != 0 && !"".equals(d9m[0])) {
			counts.add(d9m.length);
			order.setCount10(d9m.length);
			order.setCplay10("第9名");
			
			if (cname.equals("2fpk10") || cname.equals("xysm")||"2fft".equals(cname)) {
				playCounts(order, "d9m",user);
			}

		}
		// 第10名
		if (d10m.length != 0 && !"".equals(d10m[0])) {
			counts.add(d10m.length);
			order.setCount11(d10m.length);
			order.setCplay11("第10名");
			
			if (cname.equals("2fpk10") || cname.equals("xysm")||"2fft".equals(cname)) {
				playCounts(order, "d10m",user);
			}
		}
		break;

	case "cqssc":
	case "2fssc":
	case "tjssc":
	case "xjssc":
		/** 下注号码 */
		String[] zh = order.getStr1().split(",");
		String[] d1q = order.getStr2().split(",");
		String[] d2q = order.getStr3().split(",");
		String[] d3q = order.getStr4().split(",");
		String[] d4q = order.getStr5().split(",");
		String[] d5q = order.getStr6().split(",");
		String[] q3 = order.getStr7().split(",");
		String[] z3 = order.getStr8().split(",");
		String[] h3 = order.getStr9().split(",");
		String[] q2zhx0 = order.getStr10().split(",");
		String[] q2zhx1 = order.getStr11().split(",");
		String[] h2zhx0 = order.getStr12().split(",");
		String[] h2zhx1 = order.getStr13().split(",");
		String[] q3zhxx0 = order.getStr14().split(",");
		String[] q3zhxx1 = order.getStr15().split(",");
		String[] q3zhxx2 = order.getStr16().split(",");
		String[] z3zhx0 = order.getStr17().split(",");
		String[] z3zhx1 = order.getStr18().split(",");
		String[] z3zhx2 = order.getStr19().split(",");
		String[] h3zhx0 = order.getStr20().split(",");
		String[] h3zhx1 = order.getStr21().split(",");
		String[] h3zhx2 = order.getStr22().split(",");
		String[] q2zxx = order.getStr23().split(",");
		String[] h2zxx = order.getStr24().split(",");
		String[] q3z6 = order.getStr25().split(",");
		String[] z3z6 = order.getStr26().split(",");
		String[] h3z6 = order.getStr27().split(",");
		String[] q3z3 = order.getStr28().split(",");
		String[] z3z3 = order.getStr29().split(",");
		String[] h3z3 = order.getStr30().split(",");

		// 总和
		if (zh.length != 0 && !"".equals(zh[0])) {
			counts.add(zh.length);
			order.setCount1(zh.length);
			order.setCplay1("总和");
			
			if (order.getCname().equals("2fssc")) {
				playCounts(order, "zh",user);
			}
		}
		// 第一球
		if (d1q.length != 0 && !"".equals(d1q[0])) {
			counts.add(d1q.length);
			order.setCount2(d1q.length);
			order.setCplay2("第一球");
			
			if (cname.equals("2fssc")) {
				playCounts(order, "d1q",user);
			}
		}
		// 第二球
		if (d2q.length != 0 && !"".equals(d2q[0])) {
			counts.add(d2q.length);
			order.setCount3(d2q.length);
			order.setCplay3("第二球");
			
			if (cname.equals("2fssc")) {
				playCounts(order, "d2q",user);
			}
		}
		// 第三球
		if (d3q.length != 0 && !"".equals(d3q[0])) {
			counts.add(d3q.length);
			order.setCount4(d3q.length);
			order.setCplay4("第三球");
			
			if (cname.equals("2fssc")) {
				playCounts(order, "d3q",user);
			}
		}
		// 第四球
		if (d4q.length != 0 && !"".equals(d4q[0])) {
			counts.add(d4q.length);
			order.setCount5(d4q.length);
			order.setCplay5("第四球");
			
			if (cname.equals("2fssc")) {
				playCounts(order, "d4q",user);
			}
		}
		// 第五球
		if (d5q.length != 0 && !"".equals(d5q[0])) {
			counts.add(d5q.length);
			order.setCount6(d5q.length);
			order.setCplay6("第五球");
			
			if (cname.equals("2fssc")) {
				playCounts(order, "d5q",user);
			}
		}
		// 前三
		if (q3.length != 0 && !"".equals(q3[0])) {
			counts.add(q3.length);
			order.setCplay7("前三");
			order.setCount7(q3.length);
			
			if (cname.equals("2fssc")) {
				playCounts(order, "q3",user);
			}
		}
		// 中三
		if (z3.length != 0 && !"".equals(z3[0])) {
			counts.add(z3.length);
			order.setCount8(z3.length);
			order.setCplay8("中三");
			
			if (cname.equals("2fssc")) {
				playCounts(order, "z3",user);
			}
		}
		// 后三
		if (h3.length != 0 && !"".equals(h3[0])) {
			counts.add(h3.length);
			order.setCount9(h3.length);
			order.setCplay9("后三");
			
			if (cname.equals("2fssc")) {
				playCounts(order, "h3",user);
			}
		}
		// 前二直选
		if (q2zhx0.length != 0 && !"".equals(q2zhx0[0]) && q2zhx1.length != 0 && !"".equals(q2zhx1[0])) {
			counts.add(q2zhx0.length * q2zhx1.length);
			order.setCount10(q2zhx0.length * q2zhx1.length);
			order.setCplay10("前二直选前位");
			order.setCplay11("前二直选后位");
			
			if (cname.equals("2fssc")) {
				playCounts(order, "q2zhix0",user);
				playCounts(order, "q2zhix1",user);
			}
		}
		// 后二直选
		if (h2zhx0.length != 0 && !"".equals(h2zhx0[0]) && h2zhx1.length != 0 && !"".equals(h2zhx1[0])) {
			counts.add(h2zhx0.length * h2zhx1.length);
			order.setCount11(h2zhx0.length * h2zhx1.length);
			order.setCplay12("后二直选前位");
			order.setCplay13("后二直选后位");
			
			if (cname.equals("2fssc")) {
				playCounts(order, "h2zhix0",user);
				playCounts(order, "h2zhix1",user);
			}
		}
		// 前三直选
		if (q3zhxx0.length != 0 && !"".equals(q3zhxx0[0]) && q3zhxx1.length != 0 && !"".equals(q3zhxx1[0])
				&& q3zhxx2.length != 0 && !"".equals(q3zhxx2[0])) {
			counts.add(q3zhxx0.length * q3zhxx1.length * q3zhxx2.length);
			order.setCount12(q3zhxx0.length * q3zhxx1.length * q3zhxx2.length);
			order.setCplay14("前三直选前位");
			order.setCplay15("前三直选中位");
			order.setCplay16("前三直选后位");
			
			if (cname.equals("2fssc")) {
				playCounts(order, "q3zhix0",user);
				playCounts(order, "q3zhix1",user);
				playCounts(order, "q3zhix2",user);
			}
		}
		// 中三直选
		if (z3zhx0.length != 0 && !"".equals(z3zhx0[0]) && z3zhx1.length != 0 && !"".equals(z3zhx1[0])
				&& z3zhx2.length != 0 && !"".equals(z3zhx2[0])) {
			counts.add( z3zhx0.length * z3zhx1.length * z3zhx2.length);
			order.setCount13( z3zhx0.length * z3zhx1.length * z3zhx2.length);
			order.setCplay17("中三直选前位");
			order.setCplay18("中三直选中位");
			order.setCplay19("中三直选后位");
			
			if (cname.equals("2fssc")) {
				playCounts(order, "z3zhix0",user);
				playCounts(order, "z3zhix1",user);
				playCounts(order, "z3zhix2",user);
			}
		}
		// 后三直选
		if (h3zhx0.length != 0 && !"".equals(h3zhx0[0]) && h3zhx1.length != 0 && !"".equals(h3zhx1[0])
				&& h3zhx2.length != 0 && !"".equals(h3zhx2[0])) {
			counts.add(h3zhx0.length * h3zhx1.length * h3zhx2.length);
			order.setCount14(h3zhx0.length * h3zhx1.length * h3zhx2.length);
			order.setCplay20("后三直选前位");
			order.setCplay21("后三直选中位");
			order.setCplay22("后三直选后位");
			
			if (cname.equals("2fssc")) {
				playCounts(order, "h3zhix0",user);
				playCounts(order, "h3zhix1",user);
				playCounts(order, "h3zhix2",user);
			}
		}
		// 前二组选
		if (q2zxx.length != 0 && !"".equals(q2zxx[0])) {
			counts.add(q2zxx.length * (q2zxx.length - 1) / 2);
			order.setCount15(q2zxx.length * (q2zxx.length - 1) / 2);
			order.setCplay23("前二组选");
			
			if (cname.equals("2fssc")) {
				playCounts(order, "q2zx",user);
			}
		}
		// 后二组选
		if (h2zxx.length != 0 && !"".equals(h2zxx[0])) {
			counts.add(h2zxx.length * (h2zxx.length - 1) / 2);
			order.setCount16(h2zxx.length * (h2zxx.length - 1) / 2);
			order.setCplay24("后二组选");
			
			if (cname.equals("2fssc")) {
				playCounts(order, "h2zx",user);
			}
		}
		// 前三组六(三星组六)
		if (q3z6.length != 0 && !"".equals(q3z6[0])) {
			counts.add(q3z6.length * (q3z6.length - 1) * (q3z6.length - 2) / 6);
			order.setCount17(q3z6.length * (q3z6.length - 1) * (q3z6.length - 2) / 6);
			order.setCplay25("前三组六");
			
			if (cname.equals("2fssc")) {
				playCounts(order, "q3z6",user);
			}
		}
		// 中三组六
		if (z3z6.length != 0 && !"".equals(z3z6[0])) {
			counts.add(z3z6.length * (z3z6.length - 1) * (z3z6.length - 2) / 6);
			order.setCount18(z3z6.length * (z3z6.length - 1) * (z3z6.length - 2) / 6);
			order.setCplay26("中三组六");
			
			if (cname.equals("2fssc")) {
				playCounts(order, "z3z6",user);
			}
		}
		// 后三组六
		if (h3z6.length != 0 && !"".equals(h3z6[0])) {
			counts.add(h3z6.length * (h3z6.length - 1) * (h3z6.length - 2) / 6);
			order.setCount19(h3z6.length * (h3z6.length - 1) * (h3z6.length - 2) / 6);
			order.setCplay27("后三组六");
			
			if (cname.equals("2fssc")) {
				playCounts(order, "h3z6",user);
			}
		}
		// 前三组三
		if (q3z3.length != 0 && !"".equals(q3z3[0])) {
			counts.add(q3z3.length * (q3z3.length - 1));
			order.setCount20(q3z3.length * (q3z3.length - 1));
			order.setCplay28("前三组三");
			
			if (cname.equals("2fssc")) {
				playCounts(order, "q3z3",user);
			}
		}
		// 中三组三
		if (z3z3.length != 0 && !"".equals(z3z3[0])) {
			counts.add(z3z3.length * (z3z3.length - 1));
			order.setCount21(z3z3.length * (z3z3.length - 1));
			order.setCplay29("中三组三");
			
			if (cname.equals("2fssc")) {
				playCounts(order, "z3z3",user);
			}
		}
		// 后三组三
		if (h3z3.length > 2 && !"".equals(h3z3[0])) {
			counts.add(h3z3.length * (h3z3.length - 1));
			order.setCount22(h3z3.length * (h3z3.length - 1));
			order.setCplay30("后三组三");
			
			if (cname.equals("2fssc")) {
				playCounts(order, "h3z3",user);
			}
		}
		break;

	case "ahk3":
	case "gxk3":
	case "jsk3":
	case "bjk3":
	case "jlk3":
	case "2fk3":
	case "3fk3":
		String[] c1gh = order.getStr1().split(",");
		String[] slhtx = order.getStr2().split(",");
		String[] ethfx = order.getStr3().split(",");
		String[] ethdx0 = order.getStr4().split(",");
		String[] ethdx1 = order.getStr5().split(",");
		String[] ebth = order.getStr6().split(",");
		String[] ebthdt0 = order.getStr7().split(",");
		String[] ebthdt1 = order.getStr8().split(",");
		String[] sthtx = order.getStr9().split(",");
		String[] sthdx = order.getStr10().split(",");
		String[] sbth = order.getStr11().split(",");
		String[] xt = order.getStr12().split(",");
		String[] zh6 = order.getStr13().split(",");
		// 猜一个号
		if (c1gh.length != 0 && !"".equals(c1gh[0])) {
			counts.add(c1gh.length * 21);
			order.setCount1(c1gh.length * 21);
			order.setCplay1("猜一个号");
			
			if (cname.equals("3fk3")||"2fk3".equals(cname)) {
				playCounts(order, "c1gh",user);
			}

		}
		// 三连号通选
		if (slhtx.length != 0 && !"".equals(slhtx[0])) {
			counts.add(slhtx.length);
			order.setCount2(slhtx.length);
			order.setCplay2("三连号通选");
			
			if (cname.equals("3fk3")||"2fk3".equals(cname)) {
				playCounts(order, "slhtx",user);
			}
		}
		// 二同号复选
		if (ethfx.length != 0 && !"".equals(ethfx[0])) {
			counts.add(ethfx.length);
			order.setCount3(ethfx.length);
			order.setCplay3("二同号复选");
			
			if (cname.equals("3fk3")||"2fk3".equals(cname)) {
				playCounts(order, "ethfx",user);
			}
		}
		// 二同号单选
		if (ethdx0.length != 0 && !"".equals(ethdx0[0]) && ethdx1.length != 0 && !"".equals(ethdx1[0])) {
			counts.add(ethdx0.length * ethdx1.length);
			order.setCount4(ethdx0.length * ethdx1.length);
			order.setCplay4("二同号单选前位");
			order.setCplay5("二同号单选后位");
			
			if (cname.equals("3fk3")||"2fk3".equals(cname)) {
				playCounts(order, "ethdx1",user);
				playCounts(order, "ethdx2",user);
			}
		}
		// 二不同号
		if (ebth.length > 1) {
			
			switch (ebth.length) {
			case 2:
				counts.add(1);
				order.setCount5(1);
				break;
			case 3:
				counts.add(3);
				order.setCount5(3);
				break;
			case 4:
				counts.add(6);
				order.setCount5(6);
				break;
			case 5:
				counts.add(10);
				order.setCount5(10);
				break;
			case 6:
				counts.add(15);
				order.setCount5(15);
				break;
			default:
				counts.add(0);
				order.setCount5(0);
				break;
			}
			order.setCplay6("二不同号");
	
			if (cname.equals("3fk3")||"2fk3".equals(cname)) {
				playCounts(order, "ebth",user);
			}
		}
		// 二不同号胆拖
		if (ebthdt0.length != 0 && !"".equals(ebthdt0[0]) && ebthdt1.length != 0 && !"".equals(ebthdt1[0])) {
			counts.add(ebthdt0.length * ebthdt1.length);
			order.setCount6(ebthdt0.length * ebthdt1.length);
			order.setCplay7("二不同号胆码");
			order.setCplay8("二不同号拖码");
			
			if (cname.equals("3fk3")||"2fk3".equals(cname)) {
				playCounts(order, "ebthdt1",user);
				playCounts(order, "ebthdt2",user);
			}
		}
		// 三同号通选
		if (sthtx.length != 0 && !"".equals(sthtx[0])) {
			counts.add(sthtx.length);
			order.setCount7(sthtx.length);
			order.setCplay9("三同号通选");
			
			if (cname.equals("3fk3")||"2fk3".equals(cname)) {
				playCounts(order, "slhtx",user);
			}
		}
		// 三同号单选
		if (sthdx.length != 0 && !"".equals(sthdx[0])) {
			counts.add(sthdx.length);
			order.setCount8(sthdx.length);
			order.setCplay10("三同号单选");
			
			if (cname.equals("3fk3")||"2fk3".equals(cname)) {
				playCounts(order, "sthdx",user);
			}
		}
		// 三不同号
		if (sbth.length > 2) {
			switch (sbth.length) {
			case 3:
				counts.add(1);
				order.setCount9(1);
				break;
			case 4:
				counts.add(4);
				order.setCount9(4);
				break;
			case 5:
				counts.add(10);
				order.setCount9(10);
				break;
			case 6:
				counts.add(20);
				order.setCount9(20);
				break;
			default:
				counts.add(0);
				order.setCount9(0);
				break;
			}
			order.setCplay11("三不同号");
			
			if (cname.equals("3fk3")||"2fk3".equals(cname)) {
				playCounts(order, "sbth",user);
			}
		}
		// 形态
		if (xt.length != 0 && !"".equals(xt[0])) {
			counts.add(xt.length);
			order.setCount10(xt.length);
			order.setCplay12("形态");
			
			if (cname.equals("3fk3")||"2fk3".equals(cname)) {
				playCounts(order, "xt",user);
			}
		}
		// 总和
		if (zh6.length != 0 && !"".equals(zh6[0])) {
			counts.add(zh6.length);
			order.setCount11(zh6.length);
			order.setCplay13("总和");
			
			if (cname.equals("3fk3")||"2fk3".equals(cname)) {
				playCounts(order, "zh",user);
			}
		}
		break;

	case "gdkl10f":
	case "cqkl10f":
		// 下注号码
		String[] swst = order.getStr1().split(",");
		String[] swht = order.getStr2().split(",");
		String[] elzhx0 = order.getStr3().split(",");
		String[] elzhx1 = order.getStr4().split(",");
		String[] elzx = order.getStr5().split(",");
		String[] q3zhx0 = order.getStr6().split(",");
		String[] q3zhx1 = order.getStr7().split(",");
		String[] q3zhx2 = order.getStr8().split(",");
		String[] q3zx = order.getStr9().split(",");
		String[] kl2 = order.getStr10().split(",");
		String[] kl3 = order.getStr11().split(",");
		String[] kl4 = order.getStr12().split(",");
		String[] kl5 = order.getStr13().split(",");

		// 首位数投
		if (swst.length != 0 && !"".equals(swst[0])) {
			counts.add(swst.length);
			order.setCount1(swst.length);
			order.setCplay1("首位数投");
		}
		// 首位红投
		if (swht.length != 0 && !"".equals(swht[0])) {
			counts.add(swht.length);
			order.setCount2(swht.length);
			order.setCplay2("首位红投");
		}
		// 二连直选
		if (elzhx0.length != 0 && !"".equals(elzhx0[0]) && elzhx1.length != 0 && !"".equals(elzhx1[0])) {
			int c = 0;
			for (int i = 0; i < elzhx0.length; i++) {
				for (int j = 0; j < elzhx1.length; j++) {
					if (!elzhx0[i].equals(elzhx1[j])) {
						c++;
					}
				}
			}
			counts.add(c);
			order.setCount3(c);
			order.setCplay3("二连直选前位");
			order.setCplay4("二连直选后位");
		}
		// 二连组选
		if (elzx.length > 1 && !"".equals(elzx[0])) {
			counts.add(elzx.length * (elzx.length - 1) / 2);
			order.setCount4(elzx.length * (elzx.length - 1) / 2);
			order.setCplay5("二连组选");
		}
		// 前三直选
		if (q3zhx0.length != 0 && !"".equals(q3zhx0[0]) && q3zhx1.length != 0 && !"".equals(q3zhx1[0])
				&& q3zhx2.length != 0 && !"".equals(q3zhx2[0])) {
			int d = 0;
			for (int i = 0; i < q3zhx0.length; i++) {
				for (int j = 0; j < q3zhx1.length; j++) {
					for (int k = 0; k < q3zhx2.length; k++) {
						if (!q3zhx0[i].equals(q3zhx1[j]) && !q3zhx0[i].equals(q3zhx2[k])
								&& !q3zhx1[j].equals(q3zhx2[k])) {
							d++;
						}
					}
				}
			}
			counts.add(d);
			order.setCount5(d);
			order.setCplay6("前三直选前位");
			order.setCplay7("前三直选中位");
			order.setCplay8("前三直选后位");
		}
		// 前三组选
		if (q3zx.length > 2 && !"".equals(q3zx[0])) {
			int m = q3zx.length;
			counts.add((m - 2) * (m - 1) * m / 6);
			order.setCount6((m - 2) * (m - 1) * m / 6);
			order.setCplay9("前三组选");
		}
		// 快乐2
		if (kl2.length > 1 && !"".equals(kl2[0])) {
			counts.add(kl2.length * (kl2.length - 1) / 2);
			order.setCount7(kl2.length * (kl2.length - 1) / 2);
			order.setCplay10("快乐2");
		}
		// 快乐3
		if (kl3.length > 2 && !"".equals(kl3[0])) {
			int m = kl3.length;
			counts.add( (m - 2) * (m - 1) * m / 6);
			order.setCount8( (m - 2) * (m - 1) * m / 6);
			order.setCplay11("快乐3");
		}
		// 快乐4
		if (kl4.length > 3 && !"".equals(kl4[0])) {
			int n = kl4.length;
			counts.add(n * (n - 1) * (n - 2) * (n - 3) / 24);
			order.setCount9(n * (n - 1) * (n - 2) * (n - 3) / 24);
			order.setCplay12("快乐4");
		}
		// 快乐5
		if (kl5.length > 4 && !"".equals(kl5[0])) {
			int i = kl5.length;
			counts.add(i * (i - 4) * (i - 3) * (i - 2) * (i - 1) / 120);
			order.setCount10(i * (i - 4) * (i - 3) * (i - 2) * (i - 1) / 120);
			order.setCplay13("快乐5");
		}
		break;

	case "shssl":
	case "pl3":
	case "fc3d":
		// 下注号码
		String[] q2zhx2 = order.getStr1().split(",");
		String[] q2zhx3 = order.getStr2().split(",");
		String[] q2zx = order.getStr3().split(",");
		String[] h2zhx2 = order.getStr4().split(",");
		String[] h2zhx3 = order.getStr5().split(",");
		String[] h2zx = order.getStr6().split(",");
		String[] sxzhx0 = order.getStr7().split(",");
		String[] sxzhx1 = order.getStr8().split(",");
		String[] sxzhx2 = order.getStr9().split(",");
		String[] zhxhz = order.getStr10().split(",");
		String[] sxz3 = order.getStr11().split(",");
		String[] z3hz = order.getStr12().split(",");
		String[] sxz6 = order.getStr13().split(",");
		String[] z6hz = order.getStr14().split(",");
		// 前二直选
		if (q2zhx2.length != 0 && !"".equals(q2zhx2[0]) && q2zhx3.length != 0 && !"".equals(q2zhx3[0])) {
			counts.add(q2zhx2.length * q2zhx3.length);
			order.setCount1(q2zhx2.length * q2zhx3.length);
			order.setCplay1("前二直选前位");
			order.setCplay2("前二直选后位");
		}
		// 前二组选
		if (q2zx.length != 0 && !"".equals(q2zx[0])) {
			if (q2zx.length < 2) {
				return new JsonResult("xinxi", 0);
			}
			counts.add(q2zx.length * (q2zx.length - 1) / 2);
			order.setCount2(q2zx.length * (q2zx.length - 1) / 2);
			order.setCplay3("前二组选");
		}
		// 后二直选
		if (h2zhx2.length != 0 && !"".equals(h2zhx2[0]) && h2zhx3.length != 0 && !"".equals(h2zhx3[0])) {
			counts.add(h2zhx2.length * h2zhx3.length);
			order.setCount3(h2zhx2.length * h2zhx3.length);
			order.setCplay4("后二直选前位");
			order.setCplay5("后二直选后位");
		}
		// 后二组选
		if (h2zx.length > 1 && !"".equals(h2zx[0])) {
			counts.add(h2zx.length * (h2zx.length - 1) / 2);
			order.setCount4(h2zx.length * (h2zx.length - 1) / 2);
			order.setCplay6("后二组选");
		}
		// 三星直选
		if (sxzhx0.length != 0 && !"".equals(sxzhx0[0]) && sxzhx1.length != 0 && !"".equals(sxzhx1[0])
				&& sxzhx2.length != 0 && !"".equals(sxzhx2[0])) {
			counts.add(sxzhx0.length * sxzhx1.length * sxzhx2.length);
			order.setCount5(sxzhx0.length * sxzhx1.length * sxzhx2.length);
			order.setCplay7("三星直选前位");
			order.setCplay8("三星直选中位");
			order.setCplay9("三星直选后位");
		}
		// 三星直选和值
		if (zhxhz.length != 0 && !"".equals(zhxhz[0])) {
			int f = 0;
			int[] x = new int[] { 0, 1, 2, 3, 4, 5, 6, 7, 8, 9 };
			for (int i = 0; i < zhxhz.length; i++) {
				for (int j = 0; j < x.length; j++) {
					for (int k = 0; k < x.length; k++) {
						for (int l = 0; l < x.length; l++) {
							if (Integer.parseInt(zhxhz[i]) == x[j] + x[k] + x[l]) {
								f++;
							}
						}
					}
				}
			}
			counts.add(f);
			order.setCount6(f);
			order.setCplay10("三星和值");
		}
		// 三星组三
		if (sxz3.length > 1 && !"".equals(sxz3[0])) {
			counts.add(sxz3.length * (sxz3.length - 1));
			order.setCount7(sxz3.length * (sxz3.length - 1));
			order.setCplay11("三星组三");
		}
		// 组三和值
		if (z3hz.length != 0 && !"".equals(z3hz[0])) {
			int f = 0;
			int[] y = new int[] { 0, 1, 2, 3, 4, 5, 6, 7, 8, 9 };
			for (int i = 0; i < z3hz.length; i++) {
				for (int j = 0; j < y.length; j++) {
					for (int k = 0; k < y.length; k++) {
						if (Integer.parseInt(z3hz[i]) == y[j] + y[j] + y[k] && j != k) {
							f++;
						}
					}
				}
			}
			counts.add(f);
			order.setCount8(f);
			order.setCplay12("组三和值");
		}
		// 三星组六
		if (sxz6.length > 2 && !"".equals(sxz6[0])) {
			counts.add(sxz6.length * (sxz6.length - 1) * (sxz6.length - 2) / 6);
			order.setCount9(sxz6.length * (sxz6.length - 1) * (sxz6.length - 2) / 6);
			order.setCplay13("三星组六");
		}
		// 组六和值   
		if (z6hz.length != 0 && !"".equals(z6hz[0])) {  
			int f = 0;
			int[] z = new int[] { 0, 1, 2, 3, 4, 5, 6, 7, 8, 9 };
			for (int i = 0; i < z6hz.length; i++) {
				for (int j = 0; j < z.length; j++) {
					for (int k = 0; k < z.length; k++) {
						for (int l = 0; l < z.length; l++) {
							if (Integer.parseInt(z6hz[i]) == z[j] + z[k] + z[l] && j != k && j != l && l != k) {
								f++;
							}
						}
					}
				}
			}
			counts.add(f / 6);
			order.setCount10(f / 6);
			order.setCplay14("组六和值");
		}
		break;

	case "ah11x5":
	case "gd11x5":
	case "jx11x5":
	case "sd11x5":
	case "sh11x5":
		String[] d1qq = order.getStr1().split(",");
		String[] d2qq = order.getStr2().split(",");
		String[] d3qq = order.getStr3().split(",");
		String[] d4qq = order.getStr4().split(",");
		String[] d5qq = order.getStr5().split(",");
		String[] zhh = order.getStr6().split(",");
		String[] q1zhx = order.getStr7().split(",");
		String[] q2zhx4 = order.getStr8().split(",");
		String[] q2zhx5 = order.getStr9().split(",");
		String[] q3zhx6 = order.getStr10().split(",");
		String[] q3zhx7 = order.getStr11().split(",");
		String[] q3zhx8 = order.getStr12().split(",");
		String[] rx1 = order.getStr13().split(",");
		String[] rx2 = order.getStr14().split(",");
		String[] rx3 = order.getStr15().split(",");
		String[] rx4 = order.getStr16().split(",");
		String[] rx5 = order.getStr17().split(",");
		String[] rx6 = order.getStr18().split(",");
		String[] rx7 = order.getStr19().split(",");
		String[] rx8 = order.getStr20().split(",");

		// 第1球
		if (d1qq.length != 0 && !"".equals(d1qq[0])) {
			counts.add(d1qq.length);
			order.setCount1(d1qq.length);
			order.setCplay1("第1球");
		}
		// 第2球
		if (d2qq.length != 0 && !"".equals(d2qq[0])) {
			counts.add(d2qq.length);
			order.setCount2(d2qq.length);
			order.setCplay2("第2球");
		}
		// 第3球
		if (d3qq.length != 0 && !"".equals(d3qq[0])) {
			counts.add(d3qq.length);
			order.setCount3(d3qq.length);
			order.setCplay3("第3球");
		}
		// 第4球
		if (d4qq.length != 0 && !"".equals(d4qq[0])) {
			counts.add(d4qq.length);
			order.setCount4(d4qq.length);
			order.setCplay4("第4球");
		}
		// 第5球
		if (d5qq.length != 0 && !"".equals(d5qq[0])) {
			counts.add(d5qq.length);
			order.setCount5(d5qq.length);
			order.setCplay5("第5球");
		}
		// 总和
		if (zhh.length != 0 && !"".equals(zhh[0])) {
			counts.add(zhh.length);
			order.setCount6(zhh.length);
			order.setCplay6("总和");
		}
		// 前一直选
		if (q1zhx.length != 0 && !"".equals(q1zhx[0])) {
			counts.add(q1zhx.length);
			order.setCount7(q1zhx.length);
			order.setCplay7("前一直选");
		}
		// 前二直选
		if (q2zhx4.length != 0 && !"".equals(q2zhx4[0]) && q2zhx5.length != 0 && !"".equals(q2zhx5[0])) {
			int f = 0;
			for (int i = 0; i < q2zhx4.length; i++) {
				for (int j = 0; j < q2zhx5.length; j++) {
					if (!q2zhx4[i].equals(q2zhx5[j])) {
						f++;
					}
				}
			}
			counts.add(f);
			order.setCount8(f);
			order.setCplay8("前二直选前位");
			order.setCplay9("前二直选后位");
		}
		// 前三直选
		if (q3zhx6.length != 0 && !"".equals(q3zhx6[0]) && q3zhx7.length != 0 && !"".equals(q3zhx7[0])
				&& q3zhx8.length != 0 && !"".equals(q3zhx8[0])) {
			int f = 0;
			for (int i = 0; i < q3zhx6.length; i++) {
				for (int j = 0; j < q3zhx7.length; j++) {
					for (int k = 0; k < q3zhx8.length; k++) {
						if (!q3zhx6[i].equals(q3zhx7[j]) && !q3zhx6[i].equals(q3zhx8[k])
								&& !q3zhx7[j].equals(q3zhx8[k])) {
							f++;
						}
					}
				}
			}
			counts.add(f);
			order.setCount9(f);
			order.setCplay10("前三直选前位");
			order.setCplay11("前三直选中位");
			order.setCplay12("前三直选后位");
		}
		// 任选一
		if (rx1.length != 0 && !"".equals(rx1[0])) {
			counts.add(rx1.length);
			order.setCount10(rx1.length);
			order.setCplay13("任选一");
		}
		// 任选二
		if (rx2.length != 0 && !"".equals(rx2[0])) {
			int u = rx2.length;
			counts.add(u * (u - 1) / 2);
			order.setCount11(u * (u - 1) / 2);
			order.setCplay14("任选二");
		}
		// 任选三
		if (rx3.length != 0 && !"".equals(rx3[0])) {
			int u = rx3.length;
			counts.add( u * (u - 1) * (u - 2) / 6);
			order.setCount12( u * (u - 1) * (u - 2) / 6);
			order.setCplay15("任选三");
		}
		// 任选四
		if (rx4.length != 0 && !"".equals(rx4[0])) {
			int u = rx4.length;
			counts.add(u * (u - 1) * (u - 2) * (u - 3) / 24);
			order.setCount13(u * (u - 1) * (u - 2) * (u - 3) / 24);
			order.setCplay16("任选四");
		}
		// 任选五
		if (rx5.length != 0 && !"".equals(rx5[0])) {
			int u = rx5.length;
			counts.add(u * (u - 1) * (u - 2) * (u - 3) * (u - 4) / 120);
			order.setCount14(u * (u - 1) * (u - 2) * (u - 3) * (u - 4) / 120);
			order.setCplay17("任选五");
		}
		// 任选六
		if (rx6.length != 0 && !"".equals(rx6[0])) {
			int u = rx6.length;
			counts.add(u * (u - 1) * (u - 2) * (u - 3) * (u - 4) * (u - 5) / 720);
			order.setCount15(u * (u - 1) * (u - 2) * (u - 3) * (u - 4) * (u - 5) / 720);
			order.setCplay18("任选六");
		}
		// 任选七
		if (rx7.length != 0 && !"".equals(rx7[0])) {
			int u = rx7.length;
			counts.add(u * (u - 1) * (u - 2) * (u - 3) * (u - 4) * (u - 5) * (u - 6) / 5040);
			order.setCount16(u * (u - 1) * (u - 2) * (u - 3) * (u - 4) * (u - 5) * (u - 6) / 5040);
			order.setCplay19("任选七");
		}
		// 任选八
		if (rx8.length != 0 && !"".equals(rx8[0])) {
			int u = rx8.length;
			counts.add( u * (u - 1) * (u - 2) * (u - 3) * (u - 4) * (u - 5) * (u - 6) * (u - 7) / 40320);
			order.setCount17( u * (u - 1) * (u - 2) * (u - 3) * (u - 4) * (u - 5) * (u - 6) * (u - 7) / 40320);
			order.setCplay20("任选八");
		}
		break;

	case "xg6hc":
	case "5f6hc":
		String[] tma = order.getStr1().split(",");
		String[] tmb = order.getStr2().split(",");
		String[] tmsx = order.getStr3().split(",");
		String[] dxds = order.getStr4().split(",");
		String[] jqys = order.getStr5().split(",");
		String[] ts = order.getStr6().split(",");
		String[] ws = order.getStr7().split(",");
		String[] wx = order.getStr8().split(",");
		String[] zh9 = order.getStr9().split(",");
		String[] hs = order.getStr10().split(",");
		String[] dp = order.getStr11().split(",");
		String[] p2z2 = order.getStr12().split(",");
		String[] p3z3 = order.getStr13().split(",");
		String[] p3z2 = order.getStr14().split(",");
		String[] sxzt = order.getStr15().split(",");
		String[] wxzt = order.getStr16().split(",");
		String[] lxzt = order.getStr17().split(",");
		String[] pt1x = order.getStr18().split(",");
		String[] pt2x = order.getStr19().split(",");
		String[] pt3x = order.getStr20().split(",");
		String[] pt4x = order.getStr21().split(",");
		String[] pt1w = order.getStr22().split(",");
		String[] pt2w = order.getStr23().split(",");
		String[] pt3w = order.getStr24().split(",");
		String[] pt4w = order.getStr25().split(",");
		String[] wbz = order.getStr26().split(",");
		String[] lbz = order.getStr27().split(",");
		String[] qbz = order.getStr28().split(",");
		String[] bbz = order.getStr29().split(",");
		String[] jbz = order.getStr30().split(",");
		String[] shbz = order.getStr31().split(",");
		String[] sh1bz = order.getStr32().split(",");
		String[] sh2bz = order.getStr33().split(",");
		String[] sh3bz = order.getStr34().split(",");
		String[] sh4bz = order.getStr35().split(",");
		String[] sh5bz = order.getStr36().split(",");
		String[] zx = order.getStr37().split(",");
		String[] sb = order.getStr38().split(",");
		String[] bb = order.getStr39().split(",");
		String[] bbb = order.getStr40().split(",");
		String[] attrs = { "01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12", "13", "14",
				"15", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25", "26", "27", "28", "29", "30",
				"31", "32", "33", "34", "35", "36", "37", "38", "39", "40", "41", "42", "43", "44", "45", "46",
				"47", "48", "49" };
		// 特码A
		if (tma.length != 0 && !"".equals(tma[0])) {
			counts.add(tma.length);
			order.setCount1(tma.length);
			order.setCplay1("特码A");
			
			if("5f6hc".equals(cname)) {
				playCounts(order, "tma",user);
			}
		}
		// 特码B
		if (tmb.length != 0 && !"".equals(tmb[0])) {
			counts.add(tmb.length);
			order.setCount2(tmb.length);
			order.setCplay2("特码B");
			
			if("5f6hc".equals(cname)) {
				playCounts(order, "tmb",user);
			}
		}
		// 特码生肖
		if (tmsx.length != 0 && !"".equals(tmsx[0])) {
			counts.add(tmsx.length);
			order.setCount3(tmsx.length);
			order.setCplay3("特码生肖");
			
			if("5f6hc".equals(cname)) {
				playCounts(order, "tmsx",user);
			}
		}
		// 大小单双
		if (dxds.length != 0 && !"".equals(dxds[0])) {
			counts.add(dxds.length);
			order.setCount4(dxds.length);
			order.setCplay4("大小单双");
			
			if("5f6hc".equals(cname)) {
				playCounts(order, "dxds",user);
			}
		}
		// 家禽野兽
		if (jqys.length != 0 && !"".equals(jqys[0])) {
			counts.add(jqys.length);
			order.setCount5(jqys.length);
			order.setCplay5("家禽野兽");
			
			if("5f6hc".equals(cname)) {
				playCounts(order, "jqys",user);
			}
		}
		// 头数
		if (ts.length != 0 && !"".equals(ts[0])) {
			counts.add(ts.length);
			order.setCount6(ts.length);
			order.setCplay6("头数");
			
			if("5f6hc".equals(cname)) {
				playCounts(order, "ts",user);
			}
		}
		// 尾数
		if (ws.length != 0 && !"".equals(ws[0])) {
			counts.add(ws.length);
			order.setCount7(ws.length);
			order.setCplay7("尾数");
			
			if("5f6hc".equals(cname)) {
				playCounts(order, "ws",user);
			}
		}
		// 五行
		if (wx.length != 0 && !"".equals(wx[0])) {
			counts.add(wx.length);
			order.setCount8(wx.length);
			order.setCplay8("五行");
			
			if("5f6hc".equals(cname)) {
				playCounts(order, "wx",user);
			}
		}
		// 总和
		if (zh9.length != 0 && !"".equals(zh9[0])) {
			counts.add(zh9.length);
			order.setCount9(zh9.length);
			order.setCplay9("总和");
			
			if("5f6hc".equals(cname)) {
				playCounts(order, "zh",user);
			}
		}
		// 合数
		if (hs.length != 0 && !"".equals(hs[0])) {
			counts.add(hs.length);
			order.setCount10(hs.length);
			order.setCplay10("合数");
			
			if("5f6hc".equals(cname)) {
				playCounts(order, "hs",user);
			}
		}
		// 独平
		if (dp.length != 0 && !"".equals(dp[0])) {
			counts.add(dp.length);
			order.setCount11(dp.length);
			order.setCplay11("独平");
			
			if("5f6hc".equals(cname)) {
				playCounts(order, "dp",user);
			}
		}
		// 平二中二
		if (p2z2.length != 0 && !"".equals(p2z2[0])) {
			if (p2z2.length < 2) {
				return new JsonResult("xinxi", 0);
			}
			int m = p2z2.length;
			counts.add(m * (m - 1) / 2);
			order.setCount12(m * (m - 1) / 2);
			order.setCplay12("平二中二");
			
			if("5f6hc".equals(cname)) {
				playCounts(order, "p2z2",user);
			}

		}
		// 平三中三
		if (p3z3.length != 0 && !"".equals(p3z3[0])) {
			if (p3z3.length < 3) {
				return new JsonResult("xinxi", 0);
			}
			int m = p3z3.length;
			counts.add(m * (m - 1) * (m - 2) / 6);
			order.setCount13(m * (m - 1) * (m - 2) / 6);
			order.setCplay13("平三中三");
			
			if("5f6hc".equals(cname)) {
				playCounts(order, "p3z3",user);
			}
		}
		// 平三中二
		if (p3z2.length != 0 && !"".equals(p3z2[0])) {
			if (p3z2.length < 3) {
				return new JsonResult("xinxi", 0);
			}
			int m = p3z2.length;
			counts.add(m * (m - 1) * (m - 2) / 6);
			order.setCount14(m * (m - 1) * (m - 2) / 6);
			order.setCplay14("平三中二");
			
			if("5f6hc".equals(cname)) {
				playCounts(order, "p3z2",user);
			}
		}
		// 四肖中特
		if (sxzt.length != 0 && !"".equals(sxzt[0])) {
			if (sxzt.length < 4) {
				return new JsonResult("xinxi", 0);
			}
			int m = sxzt.length;
			counts.add(m * (m - 3) * (m - 2) * (m - 1) / 24);
			order.setCount15(m * (m - 3) * (m - 2) * (m - 1) / 24);
			order.setCplay15("四肖中特");
			
			if("5f6hc".equals(cname)) {
				playCounts(order, "sxzt",user);
			}
		}
		// 五肖中特
		if (wxzt.length != 0 && !"".equals(wxzt[0])) {
			if (wxzt.length < 5) {
				return new JsonResult("xinxi", 0);
			}
			int m = wxzt.length;
			counts.add(m * (m - 4) * (m - 3) * (m - 2) * (m - 1) / 120);
			order.setCount16(m * (m - 4) * (m - 3) * (m - 2) * (m - 1) / 120);
			order.setCplay16("五肖中特");
			
			if("5f6hc".equals(cname)) {
				playCounts(order, "wxzt",user);
			}
		}
		// 六肖中特
		if (lxzt.length != 0 && !"".equals(lxzt[0])) {
			if (lxzt.length < 6) {
				return new JsonResult("xinxi", 0);
			}
			int m = lxzt.length;
			counts.add(m * (m - 5) * (m - 4) * (m - 3) * (m - 2) * (m - 1) / 720);
			order.setCount17(m * (m - 5) * (m - 4) * (m - 3) * (m - 2) * (m - 1) / 720);
			order.setCplay17("六肖中特");
			
			if("5f6hc".equals(cname)) {
				playCounts(order, "lxzt",user);
			}
		}
		// 平特一肖
		if (pt1x.length != 0 && !"".equals(pt1x[0])) {
			counts.add(pt1x.length);
			order.setCount18(pt1x.length);
			order.setCplay18("平特一肖");
			
			if("5f6hc".equals(cname)) {
				playCounts(order, "pt1x",user);
			}
		}
		// 平特二肖
		if (pt2x.length != 0 && !"".equals(pt2x[0])) {
			if (pt2x.length < 2) {
				return new JsonResult("xinxi", 0);
			}
			counts.add(pt2x.length * (pt2x.length - 1) / 2);
			order.setCount19(pt2x.length * (pt2x.length - 1) / 2);
			order.setCplay19("平特二肖");
			
			if("5f6hc".equals(cname)) {
				playCounts(order, "pt2x",user);
			}
		}
		// 平特三肖
		if (pt3x.length != 0 && !"".equals(pt3x[0])) {
			if (pt3x.length < 3) {
				return new JsonResult("xinxi", 0);
			}
			int m = pt3x.length;
			counts.add(m * (m - 1) * (m - 2) / 6);
			order.setCount20(m * (m - 1) * (m - 2) / 6);
			order.setCplay20("平特三肖");
			
			if("5f6hc".equals(cname)) {
				playCounts(order, "pt3x",user);
			}
		}
		// 平特四肖
		if (pt4x.length != 0 && !"".equals(pt4x[0])) {
			if (pt4x.length < 4) {
				return new JsonResult("xinxi", 0);
			}
			int m = pt4x.length;
			counts.add(m * (m - 3) * (m - 2) * (m - 1) / 24);
			order.setCount21(m * (m - 3) * (m - 2) * (m - 1) / 24);
			order.setCplay21("平特四肖");
			
			if("5f6hc".equals(cname)) {
				playCounts(order, "pt4x",user);
			}
		}
		// 平特一尾
		if (pt1w.length != 0 && !"".equals(pt1w[0])) {
			counts.add(pt1w.length);
			order.setCount22(pt1w.length);
			order.setCplay22("平特一尾");
			
			if("5f6hc".equals(cname)) {
				playCounts(order, "pt1w",user);
			}
		}
		// 平特二尾
		if (pt2w.length != 0 && !"".equals(pt2w[0])) {
			if (pt2w.length < 2) {
				return new JsonResult("xinxi", 0);
			}
			counts.add(pt2w.length * (pt2w.length - 1) / 2);
			order.setCount23(pt2w.length * (pt2w.length - 1) / 2);
			order.setCplay23("平特二尾");
			
			if("5f6hc".equals(cname)) {
				playCounts(order, "pt2w",user);
			}
		}
		// 平特三尾
		if (pt3w.length != 0 && !"".equals(pt3w[0])) {
			if (pt3w.length < 3) {
				return new JsonResult("xinxi", 0);
			}
			int m = pt3w.length;
			counts.add(m * (m - 1) * (m - 2) / 6);
			order.setCount24(m * (m - 1) * (m - 2) / 6);
			order.setCplay24("平特三尾");
			
			if("5f6hc".equals(cname)) {
				playCounts(order, "pt3w",user);
			}
		}
		// 平特四尾
		if (pt4w.length != 0 && !"".equals(pt4w[0])) {
			if (pt4w.length < 4) {
				return new JsonResult("xinxi", 0);
			}
			int m = pt4w.length;
			counts.add(m * (m - 3) * (m - 2) * (m - 1) / 24);
			order.setCount25(m * (m - 3) * (m - 2) * (m - 1) / 24);
			order.setCplay25("平特四尾");
			
			if("5f6hc".equals(cname)) {
				playCounts(order, "pt4w",user);
			}
		}
		// 五不中
		if (wbz.length != 0 && !"".equals(wbz[0])) {
			if (wbz.length < 5 || wbz.length > 12) {
				return new JsonResult("xinxi", 0);
			}
			if(ExChangeUtil.judgeAttr(wbz, attrs)) {
				return new JsonResult("error", "请示用正确方式投注,恶意使用BUG投注,将导致停用账号!");
			}
			switch (wbz.length) {
			case 12:
				counts.add(792);
				order.setCount26(792);
				break;
			case 11:
				counts.add(462);
				order.setCount26(462);
				break;
			case 10:
				counts.add(252);
				order.setCount26(252);
				break;
			case 9:
				counts.add(126);
				order.setCount26(126);
				break;
			case 8:
				counts.add(56);
				order.setCount26(56);
				break;
			case 7:
				counts.add(21);
				order.setCount26(21);
				break;
			case 6:
				counts.add(6);
				order.setCount26(6);
				break;
			case 5:
				counts.add(1);
				order.setCount26(1);
				break;
			default:
				counts.add(0);
				order.setCount26(0);
				break;
			}
			order.setCplay26("五不中");
			
			if("5f6hc".equals(cname)) {
				playCounts(order, "wbz",user);
			}
		}
		// 六不中
		if (lbz.length != 0 && !"".equals(lbz[0])) {
			if (lbz.length < 6 || lbz.length > 12) {
				return new JsonResult("xinxi", 0);
			}
			if(ExChangeUtil.judgeAttr(lbz, attrs)) {
				return new JsonResult("error", "请示用正确方式投注,恶意使用BUG投注,将导致停用账号!");
			}
			switch (lbz.length) {
			case 12:
				counts.add(924);
				order.setCount27(924);
				break;
			case 11:
				counts.add(462);
				order.setCount27(462);
				break;
			case 10:
				counts.add(210);
				order.setCount27(210);
				break;
			case 9:
				counts.add(84);
				order.setCount27(84);
				break;
			case 8:
				counts.add(28);
				order.setCount27(28);
				break;
			case 7:
				counts.add(7);
				order.setCount27(7);
				break;
			case 6:
				counts.add(1);
				order.setCount27(1);
				break;
			default:
				counts.add(0);
				order.setCount27(0);
				break;
			}
			order.setCplay27("六不中");
			
			if("5f6hc".equals(cname)) {
				playCounts(order, "lbz",user);
			}
		}

		// 七不中
		if (qbz.length != 0 && !"".equals(qbz[0])) {
			if (qbz.length < 7 || qbz.length > 12) {
				return new JsonResult("xinxi", 0);
			}
			if(ExChangeUtil.judgeAttr(qbz, attrs)) {
				return new JsonResult("error", "请示用正确方式投注,恶意使用BUG投注,将导致停用账号!");
			}
			
			switch (qbz.length) {
			case 12:
				counts.add(924);
				order.setCount28(924);
				break;
			case 11:
				counts.add(462);
				order.setCount28(462);
				break;
			case 10:
				counts.add(210);
				order.setCount28(210);
				break;
			case 9:
				counts.add(84);
				order.setCount28(84);
				break;
			case 8:
				counts.add(28);
				order.setCount28(28);
				break;
			case 7:
				counts.add(7);
				order.setCount28(7);
				break;
			default:
				counts.add(0);
				order.setCount28(0);
				break;
			}
			order.setCplay28("七不中");
			
			if("5f6hc".equals(cname)) {
				playCounts(order, "qbz",user);
			}
		}
		// 八不中
		if (bbz.length != 0 && !"".equals(bbz[0])) {
			if (bbz.length < 8 || bbz.length > 12) {
				return new JsonResult("xinxi", 0);
			}
			if(ExChangeUtil.judgeAttr(bbz, attrs)) {
				return new JsonResult("error", "请示用正确方式投注,恶意使用BUG投注,将导致停用账号!");
			}
			order.setCplay29("八不中");
			switch (bbz.length) {
			case 12:
				counts.add(495);
				order.setCount29(495);
				break;
			case 11:
				counts.add(165);
				order.setCount29(165);
				break;
			case 10:
				counts.add(45);
				order.setCount29(45);
				break;
			case 9:
				counts.add(9);
				order.setCount29(9);
				break;
			case 8:
				counts.add(1);
				order.setCount29(1);
			default:
				counts.add(0);
				order.setCount29(0);
				break;
			}
			
			if("5f6hc".equals(cname)) {
				playCounts(order, "bbz",user);
			}
		}
		// 九不中
		if (jbz.length != 0 && !"".equals(jbz[0])) {
			if (jbz.length < 9 || jbz.length > 13) {
				return new JsonResult("xinxi", 0);
			}
			if(ExChangeUtil.judgeAttr(jbz, attrs)) {
				return new JsonResult("error", "请示用正确方式投注,恶意使用BUG投注,将导致停用账号!");
			}
			order.setCplay30("九不中");
			switch (jbz.length) {
			case 12:
				counts.add(715);
				order.setCount30(715);
				break;
			case 11:
				counts.add(220);
				order.setCount30(220);
				break;
			case 10:
				counts.add(55);
				order.setCount30(55);
				break;
			case 9:
				counts.add(10);
				order.setCount30(10);
				break;
			case 8:
				counts.add(1);
				order.setCount30(1);
			default:
				counts.add(0);
				order.setCount30(0);
				break;
			}
			
			if("5f6hc".equals(cname)) {
				playCounts(order, "jbz",user);
			}
		}
		// 10不中
		if (shbz.length != 0 && !"".equals(shbz[0])) {
			if (shbz.length < 10 || shbz.length > 13) {
				return new JsonResult("xinxi", 0);
			}
			if(ExChangeUtil.judgeAttr(shbz, attrs)) {
				return new JsonResult("error", "请示用正确方式投注,恶意使用BUG投注,将导致停用账号!");
			}
			order.setCplay31("10不中");
			switch (shbz.length) {
			case 13:
				counts.add(286);
				order.setCount31(286);
				break;
			case 12:
				counts.add(66);
				order.setCount31(66);
				break;
			case 11:
				counts.add(11);
				order.setCount31(11);
				break;
			case 10:
				counts.add(1);
				order.setCount31(1);
				break;
			default:
				counts.add(0);
				order.setCount31(0);
				break;
			}
			
			if("5f6hc".equals(cname)) {
				playCounts(order, "shbz",user);
			}
		}
		// 11不中
		if (sh1bz.length != 0 && !"".equals(sh1bz[0])) {
			if (sh1bz.length < 11 || sh1bz.length > 14) {
				return new JsonResult("xinxi", 0);
			}
			if(ExChangeUtil.judgeAttr(sh1bz, attrs)) {
				return new JsonResult("error", "请示用正确方式投注,恶意使用BUG投注,将导致停用账号!");
			}
			order.setCplay32("11不中");
			switch (sh1bz.length) {
			case 14:
				counts.add(364);
				order.setCount32(364);
				break;
			case 13:
				counts.add(78);
				order.setCount32(78);
				break;
			case 12:
				counts.add(12);
				order.setCount32(12);
				break;
			case 11:
				counts.add(1);
				order.setCount32(1);
				break;
			default:
				counts.add(0);
				order.setCount32(0);
				break;
			}
			
			if("5f6hc".equals(cname)) {
				playCounts(order, "sh1bz",user);
			}
		}
		// 12不中
		if (sh2bz.length != 0 && !"".equals(sh2bz[0])) {
			if (sh2bz.length < 12 || sh2bz.length > 15) {
				return new JsonResult("xinxi", 0);
			}
			if(ExChangeUtil.judgeAttr(sh2bz, attrs)) {
				return new JsonResult("error", "请示用正确方式投注,恶意使用BUG投注,将导致停用账号!");
			}
			order.setCplay33("12不中");
			switch (sh2bz.length) {
			case 15:
				counts.add(445);
				order.setCount33(445);
				break;
			case 14:
				counts.add(91);
				order.setCount33(91);
				break;
			case 13:
				counts.add(13);
				order.setCount33(13);
				break;
			case 12:
				counts.add(1);
				order.setCount33(1);
				break;
			default:
				counts.add(0);
				order.setCount33(0);
				break;
			}
			
			if("5f6hc".equals(cname)) {
				playCounts(order, "sh2bz",user);
			}
		}
		// 13不中
		if (sh3bz.length != 0 && !"".equals(sh3bz[0])) {
			if (sh3bz.length < 13 || sh3bz.length > 16) {
				return new JsonResult("xinxi", 0);
			}
			if(ExChangeUtil.judgeAttr(sh3bz, attrs)) {
				return new JsonResult("error", "请示用正确方式投注,恶意使用BUG投注,将导致停用账号!");
			}
			order.setCplay34("13不中");
			switch (sh3bz.length) {
			case 16:
				counts.add(560);
				order.setCount34(560);
				break;
			case 15:
				counts.add(105);
				order.setCount34(105);
				break;
			case 14:
				counts.add(14);
				order.setCount34(14);
				break;
			case 13:
				counts.add(1);
				order.setCount34(1);
				break;
			default:
				counts.add(0);
				order.setCount34(0);
				break;
			}
			
			if("5f6hc".equals(cname)) {
				playCounts(order, "sh3bz",user);
			}
		}
		// 14不中
		if (sh4bz.length != 0 && !"".equals(sh4bz[0])) {
			if (sh4bz.length < 14 || sh4bz.length > 17) {
				return new JsonResult("xinxi", 0);
			}
			if(ExChangeUtil.judgeAttr(sh4bz, attrs)) {
				return new JsonResult("ERROR", "请示用正确方式投注,恶意使用BUG投注,将导致停用账号!");
			}
			order.setCplay35("14不中");
			switch (sh4bz.length) {
			case 17:
				counts.add(680);
				order.setCount35(680);
				break;
			case 16:
				counts.add(120);
				order.setCount35(120);
				break;
			case 15:
				counts.add(15);
				order.setCount35(15);
				break;
			case 14:
				counts.add(1);
				order.setCount35(1);
				break;
			default:
				counts.add(0);
				order.setCount35(0);
				break;
			}
			
			if("5f6hc".equals(cname)) {
				playCounts(order, "sh4bz",user);
			}
		}
		// 15不中
		if (sh5bz.length != 0 && !"".equals(sh5bz[0])) {
			if (sh5bz.length < 15 || sh5bz.length > 18) {
				return new JsonResult("xinxi", 0);
			}
			if(ExChangeUtil.judgeAttr(sh5bz, attrs)) {
				return new JsonResult("error", "请示用正确方式投注,恶意使用BUG投注,将导致停用账号!");
			}
			order.setCplay36("15不中");
			switch (sh5bz.length) {
			case 18:
				counts.add(816);
				order.setCount36(816);
				break;
			case 17:
				counts.add(136);
				order.setCount36(136);
				break;
			case 16:
				counts.add(16);
				order.setCount36(16);
				break;
			case 15:
				counts.add(1);
				order.setCount36(1);
				break;
			default:
				counts.add(0);
				order.setCount36(0);
				break;
			}
			
			if("5f6hc".equals(cname)) {
				playCounts(order, "sh5bz",user);
			}
		}
		// 总肖
		if (zx.length != 0 && !"".equals(zx[0])) {
			counts.add(zx.length);
			order.setCount37(zx.length);
			order.setCplay37("总肖");
			
			if("5f6hc".equals(cname)) {
				playCounts(order, "zx",user);
			}
		}
		// 色波
		if (sb.length != 0 && !"".equals(sb[0])) {
			counts.add(sb.length);
			order.setCount38(sb.length);
			order.setCplay38("色波");
			
			if("5f6hc".equals(cname)) {
				playCounts(order, "sb",user);
			}
		}
		// 半波
		if (bb.length != 0 && !"".equals(bb[0])) {
			counts.add(bb.length);
			order.setCount39(bb.length);
			order.setCplay39("半波");
			
			if("5f6hc".equals(cname)) {
				playCounts(order, "bb",user);
			}
		}
		// 半半波
		if (bbb.length != 0 && !"".equals(bbb[0])) {
			counts.add(bbb.length);
			order.setCount40(bbb.length);
			order.setCplay40("半半波");
			
			if("5f6hc".equals(cname)) {
				playCounts(order, "bbb",user);
			}
		}
		break;
		
	case "bj28":
	case "xy28":
	case "jnd28":
		String[] hunhe = order.getStr1().split(",");
		String[] tms = order.getStr2().split(",");
		String[] tmbs = order.getStr3().split(",");
		String[] bs = order.getStr4().split(",");
		String[] bz = order.getStr5().split(",");
		
		//混合
		if(hunhe.length!=0&&!"".equals(hunhe[0])) {
			counts.add(hunhe.length);
			order.setCount1(hunhe.length);
			order.setCplay1("混合");
			
			if("xy28".equals(cname)) {
				playCounts(order, "hunhe",user);
			}
		}
		
		//特码
		if(tms.length!=0&&!"".equals(tms[0])) {
			counts.add(tms.length);
			order.setCount2(tms.length);
			order.setCplay2("特码");
			
			if("xy28".equals(cname)) {
				playCounts(order, "tema",user);
			}
		}
		
		//特码包三
		if(tmbs.length!=0&&!"".equals(tmbs[0])) {
			counts.add(tmbs.length);
			order.setCount3(tmbs.length);
			order.setCplay3("特码包三");
			
			if("xy28".equals(cname)) {
				playCounts(order, "tmb3",user);
			}
		}
		
		//波色
		if(bs.length!=0&&!"".equals(bs[0])) {
			counts.add(bs.length);
			order.setCount4(bs.length);
			order.setCplay4("波色");
			
			if("xy28".equals(cname)) {
				playCounts(order, "bs",user);
			}
		}
		
		//豹子
		if(bz.length!=0&&!"".equals(bz[0])) {
			counts.add(bz.length);
			order.setCount5(bz.length);
			order.setCplay5("豹子");
			
			if("xy28".equals(cname)) {
				playCounts(order, "bz",user);
			}
		}
		break;
	}
	int count = 0;
	for(int i=0;i<counts.size();i++) {
		count+=counts.get(i);
	}
	if (count == 0) {
		return new JsonResult("下注注数有误!", 10);
	}
	SimpleDateFormat ss = new SimpleDateFormat("yyyyMMddHHmmss");
	double amount = count * order.getLottermoney();//下注金额
	order.setHuiyuanzh(user.getName());
	order.setOrdernum("TZ" + ss.format(new Date()) + user.getId());
	order.setLottercount(count);
	order.setAcount(amount);
	order.setLottermoney(order.getLottermoney());
	order.setOrderdate(sf.format(new Date()));
	order.setRebate(amount * 3);
	order.setUserid(user.getId());
	User user1 = userMapper.getUserByid(user.getId()); 
	if (user1.getBalance() < order.getAcount()) {
		return new JsonResult("0", "余额不足,请充值后投注!");
	} 
	String type = "";
	switch (order.getCname()) {
		case "2fpk10":
		case "xysm":
		case "2fssc":
		case "3fk3":
		case "5f6hc":
			type = "系统彩投注";
			break;
		default:
			type = "彩票投注";
			break;
		}
		flowChange(user1, false, order.getCname1(), order.getPeriod(), order.getAcount(), type,order.getOrdernum());
		if (user1.getState() == 1) {
			codeRecord(user1, order.getCname(), order.getPeriod(), order.getCname1(), true, order.getAcount(), 1,type);
		}
		Lotter lotter = lotterMapper.findLotterByCname(order.getCname());
		order.setOcount(lotter.getWhetherOrNotToCode());
		orderMapper.awards(order);
		User userInfo = userMapper.getUserByid(user.getId());
		if("2fpk10".equals(order.getCname()) || 
		   "2fssc".equals(order.getCname()) ||
		   "3fk3".equals(order.getCname()) ||
		   "2fft".equals(order.getCname()) ||
		   "2fk3".equals(order.getCname()) || 
		   "xysm".equals(order.getCname()) ||
		   "5f6hc".equals(order.getCname())) {//通知后端有用户下注了系统彩
			new WebSocketJson(6,orderMapper.Inquiries(order.getPeriod(), order.getCname())).sendAllHt();
		}
		return new JsonResult(userInfo.getBalance()+"", orderMapper.findByIdOrderInfo(order.getId()));
	}
	
	@Transactional
	@Override
	public int checkLotterMoney(Order order, User user) {
		String type = "";
		switch (order.getCname()) {
		case "2fpk10":
		case "2fft":
		case "xysm":
		case "2fssc":
		case "2fk3":
		case "3fk3":
		case "5f6hc":
			type = "系统彩派奖";
			break;
		default:
			type = "彩票派奖";
			break;
		}
		if (order.getGoalmoney() != 0.00) {
			flowChange(user, true, order.getCname1(), order.getPeriod(), order.getGoalmoney(), type,order.getOrdernum());
		}
		if (user.getState() == 1) {
			addLuckyCount(user);
			if (Integer.parseInt(WebsiteStateConfig.configs.get("agent_flag")) == 1) {
				agentRebate(user, order.getAcount(), 2, order.getOrdernum());// 代理1套
			} else {
				agentRebateTwo(user, order.getAcount(), order.getOrdernum());// 代理2套
			}
		}
		orderMapper.updateCheckInfo(order);
		return 0;
	}

	@Transactional
	@Override
	public synchronized JsonResult cancelOrder(User users,Integer order_id) {
		User user = userMapper.getUserByid(users.getId());
		Order order = orderMapper.findByIdOrderInfo(order_id);
		if (order.getState()!=1) {
			return new JsonResult("该订单已开奖，无法进行撤单!", 10);
		}
		Data data = dataMapper.getMaxPeriod(order.getCname());
		long mp = Long.parseLong(order.getPeriod());// 要撤单的期号
		long ms = Long.parseLong(data.getPeriod());// 当前期号
		if (mp < ms) {
			return new JsonResult("该订单已开奖，无法进行撤单!", 10);
		}
		if (order.getCname().equals("xg6hc")) {
			return new JsonResult("香港六合彩没有撤单!", 11);
		}
		SimpleDateFormat sf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		long currents =0;
		try {
			currents = (sf.parse(data.getNextStopOrderTimeEpoch()).getTime()-new Date().getTime())/1000;
		} catch (ParseException e) {
			e.printStackTrace();
		}
		System.err.println("当前彩种： "+order.getCname1()+"第"+order.getPeriod()+"期,距下期还有："+currents+"秒,当前系统时间："+DateUtil.getCurrTime());
		if(currents<30) {
			return new JsonResult("已封盘，无法进行下单!", 10); 
		}
		String type = "";
		switch (order.getCname()) {
		case "2fpk10":
		case "xysm":
		case "2fssc":
		case "3fk3":
		case "5f6hc":
		case "2fft":
		case "2fk3":
			type = "系统彩撤单";
			break;
		default:
			type = "彩票撤单";
			break;
		}
		flowChange(user, true, order.getCname1(), order.getPeriod(), order.getAcount(), type,order.getOrdernum());
		if (user.getState() == 1) {
			codeRecord(user, order.getCname(), order.getPeriod(), order.getCname1(), false, order.getAcount(), 2, type);
		}
		order.setState(7);
		return new JsonResult("撤单成功!", orderMapper.cancelOrder(order));
	}
	
	@Transactional
	@Override
	public JsonResult oneKeyRefund(Data data, AdminUser admin) {
		if(data.getCname()==null||data.getPeriod()==null) {
			return new JsonResult("参数有误!", 0);
		}
		DecimalFormat dec = new DecimalFormat("#0.00");
		data.setLottertime(DateUtil.getCurrTime());
		data.setLotternumber("官方开奖异常");
		data.setPaijtime(DateUtil.getCurrTime());
		data.setTouzhuzt("已结束");
		data.setState("开奖异常");
		dataMapper.updateFail(data);

		double sumMoney = 0.00;
		List<Order> orders = orderMapper.getOrderUser(data);
		if (orders.size() < 1) {
			return new JsonResult("本期没有要退钱的用户!", 0);
		}
		for (Order order : orders) {
			String type = "";
			switch (order.getCname()) {
				case "2fpk10":
				case "xysm":
				case "2fssc":
				case "3fk3":
				case "5f6hc":
				case "xy28":
				case "2fft":
				case "2fk3":
					type = "系统彩开奖异常";
					break;
				default:
					type = "彩票开奖异常";
					break;
				}
			User user = userMapper.getUserByid(order.getUserid());
			flowChange(user, true, order.getCname1(), order.getPeriod(), order.getAcount(), type,
					order.getOrdernum());
			if (user.getState() == 1) {
				codeRecord(user, order.getCname(), order.getPeriod(), order.getCname1(), false, order.getAcount(), 2,
						type);
			}
			order.setState(8);
			orderMapper.cancelOrder(order);
			sumMoney += order.getAcount();
		}
		String remarks = "在" + data.getGameNameInChinese() + "第" + data.getPeriod() + "期使用了一键退款功能,本期退款"+orders.size()+"条订单,一共退款"
				+ dec.format(sumMoney) + "元!";
		Operationlog log = new Operationlog();
		log.setName(admin.getName());
		log.setOperationtype("彩票开奖管理");
		log.setRemarks(remarks);
		log.setOperationtime(DateUtil.getCurrTime());
		log.setTime(DateUtil.findFormatDate());
		operationlogMapper.addOperationlog(log);
		return new JsonResult("退钱成功!", 0);
	}

	@Transactional
	@Override
	public int GcBettingRebate(User user, Order order) {
		flowChange(user, true, order.getCname1(), order.getPeriod(), order.getAcount(), "港彩特码B返水",order.getOrdernum());
		return 0;
	}

	@Transactional
	@Override
	public int returnCheckMoney(User user, Order order) {
		flowChange(user, true, order.getCname1(), order.getPeriod(), order.getAcount(), "和局本金退还",order.getOrdernum());
		return 0;
	}

	/**
	 * 多级代理返点一计算
	 * @param user         用户信息
	 * @param amount       变动金额
	 * @param type         返点类型 1是充值 2是打码
	 * @param order_number 订单号
	 * @return
	 */
	public int agentRebate(User user, double amount, int type, String order_number) {
		AdminUser admin = new AdminUser();
		admin.setName("系统自动");
		List<SetupAgent> setups = agentMapper.findOpenAgentSetup(type);
		List<User> users = agentMapper.findAllSuperior(user.getId());
		if (users.size() < 1 || setups.size() < 1) {
			return 1;
		}
		int num = setups.size();
		if (setups.size() > users.size()) {
			num = users.size();
		}
		for (int i = 0; i < num; i++) {
			SetupAgent setup = setups.get(i);
			User u = users.get(i);
			double total = setup.getRebate_ratio() * amount;
			AgentRecord commonAgent = new AgentRecord();
			commonAgent.setAgent_name(u.getName());
			commonAgent.setAgent_grade(setup.getAgent_grade());
			commonAgent.setUser_name(user.getName());
			commonAgent.setConsume(amount);
			commonAgent.setOrder_number(order_number);
			commonAgent.setRebate_type(type);
			commonAgent.setRebate_ratio(setup.getRebate_ratio());
			commonAgent.setRebate_money(total);
			commonAgent.setCreated_time(DateUtil.getCurrTime());
			commonAgent.setAgent_id(u.getId());
			commonAgent.setUser_id(user.getId());
			agentMapper.insertAgentRecord(commonAgent);
			
			double rebate = u.getMoney();
			rebate += total;
			u.setMoney(rebate);
			u.setCreatetime(DateUtil.getCurrTime());    
			userMapper.updateUserInfo(u);
			
			AgentTotal ats = agentMapper.findAgentTotal(user.getId(), u.getId());
			AgentTotal at = new AgentTotal();
			if (ats == null) {
				at.setUser_name(user.getName());
				at.setRecharge_money(0.00);
				at.setCode_money(amount);
				at.setRebate_money(total);
				at.setBalance(user.getBalance());
				at.setAgent_grade(setup.getAgent_grade());
				at.setCreated_time(DateUtil.getCurrTime());
				at.setAgent_id(u.getId());
				at.setUser_id(user.getId());
				agentMapper.insertAgentTotal(at);
			} else {
				if (type == 1) {
					ats.setRecharge_money(ats.getRecharge_money() + amount);
				} else {
					ats.setCode_money(ats.getCode_money() + amount);
				}
				ats.setRebate_money(ats.getRebate_money() + total);
				ats.setBalance(user.getBalance() - amount);
				ats.setCreated_time(DateUtil.getCurrTime());
				agentMapper.updateAgentTotal(ats);
			}
		}
		return 1;
	}
	
	/**
	 * 多级代理返点二计算
	 * @param user         用户信息
	 * @param amount       变动金额
	 * @param type         返点类型 1是充值 2是打码
	 * @param order_number 订单号
	 * @return
	 */
	public int agentRebateTwo(User user, double amount, String order_number) {
		AdminUser admin = new AdminUser();
		admin.setName("系统自动");
		User userInfo = userMapper.getUserByid(user.getId());
		if (null == userInfo.getOdds() || userInfo.getOdds() == 0.00) {
			return 0;
		}
		List<User> agents = agentMapper.findAllSuperior(user.getId());// 用户的所有上级
		double total = userInfo.getOdds() * amount;
		agentRebateTwoCompute(agents.get(0),userInfo,userInfo,amount,order_number,agents.size(),total);
		for (int i = 0; i < agents.size(); i++) {
			if (i + 1 < agents.size()) {
				total = agents.get(i).getOdds() * amount;
				agentRebateTwoCompute(agents.get(i + 1),agents.get(i),userInfo,amount,order_number,agents.size(),total);
			}
		}
		return 1;
	}
	
	public int agentRebateTwoCompute(User agent,User agents,User user,double amount,String order_number,int grade,double total) {
		AgentRecord commonAgent = new AgentRecord();
		commonAgent.setAgent_name(agent.getName());
		commonAgent.setAgent_grade(grade);
		commonAgent.setUser_name(user.getName());
		commonAgent.setConsume(amount);
		commonAgent.setOrder_number(order_number);
		commonAgent.setRebate_type(2);
		commonAgent.setRebate_ratio(agents.getOdds());
		commonAgent.setRebate_money(total);
		commonAgent.setCreated_time(DateUtil.getCurrTime());
		commonAgent.setAgent_id(agent.getId());
		commonAgent.setUser_id(user.getId());
		agentMapper.insertAgentRecordTwo(commonAgent);
		flowChange(agent, true, "", "", total, "代理返点",order_number);
		agent.setBalance(agent.getBalance()+total);
		agent.setCreatetime(DateUtil.getCurrTime());
		userMapper.updateUserInfo(agent);

		AgentTotal ats = agentMapper.findAgentTotalTow(user.getId(), agent.getId());
		AgentTotal at = new AgentTotal();
		if (ats == null) {
			at.setUser_name(user.getName());
			at.setRecharge_money(0.00);
			at.setCode_money(amount);
			at.setRebate_money(total);
			at.setBalance(user.getBalance());
			at.setAgent_grade(grade);
			at.setCreated_time(DateUtil.getCurrTime());
			at.setAgent_id(agent.getId());
			at.setUser_id(user.getId());
			agentMapper.insertAgentTotalTwo(at);
		} else {
			ats.setCode_money(ats.getCode_money() + amount);
			ats.setRebate_money(ats.getRebate_money() + total);
			ats.setBalance(user.getBalance() - amount);
			ats.setCreated_time(DateUtil.getCurrTime());
			agentMapper.updateAgentTotalTwo(ats);
		}
		return 1;
	}
	
	public int addLuckyCount(User user) {
		double new_damaliang = 0.00;
		int count = 0;
		Integer user_id = user.getId();
		Damal damal = damalMapper.getOnedamal(user_id);
		TodayRecord record = yunyingbbService.findOperateRecord("", "", user.getName(),2);
		damal.setDamaliang(record.getTouzhu());
		if(damal.getNew_damaliang()!=null) {
			new_damaliang = damal.getNew_damaliang();
		}
		double amount = damal.getDamaliang() - new_damaliang;
		LuckyCount luck = luckyCountMapper.getOneLuckyCount(user_id);
		if (Integer.parseInt(WebsiteStateConfig.configs.get("dluckFlag")) == 1) {
			if (Double.parseDouble(WebsiteStateConfig.configs.get("dluckCount")) > 0.00) {
				String acount = (amount / Double.parseDouble(WebsiteStateConfig.configs.get("dluckCount")) + "").split("\\.")[0];
				count += Integer.parseInt(acount);
			}
		}
		luck.setCount(luck.getCount() + count);
		damal.setNew_damaliang(damal.getDamaliang());
		luckyCountMapper.updateLuckyCount(luck);
		damalMapper.updateDamal(damal);
		return 1;
	}
	
	@Transactional
	@Override
	public int awardsBJL(Double money, String model, String qihao, boolean state, User user) {
		String orderNum = "";
		if ("百家乐投注".equals(model)) {
			orderNum = "BJL" + DateUtil.DateFormatOrderNum()+user.getId();
			flowChange(user, false, "百家乐", qihao, money, model,orderNum);
			codeRecord(user, "百家乐",qihao, "bjpk10", true, money, 6,model);
		} else {
			orderNum = "BJL" + DateUtil.DateFormatOrderNum()+user.getId();
			flowChange(user, false, "百家乐", qihao, money, model,orderNum);
		}
		return 0;
	}

	@Override
	public int updateReturnCheckMoney(Integer id, String tcPlay) {
		orderMapper.updateReturnCheckMoney(id, tcPlay);
		return 0;
	}

	@Override
	public int awards2(Order order) {
		return orderMapper.awards2(order);
	}

	@Override
	public List<Order> getMyOrders(String key, String cname, Integer id) {
		if ("dkj".equals(key)) {
			return orderMapper.getMyOrdersdkj(id, cname);
		} else if ("yzj".equals(key)) {
			return orderMapper.getMyOrdersyzj(id, cname);
		} else if ("ykj".equals(key)) {
			return orderMapper.getMyOrdersykj(id, cname);
		} else if ("ycd".equals(key)) {
			return orderMapper.getMyOrdersycd(id, cname);
		} else {
			return orderMapper.getMyOrders(id, cname);
		}
	}

	@Override
	public int delOrderById(int id) {
		int num = orderMapper.delOrderById(id);
		return num;
	}

	@Override
	public int getOrdersByUid(Order order, String date) {
		return orderMapper.getOrdersByUid(order, date);
	}

	@Override
	public List<Order> getAllJl() {
		return orderMapper.getAllJl();
	}

	@Override
	public List<Order> getMhAllJl(Integer startIndex, Integer lineCount, Integer state, String date1,String date2, String period,
			String cname1, String huiyuanzh, int model) {
		return orderMapper.getMhAllJl(startIndex, lineCount, state, date1, date2,period, cname1, huiyuanzh, model);
	}

	@Override
	public List<Order> getLiuheJl() {
		return orderMapper.getLiuheJl();
	}

	@Override
	public List<Order> getMhLiuheJl(Order order, String date1, String date2) {
		return orderMapper.getMhLiuheJl(order, date1, date2);
	}

	@Override
	public List<Order> fenleiorder(Integer id) {
		return orderMapper.fenleiorder(id);
	}

	@Override
	public double getOrderSum(Order order) {
		return orderMapper.getOrderSum(order);
	}

	@Override
	public List<Order> getzjdata() {
		return orderMapper.getzjdata();
	}

	@Override
	public List<Order> getxzdata(String cname) {
		return orderMapper.getxzdata(cname);
	}

	@Override
	public int getCheckMoney(Integer id, Integer b3) {
		return orderMapper.getCheckMoney(id, b3);
	}

	@Override
	public int getAllCheckMoney(Integer id) {
		return orderMapper.getAllCheckMoney(id);
	}

	@Override
	public int getTouZhuCount(Integer id, String times) {
		return orderMapper.getTouZhuCount(id, times);
	}

	public int playCounts(Order order, String cplay,User user) {
		if(user.getState()==2||user.getState()==3) {
			return -1;
		}
		Lotter lotters = lotterMapper.getCzxinxi(order.getCname());
		String str1 = lotters.getRebate1();
		String str2 = lotters.getRebate2();
		String str3 = lotters.getRebate3();
		String str4 = lotters.getRebate4();
		String str5 = lotters.getRebate5();
		String str6 = lotters.getRebate6();
		String str7 = lotters.getRebate7();
		String str8 = lotters.getRebate8();
		String str9 = lotters.getRebate9();
		String str10 = lotters.getRebate10();
		String str11 = lotters.getRebate11();
		String str12 = lotters.getRebate12();
		String str13 = lotters.getRebate13();
		String str14 = lotters.getRebate14();
		String str15 = lotters.getRebate15();
		String str16 = lotters.getRebate16();
		String str17 = lotters.getRebate17();
		String str18 = lotters.getRebate18();
		String str19 = lotters.getRebate19();
		String str20 = lotters.getRebate20();
		String str21 = lotters.getRebate21();
		String str22 = lotters.getRebate22();
		String str23 = lotters.getRebate23();
		String str24 = lotters.getRebate24();
		String str25 = lotters.getRebate25();
		String str26 = lotters.getRebate26();
		String str27 = lotters.getRebate27();
		String str28 = lotters.getRebate28();
		String str29 = lotters.getRebate29();
		String str30 = lotters.getRebate30();
		String str31 = lotters.getRebate31();
		String str32 = lotters.getRebate32();
		String str33 = lotters.getRebate33();
		String str34 = lotters.getRebate34();
		String str35 = lotters.getRebate35();
		String str36 = lotters.getRebate36();
		String str37 = lotters.getRebate37();
		String str38 = lotters.getRebate38();
		String str39 = lotters.getRebate39();
		String str40 = lotters.getRebate40();

		String cname = order.getCname();
		double price = order.getLottermoney();

		switch (cname) {
		case "2fpk10":  
		case "xysm":
			String gyhz[] = order.getStr1().split(",");
			String gj[] = order.getStr2().split(",");
			String yj[] = order.getStr3().split(",");
			String d3m[] = order.getStr4().split(",");
			String d4m[] = order.getStr5().split(",");
			String d5m[] = order.getStr6().split(",");
			String d6m[] = order.getStr7().split(",");
			String d7m[] = order.getStr8().split(",");
			String d8m[] = order.getStr9().split(",");
			String d9m[] = order.getStr10().split(",");
			String d10m[] = order.getStr11().split(",");
			if (cplay.equals("gyhz")) {
				PlayCount p2 = new PlayCount();
				p2.setCname(order.getCname());
				p2.setPeriod(order.getPeriod());
				p2.setCplay("gyhz");
				PlayCount p = playCountMapper.getCplay(p2);
				lotterCount2fpk10(gyhz, p, price, order, "gyhz", str1, 1);
			}
			
			if (cplay.equals("gj")) {
				PlayCount p2 = new PlayCount();
				p2.setCname(order.getCname());
				p2.setPeriod(order.getPeriod());
				p2.setCplay("gj");
				PlayCount p = playCountMapper.getCplay(p2);
				lotterCount2fpk10(gj, p, price, order, "gj", str2, 2);
			}

			if (cplay.equals("yj")) {
				PlayCount p2 = new PlayCount();
				p2.setCname(order.getCname());
				p2.setPeriod(order.getPeriod());
				p2.setCplay("yj");
				PlayCount p = playCountMapper.getCplay(p2);
				lotterCount2fpk10(yj, p, price, order, "yj", str3, 2);
			}

			if (cplay.equals("d3m")) {
				PlayCount p2 = new PlayCount();
				p2.setCname(order.getCname());
				p2.setPeriod(order.getPeriod());
				p2.setCplay("d3m");
				PlayCount p = playCountMapper.getCplay(p2);
				lotterCount2fpk10(d3m, p, price, order, "d3m", str3, 2);
			}

			if (cplay.equals("d4m")) {
				PlayCount p2 = new PlayCount();
				p2.setCname(order.getCname());
				p2.setPeriod(order.getPeriod());
				p2.setCplay("d4m");
				PlayCount p = playCountMapper.getCplay(p2);
				lotterCount2fpk10(d4m, p, price, order, "d4m", str4, 2);
			}

			if (cplay.equals("d5m")) {
				PlayCount p2 = new PlayCount();
				p2.setCname(order.getCname());
				p2.setPeriod(order.getPeriod());
				p2.setCplay("d5m");
				PlayCount p = playCountMapper.getCplay(p2);
				lotterCount2fpk10(d5m, p, price, order, "d5m", str5, 2);
			}

			if (cplay.equals("d6m")) {
				PlayCount p2 = new PlayCount();
				p2.setCname(order.getCname());
				p2.setPeriod(order.getPeriod());
				p2.setCplay("d6m");
				PlayCount p = playCountMapper.getCplay(p2);
				lotterCount2fpk10(d6m, p, price, order, "d6m", str6, 3);
			}

			if (cplay.equals("d7m")) {
				PlayCount p2 = new PlayCount();
				p2.setCname(order.getCname());
				p2.setPeriod(order.getPeriod());
				p2.setCplay("d7m");
				PlayCount p = playCountMapper.getCplay(p2);
				lotterCount2fpk10(d7m, p, price, order, "d7m", str7, 3);
			}

			if (cplay.equals("d8m")) {
				PlayCount p2 = new PlayCount();
				p2.setCname(order.getCname());
				p2.setPeriod(order.getPeriod());
				p2.setCplay("d8m");
				PlayCount p = playCountMapper.getCplay(p2);
				lotterCount2fpk10(d8m, p, price, order, "d8m", str8, 3);
			}

			if (cplay.equals("d9m")) {
				PlayCount p2 = new PlayCount();
				p2.setCname(order.getCname());
				p2.setPeriod(order.getPeriod());
				p2.setCplay("d9m");
				PlayCount p = playCountMapper.getCplay(p2);
				lotterCount2fpk10(d9m, p, price, order, "d9m", str9, 3);
			}

			if (cplay.equals("d10m")) {
				PlayCount p2 = new PlayCount();
				p2.setCname(order.getCname());
				p2.setPeriod(order.getPeriod());
				p2.setCplay("d10m");
				PlayCount p = playCountMapper.getCplay(p2);
				lotterCount2fpk10(d10m, p, price, order, "d10m", str10, 3);
			}
			break;
		case "2fssc": 
			String[] zh = order.getStr1().split(",");
			String[] d1q = order.getStr2().split(",");
			String[] d2q = order.getStr3().split(",");
			String[] d3q = order.getStr4().split(",");
			String[] d4q = order.getStr5().split(",");
			String[] d5q = order.getStr6().split(",");
			String[] q3 = order.getStr7().split(",");
			String[] z3 = order.getStr8().split(",");
			String[] h3 = order.getStr9().split(",");
			String[] q2zhx0 = order.getStr10().split(",");
			String[] q2zhx1 = order.getStr11().split(",");
			String[] h2zhx0 = order.getStr12().split(",");
			String[] h2zhx1 = order.getStr13().split(",");
			String[] q3zhxx0 = order.getStr14().split(",");
			String[] q3zhxx1 = order.getStr15().split(",");
			String[] q3zhxx2 = order.getStr16().split(",");
			String[] z3zhx0 = order.getStr17().split(",");
			String[] z3zhx1 = order.getStr18().split(",");
			String[] z3zhx2 = order.getStr19().split(",");
			String[] h3zhx0 = order.getStr20().split(",");
			String[] h3zhx1 = order.getStr21().split(",");
			String[] h3zhx2 = order.getStr22().split(",");
			String[] q2zxx = order.getStr23().split(",");
			String[] h2zxx = order.getStr24().split(",");
			String[] q3z6 = order.getStr25().split(",");
			String[] z3z6 = order.getStr26().split(",");
			String[] h3z6 = order.getStr27().split(",");
			String[] q3z3 = order.getStr28().split(",");
			String[] z3z3 = order.getStr29().split(",");
			String[] h3z3 = order.getStr30().split(",");

			if (cplay.equals("zh")) {
				PlayCount p2 = new PlayCount();
				p2.setCname(order.getCname());
				p2.setPeriod(order.getPeriod());
				p2.setCplay("zh");
				PlayCount p = playCountMapper.getCplay(p2);
				lotterCount(zh, p, price, order, "zh", str1, 4);
			}

			if (cplay.equals("d1q")) {
				PlayCount p2 = new PlayCount();
				p2.setCname(order.getCname());
				p2.setPeriod(order.getPeriod());
				p2.setCplay("d1q");
				PlayCount p = playCountMapper.getCplay(p2);
				lotterCount(d1q, p, price, order, "d1q", str2, 1);
			}

			if (cplay.equals("d2q")) {
				PlayCount p2 = new PlayCount();
				p2.setCname(order.getCname());
				p2.setPeriod(order.getPeriod());
				p2.setCplay("d2q");
				PlayCount p = playCountMapper.getCplay(p2);
				lotterCount(d2q, p, price, order, "d2q", str3, 1);
			}

			if (cplay.equals("d3q")) {
				PlayCount p2 = new PlayCount();
				p2.setCname(order.getCname());
				p2.setPeriod(order.getPeriod());
				p2.setCplay("d3q");
				PlayCount p = playCountMapper.getCplay(p2);
				lotterCount(d3q, p, price, order, "d3q", str4, 1);
			}

			if (cplay.equals("d4q")) {
				PlayCount p2 = new PlayCount();
				p2.setCname(order.getCname());
				p2.setPeriod(order.getPeriod());
				p2.setCplay("d4q");
				PlayCount p = playCountMapper.getCplay(p2);
				lotterCount(d4q, p, price, order, "d4q", str5, 1);
			}

			if (cplay.equals("d5q")) {
				PlayCount p2 = new PlayCount();
				p2.setCname(order.getCname());
				p2.setPeriod(order.getPeriod());
				p2.setCplay("d5q");
				PlayCount p = playCountMapper.getCplay(p2);
				lotterCount(d5q, p, price, order, "d5q", str6, 1);
			}

			if (cplay.equals("q3")) {
				PlayCount p2 = new PlayCount();
				p2.setCname(order.getCname());
				p2.setPeriod(order.getPeriod());
				p2.setCplay("q3");
				PlayCount p = playCountMapper.getCplay(p2);
				lotterCount(q3, p, price, order, "q3", str7, 3);
			}

			if (cplay.equals("z3")) {
				PlayCount p2 = new PlayCount();
				p2.setCname(order.getCname());
				p2.setPeriod(order.getPeriod());
				p2.setCplay("z3");
				PlayCount p = playCountMapper.getCplay(p2);
				lotterCount(z3, p, price, order, "z3", str8, 3);
			}

			if (cplay.equals("h3")) {
				PlayCount p2 = new PlayCount();
				p2.setCname(order.getCname());
				p2.setPeriod(order.getPeriod());
				p2.setCplay("h3");
				PlayCount p = playCountMapper.getCplay(p2);
				lotterCount(h3, p, price, order, "h3", str9, 3);
			}

			if (cplay.equals("q2zhix0")) {
				PlayCount p2 = new PlayCount();
				p2.setCname(order.getCname());
				p2.setPeriod(order.getPeriod());
				p2.setCplay("q2zhix0");
				PlayCount p = playCountMapper.getCplay(p2);
				lotterCount(q2zhx0, p, price, order, "q2zhix0", str10, 2);
			}

			if (cplay.equals("q2zhix1")) {
				PlayCount p2 = new PlayCount();
				p2.setCname(order.getCname());
				p2.setPeriod(order.getPeriod());
				p2.setCplay("q2zhix1");
				PlayCount p = playCountMapper.getCplay(p2);
				lotterCount(q2zhx1, p, price, order, "q2zhix1", str10, 2);
			}

			if (cplay.equals("h2zhix0")) {
				PlayCount p2 = new PlayCount();
				p2.setCname(order.getCname());
				p2.setPeriod(order.getPeriod());
				p2.setCplay("h2zhix0");
				PlayCount p = playCountMapper.getCplay(p2);
				lotterCount(h2zhx0, p, price, order, "h2zhix0", str11, 2);
			}

			if (cplay.equals("h2zhix1")) {
				PlayCount p2 = new PlayCount();
				p2.setCname(order.getCname());
				p2.setPeriod(order.getPeriod());
				p2.setCplay("h2zhix1");
				PlayCount p = playCountMapper.getCplay(p2);
				lotterCount(h2zhx1, p, price, order, "h2zhix1", str11, 2);
			}

			if (cplay.equals("q3zhix0")) {
				PlayCount p2 = new PlayCount();
				p2.setCname(order.getCname());
				p2.setPeriod(order.getPeriod());
				p2.setCplay("q3zhix0");
				PlayCount p = playCountMapper.getCplay(p2);
				lotterCount(q3zhxx0, p, price, order, "q3zhix0", str12, 2);
			}

			if (cplay.equals("q3zhix1")) {
				PlayCount p2 = new PlayCount();
				p2.setCname(order.getCname());
				p2.setPeriod(order.getPeriod());
				p2.setCplay("q3zhix1");
				PlayCount p = playCountMapper.getCplay(p2);
				lotterCount(q3zhxx1, p, price, order, "q3zhix1", str12, 2);
			}

			if (cplay.equals("q3zhix2")) {
				PlayCount p2 = new PlayCount();
				p2.setCname(order.getCname());
				p2.setPeriod(order.getPeriod());
				p2.setCplay("q3zhix2");
				PlayCount p = playCountMapper.getCplay(p2);
				lotterCount(q3zhxx2, p, price, order, "q3zhix2", str12, 2);
			}

			if (cplay.equals("z3zhix0")) {
				PlayCount p2 = new PlayCount();
				p2.setCname(order.getCname());
				p2.setPeriod(order.getPeriod());
				p2.setCplay("z3zhix0");
				PlayCount p = playCountMapper.getCplay(p2);
				lotterCount(z3zhx0, p, price, order, "z3zhix0", str13, 2);
			}

			if (cplay.equals("z3zhix1")) {
				PlayCount p2 = new PlayCount();
				p2.setCname(order.getCname());
				p2.setPeriod(order.getPeriod());
				p2.setCplay("z3zhix1");
				PlayCount p = playCountMapper.getCplay(p2);
				lotterCount(z3zhx1, p, price, order, "z3zhix1", str13, 2);
			}

			if (cplay.equals("z3zhix2")) {
				PlayCount p2 = new PlayCount();
				p2.setCname(order.getCname());
				p2.setPeriod(order.getPeriod());
				p2.setCplay("z3zhix2");
				PlayCount p = playCountMapper.getCplay(p2);
				lotterCount(z3zhx2, p, price, order, "z3zhix2", str13, 2);
			}

			if (cplay.equals("h3zhix0")) {
				PlayCount p2 = new PlayCount();
				p2.setCname(order.getCname());
				p2.setPeriod(order.getPeriod());
				p2.setCplay("h3zhix0");
				PlayCount p = playCountMapper.getCplay(p2);
				lotterCount(h3zhx0, p, price, order, "h3zhix0", str14, 2);
			}

			if (cplay.equals("h3zhix1")) {
				PlayCount p2 = new PlayCount();
				p2.setCname(order.getCname());
				p2.setPeriod(order.getPeriod());
				p2.setCplay("h3zhix1");
				PlayCount p = playCountMapper.getCplay(p2);
				lotterCount(h3zhx1, p, price, order, "h3zhix1", str14, 2);
			}

			if (cplay.equals("h3zhix2")) {
				PlayCount p2 = new PlayCount();
				p2.setCname(order.getCname());
				p2.setPeriod(order.getPeriod());
				p2.setCplay("h3zhix2");
				PlayCount p = playCountMapper.getCplay(p2);
				lotterCount(h3zhx2, p, price, order, "h3zhix2", str14, 2);
			}

			if (cplay.equals("q2zx")) {
				PlayCount p2 = new PlayCount();
				p2.setCname(order.getCname());
				p2.setPeriod(order.getPeriod());
				p2.setCplay("q2zx");
				PlayCount p = playCountMapper.getCplay(p2);
				lotterCount(q2zxx, p, price, order, "q2zx", str15, 2);
			}

			if (cplay.equals("h2zx")) {
				PlayCount p2 = new PlayCount();
				p2.setCname(order.getCname());
				p2.setPeriod(order.getPeriod());
				p2.setCplay("h2zx");
				PlayCount p = playCountMapper.getCplay(p2);
				lotterCount(h2zxx, p, price, order, "h2zx", str16, 2);
			}

			if (cplay.equals("q3z6")) {
				PlayCount p2 = new PlayCount();
				p2.setCname(order.getCname());
				p2.setPeriod(order.getPeriod());
				p2.setCplay("q3z6");
				PlayCount p = playCountMapper.getCplay(p2);
				lotterCount(q3z6, p, price, order, "q3z6", str17, 2);
			}

			if (cplay.equals("z3z6")) {
				PlayCount p2 = new PlayCount();
				p2.setCname(order.getCname());
				p2.setPeriod(order.getPeriod());
				p2.setCplay("z3z6");
				PlayCount p = playCountMapper.getCplay(p2);
				lotterCount(z3z6, p, price, order, "z3z6", str18, 2);
			}

			if (cplay.equals("h3z6")) {
				PlayCount p2 = new PlayCount();
				p2.setCname(order.getCname());
				p2.setPeriod(order.getPeriod());
				p2.setCplay("h3z6");
				PlayCount p = playCountMapper.getCplay(p2);
				lotterCount(h3z6, p, price, order, "h3z6", str19, 2);
			}
			if (cplay.equals("q3z3")) {
				PlayCount p2 = new PlayCount();
				p2.setCname(order.getCname());
				p2.setPeriod(order.getPeriod());
				p2.setCplay("q3z3");
				PlayCount p = playCountMapper.getCplay(p2);
				lotterCount(q3z3, p, price, order, "q3z3", str20, 2);
			}

			if (cplay.equals("z3z3")) {
				PlayCount p2 = new PlayCount();
				p2.setCname(order.getCname());
				p2.setPeriod(order.getPeriod());
				p2.setCplay("z3z3");
				PlayCount p = playCountMapper.getCplay(p2);
				lotterCount(z3z3, p, price, order, "z3z3", str21, 2);
			}
			if (cplay.equals("h3z3")) {
				PlayCount p2 = new PlayCount();
				p2.setCname(order.getCname());
				p2.setPeriod(order.getPeriod());
				p2.setCplay("h3z3");
				PlayCount p = playCountMapper.getCplay(p2);
				lotterCount(h3z3, p, price, order, "h3z3", str22, 2);
			}
			break;

		case "3fk3":
			String[] c1gh = order.getStr1().split(",");
			String[] slhtx = order.getStr2().split(",");
			String[] ethfx = order.getStr3().split(",");
			String[] ethdx1 = order.getStr4().split(",");
			String[] ethdx2 = order.getStr5().split(",");
			String[] ebth = order.getStr6().split(",");
			String[] ebthdt1 = order.getStr7().split(",");
			String[] ebthdt2 = order.getStr8().split(",");
			String[] sthtx = order.getStr9().split(",");
			String[] sthdx = order.getStr10().split(",");
			String[] sbth = order.getStr11().split(",");
			String[] xt = order.getStr12().split(",");
			String[] zhs = order.getStr13().split(",");

			if (cplay.equals("c1gh")) {
				PlayCount p2 = new PlayCount();
				p2.setCname(order.getCname());
				p2.setPeriod(order.getPeriod());
				p2.setCplay("c1gh");
				PlayCount p = playCountMapper.getCplay(p2);
				lotterCount3fk3(c1gh, p, price, order, "c1gh", str1, 1);
			}
			if (cplay.equals("slhtx")) {
				PlayCount p2 = new PlayCount();
				p2.setCname(order.getCname());
				p2.setPeriod(order.getPeriod());
				p2.setCplay("slhtx");
				PlayCount p = playCountMapper.getCplay(p2);
				lotterCount3fk3(slhtx, p, price, order, "slhtx", str2, 2);
			}
			if (cplay.equals("ethfx")) {
				PlayCount p2 = new PlayCount();
				p2.setCname(order.getCname());
				p2.setPeriod(order.getPeriod());
				p2.setCplay("ethfx");
				PlayCount p = playCountMapper.getCplay(p2);
				lotterCount3fk3(ethfx, p, price, order, "ethfx", str3, 3);
			}
			if (cplay.equals("ethdx1")) {
				PlayCount p2 = new PlayCount();
				p2.setCname(order.getCname());
				p2.setPeriod(order.getPeriod());
				p2.setCplay("ethdx1");
				PlayCount p = playCountMapper.getCplay(p2);
				lotterCount3fk3(ethdx1, p, price, order, "ethdx1", str4, 3);
			}
			if (cplay.equals("ethdx2")) {
				PlayCount p2 = new PlayCount();
				p2.setCname(order.getCname());
				p2.setPeriod(order.getPeriod());
				p2.setCplay("ethdx2");
				PlayCount p = playCountMapper.getCplay(p2);
				lotterCount3fk3(ethdx2, p, price, order, "ethdx2", str4, 1);
			}
			if (cplay.equals("ebth")) {
				PlayCount p2 = new PlayCount();
				p2.setCname(order.getCname());
				p2.setPeriod(order.getPeriod());
				p2.setCplay("ebth");
				PlayCount p = playCountMapper.getCplay(p2);
				lotterCount3fk3(ebth, p, price, order, "ebth", str5, 1);
			}
			if (cplay.equals("ebthdt1")) {
				PlayCount p2 = new PlayCount();
				p2.setCname(order.getCname());
				p2.setPeriod(order.getPeriod());
				p2.setCplay("ebthdt1");
				PlayCount p = playCountMapper.getCplay(p2);
				lotterCount3fk3(ebthdt1, p, price, order, "ebthdt1", str6, 1);
			}
			if (cplay.equals("ebthdt2")) {
				PlayCount p2 = new PlayCount();
				p2.setCname(order.getCname());
				p2.setPeriod(order.getPeriod());
				p2.setCplay("ebthdt2");
				PlayCount p = playCountMapper.getCplay(p2);
				lotterCount3fk3(ebthdt2, p, price, order, "ebthdt2", str6, 1);
			}
			if (cplay.equals("sthtx")) {
				PlayCount p2 = new PlayCount();
				p2.setCname(order.getCname());
				p2.setPeriod(order.getPeriod());
				p2.setCplay("sthtx");
				PlayCount p = playCountMapper.getCplay(p2);
				lotterCount3fk3(sthtx, p, price, order, "sthtx", str7, 4);
			}
			if (cplay.equals("sthdx")) {
				PlayCount p2 = new PlayCount();
				p2.setCname(order.getCname());
				p2.setPeriod(order.getPeriod());
				p2.setCplay("sthdx");
				PlayCount p = playCountMapper.getCplay(p2);
				lotterCount3fk3(sthdx, p, price, order, "sthdx", str8, 5);
			}
			if (cplay.equals("sbth")) {
				PlayCount p2 = new PlayCount();
				p2.setCname(order.getCname());
				p2.setPeriod(order.getPeriod());
				p2.setCplay("sbth");
				PlayCount p = playCountMapper.getCplay(p2);
				lotterCount3fk3(sbth, p, price, order, "sbth", str9, 1);
			}
			if (cplay.equals("xt")) {
				PlayCount p2 = new PlayCount();
				p2.setCname(order.getCname());
				p2.setPeriod(order.getPeriod());
				p2.setCplay("xt");
				PlayCount p = playCountMapper.getCplay(p2);
				lotterCount3fk3(xt, p, price, order, "xt", str10, 6);
				
			}
			if (cplay.equals("zh")) {
				PlayCount p2 = new PlayCount();
				p2.setCname(order.getCname());
				p2.setPeriod(order.getPeriod());
				p2.setCplay("zh");
				PlayCount p = playCountMapper.getCplay(p2);
				lotterCount3fk3(zhs, p, price, order, "zh", str11, 7);
			}
			break;
			
		case "5f6hc":
			String[] tma = order.getStr1().split(",");
			String[] tmb = order.getStr2().split(",");
			String[] tmsx = order.getStr3().split(",");
			String[] dxds = order.getStr4().split(",");
			String[] jqys = order.getStr5().split(",");
			String[] ts = order.getStr6().split(",");
			String[] ws = order.getStr7().split(",");
			String[] wx = order.getStr8().split(",");
			String[] zhc = order.getStr9().split(",");
			String[] hs = order.getStr10().split(",");
			String[] dp = order.getStr11().split(",");
			String[] p2z2 = order.getStr12().split(",");
			String[] p3z3 = order.getStr13().split(",");
			String[] p3z2 = order.getStr14().split(",");
			String[] sxzt = order.getStr15().split(",");
			String[] wxzt = order.getStr16().split(",");
			String[] lxzt = order.getStr17().split(",");
			String[] pt1x = order.getStr18().split(",");
			String[] pt2x = order.getStr19().split(",");
			String[] pt3x = order.getStr20().split(",");
			String[] pt4x = order.getStr21().split(",");
			String[] pt1w = order.getStr22().split(",");
			String[] pt2w = order.getStr23().split(",");
			String[] pt3w = order.getStr24().split(",");
			String[] pt4w = order.getStr25().split(",");
			String[] wbz = order.getStr26().split(",");
			String[] lbz = order.getStr27().split(",");
			String[] qbz = order.getStr28().split(",");
			String[] bbz = order.getStr29().split(",");
			String[] jbz = order.getStr30().split(",");
			String[] shbz = order.getStr31().split(",");
			String[] sh1bz = order.getStr32().split(",");
			String[] sh2bz = order.getStr33().split(",");
			String[] sh3bz = order.getStr34().split(",");
			String[] sh4bz = order.getStr35().split(",");
			String[] sh5bz = order.getStr36().split(",");
			String[] zx = order.getStr37().split(",");
			String[] sb = order.getStr38().split(",");
			String[] bb = order.getStr39().split(",");
			String[] bbb = order.getStr40().split(",");
			if (cplay.equals("tma")) {
				PlayCount p2 = new PlayCount();
				p2.setCname(order.getCname());
				p2.setPeriod(order.getPeriod());
				p2.setCplay("tma");
				PlayCount p = playCountMapper.getCplay(p2);
				lotterCountxg6hc(tma, p, price, order, "tma", str1, 1);
			}
			
			if (cplay.equals("tmb")) {
				PlayCount p2 = new PlayCount();
				p2.setCname(order.getCname());
				p2.setPeriod(order.getPeriod());
				p2.setCplay("tmb");
				PlayCount p = playCountMapper.getCplay(p2);
				lotterCountxg6hc(tmb, p, price, order, "tmb", str2, 1);
			}
			
			if (cplay.equals("tmsx")) {
				PlayCount p2 = new PlayCount();
				p2.setCname(order.getCname());
				p2.setPeriod(order.getPeriod());
				p2.setCplay("tmsx");
				PlayCount p = playCountMapper.getCplay(p2);
				lotterCountxg6hc(tmsx, p, price, order, "tmsx", str3, 2);
			}
			
			if (cplay.equals("dxds")) {
				PlayCount p2 = new PlayCount();
				p2.setCname(order.getCname());
				p2.setPeriod(order.getPeriod());
				p2.setCplay("dxds");
				PlayCount p = playCountMapper.getCplay(p2);
				lotterCountxg6hc(dxds, p, price, order, "dxds", str4, 3);
			}
			
			if (cplay.equals("jqys")) {
				PlayCount p2 = new PlayCount();
				p2.setCname(order.getCname());
				p2.setPeriod(order.getPeriod());
				p2.setCplay("jqys");
				PlayCount p = playCountMapper.getCplay(p2);
				lotterCountxg6hc(jqys, p, price, order, "jqys", str5, 4);
			}
			
			if (cplay.equals("ts")) {
				PlayCount p2 = new PlayCount();
				p2.setCname(order.getCname());
				p2.setPeriod(order.getPeriod());
				p2.setCplay("ts");
				PlayCount p = playCountMapper.getCplay(p2);
				lotterCountxg6hc(ts, p, price, order, "ts", str6, 5);
			}
			
			if (cplay.equals("ws")) {
				PlayCount p2 = new PlayCount();
				p2.setCname(order.getCname());
				p2.setPeriod(order.getPeriod());
				p2.setCplay("ws");
				PlayCount p = playCountMapper.getCplay(p2);
				lotterCountxg6hc(ws, p, price, order, "ws", str7, 6);
			}
			
			if (cplay.equals("wx")) {
				PlayCount p2 = new PlayCount();
				p2.setCname(order.getCname());
				p2.setPeriod(order.getPeriod());
				p2.setCplay("wx");
				PlayCount p = playCountMapper.getCplay(p2);
				lotterCountxg6hc(wx, p, price, order, "wx", str8, 7);
			}
			
			if (cplay.equals("zh")) {
				PlayCount p2 = new PlayCount();
				p2.setCname(order.getCname());
				p2.setPeriod(order.getPeriod());
				p2.setCplay("zh");
				PlayCount p = playCountMapper.getCplay(p2);
				lotterCountxg6hc(zhc, p, price, order, "zh", str9, 3);
			}
			
			if (cplay.equals("hs")) {
				PlayCount p2 = new PlayCount();
				p2.setCname(order.getCname());
				p2.setPeriod(order.getPeriod());
				p2.setCplay("hs");
				PlayCount p = playCountMapper.getCplay(p2);
				lotterCountxg6hc(hs, p, price, order, "hs", str10, 3);
			}
			
			if (cplay.equals("dp")) {
				PlayCount p2 = new PlayCount();
				p2.setCname(order.getCname());
				p2.setPeriod(order.getPeriod());
				p2.setCplay("dp");
				PlayCount p = playCountMapper.getCplay(p2);
				lotterCountxg6hc(dp, p, price, order, "dp", str11, 1);
			}
			
			if (cplay.equals("p2z2")) {
				PlayCount p2 = new PlayCount();
				p2.setCname(order.getCname());
				p2.setPeriod(order.getPeriod());
				p2.setCplay("p2z2");
				PlayCount p = playCountMapper.getCplay(p2);
				lotterCountxg6hc(p2z2, p, price, order, "p2z2", str12, 1);
			}
			
			if (cplay.equals("p3z3")) {
				PlayCount p2 = new PlayCount();
				p2.setCname(order.getCname());
				p2.setPeriod(order.getPeriod());
				p2.setCplay("p3z3");
				PlayCount p = playCountMapper.getCplay(p2);
				lotterCountxg6hc(p3z3, p, price, order, "p3z3", str13, 1);
			}
			
			if (cplay.equals("p3z2")) {
				PlayCount p2 = new PlayCount();
				p2.setCname(order.getCname());
				p2.setPeriod(order.getPeriod());
				p2.setCplay("p3z2");
				PlayCount p = playCountMapper.getCplay(p2);
				lotterCountxg6hc(p3z2, p, price, order, "p3z2", str14, 1);
			}
			
			if (cplay.equals("sxzt")) {
				PlayCount p2 = new PlayCount();
				p2.setCname(order.getCname());
				p2.setPeriod(order.getPeriod());
				p2.setCplay("sxzt");
				PlayCount p = playCountMapper.getCplay(p2);
				lotterCountxg6hc(sxzt, p, price, order, "sxzt", str15, 2);
			}
			
			if (cplay.equals("wxzt")) {
				PlayCount p2 = new PlayCount();
				p2.setCname(order.getCname());
				p2.setPeriod(order.getPeriod());
				p2.setCplay("wxzt");
				PlayCount p = playCountMapper.getCplay(p2);
				lotterCountxg6hc(wxzt, p, price, order, "wxzt", str16, 2);
			}
			
			if (cplay.equals("lxzt")) {
				PlayCount p2 = new PlayCount();
				p2.setCname(order.getCname());
				p2.setPeriod(order.getPeriod());
				p2.setCplay("lxzt");
				PlayCount p = playCountMapper.getCplay(p2);
				lotterCountxg6hc(lxzt, p, price, order, "lxzt", str17, 2);
			}
			
			if (cplay.equals("pt1x")) {
				PlayCount p2 = new PlayCount();
				p2.setCname(order.getCname());
				p2.setPeriod(order.getPeriod());
				p2.setCplay("pt1x");
				PlayCount p = playCountMapper.getCplay(p2);
				lotterCountxg6hc(pt1x, p, price, order, "pt1x", str18, 2);
			}
			
			if (cplay.equals("pt2x")) {
				PlayCount p2 = new PlayCount();
				p2.setCname(order.getCname());
				p2.setPeriod(order.getPeriod());
				p2.setCplay("pt2x");
				PlayCount p = playCountMapper.getCplay(p2);
				lotterCountxg6hc(pt2x, p, price, order, "pt2x", str19, 2);
			}

			if (cplay.equals("pt3x")) {
				PlayCount p2 = new PlayCount();
				p2.setCname(order.getCname());
				p2.setPeriod(order.getPeriod());
				p2.setCplay("pt3x");
				PlayCount p = playCountMapper.getCplay(p2);
				lotterCountxg6hc(pt3x, p, price, order, "pt3x", str20, 2);
			}

			if (cplay.equals("pt4x")) {
				PlayCount p2 = new PlayCount();
				p2.setCname(order.getCname());
				p2.setPeriod(order.getPeriod());
				p2.setCplay("pt4x");
				PlayCount p = playCountMapper.getCplay(p2);
				lotterCountxg6hc(pt4x, p, price, order, "pt4x", str21, 2);
			}

			
			if (cplay.equals("pt1w")) {
				PlayCount p2 = new PlayCount();
				p2.setCname(order.getCname());
				p2.setPeriod(order.getPeriod());
				p2.setCplay("pt1w");
				PlayCount p = playCountMapper.getCplay(p2);
				lotterCountxg6hc(pt1w, p, price, order, "pt1w", str22, 8);
			}

			if (cplay.equals("pt2w")) {
				PlayCount p2 = new PlayCount();
				p2.setCname(order.getCname());
				p2.setPeriod(order.getPeriod());
				p2.setCplay("pt2w");
				PlayCount p = playCountMapper.getCplay(p2);
				lotterCountxg6hc(pt2w, p, price, order, "pt2w", str23, 8);
			}

			if (cplay.equals("pt3w")) {
				PlayCount p2 = new PlayCount();
				p2.setCname(order.getCname());
				p2.setPeriod(order.getPeriod());
				p2.setCplay("pt3w");
				PlayCount p = playCountMapper.getCplay(p2);
				lotterCountxg6hc(pt3w, p, price, order, "pt3w", str24, 8);
			}
			if (cplay.equals("pt4w")) {
				PlayCount p2 = new PlayCount();
				p2.setCname(order.getCname());
				p2.setPeriod(order.getPeriod());
				p2.setCplay("pt4w");
				PlayCount p = playCountMapper.getCplay(p2);
				lotterCountxg6hc(pt4w, p, price, order, "pt4w", str25, 8);
			}
			if (cplay.equals("wbz")) {
				PlayCount p2 = new PlayCount();
				p2.setCname(order.getCname());
				p2.setPeriod(order.getPeriod());
				p2.setCplay("wbz");
				PlayCount p = playCountMapper.getCplay(p2);
				lotterCountxg6hc(wbz, p, price, order, "wbz", str26, 1);
			}
			if (cplay.equals("lbz")) {
				PlayCount p2 = new PlayCount();
				p2.setCname(order.getCname());
				p2.setPeriod(order.getPeriod());
				p2.setCplay("lbz");
				PlayCount p = playCountMapper.getCplay(p2);
				lotterCountxg6hc(lbz, p, price, order, "lbz", str27, 1);
			}
			if (cplay.equals("qbz")) {
				PlayCount p2 = new PlayCount();
				p2.setCname(order.getCname());
				p2.setPeriod(order.getPeriod());
				p2.setCplay("qbz");
				PlayCount p = playCountMapper.getCplay(p2);
				lotterCountxg6hc(qbz, p, price, order, "qbz", str28, 1);
			}
			if (cplay.equals("bbz")) {
				PlayCount p2 = new PlayCount();
				p2.setCname(order.getCname());
				p2.setPeriod(order.getPeriod());
				p2.setCplay("bbz");
				PlayCount p = playCountMapper.getCplay(p2);
				lotterCountxg6hc(bbz, p, price, order, "bbz", str29, 1);
			}
			
			if (cplay.equals("jbz")) {
				PlayCount p2 = new PlayCount();
				p2.setCname(order.getCname());
				p2.setPeriod(order.getPeriod());
				p2.setCplay("jbz");
				PlayCount p = playCountMapper.getCplay(p2);
				lotterCountxg6hc(jbz, p, price, order, "jbz", str30, 1);
			}
			
			if (cplay.equals("shbz")) {
				PlayCount p2 = new PlayCount();
				p2.setCname(order.getCname());
				p2.setPeriod(order.getPeriod());
				p2.setCplay("shbz");
				PlayCount p = playCountMapper.getCplay(p2);
				lotterCountxg6hc(shbz, p, price, order, "shbz", str31, 1);
			}
			
			if (cplay.equals("sh1bz")) {
				PlayCount p2 = new PlayCount();
				p2.setCname(order.getCname());
				p2.setPeriod(order.getPeriod());
				p2.setCplay("sh1bz");
				PlayCount p = playCountMapper.getCplay(p2);
				lotterCountxg6hc(sh1bz, p, price, order, "sh1bz", str32, 1);
			}
			
			if (cplay.equals("sh2bz")) {
				PlayCount p2 = new PlayCount();
				p2.setCname(order.getCname());
				p2.setPeriod(order.getPeriod());
				p2.setCplay("sh2bz");
				PlayCount p = playCountMapper.getCplay(p2);
				lotterCountxg6hc(sh2bz, p, price, order, "sh2bz", str33, 1);
			}
			
			if (cplay.equals("sh3bz")) {
				PlayCount p2 = new PlayCount();
				p2.setCname(order.getCname());
				p2.setPeriod(order.getPeriod());
				p2.setCplay("sh3bz");
				PlayCount p = playCountMapper.getCplay(p2);
				lotterCountxg6hc(sh3bz, p, price, order, "sh3bz", str34, 1);
			}
			
			if (cplay.equals("sh4bz")) {
				PlayCount p2 = new PlayCount();
				p2.setCname(order.getCname());
				p2.setPeriod(order.getPeriod());
				p2.setCplay("sh4bz");
				PlayCount p = playCountMapper.getCplay(p2);
				lotterCountxg6hc(sh4bz, p, price, order, "sh4bz", str35, 1);
			}
			
			if (cplay.equals("sh5bz")) {
				PlayCount p2 = new PlayCount();
				p2.setCname(order.getCname());
				p2.setPeriod(order.getPeriod());
				p2.setCplay("sh5bz");
				PlayCount p = playCountMapper.getCplay(p2);
				lotterCountxg6hc(sh5bz, p, price, order, "sh5bz", str36, 1);
			}
			
			if (cplay.equals("zx")) {
				PlayCount p2 = new PlayCount();
				p2.setCname(order.getCname());
				p2.setPeriod(order.getPeriod());
				p2.setCplay("zx");
				PlayCount p = playCountMapper.getCplay(p2);
				lotterCountxg6hc(zx, p, price, order, "zx", str37, 9);
			}
			
			if (cplay.equals("sb")) {
				PlayCount p2 = new PlayCount();
				p2.setCname(order.getCname());
				p2.setPeriod(order.getPeriod());
				p2.setCplay("sb");
				PlayCount p = playCountMapper.getCplay(p2);
				lotterCountxg6hc(sb, p, price, order, "sb", str38, 10);
			}
			
			if (cplay.equals("bb")) {
				PlayCount p2 = new PlayCount();
				p2.setCname(order.getCname());
				p2.setPeriod(order.getPeriod());
				p2.setCplay("bb");
				PlayCount p = playCountMapper.getCplay(p2);
				lotterCountxg6hc(bb, p, price, order, "bb", str39, 11);
			}
			
			if (cplay.equals("bbb")) {
				PlayCount p2 = new PlayCount();
				p2.setCname(order.getCname());
				p2.setPeriod(order.getPeriod());
				p2.setCplay("bbb");
				PlayCount p = playCountMapper.getCplay(p2);
				lotterCountxg6hc(bbb, p, price, order, "bbb", str40, 12);
			}
			
		case "jnd28":
			String[] hunhe = order.getStr1().split(","); 
			String[] tema = order.getStr2().split(","); 
			String[] tmb3 = order.getStr3().split(","); 
			String[] bs = order.getStr4().split(","); 
			String[] bz = order.getStr5().split(","); 
			
			if("hunhe".equals(cplay)){
				PlayCount p2 = new PlayCount();
				p2.setCname(order.getCname());
				p2.setPeriod(order.getPeriod());
				p2.setCplay("hunhe");
				PlayCount p = playCountMapper.getCplay(p2);
				lotterCountJnd28(hunhe, p, price, order, "hunhe", str1, 1);
			}
			if("tema".equals(cplay)){
				PlayCount p2 = new PlayCount();
				p2.setCname(order.getCname());
				p2.setPeriod(order.getPeriod());
				p2.setCplay("tema");
				PlayCount p = playCountMapper.getCplay(p2);
				lotterCountJnd28(tema, p, price, order, "tema", str2, 2);
			}
			if("tmb3".equals(cplay)){
				PlayCount p2 = new PlayCount();
				p2.setCname(order.getCname());
				p2.setPeriod(order.getPeriod());
				p2.setCplay("tmb3");
				PlayCount p = playCountMapper.getCplay(p2);
				lotterCountJnd28(tmb3, p, price, order, "tmb3", str3, 2);
			}
			if("bs".equals(cplay)){
				PlayCount p2 = new PlayCount();
				p2.setCname(order.getCname());
				p2.setPeriod(order.getPeriod());
				p2.setCplay("bs");
				PlayCount p = playCountMapper.getCplay(p2);
				lotterCountJnd28(bs, p, price, order, "bs", str4, 3);
			}
			if("bz".equals(cplay)){
				PlayCount p2 = new PlayCount();
				p2.setCname(order.getCname());
				p2.setPeriod(order.getPeriod());
				p2.setCplay("bz");
				PlayCount p = playCountMapper.getCplay(p2);
				lotterCountJnd28(bz, p, price, order, "bz", str5, 4);
			}
			break;
		}
		return 1;
	}

	/** 最大一期的期号 */
	@Override
	public Data getMaxPeriod(String cname) {
		return dataMapper.getMaxPeriod(cname);
	}

	/** 彩种当期下注用户 */
	@Override
	public List<Order> getOrderUser(Data data) {
		return orderMapper.getOrderUser(data);
	}

	@Override
	public List<Order> getMyOrdersAll(Integer id, Integer i) {
		return orderMapper.getMyOrdersAll(id, i);
	}

	/** 删除某个时间段的订单 */
	@Override
	public int delOrders(String date) {
		return orderMapper.delOrders(date);
	}

	/** 单条订单 */
	@Override
	public Order getOneOrder(Integer id) {
		return orderMapper.getOneOrder(id);
	}

	/** 每个彩种的打码量 */
	@Override
	public List<Order> getCnameDama(Integer id, String time) {
		return orderMapper.getCnameDama(id, time);
	}

	@Override
	public List<Order> findCheckOrder(Order order) {
		return orderMapper.findCheckOrder(order);
	}

	@Override
	public List<GcRebate> findAllGcRebate(String cname) {
		return gcRebateMapper.findAllGcRebate(cname);
	}

	@Override
	public int insertGcRebate(GcRebate gcRebate) {
		SimpleDateFormat ss = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		gcRebate.setCreated_time(ss.format(new Date()));
		return gcRebateMapper.insertGcRebate(gcRebate);
	}

	@Override
	public int updateByGcRebate(GcRebate gcRebate) {
		SimpleDateFormat ss = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		gcRebate.setCreated_time(ss.format(new Date()));
		return gcRebateMapper.updateByGcRebate(gcRebate);
	}

	@Override
	public int deleteshanchu(Integer id) {
		return gcRebateMapper.deleteshanchu(id);
	}

	@Override
	public List<Order> findByTimeDetails(String date) {
		return orderMapper.findByTimeDetails(date);
	}

	

	@Override
	public List<Order> findMyOrders(Integer startIndex, Integer lineCount, Integer id, Integer state, String cname,
			int i) {
		return orderMapper.findMyOrders(startIndex, lineCount, id, state, cname, i);
	}

	

	@Override
	public Integer getMhAllJlCounts(Order order,String date1,String date2) {
		return orderMapper.getMhAllJlCounts(order,date1,date2);
	}

	@Override
	public Integer findMyOrdersCounts(Order order) {
		return orderMapper.findMyOrdersCounts(order);
	}

	/***
	 * 
	 * 方法名：lotterCount 描述： 二分PK10彩种下注统计 TODO 
	 * 参数： @param str 下注玩法的属性 
	 * 参数： @param p 查询是否已经有记录了 
	 * 参数： @param price 下注的单注价格 
	 * 参数： @param order 订单信息 参数： @param cplay 下注的玩法名称 
	 * 参数： @param rebate 下注的赔率 
	 * 参数： @param type 玩法 的类型 
	 * 参数： @return
	 * 
	 * @return: int
	 */
	public int lotterCount2fpk10(String[] str, PlayCount p, Double price, Order order, String cplay, String rebate,
			Integer type) {
		PlayCount p1 = new PlayCount();
		if (p == null) {
			for (int i = 0; i < str.length; i++) {
				switch (type) {

				case 1:
					switch (str[i]) {
						case "单":
							p1.setDan(1);
							break;
						case "双":
							p1.setShuang(1);
							break;
						case "大":
							p1.setDa(1);
							break;
						case "小":
							p1.setDan(1);
							break;
						}
					break;
				case 2:
					switch (str[i]) {
						case "单":
							p1.setDan(1);
							break;
						case "双":
							p1.setShuang(1);
							break;
						case "大":
							p1.setDa(1);
							break;
						case "小":
							p1.setDan(1);
							break;
						case "龙":
							p1.setLongs(1);
							break;
						case "虎":
							p1.setHu(1);
							break;
						case "1":
							p1.setD1q(1);
							break;
						case "2":
							p1.setD2q(1);
							break;
						case "3":
							p1.setD3q(1);
							break;
						case "4":
							p1.setD4q(1);
							break;
						case "5":
							p1.setD5q(1);
							break;
						case "6":
							p1.setD6q(1);
							break;
						case "7":
							p1.setD7q(1);
							break;
						case "8":
							p1.setD8q(1);
							break;
						case "9":
							p1.setD9q(1);
							break;
						case "0":
							p1.setD10q(1);
							break;
					}
					break;
				case 3:
					switch (str[i]) {
						case "单":
							p1.setDan(1);
							break;
						case "双":
							p1.setShuang(1);
							break;
						case "大":
							p1.setDa(1);
							break;
						case "小":
							p1.setDan(1);
							break;
						case "1":
							p1.setD1q(1);
							break;
						case "2":
							p1.setD2q(1);
							break;
						case "3":
							p1.setD3q(1);
							break;
						case "4":
							p1.setD4q(1);
							break;
						case "5":
							p1.setD5q(1);
							break;
						case "6":
							p1.setD6q(1);
							break;
						case "7":
							p1.setD7q(1);
							break;
						case "8":
							p1.setD8q(1);
							break;
						case "9":
							p1.setD9q(1);
							break;
						case "0":
							p1.setD10q(1);
							break;
						}
					break;
				}
			}
			double money = ExChangeUtil.checkLotterMoney1(cplay, str, rebate.split(","), price);
			p1.setCname(order.getCname());
			p1.setPeriod(order.getPeriod());
			p1.setCplay(cplay);
			p1.setCount(1);
			p1.setPrice(price);
			p1.setRebate(ExChangeUtil.rebate(rebate));
			p1.setPayMoney(money);
			p1.setCreateTime(DateUtil.getCurrTime());
			playCountMapper.addPlayCount(p1);
		} else {
			for (int i = 0; i < str.length; i++) {
				switch (type) {
				case 1:
					switch (str[i]) {
					case "单":
						p1.setDan(p.getDan() + 1);
						break;
					case "双":
						p1.setShuang(p.getShuang() + 1);
						break;
					case "大":
						p1.setDa(p.getDa() + 1);
						break;
					case "小":
						p1.setDan(p.getXiao() + 1);
						break;
					case "1":
						p1.setD1q(p.getD1q() + 1);
						break;
					case "2":
						p1.setD2q(p.getD2q() + 1);
						break;
					case "3":
						p1.setD3q(p.getD3q() + 1);
						break;
					case "4":
						p1.setD4q(p.getD4q() + 1);
						break;
					case "5":
						p1.setD5q(p.getD5q() + 1);
						break;
					case "6":
						p1.setD6q(p.getD6q() + 1);
						break;
					case "7":
						p1.setD7q(p.getD7q() + 1);
						break;
					case "8":
						p1.setD8q(p.getD8q() + 1);
						break;
					case "9":
						p1.setD9q(p.getD9q() + 1);
						break;
					case "0":
						p1.setD10q(p.getD10q() + 1);
						break;
					}
					break;
				case 2:
					switch (str[i]) {
					case "1":
						p1.setD1q(p.getD1q() + 1);
						break;
					case "2":
						p1.setD2q(p.getD2q() + 1);
						break;
					case "3":
						p1.setD3q(p.getD3q() + 1);
						break;
					case "4":
						p1.setD4q(p.getD4q() + 1);
						break;
					case "5":
						p1.setD5q(p.getD5q() + 1);
						break;
					case "6":
						p1.setD6q(p.getD6q() + 1);
						break;
					case "7":
						p1.setD7q(p.getD7q() + 1);
						break;
					case "8":
						p1.setD8q(p.getD8q() + 1);
						break;
					case "9":
						p1.setD9q(p.getD9q() + 1);
						break;
					case "0":
						p1.setD10q(p.getD10q() + 1);
						break;
					}
					break;
				case 3:
					switch (str[i]) {
					case "豹子":
						p1.setBaozi(p.getBaozi() + 1);
						break;
					case "对子":
						p1.setShuang(p.getDuizi() + 1);
						break;
					case "顺子":
						p1.setDa(p.getShunzi() + 1);
						break;
					case "半顺":
						p1.setDan(p.getBanshun() + 1);
					case "杂六":
						p1.setDan(p.getZaliu() + 1);
						break;
					}
					break;
				case 4:
					switch (str[i]) {
					case "单":
						p1.setDan(p.getDan() + 1);
						break;
					case "双":
						p1.setShuang(p.getDan() + 1);
						break;
					case "大":
						p1.setDa(p.getDan() + 1);
						break;
					case "小":
						p1.setDan(p.getDan() + 1);
						break;
					case "龙":
						p1.setLongs(p.getDan() + 1);
						break;
					case "虎":
						p1.setHu(p.getDan() + 1);
						break;
					case "和":
						p1.setHe(p.getDan() + 1);
						break;
					}
					break;
				}
			}
			double money = ExChangeUtil.checkLotterMoney1(cplay, str, rebate.split(","), price);
			p1.setCname(order.getCname());
			p1.setPeriod(order.getPeriod());
			p1.setCplay(cplay);
			p1.setCount(p.getCount() + 1);
			p1.setPrice(p.getPrice() + price);
			p1.setPayMoney(p.getPayMoney() + money);
			playCountMapper.updatePlayCount(p1);
		}
		return 1;
	}

	/***
	 * 
	 * 方法名：lotterCount 描述： 二分时时彩彩种下注统计 TODO 参数： @param str 下注玩法的属性 参数： @param p
	 * 查询是否已经有记录了 参数： @param price 下注的单注价格 参数： @param order 订单信息 参数： @param cplay
	 * 下注的玩法名称 参数： @param rebate 下注的赔率 参数： @param type 玩法 的类型 参数： @return
	 * 
	 * @return: int
	 */
	public int lotterCount(String[] str, PlayCount p, Double price, Order order, String cplay, String rebate,
			Integer type) {
		PlayCount p1 = new PlayCount();
		if (p == null) {
			for (int i = 0; i < str.length; i++) {
				switch (type) {
				case 1:
					switch (str[i]) {
					case "单":
						p1.setDan(1);
						break;
					case "双":
						p1.setShuang(1);
						break;
					case "大":
						p1.setDa(1);
						break;
					case "小":
						p1.setDan(1);
						break;
					case "1":
						p1.setD1q(1);
						break;
					case "2":
						p1.setD2q(1);
						break;
					case "3":
						p1.setD3q(1);
						break;
					case "4":
						p1.setD4q(1);
						break;
					case "5":
						p1.setD5q(1);
						break;
					case "6":
						p1.setD6q(1);
						break;
					case "7":
						p1.setD7q(1);
						break;
					case "8":
						p1.setD8q(1);
						break;
					case "9":
						p1.setD9q(1);
						break;
					case "0":
						p1.setD10q(1);
						break;
					}
					break;
				case 2:
					switch (str[i]) {
					case "1":
						p1.setD1q(1);
						break;
					case "2":
						p1.setD2q(1);
						break;
					case "3":
						p1.setD3q(1);
						break;
					case "4":
						p1.setD4q(1);
						break;
					case "5":
						p1.setD5q(1);
						break;
					case "6":
						p1.setD6q(1);
						break;
					case "7":
						p1.setD7q(1);
						break;
					case "8":
						p1.setD8q(1);
						break;
					case "9":
						p1.setD9q(1);
						break;
					case "0":
						p1.setD10q(1);
						break;
					}
					break;
				case 3:
					switch (str[i]) {
					case "豹子":
						p1.setBaozi(1);
						break;
					case "对子":
						p1.setDuizi(1);
						break;
					case "顺子":
						p1.setShunzi(1);
						break;
					case "半顺":
						p1.setBanshun(1);
					case "杂六":
						p1.setZaliu(1);
						break;
					}
					break;
				case 4:
					switch (str[i]) {
					case "单":
						p1.setDan(1);
						break;
					case "双":
						p1.setShuang(1);
						break;
					case "大":
						p1.setDa(1);
						break;
					case "小":
						p1.setDan(1);
						break;
					case "龙":
						p1.setLongs(1);
						break;
					case "虎":
						p1.setHu(1);
						break;
					case "和":
						p1.setHe(1);
						break;
					}
					break;
				}
			}
			double money = ExChangeUtil.checkLotterMoney(cplay, str, rebate.split(","), price);
			p1.setCname(order.getCname());
			p1.setPeriod(order.getPeriod());
			p1.setCplay(cplay);
			p1.setCount(1);
			p1.setPrice(price);
			p1.setRebate(ExChangeUtil.rebate(rebate));
			p1.setPayMoney(money);
			p1.setCreateTime(DateUtil.getCurrTime());
			playCountMapper.addPlayCount(p1);
		} else {
			for (int i = 0; i < str.length; i++) {
				switch (type) {
				case 1:
					switch (str[i]) {
					case "单":
						p1.setDan(p.getDan() + 1);
						break;
					case "双":
						p1.setShuang(p.getShuang() + 1);
						break;
					case "大":
						p1.setDa(p.getDa() + 1);
						break;
					case "小":
						p1.setDan(p.getXiao() + 1);
						break;
					case "1":
						p1.setD1q(p.getD1q() + 1);
						break;
					case "2":
						p1.setD2q(p.getD2q() + 1);
						break;
					case "3":
						p1.setD3q(p.getD3q() + 1);
						break;
					case "4":
						p1.setD4q(p.getD4q() + 1);
						break;
					case "5":
						p1.setD5q(p.getD5q() + 1);
						break;
					case "6":
						p1.setD6q(p.getD6q() + 1);
						break;
					case "7":
						p1.setD7q(p.getD7q() + 1);
						break;
					case "8":
						p1.setD8q(p.getD8q() + 1);
						break;
					case "9":
						p1.setD9q(p.getD9q() + 1);
						break;
					case "0":
						p1.setD10q(p.getD10q() + 1);
						break;
					}
					break;
				case 2:
					switch (str[i]) {
					case "1":
						p1.setD1q(p.getD1q() + 1);
						break;
					case "2":
						p1.setD2q(p.getD2q() + 1);
						break;
					case "3":
						p1.setD3q(p.getD3q() + 1);
						break;
					case "4":
						p1.setD4q(p.getD4q() + 1);
						break;
					case "5":
						p1.setD5q(p.getD5q() + 1);
						break;
					case "6":
						p1.setD6q(p.getD6q() + 1);
						break;
					case "7":
						p1.setD7q(p.getD7q() + 1);
						break;
					case "8":
						p1.setD8q(p.getD8q() + 1);
						break;
					case "9":
						p1.setD9q(p.getD9q() + 1);
						break;
					case "0":
						p1.setD10q(p.getD10q() + 1);
						break;
					}
					break;
				case 3:
					switch (str[i]) {
					case "豹子":
						p1.setBaozi(p.getBaozi() + 1);
						break;
					case "对子":
						p1.setShuang(p.getDuizi() + 1);
						break;
					case "顺子":
						p1.setDa(p.getShunzi() + 1);
						break;
					case "半顺":
						p1.setDan(p.getBanshun() + 1);
					case "杂六":
						p1.setDan(p.getZaliu() + 1);
						break;
					}
					break;
				case 4:
					switch (str[i]) {
					case "单":
						p1.setDan(p.getDan() + 1);
						break;
					case "双":
						p1.setShuang(p.getDan() + 1);
						break;
					case "大":
						p1.setDa(p.getDan() + 1);
						break;
					case "小":
						p1.setDan(p.getDan() + 1);
						break;
					case "龙":
						p1.setLongs(p.getDan() + 1);
						break;
					case "虎":
						p1.setHu(p.getDan() + 1);
						break;
					case "和":
						p1.setHe(p.getDan() + 1);
						break;
					}
					break;
				}
			}
			double money = ExChangeUtil.checkLotterMoney(cplay, str, rebate.split(","), price);
			p1.setCname(order.getCname());
			p1.setPeriod(order.getPeriod());
			p1.setCplay(cplay);
			p1.setCount(p.getCount() + 1);
			p1.setPrice(p.getPrice() + price);
			p1.setPayMoney(p.getPayMoney() + money);
			playCountMapper.updatePlayCount(p1);
		}
		return 1;
	}

	/***
	 * 
	 * 方法名：lotterCount 
	 * 描述：三分快3 彩种下注统计 TODO 
	 * 参数： @param str 下注玩法的属性 
	 * 参数： @param p 查询是否已经有记录了
	 *  参数： @param price 下注的单注价格 
	 *  参数： @param order 订单信息 
	 *  参数： @param cplay 下注的玩法名称
	 *   参数： @param rebate 下注的赔率 
	 * 参数： @param type 玩法 的类型
	 *  参数： @return
	 * @return: int
	 */
	public int lotterCount3fk3(String[] str, PlayCount p, Double price, Order order, String cplay, String rebate,
			Integer type) {
		PlayCount p1 = new PlayCount();
		if (p == null) {
			for (int i = 0; i < str.length; i++) {
				switch (type) {
				case 1:
					switch (str[i]) {
						case "1":
							p1.setD1q(1);
							break;
						case "2":
							p1.setD2q(1);
							break;
						case "3":
							p1.setD3q(1);
							break;
						case "4":
							p1.setD4q(1);
							break;
						case "5":
							p1.setD5q(1);
							break;
						case "6":
							p1.setD6q(1);
							break;
					}
					break;
				case 2:
					if("三连号通选".equals(str[i]))
						p1.setSlhtx(1);
					break;
				case 3:
					switch (str[i]) {
					case "11":
						p1.setD1q(1);
						break;
					case "22":
						p1.setD2q(1);
						break;
					case "33":
						p1.setD3q(1);
						break;
					case "44":
						p1.setD4q(1);
						break;
					case "55":
						p1.setD5q(1);
						break;
					case "66":
						p1.setD6q(1);
						break;
					}
					break;
				case 4:
					if("三同号通选".equals(str[i]))
						p1.setSthtx(1);
					break;
				case 5:
					switch (str[i]) {
					case "111":
						p1.setD1q(1);
						break;
					case "222":
						p1.setD2q(1);
						break;
					case "333":
						p1.setD3q(1);
						break;
					case "444":
						p1.setD4q(1);
						break;
					case "555":
						p1.setD5q(1);
						break;
					case "666":
						p1.setD6q(1);
						break;
					}
					break;
				case 6:
					switch (str[i]) {
					case "豹子":
						p1.setBaozi(1);
						break;
					case "顺子":
						p1.setShunzi(1);
						break;
					case "对子":
						p1.setDuizi(1);
						break;
					case "半顺":
						p1.setBanshun(1);
						break;
					case "杂六":
						p1.setZaliu(1);
						break;
					}
					break;
				case 7:
					switch (str[i]) {
						case "单":
							p1.setDan(1);
							break;
						case "双":
							p1.setShuang(1);
							break;
						case "大":
							p1.setDa(1);
							break;
						case "小":
							p1.setXiao(1);
							break;
						case "3":
							p1.setD1q(1);
							break;
						case "4":
							p1.setD2q(1);
							break;
						case "5":
							p1.setD3q(1);
							break;
						case "6":
							p1.setD4q(1);
							break;
						case "7":
							p1.setD5q(1);
							break;
						case "8":
							p1.setD6q(1);
							break;
						case "9":
							p1.setD7q(1);
							break;
						case "10":
							p1.setD8q(1);
							break;
						case "11":
							p1.setD9q(1);
							break;
						case "12":
							p1.setD10q(1);
							break;
						case "13":
							p1.setD11q(1);
							break;
						case "14":
							p1.setD12q(1);
							break;
						case "15":
							p1.setD13q(1);
							break;
						case "16":
							p1.setD14q(1);
							break;
						case "17":
							p1.setD15q(1);
							break;
						case "18":
							p1.setD16q(1);
							break;
					}
					break;
				}
			}
			double money = ExChangeUtil.checkLotterMoney2(cplay, str, rebate.split(","), price);
			p1.setCname(order.getCname());
			p1.setPeriod(order.getPeriod());
			p1.setCplay(cplay);
			p1.setCount(1);
			p1.setPrice(price);
			p1.setRebate(ExChangeUtil.rebate(rebate));
			p1.setPayMoney(money);
			p1.setCreateTime(DateUtil.getCurrTime());
			playCountMapper.addPlayCount(p1);
		} else {
			for (int i = 0; i < str.length; i++) {
				switch (type) {
				case 1:
					switch (str[i]) {
						case "1":
							p1.setD1q(p.getD1q()+1);
							break;
						case "2":
							p1.setD2q(p.getD2q()+1);
							break;
						case "3":
							p1.setD3q(p.getD3q()+1);
							break;
						case "4":
							p1.setD4q(p.getD4q()+1);
							break;
						case "5":
							p1.setD5q(p.getD5q()+1);
							break;
						case "6":
							p1.setD6q(p.getD6q()+1);
							break;
					}
					break;
				case 2:
					if("三连号通选".equals(str[i]))
						p1.setSlhtx(p.getSlhtx()+1);
					break;
				case 3:
					switch (str[i]) {
					case "11":
						p1.setD1q(p.getD1q()+1);
						break;
					case "22":
						p1.setD2q(p.getD2q()+1);
						break;
					case "33":
						p1.setD3q(p.getD3q()+1);
						break;
					case "44":
						p1.setD4q(p.getD4q()+1);
						break;
					case "55":
						p1.setD5q(p.getD5q()+1);
						break;
					case "66":
						p1.setD6q(p.getD6q()+1);
						break;
					}
					break;
				case 4:
					if("三同号通选".equals(str[i]))
						p1.setSthtx(p.getSlhtx()+1);
					break;
				case 5:
					switch (str[i]) {
					case "111":
						p1.setD1q(p.getD1q()+1);
						break;
					case "222":
						p1.setD2q(p.getD2q()+1);
						break;
					case "333":
						p1.setD3q(p.getD3q()+1);
						break;
					case "444":
						p1.setD4q(p.getD4q()+1);
						break;
					case "555":
						p1.setD5q(p.getD5q()+1);
						break;
					case "666":
						p1.setD6q(p.getD6q()+1);
						break;
					}
					break;
				case 6:
					switch (str[i]) {
					case "豹子":
						p1.setBaozi(p.getBaozi()+1);
						break;
					case "顺子":
						p1.setShunzi(p.getShunzi()+1);
						break;
					case "对子":
						p1.setDuizi(p.getDuizi()+1);
						break;
					case "半顺":
						p1.setBanshun(p.getBanshun()+1);
						break;
					case "杂六":
						p1.setZaliu(p.getZaliu()+1);
						break;
					}
					break;
				case 7:
					switch (str[i]) {
						case "单":
							p1.setDan(p.getDan()+1);
							break;
						case "双":
							p1.setShuang(p.getShuang()+1);
							break;
						case "大":
							p1.setDa(p.getDa()+1);
							break;
						case "小":
							p1.setXiao(p.getXiao()+1);
							break;
						case "3":
							p1.setD1q(p.getD3q()+1);
							break;
						case "4":
							p1.setD2q(p.getD4q()+1);
							break;
						case "5":
							p1.setD3q(p.getD5q()+1);
							break;
						case "6":
							p1.setD4q(p.getD6q()+1);
							break;
						case "7":
							p1.setD5q(p.getD7q()+1);
							break;
						case "8":
							p1.setD6q(p.getD8q()+1);
							break;
						case "9":
							p1.setD7q(p.getD9q()+1);
							break;
						case "10":
							p1.setD8q(p.getD10q()+1);
							break;
						case "11":
							p1.setD9q(p.getD11q()+1);
							break;
						case "12":
							p1.setD10q(p.getD12q()+1);
							break;
						case "13":
							p1.setD11q(p.getD13q()+1);
							break;
						case "14":
							p1.setD12q(p.getD14q()+1);
							break;
						case "15":
							p1.setD13q(p.getD15q()+1);
							break;
						case "16":
							p1.setD14q(p.getD16q()+1);
							break;
						case "17":
							p1.setD15q(p.getD17q()+1);
							break;
						case "18":
							p1.setD16q(p.getD18q()+1);
							break;
					}
					break;
				}
			}
			double money = ExChangeUtil.checkLotterMoney2(cplay, str, rebate.split(","), price);
			p1.setCname(order.getCname());
			p1.setPeriod(order.getPeriod());
			p1.setCplay(cplay);
			p1.setCount(p.getCount() + 1);
			p1.setPrice(p.getPrice() + price);
			p1.setPayMoney(p.getPayMoney() + money);
			playCountMapper.updatePlayCount(p1);
		}
		return 1;
	}
	
	/***
	 * 
	 * 方法名：lotterCountxg6hc 
	 * 描述: 香港6合彩  彩种下注统计 TODO 
	 * 参数： @param str 下注玩法的属性 
	 * 参数： @param p 查询是否已经有记录了
	 *  参数： @param price 下注的单注价格 
	 *  参数： @param order 订单信息 
	 *  参数： @param cplay 下注的玩法名称
	 *   参数： @param rebate 下注的赔率 
	 * 参数： @param type 玩法 的类型
	 *  参数： @return
	 * @return: int
	 */
	public int lotterCountxg6hc(String[] str, PlayCount p, Double price, Order order, String cplay, String rebate,
			Integer type) {
		PlayCount p1 = new PlayCount();
		if (p == null) {
			for (int i = 0; i < str.length; i++) {
				switch (type) {
				case 1:
					switch (str[i]) {
						case "01":
							p1.setD1q(1);
							break;
						case "02":
							p1.setD2q(1);
							break;
						case "03":
							p1.setD3q(1);
							break;
						case "04":
							p1.setD4q(1);
							break;
						case "05":
							p1.setD5q(1);
							break;
						case "06":
							p1.setD6q(1);
							break;
						case "07":
							p1.setD7q(1);
							break;
						case "08":
							p1.setD8q(1);
							break;
						case "09":
							p1.setD9q(1);
							break;
						case "10":
							p1.setD10q(1);
							break;
						case "11":
							p1.setD11q(1);
							break;
						case "12":
							p1.setD12q(1);
							break;
						case "13":
							p1.setD13q(1);
							break;
						case "14":
							p1.setD14q(1);
							break;
						case "15":
							p1.setD15q(1);
							break;
						case "16":
							p1.setD16q(1);
							break;
						case "17":
							p1.setD17q(1);
							break;
						case "18":
							p1.setD18q(1);
							break;
						case "19":
							p1.setD19q(1);
							break;
						case "20":
							p1.setD20q(1);
							break;
						case "21":
							p1.setD21q(1);
							break;
						case "22":
							p1.setD22q(1);
							break;
						case "23":
							p1.setD23q(1);
							break;
						case "24":
							p1.setD24q(1);
							break;
						case "25":
							p1.setD25q(1);
							break;
						case "26":
							p1.setD26q(1);
							break;
						case "27":
							p1.setD27q(1);
							break;
						case "28":
							p1.setD28q(1);
							break;
						case "29":
							p1.setD29q(1);
							break;
						case "30":
							p1.setD30q(1);
							break;
						case "31":
							p1.setD31q(1);
							break;
						case "32":
							p1.setD32q(1);
							break;
						case "33":
							p1.setD33q(1);
							break;
						case "34":
							p1.setD34q(1);
							break;
						case "35":
							p1.setD35q(1);
							break;
						case "36":
							p1.setD36q(1);
							break;
						case "37":
							p1.setD37q(1);
							break;
						case "38":
							p1.setD38q(1);
							break;
						case "39":
							p1.setD39q(1);
							break;
						case "40":
							p1.setD40q(1);
							break;
						case "41":
							p1.setD41q(1);
							break;
						case "42":
							p1.setD42q(1);
							break;
						case "43":
							p1.setD43q(1);
							break;
						case "44":
							p1.setD44q(1);
							break;
						case "45":
							p1.setD45q(1);
							break;
						case "46":
							p1.setD46q(1);
							break;
						case "47":
							p1.setD47q(1);
							break;
						case "48":
							p1.setD48q(1);
							break;
						case "49":
							p1.setD49q(1);
							break;
					}
					break;
					
				case 2:
					switch (str[i]) {
					case "鼠":
					p1.setShu(1);	
						break;
					case "牛":
						p1.setNiu(1);	
						break;
					case "虎":
						p1.setHu(1);
						break;
					case "兔":
						p1.setTu(1);
						break;
					case "龙":
						p1.setLongs(1);
						break;
					case "蛇":
						p1.setShe(1);
						break;
					case "马":
						p1.setMa(1);
						break;
					case "羊":
						p1.setYang(1);
						break;
					case "猴":
						p1.setHou(1);
						break;
					case "鸡":
						p1.setJi(1);
						break;
					case "狗":
						p1.setGou(1);
						break;
					case "猪":
						p1.setZhu(1);
						break;
					}
					
					break;
					
				case 3:
					switch (str[i]) {
						case "单":
						p1.setDan(1);	
							break;
						case "双":
						p1.setShuang(1);	
							break;
						case "大":
						p1.setDa(1);	
							break;
						case "小":
						p1.setDixiao(1);	
							break;
					}
					
					break;
					
				case 4:
					switch (str[i]) {
					case "家肖":
					p1.setDan(1);	
						break;
					case "野肖":
					p1.setShuang(1);	
						break;
					case "天肖":
					p1.setDa(1);	
						break;
					case "地肖":
					p1.setDixiao(1);	
						break;
					}
					break;
					
				case 5:
					switch (str[i]) {
					case "0头":
					p1.setLingtou(1);	
						break;
					case "1头":
					p1.setYitou(1);	
						break;
					case "2头":
					p1.setErtou(1);	
						break;
					case "3头":
					p1.setSantou(1);	
						break;
					case "4头":
						p1.setSitou(1);	
						break;
					}
					break;
					
				case 6:
					switch (str[i]) {
					case "0尾":
						p1.setLingwei(1);	
						break;
					case "1尾":
						p1.setYiwei(1);	
						break;
					case "2尾":
						p1.setErwei(1);	
						break;
					case "3尾":
						p1.setSanwei(1);	
						break;
					case "4尾":
						p1.setSiwei(1);	
						break;
					case "5尾":
						p1.setWuwei(1);	
						break;
					case "6尾":
						p1.setLiuwei(1);	
						break;
					case "7尾":
						p1.setQiwei(1);	
						break;
					case "8尾":
						p1.setBawei(1);	
						break;
					case "9尾":
						p1.setJiuwei(1);	
						break;
					case "大":
						p1.setDa(1);	
						break;
					case "小":
						p1.setXiao(1);	
						break;
					case "单":
						p1.setDan(1);	
						break;
					case "双":
						p1.setShuang(1);	
						break;
					
					}
					break;
					
				case 7:
					switch (str[i]) {
						case "金":
							p1.setJin(1);	
							break;
						case "木":
							p1.setMu(1);	
							break;
						case "水":
							p1.setShui(1);	
							break;
						case "火":
							p1.setHuo(1);	
							break;
						case "土":
							p1.setTus(1);	
							break;
					}
					break;
				case 8:
					switch (str[i]) {
					case "0":
						p1.setD1q(1);
						break;
					case "1":
						p1.setD2q(1);
						break;
					case "2":
						p1.setD3q(1);
						break;
					case "3":
						p1.setD4q(1);
						break;
					case "4":
						p1.setD5q(1);
						break;
					case "5":
						p1.setD6q(1);
						break;
					case "6":
						p1.setD7q(1);
						break;
					case "7":
						p1.setD8q(1);
						break;
					case "8":
						p1.setD9q(1);
						break;
					case "9":
						p1.setD10q(1);
						break;
					}
					break;
				case 9:
					switch (str[i]) {
					case "2肖":
						p1.setErxiao(1);
						break;
					case "3肖":
						p1.setSanxiao(1);
						break;
					case "4肖":
						p1.setSixiao(1);
						break;
					case "5肖":
						p1.setWuxiao(1);
						break;
					case "6肖":
						p1.setLiuxiao(1);
						break;
					case "7肖":
						p1.setQixiao(1);
						break;
					case "单":
						p1.setDan(1);
						break;
					case "双":
						p1.setShuang(1);
						break;
					}
					break;
				case 10:
					switch (str[i]) {
					case "红波":
						p1.setHongbo(1);
						break;
					case "蓝波":
						p1.setLanbo(1);
						break;
					case "绿波":
						p1.setLvbo(1);
						break;
					}
					
					break;
				case 11:
					switch (str[i]) {
					case "红大":
						p1.setHongda(1);
						break;
					case "红小":
						p1.setHongxiao(1);
						break;
					case "红单":
						p1.setHongdan(1);
						break;
					case "红双":
						p1.setHongshuang(1);
						break;
					case "蓝大":
						p1.setLanda(1);
						break;
					case "蓝小":
						p1.setLanxiao(1);
						break;
					case "蓝单":
						p1.setLandan(1);
						break;
					case "蓝双":
						p1.setLanshuang(1);
						break;
					case "绿大":
						p1.setLvda(1);
						break;
					case "绿小":
						p1.setLvxiao(1);
						break;
					case "绿单":
						p1.setLvdan(1);
						break;
					case "绿双":
						p1.setLvshuang(1);
						break;
					}
					break;
					
				case 12:
					switch (str[i]) {
					case "红大单":
						p1.setHongdadan(1);
						break;
					case "红大双":
						p1.setHongdashuang(1);
						break;
					case "红小单":
						p1.setHongxiaodan(1);
						break;
					case "红小双":
						p1.setHongxiaoshuang(1);
						break;
					case "蓝大单":
						p1.setLandadan(1);
						break;
					case "蓝大双":
						p1.setLandashuang(1);
						break;
					case "蓝小单":
						p1.setLanxiaodan(1);
						break;
					case "蓝小双":
						p1.setLanxiaoshuang(1);
						break;
					case "绿大单":
						p1.setLandadan(1);
						break;
					case "绿大双":
						p1.setLvdashuang(1);
						break;
					case "绿小单":
						p1.setLvxiaodan(1);
						break;
					case "绿小双":
						p1.setLvxiaoshuang(1);
						break;
					}
					break;
				}
			}
			double money = ExChangeUtil.checkLotterMoney3(cplay, str, rebate.split(","), price);
			p1.setCname(order.getCname());
			p1.setPeriod(order.getPeriod());
			p1.setCplay(cplay);
			p1.setCount(1);
			p1.setPrice(price);
			p1.setRebate(ExChangeUtil.rebate(rebate));
			p1.setPayMoney(money);
			p1.setCreateTime(DateUtil.getCurrTime());
			playCountMapper.addPlayCount(p1);
		} else {
			for (int i = 0; i < str.length; i++) {
				switch (type) {
				case 1:
					switch (str[i]) {
						case "01":
							p1.setD1q(p.getD1q()+1);
							break;
						case "02":
							p1.setD2q(p.getD2q()+1);
							break;
						case "03":
							p1.setD3q(p.getD3q()+1);
							break;
						case "04":
							p1.setD4q(p.getD4q()+1);
							break;
						case "05":
							p1.setD5q(p.getD5q()+1);
							break;
						case "06":
							p1.setD6q(p.getD6q()+1);
							break;
						case "07":
							p1.setD7q(p.getD7q()+1);
							break;
						case "08":
							p1.setD8q(p.getD8q()+1);
							break;
						case "09":
							p1.setD9q(p.getD9q()+1);
							break;
						case "10":
							p1.setD10q(p.getD10q()+1);
							break;
						case "11":
							p1.setD11q(p.getD11q()+1);
							break;
						case "12":
							p1.setD12q(p.getD12q()+1);
							break;
						case "13":
							p1.setD13q(p.getD13q()+1);
							break;
						case "14":
							p1.setD14q(p.getD14q()+1);
							break;
						case "15":
							p1.setD15q(p.getD15q()+1);
							break;
						case "16":
							p1.setD16q(p.getD16q()+1);
							break;
						case "17":
							p1.setD17q(p.getD17q()+1);
							break;
						case "18":
							p1.setD18q(p.getD18q()+1);
							break;
						case "19":
							p1.setD19q(p.getD19q()+1);
							break;
						case "20":
							p1.setD20q(p.getD20q()+1);
							break;
						case "21":
							p1.setD21q(p.getD21q()+1);
							break;
						case "22":
							p1.setD22q(p.getD22q()+1);
							break;
						case "23":
							p1.setD23q(p.getD23q()+1);
							break;
						case "24":
							p1.setD24q(p.getD24q()+1);
							break;
						case "25":
							p1.setD25q(p.getD25q()+1);
							break;
						case "26":
							p1.setD26q(p.getD26q()+1);
							break;
						case "27":
							p1.setD27q(p.getD27q()+1);
							break;
						case "28":
							p1.setD28q(p.getD28q()+1);
							break;
						case "29":
							p1.setD29q(p.getD29q()+1);
							break;
						case "30":
							p1.setD30q(p.getD30q()+1);
							break;
						case "31":
							p1.setD31q(p.getD31q()+1);
							break;
						case "32":
							p1.setD32q(p.getD32q()+1);
							break;
						case "33":
							p1.setD33q(p.getD33q()+1);
							break;
						case "34":
							p1.setD34q(p.getD34q()+1);
							break;
						case "35":
							p1.setD35q(p.getD35q()+1);
							break;
						case "36":
							p1.setD36q(p.getD36q()+1);
							break;
						case "37":
							p1.setD37q(p.getD37q()+1);
							break;
						case "38":
							p1.setD38q(p.getD38q()+1);
							break;
						case "39":
							p1.setD39q(p.getD39q()+1);
							break;
						case "40":
							p1.setD40q(p.getD40q()+1);
							break;
						case "41":
							p1.setD41q(p.getD41q()+1);
							break;
						case "42":
							p1.setD42q(p.getD42q()+1);
							break;
						case "43":
							p1.setD43q(p.getD43q()+1);
							break;
						case "44":
							p1.setD44q(p.getD44q()+1);
							break;
						case "45":
							p1.setD45q(p.getD45q()+1);
							break;
						case "46":
							p1.setD46q(p.getD46q()+1);
							break;
						case "47":
							p1.setD47q(p.getD47q()+1);
							break;
						case "48":
							p1.setD48q(p.getD48q()+1);
							break;
						case "49":
							p1.setD49q(p.getD49q()+1);
							break;
					}
					break;
					
				case 2:
					switch (str[i]) {
					case "鼠":
					p1.setShu(p.getShu()+1);	
						break;
					case "牛":
						p1.setNiu(p.getNiu()+1);	
						break;
					case "虎":
						p1.setHu(p.getHu()+1);
						break;
					case "兔":
						p1.setTu(p.getTu()+1);
						break;
					case "龙":
						p1.setLongs(p.getLongs()+1);
						break;
					case "蛇":
						p1.setShe(p.getShe()+1);
						break;
					case "马":
						p1.setMa(p.getMa()+1);
						break;
					case "羊":
						p1.setYang(p.getYang()+1);
						break;
					case "猴":
						p1.setHou(p.getHou()+1);
						break;
					case "鸡":
						p1.setJi(p.getJi()+1);
						break;
					case "狗":
						p1.setGou(p.getGou()+1);
						break;
					case "猪":
						p1.setZhu(p.getZhu()+1);
						break;
					}
					
					break;
					
				case 3:
					switch (str[i]) {
						case "单":
						p1.setDan(p.getDan()+1);	
							break;
						case "双":
						p1.setShuang(p.getShuang()+1);	
							break;
						case "大":
						p1.setDa(p.getDa()+1);	
							break;
						case "小":
						p1.setXiao(p.getXiao()+1);	
							break;
					}
					break;
					
				case 4:
					switch (str[i]) {
					case "家肖":
					p1.setJiaxiao(p.getJiaxiao()+1);	
						break;
					case "野肖":
					p1.setYexiao(p.getYexiao()+1);	
						break;
					case "天肖":
					p1.setTianxiao(p.getTianxiao()+1);	
						break;
					case "地肖":
					p1.setDixiao(p.getDixiao()+1);	
						break;
					}
					break;
					
				case 5:
					switch (str[i]) {
					case "0头":
					p1.setLingtou(p.getLingtou()+1);	
						break;
					case "1头":
					p1.setYitou(p.getYitou()+1);	
						break;
					case "2头":
					p1.setErtou(p.getErtou()+1);	
						break;
					case "3头":
					p1.setSantou(p.getSantou()+1);	
						break;
					case "4头":
						p1.setSitou(p.getSitou()+1);	
						break;
					}
					break;
					
				case 6:
					switch (str[i]) {
					case "0尾":
						p1.setLingwei(p.getLingwei()+1);	
						break;
					case "1尾":
						p1.setYiwei(p.getYiwei()+1);	
						break;
					case "2尾":
						p1.setErwei(p.getErwei()+1);	
						break;
					case "3尾":
						p1.setSanwei(p.getSanwei()+1);	
						break;
					case "4尾":
						p1.setSiwei(p.getSiwei()+1);	
						break;
					case "5尾":
						p1.setWuwei(p.getWuwei()+1);	
						break;
					case "6尾":
						p1.setLiuwei(p.getLiuwei()+1);	
						break;
					case "7尾":
						p1.setQiwei(p.getQiwei()+1);	
						break;
					case "8尾":
						p1.setBawei(p.getBawei()+1);	
						break;
					case "9尾":
						p1.setJiuwei(p.getJiuwei()+1);	
						break;
					case "大":
						p1.setDa(p.getDa()+1);	
						break;
					case "小":
						p1.setXiao(p.getXiao()+1);	
						break;
					case "单":
						p1.setDan(p.getDan()+1);	
						break;
					case "双":
						p1.setShuang(p.getShuang()+1);	
						break;
					
					}
					break;
					
				case 7:
					switch (str[i]) {
						case "金":
							p1.setJin(p.getJin()+1);	
							break;
						case "木":
							p1.setMu(p.getMu()+1);	
							break;
						case "水":
							p1.setShui(p.getShui()+1);	
							break;
						case "火":
							p1.setHuo(p.getHuo()+1);	
							break;
						case "土":
							p1.setTus(p.getTus()+1);	
							break;
					}
					break;
				case 8:
					switch (str[i]) {
					case "0":
						p1.setD1q(p.getD1q()+1);
						break;
					case "1":
						p1.setD2q(p.getD2q()+1);
						break;
					case "2":
						p1.setD3q(p.getD3q()+1);
						break;
					case "3":
						p1.setD4q(p.getD4q()+1);
						break;
					case "4":
						p1.setD5q(p.getD5q()+1);
						break;
					case "5":
						p1.setD6q(p.getD6q()+1);
						break;
					case "6":
						p1.setD7q(p.getD7q()+1);
						break;
					case "7":
						p1.setD8q(p.getD8q()+1);
						break;
					case "8":
						p1.setD9q(p.getD9q()+1);
						break;
					case "9":
						p1.setD10q(p.getD10q()+1);
						break;
					}
					break;
				case 9:
					switch (str[i]) {
					case "2肖":
						p1.setErxiao(p.getErxiao()+1);
						break;
					case "3肖":
						p1.setSanxiao(p.getSanxiao()+1);
						break;
					case "4肖":
						p1.setSixiao(p.getSixiao()+1);
						break;
					case "5肖":
						p1.setWuxiao(p.getWuxiao()+1);
						break;
					case "6肖":
						p1.setLiuxiao(p.getLiuxiao()+1);
						break;
					case "7肖":
						p1.setQixiao(p.getQixiao()+1);
						break;
					case "单":
						p1.setDan(p.getDan()+1);
						break;
					case "双":
						p1.setShuang(p.getShuang()+1);
						break;
					}
					break;
				case 10:
					switch (str[i]) {
					case "红波":
						p1.setHongbo(p.getHongbo()+1);
						break;
					case "蓝波":
						p1.setLanbo(p.getLanbo()+1);
						break;
					case "绿波":
						p1.setLvbo(p.getLvbo()+1);
						break;
					}
					
					break;
				case 11:
					switch (str[i]) {
					case "红大":
						p1.setHongda(p.getHongda()+1);
						break;
					case "红小":
						p1.setHongxiao(p.getHongxiao()+1);
						break;
					case "红单":
						p1.setHongdan(p.getHongdan()+1);
						break;
					case "红双":
						p1.setHongshuang(p.getHongshuang()+1);
						break;
					case "蓝大":
						p1.setLanda(p.getLanda()+1);
						break;
					case "蓝小":
						p1.setLanxiao(p.getLanxiao()+1);
						break;
					case "蓝单":
						p1.setLandan(p.getLandan()+1);
						break;
					case "蓝双":
						p1.setLanshuang(p.getLanshuang()+1);
						break;
					case "绿大":
						p1.setLvda(p.getLvda()+1);
						break;
					case "绿小":
						p1.setLvxiao(p.getLvxiao()+1);
						break;
					case "绿单":
						p1.setLvdan(p.getLvdan()+1);
						break;
					case "绿双":
						p1.setLvshuang(p.getLvshuang()+1);
						break;
					}
					break;
					
				case 12:
					switch (str[i]) {
					case "红大单":
						p1.setHongdadan(p.getHongdadan()+1);
						break;
					case "红大双":
						p1.setHongdashuang(p.getHongdashuang()+1);
						break;
					case "红小单":
						p1.setHongxiaodan(p.getHongxiaodan()+1);
						break;
					case "红小双":
						p1.setHongxiaoshuang(p.getHongxiaoshuang()+1);
						break;
					case "蓝大单":
						p1.setLandadan(p.getLandadan()+1);
						break;
					case "蓝大双":
						p1.setLandashuang(p.getLandashuang()+1);
						break;
					case "蓝小单":
						p1.setLanxiaodan(p.getLanxiaodan()+1);
						break;
					case "蓝小双":
						p1.setLanxiaoshuang(p.getLanxiaoshuang()+1);
						break;
					case "绿大单":
						p1.setLandadan(p.getLandadan()+1);
						break;
					case "绿大双":
						p1.setLvdashuang(p.getLvdashuang()+1);
						break;
					case "绿小单":
						p1.setLvxiaodan(p.getLvxiaodan()+1);
						break;
					case "绿小双":
						p1.setLvxiaoshuang(p.getLvxiaoshuang()+1);
						break;
					}
					break;
				}
			}
			double money = ExChangeUtil.checkLotterMoney3(cplay, str, rebate.split(","), price);
			p1.setCname(order.getCname());
			p1.setPeriod(order.getPeriod());
			p1.setCplay(cplay);
			p1.setCount(p.getCount() + 1);
			p1.setPrice(p.getPrice() + price);
			p1.setPayMoney(p.getPayMoney() + money);
			playCountMapper.updatePlayCount(p1);
		}
		return 1;
	}
	
	
	/**
	 * 
	   * 方法名：lotterCountJnd28   
	   * 描述： 加拿大28 下注统计                      TODO   
	   * 参数： @param str 下注玩法的属性 
	   * 参数： @param p 查询是否已经有记录了
	   * 参数： @param price 下注的单注价格 
	   * 参数： @param order 订单信息 
	   * 参数： @param cplay 下注的玩法名称
	   * 参数： @param rebate 下注的赔率 
	   * 参数： @param type 玩法 的类型
	   * 参数： @return 
	 * @return: int
	 */
	public int lotterCountJnd28(String[] str, PlayCount p, Double price, Order order, String cplay, String rebate,
			Integer type) {
		PlayCount p1 = new PlayCount();
		if (p == null) {
			for (int i = 0; i < str.length; i++) {
				switch (type) {
				case 1:
					switch (str[i]) {
						case "大":
							p1.setDa(1);
							break;
						case "小":
							p1.setXiao(1);
							break;
						case "单":
							p1.setDan(1);
							break;
						case "双":
							p1.setShuang(1);
							break;
						case "大单":
							p1.setDadan(1);
							break;
						case "大双":
							p1.setDashuang(1);
							break;
						case "小单":
							p1.setXiaodan(1);
							break;
						case "小双":
							p1.setXiaoshuang(1);
							break;
						case "极大":
							p1.setJida(1);
							break;
						case "极小":
							p1.setJiaxiao(1);
							break;
					}
					break;
				case 2:
					switch (str[i]) {
					case "0":
						p1.setD1q(1);
						break;
					case "1":
						p1.setD2q(1);
						break;
					case "2":
						p1.setD3q(1);
						break;
					case "3":
						p1.setD4q(1);
						break;
					case "4":
						p1.setD5q(1);
						break;
					case "5":
						p1.setD6q(1);
						break;
					case "6":
						p1.setD7q(1);
						break;
					case "7":
						p1.setD8q(1);
						break;
					case "8":
						p1.setD9q(1);
						break;
					case "9":
						p1.setD10q(1);
						break;
					case "10":
						p1.setD11q(1);
						break;
					case "11":
						p1.setD12q(1);
						break;
					case "12":
						p1.setD13q(1);
						break;
					case "13":
						p1.setD14q(1);
						break;
					case "14":
						p1.setD15q(1);
						break;
					case "15":
						p1.setD16q(1);
						break;
					case "16":
						p1.setD17q(1);
						break;
					case "17":
						p1.setD18q(1);
						break;
					case "18":
						p1.setD19q(1);
						break;
					case "19":
						p1.setD20q(1);
						break;
					case "20":
						p1.setD21q(1);
						break;
					case "21":
						p1.setD22q(1);
						break;
					case "22":
						p1.setD23q(1);
						break;
					case "23":
						p1.setD24q(1);
						break;
					case "24":
						p1.setD25q(1);
						break;
					case "25":
						p1.setD26q(1);
						break;
					case "26":
						p1.setD27q(1);
						break;
					case "27":
						p1.setD28q(1);
						break;
					}
				case 3:
					switch (str[i]) {
					case "红波":
						p1.setHongbo(1);
						break;
					case "绿波":
						p1.setLvbo(1);
						break;
					case "蓝波":
						p1.setLanbo(1);
						break;
					}
					break;
				case 4:
					if("豹子".equals(str[i]))
						p1.setBaozi(1);
					break;
				}
			}
			double money = ExChangeUtil.checkLotterMoney4(cplay, str, rebate.split(","), price);
			p1.setCname(order.getCname());
			p1.setPeriod(order.getPeriod());
			p1.setCplay(cplay);
			p1.setCount(1);
			p1.setPrice(price);
			p1.setRebate(ExChangeUtil.rebate(rebate));
			p1.setPayMoney(money);
			p1.setCreateTime(DateUtil.getCurrTime());
			playCountMapper.addPlayCount(p1);
		} else {
			for (int i = 0; i < str.length; i++) {
				switch (type) {
				case 1:
					switch (str[i]) {
					case "大":
						p1.setDa(p.getDa()+1);
						break;
					case "小":
						p1.setXiao(p.getXiao()+1);
						break;
					case "单":
						p1.setDan(p.getDan()+1);
						break;
					case "双":
						p1.setShuang(p.getShuang()+1);
						break;
					case "大单":
						p1.setDadan(p.getDadan()+1);
						break;
					case "大双":
						p1.setDashuang(p.getDashuang()+1);
						break;
					case "小单":
						p1.setXiaodan(p.getXiaodan()+1);
						break;
					case "小双":
						p1.setXiaoshuang(p.getXiaoshuang()+1);
						break;
					case "极大":
						p1.setJida(p.getJida()+1);
						break;
					case "极小":
						p1.setJiaxiao(p.getJiaxiao()+1);
						break;
					}
					break;
				case 2:
					switch (str[i]) {
					case "0":
						p1.setD1q(p.getD1q()+1);
						break;
					case "1":
						p1.setD2q(p.getD2q()+1);
						break;
					case "2":
						p1.setD3q(p.getD3q()+1);
						break;
					case "3":
						p1.setD4q(p.getD4q()+1);
						break;
					case "4":
						p1.setD5q(p.getD5q()+1);
						break;
					case "5":
						p1.setD6q(p.getD6q()+1);
						break;
					case "6":
						p1.setD7q(p.getD7q()+1);
						break;
					case "7":
						p1.setD8q(p.getD8q()+1);
						break;
					case "8":
						p1.setD9q(p.getD9q()+1);
						break;
					case "9":
						p1.setD10q(p.getD10q()+1);
						break;
					case "10":
						p1.setD11q(p.getD11q()+1);
						break;
					case "11":
						p1.setD12q(p.getD12q()+1);
						break;
					case "12":
						p1.setD13q(p.getD13q()+1);
						break;
					case "13":
						p1.setD14q(p.getD14q()+1);
						break;
					case "14":
						p1.setD15q(p.getD15q()+1);
						break;
					case "15":
						p1.setD16q(p.getD16q()+1);
						break;
					case "16":
						p1.setD17q(p.getD17q()+1);
						break;
					case "17":
						p1.setD18q(p.getD18q()+1);
						break;
					case "18":
						p1.setD19q(p.getD19q()+1);
						break;
					case "19":
						p1.setD20q(p.getD20q()+1);
						break;
					case "20":
						p1.setD21q(p.getD21q()+1);
						break;
					case "21":
						p1.setD22q(p.getD22q()+1);
						break;
					case "22":
						p1.setD23q(p.getD23q()+1);
						break;
					case "23":
						p1.setD24q(p.getD24q()+1);
						break;
					case "24":
						p1.setD25q(p.getD25q()+1);
						break;
					case "25":
						p1.setD26q(p.getD26q()+1);
						break;
					case "26":
						p1.setD27q(p.getD27q()+1);
						break;
					case "27":
						p1.setD28q(p.getD28q()+1);
						break;
					}
					break;
				case 3:
					switch (str[i]) {
					case "红波":
						p1.setHongbo(p.getHongbo()+1);
						break;
					case "绿波":
						p1.setLvbo(p.getLvbo()+1);
						break;
					case "蓝波":
						p1.setLanbo(p.getLanbo()+1);
						break;
					}
					break;
				case 4:
					if("豹子".equals(str[i]))
						p1.setBaozi(p.getBaozi()+1);
					break;
				}
			}
			double money = ExChangeUtil.checkLotterMoney4(cplay, str, rebate.split(","), price);
			p1.setCname(order.getCname());
			p1.setPeriod(order.getPeriod());
			p1.setCplay(cplay);
			p1.setCount(p.getCount() + 1);
			p1.setPrice(p.getPrice() + price);
			p1.setPayMoney(p.getPayMoney() + money);
			playCountMapper.updatePlayCount(p1);
		}
		return 1;
	}
	
	
	@Override
	public List<Order> Inquiries(String period, String cName) {
		return orderMapper.Inquiries(period, cName);
	}

	@Override
	public int findOrderNumberCount(String startTime, String endTime) {
		return orderMapper.findOrderNumberCount(startTime,endTime,"",-1);
	}

	@Override
	public GcRebate findByIdGcRebateInfo(Integer id) {
		return gcRebateMapper.findByIdGcRebateInfo(id);
	}

	@Override
	public List<Orders> getxzdatas(String cname) {
		return orderMapper.getxzdatas(cname);
	}

	@Override
	public JsonResult calculateBettingCount(Order o) {
				LotterExample lotters = lotterMapper.getLotterByCname(o.getCname());
				String str1 = lotters.getRebate1();
				String str2 = lotters.getRebate2();
				String str3 = lotters.getRebate3();
				String str4 = lotters.getRebate4();
				String str5 = lotters.getRebate5();
				String str6 = lotters.getRebate6();
				String str7 = lotters.getRebate7();
				String str8 = lotters.getRebate8();
				String str9 = lotters.getRebate9();
				String str10 = lotters.getRebate10();
				String str11 = lotters.getRebate11();
				String str12 = lotters.getRebate12();
				String str13 = lotters.getRebate13();
				String str14 = lotters.getRebate14();
				String str15 = lotters.getRebate15();
				String str16 = lotters.getRebate16();
				String str17 = lotters.getRebate17();
				String str18 = lotters.getRebate18();
				String str19 = lotters.getRebate19();
				String str20 = lotters.getRebate20();
				String str21 = lotters.getRebate21();
				String str22 = lotters.getRebate22();
				String str26 = lotters.getRebate26();
				String str27 = lotters.getRebate27();
				String str28 = lotters.getRebate28();
				String str29 = lotters.getRebate29();
				String str30 = lotters.getRebate30();
				String str31 = lotters.getRebate31();
				String str32 = lotters.getRebate32();
				String str33 = lotters.getRebate33();
				String str34 = lotters.getRebate34();
				String str35 = lotters.getRebate35();
				String str36 = lotters.getRebate36();
				String message = "";
				String[] pv1 = lotters.getRebate1().split(",");
				String[] pv2 = lotters.getRebate2().split(",");
				String[] pv3 = lotters.getRebate3().split(",");
				String[] pv4 = lotters.getRebate4().split(",");
				String[] pv5 = lotters.getRebate5().split(",");
				String[] pv6 = lotters.getRebate6().split(",");
				String[] pv7 = lotters.getRebate7().split(",");
				String[] pv8 = lotters.getRebate8().split(",");
				String[] pv9 = lotters.getRebate9().split(",");
				String[] pv10 = lotters.getRebate10().split(",");
				String[] pv11 = lotters.getRebate11().split(",");
				String[] pv15 = lotters.getRebate15().split(",");
				String[] pv16 = lotters.getRebate16().split(",");
				String[] pv17 = lotters.getRebate17().split(",");
				String[] pv18 = lotters.getRebate18().split(",");
				String[] pv19 = lotters.getRebate19().split(",");
				String[] pv20 = lotters.getRebate20().split(",");
				String[] pv21 = lotters.getRebate21().split(",");
				String[] pv22 = lotters.getRebate22().split(",");
				String[] pv23 = lotters.getRebate23().split(",");
				String[] pv24 = lotters.getRebate24().split(",");
				String[] pv25 = lotters.getRebate25().split(",");
				String[] pv37 = lotters.getRebate37().split(",");
				String[] pv38 = lotters.getRebate38().split(",");
				String[] pv39 = lotters.getRebate39().split(",");
				String[] pv40 = lotters.getRebate40().split(",");
				/** 注数 */
				int count = 0;
				int count1 = 0;
				int count2 = 0;
				int count3 = 0;
				int count4 = 0;
				int count5 = 0;
				int count6 = 0;
				int count7 = 0;
				int count8 = 0;
				int count9 = 0;
				int count10 = 0;
				int count11 = 0;
				int count12 = 0;
				int count13 = 0;
				int count14 = 0;
				int count15 = 0;
				int count16 = 0;
				int count17 = 0;
				int count18 = 0;
				int count19 = 0;
				int count20 = 0;
				int count21 = 0;
				int count22 = 0;
				int count23 = 0;
				int count24 = 0;
				int count25 = 0;
				int count26 = 0;
				int count27 = 0;
				int count28 = 0;
				int count29 = 0;
				int count30 = 0;
				int count31 = 0;
				int count32 = 0;
				int count33 = 0;
				int count34 = 0;
				int count35 = 0;
				int count36 = 0;
				int count37 = 0;
				int count38 = 0;
				int count39 = 0;
				int count40 = 0;
				// 金额
				double money = 0;
				double money1 = 0;
				double money2 = 0;
				double money3 = 0;
				double money4 = 0;
				double money5 = 0;
				double money6 = 0;
				double money7 = 0;
				double money8 = 0;
				double money9 = 0;
				double money10 = 0;
				double money11 = 0;
				double money12 = 0;
				double money13 = 0;
				double money14 = 0;
				double money15 = 0;
				double money16 = 0;
				double money17 = 0;
				double money18 = 0;
				double money19 = 0;
				double money20 = 0;
				double money21 = 0;
				double money22 = 0;
				double money23 = 0;
				double money24 = 0;
				double money25 = 0;
				double money26 = 0;
				double money27 = 0;
				double money28 = 0;
				double money29 = 0;
				double money30 = 0;
				double money31 = 0;
				double money32 = 0;
				double money33 = 0;
				double money34 = 0;
				double money35 = 0;
				double money36 = 0;
				double money37 = 0;
				double money38 = 0;
				double money39 = 0;
				double money40 = 0;

				/** 判断属于哪个彩种订单 */
				switch (o.getCname()) {
				case "bjpk10":
				case "2fpk10":
				case "2fft":
				case "xyft":
				case "xysm":
					/** 下注号码 */
					String gyhz[] = o.getStr1().split(",");
					String gj[] = o.getStr2().split(",");
					String yj[] = o.getStr3().split(",");
					String d3m[] = o.getStr4().split(",");
					String d4m[] = o.getStr5().split(",");
					String d5m[] = o.getStr6().split(",");
					String d6m[] = o.getStr7().split(",");
					String d7m[] = o.getStr8().split(",");
					String d8m[] = o.getStr9().split(",");
					String d9m[] = o.getStr10().split(",");
					String d10m[] = o.getStr11().split(",");
					// 冠亚和值
					if (gyhz.length != 0 && !"".equals(gyhz[0])) {
						count1 += gyhz.length;
						money1 = ExChangeUtil.dxds(gyhz, pv1);
					}
					// 冠军
					if (gj.length != 0 && !"".equals(gj[0])) {
						count2 += gj.length;
						money2 = ExChangeUtil.d1d10m("gj", gj, pv2);
					}
					// 亚军
					if (yj.length != 0 && !"".equals(yj[0])) {
						count3 += yj.length;
						money3 = ExChangeUtil.d1d10m("yj", yj, pv3);
					}
					// 第3名
					if (d3m.length != 0 && !"".equals(d3m[0])) {
						count4 += d3m.length;
						money4 = ExChangeUtil.d1d10m("d3m", d3m, pv3);
					}
					// 第4名
					if (d4m.length != 0 && !"".equals(d4m[0])) {
						count5 += d4m.length;
						money5 = ExChangeUtil.d1d10m("d4m", d4m, pv4);
					}
					// 第5名
					if (d5m.length != 0 && !"".equals(d5m[0])) {
						count6 += d5m.length;
						money6 = ExChangeUtil.d1d10m("d5m", d5m, pv5);
					}
					// 第6名
					if (d6m.length != 0 && !"".equals(d6m[0])) {
						count7 += d6m.length;
						money7 = ExChangeUtil.d1d10m("d6m", d6m, pv6);
					}
					// 第7名
					if (d7m.length != 0 && !"".equals(d7m[0])) {
						count8 += d7m.length;
						money8 = ExChangeUtil.d1d10m("d7m", d7m, pv7);
					}
					// 第8名
					if (d8m.length != 0 && !"".equals(d8m[0])) {
						count9 += d8m.length;
						money9 = ExChangeUtil.d1d10m("d8m", d8m, pv8);
					}
					// 第9名
					if (d9m.length != 0 && !"".equals(d9m[0])) {
						count10 += d9m.length;
						money10 = ExChangeUtil.d1d10m("d9m", d9m, pv9);
					}
					// 第10名
					if (d10m.length != 0 && !"".equals(d10m[0])) {
						count11 += d10m.length;
						money11 = ExChangeUtil.d1d10m("d10m", d10m, pv11);
					}
					break;

				case "cqssc":
				case "2fssc":
				case "tjssc":
				case "xjssc":
					/** 下注号码 */
					String[] zh = o.getStr1().split(",");
					String[] d1q = o.getStr2().split(",");
					String[] d2q = o.getStr3().split(",");
					String[] d3q = o.getStr4().split(",");
					String[] d4q = o.getStr5().split(",");
					String[] d5q = o.getStr6().split(",");
					String[] q3 = o.getStr7().split(",");
					String[] z3 = o.getStr8().split(",");
					String[] h3 = o.getStr9().split(",");
					String[] q2zhx0 = o.getStr10().split(",");
					String[] q2zhx1 = o.getStr11().split(",");
					String[] h2zhx0 = o.getStr12().split(",");
					String[] h2zhx1 = o.getStr13().split(",");
					String[] q3zhxx0 = o.getStr14().split(",");
					String[] q3zhxx1 = o.getStr15().split(",");
					String[] q3zhxx2 = o.getStr16().split(",");
					String[] z3zhx0 = o.getStr17().split(",");
					String[] z3zhx1 = o.getStr18().split(",");
					String[] z3zhx2 = o.getStr19().split(",");
					String[] h3zhx0 = o.getStr20().split(",");
					String[] h3zhx1 = o.getStr21().split(",");
					String[] h3zhx2 = o.getStr22().split(",");
					String[] q2zxx = o.getStr23().split(",");
					String[] h2zxx = o.getStr24().split(",");
					String[] q3z6 = o.getStr25().split(",");
					String[] z3z6 = o.getStr26().split(",");
					String[] h3z6 = o.getStr27().split(",");
					String[] q3z3 = o.getStr28().split(",");
					String[] z3z3 = o.getStr29().split(",");
					String[] h3z3 = o.getStr30().split(",");

					// 总和
					if (zh.length != 0 && !"".equals(zh[0])) {
						count1 += zh.length;
						money1 = ExChangeUtil.dxdslh(zh, pv1);
					}
					// 第一球
					if (d1q.length != 0 && !"".equals(d1q[0])) {
						count2 += d1q.length;
						money2 = ExChangeUtil.sscd1d5q(d1q, pv2);
					}
					// 第二球
					if (d2q.length != 0 && !"".equals(d2q[0])) {
						count3 += d2q.length;
						money3 = ExChangeUtil.sscd1d5q(d2q, pv3);
					}
					// 第三球
					if (d3q.length != 0 && !"".equals(d3q[0])) {
						count4 += d3q.length;
						money4 = ExChangeUtil.sscd1d5q(d3q, pv4);
					}
					// 第四球
					if (d4q.length != 0 && !"".equals(d4q[0])) {
						count5 += d4q.length;
						money5 = ExChangeUtil.sscd1d5q(d4q, pv5);
					}
					// 第五球
					if (d5q.length != 0 && !"".equals(d5q[0])) {
						count6 += d5q.length;
						money6 = ExChangeUtil.sscd1d5q(d5q, pv6);
					}
					// 前三
					String[] baozi = { "豹子", "顺子", "对子", "半顺", "杂六" };
					if (q3.length != 0 && !"".equals(q3[0])) {
						count7 += q3.length;
						money7 = ExChangeUtil.maxRebate(q3, pv7, baozi);
					}
					// 中三
					if (z3.length != 0 && !"".equals(z3[0])) {
						count8 += z3.length;
						money8 = ExChangeUtil.maxRebate(z3, pv8, baozi);
					}
					// 后三
					if (h3.length != 0 && !"".equals(h3[0])) {
						count9 += h3.length;
						money9 = ExChangeUtil.maxRebate(h3, pv9, baozi);
					}

					// 前二直选
					if (("".equals(o.getStr10()) || "".equals(o.getStr11())) && (o.getStr11() != o.getStr10())) {
						count = 0;
						return new JsonResult("xinxi", count);
					}
					if (q2zhx0.length != 0 && !"".equals(q2zhx0[0]) && q2zhx1.length != 0 && !"".equals(q2zhx1[0])) {
						count10 = q2zhx0.length * q2zhx1.length;
						money10 = ExChangeUtil.rebate(str10);
					}

					// 后二直选
					if (("".equals(o.getStr12()) || "".equals(o.getStr13())) && (o.getStr12() != o.getStr13())) {
						count = 0;
						return new JsonResult("xinxi", count);
					}
					if (h2zhx0.length != 0 && !"".equals(h2zhx0[0]) && h2zhx1.length != 0 && !"".equals(h2zhx1[0])) {
						count11 += h2zhx0.length * h2zhx1.length;
						money11 = ExChangeUtil.rebate(str11);
					}

					// 前三直选(三星直选)
					if (("".equals(o.getStr14()) || "".equals(o.getStr15()) || "".equals(o.getStr16()))
							&& (o.getStr14() != o.getStr15() && o.getStr14() != o.getStr16() || o.getStr15() != o.getStr16())) {
						count = 0;
						return new JsonResult("xinxi", count);
					}
					if (q3zhxx0.length != 0 && !"".equals(q3zhxx0[0]) && q3zhxx1.length != 0 && !"".equals(q3zhxx1[0])
							&& q3zhxx2.length != 0 && !"".equals(q3zhxx2[0])) {
						count12 += q3zhxx0.length * q3zhxx1.length * q3zhxx2.length;
						money12 = ExChangeUtil.rebate(str12);
					}

					// 中三直选
					if (("".equals(o.getStr17()) || "".equals(o.getStr18()) || "".equals(o.getStr19()))
							&& (o.getStr17() != o.getStr18() && o.getStr17() != o.getStr19() || o.getStr18() != o.getStr19())) {
						count = 0;
						return new JsonResult("xinxi", count);
					}
					if (z3zhx0.length != 0 && !"".equals(z3zhx0[0]) && z3zhx1.length != 0 && !"".equals(z3zhx1[0])
							&& z3zhx2.length != 0 && !"".equals(z3zhx2[0])) {
						count13 += z3zhx0.length * z3zhx1.length * z3zhx2.length;
						money13 = ExChangeUtil.rebate(str13);
					}
					// 后三直选
					if (("".equals(o.getStr20()) || "".equals(o.getStr21()) || "".equals(o.getStr22()))
							&& (o.getStr20() != o.getStr21() && o.getStr20() != o.getStr22() || o.getStr21() != o.getStr22())) {
						count = 0;
						return new JsonResult("xinxi", count);
					}
					if (h3zhx0.length != 0 && !"".equals(h3zhx0[0]) && h3zhx1.length != 0 && !"".equals(h3zhx1[0])
							&& h3zhx2.length != 0 && !"".equals(h3zhx2[0])) {
						count14 += h3zhx0.length * h3zhx1.length * h3zhx2.length;
						money14 = ExChangeUtil.rebate(str14);
					}
					// 前二组选
					if (q2zxx.length != 0 && !"".equals(q2zxx[0])) {
						if (q2zxx.length < 2) {
							count = 0;
							return new JsonResult("xinxi", count);
						}
						count15 += q2zxx.length * (q2zxx.length - 1) / 2;
						money15 = ExChangeUtil.rebate(str15);
					}
					// 后二组选
					if (h2zxx.length != 0 && !"".equals(h2zxx[0])) {
						if (h2zxx.length < 2) {
							count = 0;
							return new JsonResult("xinxi", count);
						}
						count16 += h2zxx.length * (h2zxx.length - 1) / 2;
						money16 = ExChangeUtil.rebate(str16);
					}
					// 前三组六(三星组六)
					if (q3z6.length != 0 && !"".equals(q3z6[0])) {
						if (q3z6.length < 3) {
							count = 0;
							return new JsonResult("xinxi", count);
						}
						count17 += q3z6.length * (q3z6.length - 1) * (q3z6.length - 2) / 6;
						money17 = ExChangeUtil.rebate(str17);
					}
					// 中三组六
					if (z3z6.length != 0 && !"".equals(z3z6[0])) {
						if (z3z6.length < 3) {
							count = 0;
							return new JsonResult("xinxi", count);
						}
						count18 += z3z6.length * (z3z6.length - 1) * (z3z6.length - 2) / 6;
						money18 = ExChangeUtil.rebate(str18);
					}
					// 后三组六
					if (h3z6.length != 0 && !"".equals(h3z6[0])) {
						if (h3z6.length < 3) {
							count = 0;
							return new JsonResult("xinxi", count);
						}
						count19 += h3z6.length * (h3z6.length - 1) * (h3z6.length - 2) / 6;
						money19 = ExChangeUtil.rebate(str19);
					}
					// 前三组三-(三星组三)
					if (q3z3.length != 0 && !"".equals(q3z3[0])) {
						if (q3z3.length < 2) {
							count = 0;
							return new JsonResult("xinxi", count);
						}
						count20 += q3z3.length * (q3z3.length - 1);
						money20 = ExChangeUtil.rebate(str20);
					}
					// 中三组三
					if (z3z3.length != 0 && !"".equals(z3z3[0])) {
						if (z3z3.length < 2) {
							count = 0;
							return new JsonResult("xinxi", count);
						}
						count21 += z3z3.length * (z3z3.length - 1);
						money21 = ExChangeUtil.rebate(str21);
					}
					// 后三组三
					if (h3z3.length > 2 && !"".equals(h3z3[0])) {
						if (h3z3.length < 2) {
							count = 0;
							return new JsonResult("xinxi", count);
						}
						count22 += h3z3.length * (h3z3.length - 1);
						money22 = ExChangeUtil.rebate(str22);
					}
					break;

				case "ahk3":
				case "gxk3":
				case "jsk3":
				case "bjk3":
				case "jlk3":
				case "2fk3":
				case "3fk3":
					String[] c1gh = o.getStr1().split(",");
					String[] slhtx = o.getStr2().split(",");
					String[] ethfx = o.getStr3().split(",");
					String[] ethdx0 = o.getStr4().split(",");
					String[] ethdx1 = o.getStr5().split(",");
					String[] ebth = o.getStr6().split(",");
					String[] ebthdt0 = o.getStr7().split(",");
					String[] ebthdt1 = o.getStr8().split(",");
					String[] sthtx = o.getStr9().split(",");
					String[] sthdx = o.getStr10().split(",");
					String[] sbth = o.getStr11().split(",");
					String[] xt = o.getStr12().split(",");
					String[] zh6 = o.getStr13().split(",");
					// 猜一个号
					if (c1gh.length != 0 && !"".equals(c1gh[0])) {
						count1 += c1gh.length * 21;
						money1 = 1 * ExChangeUtil.rebate(str1);
					}
					// 三连号通选
					if (slhtx.length != 0 && !"".equals(slhtx[0])) {
						count2 += slhtx.length;
						money2 = 1 * ExChangeUtil.rebate(str2);
					}
					// 二同号复选
					if (ethfx.length != 0 && !"".equals(ethfx[0])) {
						String[] qiu = { "11", "22", "33", "44", "55", "66" };
						count3 += ethfx.length;
						money3 = ExChangeUtil.maxRebate(ethfx, pv3, qiu);
					}
					// 二同号单选
					if (("".equals(o.getStr4()) || "".equals(o.getStr5())) && (o.getStr4() != o.getStr5())) {
						count = 0;
						return new JsonResult("xinxi", count);
					}
					if (ethdx0.length != 0 && !"".equals(ethdx0[0]) && ethdx1.length != 0 && !"".equals(ethdx1[0])) {
						count4 += ethdx0.length * ethdx1.length;
						money4 = 1 * ExChangeUtil.rebate(str4);

					}
					// 二不同号
					if (ebth.length > 1) {
						if (ebth.length == 2) {
							count7 += 1;
						} else if (ebth.length == 3) {
							count7 += 3;
						} else if (ebth.length == 4) {
							count7 += 6;
						} else if (ebth.length == 5) {
							count7 += 10;
						} else if (ebth.length == 6) {
							count7 += 15;
						} else {
							count7 += 0;
						}
						money7 = 1 * ExChangeUtil.rebate(str5);
					}

					// 二不同号胆拖
					if (("".equals(o.getStr7()) || "".equals(o.getStr8())) && (o.getStr7() != o.getStr8())) {
						count = 0;
						return new JsonResult("xinxi", count);
					}
					if (ebthdt0.length != 0 && !"".equals(ebthdt0[0]) && ebthdt1.length != 0 && !"".equals(ebthdt1[0])) {
						count8 += ebthdt0.length * ebthdt1.length;
						money8 = 1 * ExChangeUtil.rebate(str6);
					}

					// 三同号通选
					if (sthtx.length != 0 && !"".equals(sthtx[0])) {

						count5 += sthtx.length;
						money5 = ExChangeUtil.rebate(str7);
					}
					// 三同号单选
					if (sthdx.length != 0 && !"".equals(sthdx[0])) {
						count6 += sthdx.length;
						String qiu[] = { "111", "222", "333", "444", "555", "666" };
						money6 = ExChangeUtil.maxRebate(sthdx, pv8, qiu);
					}

					// 三不同号
					if (sbth.length > 2) {
						if (sbth.length == 3) {
							count9 += 1;
						} else if (sbth.length == 4) {
							count9 += 4;
						} else if (sbth.length == 5) {
							count9 += 10;
						} else if (sbth.length == 6) {
							count9 += 20;
						} else {
							count9 += 0;
						}
						money9 = 1 * ExChangeUtil.rebate(str9);
					}
					// 形态
					if (xt.length != 0 && !"".equals(xt[0])) {
						count10 += xt.length;
						String[] zl = { "豹子", "顺子", "对子", "半顺", "杂六" };
						money10 = ExChangeUtil.maxRebate(xt, pv10, zl);
					}
					// 总和
					if (zh6.length != 0 && !"".equals(zh6[0])) {
						count11 += zh6.length;
						money11 = ExChangeUtil.k3zh(zh6, pv11);
					}
					break;

				case "gdkl10f":
				case "cqkl10f":
					// 下注号码
					String[] swst = o.getStr1().split(",");
					String[] swht = o.getStr2().split(",");
					String[] elzhx0 = o.getStr3().split(",");
					String[] elzhx1 = o.getStr4().split(",");
					String[] elzx = o.getStr5().split(",");
					String[] q3zhx0 = o.getStr6().split(",");
					String[] q3zhx1 = o.getStr7().split(",");
					String[] q3zhx2 = o.getStr8().split(",");
					String[] q3zx = o.getStr9().split(",");
					String[] kl2 = o.getStr10().split(",");
					String[] kl3 = o.getStr11().split(",");
					String[] kl4 = o.getStr12().split(",");
					String[] kl5 = o.getStr13().split(",");
					String[] st = { "01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12", "13", "14", "15",
							"16", "17", "18" };
					String[] ht = { "19", "20" };
					// 首位数投
					if (swst.length != 0 && !"".equals(swst[0])) {
						count1 += swst.length;
						money1 = ExChangeUtil.maxRebate(swst, pv1, st);
					}
					// 首位红投
					if (swht.length != 0 && !"".equals(swht[0])) {
						count2 += swht.length;
						money2 = ExChangeUtil.maxRebate(swht, pv2, ht);
					}
					// 二连直选
					if (("".equals(o.getStr3()) || "".equals(o.getStr4())) && (o.getStr3() != o.getStr4())) {
						count = 0;
						return new JsonResult("xinxi", count);
					}
					if (elzhx0.length != 0 && !"".equals(elzhx0[0]) && elzhx1.length != 0 && !"".equals(elzhx1[0])) {
						int c = 0;
						for (int i = 0; i < elzhx0.length; i++) {
							for (int j = 0; j < elzhx1.length; j++) {
								if (!elzhx0[i].equals(elzhx1[j])) {
									c++;
								}
							}
						}
						count3 += c;
						money3 = 1 * ExChangeUtil.rebate(str3);
					}
					// 二连组选
					if (elzx.length > 1 && !"".equals(elzx[0])) {
						if (elzx.length < 2) {
							count = 0;
							return new JsonResult("xinxi", count);
						}
						count4 += elzx.length * (elzx.length - 1) / 2;
						money4 = 1 * ExChangeUtil.rebate(str4);
					}
					// 前三直选
					if (("".equals(o.getStr6()) || "".equals(o.getStr7()) || "".equals(o.getStr8()))
							&& (o.getStr6() != o.getStr7() && o.getStr6() != o.getStr8() || o.getStr7() != o.getStr8())) {
						count = 0;
						return new JsonResult("xinxi", count);
					}
					if (q3zhx0.length != 0 && !"".equals(q3zhx0[0]) && q3zhx1.length != 0 && !"".equals(q3zhx1[0])
							&& q3zhx2.length != 0 && !"".equals(q3zhx2[0])) {
						int d = 0;
						for (int i = 0; i < q3zhx0.length; i++) {
							for (int j = 0; j < q3zhx1.length; j++) {
								for (int k = 0; k < q3zhx2.length; k++) {
									if (!q3zhx0[i].equals(q3zhx1[j]) && !q3zhx0[i].equals(q3zhx2[k])
											&& !q3zhx1[j].equals(q3zhx2[k])) {
										d++;
									}
								}
							}
						}
						count5 += d;
						money5 = 1 * ExChangeUtil.rebate(str5);
					}
					// 前三组选
					if (q3zx.length > 2 && !"".equals(q3zx[0])) {
						if (q3zx.length < 3) {
							count = 0;
							return new JsonResult("xinxi", count);
						}
						int m = q3zx.length;
						count6 += (m - 2) * (m - 1) * m / 6;
						money6 = 1 * ExChangeUtil.rebate(str6);
					}
					// 快乐2
					if (kl2.length > 1 && !"".equals(kl2[0])) {
						if (kl2.length < 2) {
							count = 0;
							return new JsonResult("xinxi", count);
						}
						count7 += kl2.length * (kl2.length - 1) / 2;
						money7 = 28 * ExChangeUtil.rebate(str7);
					}
					// 快乐3
					if (kl3.length > 2 && !"".equals(kl3[0])) {
						if (kl3.length < 3) {
							count = 0;
							return new JsonResult("xinxi", count);
						}
						int m = kl3.length;
						count8 += (m - 2) * (m - 1) * m / 6;
						money8 = 56 * ExChangeUtil.rebate(str8);
					}
					// 快乐4
					if (kl4.length > 3 && !"".equals(kl4[0])) {
						if (kl4.length < 4) {
							count = 0;
							return new JsonResult("xinxi", count);
						}
						int n = kl4.length;
						count9 += n * (n - 1) * (n - 2) * (n - 3) / 24;
						money9 = 70 * ExChangeUtil.rebate(str9);
					}
					// 快乐5
					if (kl5.length > 4 && !"".equals(kl5[0])) {
						if (kl5.length < 5) {
							count = 0;
							return new JsonResult("xinxi", count);
						}
						int i = kl5.length;
						count10 += i * (i - 4) * (i - 3) * (i - 2) * (i - 1) / 120;
						money10 = 56 * ExChangeUtil.rebate(str10);
					}
					break;

				case "shssl":
				case "pl3":
				case "fc3d":
					// 下注号码
					String[] q2zhx2 = o.getStr1().split(",");
					String[] q2zhx3 = o.getStr2().split(",");
					String[] q2zx = o.getStr3().split(",");
					String[] h2zhx2 = o.getStr4().split(",");
					String[] h2zhx3 = o.getStr5().split(",");
					String[] h2zx = o.getStr6().split(",");
					String[] sxzhx0 = o.getStr7().split(",");
					String[] sxzhx1 = o.getStr8().split(",");
					String[] sxzhx2 = o.getStr9().split(",");
					String[] zhxhz = o.getStr10().split(",");
					String[] sxz3 = o.getStr11().split(",");
					String[] z3hz = o.getStr12().split(",");
					String[] sxz6 = o.getStr13().split(",");
					String[] z6hz = o.getStr14().split(",");
					// 前二直选
					if (("".equals(o.getStr1()) || "".equals(o.getStr2())) && (o.getStr1() != o.getStr2())) {
						count = 0;
						return new JsonResult("xinxi", count);
					}
					if (q2zhx2.length != 0 && !"".equals(q2zhx2[0]) && q2zhx3.length != 0 && !"".equals(q2zhx3[0])) {
						count1 += q2zhx2.length * q2zhx3.length;
						money1 = 1 * ExChangeUtil.rebate(str1);
					}
					// 前二组选
					if (!"".equals(o.getStr3()) && o.getStr3().length()<3 ) {
						count = 0;
						return new JsonResult("xinxi", count);
					}
					if (q2zx.length > 1 && !"".equals(q2zx[0])) {
						count2 += q2zx.length * (q2zx.length - 1) / 2;
						money2 = 1 * ExChangeUtil.rebate(str2);
					}
					// 后二直选
					if (("".equals(o.getStr4()) || "".equals(o.getStr5())) && (o.getStr4() != o.getStr5())) { 
						count = 0;
						return new JsonResult("xinxi", count);
					}
					if (h2zhx2.length != 0 && !"".equals(h2zhx2[0]) && h2zhx3.length != 0 && !"".equals(h2zhx3[0])) {
						count3 += h2zhx2.length * h2zhx3.length;
						money3 = 1 * ExChangeUtil.rebate(str3);
					}
					// 后二组选
					if (!"".equals(o.getStr6()) && o.getStr6().length()<3 ) {
						count = 0;
						return new JsonResult("xinxi", count);
					}
					if (h2zx.length > 1 && !"".equals(h2zx[0])) {
						count4 += h2zx.length * (h2zx.length - 1) / 2;
						money4 = 1 * ExChangeUtil.rebate(str4); 
					}
					// 三星直选
					if (("".equals(o.getStr7()) || "".equals(o.getStr8()) || "".equals(o.getStr9()))
							&& (o.getStr7() != o.getStr8() && o.getStr7() != o.getStr9() || o.getStr8() != o.getStr9())) {
						count = 0;
						return new JsonResult("xinxi", count);
					}
					if (sxzhx0.length != 0 && !"".equals(sxzhx0[0]) && sxzhx1.length != 0 && !"".equals(sxzhx1[0])
							&& sxzhx2.length != 0 && !"".equals(sxzhx2[0])) {
						count5 += sxzhx0.length * sxzhx1.length * sxzhx2.length;
						money5 = 1 * ExChangeUtil.rebate(str5);
					}
					// 三星直选和值
					if (zhxhz.length != 0 && !"".equals(zhxhz[0])) {
						int f = 0;
						int[] x = new int[] { 0, 1, 2, 3, 4, 5, 6, 7, 8, 9 };
						for (int i = 0; i < zhxhz.length; i++) {
							for (int j = 0; j < x.length; j++) {
								for (int k = 0; k < x.length; k++) {
									for (int l = 0; l < x.length; l++) {
										if (Integer.parseInt(zhxhz[i]) == x[j] + x[k] + x[l]) {
											f++;
										}
									}
								}
							}
						}
						count6 += f;
						money6 = 1 * ExChangeUtil.rebate(str6);
					}
					// 三星组三
					if (sxz3.length > 1 && !"".equals(sxz3[0])) {
						if (sxz3.length < 2) {
							count = 0;
							return new JsonResult("xinxi", count);
						}
						count7 += sxz3.length * (sxz3.length - 1);
						money7 = 1 * ExChangeUtil.rebate(str7);
					}
					// 组三和值
					if (z3hz.length != 0 && !"".equals(z3hz[0])) {
						int f = 0;
						int[] y = new int[] { 0, 1, 2, 3, 4, 5, 6, 7, 8, 9 };
						for (int i = 0; i < z3hz.length; i++) {
							for (int j = 0; j < y.length; j++) {
								for (int k = 0; k < y.length; k++) {
									if (Integer.parseInt(z3hz[i]) == y[j] + y[j] + y[k] && j != k) {
										f++;
									}
								}
							}
						}
						count8 += f;
						money8 = 1 * ExChangeUtil.rebate(str8);
					}
					// 三星组六
					if (sxz6.length != 0 &&!"".equals(sxz6[0])) {
						if (sxz6.length < 3) {
							count = 0;
							return new JsonResult("xinxi", count);
						}
						count9 += sxz6.length * (sxz6.length - 1) * (sxz6.length - 2) / 6;
						money9 = 1 * ExChangeUtil.rebate(str9);
					}
					// 组六和值
					if (z6hz.length != 0 && !"".equals(z6hz[0])) {
						int f = 0;
						int[] z = new int[] { 0, 1, 2, 3, 4, 5, 6, 7, 8, 9 };
						for (int i = 0; i < z6hz.length; i++) {
							for (int j = 0; j < z.length; j++) {
								for (int k = 0; k < z.length; k++) {
									for (int l = 0; l < z.length; l++) {
										if (Integer.parseInt(z6hz[i]) == z[j] + z[k] + z[l] && j != k && j != l && l != k) {
											f++;
										}
									}
								}
							}
						}
						count10 += f / 6;
						money10 = 1 * ExChangeUtil.rebate(str10);
					}
					break;

				case "ah11x5":
				case "gd11x5":
				case "jx11x5":
				case "sd11x5":
				case "sh11x5":
					String[] d1qq = o.getStr1().split(",");
					String[] d2qq = o.getStr2().split(",");
					String[] d3qq = o.getStr3().split(",");
					String[] d4qq = o.getStr4().split(",");
					String[] d5qq = o.getStr5().split(",");
					String[] zhh = o.getStr6().split(",");
					String[] q1zhx = o.getStr7().split(",");
					String[] q2zhx4 = o.getStr8().split(",");
					String[] q2zhx5 = o.getStr9().split(",");
					String[] q3zhx6 = o.getStr10().split(",");
					String[] q3zhx7 = o.getStr11().split(",");
					String[] q3zhx8 = o.getStr12().split(",");
					String[] rx1 = o.getStr13().split(",");
					String[] rx2 = o.getStr14().split(",");
					String[] rx3 = o.getStr15().split(",");
					String[] rx4 = o.getStr16().split(",");
					String[] rx5 = o.getStr17().split(",");
					String[] rx6 = o.getStr18().split(",");
					String[] rx7 = o.getStr19().split(",");
					String[] rx8 = o.getStr20().split(",");

					// 第1球
					if (d1qq.length != 0 && !"".equals(d1qq[0])) {
						count1 += d1qq.length;
						money1 = ExChangeUtil.syx5d1d5q(d1qq, pv1);
					}
					// 第2球
					if (d2qq.length != 0 && !"".equals(d2qq[0])) {
						count2 += d2qq.length;
						money2 = ExChangeUtil.syx5d1d5q(d2qq, pv2);
					}
					// 第3球
					if (d3qq.length != 0 && !"".equals(d3qq[0])) {
						count3 += d3qq.length;
						money3 = ExChangeUtil.syx5d1d5q(d3qq, pv3);
					}
					// 第4球
					if (d4qq.length != 0 && !"".equals(d4qq[0])) {
						count4 += d4qq.length;
						money4 = ExChangeUtil.syx5d1d5q(d4qq, pv4);
					}
					// 第5球
					if (d5qq.length != 0 && !"".equals(d5qq[0])) {
						count5 += d5qq.length;
						money5 = ExChangeUtil.syx5d1d5q(d5qq, pv5);
					}
					// 总和
					if (zhh.length != 0 && !"".equals(zhh[0])) {
						count6 += zhh.length;
						money6 = ExChangeUtil.dxds(zhh, pv6);
					}
					String[] qiu8 = { "01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11" };
					// 前一直选
					if (q1zhx.length != 0 && !"".equals(q1zhx[0])) {
						count7 += q1zhx.length;
						money7 = ExChangeUtil.maxRebate(q1zhx, pv7, qiu8);
					}
					// 前二直选
					if (("".equals(o.getStr8()) || "".equals(o.getStr9())) && (o.getStr8() != o.getStr9())) {
						count = 0;
						return new JsonResult("xinxi", count);
					}
					if (q2zhx4.length != 0 && !"".equals(q2zhx4[0]) && q2zhx5.length != 0 && !"".equals(q2zhx5[0])) {
						int f = 0;
						for (int i = 0; i < q2zhx4.length; i++) {
							for (int j = 0; j < q2zhx5.length; j++) {
								if (!q2zhx4[i].equals(q2zhx5[j])) {
									f++;
								}
							}
						}
						count8 += f;
						money8 = 1 * ExChangeUtil.rebate(str8);
					}
					// 前三直选
					if (("".equals(o.getStr10()) || "".equals(o.getStr11()) || "".equals(o.getStr12()))
							&& (o.getStr10() != o.getStr11() && o.getStr10() != o.getStr12() || o.getStr11() != o.getStr12())) {
						count = 0;
						return new JsonResult("xinxi", count);
					}
					if (q3zhx6.length != 0 && !"".equals(q3zhx6[0]) && q3zhx7.length != 0 && !"".equals(q3zhx7[0])
							&& q3zhx8.length != 0 && !"".equals(q3zhx8[0])) {
						int f = 0;
						for (int i = 0; i < q3zhx6.length; i++) {
							for (int j = 0; j < q3zhx7.length; j++) {
								for (int k = 0; k < q3zhx8.length; k++) {
									if (!q3zhx6[i].equals(q3zhx7[j]) && !q3zhx6[i].equals(q3zhx8[k])
											&& !q3zhx7[j].equals(q3zhx8[k])) {
										f++;
									}
								}
							}
						}
						count9 += f;
						money9 = 1 * ExChangeUtil.rebate(str9);
					}
					// 任选一
					if (rx1.length != 0 && !"".equals(rx1[0])) {
						count10 += rx1.length;
						money10 = ExChangeUtil.maxRebate(rx1, pv10, qiu8);
					}
					// 任选二
					if (rx2.length != 0 && !"".equals(rx2[0])) {
						if (rx2.length < 2) {
							count = 0;
							return new JsonResult("xinxi", count);
						}
						int u = rx2.length;
						count11 += u * (u - 1) / 2;
						money11 = 1 * ExChangeUtil.rebate(str11);
					}
					// 任选三
					if (rx3.length != 0 && !"".equals(rx3[0])) {
						if (rx3.length < 3) {
							count = 0;
							return new JsonResult("xinxi", count);
						}
						int u = rx3.length;
						count12 += u * (u - 1) * (u - 2) / 6;
						money12 = 1 * ExChangeUtil.rebate(str12);
					}
					// 任选四
					if (rx4.length != 0 && !"".equals(rx4[0])) {
						if (rx4.length < 4) {
							count = 0;
							return new JsonResult("xinxi", count);
						}
						int u = rx4.length;
						count13 += u * (u - 1) * (u - 2) * (u - 3) / 24;
						money13 = 1 * ExChangeUtil.rebate(str13);
					}
					// 任选五
					if (rx5.length != 0 && !"".equals(rx5[0])) {
						if (rx5.length < 5) {
							count = 0;
							return new JsonResult("xinxi", count);
						}
						int u = rx5.length;
						count14 += u * (u - 1) * (u - 2) * (u - 3) * (u - 4) / 120;
						money14 = 1 * ExChangeUtil.rebate(str14);
					}
					// 任选六
					if (rx6.length != 0 && !"".equals(rx6[0])) {
						if (rx6.length < 6) {
							count = 0;
							return new JsonResult("xinxi", count);
						}
						int u = rx6.length;
						count15 += u * (u - 1) * (u - 2) * (u - 3) * (u - 4) * (u - 5) / 720;
						money15 = 1 * ExChangeUtil.rebate(str15);
					}
					// 任选七
					if (rx7.length != 0 && !"".equals(rx7[0])) {
						if (rx7.length < 7) {
							count = 0;
							return new JsonResult("xinxi", count);
						}
						int u = rx7.length;
						count16 += u * (u - 1) * (u - 2) * (u - 3) * (u - 4) * (u - 5) * (u - 6) / 5040;
						money16 = 1 * ExChangeUtil.rebate(str16);
					}
					// 任选八
					if (rx8.length != 0 && !"".equals(rx8[0])) {
						if (rx8.length < 8) {
							count = 0;
							return new JsonResult("xinxi", count);
						}
						int u = rx8.length;
						count17 += u * (u - 1) * (u - 2) * (u - 3) * (u - 4) * (u - 5) * (u - 6) * (u - 7) / 40320;
						money17 = 1 * ExChangeUtil.rebate(str17);
					}
					break;

				case "xg6hc":
				case "5f6hc":
					String[] tma = o.getStr1().split(",");
					String[] tmb = o.getStr2().split(",");
					String[] tmsx = o.getStr3().split(",");
					String[] dxds = o.getStr4().split(",");
					String[] jqys = o.getStr5().split(",");
					String[] ts = o.getStr6().split(",");
					String[] ws = o.getStr7().split(",");
					String[] wx = o.getStr8().split(",");
					String[] zh9 = o.getStr9().split(",");
					String[] hs = o.getStr10().split(",");
					String[] dp = o.getStr11().split(",");
					String[] p2z2 = o.getStr12().split(",");
					String[] p3z3 = o.getStr13().split(",");
					String[] p3z2 = o.getStr14().split(",");
					String[] sxzt = o.getStr15().split(",");
					String[] wxzt = o.getStr16().split(",");
					String[] lxzt = o.getStr17().split(",");
					String[] pt1x = o.getStr18().split(",");
					String[] pt2x = o.getStr19().split(",");
					String[] pt3x = o.getStr20().split(",");
					String[] pt4x = o.getStr21().split(",");
					String[] pt1w = o.getStr22().split(",");
					String[] pt2w = o.getStr23().split(",");
					String[] pt3w = o.getStr24().split(",");
					String[] pt4w = o.getStr25().split(",");
					String[] wbz = o.getStr26().split(",");
					String[] lbz = o.getStr27().split(",");
					String[] qbz = o.getStr28().split(",");
					String[] bbz = o.getStr29().split(",");
					String[] jbz = o.getStr30().split(",");
					String[] shbz = o.getStr31().split(",");
					String[] sh1bz = o.getStr32().split(",");
					String[] sh2bz = o.getStr33().split(",");
					String[] sh3bz = o.getStr34().split(",");
					String[] sh4bz = o.getStr35().split(",");
					String[] sh5bz = o.getStr36().split(",");
					String[] zx = o.getStr37().split(",");
					String[] sb = o.getStr38().split(",");
					String[] bb = o.getStr39().split(",");
					String[] bbb = o.getStr40().split(",");
					// 特码A
					String[] tm = { "01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12", "13", "14", "15",
							"16", "17", "18", "19", "20", "21", "22", "23", "24", "25", "26", "27", "28", "29", "30", "31",
							"32", "33", "34", "35", "36", "37", "38", "39", "40", "41", "42", "43", "44", "45", "46", "47",
							"48", "49" };
					String[] sx1 = { "鼠", "牛", "虎", "兔", "龙", "蛇", "马", "羊", "猴", "鸡", "狗", "猪" };
					String[] x1 = { "金", "木", "水", "火", "土" };
					if (tma.length != 0 && !"".equals(tma[0])) {
						count1 += tma.length;
						money1 = ExChangeUtil.maxRebate(tma, pv1, tm);
					}
					// 特码B
					if (tmb.length != 0 && !"".equals(tmb[0])) {
						count2 += tmb.length;
						money2 = ExChangeUtil.maxRebate(tmb, pv2, tm);
					}
					// 特码生肖
					if (tmsx.length != 0 && !"".equals(tmsx[0])) {
						count3 += tmsx.length;
						money3 = ExChangeUtil.maxRebate(tmsx, pv3, sx1);
					}
					// 大小单双
					if (dxds.length != 0 && !"".equals(dxds[0])) {
						count4 += dxds.length;
						money4 = ExChangeUtil.dxds(dxds, pv4);
					}
					// 家禽野兽
					String[] jqysss = { "家肖", "野肖", "天肖", "地肖" };
					if (jqys.length != 0 && !"".equals(jqys[0])) { // TODO: JIA
						count5 += jqys.length;
						money5 = ExChangeUtil.maxRebate(jqys, pv5, jqysss);
					}
					String[] t1 = { "0头", "1头", "2头", "3头", "4头" };
					// 头数
					if (ts.length != 0 && !"".equals(ts[0])) {
						count6 += ts.length;
						money6 = ExChangeUtil.maxRebate(ts, pv6, t1);
					}
					// 尾数
					if (ws.length != 0 && !"".equals(ws[0])) {
						count7 += ws.length;
						money7 = ExChangeUtil.ws(ws, pv7);
					}
					// 五行
					if (wx.length != 0 && !"".equals(wx[0])) {
						count8 += wx.length;
						money8 = ExChangeUtil.maxRebate(wx, pv8, x1);
					}
					// 总和
					if (zh9.length != 0 && !"".equals(zh9[0])) {
						count9 += zh9.length;
						money9 = ExChangeUtil.dxds(zh9, pv9);
					}
					// 合数
					if (hs.length != 0 && !"".equals(hs[0])) {
						count10 += hs.length;
						money10 = ExChangeUtil.dxds(hs, pv10);
					}
					// 独平
					if (dp.length != 0 && !"".equals(dp[0])) {
						count11 += dp.length;
						money11 = ExChangeUtil.maxRebate(dp, pv11, tm);
					}
					// 平二中二
					if (p2z2.length != 0 && !"".equals(p2z2[0])) {
						if (p2z2.length < 2) {
							count = 0;
							return new JsonResult("xinxi", count);
						}
						int m = p2z2.length;
						count12 += m * (m - 1) / 2;
						money12 = 1 * ExChangeUtil.rebate(str12);
					}
					// 平三中三
					if (p3z3.length != 0 && !"".equals(p3z3[0])) {
						if (p3z3.length < 3) {
							count = 0;
							return new JsonResult("xinxi", count);
						}
						int m = p3z3.length;
						count13 += m * (m - 1) * (m - 2) / 6;
						money13 = 1 * ExChangeUtil.rebate(str13);
					}
					// 平三中二
					if (p3z2.length != 0 && !"".equals(p3z2[0])) {
						if (p3z2.length < 3) {
							count = 0;
							return new JsonResult("xinxi", count);
						}
						int m = p3z2.length;
						count14 += m * (m - 1) * (m - 2) / 6;
						money14 = 1 * ExChangeUtil.rebate(str14);
					}
					// 四肖中特
					if (sxzt.length != 0 && !"".equals(sxzt[0])) {
						if (sxzt.length < 4) {
							count = 0;
							return new JsonResult("xinxi", count);
						}
						int m = sxzt.length;
						count15 += m * (m - 3) * (m - 2) * (m - 1) / 24;
						money15 = ExChangeUtil.maxRebate(sxzt, pv15, sx1);
					}
					// 五肖中特
					if (wxzt.length != 0 && !"".equals(wxzt[0])) {
						if (wxzt.length < 5) {
							count = 0;
							return new JsonResult("xinxi", count);
						}
						int m = wxzt.length;
						count16 += m * (m - 4) * (m - 3) * (m - 2) * (m - 1) / 120;
						money16 = ExChangeUtil.maxRebate(wxzt, pv16, sx1);
					}
					// 六肖中特
					if (lxzt.length != 0 && !"".equals(lxzt[0])) {
						if (lxzt.length < 6) {
							count = 0;
							return new JsonResult("xinxi", count);
						}
						int m = lxzt.length;
						count17 += m * (m - 5) * (m - 4) * (m - 3) * (m - 2) * (m - 1) / 720;
						money17 = ExChangeUtil.maxRebate(lxzt, pv17, sx1);
					}
					// 平特一肖
					if (pt1x.length != 0 && !"".equals(pt1x[0])) {
						count18 += pt1x.length;
						money18 = ExChangeUtil.maxRebate(pt1x, pv18, sx1);
					}
					// 平特二肖
					if (pt2x.length != 0 && !"".equals(pt2x[0])) {
						if (pt2x.length < 2) {
							count = 0;
							return new JsonResult("xinxi", count);
						}
						count19 += pt2x.length * (pt2x.length - 1) / 2;
						money19 = ExChangeUtil.maxRebate(pt2x, pv19, sx1);
					}
					// 平特三肖
					if (pt3x.length != 0 && !"".equals(pt3x[0])) {
						if (pt3x.length < 3) {
							count = 0;
							return new JsonResult("xinxi", count);
						}
						int m = pt3x.length;
						count20 += m * (m - 1) * (m - 2) / 6;
						money20 = ExChangeUtil.maxRebate(pt3x, pv20, sx1);
					}
					// 平特四肖
					if (pt4x.length != 0 && !"".equals(pt4x[0])) {
						if (pt4x.length < 4) {
							count = 0;
							return new JsonResult("xinxi", count);
						}
						int m = pt4x.length;
						count21 += m * (m - 3) * (m - 2) * (m - 1) / 24;
						money21 = ExChangeUtil.maxRebate(pt4x, pv21, sx1);
					}
					// 平特一尾
					String[] ptw = { "0", "1", "2", "3", "4", "5", "6", "7", "8", "9" };
					if (pt1w.length != 0 && !"".equals(pt1w[0])) {
						count22 += pt1w.length;
						money22 = ExChangeUtil.maxRebate(pt1w, pv22, ptw);
					}
					// 平特二尾
					if (pt2w.length != 0 && !"".equals(pt2w[0])) {
						if (pt2w.length < 2) {
							count = 0;
							return new JsonResult("xinxi", count);
						}
						count23 += pt2w.length * (pt2w.length - 1) / 2;
						money23 = ExChangeUtil.maxRebate(pt2w, pv23, ptw);
					}
					// 平特三尾
					if (pt3w.length != 0 && !"".equals(pt3w[0])) {
						if (pt3w.length < 3) {
							count = 0;
							return new JsonResult("xinxi", count);
						}
						int m = pt3w.length;
						count24 += m * (m - 1) * (m - 2) / 6;
						money24 = ExChangeUtil.maxRebate(pt3w, pv24, ptw);
					}
					// 平特四尾
					if (pt4w.length != 0 && !"".equals(pt4w[0])) {
						if (pt4w.length < 4) {
							count = 0;
							return new JsonResult("xinxi", count);
						}
						int m = pt4w.length;
						count25 += m * (m - 3) * (m - 2) * (m - 1) / 24;
						money25 = ExChangeUtil.maxRebate(pt4w, pv25, ptw);
					}
					// 五不中
					if (wbz.length != 0 && !"".equals(wbz[0])) {
						if (wbz.length < 5 || wbz.length > 12) {
							count = 0;
							return new JsonResult("xinxi", count);
						}
						int m = wbz.length;
						if (m == 12) {
							count26 += 792;
						} else if (m == 11) {
							count26 += 462;
						} else if (m == 10) {
							count26 += 252;
						} else if (m == 9) {
							count26 += 126;
						} else if (m == 8) {
							count26 += 56;
						} else if (m == 7) {
							count26 += 21;
						} else if (m == 6) {
							count26 += 6;
						} else if (m == 5) {
							count26 += 1;
						} else {
							count26 = 0;
						}
						money26 = 1 * ExChangeUtil.rebate(str26);
					}
					// 六不中
					if (lbz.length != 0 && !"".equals(lbz[0])) {
						if (lbz.length < 6 || lbz.length > 12) {
							count = 0;
							return new JsonResult("xinxi", count);
						}
						int m = lbz.length;
						if (m == 12) {
							count27 += 924;
						} else if (m == 11) {
							count27 += 462;
						} else if (m == 10) {
							count27 += 210;
						} else if (m == 9) {
							count27 += 84;
						} else if (m == 8) {
							count27 += 28;
						} else if (m == 7) {
							count27 += 7;
						} else if (m == 6) {
							count27 += 1;
						} else {
							count27 = 0;
						}
						money27 = 1 * ExChangeUtil.rebate(str27);
					}

					// 七不中
					if (qbz.length != 0 && !"".equals(qbz[0])) {
						if (qbz.length < 7 || qbz.length > 12) {
							count = 0;
							return new JsonResult("xinxi", count);
						}
						int m = qbz.length;
						if (m == 12) {
							count28 += 792;
						} else if (m == 11) {
							count28 += 330;
						} else if (m == 10) {
							count28 += 120;
						} else if (m == 9) {
							count28 += 36;
						} else if (m == 8) {
							count28 += 8;
						} else if (m == 7) {
							count28 += 1;
						} else {
							count28 = 0;
						}
						money28 = 1 * ExChangeUtil.rebate(str28);
					}
					// 八不中
					if (bbz.length != 0 && !"".equals(bbz[0])) {
						if (bbz.length < 8 || bbz.length > 12) {
							count = 0;
							return new JsonResult("xinxi", count);
						}
						int m = bbz.length;
						if (m == 12) {
							count29 += 495;
						} else if (m == 11) {
							count29 += 165;
						} else if (m == 10) {
							count29 += 45;
						} else if (m == 9) {
							count29 += 9;
						} else if (m == 8) {
							count29 += 1;
						} else {
							count29 = 0;
						}
						money29 = 1 * ExChangeUtil.rebate(str29);
					}
					// 九不中
					if (jbz.length != 0 && !"".equals(jbz[0])) {
						if (jbz.length < 9 || jbz.length > 13) {
							count = 0;
							return new JsonResult("xinxi", count);
						}
						int m = jbz.length;
						if (m == 13) {
							count30 += 715;
						} else if (m == 12) {
							count30 += 220;
						} else if (m == 11) {
							count30 += 55;
						} else if (m == 10) {
							count30 += 10;
						} else if (m == 9) {
							count30 += 1;
						} else {
							count30 += 0;
						}
						money30 = 1 * ExChangeUtil.rebate(str30);
					}
					// 10不中
					if (shbz.length != 0 && !"".equals(shbz[0])) {
						if (shbz.length < 10 || shbz.length > 13) {
							count = 0;
							return new JsonResult("xinxi", count);
						}
						int m = shbz.length;
						if (m == 13) {
							count31 += 286;
						} else if (m == 12) {
							count31 += 66;
						} else if (m == 11) {
							count31 += 11;
						} else if (m == 10) {
							count31 += 1;
						} else {
							count31 += 0;
						}
						money31 = 1 * ExChangeUtil.rebate(str31);
					}
					// 11不中
					if (sh1bz.length != 0 && !"".equals(sh1bz[0])) {
						if (sh1bz.length < 11 || sh1bz.length > 14) {
							count = 0;
							return new JsonResult("xinxi", count);
						}
						int m = sh1bz.length;
						if (m == 14) {
							count32 += 364;
						} else if (m == 13) {
							count32 += 78;
						} else if (m == 12) {
							count32 += 12;
						} else if (m == 11) {
							count32 += 1;
						} else {
							count32 += 0;
						}
						money32 = 1 * ExChangeUtil.rebate(str32);
					}
					// 12不中
					if (sh2bz.length != 0 && !"".equals(sh2bz[0])) {
						if (sh2bz.length < 12 || sh2bz.length > 15) {
							count = 0;
							return new JsonResult("xinxi", count);
						}
						int m = sh2bz.length;
						if (m == 15) {
							count33 += 445;
						} else if (m == 14) {
							count33 += 91;
						} else if (m == 13) {
							count33 += 13;
						} else if (m == 12) {
							count33 += 1;
						} else {
							count33 += 0;
						}
						money33 = 1 * ExChangeUtil.rebate(str33);
					}
					// 13不中
					if (sh3bz.length != 0 && !"".equals(sh3bz[0])) {
						if (sh3bz.length < 13 || sh3bz.length > 16) {
							count = 0;
							return new JsonResult("xinxi", count);
						}
						int m = sh3bz.length;
						if (m == 16) {
							count34 += 560;
						} else if (m == 15) {
							count34 += 105;
						} else if (m == 14) {
							count34 += 14;
						} else if (m == 13) {
							count34 += 1;
						} else {
							count34 += 0;
						}
						money34 = 1 * ExChangeUtil.rebate(str34);
					}
					// 14不中
					if (sh4bz.length != 0 && !"".equals(sh4bz[0])) {
						if (sh4bz.length < 14 || sh4bz.length > 17) {
							count = 0;
							return new JsonResult("xinxi", count);
						}
						int m = sh4bz.length;
						if (m == 17) {
							count35 += 680;
						} else if (m == 16) {
							count35 += 120;
						} else if (m == 15) {
							count35 += 15;
						} else if (m == 14) {
							count35 += 1;
						} else {
							count35 += 0;
						}
						money35 = 1 * ExChangeUtil.rebate(str35);
					}
					// 15不中
					if (sh5bz.length != 0 && !"".equals(sh5bz[0])) {
						int m = sh5bz.length;
						if (sh5bz.length < 15 || sh5bz.length > 18) {
							count = 0;
							return new JsonResult("xinxi", count);
						}
						if (m == 18) {
							count36 += 816;
						} else if (m == 17) {
							count36 += 136;
						} else if (m == 16) {
							count36 += 16;
						} else if (m == 15) {
							count36 += 1;
						} else {
							count36 += 0;
						}
						money36 = ExChangeUtil.rebate(str36);
					}
					// 总肖
					if (zx.length != 0 && !"".equals(zx[0])) {
						count37 += zx.length;
						money37 = ExChangeUtil.zxds(zx, pv37);
					}
					// 色波
					String[] b1 = { "红波", "蓝波", "绿波" };
					if (sb.length != 0 && !"".equals(sb[0])) {
						count38 += sb.length;
						money38 = ExChangeUtil.maxRebate(sb, pv38, b1);
					}
					// 半波
					String[] bb1 = { "红大", "红小", "红单", "红双", "蓝大", "蓝小", "蓝单", "蓝双", "绿大", "绿小", "绿单", "绿双" };
					if (bb.length != 0 && !"".equals(bb[0])) {
						count39 += bb.length;
						money39 = ExChangeUtil.maxRebate(bb, pv39, bb1);
					}
					// 半半波
					String[] bbb1 = { "红大单", "红大双", "红小单", "红小双", "蓝大单", "蓝大双", "蓝小单", "蓝小双", "绿大单", "绿大双", "绿小单", "绿小双" };
					if (bbb.length != 0 && !"".equals(bbb[0])) {
						count40 += bbb.length;
						money40 = ExChangeUtil.maxRebate(bbb, pv40, bbb1);
					}
					break;
					
				case "bj28":
				case "xy28":
				case "jnd28":
					String[] hunhe = o.getStr1().split(",");
					String[] tms = o.getStr2().split(",");
					String[] tmbs = o.getStr3().split(",");
					String[] bs = o.getStr4().split(",");
					String[] bz = o.getStr5().split(",");
					
					String [] hunhe1 = {"大","小","单","双","大单","大双","小单","小双","极大","极小"}; 
					
					String [] tms1 = {"0","1","2","3","4","5","6","7","8","9","10","11","12","13","14","15","16","17","18","19","20",
							"21","22","23","24","25","26","27"}; 
					
					String[] bose1 = {"红波","绿波","蓝波"};
					//混合
					if(hunhe.length!=0&&!"".equals(hunhe[0])) {
						count1 += hunhe.length;
						money1 = ExChangeUtil.maxRebate(hunhe,pv1,hunhe1);
					}
					
					//特码
					if(tms.length!=0&&!"".equals(tms[0])) {
						count2 += tms.length;
						money2 = ExChangeUtil.maxRebate(tms,pv2,tms1);
					}
					
					//特码包三
					if(tmbs.length!=0&&!"".equals(tmbs[0])) {
						count3 += tmbs.length;
						money3 = ExChangeUtil.maxRebate(tmbs,pv3,tms1);
					}
					
					//波色
					if(bs.length!=0&&!"".equals(bs[0])) {
						count4 += bs.length;
						money4 =  ExChangeUtil.maxRebate(bs,pv4,bose1);
					}
					
					//豹子
					String[] baozi1 = {"豹子"};
					if(bz.length!=0&&!"".equals(bz[0])) {
						count5 += bz.length;
						money5 = ExChangeUtil.maxRebate(bz,pv5,baozi1);
					}
					break;
					
				}
				/** 下注注数 */
				o.setCount1(count1);
				o.setCount2(count2);
				o.setCount3(count3);
				o.setCount4(count4);
				o.setCount5(count5);
				o.setCount6(count6);
				o.setCount7(count7);
				o.setCount8(count8);
				o.setCount9(count9);
				o.setCount10(count10);
				o.setCount11(count11);
				o.setCount12(count12);
				o.setCount13(count13);
				o.setCount14(count14);
				o.setCount15(count15);
				o.setCount16(count16);
				o.setCount17(count17);
				o.setCount18(count18);
				o.setCount19(count19);
				o.setCount20(count20);
				o.setCount21(count21);
				o.setCount22(count22);
				o.setCount23(count23);
				o.setCount24(count24);
				o.setCount25(count25);
				o.setCount26(count26);
				o.setCount27(count27);
				o.setCount28(count28);
				o.setCount29(count29);
				o.setCount30(count30);
				o.setCount31(count31);
				o.setCount32(count32);
				o.setCount33(count33);
				o.setCount34(count34);
				o.setCount35(count35);
				o.setCount36(count36);
				o.setCount37(count37);
				o.setCount38(count38);
				o.setCount39(count39);
				o.setCount40(count40);

				count = count1 + count2 + count3 + count4 + count5 + count6 + count7 + count8 + count9 + count10 + count11
						+ count12 + count13 + count14 + count15 + count16 + count17 + count18 + count19 + count20 + count21
						+ count22 + count23 + count24 + count25 + count26 + count27 + count28 + count29 + count30 + count31
						+ count32 + count33 + count34 + count35 + count36 + count37 + count38 + count39 + count40;

				money = money1 + money2 + money3 + money4 + money5 + money6 + money7 + money8 + money9 + money10 + money11
						+ money12 + money13 + money14 + money15 + money16 + money17 + money18 + money19 + money20 + money21
						+ money22 + money23 + money24 + money25 + money26 + money27 + money28 + money29 + money30 + money31
						+ money32 + money33 + money34 + money35 + money36 + money37 + money38 + money39 + money40;

				message = money + "";
				return new JsonResult(message, count);
	}


}
