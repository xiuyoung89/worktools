package com.ja.sevice.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ja.dao.OperationlogMapper;
import com.ja.domain.AdminUser;
import com.ja.domain.Operationlog;
import com.ja.sevice.OperationlogService;
import com.ja.util.DateUtil;

@Service
public class OperationlogServiceImpl implements OperationlogService {
	
	@Autowired
	private OperationlogMapper operatiologMapper;

	@Override
	public Integer addOperationlog(AdminUser admin,String remarks,String type) {
		Operationlog log = new Operationlog();
		log.setName(admin.getName());
		log.setOperationtype(type);
		log.setRemarks(remarks);
		log.setOperationtime(DateUtil.getCurrTime());
		log.setTime(DateUtil.findFormatDate());
		return operatiologMapper.addOperationlog(log);
	}

	@Override
	public List<Operationlog> getAllOperationlog() {
		return operatiologMapper.getAllOperationlog();
	}

	@Override
	public List<Operationlog> findOperationlog(Operationlog o) {
		return operatiologMapper.findOperationlog(o);
	}

	@Override
	public Integer delOperationlog(Integer id) {
		return operatiologMapper.delOperationlog(id);
	}



}
