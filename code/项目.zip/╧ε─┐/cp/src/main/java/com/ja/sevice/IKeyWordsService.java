package com.ja.sevice;

import java.util.List;

import com.ja.domain.KeyWords;

/**
 * TODO java文件
 * @Title　IKeyWordsService.java
 * @Vers　v1.0
 * @AUTH　Bean
 * @Time　2018年5月23日 上午10:23:29
 */
public interface IKeyWordsService {

	int insert(KeyWords keyWords);

	int delById(KeyWords keyWords);

	List<KeyWords> findAll();

}
