package com.ja.sevice;

import java.util.List;

import com.ja.domain.AdminUser;
import com.ja.domain.Jine;
import com.ja.domain.Liushui;
import com.ja.domain.Lsltjl;
import com.ja.domain.PagingData;
import com.ja.domain.User;
import com.ja.util.JsonResult;

public interface LiushuiService {
	
	/**
	 * 	平台用户在线充值 - 人工加款   变动接口
	 * @param user 用户对象
	 * @param admin 管理员对象
	 * @param orderNum 充值订单号
	 * @param amount 操作的金额
	 * @param jine  充值信息
	 * @param model 金额变动类型
	 * @param type  1-在线充值   2-人工充值  类型
	 * @return
	 */
	int changeRecord(User user,AdminUser admin,String orderNum,Double amount, Jine jine,String model,Integer type);
	
	/**
	 * 	平台内部账号  人工加款 - 人工扣款   变动接口
	 * @param user 用户对象
	 * @param admin 管理员对象
	 * @param orderNum 加款扣款订单号
	 * @param amount 操作的金额
	 * @param model 金额变动类型
	 * @param type 1-人工加款  2-人工扣款  类型
	 * @return
	 */
	int insideRecord(User user,AdminUser admin,String orderNum,Double amount,String model,Integer type);

	/**
	 * 	平台用户在线提款  在线提款 - 人工扣款 流水记录
	 * @param user 用户信息
	 * @param admin 管理员信息
	 * @param orderNum 提款-扣款 订单号
	 * @param amount 操作的金额
	 * @param jine  充值信息
	 * @param model 金额变动类型
	 * @param type  1-在线提款   2-人工扣款  类型
	 * @return
	 */
	int drawingRecord(User user,AdminUser admin,String orderNum,Double amount,Jine jine,String model,Integer type);
	
	/**
	 *  平台用户参加活动的流水记录
	 * @param user 用信息
	 * @param state 收入支出状态
	 * @param money 变动金额
	 * @param model 变动类型
	 * @param type 变动类型代号  1 红包扣款 2 领取红包 3 幸运转盘 4 每日签到
	 * @return
	 */
	int addActivityRecord(User user, String ordrNum,boolean state, double money, String model,Integer type);

	/**
	  *   方法名：signInUserIng   
	  *   描述：     用户进行签到                  TODO   
	  *   参数：    @param users
	  *   参数：    @return 
	 * @return: JsonResult
	 */
	JsonResult signInUserIng(User users);
	
	
	
	/**查询当前中户的所有流水记录*/
	List<Liushui> getLiushui(Integer id);
   
	/**查询所有流水
	 * @param i 
	 * @param integer2 
	 * @param integer */
	List<Liushui> getAllJl(Integer integer, Integer integer2, int i);

	/**根据条件查询流水
	 * @param i 
	 * @param integer2 
	 * @param integer */
	List<Liushui> getTypeJl(Integer integer, Integer integer2, Liushui liushui, String date1, String date2, int i);

	/**代理下级的流水记录单个*/
	List<Liushui> getOneLsJl(Liushui liushui, String date1, String date2, Integer id);

	/**查询全部反水记录 */
	List<Liushui> getFanshuiJl();
	
	/**个人投注反水记录*/
	List<Liushui> getOneFanshui(Integer id);

	/**已读状态 integer */
	int upliushui(Integer id);

	/** 当前有多少条未读 */
	int weidu(Integer id);

	/**今天的投注总计*/
	Double getToday1(String cre1);
	
	/**今天的派奖总计*/
	double getToday2(String cre1);

	/**今天的返点总计*/
	double getToday3(String cre1);
	
	/**今天的返水总计*/
	double getToday4(String cre1);
	
    /**用户的签到记录*/
	List<Liushui> getSignInRecord(Integer id);

	/**所有用户的签到记录*/
	List<Liushui> getAllSignInRecord();

	/**查询有没有签到*/
	Liushui checkSigIn(Integer id,String date);
	
	/**查询聊天记录*/
	List<Lsltjl> query(String date);
	/**/
	User chax(Integer id);
	
	List<User> img(List<Integer> list);

	/**
	 * 查询所有的代理
	 * @return
	 */
	List<User> findAgentUserList();

	/**
	 * 根据条件查询代理
	 * @param user 用户信息
	 * @return
	 */
	List<User> findTermAgentList(User user);

	/**
	 * 查询用户的未读流水
	 * @param id 用户id
	 * @param i 
	 * @param integer2 
	 * @param integer 
	 * @return
	 */
	List<Liushui> getWDLiushui(Integer startIndex, Integer lineCount, Integer id, int model);

	/**
	 * 查询用户的已读流水
	 * @param id 用户id
	 * @param i 
	 * @param integer2 
	 * @param integer 
	 * @return
	 */
	List<Liushui> getYDLiushui(Integer startIndex, Integer lineCount, Integer id, int model);

	/**定时删除流水表里面的试玩账号记录*/
	void deleteliushui(Integer userid);

	/**
	 * 查询某段时间数据详情
	 * @param findFormatDate
	 * @return
	 */
	List<Liushui> findByTimeDetails(String findFormatDate);
	
	/**
	 * 领取返点金额
	 * @param user_id 用户信息
	 * @return
	 */
	int receiveRebateMoney(Integer user_id);

	/**
	 * 
	    *   方法名：getWDLiushuiCounts   
	    *   描述：       查询未读流水的数量                TODO   
	    *   参数：    @param id
	    *   参数：    @return 
	 * @param state 
	 * @return: Integer
	 */
	Integer getWDLiushuiCounts(Integer id, int state);

	/**
	 * 
	 *   方法名：getAllJlCounts   
	 *   描述：                       TODO   
	 *   参数：    @return 
	 * @return: Integer
	 */
	Integer getAllJlCounts();

	/**
	 * 
	 *   方法名：getTypeJlCounts   
	 *   描述：                       TODO   
	 *   参数：    @param liushui
	 *   参数：    @param date1
	 *   参数：    @param date2
	 *   参数：    @param i
	 *   参数：    @return 
	 * @return: Integer
	 */
	Integer getTypeJlCounts(Liushui liushui, String date1, String date2);

	/**
	 * 
	   *   方法名：getLiushuiCounts   
	   *   描述：                       TODO   
	   *   参数：    @param id
	   *   参数：    @return 
	 * @return: Integer
	 */
	Integer getLiushuiCounts(Liushui liushui);
	
	/**
	 * 
	   *   方法名：getLiushuis   
	   *   描述：                       TODO   
	   *   参数：    @param paging
	   *   参数：    @param id
	   *   参数：    @return 
	 * @return: List<Liushui>
	 */
	List<Liushui> getLiushuis(PagingData paging,Liushui liushui);
	/**
	 * 
	 * @param userid
	 * @return
	 */
	Double checkinTotal(Integer userid);

	/**
	 * @return
	 */
	List<Liushui> findWaterData();

	/**
	 * @param liushui
	 */
	void updateWaterData(Liushui liushui);


}
