package com.ja.domain;

import java.io.Serializable;

public class PlayCount implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = -2290706051247167297L;

	private Integer id;// 私彩玩下人数-金额统计

	private String cname;// 彩种名

	private String period;// 期号

	private String cplay;// 玩法

	private Integer count;// 玩法

	private Double price;// 单价

	private Double rebate;// 最高赔率

	private Double payMoney;// 消费金额

	private Integer d1q; // 1-10球次数  大-和 豹子-对子
	private Integer d2q;
	private Integer d3q;
	private Integer d4q;
	private Integer d5q;
	private Integer d6q;
	private Integer d7q;
	private Integer d8q;
	private Integer d9q;
	private Integer d10q;
	private Integer d11q;
	private Integer d12q;
	private Integer d13q;
	private Integer d14q;
	private Integer d15q;
	private Integer d16q;
	private Integer d17q;
	private Integer d18q;
	private Integer d19q;
	private Integer d20q;
	private Integer d21q;
	private Integer d22q;
	private Integer d23q;
	private Integer d24q;
	private Integer d25q;
	private Integer d26q;
	private Integer d27q;
	private Integer d28q;
	private Integer d29q;
	private Integer d30q;
	private Integer d31q;
	private Integer d32q;
	private Integer d33q;
	private Integer d34q;
	private Integer d35q;
	private Integer d36q;
	private Integer d37q;
	private Integer d38q;
	private Integer d39q;
	private Integer d40q;
	private Integer d41q;
	private Integer d42q;
	private Integer d43q;
	private Integer d44q;
	private Integer d45q;
	private Integer d46q;
	private Integer d47q;
	private Integer d48q;
	private Integer d49q;
	private Integer dan;
	private Integer shuang;
	private Integer da;
	private Integer xiao;
	private Integer longs;
	private Integer hu;
	private Integer he;
	private Integer baozi;
	private Integer shunzi;
	private Integer duizi;
	private Integer banshun;
	private Integer zaliu;
	private Integer slhtx;
	private Integer sthtx;
	private Integer shu;
	private Integer niu;
	private Integer tu;
	private Integer she;
	private Integer ma;
	private Integer yang;
	private Integer hou;
	private Integer ji;
	private Integer gou;
	private Integer zhu;
	private Integer jiaxiao;
	private Integer yexiao;
	private Integer tianxiao;
	private Integer dixiao;
	private Integer lingtou;
	private Integer yitou;
	private Integer ertou;
	private Integer santou;
	private Integer sitou;
	private Integer lingwei;
	private Integer yiwei;
	private Integer erwei;
	private Integer sanwei;
	private Integer siwei;
	private Integer wuwei;
	private Integer liuwei;
	private Integer qiwei;
	private Integer bawei;
	private Integer jiuwei;
	private Integer jin;
	private Integer mu;
	private Integer shui;
	private Integer huo;
	private Integer tus;
	private Integer erxiao;
	private Integer sanxiao;
	private Integer sixiao;
	private Integer wuxiao;
	private Integer liuxiao;
	private Integer qixiao;
	private Integer hongbo;
	private Integer lanbo;
	private Integer lvbo;
	private Integer hongda;
	private Integer hongxiao;
	private Integer hongdan;
	private Integer hongshuang;
	private Integer landa;
	private Integer lanxiao;
	private Integer landan;
	private Integer lanshuang;
	private Integer lvda;
	private Integer lvxiao;
	private Integer lvdan;
	private Integer lvshuang;
	private Integer hongdadan;
	private Integer hongdashuang;
	private Integer hongxiaodan;
	private Integer hongxiaoshuang;
	private Integer landadan;
	private Integer landashuang;
	private Integer lanxiaodan;
	private Integer lanxiaoshuang;
	private Integer lvdadan;
	private Integer lvdashuang;
	private Integer lvxiaodan;
	private Integer lvxiaoshuang;
	private Integer dadan;
	private Integer dashuang;
	private Integer xiaodan;
	private Integer xiaoshuang;
	private Integer jida;
	private Integer jixiao;
	private String createTime;// 创建时间
    
    public static long getSerialversionuid() {
		return serialVersionUID;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getCname() {
		return cname;
	}

	public void setCname(String cname) {
		this.cname = cname;
	}

	public String getPeriod() {
		return period;
	}

	public void setPeriod(String period) {
		this.period = period;
	}

	public String getCplay() {
		return cplay;
	}

	public void setCplay(String cplay) {
		this.cplay = cplay;
	}

	public Integer getCount() {
		return count;
	}

	public void setCount(Integer count) {
		this.count = count;
	}

	public Double getPrice() {
		return price;
	}

	public void setPrice(Double price) {
		this.price = price;
	}

	public Double getRebate() {
		return rebate;
	}

	public void setRebate(Double rebate) {
		this.rebate = rebate;
	}

	public Double getPayMoney() {
		return payMoney;
	}

	public void setPayMoney(Double payMoney) {
		this.payMoney = payMoney;
	}

	public Integer getD1q() {
		return d1q;
	}

	public void setD1q(Integer d1q) {
		this.d1q = d1q;
	}

	public Integer getD2q() {
		return d2q;
	}

	public void setD2q(Integer d2q) {
		this.d2q = d2q;
	}

	public Integer getD3q() {
		return d3q;
	}

	public void setD3q(Integer d3q) {
		this.d3q = d3q;
	}

	public Integer getD4q() {
		return d4q;
	}

	public void setD4q(Integer d4q) {
		this.d4q = d4q;
	}

	public Integer getD5q() {
		return d5q;
	}

	public void setD5q(Integer d5q) {
		this.d5q = d5q;
	}

	public Integer getD6q() {
		return d6q;
	}

	public void setD6q(Integer d6q) {
		this.d6q = d6q;
	}

	public Integer getD7q() {
		return d7q;
	}

	public void setD7q(Integer d7q) {
		this.d7q = d7q;
	}

	public Integer getD8q() {
		return d8q;
	}

	public void setD8q(Integer d8q) {
		this.d8q = d8q;
	}

	public Integer getD9q() {
		return d9q;
	}

	public void setD9q(Integer d9q) {
		this.d9q = d9q;
	}

	public Integer getD10q() {
		return d10q;
	}

	public void setD10q(Integer d10q) {
		this.d10q = d10q;
	}

	public Integer getD11q() {
		return d11q;
	}

	public void setD11q(Integer d11q) {
		this.d11q = d11q;
	}

	public Integer getD12q() {
		return d12q;
	}

	public void setD12q(Integer d12q) {
		this.d12q = d12q;
	}

	public Integer getD13q() {
		return d13q;
	}

	public void setD13q(Integer d13q) {
		this.d13q = d13q;
	}

	public Integer getD14q() {
		return d14q;
	}

	public void setD14q(Integer d14q) {
		this.d14q = d14q;
	}

	public Integer getD15q() {
		return d15q;
	}

	public void setD15q(Integer d15q) {
		this.d15q = d15q;
	}

	public Integer getD16q() {
		return d16q;
	}

	public void setD16q(Integer d16q) {
		this.d16q = d16q;
	}

	public Integer getD17q() {
		return d17q;
	}

	public void setD17q(Integer d17q) {
		this.d17q = d17q;
	}

	public Integer getD18q() {
		return d18q;
	}

	public void setD18q(Integer d18q) {
		this.d18q = d18q;
	}

	public Integer getD19q() {
		return d19q;
	}

	public void setD19q(Integer d19q) {
		this.d19q = d19q;
	}

	public Integer getD20q() {
		return d20q;
	}

	public void setD20q(Integer d20q) {
		this.d20q = d20q;
	}

	public Integer getD21q() {
		return d21q;
	}

	public void setD21q(Integer d21q) {
		this.d21q = d21q;
	}

	public Integer getD22q() {
		return d22q;
	}

	public void setD22q(Integer d22q) {
		this.d22q = d22q;
	}

	public Integer getD23q() {
		return d23q;
	}

	public void setD23q(Integer d23q) {
		this.d23q = d23q;
	}

	public Integer getD24q() {
		return d24q;
	}

	public void setD24q(Integer d24q) {
		this.d24q = d24q;
	}

	public Integer getD25q() {
		return d25q;
	}

	public void setD25q(Integer d25q) {
		this.d25q = d25q;
	}

	public Integer getD26q() {
		return d26q;
	}

	public void setD26q(Integer d26q) {
		this.d26q = d26q;
	}

	public Integer getD27q() {
		return d27q;
	}

	public void setD27q(Integer d27q) {
		this.d27q = d27q;
	}

	public Integer getD28q() {
		return d28q;
	}

	public void setD28q(Integer d28q) {
		this.d28q = d28q;
	}

	public Integer getD29q() {
		return d29q;
	}

	public void setD29q(Integer d29q) {
		this.d29q = d29q;
	}

	public Integer getD30q() {
		return d30q;
	}

	public void setD30q(Integer d30q) {
		this.d30q = d30q;
	}

	public Integer getD31q() {
		return d31q;
	}

	public void setD31q(Integer d31q) {
		this.d31q = d31q;
	}

	public Integer getD32q() {
		return d32q;
	}

	public void setD32q(Integer d32q) {
		this.d32q = d32q;
	}

	public Integer getD33q() {
		return d33q;
	}

	public void setD33q(Integer d33q) {
		this.d33q = d33q;
	}

	public Integer getD34q() {
		return d34q;
	}

	public void setD34q(Integer d34q) {
		this.d34q = d34q;
	}

	public Integer getD35q() {
		return d35q;
	}

	public void setD35q(Integer d35q) {
		this.d35q = d35q;
	}

	public Integer getD36q() {
		return d36q;
	}

	public void setD36q(Integer d36q) {
		this.d36q = d36q;
	}

	public Integer getD37q() {
		return d37q;
	}

	public void setD37q(Integer d37q) {
		this.d37q = d37q;
	}

	public Integer getD38q() {
		return d38q;
	}

	public void setD38q(Integer d38q) {
		this.d38q = d38q;
	}

	public Integer getD39q() {
		return d39q;
	}

	public void setD39q(Integer d39q) {
		this.d39q = d39q;
	}

	public Integer getD40q() {
		return d40q;
	}

	public void setD40q(Integer d40q) {
		this.d40q = d40q;
	}

	public Integer getD41q() {
		return d41q;
	}

	public void setD41q(Integer d41q) {
		this.d41q = d41q;
	}

	public Integer getD42q() {
		return d42q;
	}

	public void setD42q(Integer d42q) {
		this.d42q = d42q;
	}

	public Integer getD43q() {
		return d43q;
	}

	public void setD43q(Integer d43q) {
		this.d43q = d43q;
	}

	public Integer getD44q() {
		return d44q;
	}

	public void setD44q(Integer d44q) {
		this.d44q = d44q;
	}

	public Integer getD45q() {
		return d45q;
	}

	public void setD45q(Integer d45q) {
		this.d45q = d45q;
	}

	public Integer getD46q() {
		return d46q;
	}

	public void setD46q(Integer d46q) {
		this.d46q = d46q;
	}

	public Integer getD47q() {
		return d47q;
	}

	public void setD47q(Integer d47q) {
		this.d47q = d47q;
	}

	public Integer getD48q() {
		return d48q;
	}

	public void setD48q(Integer d48q) {
		this.d48q = d48q;
	}

	public Integer getD49q() {
		return d49q;
	}

	public void setD49q(Integer d49q) {
		this.d49q = d49q;
	}

	public Integer getDan() {
		return dan;
	}

	public void setDan(Integer dan) {
		this.dan = dan;
	}

	public Integer getShuang() {
		return shuang;
	}

	public void setShuang(Integer shuang) {
		this.shuang = shuang;
	}

	public Integer getDa() {
		return da;
	}

	public void setDa(Integer da) {
		this.da = da;
	}

	public Integer getXiao() {
		return xiao;
	}

	public void setXiao(Integer xiao) {
		this.xiao = xiao;
	}

	public Integer getLongs() {
		return longs;
	}

	public void setLongs(Integer longs) {
		this.longs = longs;
	}

	public Integer getHu() {
		return hu;
	}

	public void setHu(Integer hu) {
		this.hu = hu;
	}

	public Integer getHe() {
		return he;
	}

	public void setHe(Integer he) {
		this.he = he;
	}

	public Integer getBaozi() {
		return baozi;
	}

	public void setBaozi(Integer baozi) {
		this.baozi = baozi;
	}

	public Integer getShunzi() {
		return shunzi;
	}

	public void setShunzi(Integer shunzi) {
		this.shunzi = shunzi;
	}

	public Integer getDuizi() {
		return duizi;
	}

	public void setDuizi(Integer duizi) {
		this.duizi = duizi;
	}

	public Integer getBanshun() {
		return banshun;
	}

	public void setBanshun(Integer banshun) {
		this.banshun = banshun;
	}

	public Integer getZaliu() {
		return zaliu;
	}

	public void setZaliu(Integer zaliu) {
		this.zaliu = zaliu;
	}

	public Integer getSlhtx() {
		return slhtx;
	}

	public void setSlhtx(Integer slhtx) {
		this.slhtx = slhtx;
	}

	public Integer getSthtx() {
		return sthtx;
	}

	public void setSthtx(Integer sthtx) {
		this.sthtx = sthtx;
	}

	public Integer getShu() {
		return shu;
	}

	public void setShu(Integer shu) {
		this.shu = shu;
	}

	public Integer getNiu() {
		return niu;
	}

	public void setNiu(Integer niu) {
		this.niu = niu;
	}

	public Integer getTu() {
		return tu;
	}

	public void setTu(Integer tu) {
		this.tu = tu;
	}

	public Integer getShe() {
		return she;
	}

	public void setShe(Integer she) {
		this.she = she;
	}

	public Integer getMa() {
		return ma;
	}

	public void setMa(Integer ma) {
		this.ma = ma;
	}

	public Integer getYang() {
		return yang;
	}

	public void setYang(Integer yang) {
		this.yang = yang;
	}

	public Integer getHou() {
		return hou;
	}

	public void setHou(Integer hou) {
		this.hou = hou;
	}

	public Integer getJi() {
		return ji;
	}

	public void setJi(Integer ji) {
		this.ji = ji;
	}

	public Integer getGou() {
		return gou;
	}

	public void setGou(Integer gou) {
		this.gou = gou;
	}

	public Integer getZhu() {
		return zhu;
	}

	public void setZhu(Integer zhu) {
		this.zhu = zhu;
	}

	public Integer getJiaxiao() {
		return jiaxiao;
	}

	public void setJiaxiao(Integer jiaxiao) {
		this.jiaxiao = jiaxiao;
	}

	public Integer getYexiao() {
		return yexiao;
	}

	public void setYexiao(Integer yexiao) {
		this.yexiao = yexiao;
	}

	public Integer getTianxiao() {
		return tianxiao;
	}

	public void setTianxiao(Integer tianxiao) {
		this.tianxiao = tianxiao;
	}

	public Integer getDixiao() {
		return dixiao;
	}

	public void setDixiao(Integer dixiao) {
		this.dixiao = dixiao;
	}

	public Integer getLingtou() {
		return lingtou;
	}

	public void setLingtou(Integer lingtou) {
		this.lingtou = lingtou;
	}

	public Integer getYitou() {
		return yitou;
	}

	public void setYitou(Integer yitou) {
		this.yitou = yitou;
	}

	public Integer getErtou() {
		return ertou;
	}

	public void setErtou(Integer ertou) {
		this.ertou = ertou;
	}

	public Integer getSantou() {
		return santou;
	}

	public void setSantou(Integer santou) {
		this.santou = santou;
	}

	public Integer getSitou() {
		return sitou;
	}

	public void setSitou(Integer sitou) {
		this.sitou = sitou;
	}

	public Integer getLingwei() {
		return lingwei;
	}

	public void setLingwei(Integer lingwei) {
		this.lingwei = lingwei;
	}

	public Integer getYiwei() {
		return yiwei;
	}

	public void setYiwei(Integer yiwei) {
		this.yiwei = yiwei;
	}

	public Integer getErwei() {
		return erwei;
	}

	public void setErwei(Integer erwei) {
		this.erwei = erwei;
	}

	public Integer getSanwei() {
		return sanwei;
	}

	public void setSanwei(Integer sanwei) {
		this.sanwei = sanwei;
	}

	public Integer getSiwei() {
		return siwei;
	}

	public void setSiwei(Integer siwei) {
		this.siwei = siwei;
	}

	public Integer getWuwei() {
		return wuwei;
	}

	public void setWuwei(Integer wuwei) {
		this.wuwei = wuwei;
	}

	public Integer getLiuwei() {
		return liuwei;
	}

	public void setLiuwei(Integer liuwei) {
		this.liuwei = liuwei;
	}

	public Integer getQiwei() {
		return qiwei;
	}

	public void setQiwei(Integer qiwei) {
		this.qiwei = qiwei;
	}

	public Integer getBawei() {
		return bawei;
	}

	public void setBawei(Integer bawei) {
		this.bawei = bawei;
	}

	public Integer getJiuwei() {
		return jiuwei;
	}

	public void setJiuwei(Integer jiuwei) {
		this.jiuwei = jiuwei;
	}

	public Integer getJin() {
		return jin;
	}

	public void setJin(Integer jin) {
		this.jin = jin;
	}

	public Integer getMu() {
		return mu;
	}

	public void setMu(Integer mu) {
		this.mu = mu;
	}

	public Integer getShui() {
		return shui;
	}

	public void setShui(Integer shui) {
		this.shui = shui;
	}

	public Integer getHuo() {
		return huo;
	}

	public void setHuo(Integer huo) {
		this.huo = huo;
	}

	public Integer getTus() {
		return tus;
	}

	public void setTus(Integer tus) {
		this.tus = tus;
	}

	public Integer getErxiao() {
		return erxiao;
	}

	public void setErxiao(Integer erxiao) {
		this.erxiao = erxiao;
	}

	public Integer getSanxiao() {
		return sanxiao;
	}

	public void setSanxiao(Integer sanxiao) {
		this.sanxiao = sanxiao;
	}

	public Integer getSixiao() {
		return sixiao;
	}

	public void setSixiao(Integer sixiao) {
		this.sixiao = sixiao;
	}

	public Integer getWuxiao() {
		return wuxiao;
	}

	public void setWuxiao(Integer wuxiao) {
		this.wuxiao = wuxiao;
	}

	public Integer getLiuxiao() {
		return liuxiao;
	}

	public void setLiuxiao(Integer liuxiao) {
		this.liuxiao = liuxiao;
	}

	public Integer getQixiao() {
		return qixiao;
	}

	public void setQixiao(Integer qixiao) {
		this.qixiao = qixiao;
	}

	public Integer getHongbo() {
		return hongbo;
	}

	public void setHongbo(Integer hongbo) {
		this.hongbo = hongbo;
	}

	public Integer getLanbo() {
		return lanbo;
	}

	public void setLanbo(Integer lanbo) {
		this.lanbo = lanbo;
	}

	public Integer getLvbo() {
		return lvbo;
	}

	public void setLvbo(Integer lvbo) {
		this.lvbo = lvbo;
	}

	public Integer getHongda() {
		return hongda;
	}

	public void setHongda(Integer hongda) {
		this.hongda = hongda;
	}

	public Integer getHongxiao() {
		return hongxiao;
	}

	public void setHongxiao(Integer hongxiao) {
		this.hongxiao = hongxiao;
	}

	public Integer getHongdan() {
		return hongdan;
	}

	public void setHongdan(Integer hongdan) {
		this.hongdan = hongdan;
	}

	public Integer getHongshuang() {
		return hongshuang;
	}

	public void setHongshuang(Integer hongshuang) {
		this.hongshuang = hongshuang;
	}

	public Integer getLanda() {
		return landa;
	}

	public void setLanda(Integer landa) {
		this.landa = landa;
	}

	public Integer getLanxiao() {
		return lanxiao;
	}

	public void setLanxiao(Integer lanxiao) {
		this.lanxiao = lanxiao;
	}

	public Integer getLandan() {
		return landan;
	}

	public void setLandan(Integer landan) {
		this.landan = landan;
	}

	public Integer getLanshuang() {
		return lanshuang;
	}

	public void setLanshuang(Integer lanshuang) {
		this.lanshuang = lanshuang;
	}

	public Integer getLvda() {
		return lvda;
	}

	public void setLvda(Integer lvda) {
		this.lvda = lvda;
	}

	public Integer getLvxiao() {
		return lvxiao;
	}

	public void setLvxiao(Integer lvxiao) {
		this.lvxiao = lvxiao;
	}

	public Integer getLvdan() {
		return lvdan;
	}

	public void setLvdan(Integer lvdan) {
		this.lvdan = lvdan;
	}

	public Integer getLvshuang() {
		return lvshuang;
	}

	public void setLvshuang(Integer lvshuang) {
		this.lvshuang = lvshuang;
	}

	public Integer getHongdadan() {
		return hongdadan;
	}

	public void setHongdadan(Integer hongdadan) {
		this.hongdadan = hongdadan;
	}

	public Integer getHongdashuang() {
		return hongdashuang;
	}

	public void setHongdashuang(Integer hongdashuang) {
		this.hongdashuang = hongdashuang;
	}

	public Integer getHongxiaodan() {
		return hongxiaodan;
	}

	public void setHongxiaodan(Integer hongxiaodan) {
		this.hongxiaodan = hongxiaodan;
	}

	public Integer getHongxiaoshuang() {
		return hongxiaoshuang;
	}

	public void setHongxiaoshuang(Integer hongxiaoshuang) {
		this.hongxiaoshuang = hongxiaoshuang;
	}

	public Integer getLandadan() {
		return landadan;
	}

	public void setLandadan(Integer landadan) {
		this.landadan = landadan;
	}

	public Integer getLandashuang() {
		return landashuang;
	}

	public void setLandashuang(Integer landashuang) {
		this.landashuang = landashuang;
	}

	public Integer getLanxiaodan() {
		return lanxiaodan;
	}

	public void setLanxiaodan(Integer lanxiaodan) {
		this.lanxiaodan = lanxiaodan;
	}

	public Integer getLanxiaoshuang() {
		return lanxiaoshuang;
	}

	public void setLanxiaoshuang(Integer lanxiaoshuang) {
		this.lanxiaoshuang = lanxiaoshuang;
	}

	public Integer getLvdadan() {
		return lvdadan;
	}

	public void setLvdadan(Integer lvdadan) {
		this.lvdadan = lvdadan;
	}

	public Integer getLvdashuang() {
		return lvdashuang;
	}

	public void setLvdashuang(Integer lvdashuang) {
		this.lvdashuang = lvdashuang;
	}

	public Integer getLvxiaodan() {
		return lvxiaodan;
	}

	public void setLvxiaodan(Integer lvxiaodan) {
		this.lvxiaodan = lvxiaodan;
	}

	public Integer getLvxiaoshuang() {
		return lvxiaoshuang;
	}

	public void setLvxiaoshuang(Integer lvxiaoshuang) {
		this.lvxiaoshuang = lvxiaoshuang;
	}

	public Integer getDadan() {
		return dadan;
	}  

	public void setDadan(Integer dadan) {
		this.dadan = dadan;
	}

	public Integer getDashuang() {
		return dashuang;
	}

	public void setDashuang(Integer dashuang) {
		this.dashuang = dashuang;
	}

	public Integer getXiaodan() {
		return xiaodan;
	}

	public void setXiaodan(Integer xiaodan) {
		this.xiaodan = xiaodan;
	}

	public Integer getXiaoshuang() {  
		return xiaoshuang;
	}

	public void setXiaoshuang(Integer xiaoshuang) {
		this.xiaoshuang = xiaoshuang;
	}

	public Integer getJida() {
		return jida;
	}

	public void setJida(Integer jida) {
		this.jida = jida;
	}

	public Integer getJixiao() {
		return jixiao;
	}

	public void setJixiao(Integer jixiao) {
		this.jixiao = jixiao;
	}

	public String getCreateTime() {
		return createTime;
	}

	public void setCreateTime(String createTime) {
		this.createTime = createTime;
	}

	@Override
	public String toString() {
		return "PlayCount [id=" + id + ", cname=" + cname + ", period=" + period + ", cplay=" + cplay + ", count="
				+ count + ", price=" + price + ", rebate=" + rebate + ", payMoney=" + payMoney + ", d1q=" + d1q
				+ ", d2q=" + d2q + ", d3q=" + d3q + ", d4q=" + d4q + ", d5q=" + d5q + ", d6q=" + d6q + ", d7q=" + d7q
				+ ", d8q=" + d8q + ", d9q=" + d9q + ", d10q=" + d10q + ", d11q=" + d11q + ", d12q=" + d12q + ", d13q="
				+ d13q + ", d14q=" + d14q + ", d15q=" + d15q + ", d16q=" + d16q + ", d17q=" + d17q + ", d18q=" + d18q
				+ ", d19q=" + d19q + ", d20q=" + d20q + ", d21q=" + d21q + ", d22q=" + d22q + ", d23q=" + d23q
				+ ", d24q=" + d24q + ", d25q=" + d25q + ", d26q=" + d26q + ", d27q=" + d27q + ", d28q=" + d28q
				+ ", d29q=" + d29q + ", d30q=" + d30q + ", d31q=" + d31q + ", d32q=" + d32q + ", d33q=" + d33q
				+ ", d34q=" + d34q + ", d35q=" + d35q + ", d36q=" + d36q + ", d37q=" + d37q + ", d38q=" + d38q
				+ ", d39q=" + d39q + ", d40q=" + d40q + ", d41q=" + d41q + ", d42q=" + d42q + ", d43q=" + d43q
				+ ", d44q=" + d44q + ", d45q=" + d45q + ", d46q=" + d46q + ", d47q=" + d47q + ", d48q=" + d48q
				+ ", d49q=" + d49q + ", dan=" + dan + ", shuang=" + shuang + ", da=" + da + ", xiao=" + xiao
				+ ", longs=" + longs + ", hu=" + hu + ", he=" + he + ", baozi=" + baozi + ", shunzi=" + shunzi
				+ ", duizi=" + duizi + ", banshun=" + banshun + ", zaliu=" + zaliu + ", slhtx=" + slhtx + ", sthtx="
				+ sthtx + ", shu=" + shu + ", niu=" + niu + ", tu=" + tu + ", she=" + she + ", ma=" + ma + ", yang="
				+ yang + ", hou=" + hou + ", ji=" + ji + ", gou=" + gou + ", zhu=" + zhu + ", jiaxiao=" + jiaxiao
				+ ", yexiao=" + yexiao + ", tianxiao=" + tianxiao + ", dixiao=" + dixiao + ", lingtou=" + lingtou
				+ ", yitou=" + yitou + ", ertou=" + ertou + ", santou=" + santou + ", sitou=" + sitou + ", lingwei="
				+ lingwei + ", yiwei=" + yiwei + ", erwei=" + erwei + ", sanwei=" + sanwei + ", siwei=" + siwei
				+ ", wuwei=" + wuwei + ", liuwei=" + liuwei + ", qiwei=" + qiwei + ", bawei=" + bawei + ", jiuwei="
				+ jiuwei + ", jin=" + jin + ", mu=" + mu + ", shui=" + shui + ", huo=" + huo + ", tus=" + tus
				+ ", erxiao=" + erxiao + ", sanxiao=" + sanxiao + ", sixiao=" + sixiao + ", wuxiao=" + wuxiao
				+ ", liuxiao=" + liuxiao + ", qixiao=" + qixiao + ", hongbo=" + hongbo + ", lanbo=" + lanbo + ", lvbo="
				+ lvbo + ", hongda=" + hongda + ", hongxiao=" + hongxiao + ", hongdan=" + hongdan + ", hongshuang="
				+ hongshuang + ", landa=" + landa + ", lanxiao=" + lanxiao + ", landan=" + landan + ", lanshuang="
				+ lanshuang + ", lvda=" + lvda + ", lvxiao=" + lvxiao + ", lvdan=" + lvdan + ", lvshuang=" + lvshuang
				+ ", hongdadan=" + hongdadan + ", hongdashuang=" + hongdashuang + ", hongxiaodan=" + hongxiaodan
				+ ", hongxiaoshuang=" + hongxiaoshuang + ", landadan=" + landadan + ", landashuang=" + landashuang
				+ ", lanxiaodan=" + lanxiaodan + ", lanxiaoshuang=" + lanxiaoshuang + ", lvdadan=" + lvdadan
				+ ", lvdashuang=" + lvdashuang + ", lvxiaodan=" + lvxiaodan + ", dadan=" + dadan + ", dashuang="
				+ dashuang + ", xiaodan=" + xiaodan + ", xiaoshuang=" + xiaoshuang + ", jida=" + jida + ", jixiao="
				+ jixiao + ", createTime=" + createTime + "]";
	}
}