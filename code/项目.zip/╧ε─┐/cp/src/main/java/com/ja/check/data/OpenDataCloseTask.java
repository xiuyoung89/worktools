package com.ja.check.data;

import java.util.Calendar;
import java.util.Timer;
import java.util.TimerTask;

/**
 * @DESC: 每天各彩种结束后取消回头看定时任务(已废弃)
 * @AUTH: qhzh 
 * @DATE: 2018年8月28日 下午3:19:07
 */
@Deprecated
public class OpenDataCloseTask {

	private Timer timer = new Timer();
	
	public void closeTaskAH11X5(){
		TimerTask task = new TimerTask() {
			public void run() {
				OpenDataReviewTask.openTimeCheckTasks.get(0).cancel();
			}
		};
		Calendar calendar = Calendar.getInstance();
		calendar.set(Calendar.HOUR_OF_DAY, 22);
		calendar.set(Calendar.MINUTE, 15);
		timer.schedule(task, calendar.getTime());
	}
	
	public void closeTaskAHK3(){
		TimerTask task = new TimerTask() {
			public void run() {
				OpenDataReviewTask.openTimeCheckTasks.get(1).cancel();
			}
		};
		Calendar calendar = Calendar.getInstance();
		calendar.set(Calendar.HOUR_OF_DAY, 22);
		calendar.set(Calendar.MINUTE, 15);
		timer.schedule(task, calendar.getTime());
	}
	
	public void closeTaskCQKL10F(){
		TimerTask task = new TimerTask() {
			public void run() {
				OpenDataReviewTask.openTimeCheckTasks.get(2).cancel();
			}
		};
		Calendar calendar = Calendar.getInstance();
		calendar.add(Calendar.DAY_OF_MONTH, 1);
		calendar.set(Calendar.HOUR_OF_DAY, 2);
		calendar.set(Calendar.MINUTE, 18);
		timer.schedule(task, calendar.getTime());
	}
	
	public void closeTaskCQSSC(){
		TimerTask task = new TimerTask() {
			public void run() {
				OpenDataReviewTask.openTimeCheckTasks.get(21).cancel();
			}
		};
		Calendar calendar = Calendar.getInstance();
		calendar.add(Calendar.DAY_OF_MONTH, 1);
		calendar.set(Calendar.HOUR_OF_DAY, 2);
		calendar.set(Calendar.MINUTE, 3);
		timer.schedule(task, calendar.getTime());
	}
	
	public void closeTaskXJSSC(){
		TimerTask task = new TimerTask() {
			public void run() {
				OpenDataReviewTask.openTimeCheckTasks.get(4).cancel();
			}
		};
		Calendar calendar = Calendar.getInstance();
		calendar.add(Calendar.DAY_OF_MONTH, 1);
		calendar.set(Calendar.HOUR_OF_DAY, 2);
		calendar.set(Calendar.MINUTE, 15);
		timer.schedule(task, calendar.getTime());
	}
	
	public void closeTaskFJ11X5(){
		TimerTask task = new TimerTask() {
			public void run() {
				OpenDataReviewTask.openTimeCheckTasks.get(5).cancel();
			}
		};
		Calendar calendar = Calendar.getInstance();
		calendar.set(Calendar.HOUR_OF_DAY, 23);
		calendar.set(Calendar.MINUTE, 15);
		timer.schedule(task, calendar.getTime());
	}
	
	public void closeTaskGD11X5(){
		TimerTask task = new TimerTask() {
			public void run() {
				OpenDataReviewTask.openTimeCheckTasks.get(6).cancel();
			}
		};
		Calendar calendar = Calendar.getInstance();
		calendar.set(Calendar.HOUR_OF_DAY, 23);
		calendar.set(Calendar.MINUTE, 15);
		timer.schedule(task, calendar.getTime());
	}
	
	public void closeTaskGDKL10F(){
		TimerTask task = new TimerTask() {
			public void run() {
				OpenDataReviewTask.openTimeCheckTasks.get(7).cancel();
			}
		};
		Calendar calendar = Calendar.getInstance();
		calendar.set(Calendar.HOUR_OF_DAY, 23);
		calendar.set(Calendar.MINUTE, 15);
		timer.schedule(task, calendar.getTime());
	}
	
	public void closeTaskGXK3(){
		TimerTask task = new TimerTask() {
			public void run() {
				OpenDataReviewTask.openTimeCheckTasks.get(8).cancel();
			}
		};
		Calendar calendar = Calendar.getInstance();
		calendar.set(Calendar.HOUR_OF_DAY, 22);
		calendar.set(Calendar.MINUTE, 42);
		timer.schedule(task, calendar.getTime());
	}
	
	public void closeTaskJLK3(){
		TimerTask task = new TimerTask() {
			public void run() {
				OpenDataReviewTask.openTimeCheckTasks.get(9).cancel();
			}
		};
		Calendar calendar = Calendar.getInstance();
		calendar.set(Calendar.HOUR_OF_DAY, 23);
		calendar.set(Calendar.MINUTE, 5);
		timer.schedule(task, calendar.getTime());
	}
	
	public void closeTaskJSK3(){
		TimerTask task = new TimerTask() {
			public void run() {
				OpenDataReviewTask.openTimeCheckTasks.get(10).cancel();
			}
		};
		Calendar calendar = Calendar.getInstance();
		calendar.set(Calendar.HOUR_OF_DAY, 22);
		calendar.set(Calendar.MINUTE, 25);
		timer.schedule(task, calendar.getTime());
	}
	
	public void closeTaskJX11X5(){
		TimerTask task = new TimerTask() {
			public void run() {
				OpenDataReviewTask.openTimeCheckTasks.get(11).cancel();
			}
		};
		Calendar calendar = Calendar.getInstance();
		calendar.set(Calendar.HOUR_OF_DAY, 23);
		calendar.set(Calendar.MINUTE, 15);
		timer.schedule(task, calendar.getTime());
	}
	
	public void closeTaskSD11X5(){
		TimerTask task = new TimerTask() {
			public void run() {
				OpenDataReviewTask.openTimeCheckTasks.get(12).cancel();
			}
		};
		Calendar calendar = Calendar.getInstance();
		calendar.set(Calendar.HOUR_OF_DAY, 23);
		calendar.set(Calendar.MINUTE, 10);
		timer.schedule(task, calendar.getTime());
	}
	
	public void closeTaskSH11X5(){
		TimerTask task = new TimerTask() {
			public void run() {
				OpenDataReviewTask.openTimeCheckTasks.get(13).cancel();
			}
		};
		Calendar calendar = Calendar.getInstance();
		calendar.add(Calendar.DAY_OF_MONTH, 1);
		calendar.set(Calendar.HOUR_OF_DAY, 0);
		calendar.set(Calendar.MINUTE, 5);
		timer.schedule(task, calendar.getTime());
	}
	
	public void closeTaskSHSSL(){
		TimerTask task = new TimerTask() {
			public void run() {
				OpenDataReviewTask.openTimeCheckTasks.get(14).cancel();
			}
		};
		Calendar calendar = Calendar.getInstance();
		calendar.set(Calendar.HOUR_OF_DAY, 22);
		calendar.set(Calendar.MINUTE, 10);
		timer.schedule(task, calendar.getTime());
	}
	
	public void closeTaskTJSSC(){
		TimerTask task = new TimerTask() {
			public void run() {
				OpenDataReviewTask.openTimeCheckTasks.get(15).cancel();
			}
		};
		Calendar calendar = Calendar.getInstance();
		calendar.set(Calendar.HOUR_OF_DAY, 23);
		calendar.set(Calendar.MINUTE, 15);
		timer.schedule(task, calendar.getTime());
	}
	
	public void closeTaskXYFT(){
		TimerTask task = new TimerTask() {
			public void run() {
				OpenDataReviewTask.openTimeCheckTasks.get(16).cancel();
			}
		};
		Calendar calendar = Calendar.getInstance();
		calendar.add(Calendar.DAY_OF_MONTH, 1);
		calendar.set(Calendar.HOUR_OF_DAY, 4);
		calendar.set(Calendar.MINUTE, 15);
		timer.schedule(task, calendar.getTime());
	}
	
	public void closeTaskBJK3(){
		TimerTask task = new TimerTask() {
			public void run() {
				OpenDataReviewTask.openTimeCheckTasks.get(17).cancel();
			}
		};
		Calendar calendar = Calendar.getInstance();
		calendar.add(Calendar.DAY_OF_MONTH, 1);
		calendar.set(Calendar.HOUR_OF_DAY, 0);
		calendar.set(Calendar.MINUTE, 5);
		timer.schedule(task, calendar.getTime());
	}
	
	public void closeTaskBJPK10(){
		TimerTask task = new TimerTask() {
			public void run() {
				OpenDataReviewTask.openTimeCheckTasks.get(18).cancel();
			}
		};
		Calendar calendar = Calendar.getInstance();
		calendar.add(Calendar.DAY_OF_MONTH, 1);
		calendar.set(Calendar.HOUR_OF_DAY, 0);
		calendar.set(Calendar.MINUTE, 7);
		timer.schedule(task, calendar.getTime());
	}
}
