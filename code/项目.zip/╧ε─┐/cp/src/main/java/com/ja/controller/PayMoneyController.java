package com.ja.controller;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.ja.domain.Jine;
import com.ja.domain.PayMoney;
import com.ja.domain.RechargeInterface;
import com.ja.domain.User;
import com.ja.sevice.AddPaymentService;
import com.ja.sevice.DepositBankService;
import com.ja.sevice.JineService;
import com.ja.sevice.RechargeInterfaceService;
import com.ja.util.JsonResult;

/**
 * 项目名称：cp   
 * 类名称：PayMoneyController.java   
 * 类描述：   用户在线充值在线提款控制层
 * 创建人：   GL
 * 创建时间：2018年12月28日 上午11:25:30   
 * @version v1.0.0
 */

@Controller
@RequestMapping("/pay")
public class PayMoneyController {

	@Autowired
	private JineService jineService;

	@Autowired
	private DepositBankService depositBankService;

	@Autowired
	private RechargeInterfaceService rechargeInterfaceService;
	
	@Autowired
	private AddPaymentService addPaymentService;
	
	/**
	 * 
	 * ----TODO：在线支付管理
	 * 
	 */
	
	/**
	 * 方法名：payAndGetCash 
	 * 描述：    在线支付页面                  
	 * 参数：    @return 
	 * @return: String
	 */
	@RequestMapping("/payAndGetCash")
	public String payAndGetCash() {
		return "/u/payAndGetCash";
	}
	
	/**
	 *   方法名：findRecharge   
	 *   描述：     查询所有的在线充值方式                     
	 *   参数：    @return 
	 * @return: JsonResult
	 */
	@ResponseBody
	@RequestMapping("/findRecharge")
	public JsonResult findRecharge() {
		List<RechargeInterface> recharge1 = rechargeInterfaceService.getRecharge();
		List<RechargeInterface> recharges = new ArrayList<>();
		for(RechargeInterface recharege : recharge1) {
			RechargeInterface recharge2 = new RechargeInterface();
			recharge2.setId(recharege.getId());
			recharge2.setP_ChannelId(recharege.getP_ChannelId());
			recharge2.setMaxMoney(recharege.getMaxMoney());
			recharge2.setMinMoney(recharege.getMinMoney());
			recharges.add(recharge2);
		}
		return new JsonResult("success", recharges);
	}
	
	/**
	 * 
	 * ----TODO：支付接口一32支付
	 * 
	 */
	
	/**
	 * 方法名：payReturn 
	 * 描述：    同步跳转地址                  
	 * 参数：    @return 
	 * @return: String
	 */
	@RequestMapping("/payReturn")
	public String payReturn() {
		return "/pay/payReturn";
	}

	/**
	 *   方法名：paymentInterface   
	 *   描述：    32支付                      
	 *   参数：    @param payType 充值方式
	 *   参数：    @param money 充值金额
	 *   参数：    @param session
	 *   参数：    @param request
	 *   参数：    @return 
	 * @return: ModelAndView
	 */
	@RequestMapping("/paymentInterface")
	public ModelAndView paymentInterface(String payType, Double money, HttpSession session, HttpServletRequest request) {
		User users = (User) session.getAttribute("user");
		ModelAndView model = jineService.insertRechargeOrder(payType,money,users,request);
		model.setViewName("/pay/paymentInterface");
		return model;
	}

	/**
	 *   方法名：payNotifys   
	 *   描述：    异步通知接口                      
	 *   参数：    @param pay 充值信息
	 *   参数：    @param session
	 *   参数：    @return 
	 * @return: JsonResult
	 */
	@ResponseBody
	@RequestMapping("/payNotifys")
	public JsonResult payNotifys(PayMoney pay, HttpSession session) {
		User users = (User) session.getAttribute("user");
		JsonResult jsonResult = jineService.payNotifys(pay,users);
		return jsonResult;
	}

	/**
	 * 
	 * ----TODO：支付接口一易信支付
	 * 
	 */
	
	/**
	 *   方法名：paymentInterfaceTwo   
	 *   描述：    易信支付                      
	 *   参数：    @param payType 充值方式
	 *   参数：    @param money 充值金额
	 *   参数：    @param session
	 *   参数：    @param request
	 *   参数：    @return 
	 * @return: ModelAndView
	 */
	@ResponseBody
	@RequestMapping("/paymentInterfaceTwo")
	public String paymentInterfaceTwo(String payType, Double money, HttpSession session, HttpServletRequest request) {
		User user = (User) session.getAttribute("user");
		String jsonResult = jineService.insertRechargeOrderTwo(payType,money,user,request);
		Thread t = new Thread(){
			@Override
			public void run() {
				jineService.timingTask(true);
			}
		};
		t.start();
		return jsonResult;
	}  

	/**
	 *   方法名：payNotifysTwo   
	 *   描述：     异步通知接口                   
	 *   参数：    @param pay 充值信息
	 *   参数：    @param session
	 *   参数：    @return 
	 * @return: JsonResult
	 */
	@ResponseBody
	@RequestMapping("/payNotifysTwo")
	public JsonResult payNotifysTwo(Integer code, Integer money,String mch_order_no,String order_no,Integer time_stamp,String attach,Integer money_order,
			Integer paytype,Integer payAmount,String token) {
		PayMoney pay = new PayMoney();
		pay.setErrCode(code+"");
		pay.setMoney(money+"");
		pay.setMerchantOrderNum(mch_order_no);
		pay.setOrderNum(order_no);
		pay.setTimestamp(time_stamp+"");
		pay.setMoney_order(money_order+"");
		pay.setChannelId(paytype+"");
		pay.setFaceValue(payAmount+"");
		pay.setPostKey(token);
		JsonResult jsonResult = jineService.payNotifysTwo(pay);
		return jsonResult;
	}
	
	/**
	 *   方法名：findPaymentResult   
	 *   描述：     异步查询接口                   
	 *   参数：    @param order_no 平台订单号
	 *   参数：    @return 
	 * @return: JsonResult
	 */
	@ResponseBody
	@RequestMapping("/findPaymentResult")
	public JsonResult findPaymentResult(String order_no) {
		JsonResult jsonResult = jineService.findPaymentResult(order_no);
		return jsonResult;
	}
	
	/**
	 * 
	 * ----TODO：支付接口一快速支付接口
	 * 
	 */
	
	/**
	 *   方法名：scavengingPayment   
	 *   描述：      查询快速二维码支付接口                 
	 *   参数：    @return 
	 * @return: JsonResult
	 */
	@ResponseBody
	@RequestMapping("/scavengingPayment")
	public JsonResult scavengingPayment() {
		return new JsonResult(null, addPaymentService.QueryPaymentInformation());
	}

	/**
	 *   方法名：acountBank   
	 *   描述：     查询平台的入款账号                     
	 *   参数：    @return 
	 * @return: JsonResult
	 */
	@ResponseBody
	@RequestMapping("/acountBank")
	public JsonResult acountBank() {
		return new JsonResult("", depositBankService.getAllDepositBank());
	}

	/**
	 *   方法名：quickRecharge   
	 *   描述：    用户充值申请                    
	 *   参数：    @param jine 充值信息
	 *   参数：    @param code 验证码
	 *   参数：    @param session 
	 *   参数：    @return 
	 * @return: JsonResult
	 */
	@ResponseBody
	@RequestMapping("/shoudongcz")
	public JsonResult quickRecharge(Jine jine, HttpSession session,String code) {
		JsonResult jsonResult = jineService.quickRecharge(jine,session,code);
		return jsonResult;
	}

	/**
	 * 
	 * ----TODO：用户在线提款接口
	 * 
	 */
	
	/**
	 *   方法名：findUserCodeCount   
	 *   描述：    客户提款申请 判断打码量                     
	 *   参数：    @param money 提款金额
	 *   参数：    @param session
	 *   参数：    @return 
	 * @return: JsonResult
	 */
	@ResponseBody
	@RequestMapping("/userDamal")
	public JsonResult findUserCodeCount(Double money, HttpSession session) {
		User user = (User) session.getAttribute("user");
		JsonResult jsonResult = jineService.findUserCodeCount(user,money);
		return jsonResult;
	}

	/**
	 *   方法名：quickDrawing   
	 *   描述：     在线提款申请                    
	 *   参数：    @param jine 提款信息
	 *   参数：    @param zhifupass 支付密码
	 *   参数：    @param session session对象
	 *   参数：    @return 
	 * @return: JsonResult
	 */
	@ResponseBody
	@RequestMapping("/tikuansq")
	public JsonResult quickDrawing(Jine jine, String zhifupass, HttpSession session) {
		User user = (User) session.getAttribute("user");
		JsonResult jsonResult = jineService.quickDrawing(jine, user, zhifupass);
		return jsonResult;
	}
	
	/**
	 * 
	 * ----TODO：用户充值提款记录
	 * 
	 */
	
	/**
	 *   方法名：onetikuan   
	 *   描述：     查询用户的充值记录                     
	 *   参数：    @param session
	 *   参数：    @return 
	 * @return: JsonResult
	 */
	@ResponseBody
	@RequestMapping("/onechongzhi")
	public JsonResult onechongzhi(HttpSession session) {
		User user = (User) session.getAttribute("user");
		return new JsonResult("success", jineService.onechongzhi(user.getId()));
	}

	/**
	 *   方法名：onetikuan   
	 *   描述：      查询用户提款记录                    
	 *   参数：    @param session
	 *   参数：    @return 
	 * @return: JsonResult
	 */
	@ResponseBody
	@RequestMapping("/onetikuan")
	public JsonResult onetikuan(HttpSession session) {
		User user = (User) session.getAttribute("user");
		return new JsonResult("success", jineService.onetikuan(user.getId()));
	}
	
}
