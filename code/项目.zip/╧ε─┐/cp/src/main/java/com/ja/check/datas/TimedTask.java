package com.ja.check.datas;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.ja.domain.Data;
public class TimedTask {
	/**
	 * 所有数据接口
	 */
	String url = "https://api.api68.com/lottery/getList.do?name=&lotCode=&pageNo=&pageSize=100";
	/**
	 * 采集数据的接口
	 */
	public Map<String,String> BJPK10 = new HashMap<String,String>();
	public Map<String,String> BJ28 = new HashMap<String,String>();
	public Map<String,String> AH11X5 = new HashMap<String,String>();
	public Map<String,String> AHK3 = new HashMap<String,String>();
	public Map<String,String> BJK3 = new HashMap<String,String>();
	public Map<String,String> CQKL10F = new HashMap<String,String>();
	public Map<String,String> GD11X5 = new HashMap<String,String>();
	public Map<String,String> GXK3 = new HashMap<String,String>();
	public Map<String,String> JSK3 = new HashMap<String,String>();
	public Map<String,String> JX11X5 = new HashMap<String,String>();
	public Map<String,String> SD11X5 = new HashMap<String,String>();
	public Map<String,String> SH11X5 = new HashMap<String,String>();
	public Map<String,String> SHSSL = new HashMap<String,String>();
	public Map<String,String> TJSSC =new HashMap<String,String>();
	public Map<String,String> XJSSC = new HashMap<String,String>();
	public Map<String,String> XYFT = new HashMap<String,String>();
	public Map<String,String> GDKL10F = new HashMap<String,String>();
	public Map<String,String> PL3 = new HashMap<String,String>();
	public Map<String,String> FC3D = new HashMap<String,String>();
	public Map<String,String> XGLHC = new HashMap<String,String>();
	public void initialization() {
		/**北京28*/
		BJ28.put("c6","https://www.5555c6.com/api/v1/result/service/mobile/results/hist/HF_BJ28?limit=1");
		/**北京PK10*/
		BJPK10.put("c6","https://www.5555c6.com/api/v1/result/service/mobile/results/hist/HF_BJPK10?limit=1");
		BJPK10.put("kj","https://kj.13322.com/trend/lottery.findLotteryIssue.do?lottery=pk10");
		/**安徽11选5*/
		AH11X5.put("c6","https://www.5555c6.com/api/v1/result/service/mobile/results/hist/HF_AHD11?limit=1");
		/**安徽快3*/
		AHK3.put("c6","https://www.5555c6.com/api/v1/result/service/mobile/results/hist/HF_AHK3?limit=1");
		AHK3.put("kj","https://kj.13322.com/trend/lottery.findLotteryIssue.do?lottery=ahk3");
		/**北京快3*/
		BJK3.put("c6","https://www.5555c6.com/api/v1/result/service/mobile/results/hist/HF_BJK3?limit=1");
		/**重庆快乐十分*/
		CQKL10F.put("c6","https://www.5555c6.com/api/v1/result/service/mobile/results/hist/HF_CQKL10F?limit=1");
		CQKL10F.put("kj","https://kj.13322.com/trend/lottery.findLotteryIssue.do?lottery=cqkl10");
		/**广东11选5*/
		GD11X5.put("c6","https://www.5555c6.com/api/v1/result/service/mobile/results/hist/HF_GDD11?limit=1");
		GD11X5.put("kj","https://kj.13322.com/trend/lottery.findLotteryIssue.do?lottery=d11x5");
		/**广西快3*/
		GXK3.put("c6","https://www.5555c6.com/api/v1/result/service/mobile/results/hist/HF_GXK3?limit=1");
		GXK3.put("kj","https://kj.13322.com/trend/lottery.findLotteryIssue.do?lottery=gxk3");
		/**江苏快3*/
		JSK3.put("c6","https://www.5555c6.com/api/v1/result/service/mobile/results/hist/HF_JSK3?limit=1");
		JSK3.put("kj","https://kj.13322.com/trend/lottery.findLotteryIssue.do?lottery=jsk3");
		/**江西11选5*/
		JX11X5.put("c6","https://www.5555c6.com/api/v1/result/service/mobile/results/hist/HF_JXD11?limit=1");
		/**山东11选5*/
		SD11X5.put("c6","https://www.5555c6.com/api/v1/result/service/mobile/results/hist/HF_SDD11?limit=1");
		SD11X5.put("kj","https://kj.13322.com/trend/lottery.findLotteryIssue.do?lottery=sd11x5");
		/**上海11选5*/
		SH11X5.put("c6","https://www.5555c6.com/api/v1/result/service/mobile/results/hist/HF_SHD11?limit=1");
		/**上海时时乐*/
		SHSSL.put("c6","https://www.5555c6.com/api/v1/result/service/mobile/results/hist/HF_SHSSL?limit=1");
		SHSSL.put("kj","https://kj.13322.com/trend/lottery.findLotteryIssue.do?lottery=ssl");
		/**天津时时彩*/
		TJSSC.put("c6","https://www.5555c6.com/api/v1/result/service/mobile/results/hist/HF_TJSSC?limit=1");
		TJSSC.put("kj","https://kj.13322.com/trend/lottery.findLotteryIssue.do?lottery=tjssc");
		/**新疆时时彩*/
		XJSSC.put("c6","https://www.5555c6.com/api/v1/result/service/mobile/results/hist/HF_XJSSC?limit=1");
		XJSSC.put("kj","https://kj.13322.com/trend/lottery.findLotteryIssue.do?lottery=xjssc");
		/**幸运飞艇*/
		XYFT.put("c6","https://www.5555c6.com/api/v1/result/service/mobile/results/hist/HF_XYFT?limit=1");
		/**广东快乐十分*/
		GDKL10F.put("c6","https://www.5555c6.com/api/v1/result/service/mobile/results/hist/HF_GDKL10F?limit=1");
		GDKL10F.put("kj","https://kj.13322.com/trend/lottery.findLotteryIssue.do?lottery=dkl10");
		/** 排列三20:30*/
		PL3.put("c6","https://www.5555c6.com/api/v1/result/service/mobile/results/hist/PL3?limit=1");
		/**福彩3D21:14*/
		FC3D.put("kj","https://kj.13322.com/trend/lottery.findLotteryIssue.do?lottery=f3d");
		FC3D.put("c6","https://www.5555c6.com/api/v1/result/service/mobile/results/hist/X3D?limit=1");
		/**六合彩*/
		XGLHC.put("c6", "https://c6cai1.com/api/v1/result/service/mobile/results/hist/MARK_SIX?limit=1");
		XGLHC.put("kj", "https://kj.13322.com/trend/lottery.findLotteryIssue.do?lottery=lhc");
	}
	public void thread() {
		DataUtil util = new DataUtil();
		initialization();
		new Thread(new Runnable() {
			@Override
			public void run() {
				String cname = "bj28";
				while(true) {
					//System.out.println(Thread.activeCount()+"--------------当前活跃线程总数量");
					for (String key : BJ28.keySet()) {
						if(key.equals("c6")) {
							Data dataSource = util.filterC6(cname,BJ28.get(key));
							matchingData(dataSource);
						}
					}
					try {
						Thread.sleep(6000);
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
				}
			}

		}).start();
		new Thread(new Runnable() {
			@Override
			public void run() {
				String cname = "bjpk10";
				while(true) {
					for (String key : BJPK10.keySet()) {
						if(key.equals("c6")) {
							Data dataSource = util.filterC6(cname,BJPK10.get(key));
							matchingData(dataSource);
						}else if(key.equals("kj")) {
							Data dataSource = util.filterKj(cname,BJPK10.get(key));
							matchingData(dataSource);
						}
					}
					try {
						Thread.sleep(6000);
					} catch (InterruptedException  e) {
						e.printStackTrace();
					}
				}
			}

		}).start();
		/**安徽11选5*/
		new Thread(new Runnable() {
			@Override
			public void run() {
				String cname = "ah11x5";
				while(true) {
					for (String key : AH11X5.keySet()) {
						if(key.equals("c6")) {
							Data dataSource = util.filterC6(cname,AH11X5.get(key));
							matchingData(dataSource);
						}
					}
					try {
						Thread.sleep(6000);
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
				}
			}
		}).start();
		/**安徽快3*/
		new Thread(new Runnable() {
			@Override
			public void run() {
				String cname = "ahk3";
				while(true) {
					for (String key : AHK3.keySet()) {
						if(key.equals("c6")) {
							Data dataSource = util.filterC6(cname,AHK3.get(key));
							matchingData(dataSource);
						}else if(key.equals("kj")) {
							Data dataSource = util.filterKj(cname,AHK3.get(key));
							matchingData(dataSource);
						}
					}
					try {
						Thread.sleep(6000);
					} catch (InterruptedException  e) {
						e.printStackTrace();
					}
				}
			
			}
		}).start();
		/**北京快3*/
		new Thread(new Runnable() {
			@Override
			public void run() {
				String cname = "bjk3";
				while(true) {
					for (String key : BJK3.keySet()) {
						if(key.equals("c6")) {
							Data dataSource = util.filterC6(cname,BJK3.get(key));
							matchingData(dataSource);
						}
					}
					try {
						Thread.sleep(6000);
					} catch (InterruptedException  e) {
						e.printStackTrace();
					}
				}
			
			}
		}).start();
		/**重庆快乐10分*/
		new Thread(new Runnable() {
			@Override
			public void run() {
				String cname = "cqkl10f";
				while(true) {
					for (String key : CQKL10F.keySet()) {
						if(key.equals("c6")) {
							Data dataSource = util.filterC6(cname,CQKL10F.get(key));
							matchingData(dataSource);
						}else if(key.equals("kj")) {
							Data dataSource = util.filterKj(cname,CQKL10F.get(key));
							matchingData(dataSource);
						}
					}
					try {
						Thread.sleep(6000);
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
				}
			
			}
		}).start();
		/**广东11选5*/
		new Thread(new Runnable() {
			@Override
			public void run() {
				String cname = "gd11x5";
				while(true) {
					for (String key : GD11X5.keySet()) {
						if(key.equals("c6")) {
							Data dataSource = util.filterC6(cname,GD11X5.get(key));
							matchingData(dataSource);
						}else if(key.equals("kj")) {
							Data dataSource = util.filterKj(cname,GD11X5.get(key));
							matchingData(dataSource);
						}
					}
					try {
						Thread.sleep(6000);
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
				}
			
			}
		}).start();
		/**广西快3*/
		new Thread(new Runnable() {
			@Override
			public void run() {
				String cname = "gxk3";
				while(true) {
					for (String key : GXK3.keySet()) {
						if(key.equals("c6")) {
							Data dataSource = util.filterC6(cname,GXK3.get(key));
							matchingData(dataSource);
						}else if(key.equals("kj")) {
							Data dataSource = util.filterKj(cname,GXK3.get(key));
							matchingData(dataSource);
						}
					}
					try {
						Thread.sleep(6000);
					} catch (InterruptedException  e) {
						e.printStackTrace();
					}
				}
			
			
			}
		}).start();
		/**江苏快3*/
		new Thread(new Runnable() {
			@Override
			public void run() {
				String cname = "jsk3";
				while(true) {
					for (String key : JSK3.keySet()) {
						if(key.equals("c6")) {
							Data dataSource = util.filterC6(cname,JSK3.get(key));
							matchingData(dataSource);
						}else if(key.equals("kj")) {
							Data dataSource = util.filterKj(cname,JSK3.get(key));
							matchingData(dataSource);
						}
					}
					try {
						Thread.sleep(6000);
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
				}
			}
		}).start();
		/**江西11选5*/
		new Thread(new Runnable() {
			@Override
			public void run() {
				String cname = "jx11x5";
				while(true) {
					for (String key : JX11X5.keySet()) {
						if(key.equals("c6")) {
							Data dataSource = util.filterC6(cname,JX11X5.get(key));
							matchingData(dataSource);
						}
					}
					try {
						Thread.sleep(6000);
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
				}
			}
		}).start();
		/**山东11选5*/
		new Thread(new Runnable() {
			@Override
			public void run() {
				String cname = "sd11x5";
				while(true) {
					for (String key : SD11X5.keySet()) {
						if(key.equals("c6")) {
							Data dataSource = util.filterC6(cname,SD11X5.get(key));
							matchingData(dataSource);
						}else if(key.equals("kj")) {
							Data dataSource = util.filterKj(cname,SD11X5.get(key));
							matchingData(dataSource);
						}
					}
					try {
						Thread.sleep(6000);
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
				}
			
			}
		}).start();
		/**上海11选5*/
		new Thread(new Runnable() {
			@Override
			public void run() {
				String cname = "sh11x5";
				while(true) {
					for (String key : SH11X5.keySet()) {
						if(key.equals("c6")) {
							Data dataSource = util.filterC6(cname,SH11X5.get(key));
							matchingData(dataSource);
						}
					}
					try {
						Thread.sleep(6000);
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
				}
			
			
			}
		}).start();
		/**上海时时乐*/
		new Thread(new Runnable() {
			@Override
			public void run() {
				String cname = "shssl";
				while(true) {
					try {
						for (String key : SHSSL.keySet()) {
							if(key.equals("c6")) {
								Data dataSource = util.filterC6(cname,SHSSL.get(key));
								matchingData(dataSource);
							}else if(key.equals("kj")) {
								Data dataSource = util.filterKj(cname,SHSSL.get(key));
								matchingData(dataSource);
							}
						} 
						Thread.sleep(6000);
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
				}
			
			
			}
		}).start();
		/**天津时时彩*/
		new Thread(new Runnable() {
			@Override
			public void run() {
				String cname = "tjssc";
				while(true) {
					for (String key : TJSSC.keySet()) {
						if(key.equals("c6")) {
							Data dataSource = util.filterC6(cname,TJSSC.get(key));
							matchingData(dataSource);
						}else if(key.equals("kj")) {
							Data dataSource = util.filterKj(cname,TJSSC.get(key));
							matchingData(dataSource);
						}
					}
					try {
						Thread.sleep(6000);
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
				}
			
			}
		}).start();
		/**新疆时时彩*/
		new Thread(new Runnable() {
			@Override
			public void run() {
				String cname = "xjssc";
				while(true) {
					for (String key : XJSSC.keySet()) {
						if(key.equals("c6")) {
							Data dataSource = util.filterC6(cname,XJSSC.get(key));
							matchingData(dataSource);
						}else if(key.equals("kj")) {
							Data dataSource = util.filterKj(cname,XJSSC.get(key));
							matchingData(dataSource);
						}
					}
					try {
						Thread.sleep(6000);
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
				}
			
			
			}
		}).start();
		/**幸运飞艇*/
		new Thread(new Runnable() {
			@Override
			public void run() {
				String cname = "xyft";
				while(true) {
					for (String key : XYFT.keySet()) {
						if(key.equals("c6")) {
							Data dataSource = util.filterC6(cname,XYFT.get(key));
							matchingData(dataSource);
						}
					}
					try {
						Thread.sleep(6000);
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
				}
			
			
			}
		}).start();
		/**广东快乐10分*/
		new Thread(new Runnable() {
			@Override
			public void run() {
				String cname = "gdkl10f";
				while(true) {
					for (String key : GDKL10F.keySet()) {
						if(key.equals("c6")) {
							Data dataSource = util.filterC6(cname,GDKL10F.get(key));
							matchingData(dataSource);
						}else if(key.equals("kj")) {
							Data dataSource = util.filterKj(cname,GDKL10F.get(key));
							matchingData(dataSource);
						}	
					}
					try {
						Thread.sleep(6000);
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
				}
			
			}
		}).start();
		/**排列3*/
		new Thread(new Runnable() {
			@Override
			public void run() {
				String cname = "pl3";
				while(true) {
					for (String key : PL3.keySet()) {
						if(key.equals("c6")) {
							Data dataSource = util.filterC6(cname,PL3.get(key));
							matchingData(dataSource);
						}
					}
					try {
						Thread.sleep(10000);
					} catch (InterruptedException  e) {
						e.printStackTrace();
					}
				}
			}
		}).start();
			
		/**福彩3D*/
		new Thread(new Runnable() {
			@Override
			public void run() {
				String cname = "fc3d";
				while(true) {
					try {
						for (String key : FC3D.keySet()) {
							if(key.equals("c6")) {
								Data dataSource = util.filterC6(cname,FC3D.get(key));
								matchingData(dataSource);
							}else if(key.equals("kj")) {
								Data dataSource = util.filterKj(cname,FC3D.get(key));
								matchingData(dataSource);
							}
						}
						Thread.sleep(10000);
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
				}
			
			
			}
		}).start();
		/**香港六合彩*/
		new Thread(new Runnable() {
			@Override
			public void run() {
				String cname = "xg6hc";
				while(true) {
					try {
						for (String key : XGLHC.keySet()) {
							if(key.equals("c6")) {
								Data dataSource = util.filterC6(cname,XGLHC.get(key));
								matchingData(dataSource);
							}else if(key.equals("kj")) {
								Data dataSource = util.filterKj(cname,XGLHC.get(key));
								matchingData(dataSource);
							}
						}
						Thread.sleep(90000);
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
				}
			
			
			}
		}).start();
		/**所有数据接口*/
		new Thread(new Runnable() {
			@Override
			public void run() {
				while(true) {
						List<Data> dataSource = util.https1680380(url);
						for (Data d : dataSource) {
							matchingData(d);
						}
					try {
						Thread.sleep(6000);
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
				}
			
			}
		}).start();
	}
	
	/**
	 * 对数据进行匹配 匹配到数据则更新到数据库
	 * @param dataSource 爬取到的数据
	 * @param cName 彩种名
	 */
	public synchronized void  matchingData(Data data) {
		if(data != null) {
			Publicmethods p = new Publicmethods();
			Data d = p.pueryCurrentPeriod(data.getCname(),data.getPeriod());
			if(d != null) {
				if(d.getLotternumber() == null || "".equals(d.getLotternumber())) {
					data.setNextperiod(d.getNextperiod());//下期期号
					p.processingData(data);//执行更新
				}
			}else {
				System.out.println(data.getPeriod()+"------数据库里面没有再一期数据------"+data.getCname());
			}
		}
	}
}
