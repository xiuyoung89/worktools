package com.ja.domain;

import java.io.Serializable;

public class QqKeFu implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 2791022300037420790L;
	private Integer id;
	//用户名
	private String name;
	//密码
	private String number;
	//IP
	private String note;
	//角色
	private String createTime;
	//状态-急用-或启用
	private Integer state;
    
    public static long getSerialversionuid() {
		return serialVersionUID;
	}
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Integer getState() {
		return state;
	}
	public void setState(Integer state) {
		this.state = state;
	}
	public String getNumber() {
		return number;
	}
	public void setNumber(String number) {
		this.number = number;
	}
	public String getNote() {
		return note;
	}
	public void setNote(String note) {
		this.note = note;
	}
	public String getCreateTime() {
		return createTime;
	}
	public void setCreateTime(String createTime) {
		this.createTime = createTime;
	}
	@Override
	public String toString() {
		return "QqKeFu [id=" + id + ", name=" + name + ", number=" + number + ", note=" + note + ", createTime="
				+ createTime + ", state=" + state + "]";
	}
	public QqKeFu() {
		super();
	}

	
}
