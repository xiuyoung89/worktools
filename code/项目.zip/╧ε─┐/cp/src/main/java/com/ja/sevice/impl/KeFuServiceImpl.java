package com.ja.sevice.impl;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.DigestUtils;

import com.ja.dao.AMapper;
import com.ja.dao.KeFuAutomaticMapper;
import com.ja.dao.KeFuMapper;
import com.ja.dao.KeFuQuickMapper;
import com.ja.dao.UserMapper;
import com.ja.domain.AdminUser;
import com.ja.domain.KeFuAutomatic;
import com.ja.domain.KeFuChat;
import com.ja.domain.KeFuQuick;
import com.ja.domain.User;
import com.ja.sevice.KeFuService;
import com.ja.util.DateUtil;

@Service("keFuService")
public class KeFuServiceImpl implements KeFuService {

	@Autowired
	private KeFuMapper keFuMapper;
	
	@Autowired
	private KeFuAutomaticMapper keFuAutomaticMapper;
	
	@Autowired
	private KeFuQuickMapper keFuQuickMapper;
	
	@Autowired
	private AMapper admin1Mapper;
	
	@Autowired
	private UserMapper userMapper;
	
	@Override
	public List<KeFuAutomatic> findAllKeFuAutomatic() {
		return keFuAutomaticMapper.findAllKeFuAutomatic();
	}

	@Override
	public List<KeFuAutomatic> findTypeKeFuAutomatic(Integer type) {
		return keFuAutomaticMapper.findTypeKeFuAutomatic(type);
	}

	@Override
	public int addKeFuAutomatic(KeFuAutomatic kefuAutomatic) {
		kefuAutomatic.setCreateTime(DateUtil.getCurrTime());
		return keFuAutomaticMapper.addKeFuAutomatic(kefuAutomatic);
	}

	@Override
	public int updateKeFuAutomatic(KeFuAutomatic kefuAutomatic) {
		kefuAutomatic.setCreateTime(DateUtil.getCurrTime());
		return keFuAutomaticMapper.updateKeFuAutomatic(kefuAutomatic);
	}

	@Override
	public int deleteKeFuAutomatic(Integer id) {
		return keFuAutomaticMapper.deleteKeFuAutomatic(id);
	}

	@Override
	public List<KeFuQuick> findAllKeFuQuick() {
		return keFuQuickMapper.findAllKeFuQuick();
	}

	@Override
	public List<KeFuQuick> findTypeKeFuQuick(Integer type) {
		return keFuQuickMapper.findTypeKeFuQuick(type);
	}
	
	@Override
	public List<KeFuQuick> findLikeContentType(Integer type, String keyWord) {
		return keFuQuickMapper.findLikeContentType(type, keyWord);
	}

	@Override
	public int addKeFuQuick(KeFuQuick keFuQuick) {
		keFuQuick.setCreateTime(DateUtil.getCurrTime());
		return keFuQuickMapper.addKeFuQuick(keFuQuick);
	}

	@Override
	public int updateKeFuQuick(KeFuQuick keFuQuick) {
		keFuQuick.setCreateTime(DateUtil.getCurrTime());
		return keFuQuickMapper.updateKeFuQuick(keFuQuick);
	}

	@Override
	public int deleteKeFuQuick(Integer id) {
		return keFuQuickMapper.deleteKeFuQuick(id);
	}

	@Override
	public AdminUser findByIdAmdinUser(Integer id) {
		return admin1Mapper.findByIdAmdinUser(id);
	}

	@Override
	public int saveChatRecord(KeFuChat chat) {
		User user = userMapper.getUserByid(chat.getUser_id());
		chat.setUser_name(user.getNicheng());
		chat.setUser_avatar(user.getAvatar());
		AdminUser admin = admin1Mapper.findByIdAmdinUser(chat.getKefu_id());
		chat.setKefu_name(admin.getNick_name());
		chat.setKefu_avatar(admin.getAvatar());  
		String time =  DateUtil.getCurrTime();
		chat.setCreated_time(time.substring(5, time.length()-1));
		return keFuMapper.saveChatRecord(chat);
	}

	@Override
	public List<KeFuChat> findChatRecord(KeFuChat chat) {
		return keFuMapper.findChatRecord(chat);
	}

	@Override
	public List<AdminUser> findAllKeFuUser() {
		return admin1Mapper.findAllKeFuUser();
	}
	
	@Override
	public List<AdminUser> findByTypeKeFuUser(Integer type) {
		return admin1Mapper.findByTypeKeFuUser(type);
	}

	@Override
	public int updateKeFuUser(AdminUser admin) {
		if(admin.getPass() != null && !"".equals(admin.getPass())) {
			admin.setPass(DigestUtils.md5DigestAsHex(DigestUtils.md5DigestAsHex(admin.getPass().getBytes()).getBytes()));
		}
		admin.setCreated_time(DateUtil.getCurrTime());
		return admin1Mapper.updateAdminUser(admin);
	}

	@Override
	public int deleteKeFuUser(Integer id) {
		admin1Mapper.delPower(id);
		return admin1Mapper.deleteKeFuUser(id);
	}

	@Override
	public int saveKeFuUser(AdminUser admin) {
		admin.setCreated_time(DateUtil.getCurrTime());
		admin1Mapper.registerAdminUser(admin);
		admin1Mapper.insertPower(admin);
		return admin.getId();
	}

	@Override
	public List<KeFuChat> findChatLinkman(Integer id,Integer type) {
		KeFuChat keFuChat = new KeFuChat();
		SimpleDateFormat ss = new SimpleDateFormat("MM-dd");
		keFuChat.setCreated_time(ss.format(new Date()));
		keFuChat.setId(type);
		keFuChat.setKefu_id(id);
		return keFuMapper.findChatLinkman(keFuChat);
	}

	@Override
	public int updateChatStatu(KeFuChat chat) {
		return keFuMapper.updateChatStatu(chat);
	}

}