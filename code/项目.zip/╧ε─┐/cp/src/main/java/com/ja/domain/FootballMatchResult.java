package com.ja.domain;

import java.io.Serializable;

public class FootballMatchResult implements Serializable{
	
    /**
	 * 
	 */
	private static final long serialVersionUID = 4330305179720371313L;

	private Integer id; //足彩赛事开奖表

    private String league = FootBallMatch.DEFAULT_INIT_VALUE ; //足彩赛事目录名称

    private String team_h = FootBallMatch.DEFAULT_INIT_VALUE ; //主队名称

    private String team_c = FootBallMatch.DEFAULT_INIT_VALUE ; //客队名称

    private String start_time = FootBallMatch.DEFAULT_INIT_VALUE ; //比赛开始时间

    private String score_h = FootBallMatch.DEFAULT_INIT_VALUE ; //全场比分 主队

    private String score_c = FootBallMatch.DEFAULT_INIT_VALUE ; //全场比分 客队

    private String fh_score_h = FootBallMatch.DEFAULT_INIT_VALUE ; //半场比分 主队

    private String fh_score_c = FootBallMatch.DEFAULT_INIT_VALUE ; //半场比分 客队

    private String ctime = FootBallMatch.DEFAULT_INIT_VALUE ; //现在时间

    private String type = FootBallMatch.DEFAULT_INIT_VALUE ; //
    
    private String other = FootBallMatch.DEFAULT_INIT_VALUE ; // 
    
    private String remark = FootBallMatch.DEFAULT_INIT_VALUE ; //

    public static long getSerialversionuid() {
		return serialVersionUID;
	}
    
    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getLeague() {
        return league;
    }

    public void setLeague(String league) {
        this.league = league == null ? null : league.trim();
    }

	public String getTeam_h() {
		return team_h;
	}

	public void setTeam_h(String team_h) {
		this.team_h = team_h;
	}

	public String getTeam_c() {
		return team_c;
	}

	public void setTeam_c(String team_c) {
		this.team_c = team_c;
	}

	public String getStart_time() {
		return start_time;
	}

	public void setStart_time(String start_time) {
		this.start_time = start_time;
	}

	public String getScore_h() {
		return score_h;
	}

	public void setScore_h(String score_h) {
		this.score_h = score_h;
	}

	public String getScore_c() {
		return score_c;
	}

	public void setScore_c(String score_c) {
		this.score_c = score_c;
	}

	public String getFh_score_h() {
		return fh_score_h;
	}

	public void setFh_score_h(String fh_score_h) {
		this.fh_score_h = fh_score_h;
	}

	public String getFh_score_c() {
		return fh_score_c;
	}

	public void setFh_score_c(String fh_score_c) {
		this.fh_score_c = fh_score_c;
	}

	public String getCtime() {
		return ctime;
	}

	public void setCtime(String ctime) {
		this.ctime = ctime;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getOther() {
		return other;
	}

	public void setOther(String other) {
		this.other = other;
	}

	public String getRemark() {
		return remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}

	public FootballMatchResult() {
		super();
	}

	@Override
	public String toString() {
		return "FootBallData [id=" + id + ", league=" + league + ", team_h=" + team_h + ", team_c=" + team_c
				+ ", startTime=" + start_time + ", score_h=" + score_h + ", score_c=" + score_c + ", fh_score_h="
				+ fh_score_h + ", fh_score_c=" + fh_score_c + ", ctime=" + ctime + ", type=" + type + ", other=" + other
				+ ", remark=" + remark + "]";
	}
}