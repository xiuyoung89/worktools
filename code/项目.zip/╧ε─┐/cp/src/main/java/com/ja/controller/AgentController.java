package com.ja.controller;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.ja.domain.PagingData;
import com.ja.domain.User;
import com.ja.sevice.AgentService;
import com.ja.sevice.IUserService;
import com.ja.sevice.LiushuiService;
import com.ja.util.JsonResult;

@RequestMapping("agent")
@Controller
public class AgentController {
	
	@Autowired
	private AgentService agentService;
	  
	@Autowired
	private LiushuiService liushuiService;
	
	@Autowired
	private IUserService userService;
	
	/**
	 * 
	 * 
	 * 
	 * --------------------------TODO: 代理第1套
	 * 
	 * 
	 * 
	 */
	
	/**
	 * 
	 * ----TODO: 代理说明管理
	 * 
	 */
	
	/**
	  * 方法名：agentExplanPage 
	  * 描述：    代理说明页面                  
	  * 参数：    @param model
	  * 参数：    @return 
	 * @return: ModelAndView
	 */
	@RequestMapping("/agentExplanPage")
	public ModelAndView agentExplanPage(ModelAndView model){
		model.setViewName("agent/dailiExplain");
		return model;
	}
	
	/**
	 * 
	 * ----TODO: 用户管理
	 * 
	 */
	
	/**
	  * 方法名：agentUserPage 
	  * 描述：     用户管理页面                 
	  * 参数：    @param model
	  * 参数：    @return 
	 * @return: ModelAndView
	 */
	@RequestMapping("/agentUserPage")
	public ModelAndView agentUserPage(ModelAndView model){
		model.setViewName("agent/userManage");
		return model;
	}
	
	/**
	  * 方法名：findOneAgent 
	  * 描述：     查询所有的一级代理                 
	  * 参数：    @param paging
	  * 参数：    @param session
	  * 参数：    @return 
	 * @return: String
	 */
	@ResponseBody
	@RequestMapping("/findOneAgent")
	public String findOneAgent(PagingData paging,HttpSession session) {
		paging.setAllCount(agentService.findOneAgent(paging.getStartIndex(),paging.getLineCount(),((User)session.getAttribute("user")).getId(),0).size());
		paging.setList(agentService.findOneAgent(paging.getStartIndex(),paging.getLineCount(),((User)session.getAttribute("user")).getId(),1));
		return PagingData.pagingData(paging);
	}
	
	/**
	  * 方法名：findAllAgent 
	  * 描述：    查询一级代理下面的所有的代理                  
	  * 参数：    @param user_id 
	  * 参数：    @param session
	  * 参数：    @return 
	 * @return: JsonResult
	 */
	@ResponseBody
	@RequestMapping("/findAllAgent")
	public JsonResult findAllAgent(Integer user_id,HttpSession session) {
		return new JsonResult("",agentService.findAllAgent(user_id,((User)session.getAttribute("user")).getId()));
	}
	
	/**
	  * 方法名：findAgentInfo 
	  * 描述：    根据用户名和等级查询代理下级的详情                  
	  * 参数：    @param session
	  * 参数：    @param name
	  * 参数：    @param grade
	  * 参数：    @return 
	 * @return: JsonResult
	 */
	@ResponseBody
	@RequestMapping("/findAgentInfo")
	public JsonResult findAgentInfo(HttpSession session,String name,Integer grade) {
		return new JsonResult("",agentService.findAgentInfo(name,((User)session.getAttribute("user")).getId(),grade));
	}
	
	/**
	 * 
	 * ----TODO: 代理佣金管理
	 * 
	 */
	
	/**
	  * 方法名：agentCommisionPage 
	  * 描述：    代理佣金页面                  
	  * 参数：    @param model
	  * 参数：    @return 
	 * @return: ModelAndView
	 */
	@RequestMapping("/agentCommisionPage")
	public ModelAndView agentCommisionPage(ModelAndView model){
		model.setViewName("agent/dailiCommission");
		return model;
	}
	
	/**
	  * 方法名：findAgentRebateSum 
	  * 描述：   查询当前代理的返点总额                   
	  * 参数：    @param startDate
	  * 参数：    @param endDate
	  * 参数：    @param session
	  * 参数：    @return 
	 * @return: JsonResult
	 */
	@ResponseBody
	@RequestMapping("/findAgentRebateSum")
	public JsonResult findAgentRebateSum(String startDate,String endDate,HttpSession session) {
		return new JsonResult("",agentService.findAgentRebateSum(startDate,endDate,((User)session.getAttribute("user")).getId()));
	}
	
	/**
	  * 方法名：findAgentRebateInfo 
	  * 描述：     查询代理下级的返点记录                 
	  * 参数：    @param paging
	  * 参数：    @param startDate
	  * 参数：    @param endDate
	  * 参数：    @param session
	  * 参数：    @return 
	 * @return: String
	 */
	@ResponseBody
	@RequestMapping("/findAgentRebateInfo")
	public String findAgentRebateInfo(PagingData paging,String startDate,String endDate,HttpSession session) {
		paging.setReplace1(startDate);
		paging.setReplace2(endDate);
		paging.setReplace4(((User)session.getAttribute("user")).getId());
		paging.setAllCount(agentService.findAgentRebateInfoCounts(paging));
		paging.setList(agentService.findAgentRebateInfo(paging.getStartIndex(),paging.getLineCount(),startDate,endDate,((User)session.getAttribute("user")).getId(),1));
		return PagingData.pagingData(paging);
	}
	
	/**
	  * 方法名：receiveRebateMoney 
	  * 描述：     代理领取返点金额                  
	  * 参数：    @param session
	  * 参数：    @return 
	 * @return: JsonResult
	 */
	@ResponseBody
	@RequestMapping("/receiveRebateMoney")  
	public JsonResult receiveRebateMoney(HttpSession session) {
		return new JsonResult(String.valueOf(agentService.receiveAReturnPoint()),liushuiService.receiveRebateMoney(((User)session.getAttribute("user")).getId()));
	}
	
	/**
	 * 
	 * ----TODO: 报表统计管理
	 * 
	 */

	/**
	  * 方法名：agentReportFromPage 
	  * 描述：    报表统计页面                  
	  * 参数：    @param model
	  * 参数：    @return 
	 * @return: ModelAndView
	 */
	@RequestMapping("/agentReportFromPage")
	public ModelAndView agentReportFromPage(ModelAndView model){
		model.setViewName("agent/reportStatistic");
		return model;
	}
	
	/**
	  * 方法名：findAllTeamRcord 
	  * 描述：    查询团队报表记录                  
	  * 参数：    @param startDate
	  * 参数：    @param endDate
	  * 参数：    @param session
	  * 参数：    @return 
	 * @return: JsonResult
	 */
	@ResponseBody
	@RequestMapping("/findAllTeamRcord")
	public JsonResult findAllTeamRcord(String startDate,String endDate,HttpSession session) {
		return new JsonResult("",agentService.findAllTeamRcord(startDate,endDate,((User)session.getAttribute("user")).getId()));
	}
	
	/**
	 * 
	 * 
	 * 
	 * --------------------------TODO: 代理第2套
	 * 
	 * 
	 * 
	 */
	
	/**
	 * 
	 * ----TODO:团队佣金管理
	 * 
	 */
	
	/**
	  *  方法名：findAgentTeamRebate 
	  * 描述：    查询代理团队的佣金明细                  
	  * 参数：    @param user_id 代理id
	  * 参数：    @param startTime 开始时间
	  * 参数：    @param endTime 结束时间
	  * 参数：    @return 
	 * @return: String
	 */
	@ResponseBody
	@RequestMapping("/findAgentTeamRebate")  
	public String findAgentTeamRebate(PagingData paging,HttpSession session,String startTime,String endTime,Integer type) {
		User user = (User) session.getAttribute("user");
		String jsonResult = agentService.findAgentTeamRebate(paging,user,startTime,endTime,type);
		return jsonResult;
	}
	
	/**
	  * 方法名：findAgentTeamReport 
	  * 描述：    查询代理的团队报表                  
	  * 参数：    @param session
	  * 参数：    @param userName 下级名称
	  * 参数：    @param time 查询时间
	  * 参数：    @return 
	 * @return: JsonResult
	 */
	@ResponseBody
	@RequestMapping("/findAgentTeamReport")  
	public JsonResult findAgentTeamReport(String userName,String time) {
		User user = userService.checkUser(userName);
		if(user==null) {
			return new JsonResult("-1", "没有这个下级用户!");
		}
		JsonResult jsonResult = agentService.findAgentTeamReport(user,time);
		return jsonResult;
	}
	
	/**
	 * 方法名：findAgentSubordinateReport 
	 * 描述：     查询下级的报表记录                 
	 * 参数：    @param session
	 * 参数：    @param userName 下级用户名
	 * 参数：    @param time 查询时间
	 * 参数：    @return 
	 * @return: JsonResult
	 */
	@ResponseBody
	@RequestMapping("/findAgentSubordinateReport")  
	public JsonResult findAgentSubordinateReport(HttpSession session,String agentName,String userName,String time) {
		User user = (User) session.getAttribute("user");
		if("".equals(agentName)) {
			user = (User) session.getAttribute("user");
		}else {
			user = userService.checkUser(agentName);
		}
		JsonResult jsonResult = agentService.findAgentSubordinateReport(user,userName,time);
		return jsonResult;
	}
	
	
	

	
	
	
	
}
