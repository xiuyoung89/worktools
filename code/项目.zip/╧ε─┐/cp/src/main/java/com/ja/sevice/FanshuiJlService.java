package com.ja.sevice;

import java.util.List;

import com.ja.domain.FanshuiJl;
import com.ja.domain.User;

public interface FanshuiJlService {
	

	/**根据时间和id去查询日反水记录*/
	FanshuiJl getOneFanshui(Integer id, String time4);
	
	/**根据时间和id去查询月反水记录*/
	FanshuiJl getTowFanshui(Integer id, String time4);
	
	/**
	 * 添加反水记录
	 * @param type 反水类型
	 * @return
	 */
	int rebateRecord(int type);
	
	/**
	 * 
	   *   方法名：findUserWaterCount   
	   *   描述：     用户返水统计                  TODO   
	   *   参数：    @param id
	   *   参数：    @return 
	 * @return: List<String>
	 */
	List<String> findUserWaterCount(User user);
	

}
