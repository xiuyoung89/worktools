package com.ja.config;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.web.context.ContextLoader;

import com.ja.domain.Admin;
import com.ja.domain.Lotter;
import com.ja.sevice.FanshuiJlService;
import com.ja.sevice.ILotteryService;
import com.ja.sevice.ISystemConfigService;
import com.ja.sevice.YunyingbbService;

/**
 * 项目名称：cp   
 * 类名称：WebsiteStateConfig.java   
 * 类描述：   网站各种状态配置设置类
 * 创建人：   GL
 * 创建时间：2019年2月12日 下午12:03:30   
 * @version v1.0.0
 */
public class WebsiteStateConfig {
	
	private static ISystemConfigService systemConfigService = (ISystemConfigService) ContextLoader.getCurrentWebApplicationContext()
			.getBean("systemConfigService");
	
	private static ILotteryService lotteryService = (ILotteryService) ContextLoader.getCurrentWebApplicationContext()
			.getBean("lotteryService");
	
	private static YunyingbbService yunyingbbService = (YunyingbbService) ContextLoader.getCurrentWebApplicationContext()
			.getBean("yunyingbbService");
	
	
	private static FanshuiJlService fanshuiJlService = (FanshuiJlService) ContextLoader.getCurrentWebApplicationContext()
			.getBean("fanshuiJlService");
	
	public static Map<String,String> configs; //网站状态以及说明配置
	
	public static List<Lotter> lotteryState; //彩种状态配置
	
	/**
	 * 方法名：lotteryStateConfig 
	 * 描述：    彩种的开启状态配置                   TODO
	 * 参数：    @param cname 彩种名称
	 * 参数：    @param flag 彩种状态
	 * 参数：    @return 
	 * @return: boolean
	 */
	public static void lotteryStateConfig(String cname,Integer flag) {
		List<Lotter> states = lotteryService.findAllLotteryState();//查询所有彩种的状态
		lotteryState = new ArrayList<>();
		if("".equals(cname)) {
			lotteryState = null;
			lotteryState = new ArrayList<>();
		}
		for(Lotter state : states) {
			if(cname.equals(state.getCname())) {  
				state.setState(flag);
			}
			lotteryState.add(state);
		}
	}
	
	/**
	 * 方法名：totalTodayRecord 
	 * 描述： 统计用户以及平台前一天的所有总计                      TODO
	 * @return: void
	 */
	public static void totalTodayRecord() {
		fanshuiJlService.rebateRecord(1);
		yunyingbbService.censusTodayRecord();
	}
	
	/**
	 * 方法名：webisteAllConfig 
	 * 描述：     网站所有的配置信息                  TODO
	 * 参数：    @param admin 
	 * @return: void
	 */
	public static void webisteAllConfig(Admin admin) {
		Admin config = systemConfigService.findAllConfig();
		Field[] fields = config.getClass().getDeclaredFields();
		configs = new HashMap<>();
		if(admin==null) {
			configs = null;
			configs = new HashMap<>();
		}
		for(int i=0;i<fields.length;i++) {
			try {
				configs.put(fields[i].getName(), fields[i].get(config)+"");
			} catch (Exception e) {
				System.out.println("出现的异常： "+e.getMessage());
			} 
		}
	}
	/**
	 * 获取彩种信息
	 * @param cname 彩种名 需要获取的彩种名
	 * @return  返回当前彩种的所有数据 如果没有这个彩种在返回null
	 */
	public static Lotter getLotter(String cname) {
		if(cname == null || "".equals(cname)) {
			return null;
		}
		for (Lotter l :lotteryState) {
			if(cname.equals(l.getCname())) {
				return l;
			}
		}
		return null;
	}
}
