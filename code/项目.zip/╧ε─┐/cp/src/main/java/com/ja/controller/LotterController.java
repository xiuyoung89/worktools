package com.ja.controller;

import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.ja.check.action.CheckOrder;
import com.ja.domain.Kongzhi;
import com.ja.domain.LotterExample;
import com.ja.domain.UpDataPage;
import com.ja.domain.User;
import com.ja.sevice.AgencyCenterSevice;
import com.ja.sevice.ILotteryService;
import com.ja.sevice.InfoNoticeService;
import com.ja.sevice.KongzhiService;
import com.ja.util.JsonResult;

@Controller
@RequestMapping("/lotter")
/**
 * @author GL 页面彩种信息
 * @DATE 2018年1月10日 15:15:26
 */
public class LotterController { 
	@Autowired
	private ILotteryService lotterService;
	
	@Autowired
	private InfoNoticeService infoNotiService;
	
	@Autowired
	private KongzhiService kongzhiService;
	
	@Autowired
	private AgencyCenterSevice agencyCenterSevice;
	
	public static List<UpDataPage> list = null;
	public static String lotJs = "";//下注页面的js代码
	/** 获取所有lotter,data */
	@RequestMapping("/getlotters")
	@ResponseBody
	public JsonResult getAllLotters() {
		List<LotterExample> lotterList = lotterService.getAllLotters();
		for (LotterExample lotterExample : lotterList) {
			lotterExample.setLotternumber(lotterExample.getLotternumber().replace(",", " "));
		}
		return new JsonResult(null, lotterList);
	}
	
	/** 获取球 */
	@RequestMapping("/getQiu")
	@ResponseBody
	public JsonResult getLotterTimes(String cname) {
	    List<Kongzhi> kong = kongzhiService.getOneKongzhi(cname);
		return new JsonResult("qiu", kong);
	}
	
	/**香港六合彩 */
	@RequestMapping("xglhc")
	@ResponseBody
	public JsonResult xglhc(String cname,String xg6hc) {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		LotterExample lotter = new LotterExample();
		int xg6hcstate = 0;
		if(xg6hc == null || "".equals(xg6hc)){
			xg6hcstate = lotterService.xg6hczd(cname)-1; 
		}else{
			xg6hcstate  = Integer.parseInt(xg6hc.trim());
		}
	    lotter = lotterService.xglhc(cname,xg6hcstate);
		return new JsonResult(sdf.format(new Date()),lotter);
	}
	
	/** 查询当前彩种的上期开奖时间 */
	@RequestMapping("getnewdata")
	@ResponseBody
	public JsonResult getnewdata(String key) {
		SimpleDateFormat ss = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		String time = ss.format(new Date());
		LotterExample ls = lotterService.getLotterByCname(key);
		return new JsonResult(time, ls);
	}
	
	/** 查询走势图 */
	@RequestMapping("zoushitu")
	@ResponseBody
	public JsonResult zoushitu(String cname) {
		return new JsonResult("zoushitu", lotterService.getCzxinxi(cname));
	}
	
	/** 查询六合彩属性 */
	@RequestMapping("xgattr")
	@ResponseBody
	public JsonResult xgattr(String lotterNum, String qihao) {
		String[] data = lotterNum.split(",");
		CheckOrder orc = new CheckOrder();
		Map<String, Object> map = orc.attribute1();
		String[] sx1 = (String[]) map.get("attr");
		String[][] sx2 = (String[][]) map.get("content");
		List<String> ids = new ArrayList<String>();
		String rs1 = "";
		for (int k = 0; k < data.length; k++) {
			for (int i = 0; i < sx1.length; i++) {
				for (int j = 0; j < sx2[i].length; j++) {
					if (sx2[i][j].equals(data[k])) {
						ids.add(sx1[i]);
					}
				}
			}
		}
		for (int i = 0; i < ids.size(); i++) {
			rs1 += ids.get(i) + ",";
		}
		return new JsonResult(qihao, rs1);
	}
	
	@RequestMapping("/footballMatch")
	public String footballMatch() {
		return "include/zc";
	}

	/** 页面彩种下注信息 */
	@RequestMapping("/lot")
	@ResponseBody
	public JsonResult lot(HttpSession session,String cname) {
		if("jnd28".equals(cname)) {
			return new JsonResult(null,"  ");
		}
		if(list == null) {
			list = infoNotiService.updatePagesc(1);
		}
		for(UpDataPage p : list) {
			if(p.getPage().equals(cname)) {
				return new JsonResult("",lotPage(p.getPage()));
			}
		}
		return new JsonResult(null,"nullnull");
	}
	/** 页面彩种下注信息 */
	@RequestMapping("/lots")
	@ResponseBody
	public JsonResult lots(HttpSession session,String cname) {
		if("jnd28".equals(cname)) {
			return new JsonResult(null,"  ");
		}
		return new JsonResult("",lotPages(session,cname));
	}
	public String odds(String str,Double odds) {
		DecimalFormat df = new DecimalFormat("#0.000");
		Double oddss = Double.parseDouble(str);
		Double o =  oddss*odds;//算出平台和代理 之间的差 
		return  df.format(oddss-o);//减掉之间的差距带到最终的结果
	}
	/**
	 *生成下注页面
	 * @param session 获取用户对象
	 * @param cname 彩种名
	 * @return 传入彩种名称 返回这个彩种的下注页面
	 */
	public String lotPages(HttpSession session,String cname) {
		User user = (User)session.getAttribute("user");
		Double odds = 0.00;
		if(user.getOdds() != null) {
			odds += user.getOdds();
		}
		if(user.getOdds() != null && user.getOdds() > 0) {
			List<User> list = agencyCenterSevice.treeDataobject(user.getFid());
			for (User u : list) {
				if(u.getOdds() != null) {
					odds+=u.getOdds();
				}
			}
		}
		LotterExample lotters = lotterService.getLotterByCname(cname);
		String[] str1 = lotters.getRebate1().toString().split(",");
		String[] str2 = lotters.getRebate2().toString().split(",");
		String[] str3 = lotters.getRebate3().toString().split(",");
		String[] str4 = lotters.getRebate4().toString().split(",");
		String[] str5 = lotters.getRebate5().toString().split(",");
		String[] str6 = lotters.getRebate6().toString().split(",");
		String[] str7 = lotters.getRebate7().toString().split(",");
		String[] str8 = lotters.getRebate8().toString().split(",");
		String[] str9 = lotters.getRebate9().toString().split(",");
		String[] str10 = lotters.getRebate10().toString().split(",");
		String[] str11 = lotters.getRebate11().toString().split(",");
		String[] str12 = lotters.getRebate12().toString().split(",");
		String[] str13 = lotters.getRebate13().toString().split(",");
		String[] str14 = lotters.getRebate14().toString().split(",");
		String[] str15 = lotters.getRebate15().toString().split(",");
		String[] str16 = lotters.getRebate16().toString().split(",");
		String[] str17 = lotters.getRebate17().toString().split(",");
		String[] str18 = lotters.getRebate18().toString().split(",");
		String[] str19 = lotters.getRebate19().toString().split(",");
		String[] str20 = lotters.getRebate20().toString().split(",");
		String[] str21 = lotters.getRebate21().toString().split(",");
		String[] str22 = lotters.getRebate22().toString().split(",");
		String[] str23 = lotters.getRebate23().toString().split(",");
		String[] str24 = lotters.getRebate24().toString().split(",");
		String[] str25 = lotters.getRebate25().toString().split(",");
		String[] str26 = lotters.getRebate26().toString().split(",");
		String[] str27 = lotters.getRebate27().toString().split(",");
		String[] str28 = lotters.getRebate28().toString().split(",");
		String[] str29 = lotters.getRebate29().toString().split(",");
		String[] str30 = lotters.getRebate30().toString().split(",");
		String[] str31 = lotters.getRebate31().toString().split(",");
		String[] str32 = lotters.getRebate32().toString().split(",");
		String[] str33 = lotters.getRebate33().toString().split(",");
		String[] str34 = lotters.getRebate34().toString().split(",");
		String[] str35 = lotters.getRebate35().toString().split(",");
		String[] str36 = lotters.getRebate36().toString().split(",");
		String[] str37 = lotters.getRebate37().toString().split(",");
		String[] str38 = lotters.getRebate38().toString().split(",");
		String[] str39 = lotters.getRebate39().toString().split(",");
		String[] str40 = lotters.getRebate40().toString().split(",");
		//String str = "";
		String xiazhuqu = "";
		switch (cname) {
		case "ahk3":
		case "gxk3":
		case "jsk3":
		case "bjk3":
		case "jlk3":
		case "2fk3":
		case "3fk3":
			// TODO 快3
			String wfk3[] = { "猜一个号", "三连号通选", "二同号复选", "二同号单选", "二不同号", "二不同号胆拖", "三同号通选", "三同号单选", "三不同号", "形态",
					"总和" };
			String wfclassk3[] = { "c1gh", "slhtx", "ethfx", "ethdx", "ebth", "ebthdt", "sthtx", "sthdx", "sbth", "xt",
					"zh6" };
			//str = "<div><div class='wf'>";
			//for (int i = 0; i < wfk3.length; i++) {
			//	str += "<a href='#" + wfclassk3[i] + "'>" + wfk3[i] + "</a>";
			//}	
			String tk3 = "";
			for (int i = 1; i < 7; i++) {
				String x = i + "";
				tk3 += "	<div class='fl myfl' style='width:33.3%;'>" + "		<button class='btn3 qiu8'>" + x
						+ "</button>" + "	</div>";
			}
			String tk31 = "";
			for (int i = 1; i < 7; i++) {
				String x = i + "";
				tk31 += "	<div class='fl myfl' style='width:33.3%;'>" + "		<button class='btn3 qiu8'>" + x
						+ "</button><span>"+odds(str4[0],odds)+"</span>" + "	</div>";
			}

			String tk33 = "";
			for (int i = 1; i < 7; i++) {
				String x = i + "";
				tk33 += "	<div class='fl myfl' style='width:33.3%;'>" + "		<button class='btn3 qiu3'>" + x
						+ "</button>" + "	</div>";
			}
			String tk35 = "";
			for (int i = 3; i < 19; i++) {
				String x = i + "";
				tk35 += "	<div class='fl myfl' style='width:33.3%;'>" + "		<button class='btn3 qiu8'>" + x
						+ "</button>" + "		<span>" +odds(str11[(i - 3)], odds) + "</span>" + "	</div>";
			}

			String eth[] = { "11", "22", "33", "44", "55", "66" };
			String sth[] = { "111", "222", "333", "444", "555", "666" };
			String tk311 = "";
			for (int i = 0; i < eth.length; i++) {
				tk311 += "	<div class='fl myfl' style='width:33.3%;'>" + "		<button class='btn3 qiu2'>" + eth[i]
						+ "</button><span>"+ odds(str3[i], odds)+"</span>" + "	</div>";
			}
			String tk312 = "";
			for (int i = 0; i < eth.length; i++) {
				tk312 += "	<div class='fl myfl' style='width:33.3%;'>" + "		<button class='btn3 qiu2'>" + eth[i]
						+ "</button><span>"+ odds(str4[0], odds)+"</span>" + "	</div>";
			}
			String tk341 = "";
			for (int i = 0; i < sth.length; i++) {
				tk341 += "	<div class='fl myfl' style='width:33.3%;'>" + "		<button class='btn2 2'>" + sth[i]
						+ "</button><span>"+ odds(str8[i], odds)+"</span>" + "	</div>";
			}
			//str += "</div></div>";
			xiazhuqu += "" + "<a name='" + wfclassk3[0] + "'></a>" + "<div class='" + wfclassk3[0] + " wfdiv'>"
					+ "<div class='title'>" + wfk3[0] + "　赔率:" + odds(str1[0], odds) + "</div>" + tk3 + "	<input class='temp' />"
					+ "</div>"

					+ "<a name='" + wfclassk3[1] + "'></a>" + "<div class='" + wfclassk3[1] + " wfdiv'>"
					+ "<div class='title'>" + wfk3[1] + "　赔率:" + odds(str2[0], odds) + "</div>"
					+ "	<div class='fl myfl' style='width:100%;'>" + "		<button class='btn2 8'>三连号通选</button>"
					+ "	</div>" + "	<input class='temp' />" + "</div>"

					+ "<a name='" + wfclassk3[2] + "'></a>" + "<div class='" + wfclassk3[2] + " wfdiv'>"
					+ "<div class='title'>" + wfk3[2] +"</div>" + tk311 + "	<input class='temp' />" + "</div>"

					/*
					 * +"<a name='"+wfclassk3[3]+ "'></a>"
					 * +"<div class='"+wfclassk3[3]+" wfdiv'>"
					 * +"<div class='title'>"+wfk3[3]+"　同号　赔率:"+Double.
					 * parseDouble(str4[0])+"</div>" +tk31
					 * +"	<input class='temp' />" +"</div>"
					 * 
					 * +"<div class='"+wfclassk3[3]+" wfdiv'>"
					 * +"<div class='title'>"+wfk3[3]+"　不同号　赔率:"+Double.
					 * parseDouble(str4[0])+"</div>" +tk3
					 * +"	<input class='temp' />" +"</div>"
					 */
					+ "<a name='" + wfclassk3[3] + "'></a>" + "<div class='" + wfclassk3[3] + " wfdiv'>"
					+ "<div class='title'>" + wfk3[3] + "</div>" + tk312 + "	<input class='temp' />" + "</div>"
					+ "<div class='" + wfclassk3[3] + " wfdiv'>" + tk31 + "	<input class='temp' />" + "</div>"

					+ "<a name='" + wfclassk3[4] + "'></a>" + "<div class='" + wfclassk3[4] + " wfdiv'>"
					+ "<div class='title'>" + wfk3[4] + "　赔率:" + Double.parseDouble(odds(str5[0], odds)) + "</div>" + tk3
					+ "	<input class='temp' />" + "</div>"

					+ "<a name='" + wfclassk3[5] + "'></a>" + "<div class='" + wfclassk3[5] + " wfdiv'>"
					+ "<div class='title'>" + wfk3[5] + "　拖/胆　赔率:" + Double.parseDouble(odds(str6[0], odds)) + "</div>" + tk3
					+ "	<input class='temp' />" + "</div>"
					+ "<div class='" + wfclassk3[5] + " wfdiv'>" + tk33 + "	<input class='temp' />" + "</div>"

					+ "<a name='" + wfclassk3[6] + "'></a>" + "<div class='" + wfclassk3[6] + " wfdiv'>"
					+ "<div class='title'>" + wfk3[6] + "　赔率:" + Double.parseDouble(odds(str7[0], odds)) + "</div>"
					+ "	<div class='fl myfl' style='width:100%;'>" + "		<button class='btn2 8'>三同号通选</button>"
					+ "	</div>" + "	<input class='temp' />" + "</div>"

					+ "<a name='" + wfclassk3[7] + "'></a>" + "<div class='" + wfclassk3[7] + " wfdiv'>"
					+ "<div class='title'>" + wfk3[7] + "</div>" + tk341 + "	<input class='temp' />" + "</div>"

					+ "<a name='" + wfclassk3[8] + "'></a>" + "<div class='" + wfclassk3[8] + " wfdiv'>"
					+ "<div class='title'>" + wfk3[8] + "　赔率:" + Double.parseDouble(odds(str9[0], odds)) + "</div>" + tk3
					+ "	<input class='temp' />" + "</div>"

					+ "<a name='" + wfclassk3[9] + "'></a>" + "<div class='" + wfclassk3[9] + " wfdiv'>"
					+ "<div class='title'>" + wfk3[9] + "</div>" + "	<div class='fl myfl' style='width:50%;'>"
					+ "		<button class='btn2 2'>豹子</button>" + "		<span>" + Double.parseDouble(odds(str10[0], odds))
					+ "</span>" + "	</div>" + "	<div class='fl myfl' style='width:50%;'>"
					+ "		<button class='btn2 2'>顺子</button>" + "		<span>" + Double.parseDouble(odds(str10[1], odds))
					+ "</span>" + "	</div>" + "	<div class='fl myfl' style='width:50%;'>"
					+ "		<button class='btn2 2'>对子</button>" + "		<span>" + Double.parseDouble(odds(str10[2], odds))
					+ "</span>" + "	</div>" + "	<div class='fl myfl' style='width:50%;'>"
					+ "		<button class='btn2 2'>半顺</button>" + "		<span>" + Double.parseDouble(odds(str10[3], odds))
					+ "</span>" + "	</div>" + "	<div class='fl myfl' style='width:50%;'>"
					+ "		<button class='btn2 2'>杂六</button>" + "		<span>" + Double.parseDouble(odds(str10[4], odds))
					+ "</span>" + "	</div>" + "	<input class='temp' />" + "</div>"

					+ "<a name='" + wfclassk3[10] + "'></a>" + "<div class='" + wfclassk3[10] + " wfdiv'>"
					+ "<div class='title'>" + wfk3[10] + "</div>" + tk35
					+ "	<div class='fl myfl' style='width:33.3%;'>" + "		<button class='btn2 2'>大</button>"
					+ "		<span>" + Double.parseDouble(odds(str11[16], odds)) + "</span>" + "	</div>"
					+ "	<div class='fl myfl' style='width:33.3%;'>" + "		<button class='btn2 2'>小</button>"
					+ "		<span>" + Double.parseDouble(odds(str11[16], odds)) + "</span>" + "	</div>"
					+ "	<div class='fl myfl' style='width:33.3%;'>" + "		<button class='btn2 2'>单</button>"
					+ "		<span>" + Double.parseDouble(odds(str11[16], odds)) + "</span>" + "	</div>"
					+ "	<div class='fl myfl' style='width:33.3%;'>" + "		<button class='btn2 2'>双</button>"
					+ "		<span>" + Double.parseDouble(odds(str11[16], odds)) + "</span>" + "	</div>" + "	<input class='temp' />"
					+ "</div>";
			break;
		case "bj28":
		case "xy28":
		case "jnd28":
			// TODO 28
			String pc28[]= {"混合","特码","特码包三","波色","豹子"};
			String wfclasspc28[]= {"hunhe","tema","tmb3","teshe","baozi"};
			//str="<div><div class='wf'>";
			//for (int i = 0; i < pc28.length; i++) {
			//	str += "<a href='#" + wfclasspc28[i] + "'>" + pc28[i] + "</a>";
			//}
			//str+="</div>" + "</div>";
			//混合
			xiazhuqu += "" + "<a name='" + wfclasspc28[0] + "'></a>" + "<div class='" + wfclasspc28[0] + " wfdiv'>" + "<div class='title'>"+pc28[0]+"</div>"
					+ "	<div class='col-xs-6'>" + "		<button class='btn2 2'>大</button>" + "		<span>"
					+ Double.parseDouble(odds(str1[0], odds)) + "</span>" + "	</div>" + "	<div class='col-xs-6'>"
					+ "		<button class='btn2 2'>小</button>" + "		<span>" + Double.parseDouble(odds(str1[1], odds))
					+ "</span>" + "	</div>" + "	<div class='col-xs-6'>" + "		<button class='btn2 2'>单</button>"
					+ "		<span>" + Double.parseDouble(odds(str1[2], odds)) + "</span>" + "	</div>" + "	<div class='col-xs-6'>"
					+ "		<button class='btn2 2'>双</button>" + "<span>" + Double.parseDouble(odds(str1[3], odds))
					+ "</span>" + "	</div>"+  "	<div class='col-xs-6'>"
					+ "		<button class='btn2 2'>大单</button>" + "<span>" + Double.parseDouble(odds(str1[4], odds))
					+ "</span>" + "	</div>"+ "	<div class='col-xs-6'>"
					+ "		<button class='btn2 2'>大双</button>" + "<span>" + Double.parseDouble(odds(str1[5], odds))
					+ "</span>" + "	</div>" + "	<div class='col-xs-6'>"
					+ "		<button class='btn2 2'>小单</button>" + "<span>" + Double.parseDouble(odds(str1[6], odds))
					+ "</span>" + "	</div>" + "	<div class='col-xs-6'>"
					+ "		<button class='btn2 2'>小双</button>" + "<span>" + Double.parseDouble(odds(str1[7], odds))
					+ "</span>" + "	</div>" + "	<div class='col-xs-6'>"
					+ "		<button class='btn2 2'>极大</button>" + "<span>" + Double.parseDouble(odds(str1[8], odds))
					+ "</span>" + "	</div>"+"	<div class='col-xs-6'>"
					+ "		<button class='btn2 2'>极小</button>" + "<span>" + Double.parseDouble(odds(str1[9], odds))
					+ "</span>" + "	</div>"  + "<input class='temp' />" + "</div>";
			String[] hongbo = { "1", "2", "7", "8", "12", "13", "18", "19", "23", "24"};
			String[] lanbo = { "3", "4", "9", "10", "14", "15", "20", "25", "26"};
			String[] Lvbo = { "0","5", "6", "11", "16", "17", "21", "22", "27"};
			List<String> hb1 = Arrays.asList(hongbo);
			List<String> lbo1 = Arrays.asList(lanbo);
			List<String> lvbo1 = Arrays.asList(Lvbo);
			//特码
			xiazhuqu += "" + "<a name='" + wfclasspc28[1] + "'></a>" + "<div class='" + wfclasspc28[1] + " wfdiv'>" + "<div class='title'>"+pc28[1]+"</div>";
			for (int i = 0; i < 28; i++) {
				String x = i + "";
				if (hb1.contains(x)) {
				xiazhuqu += "	<div class='fl myfl' style='width:33.33%;'>" + "		<button class='btn3 hb'>" + x
						+ "</button><span>"+odds(str2[i], odds)+"</span>" + "	</div>";
				}
				if (lbo1.contains(x)) {
					xiazhuqu += "	<div class='fl myfl' style='width:33.33%;'>" + "		<button class='btn3 lbo'>" + x
							+ "</button><span>"+odds(str2[i], odds)+"</span>" + "	</div>";
					}
				if (lvbo1.contains(x)) {
					xiazhuqu += "	<div class='fl myfl' style='width:33.33%;'>" + "		<button class='btn3 lvbo'>" + x
							+ "</button><span>"+odds(str2[i], odds)+"</span>" + "	</div>";
					}
			}
			xiazhuqu += "<input class='temp' />" + "</div>";
			//特码包三
			xiazhuqu += "" + "<a name='" + wfclasspc28[2] + "'></a>" + "<div class='" + wfclasspc28[2] + " wfdiv'>" + "<div class='title'>"+pc28[2]+"</div>";
			for (int i = 0; i < 28; i++) {
				String x = i + "";
				if (hb1.contains(x)) {
					xiazhuqu += "	<div class='fl myfl' style='width:33.33%;'>" + "		<button class='btn3 hb'>" + x
							+ "</button><span>"+odds(str3[i], odds)+"</span>" + "	</div>";
					}
				if (lbo1.contains(x)) {
					xiazhuqu += "	<div class='fl myfl' style='width:33.33%;'>" + "		<button class='btn3 lbo'>" + x
							+ "</button><span>"+odds(str3[i], odds)+"</span>" + "	</div>";
					}
				if (lvbo1.contains(x)) {
					xiazhuqu += "	<div class='fl myfl' style='width:33.33%;'>" + "		<button class='btn3 lvbo'>" + x
							+ "</button><span>"+odds(str3[i], odds)+"</span>" + "	</div>";
					}
			}
			xiazhuqu += "<input class='temp' />" + "</div>";
			
			//波色  --豹子
			xiazhuqu += "" + "<a name='" + wfclasspc28[3] + "'></a>" + "<div class='" + wfclasspc28[3] + " wfdiv'>" + "<div class='title'>"+pc28[3]+"</div>"
			         +"<div class='col-xs-6'>"
					+ "		<button class='btn2 2'>红波</button>" + "		<span>" + Double.parseDouble(odds(str4[0], odds))
					+ "</span>" + "	</div>"+  "	<div class='col-xs-6'>"
					+ "		<button class='btn2 2'>绿波</button>" + "		<span>" + Double.parseDouble(odds(str4[1], odds))
					+ "</span>" + "	</div>"+"	<div class='col-xs-6'>"
					+ "		<button class='btn2 2'>蓝波</button>" + "		<span>" + Double.parseDouble(odds(str4[2], odds))
					+ "</span>" + "	</div>"       + "	<input class='temp' />" + "</div>"
					+"<a name='" + wfclasspc28[4] + "'></a>" + "<div class='" + wfclasspc28[4] + " wfdiv'>" + "<div class='title'>"+pc28[4]
					+ "　赔率:" + Double.parseDouble(odds(str5[0], odds))+"</div>"
					+ "<div class='fl myfl' style='width:100%;'>" + "<button class='btn2 8'>"+pc28[4] 
					+ "</button>"+"</div>"+"<input class='temp' />" + "</div>";
			break;
		case "gdkl10f":
		case "cqkl10f":
			// TODO 快乐10分
			String kl10f[] = { "首位数投", "首位红投", "二连直选", "二连组选", "前三直选", "前三组选", "快乐二", "快乐三", "快乐四", "快乐五" };
			String wfclasstkl10f[] = { "swst", "swht", "elzhx", "elzx", "q3zhx", "q3zx", "kl2", "kl3", "kl4", "kl5" };
			//str = "<div><div class='wf'>";
			//for (int i = 0; i < kl10f.length; i++) {
			//	str += "<a href='#" + wfclasstkl10f[i] + "'>" + kl10f[i] + "</a>";
			//}
			String t10f11 = "";
			for (int i = 1; i < 19; i++) {
				String x = i + "";
				if (Integer.parseInt(x) < 10) {
					x = "0" + i;
				}
				t10f11 += "	<div class='fl myfl' style='width:33.33%;'>" + "		<button class='btn3 qiu8'>" + x
						+ "</button><span>"+odds(str1[i-1], odds)+"</span>" + "	</div>";
			}
			String t10f01 = "";
			for (int i = 19; i < 21; i++) {
				String x = i + "";
				if (Integer.parseInt(x) < 10) {
					x = "0" + i;
				}
				t10f01 += "	<div class='col-xs-6'>" + "		<button class='btn3 qiu8'>" + x
						+ "</button><span>"+odds(str2[i-19], odds)+"</span>" + "	</div>";
			}
			String t10f1 = "";
			for (int i = 1; i < 21; i++) {
				String x = i + "";
				if (Integer.parseInt(x) < 10) {
					x = "0" + i;
				}
				t10f1 += "	<div class='fl myfl' style='width:14.28%;'>" + "		<button class='btn3 qiu8'>" + x
						+ "</button>" + "	</div>";
			}
			String t10f2 = "";
			for (int i = 1; i < 21; i++) {
				String x = i + "";
				if (Integer.parseInt(x) < 10) {
					x = "0" + i;
				}
				t10f2 += "	<div class='fl myfl' style='width:14.28%;'>" + "		<button class='btn3 qiu2'>" + x
						+ "</button>" + "	</div>";
			}
			String t10f3 = "";
			for (int i = 1; i < 21; i++) {
				String x = i + "";
				if (Integer.parseInt(x) < 10) {
					x = "0" + i;
				}
				t10f3 += "	<div class='fl myfl' style='width:14.28%;'>" + "		<button class='btn3 qiu3'>" + x
						+ "</button>" + "	</div>";
			}
			//str += "</div></div>";

			xiazhuqu += "" + "<a name='" + wfclasstkl10f[0] + "'></a>" + "<div class='" + wfclasstkl10f[0] + " wfdiv'>"
					+ "<div class='title'>" + kl10f[0] + "</div>" + t10f11 + "	<input class='temp' />" + "</div>"

					+ "<a name='" + wfclasstkl10f[1] + "'></a>" + "<div class='" + wfclasstkl10f[1] + " wfdiv'>"
					+ "<div class='title'>" + kl10f[1] + "</div>" + t10f01 + "	<input class='temp' />" + "</div>"

					+ "<a name='" + wfclasstkl10f[2] + "'></a>" + "<div class='" + wfclasstkl10f[2] + " wfdiv'>"
					+ "<div class='title'>" + kl10f[2] + "　赔率:" + Double.parseDouble(odds(str3[0], odds)) + "</div>" + t10f1
					+ "	<input class='temp' />" + "</div>" + "<div class='" + wfclasstkl10f[2] + " wfdiv'>" + t10f2
					+ "	<input class='temp' />" + "</div>"

					+ "<a name='" + wfclasstkl10f[3] + "'></a>" + "<div class='" + wfclasstkl10f[3] + " wfdiv'>"
					+ "<div class='title'>" + kl10f[3] + "　赔率:" + Double.parseDouble(odds(str4[0], odds)) + "</div>" + t10f1
					+ "	<input class='temp' />" + "</div>"

					+ "<a name='" + wfclasstkl10f[4] + "'></a>" + "<div class='" + wfclasstkl10f[4] + " wfdiv'>"
					+ "<div class='title'>" + kl10f[4] + "　赔率:" + Double.parseDouble(odds(str5[0], odds)) + "</div>" + t10f1
					+ "	<input class='temp' />" + "</div>" + "<div class='" + wfclasstkl10f[4] + " wfdiv'>" + t10f2
					+ "	<input class='temp' />" + "</div>" + "<div class='" + wfclasstkl10f[4] + " wfdiv'>" + t10f3
					+ "	<input class='temp' />" + "</div>";
			Double d[] = { Double.parseDouble(odds(str6[0], odds)), Double.parseDouble(odds(str7[0], odds)), Double.parseDouble(odds(str8[0], odds)),
					Double.parseDouble(odds(str9[0], odds)), Double.parseDouble(odds(str10[0], odds)) };
			for (int i = 5; i < wfclasstkl10f.length; i++) {
				xiazhuqu += "<a name='" + wfclasstkl10f[i] + "'></a>" + "<div class='" + wfclasstkl10f[i] + " wfdiv'>"
						+ "<div class='title'>" + kl10f[i] + "　赔率:" + d[i - 5] + "</div>" + t10f1
						+ "	<input class='temp' />" + "</div>";
			}

			break;
		case "gd11x5":
		case "ah11x5":
		case "jx11x5":
		case "sd11x5":
		case "sh11x5":
			// TODO 11选5
			String wft11x5[] = { "第一球", "第二球", "第三球", "第四球", "第五球", "总　和", "标准玩法" };
			String wfclasst11x5[] = { "d1q", "d2q", "d3q", "d4q", "d5q", "zh", "bzwf" };
			//str = "<div><div class='wf'>";
			//for (int i = 0; i < wft11x5.length; i++) {
			//	str += "<a href='#" + wfclasst11x5[i] + "'>" + wft11x5[i] + "</a>";
			//}
			//str += "</div></div>";
			String t11x51 = "";
			String t11x52 = "";
			String t11x53 = "";
			String t11x54 = "";
			String t11x55 = "";
			for (int i = 1; i < 12; i++) {
				String x = i + "";
				if (Integer.parseInt(x) < 10) {
					x = "0" + i;
				}
				t11x51 += "	<div class='col-xs-6'>" + "		<button class='btn3 qiu8'>" + x + "</button>"
						+ "		<span>" + odds(str1[i+3], odds) + "</span>" + "	</div>";
				t11x52 += "	<div class='col-xs-6'>" + "		<button class='btn3 qiu8'>" + x + "</button>"
						+ "		<span>" + odds(str2[i+3], odds) + "</span>" + "	</div>";
				t11x53 += "	<div class='col-xs-6'>" + "		<button class='btn3 qiu8'>" + x + "</button>"
						+ "		<span>" + odds(str3[i+3], odds) + "</span>" + "	</div>";
				t11x54 += "	<div class='col-xs-6'>" + "		<button class='btn3 qiu8'>" + x + "</button>"
						+ "		<span>" + odds(str4[i+3], odds) + "</span>" + "	</div>";
				t11x55 += "	<div class='col-xs-6'>" + "		<button class='btn3 qiu8'>" + x + "</button>"
						+ "		<span>" + odds(str5[i+3], odds) + "</span>" + "	</div>";
			}
			List<String> t11x551=new ArrayList<String>();
			t11x551.add(t11x51);
			t11x551.add(t11x52);
			t11x551.add(t11x53);
			t11x551.add(t11x54);
			t11x551.add(t11x55);
			List<String[]> syx5=new ArrayList<String[]>();
			syx5.add(str1);
			syx5.add(str2);
			syx5.add(str3);
			syx5.add(str4);
			syx5.add(str5);
			
			for (int i = 0; i < wft11x5.length - 2; i++) {
				xiazhuqu += "<a name='" + wfclasst11x5[i] + "'></a>" + "<div class='" + wfclasst11x5[i] + " wfdiv'>"
						+ "<div class='title'>" + wft11x5[i] + "</div>" + "	<div class='col-xs-6'>"
						+ "		<button class='btn2 2'>单</button>" + "		<span>" + odds(syx5.get(i)[0], odds)
						+ "</span>" + "	</div>" + "	<div class='col-xs-6'>" + "		<button class='btn2 2'>双</button>"
						+ "		<span>" + odds(syx5.get(i)[1], odds) + "</span>" + "	</div>"
						+ "	<div class='col-xs-6'>" + "		<button class='btn2 2'>大</button>" + "		<span>"
						+ odds(syx5.get(i)[2], odds) + "</span>" + "	</div>" + "	<div class='col-xs-6'>"
						+ "		<button class='btn2 2'>小</button>" + "		<span>" + odds(syx5.get(i)[3], odds)
						+ "</span>" + "	</div>" + t11x551.get(i) + "	<input class='temp' />" + "</div>";
			}
			xiazhuqu += "<a name='" + wfclasst11x5[wfclasst11x5.length - 2] + "'></a>" + "<div class='"
					+ wfclasst11x5[wfclasst11x5.length - 2] + " wfdiv'>" + "<div class='title'>"
					+ wft11x5[wfclasst11x5.length - 2] + "</div>" + "	<div class='col-xs-6'>"
					+ "		<button class='btn2 2'>单</button>" + "		<span>" + Double.parseDouble(odds(str6[0], odds))
					+ "</span>" + "	</div>" + "	<div class='col-xs-6'>" + "		<button class='btn2 2'>双</button>"
					+ "		<span>" + Double.parseDouble(odds(str6[1], odds)) + "</span>" + "	</div>" + "	<div class='col-xs-6'>"
					+ "		<button class='btn2 2'>大</button>" + "		<span>" + Double.parseDouble(odds(str6[2], odds))
					+ "</span>" + "	</div>" + "	<div class='col-xs-6'>" + "		<button class='btn2 2'>小</button>"
					+ "		<span>" + Double.parseDouble(odds(str6[3], odds)) + "</span>" + "	</div>" + "	<input class='temp' />"
					+ "</div>";

			String t21 = "";
			for (int i = 1; i < 12; i++) {
				String x = i + "";
				if (i<10) {
					x="0"+x;
				}
				t21 += "	<div class='fl myfl' style='width:20%;'>" + "		<button class='btn3 qiu8'>" + x
						+ "</button>" + "	</div>";
			}
			String t211 = "";
			for (int i = 1; i < 12; i++) {
				String x = i + "";
				if (i<10) {
					x="0"+x;
				}
				t211 += "	<div class='fl myfl' style='width:33.33%;'>" + "		<button class='btn3 qiu8'>" + x
						+ "</button><span>"+odds(str7[i-1], odds)+"</span>" + "	</div>";
			}
			String t31 = "";
			for (int i = 1; i < 12; i++) {
				String x = i + "";
				if (i<10) {
					x="0"+x;
				}
				t31 += "	<div class='fl myfl' style='width:20%;'>" + "		<button class='btn3 qiu4'>" + x
						+ "</button>" + "	</div>";
			}
			String t41 = "";
			for (int i = 1; i < 12; i++) {
				String x = i + "";
				if (i<10) {
					x="0"+x;
				}
				t41 += "	<div class='fl myfl' style='width:20%;'>" + "		<button class='btn3 qiu9'>" + x
						+ "</button>" + "	</div>";
			}
			String bzwf11x5[] = { "前一直选", "前二直选", "前三直选", "任选一", "任选二", "任选三", "任选四", "任选五", "任选六", "任选七", "任选八" };
			Double bzwf11x5pl[] = { Double.parseDouble(odds(str7[0], odds)), Double.parseDouble(odds(str8[0], odds)),
					Double.parseDouble(odds(str9[0], odds)), Double.parseDouble(odds(str10[0], odds)), Double.parseDouble(odds(str11[0], odds)),
					Double.parseDouble(odds(str12[0], odds)), Double.parseDouble(odds(str13[0], odds)), Double.parseDouble(odds(str14[0], odds)),
					Double.parseDouble(odds(str15[0], odds)), Double.parseDouble(odds(str16[0], odds)), Double.parseDouble(odds(str17[0], odds)) };

			String t51 = "";
			for (int i = 4; i < bzwf11x5.length; i++) {
				t51 += "<div class='" + wfclasst11x5[wfclasst11x5.length - 1] + " wfdiv'>" + "<div class='title'>"
						+ wft11x5[wft11x5.length - 1] + " - " + bzwf11x5[i] + "　赔率:" + bzwf11x5pl[i] + "</div>" + t21
						+ "	<input class='temp' />" + "</div>";
			}

			xiazhuqu += "<a name='bzwf'></a>" + "<div class='" + wfclasst11x5[wfclasst11x5.length - 1] + " wfdiv'>"
					+ "<div class='title'>" + wft11x5[wft11x5.length - 1] + " - " + bzwf11x5[0] + "</div>" + t211
					+ "	<input class='temp' />" + "</div>"

					+ "<div class='" + wfclasst11x5[wfclasst11x5.length - 1] + " wfdiv'>" + "<div class='title'>"
					+ wft11x5[wft11x5.length - 1] + " - " + bzwf11x5[1] + "　赔率:" + bzwf11x5pl[1] + "</div>" + t21
					+ "	<input class='temp' />" + "</div>" + "<div class='" + wfclasst11x5[wfclasst11x5.length - 1]
					+ " wfdiv'>" + t31 + "	<input class='temp' />" + "</div>"

					+ "<div class='" + wfclasst11x5[wfclasst11x5.length - 1] + " wfdiv'>" + "<div class='title'>"
					+ wft11x5[wft11x5.length - 1] + " - " + bzwf11x5[2] + "　赔率:" + bzwf11x5pl[2] + "</div>" + t21
					+ "	<input class='temp' />" + "</div>" + "<div class='" + wfclasst11x5[wfclasst11x5.length - 1]
					+ " wfdiv'>" + t31 + "	<input class='temp' />" + "</div>" + "<div class='"
					+ wfclasst11x5[wfclasst11x5.length - 1] + " wfdiv'>" + t41 + "	<input class='temp' />" + "</div>"

					+ "<div class='" + wfclasst11x5[wfclasst11x5.length - 1] + " wfdiv'>" + "<div class='title'>"
					+ wft11x5[wft11x5.length - 1] + " - " + bzwf11x5[3] + "</div>" + t211 + "	<input class='temp' />"
					+ "</div>"

					+ t51
			;
			break;
		case "cqssc":
		case "tjssc":
		case "xjssc":
		case "2fssc":
			// TODO 时时彩
			String wf1[] = { "总　和", "第一球", "第二球", "第三球", "第四球", "第五球", "前　三", "中　三", "后　三", "连　码" };
			String wfclass1[] = { "zh", "d1q", "d2q", "d3q", "d4q", "d5q", "q3", "z3", "h3", "lm" };
			//str = "<div><div class='wf'>";
			//for (int i = 0; i < wf1.length; i++) {
			//	str += "<a href='#" + wfclass1[i] + "'>" + wf1[i] + "</a>";
			//}
			//str += "</div></div>";
			// 总和
			xiazhuqu += "" + "<a name='zh'></a>" + "<div class='zh wfdiv'>" + "<div class='title'>总　和</div>"
					+ "	<div class='col-xs-6'>" + "		<button class='btn2 2'>单</button>" + "		<span>"
					+ Double.parseDouble(odds(str1[0], odds)) + "</span>" + "	</div>" + "	<div class='col-xs-6'>"
					+ "		<button class='btn2 2'>双</button>" + "		<span>" + Double.parseDouble(odds(str1[1], odds))
					+ "</span>" + "	</div>" + "	<div class='col-xs-6'>" + "		<button class='btn2 2'>大</button>"
					+ "		<span>" + Double.parseDouble(odds(str1[2], odds)) + "</span>" + "	</div>" + "	<div class='col-xs-6'>"
					+ "		<button class='btn2 2'>小</button>" + "		<span>" + Double.parseDouble(odds(str1[3], odds))
					+ "</span>" + "	</div>" + "	<div class='col-xs-6'>" + "		<button class='btn2 2'>龙</button>"
					+ "		<span>" + Double.parseDouble(odds(str1[4], odds)) + "</span>" + "	</div>" + "	<div class='col-xs-6'>"
					+ "		<button class='btn2 2'>虎</button>" + "		<span>" + Double.parseDouble(odds(str1[5], odds))
					+ "</span>" + "	</div>" + "	<div class='col-xs-6'>" + "		<button class='btn2 2'>和</button>"
					+ "		<span>" + Double.parseDouble(odds(str1[6], odds)) + "</span>" + "	</div>" + "	<input class='temp' />"
					+ "</div>";
			String t11 = "";
			String t12 = "";
			String t13 = "";
			String t14 = "";
			String t15 = "";
			for (int i = 0; i < 10; i++) {
				String x = i + "";
				t11 += "	<div class='col-xs-6'>" + "		<button class='btn3 qiu8'>" + x + "</button>" + "		<span>"
						+ Double.parseDouble( odds(str2[i+4], odds) )+ "</span>" + "	</div>";
				t12 += "	<div class='col-xs-6'>" + "		<button class='btn3 qiu8'>" + x + "</button>" + "		<span>"
						+ Double.parseDouble( odds(str3[i+4], odds) )+ "</span>" + "	</div>";
				t13 += "	<div class='col-xs-6'>" + "		<button class='btn3 qiu8'>" + x + "</button>" + "		<span>"
						+ Double.parseDouble( odds(str4[i+4], odds) )+ "</span>" + "	</div>";
				t14 += "	<div class='col-xs-6'>" + "		<button class='btn3 qiu8'>" + x + "</button>" + "		<span>"
						+ Double.parseDouble( odds(str5[i+4], odds) )+ "</span>" + "	</div>";
				t15 += "	<div class='col-xs-6'>" + "		<button class='btn3 qiu8'>" + x + "</button>" + "		<span>"
						+ Double.parseDouble( odds(str6[i+4], odds) )+ "</span>" + "	</div>";
			}
			List<String> s= new ArrayList<String>();
			s.add(t11);
			s.add(t12);
			s.add(t13);
			s.add(t14);
			s.add(t15);
			
			List<String[]> d1=new ArrayList<String[]>();
			d1.add(str2);
			d1.add(str3);
			d1.add(str4);
			d1.add(str5);
			d1.add(str6);
			
			for (int i = 1; i < 6; i++) {
				xiazhuqu += "<a name='" + wfclass1[i] + "'></a>" + "<div class='" + wfclass1[i] + " wfdiv'>"
						+ "<div class='title'>" + wf1[i] + "</div>" + "	<div class='col-xs-6'>"
						+ "		<button class='btn2 2'>单</button>" + "		<span>" + odds( d1.get(i-1)[0], odds)
						+ "</span>" + "	</div>" + "	<div class='col-xs-6'>" + "		<button class='btn2 2'>双</button>"
						+ "		<span>" +  odds(d1.get(i-1)[1], odds) + "</span>" + "	</div>"
						+ "	<div class='col-xs-6'>" + "		<button class='btn2 2'>大</button>" + "		<span>"
						+  odds(d1.get(i-1)[2], odds) + "</span>" + "	</div>" + "	<div class='col-xs-6'>"
						+ "		<button class='btn2 2'>小</button>" + "		<span>" +  odds(d1.get(i-1)[3], odds)
						+ "</span>" + "	</div>" + s.get(i-1) + "	<input class='temp' />" + "</div>";
			}
			List<String[]> d11=new ArrayList<String[]>();
			d11.add(str7);
			d11.add(str8);
			d11.add(str9);
			
			for (int i = 6; i < wf1.length - 1; i++) {
				xiazhuqu += "<a name='" + wfclass1[i] + "'></a>" + "<div class='" + wfclass1[i] + " wfdiv'>"
						+ "<div class='title'>" + wf1[i] + "</div>" + "	<div class='col-xs-6'>"
						+ "		<button class='btn2 2'>豹子</button>" + "		<span>" +  odds(d11.get(i-6)[0], odds)
						+ "</span>" + "	</div>" + "	<div class='col-xs-6'>" + "		<button class='btn2 2'>顺子</button>"
						+ "		<span>" +  odds(d11.get(i-6)[1], odds) + "</span>" + "	</div>"
						+ "	<div class='col-xs-6'>" + "		<button class='btn2 2'>对子</button>" + "		<span>"
						+  odds(d11.get(i-6)[2], odds) + "</span>" + "	</div>" + "	<div class='col-xs-6'>"
						+ "		<button class='btn2 2'>半顺</button>" + "		<span>" +  odds(d11.get(i-6)[3], odds)
						+ "</span>" + "	</div>" + "	<div class='col-xs-6'>"
						+ "		<button class='btn2 2'>杂六</button>" +"	<span>" +  odds(d11.get(i-6)[4], odds)+ "</span></div>"
						+ "	<input class='temp' />" + "</div>" ;
			}
			String t2 = "";
			for (int i = 0; i < 10; i++) {
				String x = i + "";
				t2 += "	<div class='fl myfl' style='width:20%;'>" + "		<button class='btn3 qiu8'>" + x
						+ "</button>" + "	</div>";
			}
			String t3 = "";
			for (int i = 0; i < 10; i++) {
				String x = i + "";
				t3 += "	<div class='fl myfl' style='width:20%;'>" + "		<button class='btn3 qiu4'>" + x
						+ "</button>" + "	</div>";
			}
			String t4 = "";
			for (int i = 0; i < 10; i++) {
				String x = i + "";
				t4 += "	<div class='fl myfl' style='width:20%;'>" + "		<button class='btn3 qiu9'>" + x
						+ "</button>" + "	</div>";
			}

			String zuxuan[] = { "前二组选", "后二组选", "前三组六", "中三组六", "后三组六", "前三组三", "中三组三", "后三组三" };
			Double zuxuanpl[] = { Double.parseDouble( odds(str15[0], odds)), Double.parseDouble( odds(str16[0], odds)),
					Double.parseDouble( odds(str17[0], odds)), Double.parseDouble( odds(str18[0], odds)), Double.parseDouble( odds(str19[0], odds)),
					Double.parseDouble( odds(str20[0], odds)), Double.parseDouble( odds(str21[0], odds)), Double.parseDouble( odds(str22[0], odds)) };

			String t5 = "";
			for (int i = 0; i < zuxuan.length; i++) {
				t5 += "<div class='" + wfclass1[wf1.length - 1] + " wfdiv'>" + "<div class='title'>"
						+ wf1[wf1.length - 1] + " - " + zuxuan[i] + "　赔率:" + zuxuanpl[i] + "</div>" + t2
						+ "	<input class='temp' />" + "</div>";
			}

			xiazhuqu += "<a name='lm'></a>" + "<div class='" + wfclass1[wf1.length - 1] + " wfdiv'>"
					+ "<div class='title'>" + wf1[wf1.length - 1] + " - 前二直选　赔率:" + Double.parseDouble( odds(str10[0], odds))
					+ "</div>" + t2 + "	<input class='temp' />" + "</div>" + "<div class='" + wfclass1[wf1.length - 1]
					+ " wfdiv'>" + t3 + "	<input class='temp' />" + "</div>"

					+ "<div class='" + wfclass1[wf1.length - 1] + " wfdiv'>" + "<div class='title'>"
					+ wf1[wf1.length - 1] + " - 后二直选　赔率:" + Double.parseDouble( odds(str11[0], odds)) + "</div>" + t2
					+ "	<input class='temp' />" + "</div>" + "<div class='" + wfclass1[wf1.length - 1] + " wfdiv'>" + t3
					+ "	<input class='temp' />" + "</div>"

					+ "<div class='" + wfclass1[wf1.length - 1] + " wfdiv'>" + "<div class='title'>"
					+ wf1[wf1.length - 1] + " - 前三直选　赔率:" + Double.parseDouble( odds(str12[0], odds) )+ "</div>" + t2
					+ "	<input class='temp' />" + "</div>" + "<div class='" + wfclass1[wf1.length - 1] + " wfdiv'>" + t3
					+ "	<input class='temp' />" + "</div>" + "<div class='" + wfclass1[wf1.length - 1] + " wfdiv'>" + t4
					+ "	<input class='temp' />" + "</div>"

					+ "<div class='" + wfclass1[wf1.length - 1] + " wfdiv'>" + "<div class='title'>"
					+ wf1[wf1.length - 1] + " - 中三直选　赔率:" + Double.parseDouble( odds(str13[0], odds)) + "</div>" + t2
					+ "	<input class='temp' />" + "</div>" + "<div class='" + wfclass1[wf1.length - 1] + " wfdiv'>" + t3
					+ "	<input class='temp' />" + "</div>" + "<div class='" + wfclass1[wf1.length - 1] + " wfdiv'>" + t4
					+ "	<input class='temp' />" + "</div>"

					+ "<div class='" + wfclass1[wf1.length - 1] + " wfdiv'>" + "<div class='title'>"
					+ wf1[wf1.length - 1] + " - 后三直选　赔率:" + Double.parseDouble( odds(str14[0], odds) )+ "</div>" + t2
					+ "	<input class='temp' />" + "</div>" + "<div class='" + wfclass1[wf1.length - 1] + " wfdiv'>" + t3
					+ "	<input class='temp' />" + "</div>" + "<div class='" + wfclass1[wf1.length - 1] + " wfdiv'>" + t4
					+ "	<input class='temp' />" + "</div>" + t5;
			break;
		case "bjpk10":
		case "2fpk10":
		case "2fft":
		case "xyft":
		case "xysm":
			String wf[] = { "冠亚和值", "冠　军", "亚　军", "第三名", "第四名", "第五名", "第六名", "第七名", "第八名", "第九名", "第十名" };
			String wfclass[] = { "gyhz", "gj", "yj", "d3m", "d4m", "d5m", "d6m", "d7m", "d8m", "d9m", "d10m" };
			/** 波色-红波-蓝波-绿波 */

			//str = "<div><div class='wf'>";
			//for (int i = 0; i < wf.length; i++) {
			//	str += "<a href='#" + wfclass[i] + "'>" + wf[i] + "</a>";
			//}
			//str += "</div></div>";
			// 冠亚和值
			xiazhuqu += "" + "<a name='gyhz'></a>" + "<div class='gyhz wfdiv'>" + "<div class='title'>冠亚和值</div>"
					+ "	<div class='col-xs-6'>" + "		<button class='btn2 2'>单</button>" + "		<span>"
					+ Double.parseDouble(odds(str1[0], odds)) + "</span>" + "	</div>" + "	<div class='col-xs-6'>"
					+ "		<button class='btn2 2'>双</button>" + "		<span>" + Double.parseDouble(odds(str1[1], odds))
					+ "</span>" + "	</div>" + "	<div class='col-xs-6'>" + "		<button class='btn2 2'>大</button>"
					+ "		<span>" + Double.parseDouble(odds(str1[2], odds)) + "</span>" + "	</div>" + "	<div class='col-xs-6'>"
					+ "		<button class='btn2 2'>小</button>" + "		<span>" + Double.parseDouble(odds(str1[3], odds))
					+ "</span>" + "	</div>" + "	<input class='temp' />" + "</div>";
			List<String[]> pk10=new ArrayList<String[]>();
			pk10.add(str2);
			pk10.add(str3);
			pk10.add(str4);
			pk10.add(str5);
			pk10.add(str6);
			pk10.add(str7);
			pk10.add(str8);
			pk10.add(str9);
			pk10.add(str10);
			pk10.add(str11);
			String t = "";
			for (int i = 1; i < 11; i++) {
				String x = i + "";
				if (Integer.parseInt(x) < 10) {
					x = "0" + i;
				}
				if (i<9) {
					t += "	<div class='col-xs-6'>" + "		<button class='btn3 qiu" + i + "'>" + x + "</button>"
							+ "		<span>" + odds(pk10.get(i-1)[i+5], odds) + "</span>" + "	</div>";
				}else {
					t += "	<div class='col-xs-6'>" + "		<button class='btn3 qiu" + i + "'>" + x + "</button>"
							+ "		<span>" + odds(pk10.get(i-1)[i+3], odds) + "</span>" + "	</div>";
				}
				
//				t1 += "	<div class='col-xs-6'>" + "		<button class='btn3 qiu" + i + "'>" + x + "</button>"
//						+ "		<span>" + pk10.get(i-1)[i+3] + "</span>" + "	</div>";
			}
			for (int i = 1; i < 6; i++) {
				xiazhuqu += "<a name='" + wfclass[i] + "'></a>" + "<div class='" + wfclass[i] + " wfdiv'>"
						+ "<div class='title'>" + wf[i] + "</div>" + "	<div class='col-xs-6'>"
						+ "		<button class='btn2 2'>单</button>" + "		<span>" + odds(pk10.get(i-1)[0], odds)
						+ "</span>" + "	</div>" + "	<div class='col-xs-6'>" + "		<button class='btn2 2'>双</button>"
						+ "		<span>" + odds(pk10.get(i-1)[1], odds) + "</span>" + "	</div>"
						+ "	<div class='col-xs-6'>" + "		<button class='btn2 2'>大</button>" + "		<span>"
						+  odds(pk10.get(i-1)[2], odds) + "</span>" + "	</div>" + "	<div class='col-xs-6'>"
						+ "		<button class='btn2 2'>小</button>" + "		<span>" + odds(pk10.get(i-1)[3], odds)
						+ "</span>" + "	</div>" + "	<div class='col-xs-6'>" + "		<button class='btn2 2'>龙</button>"
						+ "		<span>" +  odds(pk10.get(i-1)[4], odds) + "</span>" + "	</div>"
						+ "	<div class='col-xs-6'>" + "		<button class='btn2 2'>虎</button>" + "		<span>"
						+  odds(pk10.get(i-1)[5], odds) + "</span>" + "	</div>" + t + "	<input class='temp' />"
						+ "</div>";
			}
			for (int i = 6; i < wf.length; i++) {
				xiazhuqu += "<a name='" + wfclass[i] + "'></a>" + "<div class='" + wfclass[i] + " wfdiv'>"
						+ "<div class='title'>" + wf[i] + "</div>" + "	<div class='col-xs-6'>"
						+ "		<button class='btn2 2'>单</button>" + "		<span>" + Double.parseDouble( odds(str2[0], odds))
						+ "</span>" + "	</div>" + "	<div class='col-xs-6'>" + "		<button class='btn2 2'>双</button>"
						+ "		<span>" + Double.parseDouble( odds(str2[1], odds)) + "</span>" + "	</div>"
						+ "	<div class='col-xs-6'>" + "		<button class='btn2 2'>大</button>" + "		<span>"
						+ Double.parseDouble( odds(str2[2], odds))+ "</span>" + "	</div>" + "	<div class='col-xs-6'>"
						+ "		<button class='btn2 2'>小</button>" + "		<span>" + Double.parseDouble( odds(str2[3], odds))
						+ "</span>" + "	</div>" + t + "	<input class='temp' />" + "</div>";
			}
			break;
		case "shssl":
		case "pl3":
		case "fc3d":
			// TODO 时时乐 排列三 福彩3D
			String wffc3d[] = { "前二直选", "前二组选", "后二直选", "后二组选", "三星直选", "三星和值", "三星组三", "组三和值", "三星组六", "组六和值" };
			String wfclass1fc3d[] = { "q2zhx", "q2zx", "h2zhx", "h2zx", "3xzhx", "3xhzh", "3xz3", "z3hzh", "3xz6",
					"z6hzh" };

			//str = "<div><div class='wf'>";
			//for (int i = 0; i < wfclass1fc3d.length; i++) {
			//	str += "<a href='#" + wfclass1fc3d[i] + "'>" + wffc3d[i] + "</a>";
			//}

			//str += "</div></div>";

			String tfc3d = "";
			for (int i = 0; i < 10; i++) {
				String x = i + "";
				tfc3d += "	<div class='fl myfl' style='width:20%;'>" + "		<button class='btn3 qiu8'>" + x
						+ "</button>" + "	</div>";
			}
			String tfc3d11 = "";
			for (int i = 0; i < 10; i++) {
				String x = i + "";
				tfc3d11 += "	<div class='fl myfl' style='width:20%;'>" + "		<button class='btn3 qiu2'>" + x
						+ "</button>" + "	</div>";
			}
			String tfc3d111 = "";
			for (int i = 0; i < 10; i++) {
				String x = i + "";
				tfc3d111 += "	<div class='fl myfl' style='width:20%;'>" + "		<button class='btn3 qiu4'>" + x
						+ "</button>" + "	</div>";
			}
			String tfc3d1 = "";
			for (int i = 0; i < 28; i++) {
				String x = i + "";
				tfc3d1 += "	<div class='fl myfl' style='width:20%;'>" + "		<button class='btn3 qiu8'>" + x
						+ "</button>" + "	</div>";
			}

			String tfc3d2 = "";
			for (int i = 3; i < 25; i++) {
				String x = i + "";
				tfc3d2 += "	<div class='fl myfl' style='width:20%;'>" + "		<button class='btn3 qiu8'>" + x
						+ "</button>" + "	</div>";
			}
			String tfc3d3 = "";
			for (int i = 1; i < 27; i++) {
				String x = i + "";
				tfc3d3 += "	<div class='fl myfl' style='width:20%;'>" + "		<button class='btn3 qiu8'>" + x
						+ "</button>" + "	</div>";
			}

			xiazhuqu += "" + "<a name='" + wfclass1fc3d[0] + "'></a>" + "<div class='" + wfclass1fc3d[0] + " wfdiv'>"
					+ "<div class='title'>" + wffc3d[0] + "　百位/十位　赔率:" + Double.parseDouble( odds(str1[0], odds)) + "</div>" + tfc3d
					+ "	<input class='temp' />" + "</div>"

					+ "<div class='" + wfclass1fc3d[0] + " wfdiv'>" + tfc3d11 + "	<input class='temp' />" + "</div>"

					+ "<a name='" + wfclass1fc3d[1] + "'></a>" + "<div class='" + wfclass1fc3d[1] + " wfdiv'>"
					+ "<div class='title'>" + wffc3d[1] + "　赔率:" + Double.parseDouble( odds(str2[0], odds)) + "</div>" + tfc3d
					+ "	<input class='temp' />" + "</div>"

					+ "<a name='" + wfclass1fc3d[2] + "'></a>" + "<div class='" + wfclass1fc3d[2] + " wfdiv'>"
					+ "<div class='title'>" + wffc3d[2] + "　十位/个位　赔率:" + Double.parseDouble( odds(str3[0], odds)) + "</div>" + tfc3d
					+ "	<input class='temp' />" + "</div>" + "<div class='" + wfclass1fc3d[2] + " wfdiv'>" + tfc3d11
					+ "	<input class='temp' />" + "</div>"

					+ "<a name='" + wfclass1fc3d[3] + "'></a>" + "<div class='" + wfclass1fc3d[3] + " wfdiv'>"
					+ "<div class='title'>" + wffc3d[3] + "　赔率:" + Double.parseDouble(str4[0]) + "</div>" + tfc3d
					+ "	<input class='temp' />" + "</div>"

					+ "<a name='" + wfclass1fc3d[4] + "'></a>" + "<div class='" + wfclass1fc3d[4] + " wfdiv'>"
					+ "<div class='title'>" + wffc3d[4] + "　百/十/个　赔率:" + Double.parseDouble( odds(str5[0], odds)) + "</div>" + tfc3d
					+ "	<input class='temp' />" + "</div>"

					+ "<div class='" + wfclass1fc3d[4] + " wfdiv'>" + tfc3d11 + "	<input class='temp' />" + "</div>"

					+ "<div class='" + wfclass1fc3d[4] + " wfdiv'>" + tfc3d111 + "	<input class='temp' />" + "</div>"

					+ "<a name='" + wfclass1fc3d[5] + "'></a>" + "<div class='" + wfclass1fc3d[5] + " wfdiv'>"
					+ "<div class='title'>" + wffc3d[5] + "　赔率:" + Double.parseDouble( odds(str6[0], odds)) + "</div>" + tfc3d1
					+ "	<input class='temp' />" + "</div>"

					+ "<a name='" + wfclass1fc3d[6] + "'></a>" + "<div class='" + wfclass1fc3d[6] + " wfdiv'>"
					+ "<div class='title'>" + wffc3d[6] + "　赔率:" + Double.parseDouble( odds(str7[0], odds)) + "</div>" + tfc3d
					+ "	<input class='temp' />" + "</div>"

					+ "<a name='" + wfclass1fc3d[7] + "'></a>" + "<div class='" + wfclass1fc3d[7] + " wfdiv'>"
					+ "<div class='title'>" + wffc3d[7] + "　赔率:" + Double.parseDouble( odds(str8[0], odds)) + "</div>" + tfc3d3
					+ "	<input class='temp' />" + "</div>"

					+ "<a name='" + wfclass1fc3d[8] + "'></a>" + "<div class='" + wfclass1fc3d[8] + " wfdiv'>"
					+ "<div class='title'>" + wffc3d[8] + "　赔率:" + Double.parseDouble( odds(str9[0], odds)) + "</div>" + tfc3d
					+ "	<input class='temp' />" + "</div>"

					+ "<a name='" + wfclass1fc3d[9] + "'></a>" + "<div class='" + wfclass1fc3d[9] + " wfdiv'>"
					+ "<div class='title'>" + wffc3d[9] + "　赔率:" + Double.parseDouble( odds(str10[0], odds)) + "</div>" + tfc3d2
					+ "	<input class='temp' />" + "</div>"

			;
			break;
		case "xg6hc":
		case "5f6hc":
			// TODO 香港六合彩
			String xg6hc[] = { "特码A", "特码B", "特码生肖", "大小单双", "家禽野兽", "头数", "尾数", "五行", "总和", "合数", "独平", "平码", "定肖中特",
					"平特肖", "平特尾", "平特不中", "总肖", "色波", "半波", "半半波" };
			String classxg6hc[] = { "tma", "tmb", "tmsx", "dxds", "jqys", "ts", "ws", "wx", "zh", "hs", "dp", "pm",
					"dxzt", "ptx", "ptw", "ptbz", "zx", "sb", "bb", "bbb" };

			String sx[] = { "鼠", "牛", "虎", "兔", "龙", "蛇", "马", "羊", "猴", "鸡", "狗", "猪" };

			String[] hob = { "01", "02", "07", "08", "12", "13", "18", "19", "23", "24", "29", "30", "34", "35", "40",
					"45", "46" };
			String[] lab = { "03", "04", "09", "10", "14", "15", "20", "25", "26", "31", "36", "37", "41", "42", "47",
					"48" };
			String[] lvb = { "05", "06", "11", "16", "17", "21", "22", "27", "28", "32", "33", "38", "39", "43", "44",
					"49" };
			List<String> hb = Arrays.asList(hob);
			List<String> lbo = Arrays.asList(lab);
			List<String> lvbo = Arrays.asList(lvb);

			//str = "<div><div class='wf'>";
			//for (int i = 0; i < xg6hc.length; i++) {
			//	str += "<a href='#" + classxg6hc[i] + "'>" + xg6hc[i] + "</a>";
			//}
			String xg6hchm = "";
			for (int i = 1; i < 50; i++) {
				String x = i + "";
				if (Integer.parseInt(x) < 10) {
					x = "0" + i;
				}
				if (hb.contains(x)) {
					xg6hchm += "	<div class='fl myfl' style='width:20%;'>" + "		<button class='btn3 hb'>" + x
							+ "</button>" + "	</div>";
				}
				if (lbo.contains(x)) {
					xg6hchm += "	<div class='fl myfl' style='width:20%;'>" + "		<button class='btn3 lbo'>" + x
							+ "</button>" + "	</div>";
				}
				if (lvbo.contains(x)) {
					xg6hchm += "	<div class='fl myfl' style='width:20%;'>" + "		<button class='btn3 lvbo'>" + x
							+ "</button>" + "	</div>";
				}
			}
			String xg6hchm11 = "";
			for (int i = 1; i < 50; i++) {
				String x = i + "";
				if (Integer.parseInt(x) < 10) {
					x = "0" + i;
				}
				if (hb.contains(x)) {
					xg6hchm11 += "	<div class='fl myfl' style='width:33.3%;'>" + "		<button class='btn3 hb'>" + x
							+ "</button><span>"+ odds(str11[i-1], odds)+"</span></div>";
				}
				if (lbo.contains(x)) {
					xg6hchm11 += "	<div class='fl myfl' style='width:33.3%;'>" + "		<button class='btn3 lbo'>" + x
							+ "</button><span>"+ odds(str11[i-1], odds)+"</span></div>";
				}
				if (lvbo.contains(x)) {
					xg6hchm11 += "	<div class='fl myfl' style='width:33.3%;'>" + "		<button class='btn3 lvbo'>" + x
							+ "</button><span>"+ odds(str11[i-1], odds)+"</span></div>";
				}
			}
			String xg6hchm1 = "";
			for (int i = 1; i < 50; i++) {
				String x = i + "";
				if (Integer.parseInt(x) < 10) {
					x = "0" + i;
				}
				if (hb.contains(x)) {
					xg6hchm1 += "	<div class='fl myfl' style='width:33.33%;'>" + "		<button class='btn3 hb'>"
							+ x + "</button><span>"+ odds(str1[i-1], odds)+"</span>" + "	</div>";
				}
				if (lbo.contains(x)) {
					xg6hchm1 += "	<div class='fl myfl' style='width:33.33%;'>" + "		<button class='btn3 lbo'>"
							+ x + "</button><span>"+ odds(str1[i-1], odds)+"</span>" + "	</div>";
				}
				if (lvbo.contains(x)) {
					xg6hchm1 += "	<div class='fl myfl' style='width:33.33%;'>" + "		<button class='btn3 lvbo'>"
							+ x + "</button><span>"+ odds(str1[i-1], odds)+"</span>" + "	</div>";
				}
			}
			String xg6hchm2 = "";
			for (int i = 1; i < 50; i++) {
				String x = i + "";
				if (Integer.parseInt(x) < 10) {
					x = "0" + i;
				}
				if (hb.contains(x)) {
					xg6hchm2 += "	<div class='fl myfl' style='width:33.33%;'>" + "		<button class='btn3 hb'>"
							+ x + "</button><span>"+ odds(str2[i-1], odds)+"</span>" + "	</div>";
				}
				if (lbo.contains(x)) {
					xg6hchm2 += "	<div class='fl myfl' style='width:33.33%;'>" + "		<button class='btn3 lbo'>"
							+ x + "</button><span>"+ odds(str2[i-1], odds)+"</span>" + "	</div>";
				}
				if (lvbo.contains(x)) {
					xg6hchm2 += "	<div class='fl myfl' style='width:33.33%;'>" + "		<button class='btn3 lvbo'>"
							+ x + "</button><span>"+ odds(str2[i-1], odds)+"</span>" + "	</div>";
				}
			}
			String hm101 = "";
			for (int i = 0; i < 10; i++) {
				String x = i + "";
				hm101 += "	<div class='fl myfl' style='width:33.33%;'>" + "		<button class='btn3 hb'>" + x
						+ "</button><span>"+ odds(str22[i], odds)+"</span>" + "	</div>";
			}
			String hm102 = "";
			for (int i = 0; i < 10; i++) {
				String x = i + "";
				hm102 += "	<div class='fl myfl' style='width:33.33%;'>" + "		<button class='btn3 hb'>" + x
						+ "</button><span>"+ odds(str23[i], odds)+"</span>" + "	</div>";
			}
			String hm103 = "";
			for (int i = 0; i < 10; i++) {
				String x = i + "";
				hm103 += "	<div class='fl myfl' style='width:33.33%;'>" + "		<button class='btn3 hb'>" + x
						+ "</button><span>"+ odds(str24[i], odds)+"</span>" + "	</div>";
			}
			String hm104 = "";
			for (int i = 0; i < 10; i++) {
				String x = i + "";
				hm104 += "	<div class='fl myfl' style='width:33.33%;'>" + "		<button class='btn3 hb'>" + x
						+ "</button><span>"+ odds(str25[i], odds)+"</span>" + "	</div>";
			}
			String txg6hcsx = "";
			for (int i = 0; i < sx.length; i++) {
				txg6hcsx += "	<div class='fl myfl' style='width:50%;'>" + "		<button class='btn2 '>" + sx[i]
						+ "</button>"+ "<span>" +  odds(str3[i], odds)  + "</span>	</div>";
			}
			String txg6hcsx11 = "";
			for (int i = 0; i < sx.length; i++) {
				txg6hcsx11 += "	<div class='fl myfl' style='width:50%;'>" + "		<button class='btn2 '>" + sx[i]
						+ "</button>"+ "<span>" +  odds(str15[i], odds)  + "</span>	</div>";
			}
			String txg6hcsx12 = "";
			for (int i = 0; i < sx.length; i++) {
				txg6hcsx12 += "	<div class='fl myfl' style='width:50%;'>" + "		<button class='btn2 '>" + sx[i]
						+ "</button>"+ "<span>" +  odds(str16[i], odds)  + "</span>	</div>";
			}
			String txg6hcsx13 = "";
			for (int i = 0; i < sx.length; i++) {
				txg6hcsx13 += "	<div class='fl myfl' style='width:50%;'>" + "		<button class='btn2 '>" + sx[i]
						+ "</button>"+ "<span>" +  odds(str17[i], odds)  + "</span>	</div>";
			}
			String txg6hcsx14 = "";
			for (int i = 0; i < sx.length; i++) {
				txg6hcsx14 += "	<div class='fl myfl' style='width:50%;'>" + "		<button class='btn2 '>" + sx[i]
						+ "</button>"+ "<span>" +  odds(str18[i], odds)  + "</span>	</div>";
			}
			String txg6hcsx15 = "";
			for (int i = 0; i < sx.length; i++) {
				txg6hcsx15 += "	<div class='fl myfl' style='width:50%;'>" + "		<button class='btn2 '>" + sx[i]
						+ "</button>"+ "<span>" +  odds(str19[i], odds)  + "</span>	</div>";
			}
			String txg6hcsx16 = "";
			for (int i = 0; i < sx.length; i++) {
				txg6hcsx16 += "	<div class='fl myfl' style='width:50%;'>" + "		<button class='btn2 '>" + sx[i]
						+ "</button>"+ "<span>" +  odds(str20[i], odds)  + "</span>	</div>";
			}
			String txg6hcsx17 = "";
			for (int i = 0; i < sx.length; i++) {
				txg6hcsx17 += "	<div class='fl myfl' style='width:50%;'>" + "		<button class='btn2 '>" + sx[i]
						+ "</button>"+ "<span>" +  odds(str21[i], odds)  + "</span>	</div>";
			}
			xiazhuqu += "" + "<a name='" + classxg6hc[0] + "'></a>" + "<div class='" + classxg6hc[0] + " wfdiv'>"
					+ "<div class='title'>" + xg6hc[0] + "</div>" + xg6hchm1 + "	<input class='temp' />" + "</div>"

					+ "<a name='" + classxg6hc[1] + "'></a>" + "<div class='" + classxg6hc[1] + " wfdiv'>"
					+ "<div class='title'>" + xg6hc[1] + "</div>" + xg6hchm2 + "	<input class='temp' />" + "</div>"

					+ "<a name='" + classxg6hc[2] + "'></a>" + "<div class='" + classxg6hc[2] + " wfdiv'>"
					+ "<div class='title'>" + xg6hc[2] + "</div>" + txg6hcsx
					+ "	<input class='temp' />" + "</div>"

					+ "<a name='" + classxg6hc[3] + "'></a>" + "<div class='" + classxg6hc[3] + " wfdiv'>"
					+ "<div class='title'>" + xg6hc[3] + "</div>" + "	<div class='col-xs-6'>"
					+ "		<button class='btn2 2'>单</button>" + "		<span>" + Double.parseDouble( odds(str4[0], odds))
					+ "</span>" + "	</div>" + "	<div class='col-xs-6'>" + "		<button class='btn2 2'>双</button>"
					+ "		<span>" + Double.parseDouble( odds(str4[1], odds)) + "</span>" + "	</div>" + "	<div class='col-xs-6'>"
					+ "		<button class='btn2 2'>大</button>" + "		<span>" + Double.parseDouble( odds(str4[2], odds))
					+ "</span>" + "	</div>" + "	<div class='col-xs-6'>" + "		<button class='btn2 2'>小</button>"
					+ "		<span>" + Double.parseDouble( odds(str4[3], odds)) + "</span>" + "	</div>" + "	<input class='temp' />"
					+ "</div>"

					+ "<a name='" + classxg6hc[4] + "'></a>" + "<div class='" + classxg6hc[4] + " wfdiv'>"
					+ "<div class='title'>" + xg6hc[4] + "</div>" + "	<div class='col-xs-6'>"
					+ "		<button class='btn2 2'>家肖</button>" + "		<span>" + Double.parseDouble( odds(str5[0], odds))
					+ "</span>" + "	</div>" + "	<div class='col-xs-6'>" + "		<button class='btn2 2'>野肖</button>"
					+ "		<span>" + Double.parseDouble( odds(str5[1], odds)) + "</span>" + "	</div>" + "	<div class='col-xs-6'>"
					+ "		<button class='btn2 2'>天肖</button>" + "		<span>" + Double.parseDouble( odds(str5[2], odds))
					+ "</span>" + "	</div>" + "	<div class='col-xs-6'>" + "		<button class='btn2 2'>地肖</button>"
					+ "		<span>" + Double.parseDouble( odds(str5[3], odds)) + "</span>" + "	</div>" + "	<input class='temp' />"
					+ "</div>"

					+ "<a name='" + classxg6hc[5] + "'></a>" + "<div class='" + classxg6hc[5] + " wfdiv'>"
					+ "<div class='title'>" + xg6hc[5] + "</div>" + "	<div class='col-xs-6'>"
					+ "		<button class='btn2 2'>0头</button>" + "		<span>" + Double.parseDouble( odds(str6[0], odds))
					+ "</span>" + "	</div>" + "	<div class='col-xs-6'>" + "		<button class='btn2 2'>1头</button>"
					+ "		<span>" + Double.parseDouble( odds(str6[1], odds) )+ "</span>" + "	</div>" + "	<div class='col-xs-6'>"
					+ "		<button class='btn2 2'>2头</button>" + "		<span>" + Double.parseDouble( odds(str6[2], odds))
					+ "</span>" + "	</div>" + "	<div class='col-xs-6'>" + "		<button class='btn2 2'>3头</button>"
					+ "		<span>" + Double.parseDouble( odds(str6[3], odds)) + "</span>" + "	</div>" + "	<div class='col-xs-6'>"
					+ "		<button class='btn2 2'>4头</button>" + "		<span>" + Double.parseDouble( odds(str6[4], odds))
					+ "</span>" + "	</div>" + "	<input class='temp' />" + "</div>"

					+ "<a name='" + classxg6hc[6] + "'></a>" + "<div class='" + classxg6hc[6] + " wfdiv'>"
					+ "<div class='title'>" + xg6hc[6] + "</div>" + "	<div class='col-xs-6'>"
					+ "		<button class='btn2 2'>0尾</button>" + "		<span>" + Double.parseDouble( odds(str7[0], odds))
					+ "</span>" + "	</div>" + "	<div class='col-xs-6'>" + "		<button class='btn2 2'>1尾</button>"
					+ "		<span>" + Double.parseDouble( odds(str7[1], odds) )+ "</span>" + "	</div>" + "	<div class='col-xs-6'>"
					+ "		<button class='btn2 2'>2尾</button>" + "		<span>" + Double.parseDouble( odds(str7[2], odds))
					+ "</span>" + "	</div>" + "	<div class='col-xs-6'>" + "		<button class='btn2 2'>3尾</button>"
					+ "		<span>" + Double.parseDouble( odds(str7[3], odds)) + "</span>" + "	</div>" + "	<div class='col-xs-6'>"
					+ "		<button class='btn2 2'>4尾</button>" + "		<span>" + Double.parseDouble( odds(str7[4], odds))
					+ "</span>" + "	</div>" + "	<div class='col-xs-6'>" + "		<button class='btn2 2'>5尾</button>"
					+ "		<span>" + Double.parseDouble( odds(str7[5], odds)) + "</span>" + "	</div>" + "	<div class='col-xs-6'>"
					+ "		<button class='btn2 2'>6尾</button>" + "		<span>" + Double.parseDouble( odds(str7[6], odds))
					+ "</span>" + "	</div>" + "	<div class='col-xs-6'>" + "		<button class='btn2 2'>7尾</button>"
					+ "		<span>" + Double.parseDouble( odds(str7[7], odds)) + "</span>" + "	</div>" + "	<div class='col-xs-6'>"
					+ "		<button class='btn2 2'>8尾</button>" + "		<span>" + Double.parseDouble( odds(str7[8], odds))
					+ "</span>" + "	</div>" + "	<div class='col-xs-6'>" + "		<button class='btn2 2'>9尾</button>"
					+ "		<span>" + Double.parseDouble( odds(str7[9], odds)) + "</span>" + "	</div>" + "	<div class='col-xs-6'>"
					+ "		<button class='btn2 2'>大</button>" + "		<span>" + Double.parseDouble( odds(str7[10], odds))
					+ "</span>" + "	</div>" + "	<div class='col-xs-6'>" + "		<button class='btn2 2'>小</button>"
					+ "		<span>" + Double.parseDouble( odds(str7[11], odds)) + "</span>" + "	</div>" + "	<div class='col-xs-6'>"
					+ "		<button class='btn2 2'>单</button>" + "		<span>" + Double.parseDouble( odds(str7[12], odds))
					+ "</span>" + "	</div>" + "	<div class='col-xs-6'>" + "		<button class='btn2 2'>双</button>"
					+ "		<span>" + Double.parseDouble( odds(str7[13], odds)) + "</span>" + "	</div>" + "	<input class='temp' />"
					+ "</div>"

					+ "<a name='" + classxg6hc[7] + "'></a>" + "<div class='" + classxg6hc[7] + " wfdiv'>"
					+ "<div class='title'>" + xg6hc[7] + "</div>" + "	<div class='col-xs-6'>"
					+ "		<button class='btn2 2'>金</button>" + "		<span>" + Double.parseDouble( odds(str8[0], odds))
					+ "</span>" + "	</div>" + "	<div class='col-xs-6'>" + "		<button class='btn2 2'>木</button>"
					+ "		<span>" + Double.parseDouble( odds(str8[1], odds)) + "</span>" + "	</div>" + "	<div class='col-xs-6'>"
					+ "		<button class='btn2 2'>水</button>" + "		<span>" + Double.parseDouble( odds(str8[2], odds))
					+ "</span>" + "	</div>" + "	<div class='col-xs-6'>" + "		<button class='btn2 2'>火</button>"
					+ "		<span>" + Double.parseDouble( odds(str8[3], odds)) + "</span>" + "	</div>" + "	<div class='col-xs-6'>"
					+ "		<button class='btn2 2'>土</button>" + "		<span>" + Double.parseDouble( odds(str8[4], odds))
					+ "</span>" + "	</div>" + "	<input class='temp' />" + "</div>"

					+ "<a name='" + classxg6hc[8] + "'></a>" + "<div class='" + classxg6hc[8] + " wfdiv'>"
					+ "<div class='title'>" + xg6hc[8] + "</div>" + "	<div class='col-xs-6'>"
					+ "		<button class='btn2 2'>单</button>" + "		<span>" + Double.parseDouble( odds(str9[0], odds))
					+ "</span>" + "	</div>" + "	<div class='col-xs-6'>" + "		<button class='btn2 2'>双</button>"
					+ "		<span>" + Double.parseDouble( odds(str9[1], odds)) + "</span>" + "	</div>" + "	<div class='col-xs-6'>"
					+ "		<button class='btn2 2'>大</button>" + "		<span>" + Double.parseDouble( odds(str9[2], odds))
					+ "</span>" + "	</div>" + "	<div class='col-xs-6'>" + "		<button class='btn2 2'>小</button>"
					+ "		<span>" + Double.parseDouble( odds(str9[3], odds)) + "</span>" + "	</div>" + "	<input class='temp' />"
					+ "</div>"

					+ "<a name='" + classxg6hc[9] + "'></a>" + "<div class='" + classxg6hc[9] + " wfdiv'>"
					+ "<div class='title'>" + xg6hc[9] + "</div>" + "	<div class='col-xs-6'>"
					+ "		<button class='btn2 2'>单</button>" + "		<span>" + Double.parseDouble( odds(str10[0], odds))
					+ "</span>" + "	</div>" + "	<div class='col-xs-6'>" + "		<button class='btn2 2'>双</button>"
					+ "		<span>" + Double.parseDouble( odds(str10[1], odds)) + "</span>" + "	</div>" + "	<div class='col-xs-6'>"
					+ "		<button class='btn2 2'>大</button>" + "		<span>" + Double.parseDouble( odds(str10[2], odds))
					+ "</span>" + "	</div>" + "	<div class='col-xs-6'>" + "		<button class='btn2 2'>小</button>"
					+ "		<span>" + Double.parseDouble( odds(str10[3], odds) )+ "</span>" + "	</div>" + "	<input class='temp' />"
					+ "</div>"

					+ "<a name='" + classxg6hc[10] + "' ></a>" + "<div  class='" + classxg6hc[10] + " wfdiv'>"
					+ "<div class='title'>" + xg6hc[10] + "</div>" + xg6hchm11
					+ "	<input class='temp' />" + "</div>"

					+ "<a   name='" + classxg6hc[11] + "'></a>" + "<div   class='" + classxg6hc[11] + " wfdiv'>"
					+ "<div class='title'>" + xg6hc[11] + " - 平二中二　赔率:" + Double.parseDouble( odds(str12[0], odds)) + "</div>"
					+ xg6hchm + "	<input class='temp' />" + "</div>" + "<div  class='" + classxg6hc[11] + " wfdiv'>"
					+ "<div class='title'>" + xg6hc[11] + " - 平三中三　赔率:" + Double.parseDouble( odds(str13[0], odds)) + "</div>"
					+ xg6hchm + "	<input class='temp' />" + "</div>" + "<div  class='" + classxg6hc[11] + " wfdiv'>"
					+ "<div class='title'>" + xg6hc[11] + " - 平三中二　赔率:" + Double.parseDouble( odds(str14[0], odds)) + "</div>"
					+ xg6hchm + "	<input class='temp' />" + "</div>"

					+ "<a  name='" + classxg6hc[12] + "'></a>" + "<div  class='" + classxg6hc[12] + " wfdiv'>"
					+ "<div class='title'>" + xg6hc[12] + " - 四肖中特</div>"
					+ txg6hcsx11 + "	<input class='temp' />" + "</div>" + "<div  class='" + classxg6hc[12] + " wfdiv'>"
					+ "<div class='title'>" + xg6hc[12] + " - 五肖中特</div>"
					+ txg6hcsx12 + "	<input class='temp' />" + "</div>" + "<div  class='" + classxg6hc[12] + " wfdiv'>"
					+ "<div class='title'>" + xg6hc[12] + " - 六肖中特</div>"
					+ txg6hcsx13 + "	<input class='temp' />" + "</div>"

					+ "<a   name='" + classxg6hc[13] + "'></a>" + "<div   class='" + classxg6hc[13] + " wfdiv'>"
					+ "<div class='title'>" + xg6hc[13] + " - 平特一肖</div>" + txg6hcsx14 + "	<input class='temp' />"
					+ "</div>" + "<div   class='" + classxg6hc[13] + " wfdiv'>" + "<div class='title'>" + xg6hc[13]
					+ " - 平特二肖　赔率:" + Double.parseDouble( odds(str19[0], odds)) + "</div>" + txg6hcsx15 + "	<input class='temp' />"
					+ "</div>" + "<div   class='" + classxg6hc[13] + " wfdiv'>" + "<div class='title'>" + xg6hc[13]
					+ " - 平特三肖　赔率:" + Double.parseDouble( odds(str20[0], odds)) + "</div>" + txg6hcsx16 + "	<input class='temp' />"
					+ "</div>" + "<div   class='" + classxg6hc[13] + " wfdiv'>" + "<div class='title'>" + xg6hc[13]
					+ " - 平特四肖　赔率:" + Double.parseDouble( odds(str21[0], odds)) + "</div>" + txg6hcsx17 + "	<input class='temp' />"
					+ "</div>"

					+ "<a   name='" + classxg6hc[14] + "'></a>" + "<div  class='" + classxg6hc[14] + " wfdiv'>"
					+ "<div class='title'>" + xg6hc[14] + " - 平特一尾</div>" + hm101 + "	<input class='temp' />"
					+ "</div>" + "<div  class='" + classxg6hc[14] + " wfdiv'>" + "<div class='title'>" + xg6hc[14]
					+ " - 平特二尾</div>" + hm102 + "	<input class='temp' />"
					+ "</div>" + "<div   class='" + classxg6hc[14] + " wfdiv'>" + "<div class='title'>" + xg6hc[14]
					+ " - 平特三尾</div>" + hm103 + "	<input class='temp' />"
					+ "</div>" + "<div   class='" + classxg6hc[14] + " wfdiv'>" + "<div class='title'>" + xg6hc[14]
					+ " - 平特四尾</div>" + hm104 + "	<input class='temp' />"
					+ "</div>"

					+ "<a name='" + classxg6hc[15] + "'></a>" + "<div class='" + classxg6hc[15] + " wfdiv'>"
					+ "<div class='title'>" + xg6hc[15] + " - 5不中　赔率:" + Double.parseDouble( odds(str26[0], odds)) + "</div>"
					+ xg6hchm + "	<input class='temp' />" + "</div>" + "<div class='" + classxg6hc[15] + " wfdiv'>"
					+ "<div class='title'>" + xg6hc[15] + " - 6不中　赔率:" + Double.parseDouble( odds(str27[0], odds) )+ "</div>"
					+ xg6hchm + "	<input class='temp' />" + "</div>" + "<div class='" + classxg6hc[15] + " wfdiv'>"
					+ "<div class='title'>" + xg6hc[15] + " - 7不中　赔率:" + Double.parseDouble( odds(str28[0], odds) )+ "</div>"
					+ xg6hchm + "	<input class='temp' />" + "</div>" + "<div class='" + classxg6hc[15] + " wfdiv'>"
					+ "<div class='title'>" + xg6hc[15] + " - 8不中　赔率:" + Double.parseDouble( odds(str29[0], odds)) + "</div>"
					+ xg6hchm + "	<input class='temp' />" + "</div>" + "<div class='" + classxg6hc[15] + " wfdiv'>"
					+ "<div class='title'>" + xg6hc[15] + " - 9不中　赔率:" + Double.parseDouble( odds(str30[0], odds) )+ "</div>"
					+ xg6hchm + "	<input class='temp' />" + "</div>" + "<div class='" + classxg6hc[15] + " wfdiv'>"
					+ "<div class='title'>" + xg6hc[15] + " - 10不中　赔率:" + Double.parseDouble( odds(str31[0], odds)) + "</div>"
					+ xg6hchm + "	<input class='temp' />" + "</div>" + "<div class='" + classxg6hc[15] + " wfdiv'>"
					+ "<div class='title'>" + xg6hc[15] + " - 11不中　赔率:" + Double.parseDouble( odds(str32[0], odds)) + "</div>"
					+ xg6hchm + "	<input class='temp' />" + "</div>" + "<div class='" + classxg6hc[15] + " wfdiv'>"
					+ "<div class='title'>" + xg6hc[15] + " - 12不中　赔率:" + Double.parseDouble( odds(str33[0], odds)) + "</div>"
					+ xg6hchm + "	<input class='temp' />" + "</div>" + "<div class='" + classxg6hc[15] + " wfdiv'>"
					+ "<div class='title'>" + xg6hc[15] + " - 13不中　赔率:" + Double.parseDouble( odds(str34[0], odds) )+ "</div>"
					+ xg6hchm + "	<input class='temp' />" + "</div>" + "<div class='" + classxg6hc[15] + " wfdiv'>"
					+ "<div class='title'>" + xg6hc[15] + " - 14不中　赔率:" + Double.parseDouble( odds(str35[0], odds) )+ "</div>"
					+ xg6hchm + "	<input class='temp' />" + "</div>" + "<div class='" + classxg6hc[15] + " wfdiv'>"
					+ "<div class='title'>" + xg6hc[15] + " - 15不中　赔率:" + Double.parseDouble( odds(str36[0], odds)) + "</div>"
					+ xg6hchm + "	<input class='temp' />" + "</div>"

					+ "<a name='" + classxg6hc[16] + "'></a>" + "<div class='" + classxg6hc[16] + " wfdiv'>"
					+ "<div class='title'>" + xg6hc[16] + "</div>" + "	<div class='col-xs-6'>"
					+ "		<button class='btn2 2'>2肖</button>" + "		<span>" + Double.parseDouble( odds(str37[0], odds))
					+ "</span>" + "	</div>" + "	<div class='col-xs-6'>" + "		<button class='btn2 2'>3肖</button>"
					+ "		<span>" + Double.parseDouble( odds(str37[1], odds)) + "</span>" + "	</div>" + "	<div class='col-xs-6'>"
					+ "		<button class='btn2 2'>4肖</button>" + "		<span>" + Double.parseDouble( odds(str37[2], odds))
					+ "</span>" + "	</div>" + "	<div class='col-xs-6'>" + "		<button class='btn2 2'>5肖</button>"
					+ "		<span>" + Double.parseDouble( odds(str37[3], odds)) + "</span>" + "	</div>" + "	<div class='col-xs-6'>"
					+ "		<button class='btn2 2'>6肖</button>" + "		<span>" + Double.parseDouble( odds(str37[4], odds))
					+ "</span>" + "	</div>" + "	<div class='col-xs-6'>" + "		<button class='btn2 2'>7肖</button>"
					+ "		<span>" + Double.parseDouble( odds(str37[5], odds)) + "</span>" + "	</div>" + "	<div class='col-xs-6'>"
					+ "		<button class='btn2 2'>单</button>" + "		<span>" + Double.parseDouble( odds(str37[6], odds))
					+ "</span>" + "	</div>" + "	<div class='col-xs-6'>" + "		<button class='btn2 2'>双</button>"
					+ "		<span>" + Double.parseDouble( odds(str37[7], odds)) + "</span>" + "	</div>" + "	<input class='temp' />"
					+ "</div>"

					+ "<a name='" + classxg6hc[17] + "'></a>" + "<div class='" + classxg6hc[17] + " wfdiv'>"
					+ "<div class='title'>" + xg6hc[17] + "</div>" + "	<div class='col-xs-6'>"
					+ "		<button class='btn2 2'>红波</button>" + "		<span>" + Double.parseDouble( odds(str38[0], odds))
					+ "</span>" + "	</div>" + "	<div class='col-xs-6'>" + "		<button class='btn2 2'>蓝波</button>"
					+ "		<span>" + Double.parseDouble( odds(str38[1], odds) )+ "</span>" + "	</div>" + "	<div class='col-xs-6'>"
					+ "		<button class='btn2 2'>绿波</button>" + "		<span>" + Double.parseDouble( odds(str38[2], odds))
					+ "</span>" + "	</div>" + "	<input class='temp' />" + "</div>"

					+ "<a name='" + classxg6hc[18] + "'></a>" + "<div class='" + classxg6hc[18] + " wfdiv'>"
					+ "<div class='title'>" + xg6hc[18] + "</div>" + "	<div class='col-xs-6'>"
					+ "		<button class='btn2 2'>红大</button>" + "		<span>" + Double.parseDouble( odds(str39[0], odds))
					+ "</span>" + "	</div>" + "	<div class='col-xs-6'>" + "		<button class='btn2 2'>红小</button>"
					+ "		<span>" + Double.parseDouble( odds(str39[1], odds) )+ "</span>" + "	</div>" + "	<div class='col-xs-6'>"
					+ "		<button class='btn2 2'>红单</button>" + "		<span>" + Double.parseDouble( odds(str39[2], odds))
					+ "</span>" + "	</div>" + "	<div class='col-xs-6'>" + "		<button class='btn2 2'>红双</button>"
					+ "		<span>" + Double.parseDouble( odds(str39[3], odds)) + "</span>" + "	</div>" + "	<div class='col-xs-6'>"
					+ "		<button class='btn2 2'>蓝大</button>" + "		<span>" + Double.parseDouble( odds(str39[4], odds))
					+ "</span>" + "	</div>" + "	<div class='col-xs-6'>" + "		<button class='btn2 2'>蓝小</button>"
					+ "		<span>" + Double.parseDouble( odds(str39[5], odds)) + "</span>" + "	</div>" + "	<div class='col-xs-6'>"
					+ "		<button class='btn2 2'>蓝单</button>" + "		<span>" + Double.parseDouble( odds(str39[6], odds))
					+ "</span>" + "	</div>" + "	<div class='col-xs-6'>" + "		<button class='btn2 2'>蓝双</button>"
					+ "		<span>" + Double.parseDouble( odds(str39[7], odds)) + "</span>" + "	</div>" + "	<div class='col-xs-6'>"
					+ "		<button class='btn2 2'>绿大</button>" + "		<span>" + Double.parseDouble( odds(str39[8], odds))
					+ "</span>" + "	</div>" + "	<div class='col-xs-6'>" + "		<button class='btn2 2'>绿小</button>"
					+ "		<span>" + Double.parseDouble( odds(str39[9], odds)) + "</span>" + "	</div>" + "	<div class='col-xs-6'>"
					+ "		<button class='btn2 2'>绿单</button>" + "		<span>" + Double.parseDouble( odds(str39[10], odds))
					+ "</span>" + "	</div>" + "	<div class='col-xs-6'>" + "		<button class='btn2 2'>绿双</button>"
					+ "		<span>" + Double.parseDouble( odds(str39[11], odds)) + "</span>" + "	</div>" + "	<input class='temp' />"
					+ "</div>"

					+ "<a name='" + classxg6hc[19] + "'></a>" + "<div class='" + classxg6hc[19] + " wfdiv'>"
					+ "<div class='title'>" + xg6hc[19] + "</div>" + "	<div class='col-xs-6'>"
					+ "		<button class='btn2 2'>红大单</button>" + "		<span>" + Double.parseDouble( odds(str40[0], odds))
					+ "</span>" + "	</div>" + "	<div class='col-xs-6'>" + "		<button class='btn2 2'>红大双</button>"
					+ "		<span>" + Double.parseDouble( odds(str40[1], odds)) + "</span>" + "	</div>" + "	<div class='col-xs-6'>"
					+ "		<button class='btn2 2'>红小单</button>" + "		<span>" + Double.parseDouble( odds(str40[2], odds))
					+ "</span>" + "	</div>" + "	<div class='col-xs-6'>" + "		<button class='btn2 2'>红小双</button>"
					+ "		<span>" + Double.parseDouble( odds(str40[3], odds)) + "</span>" + "	</div>" + "	<div class='col-xs-6'>"
					+ "		<button class='btn2 2'>蓝大单</button>" + "		<span>" + Double.parseDouble( odds(str40[4], odds))
					+ "</span>" + "	</div>" + "	<div class='col-xs-6'>" + "		<button class='btn2 2'>蓝大双</button>"
					+ "		<span>" + Double.parseDouble( odds(str40[5], odds)) + "</span>" + "	</div>" + "	<div class='col-xs-6'>"
					+ "		<button class='btn2 2'>蓝小单</button>" + "		<span>" + Double.parseDouble( odds(str40[6], odds))
					+ "</span>" + "	</div>" + "	<div class='col-xs-6'>" + "		<button class='btn2 2'>蓝小双</button>"
					+ "		<span>" + Double.parseDouble( odds(str40[7], odds) )+ "</span>" + "	</div>" + "	<div class='col-xs-6'>"
					+ "		<button class='btn2 2'>绿大单</button>" + "		<span>" + Double.parseDouble( odds(str40[8], odds))
					+ "</span>" + "	</div>" + "	<div class='col-xs-6'>" + "		<button class='btn2 2'>绿大双</button>"
					+ "		<span>" + Double.parseDouble( odds(str40[9], odds)) + "</span>" + "	</div>" + "	<div class='col-xs-6'>"
					+ "		<button class='btn2 2'>绿小单</button>" + "		<span>" + Double.parseDouble( odds(str40[10], odds))
					+ "</span>" + "	</div>" + "	<div class='col-xs-6'>" + "		<button class='btn2 2'>绿小双</button>"
					+ "		<span>" + Double.parseDouble( odds(str40[11], odds) )+ "</span>" + "	</div>" + "	<input class='temp' />"
					+ "</div>";
			//str += "</div></div>";
			break;
		default:
			break;
		}
		return xiazhuqu;
	}
	/**
	 * 返回当前彩种页面
	 * @param cname 彩种名
	 * @return
	 */
	public String lotPage(String cname) {
		if("bjl".equals(cname)) {//百家乐直接返回页面
			return page(cname);
		}
		LotterExample lotters = lotterService.getLotterByCname(cname);
		if(lotters == null){
			return "nullnull";
		}
		String lotterxiazhu = "<style type=\"text/css\">#span-i-xiazhuzonge{font-size:13px;} .qiu{margin-right:3px;color:white;width:22px;height:22px;line-height:22px;font-size:12px;display:inline-block;background: #E63131;} .btn2{background: none;border: 0;color: #009ac3;font-size: 15px;padding:3px 0px; border-radius:5px;} /**.btn2{background: none;border: 0;color: #fff;font-size: 15px;padding:3px 5px;border-radius:5px;}*/ .btn3{border:0px;border-radius:50px;padding:2px;width:26px;height:26px;line-height:20px;color: white;} .qiu0{background: #D8D21C!important;} .qiu1{background: #D8D21C!important;} .qiu2{background: #3273F9!important;} .qiu3{background: #515567!important;} .qiu4{background: #E6962D!important;} .qiu5{background: #0EC2C4!important;} .qiu6{background: #2D35D0!important;} .qiu7{background: #AEAFC5!important;} .qiu8{background: #E63131!important;} .qiu9{background: #7C1F1F!important;} .qiu10{background: #2DCC21!important;} .hb{background: #F02828;} .lbo{background: #336DCC;} .lvbo{background: #09B832;} .table1{margin-top: 5px;} .table1 tr td{height: 30px;padding:0 5px;font-size: 14px;} .ctr{color: ;font-weight: bold;} .xiazhu .title{background:#EFEFEF;padding: 8px;border-bottom: 1px solid silver;} .xiazhu .col-xs-6,.xiazhu .myfl{border: 1px solid #ECECEC ;padding: 5px;padding: 13px 0px;} .xiazhu .col-xs-6 button{margin-right: 20px;} .xiazhu .row{margin: 0px;} .xiazhu input{display:none;border:1px solid red;} .xiazhu span{color: gray;display: inline-block;min-width: 40px;font-size: 12px;} .xiazhu .act{background: url(\"/img/actbg.png\");background-size: 20px 20px;background-repeat: no-repeat;} .zdsd *{font-size: 14px;} .hemei input{text-align: center;}  *{font-size: 14px;} .wf a{background: #EFEFEF;color:black; width: 98%;text-align: center;padding:5px;display: block; display: -moz-box;border: 1px solid white;font-size: 12px;cursor: pointer;} .wf .acti{background: #02AECB;color: white;} .wfdiv:after { content: \".\"; display: block; height: 0; visibility: hidden; clear: both; } .clearfix:after { content: \".\"; display: block; height: 0; visibility: hidden; clear: both; } .modal-dialog { margin:10px 0!important; } .nav a{color:white;} #myModal .modal-dialog, #betSuccessModal .modal-dialog {margin: 0 auto!important;padding:10px;} .item .important{color:red;font-weight :bold;} .item .nickname{color:#099afe} .item,.item *{font-size:12px;} .item{padding-left:30px;} .nav>li>span { color:white; position: relative; display: block; padding: 10px 15px; } .wf {width:100px;overflow:auto;max-height:100%;-webkit-overflow-scrolling: touch;} .green{border-radius:10px; border:1px solid silver ;box-shadow: 2px 3px 1px silver;padding:10px;padding-left:10px; ;line-height:30px;margin-bottom: 20px;text-align: left;} .green{border-top:5px solid green;}  .span-item-circle { display: inline-flex; background: red; margin: 1px; border-radius: 50%; color: white; font-size: 0.33rem; width: 0.46rem; height: 0.46rem; justify-content:center; align-items:center; max-width:26px; max-height:26px; } .clearfix:after { content:\"\"; display:block; clear:both; } .modal-footer { padding:6px; text-align: center; } .modal-footer > button { width:80%; } .ul-c-betSuccessItem { padding: 10px; padding-left: 30px; line-height: 30px; margin-bottom: 20px; text-align: left; overflow: auto; } #betSuccessModal .modal-body { max-height:80vh; } #checkboxhm, #checkboxgd { width:20px; height:20px; } .zdsd.set { max-width:360px; left:50%!important; transform:translateX(-50%); margin:0!important; } .col-sm-4, .col-xs-12 { padding-left:0; padding-right:0; } .clearfix:after { content:\"\"; display:block; clear:both; } #djs .yuan, #djs .fakejiahao { font-weight:normal!important; } .nav>li>span:hover { background-color:#eee; } .xiazhu > div > div, #id-ul-xiaLaMenu > li > a, #id-ul-xiaLaMenu > li > span { cursor: pointer; } .xiazhu > div > .title { cursor: default; } .span-c-gendanWrapper, .span-c-hemaiWrapper { display:none; } .span-c-gendanWrapper.active, .span-c-hemaiWrapper.active { display:inline-flex; } .span-c-gendanWrapper, .span-c-hemaiWrapper { align-items:center; } #fenpan { z-index:20; } .nav>li>a:focus, .nav>li>a:hover, .nav>li>span:focus, .nav>li>span:hover { background-color:rgb(23,162,244)!important; } .col-xs-6:after, .col-xs-12, .wfdiv { content:\"\"; display:block; clear:both; } #kuaisuxuanze button{width: 16.5%;margin:0 1%;} </style>\r\n" + 
				"<div  style=\"display:none; padding:0;\">\r\n" + 
				"			<span id=\"id\" class=\"hidden\">"+lotters.getId()+"</span>\r\n" + 
				"			<span id=\"cplay1\" class=\"hidden\"></span>\r\n" + 
				"			<span id=\"cname1\" class=\"hidden\">"+lotters.getName() +"</span>\r\n" + 
				"			<span id=\"orderid\" class=\"hidden\"></span>\r\n" + 
				"			<span id=\"cname\" class=\"hidden\">"+lotters.getCname()+"</span>\r\n" + 
				"			<span class=\"timespace hidden\">"+lotters.getTimespace()+"</span>\r\n" + 
				"			<span id=\"lasttime\" class=\"lasttime hidden\">"+lotters.getLottertime()+"</span>\r\n" + 
				"			<span id=\"cplay\" class=\"hidden\">${key}</span>\r\n" + 
				"			<div class=\"\" style=\"background: url('/img/actbg.png');\"></div>\r\n" + 
				"		</div>\r\n" + 
				"			\r\n" + 
				"		<div   style=\"display:flex;flex-direction:column;height:100%;\" class=\"wapper clearfix\" id='lotter' > \r\n" + 
				"			<div id=\"id-div-headerNav\" class=\"col-xs-12 col-sm-4 col-sm-offset-4\" style=\"display:flex;justify-content:space-between;background-color:#059BF3;align-items:center;padding:0 10px;height:50px;position:fixed;z-index:4;\">\r\n" + 
				"				<a  class=\"glyphicon glyphicon-chevron-left \" onclick=\"backPage()\" style=\"color: white;margin-top:-4px;\"></a>\r\n" + 
				"				<div style=\"position:absolute;transform:translateX(-50%) translateY(-50%);left:50%;top:50%;\">\r\n" + 
				"					<div class='font12	' style=\"color:yellow; display: none;\">当期下注总额：<span id=\"span-i-xiazhuzonge\"></span></div>\r\n" + 
				"					<div style=\"color: white;font-weight: bold;font-size: 16px;text-align: center;\" class=\"CZname\" >"+lotters.getName()+"</div>\r\n" + 
				"				</div>\r\n" + 
				"				\r\n" + 
				"				<div style=\"display:flex;align-items:center;position:absolute;top:50%;transform:translateY(-50%);right:10px;\"class=\"user\">\r\n" + 
				"					<div style=\"color: white;display:flex;flex-direction:column;align-items:flex-end;margin-right:10px;line-height:14px;\">\r\n" + 
				"						<span style=\"font-size: 12px;\">余额</span>\r\n" + 
				"						<span style=\"font-size: 12px;\" id=\"balance\"></span>\r\n" + 
				"					</div>	\r\n" + 
				"					<i class=\"glyphicon glyphicon-menu-hamburger\" style=\"font-size:20px;color:white;cursor: pointer;\"></i>\r\n" + 
				"				</div>	\r\n" + 
				"	\r\n" + 
				"				<ul id=\"id-ul-xiaLaMenu\" class=\"nav hidden\" style=\"position: absolute;right:0px;top:100%;width:100px;text-align: center;z-index:100;background: rgb(23,162,244) ;border-radius:0; \">\r\n" + 
				"					<li class=\"GoToPage xiazhuJl\"><a id=\"a-i-xiazhuRecord\">下注记录</a></li>\r\n" + 
				"					<li class=\"GoToPage kaijiangJl\"><a id=\"a-i-lotterRecord\">开奖记录</a></li>\r\n" + 
				"					<li class=\"GoToPage zs\"> <span id=\"a-i-zoushitu\">走势图</span>\r\n" + 	
				"					<span id=\"cname\" class=\"hidden\">"+lotters.getCname()+"</span>\r\n" + 
				"					<li class=\"GoToPage help"+lotters.getCname()+"\"><a>购彩助手</a></li>\r\n" + 
				"					<li class=\"GoToPage wd\"><a >我的地盘</a></li>\r\n" + 
				"					<li class=\"exit\"><a >退出登录</a></li>\r\n" + 
				"				</ul>	\r\n" + 
				"			</div>\r\n" + 
				"			<div style=\"background-color:white;line-height:25px;padding:0 6px;top:50px;position: fixed;z-index:3;\"class=\"class-div-qiuGroups col-xs-12 col-sm-4 col-sm-offset-4\">\r\n" + 
				"				<p style=\"margin-bottom:0px;display:flex;align-items:center;flex-wrap:wrap;\"><span style=\"display:inline-block;min-width:64px;white-space: nowrap;font-size: 13px;\"><span style=\"font-size: 13px;\" class=\"period\">"+lotters.getPeriod()+"</span><span class=\"\">期：</span></span><span class=\"lotternumber\" style=\"display:flex;flex-grow:1;white-space: nowrap;\">"+lotters.getLotternumber()+"</span></p>\r\n" + 
				"				<p style=\"padding-top:4px;margin-bottom:0px;\"><span style=\"display:inline-block;min-width:64px;\"><span style=\"font-size: 13px;\" class=\"xiaqi\">"+lotters.getPeriod()+1+"</span><span class=\"\">期： </span></span><span id=\"djs\" style=\"font-size: 13px;font-weight: bold;\"></span></p>\r\n" + 
				"				<div title=\"1463\" class=\"kd-marquee kd-container\" style=\"max-width:100%;overflow:hidden; display: none;\">\r\n" + 
				"					<div id=\"test1\" class=\"inner\" >\r\n" + 
				"						<nobr style=\"display:block;\">\r\n" + 
				"						</nobr>\r\n" + 
				"					</div>\r\n" + 
				"				</div>				\r\n" + 
				"			</div>\r\n" + 
				"			<div style=\"display:flex;margin-bottom:54px;\" class=\"class-div-contentDiv col-xs-12 col-sm-4 col-sm-offset-4\">	\r\n" + 
				"					"+page(cname)+"\r\n" + //下注区
				"				<div class=\"clearfix xiazhu\" style=\"overflow:auto;-webkit-overflow-scrolling: touch;position:relative;z-index:2;text-align:center;\">\r\n" + 
				//"					<!-- 下注区 -->\r\n" + 
				//"						"+xiazhuqu +"\r\n" + 
				//"					<!-- 下注区 -->\r\n" + 
				"				</div>"+
				"			</div>\r\n" + 
				"			<div style=\"position: fixed;bottom:0;z-index:3;\" id=\"div-i-footer-hemai\" class=\"col-xs-12 col-sm-4 col-sm-offset-4\">\r\n" + 
				"				<div style=\"border-top:2px solid silver;padding:5px 10px;height: 54px;background: white;\" id=\"foot\" class=\"\">\r\n" + 
				"					<div class=\"\" style=\"padding: 0; float: left;\">\r\n" + 
				"						<div> <span style=\"margin-right:12px;\">单注金额</span><input maxlength=\"10\" id=\"dzje\" style=\"width:80px;border-radius: 1px;border: 1px solid silver ;font-size:20px;\" type=\"number\" value=\"2\" /></div>\r\n" + 
				"						<div class=\"font10\">已选 <span id=\"zhushu\" class=\"font10\" style=\"min-width:14px;display:inline-block;text-align:center;\">0</span>注，共计<span id=\"gongji\" style=\"min-width:14px;display:inline-block;text-align:center;\" class=\"font10\">0</span>元</div> \r\n" + 
				"					</div>\r\n" + 
				"					<div class=\"\" style=\"padding-top:4px;align-items:center;float: right;\">\r\n" + 
				"						<div class=\"\">\r\n" + 
				"							<a onclick=\"clear1()\" class=\"btn btn-sm\" style=\"background: #eb6066;color:white;border:1px solid #eb6066;padding: 5px 20px;font-size:14px;\">清空</a>\r\n" + 
				"							<a id=\"queding\" onclick=\"comit()\" class=\"btn btn-sm queren\" style=\"border:1px solid black;padding: 5px 20px;font-size:14px;\">确定</a>\r\n" + 
				"						</div>\r\n" + 
				"					</div>\r\n" + 
				"				</div>		\r\n" + 
				"			</div>\r\n" + 
				"			<div  class=\"col-xs-12 col-sm-4 col-sm-offset-4 hidden\" id=\"kuaisuxuanze\" style=\"position: fixed;bottom: 0;background: white;height: 40px;z-index:10;border-top:1px solid silver;padding-top:2px;\">\r\n" + 
				"				<button class=\"btn btn-default\"></button>\r\n" + 
				"				<button class=\"btn btn-default\"></button>\r\n" + 
				"				<button class=\"btn btn-default\"></button>\r\n" + 
				"				<button class=\"btn btn-default\"></button>\r\n" + 
				"				<button class=\"btn btn-default\"></button>\r\n" + 
				"			</div>\r\n" + 
				"		</div>\r\n" + 
				"	<div class=\"zdsd hidden\" style='position: absolute;top:0;left:0;width: 100%;height: 100%;z-index: 60;background:rgba(0,0,0,0.5) ;'>\r\n" + 
				"	</div>\r\n" + 
				"<!-- 模态框（Modal） -->\r\n" + 
				"<div class=\"modal fade\" id=\"myModal\" tabindex=\"-1\" role=\"dialog\" aria-labelledby=\"myModalLabel\" aria-hidden=\"true\">\r\n" + 
				"    <div class=\"modal-dialog\" style=\"width:90vw;max-width:600px;\">\r\n" + 
				"        <div class=\"modal-content\">\r\n" + 
				"            <div class=\"modal-header\">\r\n" + 
				"                <h4 class=\"modal-title\" id=\"myModalLabel\" style=\"text-align: center;letter-spacing: 3px;\">★"+lotters.getName()+"★</h4>\r\n" + 
				"            </div>\r\n" + 
				"            <div class=\"modal-body\" style=\"height:65vh;overflow:auto;\">\r\n" + 
				" 				\r\n" + 
				"            </div>\r\n" + 
				"            <div class=\"modal-footer\">\r\n" + 
				"                <button type=\"button\" class=\"btn btn-primary\" data-dismiss=\"modal\">关　闭</button>\r\n" + 
				"            </div>\r\n" + 
				"        </div><!-- /.modal-content -->\r\n" + 
				"    </div><!-- /.modal-dialog -->\r\n" + 
				"</div>\r\n" + 
				"<!-- /.modal -->	\r\n" + 
				"<!-- 模态框（Modal） -->\r\n" + 
				"<div class=\"modal fade\" id=\"betSuccessModal\" tabindex=\"-1\" role=\"dialog\" aria-labelledby=\"myModalLabel\" data-backdrop=\"static\" aria-hidden=\"true\">\r\n" + 
				"    <div class=\"modal-dialog\" style=\"max-height:60vh;\">\r\n" + 
				"        <div class=\"modal-content\" style=\"height:100%;\">\r\n" + 
				"            <div class=\"modal-header\">\r\n" + 
				"                <h4 style=\"text-align: center;font-weight:bold;\" class=\"modal-title\" id=\"myModalLabel\">下注成功！</h4>\r\n" + 
				"            </div>\r\n" + 
				"            <div class=\"modal-body\" style=\"overflow:auto;max-height:60vh;\">\r\n" + 
				"                <table class=\"table table-striped table-bordered table-hover\" style=\"overflow: auto;\">\r\n" + 
				"            		<tbody class=\"ul-c-betSuccessItem\">\r\n" + 
				"            			\r\n" + 
				"            		</tbody>\r\n" + 
				"            	</table>\r\n" + 
				"<!--             	<ul class=\"ul-c-betSuccessItem\">\r\n" + 
				"            	</ul> -->\r\n" + 
				"            </div>\r\n" + 
				"            <div class=\"modal-footer\">\r\n" + 
				"                <button style=\"\" type=\"button\" class=\"btn btn-primary\" data-dismiss=\"modal\">关闭</button>\r\n" + 
				"            </div>\r\n" + 
				"        </div><!-- /.modal-content -->\r\n" + 
				"    </div><!-- /.modal-dialog -->\r\n" + 
				"</div>\r\n" + 
				"<!-- /.modal -->\r\n" + 
				"	\r\n" + 
				"<div class=\"modal-div-fakeModal\" id=\"div-i-noticeGenDan\">\r\n" + 
				"	<div class=\"div-c-modalContent\">\r\n" + 
				"		<h3 class=\"fakemodal-title\"></h3>\r\n" + 
				"		<div class=\"fakemodal-content\"></div>\r\n" + 
				"		<div class=\"fakemodal-btnsGroup\"><button class=\"btn btn-default btn-class-closeFakeModal\">关闭</button></div>\r\n" + 
				"	</div>\r\n" + 
				"</div>		\r\n" + 
				"<div id='fenpan' class='hidden col-xs-12 col-sm-4 col-sm-offset-4' style='position: fixed;bottom:0px;background:rgba(200,200,200,0.8);height:54px;line-height:54px;font-size:30px;text-align:center;color:white;'>已封盘</div>"; 
				/*if(lotJs != null && PageController.open == 1) {
					return lotterxiazhu+lotJs;
				}
				lotJs = PageController.readTheFrontendCode("lotter");*/
				return lotterxiazhu+PageController.readTheFrontendCode("lotter");
	}
	
	public String page(String cname) {
		String str = "";
		switch (cname) {
		case "ahk3":
		case "gxk3":
		case "jsk3":
		case "bjk3":
		case "jlk3":
		case "2fk3":
		case "3fk3":
			// TODO 快3
			String wfk3[] = { "猜一个号", "三连号通选", "二同号复选", "二同号单选", "二不同号", "二不同号胆拖", "三同号通选", "三同号单选", "三不同号", "形态",
					"总和" };
			String wfclassk3[] = { "c1gh", "slhtx", "ethfx", "ethdx", "ebth", "ebthdt", "sthtx", "sthdx", "sbth", "xt",
					"zh6" };
			str = "<div><div class='wf'>";
			for (int i = 0; i < wfk3.length; i++) {
				str += "<a href='#" + wfclassk3[i] + "'>" + wfk3[i] + "</a>";
			}	
			str += "</div></div>";
			break;
		case "bj28":
		case "xy28":
		case "jnd28":
			// TODO 28
			String pc28[]= {"混合","特码","特码包三","波色","豹子"};
			String wfclasspc28[]= {"hunhe","tema","tmb3","teshe","baozi"};
			str="<div><div class='wf'>";
			for (int i = 0; i < pc28.length; i++) {
				str += "<a href='#" + wfclasspc28[i] + "'>" + pc28[i] + "</a>";
			}
			str+="</div>" + "</div>";
			break;
		case "gdkl10f":
		case "cqkl10f":
			// TODO 快乐10分
			String kl10f[] = { "首位数投", "首位红投", "二连直选", "二连组选", "前三直选", "前三组选", "快乐二", "快乐三", "快乐四", "快乐五" };
			String wfclasstkl10f[] = { "swst", "swht", "elzhx", "elzx", "q3zhx", "q3zx", "kl2", "kl3", "kl4", "kl5" };
			str = "<div><div class='wf'>";
			for (int i = 0; i < kl10f.length; i++) {
				str += "<a href='#" + wfclasstkl10f[i] + "'>" + kl10f[i] + "</a>";
			}
			str += "</div></div>";
			break;
		case "gd11x5":
		case "ah11x5":
		case "jx11x5":
		case "sd11x5":
		case "sh11x5":
			// TODO 11选5
			String wft11x5[] = { "第一球", "第二球", "第三球", "第四球", "第五球", "总　和", "标准玩法" };
			String wfclasst11x5[] = { "d1q", "d2q", "d3q", "d4q", "d5q", "zh", "bzwf" };
			str = "<div><div class='wf'>";
			for (int i = 0; i < wft11x5.length; i++) {
				str += "<a href='#" + wfclasst11x5[i] + "'>" + wft11x5[i] + "</a>";
			}
			str += "</div></div>";
			break;
		case "bjl":
			String strin = "<style type=\"text/css\"> header { background-color: black; color:white;} body { background-color: #003d38; } .site-background { background-image: url(/img/caizhong/bjl/bjlbg.png); max-height: 100%; max-width: 100%; opacity: 0.08; filter:alpha(opacity=8); position: fixed; top: 0; left: 0; bottom: 0; right: 0; }  header { display:flex; padding: 1vh 0; justify-content: center; position: relative;} .div-c-main { display: flex; height: 100vh; width: 100%; flex-direction: column; position: fixed; } .div-c-main > .div-c-tableList { flex-grow: 1; overflow: auto; padding: 3vh; margin-bottom: 10vh; -webkit-overflow-scrolling : touch; } .tableItem { background-repeat: no-repeat; background-size: cover; background-position: center center; color: white; width: 22vh; height: 20vh; position: absolute; transform: translateX(-50%) translateY(-50%); top: 50%; left: 50%; } .tableItem-wrapper:nth-child(1) .tableItem, .tableItem-wrapper:nth-child(2) .tableItem { background-image: url(/img/caizhong/bjl/bjlzm1.png); } .tableItem-wrapper:nth-child(3) .tableItem, .tableItem-wrapper:nth-child(4) .tableItem { background-image: url(/img/caizhong/bjl/bjlzm2.png); } .tableItem-wrapper:nth-child(5) .tableItem, .tableItem-wrapper:nth-child(6) .tableItem { background-image: url(/img/caizhong/bjl/bjlzm3.png); } .tableItem-wrapper { box-shadow: 0 0 5px rgba(0,0,0,.6), inset 0 0 4px rgba(255,255,255,.3); background-color: rgba(255,255,255,.08); width: 24vh; height: 24vh; position: relative; border-radius: 10px; } .tableItem-wrapper > .span-betMoney-text { background-color: #0173dd; border-radius: 100px; width: 80%; color: white; text-align: center; padding: 1vh 0; display: inline-block; z-index: 2; box-shadow: 0 2px 3px rgba(0,0,0,.3), inset 0 0 2px rgba(0,0,0,.3); border: 1px solid #cce6ff; position: absolute; top: 1vh; left: 50%; transform: translateX(-50%); } .tableItem > .span-s-tableNumber, .tableItem > p { color: #e4d68c; position: absolute; left: 50%; transform: translateX(-50%); bottom: 44%; } .tableItem > p { text-align: center; bottom: 7%; color: black; margin-bottom: 0; width: 100%; } .tableItem > p .span-c-roomTime { font-weight: bold; } .tableItem > p span:nth-child(1) { margin-right: 6px; } .tableItem > p span:nth-child(2) { color: #8b0000; } .div-c-tableList > div { float:left; margin-bottom:10px; width: 46%; } .div-c-tableList > div:nth-child(odd) { margin-left: 2.5%; margin-right: 2.5%; } .clearfix:after { content: \"\"; display: block; clear: both; } header > .roleBtn { position: absolute; display: inline-block; cursor:pointer; top: 50%; transform: translateY(-50%); right: 16px; padding: 0 4px; border-radius: 4px; border: 1px solid #1456be; box-shadow: 0 0 8px #1456be, inset 0 0 21px #1456be, inset 0 0 5px #1456be; background: -webkit-linear-gradient(top,#175586,#1a7bb7 58%,#5972fe 80%,#1456be); } header > .backBtn { position: absolute; top: 50%; transform: translateY(-50%); left:16px; padding: 1px 6px; border-radius: 4px; border: 1px solid #1456be; box-shadow: 0 0 8px #1456be, inset 0 0 21px #1456be, inset 0 0 5px #1456be; background: -webkit-linear-gradient(top,#175586,#1a7bb7 58%,#5972fe 80%,#1456be); } #id-div-noticeDiv { font-size: 3vh; } .tableItem-wrapper { cursor: pointer; } .noticeContentInner .main .title { position: relative; height: 30px; margin-top: 5px; padding-left: 15px; font-size: 14px; line-height: 30px; font-weight: 700; } .noticeContentInner .main .title span { margin-left: 10px; color: #fb0; } .noticeContentInner .space { text-indent:2rem; } .noticeContentInner .content { line-height: 1.8; font-size: 1.3rem; } .noticeContentInner .line { height: 10px; border-bottom: 1px solid #ddd; } .noticeContentInner .list { padding-bottom:10px; } .noticeContentInner .list div { position: relative; margin-top: 6px; padding-left: 20px; line-height: 1.5; font-size: 12px; } .noticeContentInner .list div::after { content: \" \"; position: absolute; top: 6px; left: 7px; display: block; width: 6px; height: 6px; border-radius: 50%; background: #aaa; } .noticeContentInner .red { color: #d32f2f; } .noticeContentInner .table { display: table; width: 100%; margin: 5px 0; border-spacing: 0; border-collapse: collapse; font-size: 12px; text-align: center; } .noticeContentInner .table>div:first-of-type { background: #f44336; font-size: 13px; color: #fff; } .noticeContentInner .table>div { display:table-row; } .noticeContentInner .table>div>div { display: table-cell; width: 50%; font-size:14px; line-height: 1.5; padding: 4px 5px; border: 1px solid #ddd; vertical-align: middle; word-wrap: break-word; word-break: break-all; } </style>\r\n" + 
					"	<div class='wapper' id='bjl'>\r\n" + 
					"		 <div class=\"site-background\"></div>\r\n" + 
					"		 <div id=\"id-div-noticeDiv\"></div>\r\n" + 
					"			<div class=\"div-c-main\">\r\n" + 
					"	 		<header class=\"clearfix\">\r\n" + 
					"	 			<button class=\"btn btn-primary backBtn\" onclick='backPage()'>返回</button>\r\n" + 
					"	 			<h4>百家乐</h4>\r\n" + 
					"	 			<span class=\"roleBtn\">规则说明</span>\r\n" + 
					"	 		</header>\r\n" + 
					"	 		<div class=\"div-c-tableList clearfix\">\r\n" + 
					"	 			<div class=\"tableItem-wrapper\" id=\"tableItem-wrapper1\">\r\n" + 
					"	 				<span class=\"span-betMoney-text\"></span>\r\n" + 
					"		 			<div class=\"tableItem\">\r\n" + 
					"		 				<span class=\"span-s-tableNumber\">001桌</span>\r\n" + 
					"		 				<p><span class=\"span-c-roomStatus\"></span><span class=\"span-c-roomTime\"></span></p>\r\n" + 
					"		 			</div>\r\n" + 
					"	 			</div>\r\n" + 
					"	 			<div class=\"tableItem-wrapper\" id=\"tableItem-wrapper2\">\r\n" + 
					"	 				<span class=\"span-betMoney-text\"></span>\r\n" + 
					"		 			<div class=\"tableItem\">\r\n" + 
					"		 				<span class=\"span-s-tableNumber\">002桌</span>\r\n" + 
					"		 				<p><span class=\"span-c-roomStatus\"></span><span class=\"span-c-roomTime\"></span></p>\r\n" + 
					"		 			</div>\r\n" + 
					"	 			</div>\r\n" + 
					"	 			<div class=\"tableItem-wrapper\" id=\"tableItem-wrapper3\">\r\n" + 
					"	 				<span class=\"span-betMoney-text\"></span>\r\n" + 
					"		 			<div class=\"tableItem\">\r\n" + 
					"		 				<span class=\"span-s-tableNumber\">003桌</span>\r\n" + 
					"		 				<p><span class=\"span-c-roomStatus\"></span><span class=\"span-c-roomTime\"></span></p>\r\n" + 
					"		 			</div>\r\n" + 
					"	 			</div>\r\n" + 
					"	 			<div class=\"tableItem-wrapper\" id=\"tableItem-wrapper4\">\r\n" + 
					"	 				<span class=\"span-betMoney-text\"></span>\r\n" + 
					"		 			<div class=\"tableItem\">\r\n" + 
					"		 				<span class=\"span-s-tableNumber\">004桌</span>\r\n" + 
					"		 				<p><span class=\"span-c-roomStatus\"></span><span class=\"span-c-roomTime\"></span></p>\r\n" + 
					"		 			</div>\r\n" + 
					"	 			</div>\r\n" + 
					"	 			<div class=\"tableItem-wrapper\" id=\"tableItem-wrapper5\">\r\n" + 
					"	 				<span class=\"span-betMoney-text\"></span>\r\n" + 
					"		 			<div class=\"tableItem\">\r\n" + 
					"		 				<span class=\"span-s-tableNumber\">005桌</span>\r\n" + 
					"		 				<p><span class=\"span-c-roomStatus\"></span><span class=\"span-c-roomTime\"></span></p>\r\n" + 
					"		 			</div>\r\n" + 
					"	 			</div>\r\n" + 
					"	 			<div class=\"tableItem-wrapper\" id=\"tableItem-wrapper6\">\r\n" + 
					"	 				<span class=\"span-betMoney-text\"></span>\r\n" + 
					"		 			<div class=\"tableItem\">\r\n" + 
					"		 				<span class=\"span-s-tableNumber\">006桌</span>\r\n" + 
					"		 				<p><span class=\"span-c-roomStatus\"></span><span class=\"span-c-roomTime\"></span></p>\r\n" + 
					"		 			</div>\r\n" + 
					"	 			</div>\r\n" + 
					"			</div> \r\n" + 
					"		</div>\r\n" + 
					"	</div>";
			String strin2 =  "<script type=\"text/javascript\">\r\n" + 
					"	$(\".backBtn\").on(\"click\", function(e) {\r\n" + 
					"		//window.location.href = \"/gc.do\"\r\n" + 
					"	})\r\n" + 
					"	$('.foot').hide()\r\n" + 
					"	$(\".roleBtn\").on(\"click\", function(e) {\r\n" + 
					"		var newRequest = {\r\n" + 
					"				url: \"/b/baccaratOdds.do\",\r\n" + 
					"				type: \"post\",\r\n" + 
					"				data: {},\r\n" + 
					"				success: function(data) {\r\n" + 
					"					var newData = JSON.parse(data)\r\n" + 
					"					var zhuang = newData.data.rebate1\r\n" + 
					"					var xian = newData.data.rebate2\r\n" + 
					"					var he = newData.data.rebate5\r\n" + 
					"					var zhuangdui = newData.data.rebate3\r\n" + 
					"					var xiandui = newData.data.rebate4\r\n" + 
					"					showAlertNotice(\"百家乐规则\", '<div class=\"title\">'+\r\n" + 
					"			'简介<span>INTRODUCTION</span></div>'+\r\n" + 
					"	'<div class=\"content space\">'+\r\n" + 
					"			'百家乐源起于意大利，简单的推理和快速运算是百家乐最大特点，因而从十九世纪即为广受欢迎的扑克游戏。</div>'+\r\n" + 
					"		'<div class=\"line\">'+\r\n" + 
					"			'&nbsp;</div>'+\r\n" + 
					"		'<div class=\"title\">'+\r\n" + 
					"		'	玩法<span>GAME INSTRUCTION</span></div>'+\r\n" + 
					"		'<div class=\"content\">'+\r\n" + 
					"		'	游戏使用8副扑克牌：</div>'+\r\n" + 
					"		'<div class=\"list\">'+\r\n" + 
					"		'	<div>'+\r\n" + 
					"		'		荷官会派出“庄家”和“闲家”两份牌。</div>'+\r\n" + 
					"		'	<div>'+\r\n" + 
					"			'A是1点，2到9的牌面即为点数，K、Q、J、10是0点，加起来等于10也当作是0点；总数9点或最接近9点的一家胜出。</div>'+\r\n" + 
					"		'	<div>'+\r\n" + 
					"				'当任何一家起手牌的点数总和为8或9，就称为“天生赢家”，牌局就算结束，双方不再补牌。</div>'+\r\n" + 
					"		'	<div>'+\r\n" + 
					"		'		您有5种下注选择：闲家、庄家、和局、庄对子、闲对子</div>'+\r\n" + 
					"		'	<div>'+\r\n" + 
					"		'		派完起手牌，将依补牌规则补1张牌。</div>'+\r\n" + 
					"		'</div>'+\r\n" + 
					"		'<div class=\"content\">'+\r\n" + 
					"			'补牌规则：</div>'+\r\n" + 
					"		'<div class=\"content red\">'+\r\n" + 
					"			'闲家：</div>'+\r\n" + 
					"	'<div class=\"table\">'+\r\n" + 
					"			'<div>'+\r\n" + 
					"				'<div>'+\r\n" + 
					"				'	起手牌点数总和</div>'+\r\n" + 
					"				'<div>'+\r\n" + 
					"				'	补牌规则</div>'+\r\n" + 
					"			'</div>'+\r\n" + 
					"			'<div>'+\r\n" + 
					"				'<div>'+\r\n" + 
					"				'	0</div>'+\r\n" + 
					"				'<div>'+\r\n" + 
					"				'	须补牌</div>'+\r\n" + 
					"			'</div>'+\r\n" + 
					"			'<div>'+\r\n" + 
					"				'<div>'+\r\n" + 
					"					'1</div>'+\r\n" + 
					"			'<div>'+\r\n" + 
					"					'须补牌</div>'+\r\n" + 
					"		'</div>'+\r\n" + 
					"			'<div>'+\r\n" + 
					"			'	<div>'+\r\n" + 
					"				'	2</div>'+\r\n" + 
					"				'<div>'+\r\n" + 
					"					'须补牌</div>'+\r\n" + 
					"		'</div>'+\r\n" + 
					"			'<div>'+\r\n" + 
					"				'<div>'+\r\n" + 
					"					'3</div>'+\r\n" + 
					"				'<div>'+\r\n" + 
					"					'须补牌</div>'+\r\n" + 
					"			'</div>'+\r\n" + 
					"			'<div>'+\r\n" + 
					"				'<div>'+\r\n" + 
					"				'4</div>'+\r\n" + 
					"				'<div>'+\r\n" + 
					"					'须补牌</div>'+\r\n" + 
					"			'</div>'+\r\n" + 
					"			'<div>'+\r\n" + 
					"				'<div>'+\r\n" + 
					"					'5</div>'+\r\n" + 
					"				'<div>'+\r\n" + 
					"					'须补牌</div>'+\r\n" + 
					"			'</div>'+\r\n" + 
					"			'<div>'+\r\n" + 
					"				'<div>'+\r\n" + 
					"				'6</div>'+\r\n" + 
					"				'<div>'+\r\n" + 
					"					'不须补牌</div>'+\r\n" + 
					"			'</div>'+\r\n" + 
					"			'<div>'+\r\n" + 
					"				'<div>'+\r\n" + 
					"					'7</div>'+\r\n" + 
					"				'<div>'+\r\n" + 
					"				'不须补牌</div>'+\r\n" + 
					"			'</div>'+\r\n" + 
					"			'<div>'+\r\n" + 
					"				'<div>'+\r\n" + 
					"				'8</div>'+\r\n" + 
					"				'<div>'+\r\n" + 
					"					'“天生赢家”</div>'+\r\n" + 
					"			'</div>'+\r\n" + 
					"			'<div>'+\r\n" + 
					"				'<div>'+\r\n" + 
					"					'9</div>'+\r\n" + 
					"				'<div>'+\r\n" + 
					"					'“天生赢家”</div>'+\r\n" + 
					"			'</div>'+\r\n" + 
					"		'</div>'+\r\n" + 
					"	'<div class=\"content red\">'+\r\n" + 
					"			'庄家：</div>'+\r\n" + 
					"		'<div class=\"table\">'+\r\n" + 
					"			'<div>'+\r\n" + 
					"				'<div>'+\r\n" + 
					"					'起手牌点数总和</div>'+\r\n" + 
					"			'<div>'+\r\n" + 
					"					'补牌规则</div>'+\r\n" + 
					"			'</div>'+\r\n" + 
					"			'<div>'+\r\n" + 
					"				'<div>'+\r\n" + 
					"					'0</div>'+\r\n" + 
					"			'<div>'+\r\n" + 
					"					'须补牌</div>'+\r\n" + 
					"			'</div>'+\r\n" + 
					"			'<div>'+\r\n" + 
					"				'<div>'+\r\n" + 
					"					'1</div>'+\r\n" + 
					"				'<div>'+\r\n" + 
					"					'须补牌</div>'+\r\n" + 
					"			'</div>'+\r\n" + 
					"			'<div>'+\r\n" + 
					"				'<div>'+\r\n" + 
					"					'2</div>'+\r\n" + 
					"			'<div>'+\r\n" + 
					"					'须补牌</div>'+\r\n" + 
					"			'</div>'+\r\n" + 
					"			'<div>'+\r\n" + 
					"				'<div>'+\r\n" + 
					"					'3</div>'+\r\n" + 
					"				'<div>'+\r\n" + 
					"					'当闲家补得第三张牌是8，不须补牌；其余则须补牌</div>'+\r\n" + 
					"			'</div>'+\r\n" + 
					"			'<div>'+\r\n" + 
					"				'<div>'+\r\n" + 
					"					'4</div>'+\r\n" + 
					"				'<div>'+\r\n" + 
					"					'当闲家补得第三张牌是0.1.8.9，不须补牌；其余则须补牌</div>'+\r\n" + 
					"			'</div>'+\r\n" + 
					"			'<div>'+\r\n" + 
					"				'<div>'+\r\n" + 
					"					'5</div>'+\r\n" + 
					"				'<div>'+\r\n" + 
					"					'当闲家补得第三张牌是0.1.2.3.8.9，不须补牌；其余则须补牌</div>'+\r\n" + 
					"			'</div>'+\r\n" + 
					"			'<div>'+\r\n" + 
					"				'<div>'+\r\n" + 
					"					'6</div>'+\r\n" + 
					"				'<div>'+\r\n" + 
					"					'当闲家补得第三张牌是0.1.2.3.4.5.8.9，不须补牌；其余则须补牌</div>'+\r\n" + 
					"			'</div>'+\r\n" + 
					"			'<div>'+\r\n" + 
					"				'<div>'+\r\n" + 
					"					'7</div>'+\r\n" + 
					"				'<div>'+\r\n" + 
					"					'不须补牌</div>'+\r\n" + 
					"			'</div>'+\r\n" + 
					"			'<div>'+\r\n" + 
					"				'<div>'+\r\n" + 
					"					'8</div>'+\r\n" + 
					"				'<div>'+\r\n" + 
					"					'“天生赢家”</div>'+\r\n" + 
					"			'</div>'+\r\n" + 
					"			'<div>'+\r\n" + 
					"				'<div>'+\r\n" + 
					"					'9</div>'+\r\n" + 
					"				'<div>'+\r\n" + 
					"					'“天生赢家”</div>'+\r\n" + 
					"			'</div>'+\r\n" + 
					"		'</div>'+\r\n" + 
					"		'<div class=\"content red\">'+\r\n" + 
					"			'闲家起手牌点数为6点或7点，闲家不须补牌 ，此条件下庄家起手牌点数为5或5点以下，庄家必须补第三张牌。</div>'+\r\n" + 
					"		'<div class=\"line\">'+\r\n" + 
					"			'&nbsp;</div>'+\r\n" + 
					"		'<div class=\"title\">'+\r\n" + 
					"			'派彩<span>PAYOFF</span></div>'+\r\n" + 
					"		'<div class=\"table\">'+\r\n" + 
					"			'<div>'+\r\n" + 
					"				'<div>'+\r\n" + 
					"					'下注组合</div>'+\r\n" + 
					"				'<div>'+\r\n" + 
					"					'赔率</div>'+\r\n" + 
					"			'</div>'+\r\n" + 
					"			'<div>'+\r\n" + 
					"				'<div>'+\r\n" + 
					"					'庄</div>'+\r\n" + 
					"				'<div id=\"e-Zhuang\">'+\r\n" + 
					"					'1 赔 ' + zhuang  + '</div>'+\r\n" + 
					"			'</div>'+\r\n" + 
					"			'<div>'+\r\n" + 
					"				'<div>'+\r\n" + 
					"					'闲</div>'+\r\n" + 
					"				'<div id=\"e-Xian\">'+\r\n" + 
					"					'1 赔 ' + xian + '</div>'+\r\n" + 
					"			'</div>'+\r\n" + 
					"			'<div>'+\r\n" + 
					"				'<div>'+\r\n" + 
					"					'和</div>'+\r\n" + 
					"				'<div id=\"e-He\">'+\r\n" + 
					"					'1 赔 ' + he + '</div>'+\r\n" + 
					"			'</div>'+\r\n" + 
					"			'<div>'+\r\n" + 
					"				'<div>'+\r\n" + 
					"					'庄对</div>'+\r\n" + 
					"				'<div id=\"e-ZhuangDui\">'+\r\n" + 
					"					'1 赔' + zhuangdui + '</div>'+\r\n" + 
					"			'</div>'+\r\n" + 
					"			'<div>'+\r\n" + 
					"				'<div>'+\r\n" + 
					"					'闲对</div>'+\r\n" + 
					"				'<div id=\"e-XianDui\">'+\r\n" + 
					"					'1 赔 ' + xiandui + '</div>'+\r\n" + 
					"			'</div>'+\r\n" + 
					"		'</div>'+\r\n" + 
					"		'<div class=\"list\">'+\r\n" + 
					"			'<div>'+\r\n" + 
					"				'和局时，“庄／闲”的下注将退回。</div>'+\r\n" + 
					"			'<div>'+\r\n" + 
					"				'庄对指庄的起手牌为同数字或英文字母。</div>'+\r\n" + 
					"			'<div>'+\r\n" + 
					"				'闲对指闲的起手牌为同数字或英文字母。</div>'+\r\n" + 
					"		'</div>', \"\")\r\n" + 
					"				},\r\n" + 
					"				error: function(status) {\r\n" + 
					"					setNoticeDivHTML(\"网络繁忙\")\r\n" + 
					"				}\r\n" + 
					"			}\r\n" + 
					"		ajax(newRequest)\r\n" + 
					"		\r\n" + 
					"	})\r\n" + 
					"	var TABLE_NUMBER_OBJECT = {\r\n" + 
					"			\"1\": \"\",\r\n" + 
					"			\"2\": \"2\",\r\n" + 
					"			\"3\": \"3\",\r\n" + 
					"			\"4\": \"4\",\r\n" + 
					"			\"5\": \"5\",\r\n" + 
					"			\"6\": \"6\",\r\n" + 
					"	}\r\n" + 
					"	   \r\n" + 
					"	   var setAllTableData = function(arr) {\r\n" + 
					"		   console.log(arr,'arr')\r\n" + 
					"		   var allTableDivs = document.querySelectorAll(\".tableItem-wrapper\")\r\n" + 
					"		   for (var i = 0; i < allTableDivs.length; i++) {\r\n" + 
					"			   var item = allTableDivs[i]\r\n" + 
					"			   var dataItem = arr[i]\r\n" + 
					"			   var minValue = formatString2SimpleString(dataItem.minimumSum)\r\n" + 
					"			   var maxValue = formatString2SimpleString(dataItem.maximumAmount)\r\n" + 
					"			   var spanElement = item.querySelector(\".span-betMoney-text\")\r\n" + 
					"			   spanElement.innerHTML = minValue + \"-\" + maxValue\r\n" + 
					"			   item.dataset.roomid = dataItem.tableNumber\r\n" + 
					"			   item.dataset.max = dataItem.minimumSum\r\n" + 
					"			   item.dataset.min = dataItem.maximumAmount\r\n" + 
					"			   item.dataset.index = (i + 1)\r\n" + 
					"		   }\r\n" + 
					"	   } \r\n" + 
					"	   \r\n" + 
					"	   // 35 ~ 0\r\n" + 
					"	   // 20 秒下注 15秒发牌\r\n" + 
					"	   \r\n" + 
					"	   var autoUpdateStausAndTime = function(parentDiv, time) {\r\n" + 
					"				if($('#bjl').length==0){\r\n" +
					"					return;\r\n" +
					"				}\r\n" +
					"		   var statusSpan = parentDiv.querySelector(\".span-c-roomStatus\")\r\n" + 
					"		   var timeSpan = parentDiv.querySelector(\".span-c-roomTime\")\r\n" + 
					"		  var fapai= setInterval(function() {\r\n" + 
					"				if($('#bjl').length==0){\r\n" +
					"					clearInterval(fapai)\r\n" +
					"					return;\r\n" +
					"				}\r\n" +
					"			   if (time == 0) {\r\n" + 
					"  				var urlPath = \"/b/bjlLotter.do\"\r\n" + 
					"					var newRequest = {\r\n" + 
					"						url: urlPath,\r\n" + 
					"						type: \"post\",\r\n" + 
					"						data: {\r\n" + 
					"							tableNumber: parentDiv.dataset.roomid\r\n" + 
					"						},\r\n" + 
					"						success: function(data) {\r\n" + 
					"							var newData = JSON.parse(data)\r\n" + 
					"							console.log(newData,'newData的值')\r\n" + 
					"							if(newData.data == null){\r\n" + 
					"								return;\r\n" + 
					"							}\r\n" + 
					"							var curTime=new Date(newData.message).getTime(); //当前系统毫秒时间\r\n" + 
					"							var nextTime=new Date(newData.data.nextTime).getTime();//下棋开奖时间\r\n" + 
					"							var daojishi =(nextTime-curTime)/1000;  //倒计时时间\r\n" + 
					"							time = daojishi\r\n" + 
					"					},\r\n" + 
					"				}\r\n" + 
					"			ajax(newRequest)		   \r\n" + 
					"			   }\r\n" + 
					"			   if (time> 15) {\r\n" + 
					"				   statusSpan.innerHTML = \"下注中\"\r\n" + 
					"				   timeSpan.innerHTML = time - 15 \r\n" + 
					"				   time = time - 1\r\n" + 
					"			   }\r\n" + 
					"			   else if (time > 0) {\r\n" + 
					"				   statusSpan.innerHTML = \"开牌中\"\r\n" + 
					"				   timeSpan.innerHTML = time\r\n" + 
					"				   time = time - 1\r\n" + 
					"			   }\r\n" + 
					"		   }, 1000)\r\n" + 
					"	   }\r\n" + 
					"	   \r\n" + 
					"	   var getAllTableTime = function() {\r\n" + 
					"  			var urlPath = \"/b/bjlRoom.do\"\r\n" + 
					"				var newRequest = {\r\n" + 
					"					url: urlPath,\r\n" + 
					"					type: \"post\",\r\n" + 
					"					data: {\r\n" + 
					"					},\r\n" + 
					"					success: function(data) {\r\n" + 
					"						var newData = JSON.parse(data)\r\n" + 
					"						console.log(newData,'newData的值')\r\n" + 
					"						if(newData.data == null){\r\n" + 
					"						layer.open({\r\n" + 
					"			   				 type: 1,\r\n" + 
					"			   				 area:['300px',\"150px\"],\r\n" + 
					"			    			title:'温馨提示',\r\n" + 
					"			    			shadeClose: false, //点击遮罩关闭\r\n" + 
					"			   				 anim: 4,\r\n" + 
					"			   				 content: '该页面正在维护中...请稍后再试',    //右边也可以自己定义样式，引用时最外面的那个id,如$(\"#\"+\"ID名\")\r\n" + 
					"			   				 btn:'知道了',\r\n" + 
					"							yes:function(layero,index){\r\n" +
					"								layer.close(layer.index)\r\n" +
					"								save.push('gc')\r\n" +
					"								bindSetData('gc')\r\n" +
					"							},\r\n" +
					"							cancel:function(layero,index){\r\n" +
					"								layer.close(layer.index)\r\n" +
					"								save.push('gc')\r\n" +
					"								bindSetData('gc')\r\n" +
					"							},\r\n" +
					"			 			 });\r\n" +
					"							return;\r\n" +
					"						}\r\n" + 
					"						for(var i =0;i<newData.data.length;i++){\r\n" + 
					"							console.log(i,'i的值')\r\n" + 
					"							var curTime=new Date(newData.message).getTime(); //当前系统毫秒时间 \r\n" + 
					"							var nextTime=new Date(newData.data[i].nextTime).getTime();//下棋开奖时间 \r\n" + 
					"							var daojishi =(nextTime-curTime)/1000;  //倒计时时间 \r\n" + 
					"							var Room = document.querySelector(\"#tableItem-wrapper\"+(i+1)) \r\n" + 
					"							console.log(Room,'Room')\r\n" + 
					"							autoUpdateStausAndTime(Room, daojishi) \r\n" + 
					"						}\r\n" + 
					"					},\r\n" + 
					"				}\r\n" + 
					"			ajax(newRequest)		   \r\n" + 
					"	   }\r\n" + 
					"	    \r\n" + 
					"	   var getAllTableData = function() {\r\n" + 
					"   			var urlPath = \"/b/tableNumber.do\" \r\n" + 
					"				var newRequest = {\r\n" + 
					"					url: urlPath,\r\n" + 
					"					type: \"post\",\r\n" + 
					"					data: {},\r\n" + 
					"					success: function(data) {\r\n" + 
					"						var newData = JSON.parse(data)\r\n" + 
					"					console.log(newData,'newData')\r\n" + 
					"						setAllTableData(newData.data)\r\n" + 
					"						//for (var i = 1; i < 7; i++) {\r\n" + 
					"						getAllTableTime(document.querySelector(\"#tableItem-wrapper1\"))\r\n" + 
					"						//}\r\n" + 
					"					},\r\n" + 
					"					error: function(status) {\r\n" + 
					"						console.log(\"status\", status)\r\n" + 
					"					}\r\n" + 
					"				}\r\n" + 
					"			ajax(newRequest)\r\n" + 
					"	   }\r\n" + 
					"	   \r\n" + 
					"	   var bindAllCickEvent = function() {\r\n" + 
					"		   var allDivs = document.querySelectorAll(\".tableItem-wrapper\")\r\n" + 
					"		   for (var i = 0; i < allDivs.length; i++) {\r\n" + 
					"			   var item =allDivs[i]\r\n" + 
					"			   item.addEventListener(\"click\", function(event) {\r\n" + 
					"					console.log($(this).attr('data-roomid'),'房间号的id')\r\n" + 
					"					localStorage.setItem('roomId',$(this).attr('data-roomid'))\r\n" +
					"				   var urlPath =\"/b/Money.do\"\r\n" + 
					"						var newRequest = {\r\n" + 
					"							url: urlPath,\r\n" + 
					"							type: \"post\",\r\n" + 
					"							data: {	},\r\n" + 
					"							success: function(data) {\r\n" + 
					"								var newData = JSON.parse(data)\r\n" + 
					"								var currentMoney = parseFloat(newData.data)\r\n" + 
					"								var parentDiv = $(event.target).closest(\".tableItem-wrapper\")[0]\r\n" + 
					"								var maxValue = parseFloat(parentDiv.dataset.max)\r\n" + 
					"								var minValue = parseFloat(parentDiv.dataset.min)\r\n" + 
					"								console.log(maxValue,minValue,currentMoney)\r\n" + 
					"								clearInterval(daojishi2)\r\n" + 
					"								if(error.indexOf('bjllot')!=-1){\r\n" + 
					"									maintenance()\r\n" + 
					"									return;\r\n" + 
					"								}\r\n" + 
					" 								save.push('bjl')\r\n" + 
					" 								bindSetData('bjllot')\r\n" +
					"							},\r\n" + 
					"							error: function(status) {\r\n" + 
					"							}\r\n" + 
					"						}\r\n" + 
					"					ajax(newRequest)\r\n" + 
					"			   })\r\n" + 
					"		   }\r\n" + 
					"	   }\r\n" + 
					"\r\n" + 
					"	   var __main = function() {\r\n" + 
					"	      getAllTableData()\r\n" + 
					"	      bindAllCickEvent()\r\n" + 
					"	   }\r\n" + 
					"	   \r\n" + 
					"	   __main()\r\n" + 
					"	</script>";
			return strin+strin2;
		case "klpk":
			// TODO 快乐扑克
			str = "<div>" + "	<div class='wf'>" + "		<span>包　选</span>" + "		<div>"
					+ "			<button class='wfbtn hidden bx'>包选</button>" + "		</div>" + "	</div>"
					+ "	<div class='wf'>" + "		<span>任　选</span>" + "		<div>"
					+ "			<button class='wfbtn hidden rx1'>任选一</button>"
					+ "			<button class='wfbtn hidden rx2'>任选二</button>"
					+ "			<button class='wfbtn hidden rx3'>任选三</button>"
					+ "			<button class='wfbtn hidden rx4'>任选四</button>"
					+ "			<button class='wfbtn hidden rx5'>任选五</button>"
					+ "			<button class='wfbtn hidden rx6'>任选六</button>" + "		</div>" + "	</div>"
					+ "	<div class='wf'>" + "		<span>单　选</span>" + "		<div>"
					+ "			<button class='wfbtn hidden th'>同花</button>"
					+ "			<button class='wfbtn hidden sz'>顺子</button>"
					+ "			<button class='wfbtn hidden bz'>豹子</button><br>"
					+ "			<button class='wfbtn hidden dz'>对子</button>"
					+ "			<button class='wfbtn hidden ths'>同花顺</button>" + "		</div>" + "	</div>" + "</div>";
		case "cqssc":
		case "tjssc":
		case "xjssc":
		case "2fssc":
			// TODO 时时彩
			String wf1[] = { "总　和", "第一球", "第二球", "第三球", "第四球", "第五球", "前　三", "中　三", "后　三", "连　码" };
			String wfclass1[] = { "zh", "d1q", "d2q", "d3q", "d4q", "d5q", "q3", "z3", "h3", "lm" };
			str = "<div><div class='wf'>";
			for (int i = 0; i < wf1.length; i++) {
				str += "<a href='#" + wfclass1[i] + "'>" + wf1[i] + "</a>";
			}
			str += "</div></div>";
			break;
		case "bjpk10":
		case "2fpk10":
		case "2fft":
		case "xyft":
		case "xysm":
			String wf[] = { "冠亚和值", "冠　军", "亚　军", "第三名", "第四名", "第五名", "第六名", "第七名", "第八名", "第九名", "第十名" };
			String wfclass[] = { "gyhz", "gj", "yj", "d3m", "d4m", "d5m", "d6m", "d7m", "d8m", "d9m", "d10m" };
			/** 波色-红波-蓝波-绿波 */
			str = "<div><div class='wf'>";
			for (int i = 0; i < wf.length; i++) {
				str += "<a href='#" + wfclass[i] + "'>" + wf[i] + "</a>";
			}
			str += "</div></div>";
			break;
		case "shssl":
		case "pl3":
		case "fc3d":
			// TODO 时时乐 排列三 福彩3D
			String wffc3d[] = { "前二直选", "前二组选", "后二直选", "后二组选", "三星直选", "三星和值", "三星组三", "组三和值", "三星组六", "组六和值" };
			String wfclass1fc3d[] = { "q2zhx", "q2zx", "h2zhx", "h2zx", "3xzhx", "3xhzh", "3xz3", "z3hzh", "3xz6",
					"z6hzh" };
			str = "<div><div class='wf'>";
			for (int i = 0; i < wfclass1fc3d.length; i++) {
				str += "<a href='#" + wfclass1fc3d[i] + "'>" + wffc3d[i] + "</a>";
			}
			str += "</div></div>";
			break;
		case "xg6hc":
		case "5f6hc":
			// TODO 香港六合彩
			String xg6hc[] = { "特码A", "特码B", "特码生肖", "大小单双", "家禽野兽", "头数", "尾数", "五行", "总和", "合数", "独平", "平码", "定肖中特",
					"平特肖", "平特尾", "平特不中", "总肖", "色波", "半波", "半半波" };
			String classxg6hc[] = { "tma", "tmb", "tmsx", "dxds", "jqys", "ts", "ws", "wx", "zh", "hs", "dp", "pm",
					"dxzt", "ptx", "ptw", "ptbz", "zx", "sb", "bb", "bbb" };

			str = "<div><div class='wf'>";
			for (int i = 0; i < xg6hc.length; i++) {
				str += "<a href='#" + classxg6hc[i] + "'>" + xg6hc[i] + "</a>";
			}
			str += "</div></div>";
			break;
		default:
			break;
		}
		return str;
	
	}
	
}
