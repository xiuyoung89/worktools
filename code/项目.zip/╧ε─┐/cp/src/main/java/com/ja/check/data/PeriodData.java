package com.ja.check.data;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Timer;
import java.util.TimerTask;

import org.springframework.web.context.ContextLoader;

import com.alibaba.druid.util.StringUtils;
import com.ja.check.datas.Publicmethods;
import com.ja.domain.Data;
import com.ja.sevice.IDataService;
import com.ja.util.DateUtil;

/**
 * @DESC: 针对每一彩种生成当天的期数数据（时间均为北京时间）
 * @AUTH: qhzh
 * @DATE: 2018年8月21日 下午2:26:19
 */
public class PeriodData {

	private IDataService dataService =  (IDataService) ContextLoader.getCurrentWebApplicationContext()
			.getBean("dataService");
	
	private  Publicmethods publicmethods = new Publicmethods();
	
	private LocalDateTime firstPeriodOpenTime;
	
	private String latestPeriod;
	

	/**
	 * 彩票名称： 重庆快乐十分（幸运农场）
	 * 开奖时间： 开奖时间 早上00:21:45 到晚上  23:41:45   中途009期也就是 03:01:45的时候 要到早上 07:21:45才继续010期  一天59期  每期20分钟
	 * 每日期数： 001～059（00:21:45分开第一期）
	 * 开奖频率：每20分钟
	 * 期数特征：期数按天连续
	 */
	public void initCQKL10F() {
		/**生成期号时使用*/
		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
		/**时间转换的时候使用*/
		SimpleDateFormat sdf1 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		/**拼接时间时使用*/
		SimpleDateFormat sdf2 = new SimpleDateFormat("yyyy-MM-dd");
		List<Data> list =  new ArrayList<Data>();
		Integer currPeriod = 1;
		/*查询是否有昨天的数据*/
		Data da = publicmethods.pueryCurrentPeriod("cqkl10f",DateUtil.findLatelyDate(-1).replace("-", "")+"059");
		/*生成上一期的数据*/
		if(da == null) {
			Data data = new Data();
			data.setCname("cqkl10f");
			data.setGameNameInChinese("重庆快乐10分");
			data.setPeriod(DateUtil.findLatelyDate(-1).replace("-", "")+"059");
			data.setOpenTime(DateUtil.findLatelyDate(-1)+" 23:41:45");
			data.setNextperiod(sdf.format(new Date())+"001");
			SimpleDateFormat sft = new SimpleDateFormat("yyyy-MM-dd");
			data.setNextStopOrderTimeEpoch(sft.format(new Date())+" 00:19:00");
			dataService.insert(data);
		}
		//查询数据库是否有今天的数据 在生成数据
		String period = sdf.format(new Date())+"001";
		Data data = publicmethods.pueryCurrentPeriod("cqkl10f", period);
		//今天开奖的第一期时间
		String time = sdf2.format(new Date())+" 00:19:00";
		//如果数据库为null则今天还没有生成数据
		if(data == null) {
			//查询当前彩种最后一条数据
			for(int i = 0;i<59;i++) {
				Data d = new Data();
				d.setCname("cqkl10f");//彩种名
				d.setGameNameInChinese("重庆快乐十分");//彩种中文名
				d.setType(0); //彩种类型 0 是国彩  1是系统彩
				d.setStatus(0);//开奖状态
				Calendar calendar = Calendar.getInstance();
				try {calendar.setTime(sdf1.parse(time));} catch (ParseException e) {}
				if(i!=9) {
					calendar.add(Calendar.MINUTE, +20);
				}
				if(i != 58){
					/** 当期号小于10要两个00 大于10则只需要一个0*/
					if(currPeriod < 10) {
						d.setPeriod(sdf.format(new Date())+"00"+currPeriod);//当期开奖期号
						/**当下期期号大于等于10则走if 否则走else */
						if(currPeriod+1 >= 10) {
							d.setNextperiod(sdf.format(new Date())+"0"+(currPeriod+1));//下期开奖期号
						}else {
							d.setNextperiod(sdf.format(new Date())+"00"+(currPeriod+1));//下期开奖期号
						}
					}else {
						d.setPeriod(sdf.format(new Date())+"0"+currPeriod);//当期开奖期号
						d.setNextperiod(sdf.format(new Date())+"0"+(currPeriod+1));//下期开奖期号
					}
					/**当下标到8的时候  开奖时间已经到了07:19:00所以需要判断一下*/
					if(i==9) {
						d.setOpenTime(sdf2.format(new Date())+" 07:19:00");//当期开奖时间
						Calendar cal = Calendar.getInstance();
						try {
							cal.setTime(sdf1.parse(sdf2.format(new Date())+" 07:19:00"));
							cal.add(Calendar.MINUTE, +20);
						} catch (ParseException e) {
							e.printStackTrace();
						}
						d.setNextStopOrderTimeEpoch(sdf1.format(cal.getTime()));//下期开奖时间
						time = sdf1.format(cal.getTime());
					}else {
						d.setOpenTime(time);
						/**当下标到7的时候 下期开奖时间应该是07:19:00*/
						if(i==8) {
							d.setNextStopOrderTimeEpoch(sdf2.format(new Date())+" 07:19:00");//下期开奖时间
						}else {
							d.setNextStopOrderTimeEpoch(sdf1.format(calendar.getTime()));//下期开奖时间
						}
					}
					currPeriod++;
				}else if(i == 58) {
					d.setPeriod(sdf.format(new Date())+"0"+currPeriod);//当期开奖期号
					String nextPeriod = DateUtil.findLatelyDate(+1).replaceAll("-", "")+"001";
					d.setNextperiod(nextPeriod.trim());//下期开奖期号
					d.setOpenTime(time);//当期开奖时间
					d.setNextStopOrderTimeEpoch(DateUtil.findLatelyDate(+1)+" 00:19:00");//下期开奖时间
					currPeriod++;
				}
				if(i != 9) {
					time = sdf1.format(calendar.getTime());
				}
				list.add(d);
			}
			//将生成出来的数据保存到数据库
			dataService.insertByBatch(list);
		}
	}

	/**
	 * 彩票名称： 重庆时时彩
	 * 开奖时间： 开奖时间  早上00:30 到晚上  23:50   每20分钟开一期  一天59期
	 * 每日期数： 001~059(0:05开第一期)
	 * 开奖频率：每20分钟开一期
	 * 期数特征：期数按天连续
	 */
	/*public void initCQSSC() {
		*//**生成期号时使用*//*
		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
		*//**时间转换的时候使用*//*
		SimpleDateFormat sdf1 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		*//**拼接时间时使用*//*
		SimpleDateFormat sdf2 = new SimpleDateFormat("yyyy-MM-dd");
		List<Data> list =  new ArrayList<Data>();
		Integer currPeriod = 1;
		查询是否有昨天的数据
		Data da = publicmethods.pueryCurrentPeriod("cqssc", String.valueOf(DateUtil.findLatelyDate(-1).replace("-", "")+"059"));
		生成上一期的数据
		if(da == null) {
			Data data = new Data();
			data.setCname("cqssc");
			data.setGameNameInChinese("重庆时时彩");
			data.setPeriod(String.valueOf(DateUtil.findLatelyDate(-1).replace("-", "")+"059"));
			data.setOpenTime(DateUtil.findLatelyDate(-1)+" 23:50:00");
			data.setNextperiod(sdf.format(new Date())+"001");
			SimpleDateFormat sft = new SimpleDateFormat("yyyy-MM-dd");
			data.setNextStopOrderTimeEpoch(sft.format(new Date())+" 00:29:00");
			dataService.insert(data);
		}
		//查询数据库是否有今天的数据 在生成数据
		String period = sdf.format(new Date())+"001";
		Data data = publicmethods.pueryCurrentPeriod("cqssc", period);
		//今天开奖的第一期时间
		String time = sdf2.format(new Date())+" 00:29:00";
		//如果数据库为null则今天还没有生成数据
		if(data == null) {
			//查询当前彩种最后一条数据
			for(int i = 0;i<59;i++) {
				Data d = new Data();
				d.setCname("cqssc");//彩种名
				d.setGameNameInChinese("重庆时时彩");//彩种中文名
				d.setType(0); //彩种类型 0 是国彩  1是系统彩
				d.setStatus(0);//开奖状态
				Calendar calendar = Calendar.getInstance();
				try {calendar.setTime(sdf1.parse(time));} catch (ParseException e) {}
				if(i!=9) {
					calendar.add(Calendar.MINUTE, +20);
				}
				if(i != 58){
					*//** 当期号小于10要两个00 大于10则只需要一个0*//*
					if(currPeriod < 10) {
						d.setPeriod(sdf.format(new Date())+"00"+currPeriod);//当期开奖期号
						*//**当下期期号大于等于10则走if 否则走else *//*
						if(currPeriod+1 >= 10) {
							d.setNextperiod(sdf.format(new Date())+"0"+(currPeriod+1));//下期开奖期号
						}else {
							d.setNextperiod(sdf.format(new Date())+"00"+(currPeriod+1));//下期开奖期号
						}
					}else {
						d.setPeriod(sdf.format(new Date())+"0"+currPeriod);//当期开奖期号
						d.setNextperiod(sdf.format(new Date())+"0"+(currPeriod+1));//下期开奖期号
					}
					*//**当等于9的时候  开奖时间已经到了7:30:00所以需要判断一下*//*
					if(i==9) {
						d.setOpenTime(sdf2.format(new Date())+" 07:29:00");//当期开奖时间
						Calendar cal = Calendar.getInstance();
						try {
							cal.setTime(sdf1.parse(sdf2.format(new Date())+" 07:29:00"));
							cal.add(Calendar.MINUTE, +20);
						} catch (ParseException e) {
							e.printStackTrace();
						}
						d.setNextStopOrderTimeEpoch(sdf1.format(cal.getTime()));//下期开奖时间
						time = sdf1.format(cal.getTime());
					}else {
						d.setOpenTime(time);
						*//**
						 * 当下标等于8时 下期开奖时间应该是07:30:00
						 *//*
						if(i == 8) {
							d.setNextStopOrderTimeEpoch(sdf2.format(new Date())+" 07:29:00");//下期开奖时间
						}else {
							d.setNextStopOrderTimeEpoch(sdf1.format(calendar.getTime()));//下期开奖时间
						}
					}
					currPeriod++;
				}else if(i == 58) {
					d.setPeriod(sdf.format(new Date())+"0"+currPeriod);//当期开奖期号
					String nextPeriod = DateUtil.findLatelyDate(+1).replaceAll("-", "")+"001";
					d.setNextperiod(nextPeriod.trim());//下期开奖期号
					d.setOpenTime(time);//当期开奖时间
					d.setNextStopOrderTimeEpoch(DateUtil.findLatelyDate(+1)+" 00:29:00");//下期开奖时间
					currPeriod++;
				}
				if(i != 9) {
					time = sdf1.format(calendar.getTime());
				}
				list.add(d);
			}
			//将生成出来的数据保存到数据库
			dataService.insertByBatch(list);
		}
	}*/
	/**
	 * 彩票名称： 幸运飞艇
	 * 开奖时间： 13:05～04:05
	 * 每日期数： 001～180
	 * 开奖频率：每5分钟
	 * 期数特征：期数按天连续
	 * @throws ParseException 
	 */
	public void initXYFT() {
		/**生成期号时使用*/
		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
		/**时间转换的时候使用*/
		SimpleDateFormat sdf1 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		/**拼接时间时使用*/
		SimpleDateFormat sdf2 = new SimpleDateFormat("yyyy-MM-dd");
		List<Data> list =  new ArrayList<Data>();
		//查询数据库是否有今天的数据 在生成数据
		Data data = publicmethods.pueryCurrentPeriod("xyft", sdf.format(new Date())+"001");
		/*查询是否有昨天的数据*/
		Data da = publicmethods.pueryCurrentPeriod("xyft", DateUtil.findLatelyDate(-1).replaceAll("-", "")+"001");
		/*为空则生成昨天的开奖数据*/
		if(da == null) {
			List<Data> list1 =  new ArrayList<Data>();
			Integer currPeriod = 1;
			String time = DateUtil.findLatelyDate(-1)+" 13:08:00";
			for(int i = 0;i<180;i++) {
				Data d = new Data();
				d.setCname("xyft");//彩种名
				d.setGameNameInChinese("幸运飞艇");//彩种中文名
				d.setType(0); //彩种类型 0 是国彩  1是系统彩
				d.setStatus(0);//开奖状态
				Calendar calendar = Calendar.getInstance();
				try {calendar.setTime(sdf1.parse(time));} catch (ParseException e) {}
				calendar.add(Calendar.MINUTE, +5);
				if(i != 179){
					/** 当期号小于10要两个00 大于10则只需要一个0*/
					if(currPeriod < 10) {
						d.setPeriod(DateUtil.findLatelyDate(-1).replaceAll("-", "")+"00"+currPeriod);//当期开奖期号
						/**小于10需要两个0  不小于10 则需要一个0*/
						if(currPeriod+1 < 10) d.setNextperiod(DateUtil.findLatelyDate(-1).replaceAll("-", "")+"00"+(currPeriod+1));//下期开奖期号 
						else 	d.setNextperiod(DateUtil.findLatelyDate(-1).replaceAll("-", "")+"0"+(currPeriod+1));//下期开奖期号
					}else if(currPeriod < 100 && currPeriod >= 10){
						d.setPeriod(DateUtil.findLatelyDate(-1).replaceAll("-", "")+"0"+currPeriod);//当期开奖期号
						/**当加1以后等于100不用在前面加0*/
						if(currPeriod+1 == 100) {
							d.setNextperiod(DateUtil.findLatelyDate(-1).replaceAll("-", "")+(currPeriod+1));//下期开奖期号
						}else {
							d.setNextperiod(DateUtil.findLatelyDate(-1).replaceAll("-", "")+"0"+(currPeriod+1));//下期开奖期号
						}
					}else {
						d.setPeriod(DateUtil.findLatelyDate(-1).replaceAll("-", "")+currPeriod);//当期开奖期号
						d.setNextperiod(DateUtil.findLatelyDate(-1).replaceAll("-", "")+(currPeriod+1));//下期开奖期号
					}
					d.setOpenTime(time);
					d.setNextStopOrderTimeEpoch(sdf1.format(calendar.getTime()));//下期开奖时间
					currPeriod++;
				}else if(i == 179) {
					d.setPeriod(DateUtil.findLatelyDate(-1).replaceAll("-", "")+currPeriod);//当期开奖期号
					String nextPeriod = sdf.format(new Date())+"001";
					d.setNextperiod(nextPeriod.trim());//下期开奖期号
					d.setOpenTime(time);//当期开奖时间
					d.setNextStopOrderTimeEpoch(sdf2.format(new Date())+" 13:08:00");//下期开奖时间
					currPeriod++;
				}
				time = sdf1.format(calendar.getTime());
				list1.add(d);
			}
			//将生成出来的数据保存到数据库
			dataService.insertByBatch(list1);
		}
		Integer currPeriod = 1;
		//今天开奖的第一期时间
		String time = sdf2.format(new Date())+" 13:08:00";
		//如果数据库为null则今天还没有生成数据
		if(data == null) {
			for(int i = 0;i<180;i++) {
				Data d = new Data();
				d.setCname("xyft");//彩种名
				d.setGameNameInChinese("幸运飞艇");//彩种中文名
				d.setType(0); //彩种类型 0 是国彩  1是系统彩
				d.setStatus(0);//开奖状态
				Calendar calendar = Calendar.getInstance();
				try {calendar.setTime(sdf1.parse(time));} catch (ParseException e) {}
				calendar.add(Calendar.MINUTE, +5);
				if(i != 179){
					/** 当期号小于10要两个00 大于10则只需要一个0*/
					if(currPeriod < 10) {
						d.setPeriod(sdf.format(new Date())+"00"+currPeriod);//当期开奖期号
						/**
						 * 小于10需要两个0  不小于10 则需要一个0
						 */
						if(currPeriod+1 < 10) d.setNextperiod(sdf.format(new Date())+"00"+(currPeriod+1));//下期开奖期号 
						else 	d.setNextperiod(sdf.format(new Date())+"0"+(currPeriod+1));//下期开奖期号
					}else if(currPeriod < 100 && currPeriod >= 10){
						d.setPeriod(sdf.format(new Date())+"0"+currPeriod);//当期开奖期号
						/**当加1以后等于100不用在前面加0*/
						if(currPeriod+1 == 100) {
							d.setNextperiod(sdf.format(new Date())+(currPeriod+1));//下期开奖期号
						}else {
							d.setNextperiod(sdf.format(new Date())+"0"+(currPeriod+1));//下期开奖期号
						}
					}else {
						d.setPeriod(sdf.format(new Date())+currPeriod);//当期开奖期号
						d.setNextperiod(sdf.format(new Date())+(currPeriod+1));//下期开奖期号
					}
					d.setOpenTime(time);
					d.setNextStopOrderTimeEpoch(sdf1.format(calendar.getTime()));//下期开奖时间
					currPeriod++;
				}else if(i == 179) {
					d.setPeriod(sdf.format(new Date())+currPeriod);//当期开奖期号
					String nextPeriod = DateUtil.findLatelyDate(+1).replaceAll("-", "")+"001";
					d.setNextperiod(nextPeriod.trim());//下期开奖期号
					d.setOpenTime(time);//当期开奖时间
					d.setNextStopOrderTimeEpoch(DateUtil.findLatelyDate(+1)+" 13:08:00");//下期开奖时间
					currPeriod++;
				}
				time = sdf1.format(calendar.getTime());
				list.add(d);
			}
			//将生成出来的数据保存到数据库
			dataService.insertByBatch(list);
		}
	}

	//-----------------------------------以上为期数按天连续的彩种；以下为期数整体连续的彩种----------------------------------
	
	/**
	 * 彩票名称： 北京快3
	 * 开奖时间： 开奖时间 09:20  到晚上23:40   每20分钟开一期 一天44期    
	 * 每日期数： 44
	 * 开奖频率：每20分钟
	 * 期数特征：期数整体连续
	 * 基准期数：132953期	开奖时间-2019-02-11 09:20:00
	 */
	public void initBJK3() {
		int num = 132953;
		String str = "2019-02-11 09:20:00";
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		SimpleDateFormat sdf1 = new SimpleDateFormat("yyyy-MM-dd");
		String[] time1 = sdf.format(new Date()).split(" ");
		Long period = null;
		try {
			//每天的第一期
			period =  (sdf1.parse(time1[0]).getTime() - sdf1.parse(str.split(" ")[0]).getTime())/86400000*44+num;} catch (ParseException e) {}
		/*查询是否有昨天的数据*/
		Data da = publicmethods.pueryCurrentPeriod("bjk3", String.valueOf(period-1));
		/*生成上一期的数据*/
		if(da == null) {
			Data d = new Data();
			d.setCname("bjk3");
			d.setGameNameInChinese("北京快3");
			d.setPeriod(String.valueOf(period-1));
			d.setOpenTime(DateUtil.findLatelyDate(-1)+" 23:40:00");
			d.setNextperiod(String.valueOf(period));
			SimpleDateFormat sft = new SimpleDateFormat("yyyy-MM-dd");
			d.setNextStopOrderTimeEpoch(sft.format(new Date())+" 09:18:00");
			dataService.insert(d);
		} 
		//查询数据库是否有今天的数据 在生成数据
		Data data = publicmethods.pueryCurrentPeriod("bjk3", String.valueOf(period));
		//如果数据库为null则今天还没有生成数据
		if(data == null) {
			dataService.insertByBatch(generationOfPeriodNumber3(44," 09:18:00",20,period,"bjk3","北京快3"));
		}
	}

	/**
	 * 彩票名称： 北京PK拾
	 * 开奖时间： 早上9:30 ~晚上 23:50       每20分钟开一期    一天44期
	 * 每日期数： 001～044
	 * 开奖频率：每20分钟
	 * 期数特征：期数整体连续
	 * 基准期数：
	 */
	public void initBJPK10() {
		int num = 729392;
		String str = "2019-02-11 09:30:00";
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		SimpleDateFormat sdf1 = new SimpleDateFormat("yyyy-MM-dd");
		String[] time1 = sdf.format(new Date()).split(" ");
		Long period = null;
		try {
			//每天的第一期
			period =  (sdf1.parse(time1[0]).getTime() - sdf1.parse(str.split(" ")[0]).getTime())/86400000*44+num;} catch (ParseException e) {}
		/*查询是否有昨天的数据*/
		Data da = publicmethods.pueryCurrentPeriod("bjpk10", String.valueOf(period-1));
		/*生成上一期的数据*/
		if(da == null) {
			Data d = new Data();
			d.setCname("bjpk10");
			d.setGameNameInChinese("北京PK10");
			d.setPeriod(String.valueOf(period-1));
			d.setOpenTime(DateUtil.findLatelyDate(-1)+" 23:50:00");
			d.setNextperiod(String.valueOf(period));
			SimpleDateFormat sft = new SimpleDateFormat("yyyy-MM-dd");
			d.setNextStopOrderTimeEpoch(sft.format(new Date())+" 09:29:30");
			dataService.insert(d);
		}
		//查询数据库是否有今天的数据 在生成数据
		Data data = publicmethods.pueryCurrentPeriod("bjpk10", String.valueOf(period));
		//如果数据库为null则今天还没有生成数据
		if(data == null) {
			dataService.insertByBatch(generationOfPeriodNumber3(44," 09:29:30",20,period,"bjpk10","北京PK拾"));
		}
	}
	/**
	 * 生成连续期号  支持彩种  北京PK拾  北京快3   北京28待定
	 * @param num  生成多少期
	 * @param date  开始时间
	 * @param times  每次多少分钟
	 * @param period 从那一期开始生成
	 * @param cname  彩种英文名
	 * @param cnames 彩种中文名
	 * @return  生成数据并返回list集合里面包含生成的每一个数据Data
	 */
	public static List<Data> generationOfPeriodNumber3(Integer num,String date,Integer times,Long period,String cname,String cnames){
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		SimpleDateFormat sdf1 = new SimpleDateFormat("yyyy-MM-dd");
		List<Data> list =  new ArrayList<Data>();
		String time = sdf1.format(new Date())+date;
		for(int i = 0;i<num;i++) {
			Data d = new Data();
			d.setCname(cname);//彩种名
			d.setGameNameInChinese(cnames);//彩种中文名
			d.setType(0); //彩种类型 0 是国彩  1是系统彩
			d.setStatus(0);//开奖状态
			Calendar calendar = Calendar.getInstance();
			try {calendar.setTime(sdf.parse(time));} catch (ParseException e) {}
			calendar.add(Calendar.MINUTE, +times);
			if(i != num-1){
				d.setPeriod(String.valueOf(period));//当期开奖期号
				d.setNextperiod(String.valueOf(period+1));//下期开奖期号
				d.setOpenTime(time);
				d.setNextStopOrderTimeEpoch(sdf.format(calendar.getTime()));//下期开奖时间
			}else if(i == num-1) {
				d.setPeriod(String.valueOf(period));//当期开奖期号
				d.setNextperiod(String.valueOf(period+1));//下期开奖期号
				d.setOpenTime(time);//当期开奖时间
				d.setNextStopOrderTimeEpoch(DateUtil.findLatelyDate(+1)+date);//下期开奖时间
			}
			period++;
			time = sdf.format(calendar.getTime());
			list.add(d);
		}
		return list;
	}
	
	
	/**
	 * 彩票名称： 福彩3D
	 * 开奖时间： 每晚21:15
	 * 每日期数： 1
	 * 开奖频率：24小时
	 * 期数特征：期数整体连续
	 * 基准期数：2019036期	开奖时间-2019-02-12
	 */
	public void initFC3D() {
		String period = "2019036";
		String date = "2019-02-12";
		firstPeriodOpenTime = LocalDate.now().atTime(21, 5, 0);
		latestPeriod = dataService.getTodayLatestPeriodOfSpecialCp("fc3d",period,period);
		if(!StringUtils.isEmpty(latestPeriod)) {
			return ;			
		}
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy");
		SimpleDateFormat sdf1 = new SimpleDateFormat("yyyy-MM-dd");
		int num = (new Integer(sdf.format(new Date()))-2019)*6;
		period = String.valueOf(new Integer(period)-num);
		try {
			period = String.valueOf(2019036-num+(sdf1.parse(sdf1.format(new Date())).getTime()-sdf1.parse(date).getTime())/86400000);
			} catch (ParseException e) {}
		/*查询是否有昨天的数据*/
		Data da = publicmethods.previousIssue("fc3d", String.valueOf(period));
		/*生成上一期的数据*/
		if(da == null) {
			Data data = new Data();
			data.setCname("fc3d");
			data.setGameNameInChinese("福彩3D");
			data.setPeriod(String.valueOf(new Integer(period)-1));
			data.setOpenTime(DateUtil.findLatelyDate(-1)+" 21:05:00");
			data.setNextperiod(Long.parseLong(data.getPeriod())+1+"");
			SimpleDateFormat sft = new SimpleDateFormat("yyyy-MM-dd");
			data.setNextStopOrderTimeEpoch(sft.format(new Date())+" 21:05:00");
			dataService.insert(data);
		}
		Data d = publicmethods.pueryCurrentPeriod("fc3d", String.valueOf(period));
		if(d != null) {
			return;
		}
		Data data = new Data();
		data.setCname("fc3d");
		data.setGameNameInChinese("福彩3D");
		data.setPeriod(period);
		data.setOpenTime(DateUtil.formatDateTime(firstPeriodOpenTime));
		data.setNextperiod(Long.parseLong(data.getPeriod())+1+"");
		firstPeriodOpenTime = firstPeriodOpenTime.plusDays(1);
		data.setNextStopOrderTimeEpoch(DateUtil.formatDateTime(firstPeriodOpenTime));
		dataService.insert(data);
	}
	
	/**
	 * 彩种名称：香港六合彩
	 * 开奖时间：每周二、周四、周六（或周日）21:33左右（北京时间）
	 * 每周期数：3期  
	 * 开奖频率：48小时一期
	 * 期数特征： 期数整体连续
	 * 基准期数： 2019023期   开奖时间2019-02-26 21:35:20
	 */
	public void initXglhc(){
	/*	SimpleDateFormat sdfE = new SimpleDateFormat("E");
		String whatDayIsToday = sdfE.format(new Date());//今天是星期几
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		SimpleDateFormat sdf1 = new SimpleDateFormat("yyyy-MM-dd");
		String times = " 21:30:00";//开奖时间
			//查询数据库是否有计算出来的sssss一期开奖数据
			Data d = publicmethods.pueryCurrentPeriod("xg6hc", String.valueOf(period));
			if(d == null){//如果查询出来为空null  证明这个星期还没生成开奖数据 需要生成开奖数据
				if(whatDayIsToday.equals("星期一")){
					//星期二的数据 
					Data data = new Data();
					data.setCname("xg6hc");
					data.setGameNameInChinese("香港六合彩");
					data.setPeriod(period);//当期旗号
					data.setNextperiod(String.valueOf(Long.parseLong(period)+1));
					data.setNextStopOrderTimeEpoch(DateUtil.findLatelyDate(+3)+times);//星期二开奖
					data.setOpenTime(DateUtil.findLatelyDate(+1)+times);
					dataService.insert(data);
				}else if(whatDayIsToday.equals("星期三")){
					//生成星期四的数据
					Data data = new Data();
					data.setCname("xg6hc");
					data.setGameNameInChinese("香港六合彩");
					data.setPeriod(period);//当期旗号
					data.setNextperiod(String.valueOf(Long.parseLong(period)+1));
					data.setNextStopOrderTimeEpoch(DateUtil.findLatelyDate(+3)+times);//星期二开奖
					data.setOpenTime(DateUtil.findLatelyDate(+1)+times);
					dataService.insert(data);
				}else if(whatDayIsToday.equals("星期五")){
					//生成星期六数据
					Data data = new Data();
					data.setCname("xg6hc");
					data.setGameNameInChinese("香港六合彩");
					data.setPeriod(period);//当期旗号
					data.setNextperiod(String.valueOf(Long.parseLong(period)+1));
					data.setNextStopOrderTimeEpoch(DateUtil.findLatelyDate(+4)+times);//星期二开奖
					data.setOpenTime(DateUtil.findLatelyDate(+1)+times);
					dataService.insert(data);
				}
			}
			} catch (ParseException e) {
				e.printStackTrace();
			}*/
		}
	
	/**
	 * 彩票名称： 排列三
	 * 开奖时间： 每晚20:30
	 * 每日期数： 1
	 * 开奖频率：24小时
	 * 期数特征：期数整体连续
	 * 基准期数：2019036期	开奖时间-2019-02-12 20:30:00
	 */
	public void initPL3() {
		String period = "2019036";
		 //2019-02-12 20:30:00
		String date = "2019-02-12";
		latestPeriod = dataService.getTodayLatestPeriodOfSpecialCp("pl3",period,period);
		if(!StringUtils.isEmpty(latestPeriod)) {
			return ;			
		}
		firstPeriodOpenTime = LocalDate.now().atTime(20, 20, 0);
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy");
		 SimpleDateFormat sdf1 = new SimpleDateFormat("yyyy-MM-dd");
		int num = (new Integer(sdf.format(new Date()))-2019)*6;
		period = String.valueOf(new Integer(period)-num);
		try {
			period = String.valueOf(2019036-num+(sdf1.parse(sdf1.format(new Date())).getTime()-sdf1.parse(date).getTime())/86400000);
			} catch (ParseException e) {}
		/*查询是否有昨天的数据*/
		Data da = publicmethods.previousIssue("pl3", String.valueOf(period));
		/*生成上一期的数据*/
		if(da == null) {
			Data data = new Data();
			data.setCname("pl3");
			data.setGameNameInChinese("排列三");
			data.setPeriod(String.valueOf(new Integer(period)-1));
			data.setOpenTime(DateUtil.findLatelyDate(-1)+" 20:20:00");
			data.setNextperiod(Long.parseLong(data.getPeriod())+1+"");
			SimpleDateFormat sft = new SimpleDateFormat("yyyy-MM-dd");
			data.setNextStopOrderTimeEpoch(sft.format(new Date())+" 20:20:00");
			dataService.insert(data);
		}
		Data d = publicmethods.pueryCurrentPeriod("pl3", String.valueOf(period));
		if(d != null) {
			return;
		}
		Data data = new Data();
		data.setCname("pl3");
		data.setGameNameInChinese("排列三");
		data.setPeriod(period);
		data.setOpenTime(DateUtil.formatDateTime(firstPeriodOpenTime));
		data.setNextperiod(Long.parseLong(data.getPeriod())+1+"");
		firstPeriodOpenTime = firstPeriodOpenTime.plusDays(1);
		data.setNextStopOrderTimeEpoch(DateUtil.formatDateTime(firstPeriodOpenTime));
		dataService.insert(data);
	}
	Map<String, Data> map = new HashMap<>();
	/**
	 * 初始化生成期号的参数
	 */
	public void parameter() {
		Data hbk3= new Data();
		hbk3.setCname("hbk3");//彩种英文名
		hbk3.setGameNameInChinese("河北快3");//彩种中文名
		hbk3.setLottertime(" 08:39:00");//开始时间
		hbk3.setOpenTime(" 22:07:00");//结束时间
		hbk3.setPeriod("001");//第一期
		hbk3.setNextperiod("041");//最后一期
		hbk3.setStatus(41);//一天多少期
		map.put("hbk3", hbk3);
		
		Data jsk3= new Data();
		jsk3.setCname("jsk3");//彩种英文名
		jsk3.setGameNameInChinese("江苏快3");//彩种中文名
		jsk3.setLottertime(" 08:48:00");//开始时间
		jsk3.setOpenTime(" 22:10:00");//结束时间
		jsk3.setPeriod("001");//第一期
		jsk3.setNextperiod("041");//最后一期
		jsk3.setStatus(41);//一天多少期
		map.put("jsk3", jsk3);
		
		Data ahk3= new Data();
		ahk3.setCname("ahk3");//彩种英文名
		ahk3.setGameNameInChinese("安徽快3");//彩种中文名
		ahk3.setLottertime(" 08:57:00");//开始时间
		ahk3.setOpenTime(" 21:50:00");//结束时间
		ahk3.setPeriod("001");//第一期
		ahk3.setNextperiod("040");//最后一期
		ahk3.setStatus(40);//一天多少期
		map.put("ahk3", ahk3);
		
		Data gxk3= new Data();
		gxk3.setCname("gxk3");//彩种英文名
		gxk3.setGameNameInChinese("广西快3");//彩种中文名
		gxk3.setLottertime(" 09:28:00");//开始时间
		gxk3.setOpenTime(" 22:30:00");//结束时间
		gxk3.setPeriod("001");//第一期
		gxk3.setNextperiod("040");//最后一期
		gxk3.setStatus(40);//一天多少期
		map.put("gxk3", gxk3);
		
		Data tjssc= new Data();
		tjssc.setCname("tjssc");//彩种英文名
		tjssc.setGameNameInChinese("天津时时彩");//彩种中文名
		tjssc.setLottertime(" 09:18:00");//开始时间
		tjssc.setOpenTime(" 23:00:00");//结束时间
		tjssc.setPeriod("001");//第一期
		tjssc.setNextperiod("042");//最后一期
		tjssc.setStatus(42);//一天多少期
		map.put("tjssc", tjssc);
		
		Data gdkl10f= new Data();
		gdkl10f.setCname("gdkl10f");//彩种英文名
		gdkl10f.setGameNameInChinese("广东快乐十分");//彩种中文名
		gdkl10f.setLottertime(" 09:30:00");//开始时间
		gdkl10f.setOpenTime(" 23:10:00");//结束时间
		gdkl10f.setPeriod("001");//第一期
		gdkl10f.setNextperiod("042");//最后一期
		gdkl10f.setStatus(42);//一天多少期
		map.put("gdkl10f", gdkl10f);
		
		Data fjk3= new Data();
		fjk3.setCname("fjk3");//彩种英文名
		fjk3.setGameNameInChinese("福建快3");//彩种中文名
		fjk3.setLottertime(" 09:00:09");//开始时间
		fjk3.setOpenTime(" 22:00:30");//结束时间
		fjk3.setPeriod("001");//第一期
		fjk3.setNextperiod("039");//最后一期
		fjk3.setStatus(39);//一天多少期
		map.put("fjk3", fjk3);
		
		Data jlk3= new Data();
		jlk3.setCname("jlk3");//彩种英文名
		jlk3.setGameNameInChinese("吉林快3");//彩种中文名
		jlk3.setLottertime(" 08:39:50");//开始时间
		jlk3.setOpenTime(" 21:40:50");//结束时间
		jlk3.setPeriod("001");//第一期
		jlk3.setNextperiod("040");//最后一期
		jlk3.setStatus(40);//一天多少期
		map.put("jlk3", jlk3);
		
		Data HB_k3= new Data();
		HB_k3.setCname("HB_k3");//彩种英文名
		HB_k3.setGameNameInChinese("湖北快3");//彩种中文名
		HB_k3.setLottertime(" 09:19:30");//开始时间
		HB_k3.setOpenTime(" 22:40:10");//结束时间
		HB_k3.setPeriod("001");//第一期
		HB_k3.setNextperiod("042");//最后一期
		HB_k3.setStatus(42);//一天多少期
		map.put("HB_k3", HB_k3);
		/*----------------------------------------一下是一个0的期号----------------------------------------------- */
		
		Data gd11x5= new Data();
		gd11x5.setCname("gd11x5");//彩种英文名
		gd11x5.setGameNameInChinese("广东11选5");//彩种中文名
		gd11x5.setLottertime(" 09:48:30");//开始时间
		gd11x5.setOpenTime(" 23:10:00");//结束时间
		gd11x5.setPeriod("01");//第一期
		gd11x5.setNextperiod("42");//最后一期
		gd11x5.setStatus(42);//一天多少期
		gd11x5.setType(20);//多少分钟开一期
		map.put("gd11x5", gd11x5);
		
		Data sh11x5= new Data();
		sh11x5.setCname("sh11x5");//彩种英文名
		sh11x5.setGameNameInChinese("上海11选5");//彩种中文名
		sh11x5.setLottertime(" 09:19:00");//开始时间
		sh11x5.setOpenTime(" 23:40:00");//结束时间
		sh11x5.setPeriod("01");//第一期
		sh11x5.setNextperiod("45");//最后一期
		sh11x5.setStatus(45);//一天多少期
		sh11x5.setType(20);//多少分钟开一期
		map.put("sh11x5", sh11x5);
		
		Data ah11x5= new Data();
		ah11x5.setCname("ah11x5");//彩种英文名
		ah11x5.setGameNameInChinese("安徽11选5");//彩种中文名
		ah11x5.setLottertime(" 08:59:30");//开始时间
		ah11x5.setOpenTime(" 22:00:00");//结束时间
		ah11x5.setPeriod("01");//第一期
		ah11x5.setNextperiod("40");//最后一期
		ah11x5.setStatus(40);//一天多少期
		ah11x5.setType(20);//多少分钟开一期
		map.put("ah11x5", ah11x5);
		
		Data sd11x5= new Data();
		sd11x5.setCname("sd11x5");//彩种英文名
		sd11x5.setGameNameInChinese("山东11选5");//彩种中文名
		sd11x5.setLottertime(" 08:58:30");//开始时间
		sd11x5.setOpenTime(" 23:00:00");//结束时间
		sd11x5.setPeriod("01");//第一期
		sd11x5.setNextperiod("43");//最后一期
		sd11x5.setStatus(43);//一天多少期
		sd11x5.setType(20);//多少分钟开一期
		map.put("sd11x5", sd11x5);
		
		Data jx11x5= new Data();
		jx11x5.setCname("jx11x5");//彩种英文名
		jx11x5.setGameNameInChinese("江西11选5");//彩种中文名
		jx11x5.setLottertime(" 09:28:30");//开始时间
		jx11x5.setOpenTime(" 23:10:00");//结束时间
		jx11x5.setPeriod("01");//第一期
		jx11x5.setNextperiod("42");//最后一期
		jx11x5.setStatus(42);//一天多少期
		jx11x5.setType(20);//多少分钟开一期
		map.put("jx11x5", jx11x5);
		
		Data nmgk3= new Data();
		nmgk3.setCname("nmgk3");//彩种英文名
		nmgk3.setGameNameInChinese("内蒙古快3");//彩种中文名
		nmgk3.setLottertime(" 09:45:51");//开始时间
		nmgk3.setOpenTime(" 21:46:51");//结束时间
		nmgk3.setPeriod("01");//第一期
		nmgk3.setNextperiod("36");//最后一期
		nmgk3.setStatus(36);//一天多少期
		nmgk3.setType(20);//多少分钟开一期
		map.put("nmgk3", nmgk3);
		
		Data shssl= new Data();
		shssl.setCname("shssl");//彩种英文名
		shssl.setGameNameInChinese("上海时时乐");//彩种中文名
		shssl.setLottertime(" 10:30:00");//开始时间
		shssl.setOpenTime(" 21:30:00");//结束时间
		shssl.setPeriod("01");//第一期
		shssl.setNextperiod("23");//最后一期
		shssl.setStatus(23);//一天多少期
		shssl.setType(30);//多少分钟开一期
		map.put("shssl", shssl);
	}
	/**
	 * 定时任务 每天00:00:00点的时候执行生成开奖期号和时间
	 */
	public void timingTask() {
		parameter();
		//initCQSSC();//隔天了
		
		initXJSSC();//隔天了
		initCQKL10F();//隔天了
		
		initBJPK10();//连续期号
		initBJK3();//连续期号
		insertBj28();//连续期号
		
		
		initXYFT();//隔天的
		
	
		initPL3();//一天就一期
		initFC3D();//一天就一期
		/**
		 * 彩票名称： 江苏快3 
		 * 开奖时间： 开奖时间  08:50  到晚上 22:10  每20分钟开一期  一天41期
		 * 每日期数： 001～041
		 * 开奖频率：每20分钟
		 * 期数特征：期数按天连续
		 */
		initIssueNumber(map.get("jsk3"));
		/**
		 * 彩票名称： 安徽快3 
		 * 开奖时间： 开奖时间 08:50  到晚上21:58  每20分钟开一期  一天40期
		 * 每日期数： 001～040
		 * 开奖频率：每20分钟
		 * 期数特征：期数按天连续
		 */
		initIssueNumber(map.get("ahk3"));
		/**
		 * 彩票名称： 广西快3  
		 * 开奖时间：开奖时间09:30  到晚上 22:30 每20分钟开一期   一天40期
		 * 每日期数： 001～040
		 * 开奖频率：每20分钟
		 * 期数特征：期数按天连续
		 */
		initIssueNumber(map.get("gxk3"));
		/**
		 * 彩票名称： 天津时时彩 
		 * 开奖时间： 开奖时间  早上 09:20  到晚上  23:00  每20分钟一期  一天42期
		 * 每日期数： 001～042
		 * 开奖频率：每20分钟
		 * 期数特征：期数按天连续
		 */
		initIssueNumber(map.get("tjssc"));
		/**
		 * 彩票名称： 广东快乐十分 
		 * 开奖时间：开奖时间 09:30  到晚上23:10:00    每20分钟开一期  一天42期 
		 * 每日期数： 001～042
		 * 开奖频率：每10分钟
		 * 期数特征：期数按天连续
		 */
		initIssueNumber(map.get("gdkl10f"));
		/**
		 * 彩票名称：河北快3
		 * 开奖时间：开奖时间  早上08:40:00 到晚上  22:07:00  每20分钟一期  一天41期
		 * 每日期数： 001～041
		 * 开奖频率：每20分钟
		 * 期数特征：期数按天连续
		 */
		//initIssueNumber(map.get("hbk3"));
		/**
		 * 彩票名称：福建快3
		 * 开奖时间：开奖时间  早上 09:00:10 到晚上 22:00:30   每20分钟一期  一天39期
		 * 每日期数： 001～039
		 * 开奖频率：每20分钟
		 * 期数特征：期数按天连续
		 */
		//initIssueNumber(map.get("fjk3"));
		/**
		 * 彩票名称： 吉林快3
		 * 开奖时间：开奖时间  早上08:40:50 到晚上 21:40:50  每20分钟一期  一天40期
		 * 每日期数： 001～040
		 * 开奖频率：每20分钟
		 * 期数特征：期数按天连续
		 */
		//initIssueNumber(map.get("jlk3"));
		/**
		 * 彩票名称：湖北快3
		 * 开奖时间：开奖时间  早上09:20:30到晚上 22:40:10  每20分钟一期  一天42期
		 * 每日期数： 001～042
		 * 开奖频率：每20分钟
		 * 期数特征：期数按天连续
		 */
		//initIssueNumber(map.get("HB_k3"));
		/**
		 * 彩票名称： 广东11选5
		 * 开奖时间：开奖时间  早上09:30:00到晚上 23:10:00  每20分钟一期  一天42期
		 * 每日期数： 01～42
		 * 开奖频率：每20分钟
		 * 期数特征：期数按天连续
		 */
		initIssueNumber1(map.get("gd11x5"));
		/**
		 * 彩票名称： 上海11选5 
		 * 开奖时间：开奖时间  早上09:20  到晚上  23:40   每20分钟一期 每天44期
		 * 每日期数： 01～44
		 * 开奖频率：每20分钟
		 * 期数特征：期数按天连续
		 */
		initIssueNumber1(map.get("sh11x5"));
		/**
		 * 彩票名称： 安徽11选5  
		 * 开奖时间： 开奖时间 早上09:00  到晚上22:00  每20分钟一期 每天40期
		 * 每日期数： 01～40
		 * 开奖频率：每20分钟
		 * 期数特征：期数按天连续
		 */
		initIssueNumber1(map.get("ah11x5"));
		/**
		 * 彩票名称： 山东11选5 
		 * 开奖时间： 开奖时间 09：00：00   每20分钟一期 一天43期
		 * 每日期数： 01～43
		 * 开奖频率：每20分钟
		 * 期数特征：期数按天连续
		 */
		initIssueNumber1(map.get("sd11x5"));
		/**
		 * 彩票名称： 江西11选5 
		 * 开奖时间： 开奖时间 早上09:30   到晚上 23:13  每20分钟一期  每天42期
		 * 每日期数： 01～42
		 * 开奖频率：每20分钟
		 * 期数特征：期数按天连续
		 */
		initIssueNumber1(map.get("jx11x5"));
		/**
		 * 彩票名称：内蒙古快3
		 * 开奖时间：开奖时间  早上09:46:51 到晚上   21:46:51  每20分钟一期  一天36期
		 * 每日期数： 01～36
		 * 开奖频率：每20分钟
		 * 期数特征：期数按天连续
		 */
		//initIssueNumber1(map.get("nmgk3"));
		/**
		 * 彩票名称： 上海时时乐
		 * 开奖时间： 10:30～21:30
		 * 每日期数： 01～23
		 * 开奖频率：30分钟
		 * 期数特征：期数按天连续
		 */
		initIssueNumber1(map.get("shssl"));
		/**
		 * 香港六合彩
		 */
		initXglhc();
		
		Calendar date = Calendar.getInstance();
        date.set(date.get(Calendar.YEAR), date.get(Calendar.MONTH), date.get(Calendar.DATE), 0, 0, 0);
        long daySpan = 24 * 60 * 60 * 1000;
        Timer t = new Timer();
     	Calendar cal = Calendar.getInstance();
     	cal.set(Calendar.DAY_OF_MONTH, cal.get(Calendar.DAY_OF_MONTH) + 1);
     	cal.set(Calendar.HOUR_OF_DAY, 0);
     	cal.set(Calendar.MINUTE, 0);
     	cal.set(Calendar.SECOND, 0);
     	cal.set(Calendar.MILLISECOND, 0);
     	Integer diff = (int) (cal.getTimeInMillis() - System.currentTimeMillis());
        t.schedule(new TimerTask() {
            public void run() {
               System.out.println("定时器执行生成北京28开奖数据..");
        		initIssueNumber1(map.get("gd11x5"));//广东11选5
        		initIssueNumber1(map.get("sh11x5"));//上海11选5
        		initIssueNumber1(map.get("ah11x5"));//安徽11选5
        		initIssueNumber1(map.get("sd11x5"));//山东11选5
        		initIssueNumber1(map.get("jx11x5"));//江西11选5
        		initIssueNumber1(map.get("shssl"));//上海时时乐
        		//initIssueNumber1(map.get("nmgk3"));
        		
        		initIssueNumber(map.get("jsk3"));//江苏快3
        		initIssueNumber(map.get("ahk3"));//安徽快3
        		initIssueNumber(map.get("gxk3"));//广西快3
        		initIssueNumber(map.get("tjssc"));//天津时时彩
        		initIssueNumber(map.get("gdkl10f"));//广东快乐10分
        		//initIssueNumber(map.get("fjk3"));//福建快3
        		//initIssueNumber(map.get("jlk3"));//吉林快3
        		//initIssueNumber(map.get("HB_k3"));//湖北快3
        		//initIssueNumber(map.get("hbk3"));//河北快3
        		
        		insertBj28();
          		//initCQSSC();  //重庆时时彩
        		initXJSSC();//新疆时时彩
        		initBJPK10();//北京PK10
        		initBJK3();//北京快3
        		initXYFT();//幸运飞艇

        		initPL3();//排列3
        		initFC3D();//福彩3D
        		initCQKL10F();//重庆快乐10分
        		
        		initXglhc();//香港六合彩
            }
        }, diff, daySpan);//daySpan是一天的毫秒数，也是执行间隔
	}
	public static void main(String[] args) {
		SimpleDateFormat sdf2 = new SimpleDateFormat("yyyy-MM-dd");
		SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
		Date date1;
		int a = 0;
		try {
			date1 = format.parse("2019-02-12 09:05:00".split(" ")[0]);
			Date date2 = format.parse(sdf2.format((new Date())));
			a = (int) ((date2.getTime() - date1.getTime()) / (1000*3600*24));
		} catch (ParseException e1) {}
		Long period = a*179+935548l -1; 
		List<Data> d = generationOfPeriodNumber3(179," 09:05:00",5,period+1,"bj28","北京28");
		for (Data data : d) {
			System.out.println(data.toString());
		}
	}
	/**
	 * 彩票名称： 北京28
	 * 开奖时间： 09:05:00~23:55:00
	 * 每日期数： 179
	 * 期数特征：期数整体连续
	 * 基准期数：935548期	开奖时间-2019-02-12 09:05:00
	 */
	public void insertBj28() {
 		//SimpleDateFormat sdf2 = new SimpleDateFormat("yyyy-MM-dd");
		SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
		Date date1;
		int a = 0;
		try {
			date1 = format.parse("2019-02-12 09:05:00".split(" ")[0]);
			Date date2 = format.parse(format.format((new Date())));
			a = (int) ((date2.getTime() - date1.getTime()) / (1000*3600*24));
		} catch (ParseException e1) {}
		//昨天最后的一期
		Long period = a*179+935548l -1; 
		/*查询是否有昨天的数据*/
		Data da = publicmethods.pueryCurrentPeriod("bj28", String.valueOf(period));
		/*生成上一期的数据*/
		if(da == null) {
			Data d = new Data();
			d.setCname("bj28");
			d.setGameNameInChinese("北京28");
			d.setPeriod(String.valueOf(period));
			d.setOpenTime(DateUtil.findLatelyDate(-1)+" 23:55:00");
			d.setNextperiod(String.valueOf(period+1));
			SimpleDateFormat sft = new SimpleDateFormat("yyyy-MM-dd");
			d.setNextStopOrderTimeEpoch(sft.format(new Date())+" 09:04:40");
			dataService.insert(d);
		}
		//查询今天是否已经生成数据 如果没有生成数据则生成数据 如果有生成数据则不生成数据
		Data ins = new Publicmethods().pueryCurrentPeriod("bj28", String.valueOf(period+1));
		//ins 为空代表没有生成数据 需要生成数据 如果不为空则已经生成数据了 不需要在生成数据
		if(ins == null) {
			dataService.insertByBatch(generationOfPeriodNumber3(179," 09:04:40",5,period+1,"bj28","北京28"));
	   }
	}
	/**
	 * 彩票名称： 新疆时时彩
	 * 开奖时间： 开奖时间  早上10:20 到凌晨  02:00   每20分钟一期 一天48期
	 * 每日期数： 001～048
	 * 开奖频率：每20分钟
	 * 期数特征：期数按天连续
	 */
	public void initXJSSC() {
		/**生成期号时使用*/
		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
		/**时间转换的时候使用*/
		SimpleDateFormat sdf1 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		/**拼接时间时使用*/
		SimpleDateFormat sdf2 = new SimpleDateFormat("yyyy-MM-dd");
		/*查询是否有昨天的数据*/
		Data da = publicmethods.pueryCurrentPeriod("xjssc", DateUtil.findLatelyDate(-1).replace("-", "")+"001");
		/*生成上一期的数据*/
		if(da == null) {
			List<Data> list1 =  new ArrayList<Data>();
			Integer currPeriod = 1;
			String time =  DateUtil.findLatelyDate(-1)+" 10:17:00";
			for(int i = 0;i<48;i++) {
				Data d = new Data();
				d.setCname("xjssc");//彩种名
				d.setGameNameInChinese("新疆时时彩");//彩种中文名
				d.setType(0); //彩种类型 0 是国彩  1是系统彩
				d.setStatus(0);//开奖状态
				Calendar calendar = Calendar.getInstance();
				try {calendar.setTime(sdf1.parse(time));} catch (ParseException e) {}
				calendar.add(Calendar.MINUTE, +20);
				if(i != 47){
					/** 当期号小于10要两个00 大于10则只需要一个0*/
					if(currPeriod < 10) {
						d.setPeriod(DateUtil.findLatelyDate(-1).replaceAll("-", "")+"00"+currPeriod);//当期开奖期号
						/**
						 * 小于10需要两个0  不小于10 则需要一个0
						 */
						if(currPeriod+1 < 10) d.setNextperiod(DateUtil.findLatelyDate(-1).replaceAll("-", "")+"00"+(currPeriod+1));//下期开奖期号 
						else 	d.setNextperiod(DateUtil.findLatelyDate(-1).replaceAll("-", "")+"0"+(currPeriod+1));//下期开奖期号
					}else {
						d.setPeriod(DateUtil.findLatelyDate(-1).replaceAll("-", "")+"0"+currPeriod);//当期开奖期号
						d.setNextperiod(DateUtil.findLatelyDate(-1).replaceAll("-", "")+"0"+(currPeriod+1));//下期开奖期号
					}
					d.setOpenTime(time);
					d.setNextStopOrderTimeEpoch(sdf1.format(calendar.getTime()));//下期开奖时间
					currPeriod++;
				}else if(i == 47) {
					d.setPeriod(DateUtil.findLatelyDate(-1).replaceAll("-", "")+"0"+currPeriod);//当期开奖期号
					String nextPeriod = sdf.format(new Date())+"001";
					d.setNextperiod(nextPeriod.trim());//下期开奖期号
					d.setOpenTime(time);//当期开奖时间
					d.setNextStopOrderTimeEpoch(sdf2.format(new Date())+" 10:17:00");//下期开奖时间
					currPeriod++;
				}
				time = sdf1.format(calendar.getTime());
				list1.add(d);
			}
			//将生成出来的数据保存到数据库
			dataService.insertByBatch(list1);
		}
		//查询数据库是否有今天的数据 在生成数据
		Data data = publicmethods.pueryCurrentPeriod("xjssc", sdf.format(new Date())+"001");
			//如果数据库为null则今天还没有生成数据
			if(data == null) {
				dataService.insertByBatch(generationOfPeriodNumber2(48," 10:17:00","xjssc","新疆时时彩"));
			}
		}
	
	/**
	 * d.setCname("hbk3"); 彩种英文名
	 *d.setGameNameInChinese("河北快3"); 彩种中文名
	 *d.setLottertime(" 08:39:00"); 开始时间
	 *d.setOpenTime(" 22:07:00"); 结束时间
	 *d.setPeriod("001"); 第一期
	 *d.setNextperiod("041"); 最后一期
	 *d.setStatus(41); 一天多少期
	 */
	public void initIssueNumber(Data d) {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
		//查询是否有昨天的数据
		Data da = publicmethods.pueryCurrentPeriod(d.getCname(),String.valueOf(DateUtil.findLatelyDate(-1).replace("-", "")+d.getNextperiod()));
		//生成上一期的数据
		if(da == null) {
			Data data = new Data();
			data.setCname(d.getCname());
			data.setGameNameInChinese(d.getGameNameInChinese());
			data.setPeriod(String.valueOf(DateUtil.findLatelyDate(-1).replace("-", "")+d.getNextperiod()));
			data.setOpenTime(DateUtil.findLatelyDate(-1)+d.getOpenTime());
			data.setNextperiod(sdf.format(new Date())+d.getPeriod());
			SimpleDateFormat sft = new SimpleDateFormat("yyyy-MM-dd");
			data.setNextStopOrderTimeEpoch(sft.format(new Date())+d.getLottertime());
			dataService.insert(data);
		}
		//查询数据库是否有今天的数据 在生成数据
		Data data = publicmethods.pueryCurrentPeriod(d.getCname(), sdf.format(new Date())+d.getNextperiod());
		//如果数据库为null则今天还没有生成数据
		if(data == null) {
			dataService.insertByBatch(generationOfPeriodNumber2(d.getStatus(),d.getLottertime(),d.getCname(),d.getGameNameInChinese()));
		}
			
	}
	/**
	 * 生成开奖数据     支持的彩种名称      需要一个00 安徽快3 天津时时彩  广东快乐十分  广西快3  江苏快3  新疆时时彩
	 * @param num  生成多少期
	 * @param date  第一期开始的时间
	 * @param cname  彩种名称  英文名
	 * @param cnames  彩种的中文名  
	 * @return   返回List集合 里面存放的是Data对象
	 */
	// TODO: 生成开奖数据 2 支持一个00
	public static  List<Data> generationOfPeriodNumber2(Integer num,String date,String cname,String cnames){
		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
		SimpleDateFormat sdf1 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		SimpleDateFormat sdf2 = new SimpleDateFormat("yyyy-MM-dd");
		List<Data> list =  new ArrayList<Data>();
		Integer currPeriod = 1;
		String time = sdf2.format(new Date())+date;
		for(int i = 0;i<num;i++) {
			Data d = new Data();
			d.setCname(cname);//彩种名
			d.setGameNameInChinese(cnames);//彩种中文名
			d.setType(0); //彩种类型 0 是国彩  1是系统彩
			d.setStatus(0);//开奖状态
			Calendar calendar = Calendar.getInstance();
			try {calendar.setTime(sdf1.parse(time));} catch (ParseException e) {}
			calendar.add(Calendar.MINUTE, +20);
			if(i != num-1){
				/** 当期号小于10要两个00 大于10则只需要一个0*/
				if(currPeriod < 10) {
					d.setPeriod(sdf.format(new Date())+"00"+currPeriod);//当期开奖期号
					/** 小于10需要两个0  不小于10 则需要一个0 */
					if(currPeriod+1 < 10) d.setNextperiod(sdf.format(new Date())+"00"+(currPeriod+1));//下期开奖期号 
					else 	d.setNextperiod(sdf.format(new Date())+"0"+(currPeriod+1));//下期开奖期号
				}else {
					d.setPeriod(sdf.format(new Date())+"0"+currPeriod);//当期开奖期号
					d.setNextperiod(sdf.format(new Date())+"0"+(currPeriod+1));//下期开奖期号
				}
				d.setOpenTime(time);
				d.setNextStopOrderTimeEpoch(sdf1.format(calendar.getTime()));//下期开奖时间
				currPeriod++;
			}else if(i == num-1) {
				d.setPeriod(sdf.format(new Date())+"0"+currPeriod);//当期开奖期号
				String nextPeriod = DateUtil.findLatelyDate(+1).replaceAll("-", "")+"001";
				d.setNextperiod(nextPeriod.trim());//下期开奖期号
				d.setOpenTime(time);//当期开奖时间
				d.setNextStopOrderTimeEpoch(DateUtil.findLatelyDate(+1)+date);//下期开奖时间
				currPeriod++;
			}
			time = sdf1.format(calendar.getTime());
			list.add(d);
		}
		return list;
	}
	// TODO: 上面是两个00  下面是一个0
	/*----------------------------------------------一个0的-------------------------------------------------------------------*/
		/**
		 *d.setCname("hbk3"); 彩种英文名
		 *d.setGameNameInChinese("河北快3"); 彩种中文名
		 *d.setLottertime(" 08:39:00"); 开始时间
		 *d.setOpenTime(" 22:07:00"); 结束时间
		 *d.setPeriod("01"); 第一期
		 *d.setNextperiod("41"); 最后一期
		 *d.setStatus(41); 一天多少期
		 *d.getType() 多长时间一期
		 */
		public void initIssueNumber1(Data d) {
			//生成期号时使用
			SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
			//查询是否有昨天的数据
			Data da =  publicmethods.pueryCurrentPeriod(d.getCname(), String.valueOf(DateUtil.findLatelyDate(-1).replace("-", "")+d.getNextperiod()));
			//生成上一期的数据
			if(da == null) {
				Data data = new Data();
				data.setCname(d.getCname());
				data.setGameNameInChinese(d.getGameNameInChinese());
				data.setPeriod(String.valueOf(DateUtil.findLatelyDate(-1).replace("-", "")+d.getNextperiod()));
				data.setOpenTime(DateUtil.findLatelyDate(-1)+d.getOpenTime());
				data.setNextperiod(sdf.format(new Date())+d.getPeriod());
				SimpleDateFormat sft = new SimpleDateFormat("yyyy-MM-dd");
				data.setNextStopOrderTimeEpoch(sft.format(new Date())+d.getLottertime());
				dataService.insert(data);
			}
			//查询数据库是否有今天的数据 在生成数据
			Data data = publicmethods.pueryCurrentPeriod(d.getCname(), sdf.format(new Date())+d.getPeriod());
			//如果数据库为null则今天还没有生成数据
			if(data == null) {
				//将生成出来的数据保存到数据库
				dataService.insertByBatch(generationOfPeriodNumber1(d.getStatus(),d.getLottertime(),d.getCname(),d.getGameNameInChinese(),d.getType()));
			}
		}
		/**
		 * 生成开奖数据     支持的彩种名称      需要一个0 山东11选5  江西11选5  安徽11选5  上海11选5 广东11选5
		 * @param num  生成多少期
		 * @param date  第一期开始的时间
		 * @param cname  彩种名称  英文名
		 * @param cnames  彩种的中文名  
		 * @param dates  每隔多少分钟一期
		 * @return   返回List集合 里面存放的是Data对象
		 */
		// TODO: 生成开奖数据 1 支持一个0
		public static  List<Data> generationOfPeriodNumber1(Integer num,String date,String cname,String cnames,Integer dates){
			SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
			SimpleDateFormat sdf1 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			SimpleDateFormat sdf2 = new SimpleDateFormat("yyyy-MM-dd");
			List<Data> list =  new ArrayList<Data>();
			Integer currPeriod = 1;
			String time = sdf2.format(new Date())+date;
			for(int i = 0;i<num;i++) {
				Data d = new Data();
				d.setCname(cname);//彩种名
				d.setGameNameInChinese(cnames);//彩种中文名
				d.setType(0); //彩种类型 0 是国彩  1是系统彩
				d.setStatus(0);//开奖状态
				Calendar calendar = Calendar.getInstance();
				try {calendar.setTime(sdf1.parse(time));} catch (ParseException e) {}
				calendar.add(Calendar.MINUTE, +dates);
				if(i != num-1){
					/** 当期号小于10要两个00 大于10则只需要一个0*/
					if(currPeriod < 10) {
						d.setPeriod(sdf.format(new Date())+"0"+currPeriod);//当期开奖期号
						/**小于10需要一个0 不小于10 则不用管*/
						if(currPeriod+1 < 10) d.setNextperiod(sdf.format(new Date())+"0"+(currPeriod+1));//下期开奖期号 
						else 	d.setNextperiod(sdf.format(new Date())+(currPeriod+1));//下期开奖期号
					}else {
						d.setPeriod(sdf.format(new Date())+currPeriod);//当期开奖期号
						d.setNextperiod(sdf.format(new Date())+(currPeriod+1));//下期开奖期号
					}
					d.setOpenTime(time);
					d.setNextStopOrderTimeEpoch(sdf1.format(calendar.getTime()));//下期开奖时间
					currPeriod++;
				}else if(i == num-1) {
					d.setPeriod(sdf.format(new Date())+currPeriod);//当期开奖期号
					String nextPeriod = DateUtil.findLatelyDate(+1).replaceAll("-", "")+"01";
					d.setNextperiod(nextPeriod.trim());//下期开奖期号
					d.setOpenTime(time);//当期开奖时间
					d.setNextStopOrderTimeEpoch(DateUtil.findLatelyDate(+1)+date);//下期开奖时间
					currPeriod++;
				}
				time = sdf1.format(calendar.getTime());
				list.add(d);
			}
			return list;
		}
}
