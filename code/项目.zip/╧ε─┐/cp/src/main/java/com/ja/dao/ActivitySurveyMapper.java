package com.ja.dao;

import org.apache.ibatis.annotations.Param;

import com.ja.domain.ActivitySurvey;

public interface ActivitySurveyMapper {

	/**添加活动参加情况*/
	int addActivitySurvey(@Param("s") ActivitySurvey survey);
	
	/**查看是否已参加活动*/
	ActivitySurvey getOneSurvey(@Param("userid") Integer userid, @Param("id") Integer id);

}