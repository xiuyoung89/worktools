package com.ja.domain;

import java.io.Serializable;

public class KeFuAutomatic implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -2440931076694812753L;

	private Integer id; //客服咨询 自动回复设置
	  
	private String content; //回复内容
	  
	private Integer sort; //排序号
	  
	private Integer type; //回复类型
	  
	private String createTime; //操作时间
	
	private Integer state; //0禁用 1开启
	  
    
    public static long getSerialversionuid() {
		return serialVersionUID;
	}
	public Integer getId() {
		 return id;
	}
	
	public void setId(Integer id) {
		this.id = id;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public Integer getSort() {
		return sort;
	}

	public void setSort(Integer sort) {
		this.sort = sort;
	}

	public Integer getType() {
		return type;
	}

	public void setType(Integer type) {
		this.type = type;
	}

	public String getCreateTime() {
		return createTime;
	}

	public void setCreateTime(String createTime) {
		this.createTime = createTime;
	}

	public Integer getState() {
		return state;
	}

	public void setState(Integer state) {
		this.state = state;
	}

	public KeFuAutomatic() {
		super();
	}

	@Override
	public String toString() {
		return "KeFuAutomatic [id=" + id + ", content=" + content + ", sort=" + sort + ", type=" + type
				+ ", createTime=" + createTime + ", state=" + state + "]";
	}
	
}