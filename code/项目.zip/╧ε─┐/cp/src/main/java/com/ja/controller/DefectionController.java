package com.ja.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import com.ja.domain.User;
import com.ja.sevice.BackManagerService;
import com.ja.sevice.FanshuiJlService;
import com.ja.sevice.IUserService;
import com.ja.sevice.YunyingbbService;
/**
 * 项目名称：cp   
 * 类名称：DefectionController.java   
 * 类描述：   
 * 创建人：   GL
 * 创建时间：2019年2月22日 下午2:48:51   
 * @version v1.0.0
 */
@Component
@EnableScheduling
public class DefectionController {

	@Autowired
	private FanshuiJlService fanshuiJlService;
	
	@Autowired
	private IUserService userService;
	
	@Autowired
	private YunyingbbService yunyingbbService;
	
	@Autowired
	private BackManagerService managerService;
	
	/**
	 * 方法名：defectionToday 
	 * 描述：   用户每日返水                   
	 * 参数：     
	 * @return: void
	 */
	@Scheduled(cron = " 0 0 12 * * ? ")//每天中午12:00:00 执行
	public void defectionToday() {
		fanshuiJlService.rebateRecord(1);
	}

	/**
	 * 方法名：defectionMonth 
	 * 描述：   用户每月返水                   
	 * 参数：     
	 * @return: void
	 */
	@Scheduled(cron = " 10 0 0 1 * ? ") //每月1号凌晨0点01执行
	public void defectionMonth() {
		fanshuiJlService.rebateRecord(2);
	}
	
	/**
	 * 方法名：updtateRechange 
	 * 0示状态                      
	 * 参数：     
	 * @return: void
	 */
	@Scheduled(cron = " 0 1 0 * * ? ")//每日凌晨00:01:00 执行
	public void updtateRechange() {
		List<User> users = userService.getAllUsers();
		for(User user : users) {
			user.setStatu(0);
			userService.updateUserInfo(user);
		}
	}
	
	/**
	 * 方法名：deleteDataBaseData 
	 * 描述：定时删除数据库多余数据                      
	 * 参数：     
	 * @return: void
	 */
	@Scheduled(cron = "0 5 1 * *  ?")//每日凌晨 01:05:00 执行
	public void deleteDataBaseData() {
		String[] base = {"cp_data","cp_bjldata"};
		//,"cp_bjlsjb","cp_bjl_money","cp_false_money","cp_fanshuijl","cp_football_match", "cp_logonlog","cp_operationlog","cp_play_count","cp_redpacket"
		for(int i=0;i<base.length;i++) {
			userService.findDatabaseCounts(base[i]);
		}
	}
	
	/**
	 * 方法名：censusTodayRecord 
	 * 描述：  空闲统计用户和平台前一天的总计                    
	 * 参数：     
	 * @return: void
	 */
	@Scheduled(cron = " 10 0 0 * * ? ")//每日凌晨 0:00:30 执行
	public void censusTodayRecord () {
		yunyingbbService.censusTodayRecord();
	}
	
	/**
	 * 方法名：recyclingTrialAccount 
	 * 描述：  定时回收试玩账号                    
	 * 参数：     
	 * @return: void
	 */
	@Scheduled(cron = " 0 30 1 * * ? ")//每日凌晨 01:30:00 执行
	public void recyclingTrialAccount () {
		managerService.recyclingTrialAccount();
	}
	
}