package com.ja.dao;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.ja.domain.ColorVariety;
import com.ja.domain.Data;
import com.ja.domain.Lotter;
import com.ja.domain.LotterExample;
import com.ja.domain.Order;

public interface LotteryMapper {
	
	/**
	 * 方法名：updateLotterySetupInfo 
	 * 描述：     修改彩种的各种设置信息                  TODO
	 * 参数：    @param lotter 设置信息
	 * 参数：    @return 
	 * @return: int
	 */
	int updateLotterySetupInfo(Lotter lotter);
	
	
	/**查询开奖号*/
	Data inquir(@Param("cName")String cName,@Param("period")String period);
	/**插入开奖号*/
	int updataawardnumber(@Param("cName")String cName,@Param("period")String period,@Param("lotterNumber")String lotterNumber);
	
	/**获取所有彩种信息*/
	List<LotterExample> getAllLotters();
	
	/**获取所有彩种信息 最新开奖信息*/
	List<Data> getAllLotters1();

	LotterExample getLotterByCname(@Param("cName")String cName);

	Lotter getLotterById(Integer lotterid);
    
	List<Lotter> getAllLotter();

	/**关闭*/
	int delLotter(int id);
    /**开启*/
	int resetLotter(int id);

	/**查询时间差*/
	String getTimeSpace(String cname);

	/**查询背景pk10的彩种信息*/
	Lotter getBjpk10();
	
	/**根据彩种英文名查询彩种信息*/
	Lotter getByCname(String cname);
	
	/**查询所有的彩种信息*/
	List<Lotter> getAlloter();
	
	/**开启或关闭彩种*/
	int updatecz(@Param(value="id")Integer id,@Param(value="state")Integer state);

	/**根据名称查询彩种信息*/
	Lotter getCzxinxi(String name);
	
	/**修改彩种的玩法的赔率*/
	int upczpv(@Param(value="l")Lotter l);
	
	/**根据玩法来查询当前彩种单个玩法的赔率*/
	Lotter getLotterPlay(@Param(value="cname")String cname, @Param(value="id")Integer id);
	
	/**系统彩彩种*/
	List<Lotter> xitongcaicz();

	/**每天开奖次数*/
	int updateCountse(int c2, String cname);
	/**香港六合彩*/
	LotterExample xglhc(@Param("cname")String cname,@Param("xg6hcstate")int xg6hcstate);
	
	int xg6hczx(String cName);
	
	int xg6hczd(String cName);
	
	int getTotalrecord(@Param("userId")int userId,@Param("state")int state);
	
	List<Order> getPageData(@Param("pageindex")int pageindex,@Param("row") int row,@Param("userId")int userId);
	
	int userdelete(@Param("name")String name,@Param("period")String period);
	
	int iddelete(Integer id);
	
	/**修改重庆时时彩开奖时间差*/
	int updateTimespace(String timespace);
	
	/**
	 * 修改彩种打码开启和关闭
	 * @param id
	 * @param state
	 * @return
	 */
	int updatestate(@Param("id")Integer id,@Param("state")Integer state);
	
	/**
	 * 
	 *   方法名：findLotterDamaState   
	 *   描述：       查询彩种是否开启打码                TODO   
	 *   参数：    @param cname
	 *   参数：    @return 
	 * @return: Lotter
	 */
	Lotter findLotterByCname(String cname);
	
	
	/**
	 * 方法名：findAllLotteryState 
	 * 描述：    查询所有彩种的开启状态                   TODO
	 * 参数：    @return 
	 * @return: Lotter
	 */
	List<Lotter> findAllLotteryState();
	
	/**
	 * 查询彩种状态
	 * @return
	 */
	List<ColorVariety> colorVariety();
	
	/**
	 * 方法名：findSameTypeLottery 
	 * 描述：     查询彩种的分类                 
	 * 参数：    @return 
	* @return: List<Lotter>
	*/
	List<Lotter> findSameTypeLottery();
	/**
	 * 根据传入的彩种名称 查询彩种的赔率以及开奖数据 
	 * @param cname 彩种名称
	 * @return 返回当前彩种的彩种赔率以及 彩种的开奖数据
	 */ 
	LotterExample syLotterrs(String cname); 
}
