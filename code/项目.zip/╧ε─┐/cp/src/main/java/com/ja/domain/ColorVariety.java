package com.ja.domain;

public class ColorVariety {
	
	private String cname;//彩种名称
	
	private Integer state;//彩种状态 0-关闭 1-开启
	
	public ColorVariety(String cname,Integer state) {
		this.cname = cname;
		this.state = state;
	}
	
	public String getCname() {
		return cname;
	}

	public void setCname(String cname) {
		this.cname = cname;
	}

	public Integer getState() {
		return state;
	}

	public void setState(Integer state) {
		this.state = state;
	}
	
}
