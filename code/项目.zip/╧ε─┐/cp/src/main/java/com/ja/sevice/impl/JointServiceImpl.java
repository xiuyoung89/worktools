package com.ja.sevice.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ja.dao.JointMapper;
import com.ja.domain.Data;
import com.ja.domain.Joint;
import com.ja.domain.JointVo;
import com.ja.sevice.IJointService;

@Service
public class JointServiceImpl implements IJointService {
    
	@Autowired
	private JointMapper jointMapper;
	
	/**增加合买订单*/
	@Override
	public int insertJoint(Joint jo) {
		return jointMapper.insertJoint(jo);
	}
    
	/**查询所有发起的合买*/
	@Override
	public JointVo getAllJoint(String num) {
		return jointMapper.getAllJoint(num);
	}
	/**查询所有发起的订单号*/
	@Override
	public List<String> getFindJoint() {
		return jointMapper.getFindJoint();
	}
	/**查询个人参与的合买*/
	@Override
	public List<JointVo> getOneJoint(String num, Integer userid) {
		return jointMapper.getOneJoint(num,userid);
	}
	/**查询当前合买剩下的份数*/
	@Override
	public Integer getScountJoint(String num) {
		return jointMapper.getScountJoint(num);
	}

	/**合买失效,实际的合买分数*/ 
	@Override
	public int getHfenshu(String orderNum) {
		return jointMapper.getHfenshu(orderNum);
	}

	/**当前发起人合买信息*/
	@Override
	public Joint getFaqiJoint(String ordernum) {
		return jointMapper.getFaqiJoint(ordernum);
	}

	/**根据当前订单号查询合买的用户信息*/
	@Override
	public List<Integer> getNumJoint(String ordernum) {
		return jointMapper.getNumJoint(ordernum);
	}

	/**修改订单生效状态*/
	@Override
	public int upDingDan(List<Integer> ids) {
		return jointMapper.upDingDan(ids);
	}

	/**修改实际保底分数*/
	@Override
	public int upBaodi(int sjbdfs, double sjine,Integer id) {
		return jointMapper.upBaodi(sjbdfs,sjine, id);
	}

	/**修改退钱状态*/
	@Override
	public int upTuiQian(List<Integer> ids) {
		return jointMapper.upTuiQian(ids);
	}

	/**修改剩余分数*/
	@Override
	public int upSyCount(int scount, Integer id, String ordernum) {
		return jointMapper.upSyCount(scount, id, ordernum);
	}

	/**历史记录*/
	@Override
	public List<Joint> getLishiJl() {
		return jointMapper.getLishiJl();
	}

	//查询所有的发起人
	@Override
	public List<Joint> chaxunfqr() {
		return jointMapper.chaxunfqr();
	}

	//查询发起人的所有发起次数
	@Override
	public int chaxunsycs(String user) {
		return jointMapper.chaxunsycs(user);
	}

	//查询发起人的中奖次数
	@Override
	public int chaxunzjcs(String user) {
		return jointMapper.chaxunzjcs(user);
	}

	//查看有没有参加合买
	@Override
	public Joint checkhm(String orderNum, Integer id) {
		return jointMapper.checkhm(orderNum, id);
	}

	//查询发起和参与的订单号
	@Override
	public List<String> getOrderNum(int i) {
		return jointMapper.getOrderNum(i);
	}
	
	@Override
	public List<JointVo> getOneJoint1(String num, Integer userid) {
		return jointMapper.getOneJoint1(num,userid);
	}

	/**某个彩种某期退钱*/
	@Override
	public List<Joint> getAllUser(Data data) {
		return jointMapper.getAllUser(data);
	}

	/**官方开奖异常*/
	@Override
	public int chedan(Joint or) {
		return jointMapper.chedan(or);
	}


}
