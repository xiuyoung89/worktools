package com.ja.check.action;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Date;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.web.context.ContextLoader;

import com.ja.config.WebsiteStateConfig;
import com.ja.domain.Data;
import com.ja.domain.Lotter;
import com.ja.domain.PlayCount;
import com.ja.sevice.IDataService;
import com.ja.sevice.ILotteryService;
import com.ja.util.DateUtil;

/**
 * 项目名称：cp 
 * 类名称：SystemLotter.java 
 * 类描述： 系统彩开奖数据 
 * 创建人： GL 
 * 创建时间：2018年11月10日  上午10:30:42
 * @version v1.0.0
 */
public class SystemLotter {
	
	private Logger logger = LogManager.getLogger(LogManager.ROOT_LOGGER_NAME);  

	private IDataService dataService = (IDataService) ContextLoader.getCurrentWebApplicationContext().getBean("dataService");

	private ILotteryService lotterService = (ILotteryService) ContextLoader.getCurrentWebApplicationContext().getBean("lotteryService");
	
	 /* private ClassPathXmlApplicationContext ctx = new ClassPathXmlApplicationContext("/spring/applicationContext-dao.xml", "/spring/applicationContext-service.xml"); 
	  IDataService dataService =(IDataService) ctx.getBean("dataService"); 
	  ILotteryService lotterService =  (ILotteryService) ctx.getBean("lotteryService");*/
	 
	private static final String CNAME_2FPK10 = "2fpk10";
	private static final String CNAME_2FFT = "2fft";
	private static final String CNAME_XYSM = "xysm";
	private static final String CNAME_2FSSC = "2fssc";
	private static final String CNAME_2FK3 = "2fk3";
	private static final String CNAME_3FK3 = "3fk3";
	private static final String CNAME_5F6HC = "5f6hc";
	private static final String CNAME_XY28 = "xy28";
	private static final Integer LOTTER_TIME120 = 120 * 1000;
	private static final Integer LOTTER_TIME180 = 180 * 1000;
	private static final Integer LOTTER_TIME300 = 300 * 1000;
	private volatile static boolean falg = true; //线程开关
	CheckOrder co = new CheckOrder();  

	/**
	 * 方法名：findSystemLotteryPlayCount 
	 * 描述：    查询系统彩玩法下注情况                  
	 * 参数：    @param cname 彩种名称
	 * 参数：    @return 
	 * @return: List<PlayCount>
	 */
	public List<PlayCount> findSystemLotteryPlayCount(String cname) {
		List<PlayCount> play = new ArrayList<PlayCount>();
		Data data = dataService.getMaxPeriod(cname);
		if (data != null) {
			String period = (Long.parseLong(data.getPeriod()) + 1) + "";
			data.setCname(cname);
			data.setPeriod(period);
			play = dataService.findPlayDetails(data);
		}
		return play;
	}

	/**
	 * 方法名：findCplayMaxAttr 
	 * 描述： 查询系统彩中奖最高玩法的属性  
	 * 参数： @param cname 彩种名称
	 * 参数： @param cplay 玩法
	 * 参数： @return
	 * @return: PlayCount
	 */
	public PlayCount findCplayMaxAttr(String cname, String cplay) {
		Data data = dataService.getMaxPeriod(cname);
		PlayCount play = new PlayCount();
		if (data != null) {
			String period = (Long.parseLong(data.getPeriod()) + 1) + "";
			play.setCname(cname);
			play.setPeriod(period);
			play.setCplay(cplay);
			play = dataService.findCplay(play);
		}

		return play;
	}

	/**
	 * 方法名：producePeriod 
	 * 描述：    彩种期号生成                 
	 * 参数：    @param cname 彩种名称
	 * 参数：    @return 
	 * @return: int
	 */
	public int producePeriod(String cname) {
		synchronized (this) {
			int count = 0;
			String name = "";
			String newPeriod = "";
			switch (cname) {
				case CNAME_2FPK10:
					count = 720;
					name = "二分PK拾";
					break;
				case CNAME_2FFT:
					count = 720;
					name = "二分飞艇";
					break;
				case CNAME_XYSM:
					count = 288;
					name = "幸运赛马";
					break;
				case CNAME_2FSSC:
					count = 720;
					name = "二分时时彩";
					break;
				case CNAME_2FK3:
					count = 720;
					name = "二分快3";
					break;
				case CNAME_3FK3:
					count = 480;
					name = "三分快3";
					break;
				case CNAME_5F6HC:
					count = 288;
					name = "五分六合彩";
					break;
				case CNAME_XY28:
					count = 288;
					name = "幸运28";
					break;
			}
			newPeriod = (Long.parseLong(DateUtil.findFormatDates() + "00" + 1)) + "";
			Data ds = dataService.getLotteryDate(newPeriod, cname);
			if (ds != null) {
				return 0;
			}
			List<Data> datas = new ArrayList<Data>();
			Data dsData = new Data();
			dsData.setGameNameInChinese(name);
			dsData.setLottertime(DateUtil.getCurrTime());
			dsData.setCname(cname);
			dsData.setType(1);
			dsData.setPeriod(newPeriod);
			datas.add(dsData);
			for (int i = 1; i < count; i++) {
				newPeriod = Long.parseLong(newPeriod) + 1 + "";
				Data data = new Data();
				data.setGameNameInChinese(name);
				data.setLottertime(DateUtil.getCurrTime());
				data.setCname(cname);
				data.setPeriod(newPeriod);
				data.setType(1);
				datas.add(data);
			}
			dataService.addSystemLotters(datas);
		}
		return 0;
	}
	
	/**
	  * 方法名：periodCreated 
	  * 描述：    每天期号生成                 
	  * 参数：    @param cname 彩种名称
	  * 参数：    @return 
	 * @return: int
	 */
	public int periodCreated(String cname) {
		producePeriod(cname);
		Thread period = new Thread() {
			public void run() {
				while (falg) {
					try {
						Thread.sleep(1000);
						if (DateUtil.findFormatDateHours().equals("00:00:01")) {
							producePeriod(cname);
						}
					} catch (InterruptedException e) {
						logger.error("SystemLotter类：彩种每日生成期号出了问题!");
					}
				}
			}
		};
		period.start();
		return 1;
	}

	/**
	 * 方法名：checkRandomNum1 
	 * 描述：    二分PK拾--二分飞艇--幸运赛马开奖号码生成                
	 * 参数：    @return 
	 * @return: String
	 */
	public static String checkRandomNum1() {
		List<String> ids = new ArrayList<String>();
		String[] qiu = { "01", "02", "03", "04", "05", "06", "07", "08", "09", "10" };
		ids = Arrays.asList(qiu);
		Collections.shuffle(ids);
		String str = "";
		for (Object ob : ids) {
			str += ob + ",";
		}
		return str;
	}
	
	/**
	 * 方法名：checkNumPk10 
	 * 描述：     二分PK拾--二分飞艇--幸运赛马开奖号码控制                    
	 * 参数：    @param cname
	 * 参数：    @return 
	 * @return: String
	 */
	public String checkNumPk10(String cname) {
		try {
			SystemAttribute syAttr = new SystemAttribute();
			CplayMaxBall cmb = new CplayMaxBall();
			List<PlayCount> pc = findSystemLotteryPlayCount(cname);
			Lotter lotters = lotterService.getCzxinxi(cname);
			String lotterNums = "";
			String cplay = cmb.maxCplay(pc);// 最大的玩法
			String[] strs = cplay.split("&");
			if ("0".equals(strs[1])) {
				return SystemLotter.checkRandomNum1();
			}
			cplay = strs[0];
			PlayCount play = findCplayMaxAttr(cname, cplay);// 下注的属性
			if (play != null) {
				String attr = cmb.maxAttribute2fpk10(cplay, play, lotters);// 最大的
				switch (play.getCplay()) {
				case "gyhz":
					switch (attr) {
					case "dan":
						lotterNums = syAttr.gyhz(attr);
						break;
					case "shuang":
						lotterNums = syAttr.gyhz(attr);
						break;
					case "da":
						lotterNums = syAttr.gyhz(attr);
						break;
					case "xiao":
						lotterNums = syAttr.gyhz(attr);
						break;
					}
					break;
				case "gj":
				case "yj":
				case "d3m":
				case "d4m":
				case "d5m":
				case "d6m":
				case "d7m":
				case "d8m":
				case "d9m":
				case "d10m":
					switch (attr) {
					case "dan":
						lotterNums = syAttr.djm(play.getCplay(), attr);
						break;
					case "shuang":
						lotterNums = syAttr.djm(play.getCplay(), attr);
						break;
					case "da":
						lotterNums = syAttr.djm(play.getCplay(), attr);
						break;
					case "xiao":
						lotterNums = syAttr.djm(play.getCplay(), attr);
						break;
					case "longs":
						lotterNums = syAttr.djm(play.getCplay(), attr);
						break;
					case "hu":
						lotterNums = syAttr.djm(play.getCplay(), attr);
						break;
					case "d1q":
						lotterNums = syAttr.djm(play.getCplay(), attr);
						break;
					case "d2q":
						lotterNums = syAttr.djm(play.getCplay(), attr);
						break;
					case "d3q":
						lotterNums = syAttr.djm(play.getCplay(), attr);
						break;
					case "d4q":
						lotterNums = syAttr.djm(play.getCplay(), attr);
						break;
					case "d5q":
						lotterNums = syAttr.djm(play.getCplay(), attr);
						break;
					case "d6q":
						lotterNums = syAttr.djm(play.getCplay(), attr);
						break;
					case "d7q":
						lotterNums = syAttr.djm(play.getCplay(), attr);
						break;
					case "d8q":
						lotterNums = syAttr.djm(play.getCplay(), attr);
						break;
					case "d9q":
						lotterNums = syAttr.djm(play.getCplay(), attr);
						break;
					case "d10q":
						lotterNums = syAttr.djm(play.getCplay(), attr);
						break;
					}
					break;
				}
			}
			if ("".equals(lotterNums)) {
				lotterNums = SystemLotter.checkRandomNum1();
			}
			return lotterNums;
		} catch (Exception e) {
			e.printStackTrace();
			logger.error("SystemLotter类：二分PK拾--二分飞艇--幸运赛马开奖号码控制出现了异常： "+ e.toString());
			return SystemLotter.checkRandomNum1();
		}
	}
	
	/**
	 * 方法名：checkRandomNum2 
	 * 描述：   二分时时彩开奖号码生成               
	 * 参数：    @return 
	 * @return: String
	 */
	public static String checkRandomNum2() {
		List<Integer> qiu = new ArrayList<Integer>();
		List<String> ids = new ArrayList<String>();
		for (int i = 0; i < 5; i++) {
			int math1 = (int) (Math.random() * 10);
			qiu.add(math1);
		}
		int a1 = 0;
		int a2 = 0;
		int a3 = 0;
		for (int i = 0; i < qiu.size(); i++) {
			for (int j = 0; j < qiu.size(); j++) {
				if (qiu.get(i).equals(qiu.get(j))) {
					a1++;
					if (a1 == 4) {
						a2 = qiu.get(i);
						a3 = i;
					}
				}
			}
		}
		while (falg) {
			int math2 = (int) (Math.random() * 10);
			if (math2 != a2) {
				qiu.set(a3, math2);
				break;
			}
		}
		for (int i = 0; i < qiu.size(); i++) {
			String qiu1 = qiu.get(i) + "";
			ids.add(qiu1);
		}
		String str = "";
		for (Object ob : ids) {
			str += ob + ",";
		}
		return str;
	}
	
	/**
	 * 方法名：checkNumssc 
	 * 描述：    二分时时彩开奖号码控制                  
	 * 参数：    @param cname
	 * 参数：    @return 
	 * @return: String
	 */
	public String checkNumssc(String cname) { 
		try {
			SystemAttribute syAttr = new SystemAttribute();
			CplayMaxBall cmb = new CplayMaxBall();
			List<PlayCount> pc = findSystemLotteryPlayCount(cname);
			Lotter lotters = lotterService.getCzxinxi(cname);
			String lotterNums = "";
			String cplay = cmb.maxCplay(pc);// 最大的玩法
			String[] strs = cplay.split("&");
			if ("0".equals(strs[1])) {
				return SystemLotter.checkRandomNum2();
			}
			cplay = strs[0];
			PlayCount play = findCplayMaxAttr(cname, cplay);// 下注的属性
			if (play != null) {
				String attr = cmb.maxAttribute(cplay, play, lotters);// 最大的
				switch (play.getCplay()) {
				case "zh":
					switch (attr) {
					case "dan":
						lotterNums = syAttr.zh(attr);
						break;
					case "shuang":
						lotterNums = syAttr.zh(attr);
						break;
					case "da":
						lotterNums = syAttr.zh(attr);
						break;
					case "xiao":
						lotterNums = syAttr.zh(attr);
						break;
					case "longs":
						lotterNums = syAttr.zh(attr);
						break;
					case "hu":
						lotterNums = syAttr.zh(attr);
						break;
					case "he":
						lotterNums = syAttr.zh(attr);
						break;
					}
					break;
				case "d1q":
				case "d2q":
				case "d3q":
				case "d4q":
				case "d5q":
					switch (attr) {
					case "dan":
						lotterNums = syAttr.djqiu(play.getCplay(), attr);
						break;
					case "shuagn":
						lotterNums = syAttr.djqiu(play.getCplay(), attr);
						break;
					case "da":
						lotterNums = syAttr.djqiu(play.getCplay(), attr);
						break;
					case "d1q":
						lotterNums = syAttr.djqiu(play.getCplay(), attr);
						break;
					case "d2q":
						lotterNums = syAttr.djqiu(play.getCplay(), attr);
						break;
					case "d3q":
						lotterNums = syAttr.djqiu(play.getCplay(), attr);
						break;
					case "d4q":
						lotterNums = syAttr.djqiu(play.getCplay(), attr);
						break;
					case "d5q":
						lotterNums = syAttr.djqiu(play.getCplay(), attr);
						break;
					case "d6q":
						lotterNums = syAttr.djqiu(play.getCplay(), attr);
						break;
					case "d7q":
						lotterNums = syAttr.djqiu(play.getCplay(), attr);
						break;
					case "d8q":
						lotterNums = syAttr.djqiu(play.getCplay(), attr);
						break;
					case "d9q":
						lotterNums = syAttr.djqiu(play.getCplay(), attr);
						break;
					case "d10q":
						lotterNums = syAttr.djqiu(play.getCplay(), attr);
						break;
					}
					break;

				case "q3":
				case "z3":
				case "h3":
					switch (attr) {
					case "baozi":
						lotterNums = syAttr.q3(play.getCplay(), attr);
						break;
					case "shunzi":
						lotterNums = syAttr.q3(play.getCplay(), attr);
						break;
					case "duizi":
						lotterNums = syAttr.q3(play.getCplay(), attr);
						break;
					case "banshun":
						lotterNums = syAttr.q3(play.getCplay(), attr);
						break;
					case "zaliu":
						lotterNums = syAttr.q3(play.getCplay(), attr);
						break;
					}
					break;
				case "q2zhix0":
				case "q2zhix1":
				case "h2zhix0":
				case "h2zhix1":
				case "q3zhix0":
				case "q3zhix1":
				case "q3zhix2":
				case "z3zhix0":
				case "z3zhix1":
				case "z3zhix2":
				case "h3zhix0":
				case "h3zhix1":
				case "h3zhix2":
				case "q2zx":
				case "h2zx":
				case "q3z6":
				case "z3z6":
				case "h3z6":
				case "q3z3":
				case "z3z3":
				case "h3z3":
					lotterNums = syAttr.q3(play.getCplay(), attr);
					break;
				}
			}
			if ("".equals(lotterNums)) {
				lotterNums = SystemLotter.checkRandomNum2();
			}
			return lotterNums;
		} catch (Exception e) {
			e.printStackTrace();
			logger.error("SystemLotter类二：分时时彩控制出现了异常： "+ e.toString());
			return SystemLotter.checkRandomNum2();
		}
	}
	
	/**
	 * 方法名：checkRandomNum3 
	 * 描述：     三分快3--二分快3开奖号码生成          
	 * 参数：    @return 
	 * @return: String
	 */
	public static String checkRandomNum3() {
		String str = "";
		int math = 0;
		for (int i = 0; i < 3; i++) {
			math = (int) (Math.random() * 6 + 1);
			str += math + ",";
		}
		return str;
	}

	/**
	 * 方法名：checkNumk3 
	 * 描述：    三分快3--二分快3开奖号码控制                   
	 * 参数：    @param cname
	 * 参数：    @return 
	 * @return: String
	 */
	public String checkNumk3(String cname) {
		try {
			SystemAttribute syAttr = new SystemAttribute();
			CplayMaxBall cmb = new CplayMaxBall();
			List<PlayCount> pc = findSystemLotteryPlayCount(cname);
			Lotter lotters = lotterService.getCzxinxi(cname);
			String lotterNums = "";
			String cplay = cmb.maxCplay(pc);// 最大的玩法
			String[] strs = cplay.split("&");
			if ("0".equals(strs[1])) {
				return SystemLotter.checkRandomNum3();
			}
			cplay = strs[0];
			PlayCount play = findCplayMaxAttr(cname, cplay);// 下注的属性
			if (play != null) {
				String attr = cmb.maxAttributesfk3(cplay, play, lotters);// 最大的
				switch (play.getCplay()) {
				case "c1gh":
					List<Integer> attrs = new ArrayList<>();
					if (play.getD1q() != 0) {
						attrs.add(1);
					}
					if (play.getD2q() != 0) {
						attrs.add(2);
					}
					if (play.getD3q() != 0) {
						attrs.add(3);
					}
					if (play.getD4q() != 0) {
						attrs.add(4);
					}
					if (play.getD5q() != 0) {
						attrs.add(5);
					}
					if (play.getD6q() != 0) {
						attrs.add(6);
					}
					lotterNums = syAttr.c1gh(attrs);
					break;
				case "ethfx":
				case "ethdx1":
				case "ethdx2":
				case "ebth":
				case "ebthdt1":
				case "ebthdt2":
				case "sthdx":
				case "sbth":
				case "slhtx":
				case "sthtx":
				case "xt":
					lotterNums = syAttr.sfk3dq(cplay, attr);
					break;
				case "zh":
					lotterNums = syAttr.sfk3zhs(attr);
					break;
				}
			}
			if ("".equals(lotterNums)) {
				lotterNums = SystemLotter.checkRandomNum3();
				System.err.println("判断出了问题");
			}
			return lotterNums;
		} catch (Exception e) {
			e.printStackTrace();
			logger.error("SystemLotter类：二分快3--三分快3控制出现了异常： "+ e.toString());
			return SystemLotter.checkRandomNum3();
		}
	}
	
	/**
	   *   方法名：checkRandomNum4   
	   *   描述：      五分六合彩开奖号码生成                    
	   *   参数：    @return 
	 * @return: String
	 */
	public static String checkRandomNum4() {
		List<String> nums = new ArrayList<>();
		String[] array = { "01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12", "13", "14", "15",
				"16", "17", "18", "19", "20", "21", "22", "23", "24", "25", "26", "27", "28", "29", "30", "31", "32",
				"33", "34", "35", "36", "37", "38", "39", "40", "41", "42", "43", "44", "45", "46", "47", "48", "49" };
		Combine.distinctNum(49, 7, array, nums);
		return nums.toString().replace("[", "").replace("]", "");
	}

	/**
	 * 方法名：checkNum6hc 
	 * 描述：    五分六合彩开奖号码控制                  
	 * 参数：    @param cname
	 * 参数：    @return 
	 * @return: String
	 */
	public String checkNum6hc(String cname) {
		try {
			SystemAttribute syAttr = new SystemAttribute();
			CplayMaxBall cmb = new CplayMaxBall();
			List<PlayCount> pc = findSystemLotteryPlayCount(cname);
			Lotter lotters = lotterService.getCzxinxi(cname);
			String lotterNums = "";
			String cplay = cmb.maxCplay(pc);// 最大的玩法
			String[] strs = cplay.split("&");
			if ("0".equals(strs[1])) {
				return SystemLotter.checkRandomNum4();
			}
			cplay = strs[0];
			PlayCount play = findCplayMaxAttr(cname, cplay);// 下注的属性
			if (play != null) {
				String attr = cmb.maxAttributexg6hc(cplay, play, lotters);// 最大的
				switch (play.getCplay()) {
				case "tma":
				case "tmb":
				case "dp":
				case "p2z2":
				case "p3z3":
				case "p3z2":
				case "wbz":
				case "lbz":
				case "qbz":
				case "bbz":
				case "jbz":
				case "shbz":
				case "sh1bz":
				case "sh2bz":
				case "sh3bz":
				case "sh4bz":
				case "sh5bz":
					switch (attr) {
					case "d1q":
						lotterNums = syAttr.dsq(play.getCplay(), attr);
						break;
					case "d2q":
						lotterNums = syAttr.dsq(play.getCplay(), attr);
						break;
					case "d3q":
						lotterNums = syAttr.dsq(play.getCplay(), attr);
						break;
					case "d4q":
						lotterNums = syAttr.dsq(play.getCplay(), attr);
						break;
					case "d5q":
						lotterNums = syAttr.dsq(play.getCplay(), attr);
						break;
					case "d6q":
						lotterNums = syAttr.dsq(play.getCplay(), attr);
						break;
					case "d7q":
						lotterNums = syAttr.dsq(play.getCplay(), attr);
						break;
					case "d8q":
						lotterNums = syAttr.dsq(play.getCplay(), attr);
						break;
					case "d9q":
						lotterNums = syAttr.dsq(play.getCplay(), attr);
						break;
					case "d10q":
						lotterNums = syAttr.dsq(play.getCplay(), attr);
						break;
					case "d11q":
						lotterNums = syAttr.dsq(play.getCplay(), attr);
						break;
					case "d12q":
						lotterNums = syAttr.dsq(play.getCplay(), attr);
						break;
					case "d13q":
						lotterNums = syAttr.dsq(play.getCplay(), attr);
						break;
					case "d14q":
						lotterNums = syAttr.dsq(play.getCplay(), attr);
						break;
					case "d15q":
						lotterNums = syAttr.dsq(play.getCplay(), attr);
						break;
					case "d16q":
						lotterNums = syAttr.dsq(play.getCplay(), attr);
						break;
					case "d17q":
						lotterNums = syAttr.dsq(play.getCplay(), attr);
						break;
					case "d18q":
						lotterNums = syAttr.dsq(play.getCplay(), attr);
						break;
					case "d19q":
						lotterNums = syAttr.dsq(play.getCplay(), attr);
						break;
					case "d20q":
						lotterNums = syAttr.dsq(play.getCplay(), attr);
						break;
					case "d21q":
						lotterNums = syAttr.dsq(play.getCplay(), attr);
						break;
					case "d22q":
						lotterNums = syAttr.dsq(play.getCplay(), attr);
						break;
					case "d23q":
						lotterNums = syAttr.dsq(play.getCplay(), attr);
						break;
					case "d24q":
						lotterNums = syAttr.dsq(play.getCplay(), attr);
						break;
					case "d25q":
						lotterNums = syAttr.dsq(play.getCplay(), attr);
						break;
					case "d26q":
						lotterNums = syAttr.dsq(play.getCplay(), attr);
						break;
					case "d27q":
						lotterNums = syAttr.dsq(play.getCplay(), attr);
						break;
					case "d28q":
						lotterNums = syAttr.dsq(play.getCplay(), attr);
						break;
					case "d29q":
						lotterNums = syAttr.dsq(play.getCplay(), attr);
						break;
					case "d30q":
						lotterNums = syAttr.dsq(play.getCplay(), attr);
						break;
					case "d31q":
						lotterNums = syAttr.dsq(play.getCplay(), attr);
						break;
					case "d32q":
						lotterNums = syAttr.dsq(play.getCplay(), attr);
						break;
					case "d33q":
						lotterNums = syAttr.dsq(play.getCplay(), attr);
						break;
					case "d34q":
						lotterNums = syAttr.dsq(play.getCplay(), attr);
						break;
					case "d35q":
						lotterNums = syAttr.dsq(play.getCplay(), attr);
						break;
					case "d36q":
						lotterNums = syAttr.dsq(play.getCplay(), attr);
						break;
					case "d37q":
						lotterNums = syAttr.dsq(play.getCplay(), attr);
						break;
					case "d38q":
						lotterNums = syAttr.dsq(play.getCplay(), attr);
						break;
					case "d39q":
						lotterNums = syAttr.dsq(play.getCplay(), attr);
						break;
					case "d40q":
						lotterNums = syAttr.dsq(play.getCplay(), attr);
						break;
					case "d41q":
						lotterNums = syAttr.dsq(play.getCplay(), attr);
						break;
					case "d42q":
						lotterNums = syAttr.dsq(play.getCplay(), attr);
						break;
					case "d43q":
						lotterNums = syAttr.dsq(play.getCplay(), attr);
						break;
					case "d44q":
						lotterNums = syAttr.dsq(play.getCplay(), attr);
						break;
					case "d45q":
						lotterNums = syAttr.dsq(play.getCplay(), attr);
						break;
					case "d46q":
						lotterNums = syAttr.dsq(play.getCplay(), attr);
						break;
					case "d47q":
						lotterNums = syAttr.dsq(play.getCplay(), attr);
						break;
					case "d48q":
						lotterNums = syAttr.dsq(play.getCplay(), attr);
						break;
					case "d49q":
						lotterNums = syAttr.dsq(play.getCplay(), attr);
						break;
					}
					break;
				case "tmsx":
				case "sxzt":
				case "wxzt":
				case "lxzt":
				case "pt1x":
				case "pt2x":
				case "pt3x":
				case "pt4x":
					switch (attr) {
					case "shu":
						lotterNums = syAttr.lhcshu(cplay, attr);
						break;
					case "niu":
						lotterNums = syAttr.lhcshu(cplay, attr);
						break;
					case "hu":
						lotterNums = syAttr.lhcshu(cplay, attr);
						break;
					case "tu":
						lotterNums = syAttr.lhcshu(cplay, attr);
						break;
					case "longs":
						lotterNums = syAttr.lhcshu(cplay, attr);
						break;
					case "she":
						lotterNums = syAttr.lhcshu(cplay, attr);
						break;
					case "ma":
						lotterNums = syAttr.lhcshu(cplay, attr);
						break;
					case "yang":
						lotterNums = syAttr.lhcshu(cplay, attr);
						break;
					case "hou":
						lotterNums = syAttr.lhcshu(cplay, attr);
						break;
					case "ji":
						lotterNums = syAttr.lhcshu(cplay, attr);
						break;
					case "gou":
						lotterNums = syAttr.lhcshu(cplay, attr);
						break;
					case "zhu":
						lotterNums = syAttr.lhcshu(cplay, attr);
						break;
					}

				case "dxds":
				case "zh":
				case "hs":
					switch (attr) {
					case "dan":
						lotterNums = syAttr.lhcdsdx(cplay, attr);
						break;
					case "shuang":
						lotterNums = syAttr.lhcdsdx(cplay, attr);
						break;
					case "da":
						lotterNums = syAttr.lhcdsdx(cplay, attr);
						break;
					case "xiao":
						lotterNums = syAttr.lhcdsdx(cplay, attr);
						break;
					}
					break;

				case "jqys":
					switch (attr) {
					case "jiaxiao":
						lotterNums = syAttr.jqys(attr);
						break;
					case "yexiao":
						lotterNums = syAttr.jqys(attr);
						break;
					case "tianxiao":
						lotterNums = syAttr.jqys(attr);
						break;
					case "dixiao":
						lotterNums = syAttr.jqys(attr);
						break;
					}
					break;

				case "ts":
					switch (attr) {
					case "lingtou":
						lotterNums = syAttr.toushu(attr);
						break;
					case "yitou":
						lotterNums = syAttr.toushu(attr);
						break;
					case "ertou":
						lotterNums = syAttr.toushu(attr);
						break;
					case "santou":
						lotterNums = syAttr.toushu(attr);
						break;
					case "sitou":
						lotterNums = syAttr.toushu(attr);
						break;
					}
					break;

				case "ws":
					switch (attr) {
					case "lingwei":
						lotterNums = syAttr.weishu(attr);
						break;
					case "yiwei":
						lotterNums = syAttr.weishu(attr);
						break;
					case "erwei":
						lotterNums = syAttr.weishu(attr);
						break;
					case "sanwei":
						lotterNums = syAttr.weishu(attr);
						break;
					case "siwei":
						lotterNums = syAttr.weishu(attr);
						break;
					case "wuwei":
						lotterNums = syAttr.weishu(attr);
						break;
					case "liuwei":
						lotterNums = syAttr.weishu(attr);
						break;
					case "qiwei":
						lotterNums = syAttr.weishu(attr);
						break;
					case "bawei":
						lotterNums = syAttr.weishu(attr);
						break;
					case "jiuwei":
						lotterNums = syAttr.weishu(attr);
						break;
					}
					break;

				case "wx":
					switch (attr) {
					case "jin":
						lotterNums = syAttr.wuxin(attr);
						break;
					case "mu":
						lotterNums = syAttr.wuxin(attr);
						break;
					case "shui":
						lotterNums = syAttr.wuxin(attr);
						break;
					case "huo":
						lotterNums = syAttr.wuxin(attr);
						break;
					case "tus":
						lotterNums = syAttr.wuxin(attr);
						break;
					}
					break;

				case "pt1w":
				case "pt2w":
				case "pt3w":
				case "pt4w":
					switch (attr) {
					case "d1q":
						lotterNums = syAttr.dsw(play.getCplay(), attr);
						break;
					case "d2q":
						lotterNums = syAttr.dsw(play.getCplay(), attr);
						break;
					case "d3q":
						lotterNums = syAttr.dsw(play.getCplay(), attr);
						break;
					case "d4q":
						lotterNums = syAttr.dsw(play.getCplay(), attr);
						break;
					case "d5q":
						lotterNums = syAttr.dsw(play.getCplay(), attr);
						break;
					case "d6q":
						lotterNums = syAttr.dsw(play.getCplay(), attr);
						break;
					case "d7q":
						lotterNums = syAttr.dsw(play.getCplay(), attr);
						break;
					case "d8q":
						lotterNums = syAttr.dsw(play.getCplay(), attr);
						break;
					case "d9q":
						lotterNums = syAttr.dsw(play.getCplay(), attr);
						break;
					case "d10q":
						lotterNums = syAttr.dsw(play.getCplay(), attr);
						break;
					}
					break;

				case "zx":
					switch (attr) {
					case "erxiao":
						lotterNums = syAttr.zongxiao(attr);
						break;
					case "sanxiao":
						lotterNums = syAttr.zongxiao(attr);
						break;
					case "sixiao":
						lotterNums = syAttr.zongxiao(attr);
						break;
					case "wuxiao":
						lotterNums = syAttr.zongxiao(attr);
						break;
					case "liuxiao":
						lotterNums = syAttr.zongxiao(attr);
						break;
					case "qixiao":
						lotterNums = syAttr.zongxiao(attr);
						break;
					case "dan":
						lotterNums = syAttr.zongxiao(attr);
						break;
					case "shuang":
						lotterNums = syAttr.zongxiao(attr);
						break;
					}
					break;

				case "sb":
					switch (attr) {
					case "hongbo":
						lotterNums = syAttr.sebo(attr);
						break;
					case "lanbo":
						lotterNums = syAttr.sebo(attr);
						break;
					case "lvbo":
						lotterNums = syAttr.sebo(attr);
						break;
					}
					break;

				case "bb":
					switch (attr) {
					case "hongda":
						lotterNums = syAttr.banbo(attr);
						break;
					case "hongxiao":
						lotterNums = syAttr.banbo(attr);
						break;
					case "hongdan":
						lotterNums = syAttr.banbo(attr);
						break;
					case "hongshuang":
						lotterNums = syAttr.banbo(attr);
						break;
					case "landa":
						lotterNums = syAttr.banbo(attr);
						break;
					case "lanxiao":
						lotterNums = syAttr.banbo(attr);
						break;
					case "landan":
						lotterNums = syAttr.banbo(attr);
						break;
					case "lanshuang":
						lotterNums = syAttr.banbo(attr);
						break;
					case "lvda":
						lotterNums = syAttr.banbo(attr);
						break;
					case "lvdan":
						lotterNums = syAttr.banbo(attr);
						break;
					case "lvshuang":
						lotterNums = syAttr.banbo(attr);
						break;
					}
					break;

				case "bbb":
					switch (attr) {
					case "hongdadan":
						lotterNums = syAttr.banbanbo(attr);
						break;
					case "hongdashuang":
						lotterNums = syAttr.banbanbo(attr);
						break;
					case "hongxiaodan":
						lotterNums = syAttr.banbanbo(attr);
						break;
					case "hongxiaoshuang":
						lotterNums = syAttr.banbanbo(attr);
						break;
					case "landadan":
						lotterNums = syAttr.banbanbo(attr);
						break;
					case "landashuang":
						lotterNums = syAttr.banbanbo(attr);
						break;
					case "lanxiaodan":
						lotterNums = syAttr.banbanbo(attr);
						break;
					case "lanxiaoshuang":
						lotterNums = syAttr.banbanbo(attr);
						break;
					case "lvdadan":
						lotterNums = syAttr.banbanbo(attr);
						break;
					case "lvdashuang":
						lotterNums = syAttr.banbanbo(attr);
						break;
					case "lvxiaodan":
						lotterNums = syAttr.banbanbo(attr);
						break;
					case "lvxiaoshuang":
						lotterNums = syAttr.banbanbo(attr);
						break;
					}
					break;
				}
				if ("".equals(lotterNums)) {
					lotterNums = SystemLotter.checkRandomNum4();
					System.err.println("判断出了问题");
				}
			}
			return lotterNums;
		} catch (Exception e) {
			e.printStackTrace();
			logger.error("SystemLotter类：香港六合彩控制出现了异常： "+ e.toString());
			return SystemLotter.checkRandomNum4();
		}
	}
	
	/**
	   *   方法名：checkRandomNum5   
	   *   描述：     幸运28开奖号码生成                    
	   *   参数：    @return 
	 * @return: String
	 */
	public static String checkRandomNum5() {
		String str = "";
		int math = 0;
		for (int i = 0; i < 3; i++) {
			math = (int) (Math.random() * 10);
			str += math + ",";
		}
		return str;
	}
	
	/**
	   *   方法名：checkNum28   
	   *   描述：    幸运28开奖号码控制                  
	   *   参数：    @param cname 彩种名称
	 * @return: String
	 */
	public String checkNum28(String cname) {
		try {
			SystemAttribute syAttr = new SystemAttribute();
			CplayMaxBall cmb = new CplayMaxBall();
			List<PlayCount> pc = findSystemLotteryPlayCount(cname);
			Lotter lotters = lotterService.getCzxinxi(cname);
			String lotterNums = "";
			String cplay = cmb.maxCplay(pc);// 最大的玩法
			String[] strs = cplay.split("&");
			if ("0".equals(strs[1])) {
				return SystemLotter.checkRandomNum5();
			}
			cplay = strs[0];
			PlayCount play = findCplayMaxAttr(cname, cplay);// 下注的属性
			if (play != null) {
				String attr = cmb.maxAttributeJnd28(cplay, play, lotters);// 最大的属性
				switch (play.getCplay()) {
					case "hunhe":
						lotterNums = syAttr.jnd28Hunhe(attr);
						break;
					case "tema":
					case "tmb3":
						lotterNums = syAttr.jnd28tema(cplay, attr);
						break;
					case "bs":
						lotterNums = syAttr.jnd28bs(attr);
						break;
					case "bz":
						lotterNums = syAttr.jnd28bz(attr);
						break;
				}
			}
			if ("".equals(lotterNums)) {
				lotterNums = SystemLotter.checkRandomNum3();
				System.err.println("判断出了问题!");
			}
			return lotterNums;
		} catch (Exception e) {
			e.printStackTrace();
			logger.error("SystemLotter类：幸运28控制出现了异常： "+ e.toString());
			return SystemLotter.checkRandomNum3();
		}
	}
	
	/**
	  * 方法名：lotteryControl 
	  * 描述：    彩种控制                 
	  * 参数：    @param cname 彩种名称
	  * 参数：    @param timespace 开奖间隔
	 * @return: int
	 */
	public int lotteryControl(String cname,int timespace) {
		String checkNum = "";
		String period = "";
		String nextPeriod = "";
		switch (cname) {
			case CNAME_2FPK10:
			case CNAME_2FFT:
			case CNAME_XYSM:
				checkNum = checkNumPk10(cname);
				break;
			case CNAME_2FSSC:
				checkNum = checkNumssc(cname);
				break;
			case CNAME_2FK3:
			case CNAME_3FK3:
				checkNum = checkNumk3(cname);
				break;
			case CNAME_5F6HC:
				checkNum = checkNum6hc(cname);
				break;
			case CNAME_XY28:
				checkNum = checkNum28(cname);
				break;
		}
		Data ds2 = dataService.findLotterLastPeriod(cname, DateUtil.getCurrTime());
		if (ds2 != null) {
			if (!ds2.getLottertime().split(" ")[0].equals(ds2.getNextStopOrderTimeEpoch().split(" ")[0])) {
				period = ds2.getNextperiod();
				nextPeriod = (Long.parseLong(DateUtil.findFormatDates() + "00" + 1)) + "";
			} else {
				Data dd = dataService.findBySetCname(cname, DateUtil.findFormatDate());
				if (dd != null) {
					period = dd.getPeriod();
					nextPeriod = (Long.parseLong(dd.getPeriod()) + 1) + "";
				} else {
					Data ds1 = dataService.findNewestPeriod(cname, DateUtil.findFormatDate());
					if (ds1 != null) {
						period = ds1.getPeriod();
						nextPeriod = (Long.parseLong(period) + 1) + "";
					} else {
						logger.error("SystemLotter类---彩种开奖(不控制)："+cname+"没有下一期期号了!");
					}
				}
			}
		} else {
			Data ds1 = dataService.findNewestPeriod(cname, DateUtil.findFormatDate());
			if (ds1 != null) {
				period = ds1.getPeriod();
				nextPeriod = (Long.parseLong(period) + 1) + "";
			} else {
				logger.error("SystemLotter类---彩种开奖(不控制)："+cname+"没有下一期期号了!");
			}
		}
		SystemLotter sl = new SystemLotter();
		Data p = new Data();
		p.setCname(cname);
		p.setPeriod(period);
		p.setLotternumber(checkNum);
		p.setLottertime(DateUtil.getCurrTime());
		p.setNextperiod(nextPeriod);
		p.setNextStopOrderTimeEpoch(DateUtil.getCurrTimes(new Date().getTime() + timespace));
		sl.insertData(p);
		System.err.println("彩种："+cname+"第："+period+"进行了控制,控制后的开奖号码为："+checkNum+"!");
		return 1;
	}
	
	/**
	 * 方法名：lotteryNoControl 
	 * 描述：    彩种不控制                 
	 * 参数：    @param cname 彩种名称
	 * 参数：    @param timespace 开奖间隔
	 * @return: int
	 */
	public int lotteryNoControl(String cname,int timespace) {
		String checkNum = "";
		String period = "";
		String nextPeriod = "";
		switch (cname) {
			case CNAME_2FPK10:
			case CNAME_2FFT:
			case CNAME_XYSM:
				checkNum = checkRandomNum1();
				break;
			case CNAME_2FSSC:
				checkNum = checkRandomNum2();
				break;
			case CNAME_2FK3:
			case CNAME_3FK3:
				checkNum = checkRandomNum3();
				break;
			case CNAME_5F6HC:
				checkNum = checkRandomNum4();
				break;
			case CNAME_XY28:
				checkNum = checkRandomNum5();
				break;
		}
		Data ds0 = dataService.findLotterLastPeriod(cname, DateUtil.getCurrTime());
		if (ds0 != null) {
			if (!ds0.getLottertime().split(" ")[0].equals(ds0.getNextStopOrderTimeEpoch().split(" ")[0])) {
				period = ds0.getNextperiod();
				nextPeriod = (Long.parseLong(DateUtil.formatDateInNumber(new Date()) + "00" + 1)) + "";
			} else {
				Data dd = dataService.findBySetCname(cname, DateUtil.findFormatDate());
				if (dd != null) {
					period = dd.getPeriod();
					nextPeriod = (Long.parseLong(dd.getPeriod()) + 1) + "";
				} else {
					Data ds1 = dataService.findNewestPeriod(cname,  DateUtil.findFormatDate());
					if (ds1 != null) {
						period = ds1.getPeriod();
						nextPeriod = (Long.parseLong(period) + 1) + "";
					} else {
						logger.error("SystemLotter类---彩种开奖(不控制)："+cname+"没有下一期期号了!");
						new RuntimeException("异常!");
					}
				}
			}
		} else {
			Data ds1 = dataService.findNewestPeriod(cname,  DateUtil.findFormatDate());
			if (ds1 != null) {
				period = ds1.getPeriod();
				nextPeriod = (Long.parseLong(period) + 1) + "";
			} else {
				logger.error("SystemLotter类---彩种开奖(不控制)："+cname+"没有下一期期号了!");
				new RuntimeException("异常!");
			}
		}
		SystemLotter sl = new SystemLotter();
		Data p1 = new Data();
		p1.setCname(cname);
		p1.setPeriod(period);
		p1.setLotternumber(checkNum);
		p1.setLottertime(DateUtil.getCurrTime());
		p1.setNextperiod(nextPeriod);
		p1.setNextStopOrderTimeEpoch(DateUtil.getCurrTimes(new Date().getTime() + timespace));
		sl.insertData(p1);
		System.err.println("彩种："+cname+"第："+period+"随机开,随机的开奖号码为："+checkNum+"!");
		return 1;
	}
	
	/**
	  * 方法名：controlRatio  
	  * 描述：    根据权重计算是否控制                  
	  * 参数：    @param count 剩下的期数
	 * @return: int
	 */
	public int controlRatio() {
		double ratio = Double.parseDouble(WebsiteStateConfig.configs.get("xitongcaizjratio"))/100;//控制比率
		int weight = 2;// 控制与不控制 
		double sumWeight = 1;// 权重大小
		double d1 = 0.00;//权重区间范围
		double d2 = 0.00;
		List<Double> weights = new ArrayList<>();
		weights.add(ratio);// 1 控制
		weights.add(1 - ratio);// 2 不控制
		double randomNumber = Math.random();
		for (int i = 0; i < weights.size(); i++) {
			d2 += (weights.get(i) / sumWeight);
			if (i == 0) {
				d1 = 0;
			} else {
				d1 += (weights.get(i - 1) / sumWeight);
			}
			if (randomNumber > d1 && randomNumber < d2) {
				weight = i;
				weight += 1;
			}
		}
		return weight;
	}

	/**
	 * 方法名：check2fpk10Num 
	 * 描述： 二分PK拾开奖                     
	 * @return: void
	 */
	public void check2fpk10Num() {
		periodCreated(CNAME_2FPK10);
		while (falg) {
			try {
				int weight = controlRatio();
				double ratio = Double.parseDouble(WebsiteStateConfig.configs.get("xitongcaizjratio"))/100;//控制比率
				if (weight == 1 && ratio !=0.00) {
					lotteryControl(CNAME_2FPK10, LOTTER_TIME120);// 控制
				} else {
					lotteryNoControl(CNAME_2FPK10, LOTTER_TIME120);// 不控制
				}
				Thread.sleep(LOTTER_TIME120);
			} catch (Throwable e) {
				logger.error("SystemLotter类：二分PK10开奖出了问题：" + e.toString());
				e.printStackTrace();
			}
		}
	}
	
	/**
	 * 方法名：check2fftNum 
	 * 描述：    二分飞艇开奖                  
	 * @return: void
	 */
	public void check2fftNum() {
		periodCreated(CNAME_2FFT);
		while (falg) {
			try {
				int weight = controlRatio();
				double ratio = Double.parseDouble(WebsiteStateConfig.configs.get("xitongcaizjratio"))/100;//控制比率
				if (weight == 1 && ratio !=0.00) {
					lotteryControl(CNAME_2FFT, LOTTER_TIME120);// 控制
				} else {
					lotteryNoControl(CNAME_2FFT, LOTTER_TIME120);// 不控制
				}
				Thread.sleep(LOTTER_TIME120);
			} catch (Throwable e) {
				logger.error("SystemLotter类：二分飞艇开奖出了问题：" + e.toString());
			}
		}
	}

	/**
	 * 方法名：checkXysmNum 
	 * 描述：   幸运赛马开奖                   
	 * @return: void
	 */
	public void checkXysmNum() {
		periodCreated(CNAME_XYSM);
		while (falg) {
			try {
				int weight = controlRatio();
				double ratio = Double.parseDouble(WebsiteStateConfig.configs.get("xitongcaizjratio"))/100;//控制比率
				if (weight == 1 && ratio !=0.00) {
					lotteryControl(CNAME_XYSM, LOTTER_TIME120);// 控制
				} else {
					lotteryNoControl(CNAME_XYSM, LOTTER_TIME120);// 不控制
				}
				Thread.sleep(LOTTER_TIME300);
			} catch (Throwable e) {
				logger.error("SystemLotter类：二分飞艇开奖出了问题：" + e.toString());
			}
		}
	}

	/**
	 * 方法名：check2fsscNum 
	 * 描述：    二分时时彩开奖                  
	 * @return: void
	 */
	public void check2fsscNum() {
		periodCreated(CNAME_2FSSC);
		while (falg) {
			try {
				int weight = controlRatio();
				double ratio = Double.parseDouble(WebsiteStateConfig.configs.get("xitongcaizjratio"))/100;//控制比率
				if (weight == 1 && ratio !=0.00) {
					lotteryControl(CNAME_2FSSC, LOTTER_TIME120);// 控制
				} else {
					lotteryNoControl(CNAME_2FSSC, LOTTER_TIME120);// 不控制
				}
				Thread.sleep(LOTTER_TIME120);
			} catch (Throwable e) {
				logger.error("SystemLotter类：二分时时彩开奖出了问题：" + e.toString());
			}
		}
	}
	
	/**
	 * 方法名：check2fk3Num 
	 * 描述：    二分快3开奖                 
	 * @return: void
	 */
	public void check2fk3Num() { 
		periodCreated(CNAME_2FK3);
		while (falg) {
			try {
				int weight = controlRatio();
				double ratio = Double.parseDouble(WebsiteStateConfig.configs.get("xitongcaizjratio"))/100;//控制比率
				if (weight == 1 && ratio !=0.00) {
					lotteryControl(CNAME_2FK3, LOTTER_TIME120);// 控制
				} else {
					lotteryNoControl(CNAME_2FK3, LOTTER_TIME120);// 不控制
				}
				Thread.sleep(LOTTER_TIME120);
			} catch (Throwable e) {
				logger.error("SystemLotter类：二分快3开奖出了问题：" + e.toString());
			}
		}
	}

	/**
	 * 方法名：check3fk3Num 
	 * 描述：    三分快3开奖                 
	 * @return: void
	 */
	public void check3fk3Num() {
		periodCreated(CNAME_3FK3);
		while (falg) {
			try {
				int weight = controlRatio();
				double ratio = Double.parseDouble(WebsiteStateConfig.configs.get("xitongcaizjratio"))/100;//控制比率
				if (weight == 1 && ratio !=0.00) {
					lotteryControl(CNAME_3FK3, LOTTER_TIME180);// 控制
				} else {
					lotteryNoControl(CNAME_3FK3, LOTTER_TIME180);// 不控制
				}
				Thread.sleep(LOTTER_TIME180);
			} catch (Throwable e) {
				logger.error("SystemLotter类：三分快3开奖出了问题：" + e.toString());
			}
		}
	}

	/**
	 * 方法名：check5f6hcNum 
	 * 描述：    五分六合彩开奖                  
	 * @return: void
	 */
	public void check5f6hcNum() {
		periodCreated(CNAME_5F6HC);
		while (falg) {
			try {
				int weight = controlRatio();
				double ratio = Double.parseDouble(WebsiteStateConfig.configs.get("xitongcaizjratio"))/100;//控制比率
				if (weight == 1 && ratio !=0.00) {
					lotteryControl(CNAME_5F6HC, LOTTER_TIME300);// 控制
				} else {
					lotteryNoControl(CNAME_5F6HC, LOTTER_TIME300);// 不控制
				}
				Thread.sleep(LOTTER_TIME300);
			} catch (Throwable e) {
				logger.error("SystemLotter类：五分六合彩开奖出了问题：" + e.toString());
			}
		}
	}

	/**
	 * 方法名：checkXy28Num 
	 * 描述：    幸运28开奖                  
	 * @return: void
	 */
	public void checkXy28Num() {
		periodCreated(CNAME_XY28);
		while (falg) {
			try {
				int weight = controlRatio();
				double ratio = Double.parseDouble(WebsiteStateConfig.configs.get("xitongcaizjratio"))/100;//控制比率
				if (weight == 1 && ratio !=0.00) {
					lotteryControl(CNAME_XY28, LOTTER_TIME300);// 控制
				} else {
					lotteryNoControl(CNAME_XY28, LOTTER_TIME300);// 不控制
				}
				Thread.sleep(LOTTER_TIME300);
			} catch (Throwable e) {
				logger.error("SystemLotter类：幸运28开奖出了问题：" + e.toString());
			}
		}
	}

	/**
	  * 方法名：insertData 
	  * 描述： 插入开奖数据并开奖  
	  * 参数： @param data 
	 * @return: int
	 */
	public int insertData(Data data) {
		String period = data.getPeriod();
		String cname = data.getCname();
		Data datas = dataService.getLotteryDate(period, cname);
		Data datas1 = dataService.lotteryData(cname,period);
		if(datas1 != null){
			if (datas1.getLotternumber() != null && !"".equals(datas1.getLotternumber())) {
				data.setLotternumber(datas1.getLotternumber());
			}
		}
		data.setId(datas.getId());
		dataService.addSystemLotterInfo(data);
	    co.checkLotters(data);
	    dataService.deleteLotterSystemData(cname,period);//删除计划表里面的开奖计划数据
		return 1;
	}

	/**
	 * 方法名：checkNum 
	 * 描述：    彩种开奖线程                
	 * @return: int
	 */
	public int checkNum() {

		Thread efpk10 = new Thread() {
			public void run() {
				check2fpk10Num();
			}
		};
		
		Thread efft = new Thread() {
			public void run() {
				check2fftNum();
			}
		};
		
		Thread xysm = new Thread() {
			public void run() {
				checkXysmNum();
			}
		};
		
		Thread efssc = new Thread() {
			public void run() {
				check2fsscNum();
			}
		};
		
		Thread efk3 = new Thread() {
			public void run() {
				check2fk3Num();
			}
		};
		
		Thread sfk3 = new Thread() {
			public void run() {
				check3fk3Num();
			}
		};
		Thread wf6hc = new Thread() {
			public void run() {
				check5f6hcNum();
			}
		};
		Thread xy28 = new Thread() {
			public void run() {
				checkXy28Num();
			}
		};
		efpk10.start();
		efft.start();
		xysm.start();
		efssc.start();
		efk3.start();
		sfk3.start();
		wf6hc.start();
		xy28.start();
		return 1;
	}

	/**
	 * 方法名：checkNums 
	 * 描述：    开奖开关                  
	 * 参数：    @param open 
	 * @return: void
	 */
	public static void checkNums(int open) {
		if (open == 1) {
			SystemLotter sy = new SystemLotter();
			sy.checkNum();
		} else {
			falg = false;
		}
	}

	public static void main(String[] args) {
		SystemLotter.checkNums(1);
	}
}
