package com.ja.domain;

import java.io.Serializable;

public class InfoNotice implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = -5207150379125224989L;

	private Integer id; // 公告发布

	private String noticeName;// 公告名称

	private String noticeType; // 公告类型
	
	private String noticePicture;//公告图片

	private Integer noticeState; // 公告状态

	private String createTime; // 发布时间

	private String updateName; // 发布人

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getNoticeType() {
		return noticeType;
	}

	public void setNoticeType(String noticeType) {
		this.noticeType = noticeType;
	}

	public Integer getNoticeState() {
		return noticeState;
	}

	public void setNoticeState(Integer noticeState) {
		this.noticeState = noticeState;
	}
	
	public String getCreateTime() {
		return createTime;
	}

	public void setCreateTime(String createTime) {
		this.createTime = createTime;
	}

	public String getUpdateName() {
		return updateName;
	}

	public void setUpdateName(String updateName) {
		this.updateName = updateName;
	}
	
	public String getNoticeName() {
		return noticeName;
	}

	public void setNoticeName(String noticeName) {
		this.noticeName = noticeName;
	}

	public String getNoticePicture() {
		return noticePicture;
	}

	public void setNoticePicture(String noticePicture) {
		this.noticePicture = noticePicture;
	}

	@Override
	public String toString() {
		return "InfoNotice [id=" + id + ", noticeName=" + noticeName + ", noticeType=" + noticeType + ", noticePicture="
				+ noticePicture + ", noticeState=" + noticeState + ", createTime=" + createTime + ", updateName="
				+ updateName + "]";
	}

	public InfoNotice() {
		super();
	}
}