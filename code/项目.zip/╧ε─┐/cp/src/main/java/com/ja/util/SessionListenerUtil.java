package com.ja.util;

import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.servlet.http.HttpSessionEvent;
import javax.servlet.http.HttpSessionListener;

import com.ja.controller.ChatWebSocketHandler;
import com.ja.domain.User;
/**
 * 
 * 单点登录-强制下线-在线人数
 * @date 2018-09-14 09:52:22
 * @author GL
 *
 */
public class SessionListenerUtil implements HttpSessionListener {

	/**
	 * session的创建
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void sessionCreated(HttpSessionEvent event) {
		HttpSession session = event.getSession();
		ServletContext application = session.getServletContext();
		
		/** 由一个HashSet集保存所有的session */
		HashSet<HttpSession> sessions1 = new HashSet<HttpSession>();
		if ((HashSet<HttpSession>) application.getAttribute("sessions")!=null) {
			sessions1.addAll((HashSet<HttpSession>) application.getAttribute("sessions"));
		}
		sessions1.add(session);
		application.setAttribute("sessions", sessions1);
		/** 新创建的session均添加到HashSet集中 */
	}
   
	/**   
	 * session的销毁
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void sessionDestroyed(HttpSessionEvent event) {
		HttpSession session = event.getSession();
		ServletContext application = session.getServletContext();  
		HashSet<HttpSession> sessions = (HashSet<HttpSession>) application.getAttribute("sessions");

		/** 销毁的session均从HashSet集中移除 */
		if (sessions != null) {
			sessions.remove(session);
		}
	}

	/**
	 * 在线用户登录人数
	 * @param request 当前请求对象
	 * @return
	 */
	public static Set<User> onlineNum(HttpServletRequest request) {
		Set<User> set = new HashSet<User>();
		ServletContext application = request.getSession().getServletContext();
		@SuppressWarnings("unchecked")
		HashSet<HttpSession> sessions = (HashSet<HttpSession>) application.getAttribute("sessions");
		if (sessions != null && sessions.size() > 0) {
			for (HttpSession session : sessions) {
				User user = (User) session.getAttribute("user");
				if (user != null) {
					if(user.getState() == 1) {
						set.add(user);
					}
				}
			}
		}
		return set;
	}
	
	/**
	 * 单点登录-强制下线
	 * @param request 当前请求对象
	 * @return
	 */
	public static void singleLogin(HttpServletRequest request, String name) {
		try {
			ChatWebSocketHandler.removeName(name);
			ServletContext application = request.getSession().getServletContext();
			@SuppressWarnings("unchecked")
			HashSet<HttpSession> sessions = (HashSet<HttpSession>) application.getAttribute("sessions");
			if (sessions != null && sessions.size() > 0) {
				Iterator<HttpSession> iter = sessions.iterator();
				while (iter.hasNext()) {
					HttpSession session = iter.next();
					User user = (User) session.getAttribute("user");
					if (user != null) {
						if (name != null && name.equals(user.getName())) {
							sessions.remove(session);
							application.setAttribute("sessions", sessions);
							session.invalidate();
						}
					}
				}
			}
		} catch (Exception e) {
		}
	}

}
