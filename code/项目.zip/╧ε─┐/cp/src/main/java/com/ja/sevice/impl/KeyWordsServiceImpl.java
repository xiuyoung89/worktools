package com.ja.sevice.impl;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.ja.dao.KeyWordsMapper;
import com.ja.domain.KeyWords;
import com.ja.sevice.IKeyWordsService;

/**
 * TODO java文件
 * @Title　KeyWordsServiceImpl.java
 * @Vers　v1.0
 * @AUTH　Bean
 * @Time　2018年5月23日 上午10:24:03
 */
@Service("keyWordsService")
public class KeyWordsServiceImpl implements IKeyWordsService {

	@Resource
	private KeyWordsMapper keyWordsMapper;
	@Override
	public int insert(KeyWords keyWords) {
		return keyWordsMapper.insert(keyWords);
	}
	@Override
	public int delById(KeyWords keyWords) {
		return keyWordsMapper.delById(keyWords);
	}
	@Override
	public List<KeyWords> findAll() {
		return keyWordsMapper.selectAll();
	}

}
