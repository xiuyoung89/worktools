package com.ja.check.action;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.context.ContextLoader;

import com.ja.domain.FootBallOrder;
import com.ja.domain.Liushui;
import com.ja.domain.User;
import com.ja.sevice.FootBallOrderService;
import com.ja.sevice.IUserService;

public class FootBallCheckOrder {

	/**
	 * 注入Bean
	 */
	@Autowired
	private IUserService userService = (IUserService) ContextLoader.getCurrentWebApplicationContext()
			.getBean("userService");
	@Autowired
	private FootBallOrderService fOrderService = (FootBallOrderService) ContextLoader.getCurrentWebApplicationContext()
			.getBean("fOrderService");

	/** 计算开奖 所有 */
	public int checkFootBallMatch() {
		FootBallCheckOrder fc = new FootBallCheckOrder();
		/** 查询订单信息以及开奖信息 */
		List<FootBallOrder> info = fOrderService.getCheckOrderInfo();
		for (FootBallOrder order : info) {
			String des_in = "";
			String attrs = "";
			double rebates = 0.00;
			// 下注属性
			String attr = order.getAttributes();
			if (order.getType().equals("滚球") || order.getType().equals("单式")) {
				// 下注子属性
				attrs = order.getRebate().split(" ")[0];
				// 下注赔率
				rebates = Double.parseDouble(order.getRebate().split(" ")[1]);
				// 下注盘口信息
				des_in = order.getDes_in();
			} else {
				rebates = Double.parseDouble(order.getRebate());
			}
			// 下注金额
			double acount = order.getAcount();
			// 中奖金额
			double lotterMoney = 0.00;
			// 比赛比分
			int score_h = 0;
			int score_c = 0;
			int fh_score_h = 0;
			int fh_score_c = 0;

			int h_score = 0;
			int c_score = 0;
			int h_fh_score = 0;
			int c_fh_score = 0;
			try {
				if (attr.contains("半")) {
					fh_score_h = Integer.parseInt(order.getFh_score_h());
					fh_score_c = Integer.parseInt(order.getFh_score_c());
				} else {
					fh_score_h = Integer.parseInt(order.getFh_score_h());
					fh_score_c = Integer.parseInt(order.getFh_score_c());
					score_h = Integer.parseInt(order.getScore_h());
					score_c = Integer.parseInt(order.getScore_c());
				}
				// 主队比分-客队比分
				h_score = score_h - score_c;
				c_score = score_c - score_h;
				h_fh_score = fh_score_h - fh_score_c;
				c_fh_score = fh_score_c - fh_score_h;
			} catch (Exception e) {
				// 比赛取消,赛事无效
				if (!order.getFh_score_h().equals("no") || !order.getFh_score_c().equals("no")
						|| !order.getScore_h().equals("no") || !order.getScore_c().equals("no")) {
					order.setState(4);
					fOrderService.updateFootBallOrder(order);
					/** 赛事无效--退钱 */
					fc.returnMoney(order, order.getAcount());
				}
				continue;
			}
			// 结算
			int state = 0;
			// 退回的钱
			FootBallCheckOrder fb = new FootBallCheckOrder();
			double returnMoney = 0.00;

			// 让球 is not 0:0
			boolean s_0 = (score_h != 0) && (score_c != 0);
			boolean c_0 = score_h == score_c;

			// Test
			System.out.println("下注属性：" + attr);
			System.out.println("盘口信息：" + des_in);

			switch (order.getType()) {
			case "单式":
			case "滚球":
				if (attr.equals("全场-独赢")) {
					if (attrs.equals("主")) {
						if (score_h > score_c) {
							lotterMoney = (rebates - 1) * acount;
						}
					} else if (attrs.equals("客")) {
						if (score_h < score_c) {
							lotterMoney = (rebates - 1) * acount;
						}
					} else if (attrs.equals("和")) {
						if (score_h == score_c) {
							lotterMoney = (rebates - 1) * acount;
						}
					}
				} else if (attr.equals("全场-让球")) {
					String de1 = des_in.substring(0, 1);
					String de2 = des_in.substring(1);
					if (de2.equals("0")) {
						if (attrs.equals("主") && score_h > score_c) {
							lotterMoney = rebates * acount;
						} else if (attrs.equals("客") && score_h < score_c) {
							lotterMoney = rebates * acount;
						} else if (s_0 && c_0) {
							// 和局 退钱全部
							fb.returnMoney(order, order.getAcount());
							returnMoney = order.getAcount();
						}
					} else if (de2.equals("0/0.5")) {
						if (de1.equals("主")) {
							if (score_h == score_c) {
								if (attrs.equals("主")) {
									// 输一半 退一半的钱
									fb.returnMoney(order, order.getAcount() * 0.5);
									returnMoney = order.getAcount() * 0.5;
								}
								if (attrs.equals("客")) {
									// 受让方赢
									lotterMoney = rebates * acount;
								}
							} else if (score_h > score_c) {
								if (attrs.equals("主")) {
									// 赢一个 全赢
									lotterMoney = rebates * acount;
								}
							}
						} else if (de1.equals("客")) {
							if (score_h == score_c) {
								if (attrs.equals("客")) {
									// 输一半 退一半的钱
									fb.returnMoney(order, order.getAcount() * 0.5);
									returnMoney = order.getAcount() * 0.5;
								}
								if (attrs.equals("主")) {
									// 受让方赢
									lotterMoney = rebates * acount;
								}
							} else if (score_h < score_c) {
								if (attrs.equals("客")) {
									// 赢一个 全赢
									lotterMoney = rebates * acount;
								}
							}
						}
					} else if (de2.equals("0.5")) {
						if (de1.equals("主")) {
							if (score_h == score_c || h_score < 0) {
								if (attrs.equals("客")) {
									// 受让方赢
									lotterMoney = rebates * acount;
								}
							} else if (score_h > score_c) {
								if (attrs.equals("主")) {
									// 赢一个 全赢
									lotterMoney = rebates * acount;
								}
							}
						} else if (de1.equals("客")) {
							if (score_h == score_c || c_score < 0) {
								if (attrs.equals("主")) {
									// 受让方赢
									lotterMoney = rebates * acount;
								}
							} else if (score_h < score_c) {
								if (attrs.equals("客")) {
									// 赢一个 全赢
									lotterMoney = rebates * acount;
								}
							}
						}
					} else if (de2.equals("0.5/1")) {
						if (de1.equals("主")) {
							if (score_h == score_c || h_score < 0) {
								if (attrs.equals("客")) {
									// 受让方赢
									lotterMoney = rebates * acount;
								}
							} else if (h_score == 1) {
								if (attrs.equals("主")) {
									// 赢一个 全赢
									lotterMoney = (rebates * acount) * 0.5;
								}
							} else if (h_score > 1) {
								if (attrs.equals("主")) {
									lotterMoney = rebates * acount;
								}
							}
						} else if (de1.equals("客")) {
							if (score_h == score_c || c_score < 0) {
								if (attrs.equals("主")) {
									// 受让方赢
									lotterMoney = rebates * acount;
								}
							} else if (c_score == 1) {
								if (attrs.equals("客")) {
									// 赢一个 赢一半
									lotterMoney = (rebates * acount) * 0.5;
								}
							} else if (c_score > 1) {
								if (attrs.equals("客")) {
									lotterMoney = rebates * acount;
								}
							}
						}
					} else if (de2.equals("1")) {
						if (de1.equals("主")) {
							if (score_h == score_c || h_score < 0) {
								if (attrs.equals("客")) {
									// 受让方赢
									lotterMoney = rebates * acount;
								}
							} else if (h_score == 1) {
								// 赢一个 算平 退全部钱
								fb.returnMoney(order, order.getAcount());
								returnMoney = order.getAcount();
							} else if (h_score > 1) {
								if (attrs.equals("主")) {
									lotterMoney = rebates * acount;
								}
							}
						} else if (de1.equals("客")) {
							if (score_h == score_c || c_score < 0) {
								if (attrs.equals("主")) {
									// 受让方赢
									lotterMoney = rebates * acount;
								}
							} else if (c_score == 1) {
								// 赢一个 平 全部退钱
								fb.returnMoney(order, order.getAcount());
								returnMoney = order.getAcount();
							} else if (c_score > 1) {
								if (attrs.equals("客")) {
									lotterMoney = rebates * acount;
								}
							}
						}
					} else if (de2.equals("1/1.5")) {
						if (de1.equals("主")) {
							if (score_h == score_c || h_score < 2) {
								if (attrs.equals("客")) {
									// 受让方赢
									lotterMoney = rebates * acount;
								}
							} else if (h_score == 1) {
								// 赢一个 输一半 退一半的钱
								fb.returnMoney(order, order.getAcount() * 0.5);
								returnMoney = order.getAcount() * 0.5;

							} else if (h_score > 1) {
								if (attrs.equals("主")) {
									lotterMoney = rebates * acount;
								}
							}
						} else if (de1.equals("客")) {
							if (score_h == score_c || c_score < 2) {
								if (attrs.equals("主")) {
									// 受让方赢
									lotterMoney = rebates * acount;
								}
							} else if (c_score == 1) {
								// 赢一个 输一半 退一半的钱

							} else if (c_score > 1) {
								if (attrs.equals("客")) {
									lotterMoney = rebates * acount;
								}
							}
						}
					} else if (de2.equals("1.5")) {
						if (de1.equals("主")) {
							if (score_h == score_c || h_score < 2) {
								if (attrs.equals("客")) {
									// 受让方赢
									lotterMoney = rebates * acount;
								}
							} else if (h_score > 1) {
								if (attrs.equals("主")) {
									lotterMoney = rebates * acount;
								}
							}
						} else if (de1.equals("客")) {
							if (score_h == score_c || c_score < 2) {
								if (attrs.equals("主")) {
									// 受让方赢
									lotterMoney = rebates * acount;
								}
							} else if (c_score > 1) {
								if (attrs.equals("客")) {
									lotterMoney = rebates * acount;
								}
							}
						}

					} else if (de2.equals("1.5/2")) {
						if (de1.equals("主")) {
							if (score_h == score_c || h_score < 3) {
								if (attrs.equals("客")) {
									// 受让方赢
									lotterMoney = rebates * acount;
								}
							} else if (h_score == 2) {
								// 赢2个 输一半 退一半的钱
								fb.returnMoney(order, order.getAcount() * 0.5);
								returnMoney = order.getAcount() * 0.5;
							} else if (h_score > 2) {
								if (attrs.equals("主")) {
									lotterMoney = rebates * acount;
								}
							}
						} else if (de1.equals("客")) {
							if (score_h == score_c || c_score < 3) {
								if (attrs.equals("主")) {
									// 受让方赢
									lotterMoney = rebates * acount;
								}
							} else if (c_score == 2) {
								// 赢2个 输一半 退一半的钱
								fb.returnMoney(order, order.getAcount() * 0.5);
								returnMoney = order.getAcount() * 0.5;
							} else if (c_score > 2) {
								if (attrs.equals("客")) {
									lotterMoney = rebates * acount;
								}
							}
						}
					} else if (de2.equals("2")) {
						if (de1.equals("主")) {
							if (h_score == 2) {
								// 赢两个 平 退钱
								fb.returnMoney(order, order.getAcount());
								returnMoney = order.getAcount();
							} else if (h_score < 2) {
								if (attrs.equals("客")) {
									// 受让方赢
									lotterMoney = rebates * acount;
								}
							} else if (h_score > 2) {
								if (attrs.equals("主")) {
									lotterMoney = rebates * acount;
								}
							}
						} else if (de1.equals("客")) {
							if (c_score == 2) {
								// 赢两个 平 退钱
								fb.returnMoney(order, order.getAcount());
								returnMoney = order.getAcount();
							} else if (c_score < 2) {
								if (attrs.equals("主")) {
									// 受让方赢
									lotterMoney = rebates * acount;
								}
							} else if (c_score > 2) {
								if (attrs.equals("客")) {
									lotterMoney = rebates * acount;
								}
							}
						}
					}
				} else if (attr.equals("全场-大小")) {
					String de2 = des_in;
					int sum_score = score_h + score_c;
					try {
						String[] dsc = de2.split("/");
						String num1 = dsc[0].substring(0, 1);
						String num2 = dsc[1].substring(0, 1);
						int a1 = Integer.parseInt(num1) + 1;
						if (num1.equals(num2)) {
							if (sum_score > a1) {
								if (attrs.equals("大")) {
									lotterMoney = rebates * acount;
								}
							} else if (sum_score <= Integer.parseInt(num1)) {
								if (attrs.equals("大")) {
									fb.returnMoney(order, order.getAcount() * 0.5);
									returnMoney = order.getAcount() * 0.5;
								} else if (attrs.equals("小")) {
									lotterMoney = rebates * acount * 0.5;
								}
							}
						} else if ((Integer.parseInt(num1) + 1) == Integer.parseInt(num2)) {
							if (sum_score == a1) {
								if (attrs.equals("大")) {
									lotterMoney = rebates * acount * 0.5;
								} else if (attrs.equals("小")) {
									fb.returnMoney(order, order.getAcount() * 0.5);
									returnMoney = order.getAcount() * 0.5;
								}
							} else if (sum_score > a1) {
								if (attrs.equals("大")) {
									lotterMoney = rebates * acount;
								}
							} else if (sum_score == Integer.parseInt(num1)) {
								if (attrs.equals("小")) {
									lotterMoney = rebates * acount * 0.5;
								}
							}
						}
					} catch (Exception e) {
						if (de2.length() == 1) {
							int num1 = Integer.parseInt(de2);
							if (sum_score == num1) {
								fb.returnMoney(order, acount);
								returnMoney = acount;
							} else if (sum_score > num1) {
								if (attrs.equals("大")) {
									lotterMoney = rebates * acount;
								}
							} else if (sum_score < num1) {
								if (attrs.equals("小")) {
									lotterMoney = rebates * acount;
								}
							}
						} else {
							int num1 = Integer.parseInt(de2.substring(0, 1));
							if (sum_score <= num1) {
								if (attrs.equals("小")) {
									lotterMoney = rebates * acount;
								}
							} else if (sum_score > num1 + 1) {
								if (attrs.equals("大")) {
									lotterMoney = rebates * acount;
								}
							}
						}
					}
				} else if (attr.equals("全场-单双")) {
					int sum_score = score_h + score_c;
					if (attrs.equals("单")) {
						if (sum_score % 2 == 1) {
							lotterMoney = (rebates - 1) * acount;
						}
					} else if (attrs.equals("双")) {
						if (sum_score % 2 == 0) {
							lotterMoney = (rebates - 1) * acount;
						}
					}
				} else if (attr.equals("半场-独赢")) {
					if (attrs.equals("主")) {
						if (fh_score_h > fh_score_c) {
							lotterMoney = (rebates - 1) * acount;
						}
					} else if (attrs.equals("客")) {
						if (fh_score_h < fh_score_c) {
							lotterMoney = (rebates - 1) * acount;
						}
					} else if (attrs.equals("和")) {
						if (fh_score_h == fh_score_c) {
							lotterMoney = (rebates - 1) * acount;
						}
					}
				} else if (attr.equals("半场-让球")) {
					String de1 = des_in.substring(0, 1);
					String de2 = des_in.substring(1);
					score_h = fh_score_h;
					score_c = fh_score_c;
					h_score = h_fh_score;
					c_score = c_fh_score;
					if (de2.equals("0")) {
						if (attrs.equals("主") && score_h > score_c) {
							lotterMoney = rebates * acount;
						} else if (attrs.equals("客") && score_h < score_c) {
							lotterMoney = rebates * acount;
						} else if (s_0 && c_0) {
							// 和局 退钱全部
							fb.returnMoney(order, order.getAcount());
							returnMoney = order.getAcount();
						}
					} else if (de2.equals("0/0.5")) {
						if (de1.equals("主")) {
							if (score_h == score_c) {
								if (attrs.equals("主")) {
									// 输一半 退一半的钱
									fb.returnMoney(order, order.getAcount() * 0.5);
									returnMoney = order.getAcount() * 0.5;
								}
								if (attrs.equals("客")) {
									// 受让方赢
									lotterMoney = rebates * acount;
								}
							} else if (score_h > score_c) {
								if (attrs.equals("主")) {
									// 赢一个 全赢
									lotterMoney = rebates * acount;
								}
							}
						} else if (de1.equals("客")) {
							if (score_h == score_c) {
								if (attrs.equals("客")) {
									// 输一半 退一半的钱
									fb.returnMoney(order, order.getAcount() * 0.5);
									returnMoney = order.getAcount() * 0.5;
								}
								if (attrs.equals("主")) {
									// 受让方赢
									lotterMoney = rebates * acount;
								}
							} else if (score_h < score_c) {
								if (attrs.equals("客")) {
									// 赢一个 全赢
									lotterMoney = rebates * acount;
								}
							}
						}
					} else if (de2.equals("0.5")) {
						if (de1.equals("主")) {
							if (score_h == score_c || h_score < 0) {
								if (attrs.equals("客")) {
									// 受让方赢
									lotterMoney = rebates * acount;
								}
							} else if (score_h > score_c) {
								if (attrs.equals("主")) {
									// 赢一个 全赢
									lotterMoney = rebates * acount;
								}
							}
						} else if (de1.equals("客")) {
							if (score_h == score_c || c_score < 0) {
								if (attrs.equals("主")) {
									// 受让方赢
									lotterMoney = rebates * acount;
								}
							} else if (score_h < score_c) {
								if (attrs.equals("客")) {
									// 赢一个 全赢
									lotterMoney = rebates * acount;
								}
							}
						}
					} else if (de2.equals("0.5/1")) {
						if (de1.equals("主")) {
							if (score_h == score_c || h_score < 0) {
								if (attrs.equals("客")) {
									// 受让方赢
									lotterMoney = rebates * acount;
								}
							} else if (h_score == 1) {
								if (attrs.equals("主")) {
									// 赢一个 全赢
									lotterMoney = (rebates * acount) * 0.5;
								}
							} else if (h_score > 1) {
								if (attrs.equals("主")) {
									lotterMoney = rebates * acount;
								}
							}
						} else if (de1.equals("客")) {
							if (score_h == score_c || c_score < 0) {
								if (attrs.equals("主")) {
									// 受让方赢
									lotterMoney = rebates * acount;
								}
							} else if (c_score == 1) {
								if (attrs.equals("客")) {
									// 赢一个 赢一半
									lotterMoney = (rebates * acount) * 0.5;
								}
							} else if (c_score > 1) {
								if (attrs.equals("客")) {
									lotterMoney = rebates * acount;
								}
							}
						}
					} else if (de2.equals("1")) {
						if (de1.equals("主")) {
							if (score_h == score_c || h_score < 0) {
								if (attrs.equals("客")) {
									// 受让方赢
									lotterMoney = rebates * acount;
								}
							} else if (h_score == 1) {
								// 赢一个 算平 退全部钱
								fb.returnMoney(order, order.getAcount());
								returnMoney = order.getAcount();
							} else if (h_score > 1) {
								if (attrs.equals("主")) {
									lotterMoney = rebates * acount;
								}
							}
						} else if (de1.equals("客")) {
							if (score_h == score_c || c_score < 0) {
								if (attrs.equals("主")) {
									// 受让方赢
									lotterMoney = rebates * acount;
								}
							} else if (c_score == 1) {
								// 赢一个 平 全部退钱
								fb.returnMoney(order, order.getAcount());
								returnMoney = order.getAcount();
							} else if (c_score > 1) {
								if (attrs.equals("客")) {
									lotterMoney = rebates * acount;
								}
							}
						}
					} else if (de2.equals("1/1.5")) {
						if (de1.equals("主")) {
							if (score_h == score_c || h_score < 1) {
								if (attrs.equals("客")) {
									// 受让方赢
									lotterMoney = rebates * acount;
								}
							} else if (h_score == 1) {
								// 赢一个 输一半 退一半的钱
								fb.returnMoney(order, order.getAcount() * 0.5);
								returnMoney = order.getAcount() * 0.5;

							} else if (h_score > 1) {
								if (attrs.equals("主")) {
									lotterMoney = rebates * acount;
								}
							}
						} else if (de1.equals("客")) {
							if (score_h == score_c || c_score < 2) {
								if (attrs.equals("主")) {
									// 受让方赢
									lotterMoney = rebates * acount;
								}
							} else if (c_score == 1) {
								// 赢一个 输一半 退一半的钱

							} else if (c_score > 1) {
								if (attrs.equals("客")) {
									lotterMoney = rebates * acount;
								}
							}
						}
					} else if (de2.equals("1.5")) {
						if (de1.equals("主")) {
							if (score_h == score_c || h_score < 2) {
								if (attrs.equals("客")) {
									// 受让方赢
									lotterMoney = rebates * acount;
								}
							} else if (h_score > 1) {
								if (attrs.equals("主")) {
									lotterMoney = rebates * acount;
								}
							}
						} else if (de1.equals("客")) {
							if (score_h == score_c || c_score < 2) {
								if (attrs.equals("主")) {
									// 受让方赢
									lotterMoney = rebates * acount;
								}
							} else if (c_score > 1) {
								if (attrs.equals("客")) {
									lotterMoney = rebates * acount;
								}
							}
						}

					} else if (de2.equals("1.5/2")) {
						if (de1.equals("主")) {
							if (score_h == score_c || h_score < 3) {
								if (attrs.equals("客")) {
									// 受让方赢
									lotterMoney = rebates * acount;
								}
							} else if (h_score == 2) {
								// 赢2个 输一半 退一半的钱
								fb.returnMoney(order, order.getAcount() * 0.5);
								returnMoney = order.getAcount() * 0.5;
							} else if (h_score > 2) {
								if (attrs.equals("主")) {
									lotterMoney = rebates * acount;
								}
							}
						} else if (de1.equals("客")) {
							if (score_h == score_c || c_score < 3) {
								if (attrs.equals("主")) {
									// 受让方赢
									lotterMoney = rebates * acount;
								}
							} else if (c_score == 2) {
								// 赢2个 输一半 退一半的钱
								fb.returnMoney(order, order.getAcount() * 0.5);
								returnMoney = order.getAcount() * 0.5;
							} else if (c_score > 2) {
								if (attrs.equals("客")) {
									lotterMoney = rebates * acount;
								}
							}
						}
					} else if (de2.equals("2")) {
						if (de1.equals("主")) {
							if (h_score == 2) {
								// 赢两个 平 退钱
								fb.returnMoney(order, order.getAcount());
								returnMoney = order.getAcount();
							} else if (h_score < 2) {
								if (attrs.equals("客")) {
									// 受让方赢
									lotterMoney = rebates * acount;
								}
							} else if (h_score > 2) {
								if (attrs.equals("主")) {
									lotterMoney = rebates * acount;
								}
							}
						} else if (de1.equals("客")) {
							if (c_score == 2) {
								// 赢两个 平 退钱
								fb.returnMoney(order, order.getAcount());
								returnMoney = order.getAcount();
							} else if (c_score < 2) {
								if (attrs.equals("主")) {
									// 受让方赢
									lotterMoney = rebates * acount;
								}
							} else if (c_score > 2) {
								if (attrs.equals("客")) {
									lotterMoney = rebates * acount;
								}
							}
						}
					} else if (de2.equals("1")) {
						if (de1.equals("主")) {
							if (score_h == score_c || h_score < 0) {
								if (attrs.equals("客")) {
									// 受让方赢
									lotterMoney = (rebates - 1) * acount;
								}
							} else if (h_score == 1) {
								// 赢一个 算平 退全部钱
								fb.returnMoney(order, order.getAcount());
								returnMoney = order.getAcount();

							} else if (h_score > 1) {
								if (attrs.equals("主")) {
									lotterMoney = (rebates - 1) * acount;
								}
							}
						} else if (de1.equals("客")) {
							if (score_h == score_c || c_score < 0) {
								if (attrs.equals("主")) {
									// 受让方赢
									lotterMoney = (rebates - 1) * acount;
								}
							} else if (c_score == 1) {
								// 赢一个 平 全部退钱
								fb.returnMoney(order, order.getAcount());
								returnMoney = order.getAcount();

							} else if (c_score > 1) {
								if (attrs.equals("客")) {
									lotterMoney = (rebates - 1) * acount;
								}
							}
						}
					} else if (de2.equals("1/1.5")) {
						if (de1.equals("主")) {
							if (score_h == score_c || h_score < 2) {
								if (attrs.equals("客")) {
									// 受让方赢
									lotterMoney = (rebates - 1) * acount;
								}
							} else if (h_score == 1) {
								// 赢一个 输一半 退一半的钱
								fb.returnMoney(order, order.getAcount() * 0.5);
								returnMoney = order.getAcount() * 0.5;
							} else if (h_score > 1) {
								if (attrs.equals("主")) {
									lotterMoney = (rebates - 1) * acount;
								}
							}
						} else if (de1.equals("客")) {
							if (score_h == score_c || c_score < 2) {
								if (attrs.equals("主")) {
									// 受让方赢
									lotterMoney = (rebates - 1) * acount;
								}
							} else if (c_score == 1) {
								// 赢一个 输一半 退一半的钱
								fb.returnMoney(order, order.getAcount() * 0.5);
								returnMoney = order.getAcount() * 0.5;
							} else if (c_score > 1) {
								if (attrs.equals("客")) {
									lotterMoney = (rebates - 1) * acount;
								}
							}
						}
					} else if (de2.equals("1.5")) {
						if (de1.equals("主")) {
							if (score_h == score_c || h_score < 2) {
								if (attrs.equals("客")) {
									// 受让方赢
									lotterMoney = (rebates - 1) * acount;
								}
							} else if (h_score > 1) {
								if (attrs.equals("主")) {
									lotterMoney = (rebates - 1) * acount;
								}
							}
						} else if (de1.equals("客")) {
							if (score_h == score_c || c_score < 2) {
								if (attrs.equals("主")) {
									// 受让方赢
									lotterMoney = (rebates - 1) * acount;
								}
							} else if (c_score > 1) {
								if (attrs.equals("客")) {
									lotterMoney = (rebates - 1) * acount;
								}
							}
						}

					} else if (de2.equals("1.5/2")) {
						if (de1.equals("主")) {
							if (score_h == score_c || h_score < 3) {
								if (attrs.equals("客")) {
									// 受让方赢
									lotterMoney = (rebates - 1) * acount;
								}
							} else if (h_score == 2) {
								// 赢2个 输一半 退一半的钱
								fb.returnMoney(order, order.getAcount() * 0.5);
								returnMoney = order.getAcount() * 0.5;
							} else if (h_score > 2) {
								if (attrs.equals("主")) {
									lotterMoney = (rebates - 1) * acount;
								}
							}
						} else if (de1.equals("客")) {
							if (score_h == score_c || c_score < 3) {
								if (attrs.equals("主")) {
									// 受让方赢
									lotterMoney = (rebates - 1) * acount;
								}
							} else if (c_score == 2) {
								// 赢2个 输一半 退一半的钱
								fb.returnMoney(order, order.getAcount() * 0.5);
								returnMoney = order.getAcount() * 0.5;
							} else if (c_score > 2) {
								if (attrs.equals("客")) {
									lotterMoney = (rebates - 1) * acount;
								}
							}
						}
					} else if (de2.equals("2")) {
						if (de1.equals("主")) {
							if (h_score == 2) {
								// 赢两个 平 退钱
								fb.returnMoney(order, order.getAcount());
								returnMoney = order.getAcount();
							} else if (h_score < 2) {
								if (attrs.equals("客")) {
									// 受让方赢
									lotterMoney = (rebates - 1) * acount;
								}
							} else if (h_score > 2) {
								if (attrs.equals("主")) {
									lotterMoney = (rebates - 1) * acount;
								}
							}
						} else if (de1.equals("客")) {
							if (c_score == 2) {
								// 赢两个 平 退钱
							} else if (c_score < 2) {
								if (attrs.equals("主")) {
									// 受让方赢
									lotterMoney = (rebates - 1) * acount;
								}
							} else if (c_score > 2) {
								if (attrs.equals("客")) {
									lotterMoney = (rebates - 1) * acount;
								}
							}
						}
					}
				} else if (attr.equals("半场-大小")) {
					String de2 = des_in;
					int sum_score = fh_score_h + fh_score_c;
					try {
						String[] dsc = de2.split("/");
						String num1 = dsc[0].substring(0, 1);
						String num2 = dsc[1].substring(0, 1);
						int a1 = Integer.parseInt(num1) + 1;
						if (num1.equals(num2)) {
							if (sum_score > a1) {
								if (attrs.equals("大")) {
									lotterMoney = rebates * acount;
								}
							} else if (sum_score <= Integer.parseInt(num1)) {
								if (attrs.equals("大")) {
									fb.returnMoney(order, order.getAcount() * 0.5);
									returnMoney = order.getAcount() * 0.5;
								} else if (attrs.equals("小")) {
									lotterMoney = rebates * acount * 0.5;
								}
							}
						} else if ((Integer.parseInt(num1) + 1) == Integer.parseInt(num2)) {
							if (sum_score == a1) {
								if (attrs.equals("大")) {
									lotterMoney = rebates * acount * 0.5;
								} else if (attrs.equals("小")) {
									fb.returnMoney(order, order.getAcount() * 0.5);
									returnMoney = order.getAcount() * 0.5;
								}
							} else if (sum_score > a1) {
								if (attrs.equals("大")) {
									lotterMoney = rebates * acount;
								}
							} else if (sum_score == Integer.parseInt(num1)) {
								if (attrs.equals("小")) {
									lotterMoney = rebates * acount * 0.5;
								}
							}
						}
					} catch (Exception e) {
						if (de2.length() == 1) {
							int num1 = Integer.parseInt(de2);
							if (sum_score == num1) {
								fb.returnMoney(order, acount);
								returnMoney = acount;
							} else if (sum_score > num1) {
								if (attrs.equals("大")) {
									lotterMoney = rebates * acount;
								}
							} else if (sum_score < num1) {
								if (attrs.equals("小")) {
									lotterMoney = rebates * acount;
								}
							}
						} else {
							int num1 = Integer.parseInt(de2.substring(0, 1));
							if (sum_score <= num1) {
								if (attrs.equals("小")) {
									lotterMoney = rebates * acount;
								}
							} else if (sum_score > num1 + 1) {
								if (attrs.equals("大")) {
									lotterMoney = rebates * acount;
								}
							}
						}
					}
				}
				break;

			case "波胆":
				String[] bds1 = { "半场比分 1:0", "半场比分 0:1", "半场比分 2:0", "半场比分 0:2", "半场比分 2:1", "半场比分 1:2", "半场比分 3:0",
						"半场比分 0:3", "半场比分 3:1", "半场比分 1:3", "半场比分 3:2", "半场比分 2:3", "半场比分 4:0", "半场比分 0:4", "半场比分 4:1",
						"半场比分 1:4", "半场比分 4:2", "半场比分 2:4", "半场比分 4:3", "半场比分 3:4", "半场比分 0:0", "半场比分 1:1", "半场比分 2:2",
						"半场比分 3:3", "半场比分 4:4", "半场比分 其他" };
				String[] bds2 = { "全场比分 1:0", "全场比分 0:1", "全场比分 2:0", "全场比分 0:2", "全场比分 2:1", "全场比分 1:2", "全场比分 3:0",
						"全场比分 0:3", "全场比分 3:1", "全场比分 1:3", "全场比分 3:2", "全场比分 2:3", "全场比分 4:0", "全场比分 0:4", "全场比分 4:1",
						"全场比分 1:4", "全场比分 4:2", "全场比分 2:4", "全场比分 4:3", "全场比分 3:4", "全场比分 0:0", "全场比分 1:1", "全场比分 2:2",
						"全场比分 3:3", "全场比分 4:4", "全场比分 其他" };
				String bc_bf = "半场比分 " + fh_score_h + ":" + fh_score_c;
				String qc_bf = score_h + ":" + score_c;
				if (attr.contains("半场")) {
					for (int i = 0; i < bds1.length; i++) {
						if (attr.equals(bds1[i]) && ("半场比分 " + bc_bf).equals(bds1[i])) {
							lotterMoney = (rebates - 1) * acount;
						}
					}
				} else {
					for (int i = 0; i < bds2.length; i++) {
						if (attr.equals(bds2[i]) && ("全场比分 " + qc_bf).equals(bds2[i])) {
							lotterMoney = (rebates - 1) * acount;
						}
					}
				}
				break;
			case "入球数":
				if (attr.equals("0~1")) {
					if (score_h + score_c == 0 || score_h + score_c == 1) {
						lotterMoney = (rebates - 1) * acount;
					}
				} else if (attr.equals("2~3")) {
					if (score_h + score_c == 2 || score_h + score_c == 3) {
						lotterMoney = (rebates - 1) * acount;
					}
				} else if (attr.equals("4~6")) {
					if (score_h + score_c == 4 || score_h + score_c == 5 || score_h + score_c == 6) {
						lotterMoney = (rebates - 1) * acount;
					}
				} else if (attr.equals("7up")) {
					if (score_h + score_c > 6) {
						lotterMoney = (rebates - 1) * acount;
					}
				}
				break;

			case "半全场":
				if (attr.equals("主/主")) {
					if (score_h > score_c && fh_score_h > fh_score_c) {
						lotterMoney = (rebates - 1) * acount;
					}
				} else if (attr.equals("主/和")) {
					if (score_h == score_c && fh_score_h > fh_score_c) {
						lotterMoney = (rebates - 1) * acount;
					}
				} else if (attr.equals("主/客")) {
					if (score_h > score_c && fh_score_h < fh_score_c) {
						lotterMoney = (rebates - 1) * acount;
					}
				} else if (attr.equals("和/主")) {
					if (score_h == score_c && fh_score_h > fh_score_c) {
						lotterMoney = (rebates - 1) * acount;
					}
				} else if (attr.equals("和/和")) {
					if (score_h == score_c && fh_score_h == fh_score_c) {
						lotterMoney = (rebates - 1) * acount;
					}
				} else if (attr.equals("和/客")) {
					if (score_h < score_c && fh_score_h == fh_score_c) {
						lotterMoney = (rebates - 1) * acount;
					}
				} else if (attr.equals("客/主")) {
					if (score_h > score_c && fh_score_h < fh_score_c) {
						lotterMoney = (rebates - 1) * acount;
					}
				} else if (attr.equals("客/和")) {
					if (score_h == score_c && fh_score_h < fh_score_c) {
						lotterMoney = (rebates - 1) * acount;
					}
				} else if (attr.equals("客/客")) {
					if (score_h < score_c && fh_score_h < fh_score_c) {
						lotterMoney = (rebates - 1) * acount;
					}
				}
				break;
			}
			/** 插入开奖信息 */
			String state1 = "";
			/** 输或者输一半 那么就彻底结束 */
			if (lotterMoney == 0.0 && returnMoney != 0.0 || lotterMoney == 0.0 && returnMoney == 0.0) {
				state = 2;
				state1 = "未中奖";
			}
			if (lotterMoney != 0.0) {// 中奖
				state = 3;
				state1 = "已中奖";
			}
			state = 1;
			order.setLotter_money(lotterMoney);
			order.setState(state);
			order.setLtime(new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date()));
			order.setReturn_money(returnMoney);
			System.out.println("订单状态:" + state1 + "   中奖金额:" + lotterMoney + "   退钱金额:" + returnMoney); // TODO PT
			fOrderService.updateFootBallOrder(order);
			if (lotterMoney != 0.0) {
				User user = userService.getUserByid(order.getUser_id());
				Liushui l = new Liushui();
				double gxyue = user.getBalance() + lotterMoney;
				user.setBalance(gxyue);
				l.setHuiyuanzh(user.getName());
				l.setBdtype("足彩派奖");
				l.setBdqjine(user.getBalance());
				l.setBdjine(lotterMoney);
				l.setBdhjine(gxyue);
				l.setCreatetime(new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date()));
				l.setOrdernum(order.getOrder_num());
				l.setCname(order.getType());
				l.setPeriod(order.getTypes());
				l.setCzname(user.getName());
				l.setBeizhu("派奖成功");
				l.setState(true);
				l.setUserid(user.getId());
				userService.updateMoney(user, l);
				if (user.getState() == 1) {
				}
			}
		}
		return 1;

	}

	/** moveData */
	public int checkSeries() { // TODO moveDdat
		FootBallCheckOrder check = new FootBallCheckOrder();
		List<FootBallOrder> fb = fOrderService.getCheckOrderSeries();
		for (FootBallOrder o : fb) {
			List<FootBallOrder> fbo = fOrderService.getCheckOrderSeriesInfo(o.getOrder_num());
			// 没全部开奖
			boolean sign = false;
			for (FootBallOrder or : fbo) {
				if ("no".equals(or.getScore_h())) {
					sign = true;
				}
			}
			// 判断是子订单 或者是 最后一条订单
			for (int i = 0; i < fbo.size(); i++) {
				if (sign == true) {
					break;
				}
				boolean flag = true;
				if (i != fbo.size() - 1) {
					flag = false;
				}
				int oo = check.checkSeriesOrder(fbo.get(i), flag, i);
				if (oo == 1) {
					return 1;
				}
			}
		}
		return 1;
	}

	/** 计算开奖综合过关 */
	public int checkSeriesOrder(FootBallOrder order, boolean sign, int count) { // TODO checkSeries
		FootBallCheckOrder fc = new FootBallCheckOrder();
		String des_in = "";
		String attrs = "";
		double rebates = 0.00;
		// 下注属性
		String attr = order.getAttributes();
		// 下注子属性
		attrs = order.getRebate().split(" ")[0];
		// 下注盘口信息
		des_in = order.getDes_in();
		// 下注赔率
		rebates = Double.parseDouble(order.getRebate().split(" ")[1]);
		// 上一次的中奖金额
		double lastMoney = 0.00;
		if (count != 0) {
			lastMoney = fOrderService.getLastMoney(order.getSort()).getLotter_money();
		}
		// 下注金额
		double acount = order.getAcount();
		// 判断是不是第一次
		if (lastMoney != 0.0) {
			acount = lastMoney;
		}
		// 中奖金额
		double lotterMoney = 0.00;
		// 比赛比分
		int score_h = 0;
		int score_c = 0;
		int fh_score_h = 0;
		int fh_score_c = 0;
		// 比分之差
		int h_score = 0;
		int c_score = 0;
		int h_fh_score = 0;
		int c_fh_score = 0;
		// 订单状态
		int state = 0;
		try {
			if (attr.contains("半")) {
				fh_score_h = Integer.parseInt(order.getFh_score_h());
				fh_score_c = Integer.parseInt(order.getFh_score_c());
			} else {
				fh_score_h = Integer.parseInt(order.getFh_score_h());
				fh_score_c = Integer.parseInt(order.getFh_score_c());
				score_h = Integer.parseInt(order.getScore_h());
				score_c = Integer.parseInt(order.getScore_c());
			}
			// 主队比分-客队比分
			h_score = score_h - score_c;
			c_score = score_c - score_h;
			h_fh_score = fh_score_h - fh_score_c;
			c_fh_score = fh_score_c - fh_score_h;
		} catch (Exception e) {
			// 比赛取消,赛事无效
			order.setState(4);
			fOrderService.updateFootBallOrder(order);
			/** 赛事无效--退钱 */
			fc.returnMoney(order, order.getAcount());
			return 0;
		}

		// 退回的钱
		FootBallCheckOrder fb = new FootBallCheckOrder();
		double returnMoney = 0.00;

		// 让球 is not 0:0
		boolean s_0 = (score_h != 0) && (score_c != 0);
		boolean c_0 = score_h == score_c;

		if (attr.equals("全场-独赢")) {
			if (attrs.equals("主")) {
				if (score_h > score_c) {
					lotterMoney = (rebates - 1) * acount;
				}
			} else if (attrs.equals("客")) {
				if (score_h < score_c) {
					lotterMoney = (rebates - 1) * acount;
				}
			} else if (attrs.equals("和")) {
				if (score_h == score_c) {
					lotterMoney = (rebates - 1) * acount;
				}
			}
		} else if (attr.equals("全场-让球")) {
			String de1 = des_in.substring(0, 1);
			String de2 = des_in.substring(1);
			if (de2.equals("0")) {
				if (attrs.equals("主") && score_h > score_c) {
					lotterMoney = rebates * acount;
				} else if (attrs.equals("客") && score_h < score_c) {
					lotterMoney = rebates * acount;
				} else if (s_0 && c_0) {
					// 和局 退钱全部
					fb.returnMoney(order, order.getAcount());
					returnMoney = order.getAcount();
				}
			} else if (de2.equals("0/0.5")) {
				if (de1.equals("主")) {
					if (score_h == score_c) {
						if (attrs.equals("主")) {
							// 输一半 退一半的钱
							fb.returnMoney(order, order.getAcount() * 0.5);
							returnMoney = order.getAcount() * 0.5;
						}
						if (attrs.equals("客")) {
							// 受让方赢
							lotterMoney = rebates * acount;
						}
					} else if (score_h > score_c) {
						if (attrs.equals("主")) {
							// 赢一个 全赢
							lotterMoney = rebates * acount;
						}
					}
				} else if (de1.equals("客")) {
					if (score_h == score_c) {
						if (attrs.equals("客")) {
							// 输一半 退一半的钱
							fb.returnMoney(order, order.getAcount() * 0.5);
							returnMoney = order.getAcount() * 0.5;
						}
						if (attrs.equals("主")) {
							// 受让方赢
							lotterMoney = rebates * acount;
						}
					} else if (score_h < score_c) {
						if (attrs.equals("客")) {
							// 赢一个 全赢
							lotterMoney = rebates * acount;
						}
					}
				}
			} else if (de2.equals("0.5")) {
				if (de1.equals("主")) {
					if (score_h == score_c || h_score < 0) {
						if (attrs.equals("客")) {
							// 受让方赢
							lotterMoney = rebates * acount;
						}
					} else if (score_h > score_c) {
						if (attrs.equals("主")) {
							// 赢一个 全赢
							lotterMoney = rebates * acount;
						}
					}
				} else if (de1.equals("客")) {
					if (score_h == score_c || c_score < 0) {
						if (attrs.equals("主")) {
							// 受让方赢
							lotterMoney = rebates * acount;
						}
					} else if (score_h < score_c) {
						if (attrs.equals("客")) {
							// 赢一个 全赢
							lotterMoney = rebates * acount;
						}
					}
				}
			} else if (de2.equals("0.5/1")) {
				if (de1.equals("主")) {
					if (score_h == score_c || h_score < 0) {
						if (attrs.equals("客")) {
							// 受让方赢
							lotterMoney = rebates * acount;
						}
					} else if (h_score == 1) {
						if (attrs.equals("主")) {
							// 赢一个 全赢
							lotterMoney = (rebates * acount) * 0.5;
						}
					} else if (h_score > 1) {
						if (attrs.equals("主")) {
							lotterMoney = rebates * acount;
						}
					}
				} else if (de1.equals("客")) {
					if (score_h == score_c || c_score < 0) {
						if (attrs.equals("主")) {
							// 受让方赢
							lotterMoney = rebates * acount;
						}
					} else if (c_score == 1) {
						if (attrs.equals("客")) {
							// 赢一个 赢一半
							lotterMoney = (rebates * acount) * 0.5;
						}
					} else if (c_score > 1) {
						if (attrs.equals("客")) {
							lotterMoney = rebates * acount;
						}
					}
				}
			} else if (de2.equals("1")) {
				if (de1.equals("主")) {
					if (score_h == score_c || h_score < 0) {
						if (attrs.equals("客")) {
							// 受让方赢
							lotterMoney = rebates * acount;
						}
					} else if (h_score == 1) {
						// 赢一个 算平 退全部钱
						fb.returnMoney(order, order.getAcount());
						returnMoney = order.getAcount();
					} else if (h_score > 1) {
						if (attrs.equals("主")) {
							lotterMoney = rebates * acount;
						}
					}
				} else if (de1.equals("客")) {
					if (score_h == score_c || c_score < 0) {
						if (attrs.equals("主")) {
							// 受让方赢
							lotterMoney = rebates * acount;
						}
					} else if (c_score == 1) {
						// 赢一个 平 全部退钱
						fb.returnMoney(order, order.getAcount());
						returnMoney = order.getAcount();
					} else if (c_score > 1) {
						if (attrs.equals("客")) {
							lotterMoney = rebates * acount;
						}
					}
				}
			} else if (de2.equals("1/1.5")) {
				if (de1.equals("主")) {
					if (score_h == score_c || h_score < 2) {
						if (attrs.equals("客")) {
							// 受让方赢
							lotterMoney = rebates * acount;
						}
					} else if (h_score == 1) {
						// 赢一个 输一半 退一半的钱
						fb.returnMoney(order, order.getAcount() * 0.5);
						returnMoney = order.getAcount() * 0.5;

					} else if (h_score > 1) {
						if (attrs.equals("主")) {
							lotterMoney = rebates * acount;
						}
					}
				} else if (de1.equals("客")) {
					if (score_h == score_c || c_score < 2) {
						if (attrs.equals("主")) {
							// 受让方赢
							lotterMoney = rebates * acount;
						}
					} else if (c_score == 1) {
						// 赢一个 输一半 退一半的钱

					} else if (c_score > 1) {
						if (attrs.equals("客")) {
							lotterMoney = rebates * acount;
						}
					}
				}
			} else if (de2.equals("1.5")) {
				if (de1.equals("主")) {
					if (score_h == score_c || h_score < 2) {
						if (attrs.equals("客")) {
							// 受让方赢
							lotterMoney = rebates * acount;
						}
					} else if (h_score > 1) {
						if (attrs.equals("主")) {
							lotterMoney = rebates * acount;
						}
					}
				} else if (de1.equals("客")) {
					if (score_h == score_c || c_score < 2) {
						if (attrs.equals("主")) {
							// 受让方赢
							lotterMoney = rebates * acount;
						}
					} else if (c_score > 1) {
						if (attrs.equals("客")) {
							lotterMoney = rebates * acount;
						}
					}
				}

			} else if (de2.equals("1.5/2")) {
				if (de1.equals("主")) {
					if (score_h == score_c || h_score < 3) {
						if (attrs.equals("客")) {
							// 受让方赢
							lotterMoney = rebates * acount;
						}
					} else if (h_score == 2) {
						// 赢2个 输一半 退一半的钱
						fb.returnMoney(order, order.getAcount() * 0.5);
						returnMoney = order.getAcount() * 0.5;
					} else if (h_score > 2) {
						if (attrs.equals("主")) {
							lotterMoney = rebates * acount;
						}
					}
				} else if (de1.equals("客")) {
					if (score_h == score_c || c_score < 3) {
						if (attrs.equals("主")) {
							// 受让方赢
							lotterMoney = rebates * acount;
						}
					} else if (c_score == 2) {
						// 赢2个 输一半 退一半的钱
						fb.returnMoney(order, order.getAcount() * 0.5);
						returnMoney = order.getAcount() * 0.5;
					} else if (c_score > 2) {
						if (attrs.equals("客")) {
							lotterMoney = rebates * acount;
						}
					}
				}
			} else if (de2.equals("2")) {
				if (de1.equals("主")) {
					if (h_score == 2) {
						// 赢两个 平 退钱
						fb.returnMoney(order, order.getAcount());
						returnMoney = order.getAcount();
					} else if (h_score < 2) {
						if (attrs.equals("客")) {
							// 受让方赢
							lotterMoney = rebates * acount;
						}
					} else if (h_score > 2) {
						if (attrs.equals("主")) {
							lotterMoney = rebates * acount;
						}
					}
				} else if (de1.equals("客")) {
					if (c_score == 2) {
						// 赢两个 平 退钱
						fb.returnMoney(order, order.getAcount());
						returnMoney = order.getAcount();
					} else if (c_score < 2) {
						if (attrs.equals("主")) {
							// 受让方赢
							lotterMoney = rebates * acount;
						}
					} else if (c_score > 2) {
						if (attrs.equals("客")) {
							lotterMoney = rebates * acount;
						}
					}
				}
			}
		} else if (attr.equals("全场-大小")) {
			String de2 = des_in;
			int sum_score = score_h + score_c;
			try {
				String[] dsc = de2.split("/");
				String num1 = dsc[0].substring(0, 1);
				String num2 = dsc[1].substring(0, 1);
				int a1 = Integer.parseInt(num1) + 1;
				if (num1.equals(num2)) {
					if (sum_score > a1) {
						if (attrs.equals("大")) {
							lotterMoney = rebates * acount;
						}
					} else if (sum_score <= Integer.parseInt(num1)) {
						if (attrs.equals("大")) {
							fb.returnMoney(order, order.getAcount() * 0.5);
							returnMoney = order.getAcount() * 0.5;
						} else if (attrs.equals("小")) {
							lotterMoney = rebates * acount * 0.5;
						}
					}
				} else if ((Integer.parseInt(num1) + 1) == Integer.parseInt(num2)) {
					if (sum_score == a1) {
						if (attrs.equals("大")) {
							lotterMoney = rebates * acount * 0.5;
						} else if (attrs.equals("小")) {
							fb.returnMoney(order, order.getAcount() * 0.5);
							returnMoney = order.getAcount() * 0.5;
						}
					} else if (sum_score > a1) {
						if (attrs.equals("大")) {
							lotterMoney = rebates * acount;
						}
					} else if (sum_score == Integer.parseInt(num1)) {
						if (attrs.equals("小")) {
							lotterMoney = rebates * acount * 0.5;
						}
					}
				}
			} catch (Exception e) {
				if (de2.length() == 1) {
					int num1 = Integer.parseInt(de2);
					if (sum_score == num1) {
						fb.returnMoney(order, acount);
						returnMoney = acount;
					} else if (sum_score > num1) {
						if (attrs.equals("大")) {
							lotterMoney = rebates * acount;
						}
					} else if (sum_score < num1) {
						if (attrs.equals("小")) {
							lotterMoney = rebates * acount;
						}
					}
				} else {
					int num1 = Integer.parseInt(de2.substring(0, 1));
					if (sum_score <= num1) {
						if (attrs.equals("小")) {
							lotterMoney = rebates * acount;
						}
					} else if (sum_score > num1 + 1) {
						if (attrs.equals("大")) {
							lotterMoney = rebates * acount;
						}
					}
				}
			}

		} else if (attr.equals("全场-单双")) {
			int sum_score = score_h + score_c;
			if (attrs.equals("单")) {
				if (sum_score % 2 == 1) {
					lotterMoney = (rebates - 1) * acount;
				}
			} else if (attrs.equals("双")) {
				if (sum_score % 2 == 0) {
					lotterMoney = (rebates - 1) * acount;
				}
			}
		} else if (attr.equals("半场-独赢")) {
			if (attrs.equals("主")) {
				if (fh_score_h > fh_score_c) {
					lotterMoney = (rebates - 1) * acount;
				}
			} else if (attrs.equals("客")) {
				if (fh_score_h < fh_score_c) {
					lotterMoney = (rebates - 1) * acount;
				}
			} else if (attrs.equals("和")) {
				if (fh_score_h == fh_score_c) {
					lotterMoney = (rebates - 1) * acount;
				}
			}
		} else if (attr.equals("半场-让球")) {
			String de1 = des_in.substring(0, 1);
			String de2 = des_in.substring(1);
			score_h = fh_score_h;
			score_c = fh_score_c;
			h_score = h_fh_score;
			c_score = c_fh_score;
			if (de2.equals("0")) {
				if (attrs.equals("主") && score_h > score_c) {
					lotterMoney = rebates * acount;
				} else if (attrs.equals("客") && score_h < score_c) {
					lotterMoney = rebates * acount;
				} else if (s_0 && c_0) {
					// 和局 退钱全部
					fb.returnMoney(order, order.getAcount());
					returnMoney = order.getAcount();
				}
			} else if (de2.equals("0/0.5")) {
				if (de1.equals("主")) {
					if (score_h == score_c) {
						if (attrs.equals("主")) {
							// 输一半 退一半的钱
							fb.returnMoney(order, order.getAcount() * 0.5);
							returnMoney = order.getAcount() * 0.5;
						}
						if (attrs.equals("客")) {
							// 受让方赢
							lotterMoney = rebates * acount;
						}
					} else if (score_h > score_c) {
						if (attrs.equals("主")) {
							// 赢一个 全赢
							lotterMoney = rebates * acount;
						}
					}
				} else if (de1.equals("客")) {
					if (score_h == score_c) {
						if (attrs.equals("客")) {
							// 输一半 退一半的钱
							fb.returnMoney(order, order.getAcount() * 0.5);
							returnMoney = order.getAcount() * 0.5;
						}
						if (attrs.equals("主")) {
							// 受让方赢
							lotterMoney = rebates * acount;
						}
					} else if (score_h < score_c) {
						if (attrs.equals("客")) {
							// 赢一个 全赢
							lotterMoney = rebates * acount;
						}
					}
				}
			} else if (de2.equals("0.5")) {
				if (de1.equals("主")) {
					if (score_h == score_c || h_score < 0) {
						if (attrs.equals("客")) {
							// 受让方赢
							lotterMoney = rebates * acount;
						}
					} else if (score_h > score_c) {
						if (attrs.equals("主")) {
							// 赢一个 全赢
							lotterMoney = rebates * acount;
						}
					}
				} else if (de1.equals("客")) {
					if (score_h == score_c || c_score < 0) {
						if (attrs.equals("主")) {
							// 受让方赢
							lotterMoney = rebates * acount;
						}
					} else if (score_h < score_c) {
						if (attrs.equals("客")) {
							// 赢一个 全赢
							lotterMoney = rebates * acount;
						}
					}
				}
			} else if (de2.equals("0.5/1")) {
				if (de1.equals("主")) {
					if (score_h == score_c || h_score < 0) {
						if (attrs.equals("客")) {
							// 受让方赢
							lotterMoney = rebates * acount;
						}
					} else if (h_score == 1) {
						if (attrs.equals("主")) {
							// 赢一个 全赢
							lotterMoney = (rebates * acount) * 0.5;
						}
					} else if (h_score > 1) {
						if (attrs.equals("主")) {
							lotterMoney = rebates * acount;
						}
					}
				} else if (de1.equals("客")) {
					if (score_h == score_c || c_score < 0) {
						if (attrs.equals("主")) {
							// 受让方赢
							lotterMoney = rebates * acount;
						}
					} else if (c_score == 1) {
						if (attrs.equals("客")) {
							// 赢一个 赢一半
							lotterMoney = (rebates * acount) * 0.5;
						}
					} else if (c_score > 1) {
						if (attrs.equals("客")) {
							lotterMoney = rebates * acount;
						}
					}
				}
			} else if (de2.equals("1")) {
				if (de1.equals("主")) {
					if (score_h == score_c || h_score < 0) {
						if (attrs.equals("客")) {
							// 受让方赢
							lotterMoney = rebates * acount;
						}
					} else if (h_score == 1) {
						// 赢一个 算平 退全部钱
						fb.returnMoney(order, order.getAcount());
						returnMoney = order.getAcount();
					} else if (h_score > 1) {
						if (attrs.equals("主")) {
							lotterMoney = rebates * acount;
						}
					}
				} else if (de1.equals("客")) {
					if (score_h == score_c || c_score < 0) {
						if (attrs.equals("主")) {
							// 受让方赢
							lotterMoney = rebates * acount;
						}
					} else if (c_score == 1) {
						// 赢一个 平 全部退钱
						fb.returnMoney(order, order.getAcount());
						returnMoney = order.getAcount();
					} else if (c_score > 1) {
						if (attrs.equals("客")) {
							lotterMoney = rebates * acount;
						}
					}
				}
			} else if (de2.equals("1/1.5")) {
				if (de1.equals("主")) {
					if (score_h == score_c || h_score < 1) {
						if (attrs.equals("客")) {
							// 受让方赢
							lotterMoney = rebates * acount;
						}
					} else if (h_score == 1) {
						// 赢一个 输一半 退一半的钱
						fb.returnMoney(order, order.getAcount() * 0.5);
						returnMoney = order.getAcount() * 0.5;

					} else if (h_score > 1) {
						if (attrs.equals("主")) {
							lotterMoney = rebates * acount;
						}
					}
				} else if (de1.equals("客")) {
					if (score_h == score_c || c_score < 2) {
						if (attrs.equals("主")) {
							// 受让方赢
							lotterMoney = rebates * acount;
						}
					} else if (c_score == 1) {
						// 赢一个 输一半 退一半的钱

					} else if (c_score > 1) {
						if (attrs.equals("客")) {
							lotterMoney = rebates * acount;
						}
					}
				}
			} else if (de2.equals("1.5")) {
				if (de1.equals("主")) {
					if (score_h == score_c || h_score < 2) {
						if (attrs.equals("客")) {
							// 受让方赢
							lotterMoney = rebates * acount;
						}
					} else if (h_score > 1) {
						if (attrs.equals("主")) {
							lotterMoney = rebates * acount;
						}
					}
				} else if (de1.equals("客")) {
					if (score_h == score_c || c_score < 2) {
						if (attrs.equals("主")) {
							// 受让方赢
							lotterMoney = rebates * acount;
						}
					} else if (c_score > 1) {
						if (attrs.equals("客")) {
							lotterMoney = rebates * acount;
						}
					}
				}

			} else if (de2.equals("1.5/2")) {
				if (de1.equals("主")) {
					if (score_h == score_c || h_score < 3) {
						if (attrs.equals("客")) {
							// 受让方赢
							lotterMoney = rebates * acount;
						}
					} else if (h_score == 2) {
						// 赢2个 输一半 退一半的钱
						fb.returnMoney(order, order.getAcount() * 0.5);
						returnMoney = order.getAcount() * 0.5;
					} else if (h_score > 2) {
						if (attrs.equals("主")) {
							lotterMoney = rebates * acount;
						}
					}
				} else if (de1.equals("客")) {
					if (score_h == score_c || c_score < 3) {
						if (attrs.equals("主")) {
							// 受让方赢
							lotterMoney = rebates * acount;
						}
					} else if (c_score == 2) {
						// 赢2个 输一半 退一半的钱
						fb.returnMoney(order, order.getAcount() * 0.5);
						returnMoney = order.getAcount() * 0.5;
					} else if (c_score > 2) {
						if (attrs.equals("客")) {
							lotterMoney = rebates * acount;
						}
					}
				}
			} else if (de2.equals("2")) {
				if (de1.equals("主")) {
					if (h_score == 2) {
						// 赢两个 平 退钱
						fb.returnMoney(order, order.getAcount());
						returnMoney = order.getAcount();
					} else if (h_score < 2) {
						if (attrs.equals("客")) {
							// 受让方赢
							lotterMoney = rebates * acount;
						}
					} else if (h_score > 2) {
						if (attrs.equals("主")) {
							lotterMoney = rebates * acount;
						}
					}
				} else if (de1.equals("客")) {
					if (c_score == 2) {
						// 赢两个 平 退钱
						fb.returnMoney(order, order.getAcount());
						returnMoney = order.getAcount();
					} else if (c_score < 2) {
						if (attrs.equals("主")) {
							// 受让方赢
							lotterMoney = rebates * acount;
						}
					} else if (c_score > 2) {
						if (attrs.equals("客")) {
							lotterMoney = rebates * acount;
						}
					}
				}
			} else if (de2.equals("1")) {
				if (de1.equals("主")) {
					if (score_h == score_c || h_score < 0) {
						if (attrs.equals("客")) {
							// 受让方赢
							lotterMoney = (rebates - 1) * acount;
						}
					} else if (h_score == 1) {
						// 赢一个 算平 退全部钱
						fb.returnMoney(order, order.getAcount());
						returnMoney = order.getAcount();

					} else if (h_score > 1) {
						if (attrs.equals("主")) {
							lotterMoney = (rebates - 1) * acount;
						}
					}
				} else if (de1.equals("客")) {
					if (score_h == score_c || c_score < 0) {
						if (attrs.equals("主")) {
							// 受让方赢
							lotterMoney = (rebates - 1) * acount;
						}
					} else if (c_score == 1) {
						// 赢一个 平 全部退钱
						fb.returnMoney(order, order.getAcount());
						returnMoney = order.getAcount();

					} else if (c_score > 1) {
						if (attrs.equals("客")) {
							lotterMoney = (rebates - 1) * acount;
						}
					}
				}
			} else if (de2.equals("1/1.5")) {
				if (de1.equals("主")) {
					if (score_h == score_c || h_score < 2) {
						if (attrs.equals("客")) {
							// 受让方赢
							lotterMoney = (rebates - 1) * acount;
						}
					} else if (h_score == 1) {
						// 赢一个 输一半 退一半的钱
						fb.returnMoney(order, order.getAcount() * 0.5);
						returnMoney = order.getAcount() * 0.5;
					} else if (h_score > 1) {
						if (attrs.equals("主")) {
							lotterMoney = (rebates - 1) * acount;
						}
					}
				} else if (de1.equals("客")) {
					if (score_h == score_c || c_score < 2) {
						if (attrs.equals("主")) {
							// 受让方赢
							lotterMoney = (rebates - 1) * acount;
						}
					} else if (c_score == 1) {
						// 赢一个 输一半 退一半的钱
						fb.returnMoney(order, order.getAcount() * 0.5);
						returnMoney = order.getAcount() * 0.5;
					} else if (c_score > 1) {
						if (attrs.equals("客")) {
							lotterMoney = (rebates - 1) * acount;
						}
					}
				}
			} else if (de2.equals("1.5")) {
				if (de1.equals("主")) {
					if (score_h == score_c || h_score < 2) {
						if (attrs.equals("客")) {
							// 受让方赢
							lotterMoney = (rebates - 1) * acount;
						}
					} else if (h_score > 1) {
						if (attrs.equals("主")) {
							lotterMoney = (rebates - 1) * acount;
						}
					}
				} else if (de1.equals("客")) {
					if (score_h == score_c || c_score < 2) {
						if (attrs.equals("主")) {
							// 受让方赢
							lotterMoney = (rebates - 1) * acount;
						}
					} else if (c_score > 1) {
						if (attrs.equals("客")) {
							lotterMoney = (rebates - 1) * acount;
						}
					}
				}

			} else if (de2.equals("1.5/2")) {
				if (de1.equals("主")) {
					if (score_h == score_c || h_score < 3) {
						if (attrs.equals("客")) {
							// 受让方赢
							lotterMoney = (rebates - 1) * acount;
						}
					} else if (h_score == 2) {
						// 赢2个 输一半 退一半的钱
						fb.returnMoney(order, order.getAcount() * 0.5);
						returnMoney = order.getAcount() * 0.5;
					} else if (h_score > 2) {
						if (attrs.equals("主")) {
							lotterMoney = (rebates - 1) * acount;
						}
					}
				} else if (de1.equals("客")) {
					if (score_h == score_c || c_score < 3) {
						if (attrs.equals("主")) {
							// 受让方赢
							lotterMoney = (rebates - 1) * acount;
						}
					} else if (c_score == 2) {
						// 赢2个 输一半 退一半的钱
						fb.returnMoney(order, order.getAcount() * 0.5);
						returnMoney = order.getAcount() * 0.5;
					} else if (c_score > 2) {
						if (attrs.equals("客")) {
							lotterMoney = (rebates - 1) * acount;
						}
					}
				}
			} else if (de2.equals("2")) {
				if (de1.equals("主")) {
					if (h_score == 2) {
						// 赢两个 平 退钱
						fb.returnMoney(order, order.getAcount());
						returnMoney = order.getAcount();
					} else if (h_score < 2) {
						if (attrs.equals("客")) {
							// 受让方赢
							lotterMoney = (rebates - 1) * acount;
						}
					} else if (h_score > 2) {
						if (attrs.equals("主")) {
							lotterMoney = (rebates - 1) * acount;
						}
					}
				} else if (de1.equals("客")) {
					if (c_score == 2) {
						// 赢两个 平 退钱
					} else if (c_score < 2) {
						if (attrs.equals("主")) {
							// 受让方赢
							lotterMoney = (rebates - 1) * acount;
						}
					} else if (c_score > 2) {
						if (attrs.equals("客")) {
							lotterMoney = (rebates - 1) * acount;
						}
					}
				}
			}
		} else if (attr.equals("半场-大小")) {
			String de2 = des_in;
			int sum_score = fh_score_h + fh_score_c;
			try {
				String[] dsc = de2.split("/");
				String num1 = dsc[0].substring(0, 1);
				String num2 = dsc[1].substring(0, 1);
				int a1 = Integer.parseInt(num1) + 1;
				if (num1.equals(num2)) {
					if (sum_score > a1) {
						if (attrs.equals("大")) {
							lotterMoney = rebates * acount;
						}
					} else if (sum_score <= Integer.parseInt(num1)) {
						if (attrs.equals("大")) {
							fb.returnMoney(order, order.getAcount() * 0.5);
							returnMoney = order.getAcount() * 0.5;
						} else if (attrs.equals("小")) {
							lotterMoney = rebates * acount * 0.5;
						}
					}
				} else if ((Integer.parseInt(num1) + 1) == Integer.parseInt(num2)) {
					if (sum_score == a1) {
						if (attrs.equals("大")) {
							lotterMoney = rebates * acount * 0.5;
						} else if (attrs.equals("小")) {
							fb.returnMoney(order, order.getAcount() * 0.5);
							returnMoney = order.getAcount() * 0.5;
						}
					} else if (sum_score > a1) {
						if (attrs.equals("大")) {
							lotterMoney = rebates * acount;
						}
					} else if (sum_score == Integer.parseInt(num1)) {
						if (attrs.equals("小")) {
							lotterMoney = rebates * acount * 0.5;
						}
					}
				}
			} catch (Exception e) {
				if (de2.length() == 1) {
					int num1 = Integer.parseInt(de2);
					if (sum_score == num1) {
						fb.returnMoney(order, acount);
						returnMoney = acount;
					} else if (sum_score > num1) {
						if (attrs.equals("大")) {
							lotterMoney = rebates * acount;
						}
					} else if (sum_score < num1) {
						if (attrs.equals("小")) {
							lotterMoney = rebates * acount;
						}
					}
				} else {
					int num1 = Integer.parseInt(de2.substring(0, 1));
					if (sum_score <= num1) {
						if (attrs.equals("小")) {
							lotterMoney = rebates * acount;
						}
					} else if (sum_score > num1 + 1) {
						if (attrs.equals("大")) {
							lotterMoney = rebates * acount;
						}
					}
				}
			}
		}

		/** 插入开奖信息 */
		String state1 = "";
		/** 输或者输一半 那么就彻底结束 */
		if (lotterMoney == 0.0 && returnMoney != 0.0 || lotterMoney == 0.0 && returnMoney == 0.0) {
			state = 2;
			state1 = "未中奖";
		}
		if (lotterMoney != 0.0) {// 中奖
			state = 3;
			state1 = "已中奖";
		}
		// 子订单
		if (sign == false) { // TODO zh
			if (state == 2) {
				order.setLotter_money(lotterMoney);
				order.setState(state);
				order.setLtime(new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date()));
				order.setReturn_money(returnMoney);
				System.out.println("订单状态:" + state1 + "   中奖金额:" + lotterMoney + "   退钱金额:" + returnMoney);
				fOrderService.updateFootBallOrder(order);
				fOrderService.updateFootBallSeries(order);
				return 1;
			}
			System.out.println("订单状态:" + state1 + "   中奖金额:" + lotterMoney + "   退钱金额:" + returnMoney);
			order.setLotter_money(lotterMoney);
			order.setReturn_money(returnMoney);
			fOrderService.updateFootBallSeries(order);
		} else {
			// 总订单
			order.setState(state);
			order.setLotter_money(lotterMoney);
			order.setReturn_money(returnMoney);
			order.setLtime(new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date()));
			System.out.println("订单状态:" + state1 + "   中奖金额:" + lotterMoney + "   退钱金额:" + returnMoney);

			fOrderService.updateFootBallOrder(order);
			fOrderService.updateFootBallSeries(order);
			if (lotterMoney != 0.0) {
				User user = userService.getUserByid(order.getUser_id());
				order.setAcount(lotterMoney);
				fOrderService.returMoney(order, user,false);
			}
		}
		return 2;
	}

	/** 退还本金 */
	public int returnMoney(FootBallOrder o, double money) {
		User user = userService.getUserByid(o.getUser_id());
		o.setAcount(money);
		fOrderService.returMoney(o, user,true);
		return 0;
	}

	public void checks() {
		FootBallCheckOrder fb = new FootBallCheckOrder();
		fb.checkFootBallMatch();
		fb.checkSeries();
	}

	public static void main(String[] args) {
		FootBallCheckOrder fb = new FootBallCheckOrder();
		fb.checks();
	}

}
