package com.ja.sevice.impl;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;

import org.apache.ibatis.annotations.Param;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.DigestUtils;

import com.ja.dao.UserAgentMapper;
import com.ja.domain.Agent;
import com.ja.domain.AgentRebate;
import com.ja.domain.Jine;
import com.ja.domain.Liushui;
import com.ja.domain.Order;
import com.ja.domain.ProxyConnection;
import com.ja.domain.ProxyReport;
import com.ja.domain.User;
import com.ja.sevice.IUserAgentService;

public class UserAgentServiceImp implements IUserAgentService {

	@Autowired
	private UserAgentMapper userAgentMapper;
	
	@Override
	public List<User> showUser(Integer id, Integer online, Integer accountType, String account) {
		return userAgentMapper.showUser(id, online, accountType, account);
	}


	@Override
	public User showSelf(Integer id) {
		return userAgentMapper.showSelf(id);
	}

	@Override
	public Integer updateRebate(Integer id, Double rebate) {
		return userAgentMapper.updateRebate(id, rebate);
	}


	@Override
	public Agent findAgent(String agent) {
		return userAgentMapper.findAgent(agent);
	}


	@Override
	public Integer addUserAgentID(Integer id, Integer agentId) {
		return userAgentMapper.addUserAgentID(id, agentId);
	}


	@Override
	public User findUserByIcode(String icode) {
		return userAgentMapper.findUserByIcode(icode);
	}


	@Override
	public Integer updateUserFid(Integer id, Integer fid) {
		return userAgentMapper.updateUserFid(id, fid);
	}


	@Override
	public List<Liushui> findLiushui(String date1, String date2, String account, String type,
			String orderId,Agent a) {
		return userAgentMapper.findLiushui(date1, date2, account, type, orderId,a);
	}

	@Override
	public List<ProxyReport> findYunyingbbByUserId(Agent a,@Param("date1") String date1,@Param("date2") String date2,String name) {
		
		
		
		//支出
		//提款手续费
		Double tkshouxufei = userAgentMapper.findYunyingbbByUserId(a, date1, date2,"提款手续费",name);
		if(tkshouxufei == null) {
			tkshouxufei = 0.00;
		}
		//人工扣款
		Double rgkoukuan = userAgentMapper.findYunyingbbByUserId(a, date1, date2,"人工扣款",name);
		if(rgkoukuan  == null) {
			rgkoukuan = 0.00;
		}
		//快速提款
		Double kstikuan = userAgentMapper.findYunyingbbByUserId(a, date1, date2,"快速提款",name);
		if(kstikuan  == null) {
			kstikuan  = 0.00;
		}
		//彩票投注
		Double cptouzhu = userAgentMapper.findYunyingbbByUserId(a, date1, date2,"彩票投注",name);
		if(cptouzhu  == null) {
			cptouzhu = 0.00;
		}
		//百家乐投注
		//系统彩投注
		Double xtctouzhu = 0.00;
		if(userAgentMapper.findYunyingbbByUserId(a, date1, date2,"百家乐投注",name) != null) {
			xtctouzhu += userAgentMapper.findYunyingbbByUserId(a, date1, date2,"百家乐投注",name);
		}
		if(userAgentMapper.findYunyingbbByUserId(a, date1, date2,"系统彩投注",name) != null) {
			xtctouzhu += userAgentMapper.findYunyingbbByUserId(a, date1, date2,"系统彩投注",name);
		}
		//聊天室发红包
		Double ltsfhongbao = userAgentMapper.findYunyingbbByUserId(a, date1, date2,"聊天室发红包 ",name);
		if(ltsfhongbao == null) {
			ltsfhongbao = 0.00;
		}
		
		
		
		//收入
		//代理返点
		Double dlfandian = userAgentMapper.findYunyingbbByUserId(a, date1, date2,"代理返点",name);
		if(dlfandian  == null) {
			dlfandian  = 0.00;
		}
		//每日反水
		Double mrfanshui = userAgentMapper.findYunyingbbByUserId(a, date1, date2,"每日反水",name);
		if( mrfanshui == null) {
			 mrfanshui = 0.00;
		}
		//每月返水
		Double myfanshui = userAgentMapper.findYunyingbbByUserId(a, date1, date2,"每月返水",name);
		if(myfanshui  == null) {
			myfanshui = 0.00;
		}
		//特码B反水
		Double tmbfanshui = userAgentMapper.findYunyingbbByUserId(a, date1, date2,"特码B反水",name);
		if(tmbfanshui  == null ) {
			tmbfanshui = 0.00;
		}
		//充值赠送
		Double czzengsong = userAgentMapper.findYunyingbbByUserId(a, date1, date2,"充值赠送",name);
		if(czzengsong == null) {
			czzengsong = 0.00;
		}
		//幸运大转盘
		Double xyzhuanpan = userAgentMapper.findYunyingbbByUserId(a, date1, date2,"幸运转盘抽奖",name);
		if(xyzhuanpan == null ) {
			xyzhuanpan= 0.00;
		}
		/*//提款失败
		Double tkshibaith = userAgentMapper.findYunyingbbByUserId(a, date1, date2,"提款失败",name);
		if(tkshibaith == null) {
			tkshibaith = 0.00;
		}*/
		/*//提款失败退还手续费
		Double tkshibaithsxf = userAgentMapper.findYunyingbbByUserId(a, date1, date2,"提款失败退还手续费",name);
		if(tkshibaithsxf == null ) {
			tkshibaithsxf = 0.00;
		}*/
		//人工加款
		Double rgjiakuan = userAgentMapper.findYunyingbbByUserId(a, date1, date2,"人工加款",name);
		if(rgjiakuan == null) {
			rgjiakuan = 0.00;
		}
		//在线充值
		Double zxchongzhi = userAgentMapper.findYunyingbbByUserId(a, date1, date2,"在线充值",name);
		if(zxchongzhi == null ) {
			zxchongzhi = 0.00;
		}
		//注册赠送
		Double zczengsong = userAgentMapper.findYunyingbbByUserId(a, date1, date2,"注册赠送",name);
		if(zczengsong == null) {
			zczengsong= 0.00;
		}
		//每日签到 
		Double mrqiandao = userAgentMapper.findYunyingbbByUserId(a, date1, date2,"每日签到 ",name);
		if(mrqiandao == null) {
			mrqiandao = 0.00;
		}
		//彩票撤单
		Double cpchedan = userAgentMapper.findYunyingbbByUserId(a, date1, date2,"彩票撤单",name);
		if(cpchedan == null) {
			cpchedan = 0.00;
		}
		//彩票派奖
		Double cppaijiang = userAgentMapper.findYunyingbbByUserId(a, date1, date2,"彩票派奖",name);
		if(cppaijiang == null) {
			cppaijiang = 0.00;
		}
		// 系统彩派奖
		//百家乐派奖
		Double xitcpaijiang = 0.00;
		if(userAgentMapper.findYunyingbbByUserId(a, date1, date2,"系统彩派奖",name) != null) {
			xitcpaijiang += userAgentMapper.findYunyingbbByUserId(a, date1, date2,"系统彩派奖",name);
		}
		if(userAgentMapper.findYunyingbbByUserId(a, date1, date2,"百家乐派奖",name) != null){
			xitcpaijiang += userAgentMapper.findYunyingbbByUserId(a, date1, date2,"百家乐派奖",name);
		}
		//系统彩撤单
		Double xtcchedan = userAgentMapper.findYunyingbbByUserId(a, date1, date2,"系统彩撤单",name);
		if(xtcchedan  == null) {
			xtcchedan  = 0.00;
		}
		//和局退还本金
		Double hjtuihuan = userAgentMapper.findYunyingbbByUserId(a, date1, date2,"和局退还本金",name);
		if(hjtuihuan == null) {
			hjtuihuan  = 0.00;
		}
		//聊天室收红包
		Double ltsshongbao = userAgentMapper.findYunyingbbByUserId(a, date1, date2,"聊天室收红包 ",name);
		if(ltsshongbao == null) {
			ltsshongbao = 0.00;
		}	
		ProxyReport t = new ProxyReport();
		//在线充值
		t.setZxchongzhi(zxchongzhi);
		//提款总计 快速提款+人工扣款
		/*t.setRgkoukuan(rgkoukuan+kstikuan);*/
		t.setTikuanzongji(rgkoukuan+kstikuan);
		//代理返点
		t.setDlfandian(dlfandian);
		//反水总计 每日反水+每月反水+特码B反水
		t.setMrfanshui(mrfanshui+myfanshui+tmbfanshui);
		//充值赠送
		t.setCzzengsong(czzengsong);
		//注册赠送
		t.setZczengsong(zczengsong);
		//人工加款
		t.setRgjiakuan(rgjiakuan);
		//人工扣款
		t.setRgkoukuan(rgkoukuan);
		//投注总计
		t.setCptouzhu(cptouzhu+xtctouzhu);
		//中奖总计
		t.setCppaijiang(cppaijiang+xitcpaijiang);
		DecimalFormat dft = new DecimalFormat("#0.00");
		//投注输赢 投注-派奖=输赢 
		Double defeatOrVictory = t.getCptouzhu()-t.getCppaijiang();
		//团队余额 收入
		Double teamBalance = hjtuihuan+xtcchedan+xitcpaijiang+cppaijiang+cpchedan+mrqiandao+zczengsong+zxchongzhi+rgjiakuan+ltsshongbao/*+tkshibaithsxf+tkshibaith*/+xyzhuanpan+czzengsong+tmbfanshui+myfanshui+mrfanshui+dlfandian;
		//团队余额 支出
		Double teamBalance1 = xtctouzhu+cptouzhu+kstikuan+rgkoukuan+tkshouxufei+ltsfhongbao;
		//最终的团队余额
		Double teamBalance2 = teamBalance-teamBalance1;
		//团队投注人数
		Integer theNumberOfBets =  userAgentMapper.theNumberOfBets(a, date1, date2).size();
		//投注输赢 投注-派奖=输赢 
		t.setDefeatOrVictory(new Double(dft.format(defeatOrVictory)));
		//团队余额
		if(date1 == null  && name == null || "".equals(date1) && "".equals(name)) {
			Double Balance = userAgentMapper.teamBalances(a);
			if(Balance == null) {
				Balance = 0.00;
			}
			t.setTeamBalance(Balance);
		}else {
			t.setTeamBalance(teamBalance2);
		}
		//投注人数
		t.setTheNumberOfBets(theNumberOfBets);
		List<ProxyReport> list = new ArrayList<ProxyReport>();
		list.add(t);
		return list;
	}


	@Override
	public List<Jine> findJineByUserId(Integer agentId, String status, String type, String account, String date1,
			String date2) {
		return userAgentMapper.findJineByUserId(agentId, status, type, account, date1, date2);
	}

	@Override
	public Agent login(String name, String pass) {
		Agent agent = userAgentMapper.login(name, pass);
		return agent;
	}

	@Transactional
	public Integer editeAgent(Integer id,String oldPassword,String newPassword) {
		Agent ag = findAgentById(id);
		if(ag==null)
			return 0;
		String pass = DigestUtils.md5DigestAsHex(DigestUtils.md5DigestAsHex(oldPassword.getBytes()).getBytes());
		if(ag.getPassword().equals(pass)){
			newPassword = DigestUtils.md5DigestAsHex(DigestUtils.md5DigestAsHex(newPassword.getBytes()).getBytes());
			Agent a = new Agent();
			a.setId(id);
			a.setPassword(newPassword);
			Integer affectRow = userAgentMapper.editeAgent(a);
			if(affectRow!=1)
				throw new RuntimeException("系统忙!!");
			return affectRow;
		}else{
			throw new RuntimeException("输入的旧密码错误");
		}
	}

	/**
	 * 根据代理的id找到相对应的代理
	 * @param id
	 * @return
	 */
	public Agent findAgentById(Integer id){
		return userAgentMapper.findAgentById(id);
	}

	@Override
	public Integer insertAgentRebate(AgentRebate agentRebate) {
		return userAgentMapper.insertAgentRebate(agentRebate);
		
	}


	@Override
	public Agent findAgentByUserId(Integer userid) {
		return userAgentMapper.findAgentByUserId(userid);
	}


	@Override
	public List<AgentRebate> findAgentRebate(Integer agentId, String date1, String date2) {
		return userAgentMapper.findAgentRebate(agentId, date1, date2);
	}


	@Override
	public Double teamBalance(Integer agentId, String date1, String date2, String account) {
		return userAgentMapper.teamBalance(agentId, date1, date2, account);
	}


	@Override
	public List<ProxyConnection> queryAgentConnection(Agent a) {
		return userAgentMapper.queryAgentConnection(a);
	}


	@Override
	public List<Order> noteRecord(Agent a, Order o, String time, String time1, Integer startIndex, Integer lineCount,
			int model) {
		return userAgentMapper.noteRecord(a, o, time, time1, startIndex, lineCount, model);
	}


	@Override
	public Order idQuery(Integer id) {
		return userAgentMapper.idQuery(id);
	}


	@Override
	public User findByNameUser(String userName) {
		return userAgentMapper.findByNameUser(userName);
	}


	@Override
	public List<User> findByGeneralAgentIdUser(Integer agent_id) {
		return userAgentMapper.findByGeneralAgentIdUser(agent_id);
	}
}
