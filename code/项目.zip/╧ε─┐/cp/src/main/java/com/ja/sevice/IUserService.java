package com.ja.sevice;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import com.ja.domain.Liushui;
import com.ja.domain.PagingData;
import com.ja.domain.User;

public interface IUserService {

	/**
	 * 
	   *   方法名：getAllUsers   
	   *   描述：     查询用户所有信息                  TODO   
	   *   参数：    @return 
	 * @return: List<User>
	 */
	 List<User> getAllUsers();
	
	 /**
	  * 
	    *   方法名：getUserByid   
	    *   描述：    根据id查询用户信息                      TODO   
	    *   参数：    @param user_id 用户id
	    *   参数：    @return 
	  * @return: User
	  */
	User getUserByid(Integer user_id);

	/**
	 * 
	   *   方法名：checkUser   
	   *   描述：     根据用户名查询用户信息                  TODO   
	   *   参数：    @param user_name 用户名称
	   *   参数：    @return 
	 * @return: User
	 */
	User checkUser(String user_name);
	
	/**
	 * 
	   *   方法名：register   
	   *   描述：    添加用户                    TODO   
	   *   参数：    @param name 用户名
	   *   参数：    @param pass 密码
	   *   参数：    @param invitationCode 邀请码
	   *   参数：    @param qq qq
	   *   参数：    @param ip 注册ip
	   *   参数：    @param telephone 用户电话
	   *   参数：    @return 
	 * @return: int
	 */
	 int register(HttpSession session,HttpServletRequest request,String name, String pass, String invitationCode, 
			 String qq, String ip, String telephone);

	/**
	 * 
	   *   方法名：updateUserInfo   
	   *   描述：      修改用户信息                  TODO   
	   *   参数：    @param user 修改信息
	   *   参数：    @return 
	 * @return: int
	 */
	int updateUserInfo(User user);

	 
	/**
	 * 
	   *   方法名：userTryplay   
	   *   描述：     添加试玩账户                  TODO   
	   *   参数：    @param user
	   *   参数：    @return 
	 * @return: int
	 */
	int userTryplay(User user);

	/**
	 * 
	   *   方法名：getUserCount   
	   *   描述：       查询用户总,代理,会员人数                 TODO   
	   *   参数：    @return 
	 * @return: int[]
	 */
	int[] getUserCount();

	/**
	 * 
	   *   方法名：getAllAgentRebateTotal   
	   *   描述：    查询所有的代理返点总计                   TODO   
	   *   参数：    @return 
	 * @return: Double
	 */
	Double getAllAgentRebateTotal();

	// 用户登陆接口
	 User login(String name, String pass);

	// 更新余额-流水记录
	int updateMoney(User user, Liushui l);

	void delUser(Integer id);

	/** 查询所有的代理 */
	List<User> getAllAgent();

	/** 定时回收试玩账号 */
	List<User> timingRecovery();

	/** 定时删除试玩账号 */
	void timeDeleting(Integer id);

	/**
	 * 自动清理表
	 * @param dataBaseName 表名
	 */
	int findDatabaseCounts(String dataBaseName);
	/**
	 * 根据条件查询用户信息
	 * @param name  用户名
	 * @param ip 登录ip
	 * @param bankCard 银行卡号
	 * @param cname 开户名  就是银行卡绑定的姓名
	 * @return 返回查询到的用户   list集合包含User数据对象
	 */
	int findAllUserCounts(String  name,String ip,String  bankCard,String cname);

	/**
	    *   方法名：findAllUsers   
	    *   描述：     分页查询所有的会员                      TODO     
	    *   参数：    @param paging
	 * @return: List<User>
	 */
	List<User> findAllUsers(PagingData paging,String ip,String bankCard,String cname);

	/**
	 * 查询所有用户的推广链接
	 * @return
	 */
	List<String> promotionLinks();
	/**
	 * 游客添加接口
	 */
	void addTourists(String ip,String page);

	/**
	 * 
	   *   方法名：findByTimeOrNameAllUsers   
	   *   描述：     根据时间或用户名查询用户信息                  TODO   
	   *   参数：    @param startTime 开始时间
	   *   参数：    @param endTime 结束时间
	   *   参数：    @param userName 用户名称
	   *   参数：    @return 
	 * @return: List<User>
	 */
	List<User> findByTimeOrNameAllUsers(String startTime, String endTime, String userName);
	/**
	 * 会头衔晋级  根据充值金额进行晋级    
	 * @param id 会员id  
	 * @param name 用户名   如果没有id就传会员名  传其中一个都可以 随便传一个都可以
	 * @return 成功就返回1
	 */
	int  vip(Integer id,String name);
	/**
	 * 转移下级
	 * @param name 转到某个代理名下的代理用户名
	 * @param cname  被转到别的代理名下的 用户名
	 * @param odds  转过来 的赔率是多少
	 * @return  转移成功则返回1  转移失败则返回0 返回-1用户的赔率不能为空  返回-2赔率不能大于代理可调动的赔率  返回-3设置的赔率格式不对 返回-4代表 这个用户不存在
	 */
	int transferSubordinate(String name,String cname,String odds);
}
