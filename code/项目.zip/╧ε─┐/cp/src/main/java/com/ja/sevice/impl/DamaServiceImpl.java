package com.ja.sevice.impl;

import java.text.DecimalFormat;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ja.dao.DamaMapper;
import com.ja.dao.OrderMapper;
import com.ja.domain.Dama;
import com.ja.domain.Order;
import com.ja.domain.TodayRecord;
import com.ja.sevice.DamaService;
import com.ja.util.DateUtil;
import com.ja.util.JsonResult;

@Service
/**
 * @author GL 会员打码记录-
 * @DATE 2018年1月15日 18:03:40
 */
public class DamaServiceImpl implements DamaService {

	@Autowired
	private DamaMapper damaMapper;
	
	@Autowired
	private OrderMapper orderMapper;

	@Override
	public List<Dama> getAllDama(Integer integer, Integer integer2, int i) {
		return damaMapper.getAllDama(integer,integer2,i);
	}

	@Override
	public List<Dama> getMhdama(Integer integer, Integer integer2,Dama d,String date1,String date2,int model) {
		return damaMapper.getMhdama(integer,integer2,d,date1,date2,model);
	}

	@Override
	public int addDama(Dama d) {
		return damaMapper.addDama(d);
	}

	@Override
	public double getDmTodyJl1(Integer id,String time) {
		return damaMapper.getDmTodyJl1(id,time);
	}
	@Override
	public double getDmTodyJl2(Integer id,String time) {
		return damaMapper.getDmTodyJl2(id,time);
	}

	@Override
	public double getDmMonthJl1(Integer id) {
		return damaMapper.getDmMonthJl1(id);
	}
	@Override
	public double getDmMonthJl2(Integer id) {
		return damaMapper.getDmMonthJl2(id);
	}

	@Override
	public double getDmLastMonthJl1(Integer id, String time) {
		return damaMapper.getDmLastMonthJl1(id, time);
	}

	@Override
	public double getDmLastMonthJl2(Integer id, String time) {
		return damaMapper.getDmLastMonthJl2(id, time);
	}

	@Override
	public Dama getOneDamaJl(Integer id, String time) {
		return damaMapper.getOneDamaJl(id, time);
	}

	@Override
	public JsonResult findByTimeCodeCount(Integer type,Integer user_id) {
		DecimalFormat dec = new DecimalFormat("#0.00");
		String time = "";
		String allCount = "";
		Double count1 = 0.00;
		Double count2 = 0.00;
		switch (type) {
		case 1:
			count1 = damaMapper.findUserByTimeCodeCount(user_id, DateUtil.findFormatDate(),1);
			count2 = damaMapper.findUserByTimeCodeCount(user_id, DateUtil.findFormatDate(),2);
			allCount = dec.format(count1 - count2) + "";
			time = DateUtil.findFormatDate();
			break;
		case 2:
			count1 = damaMapper.findUserByTimeCodeCount(user_id, DateUtil.findFormatDate().substring(0, 7),1);
			count2 = damaMapper.findUserByTimeCodeCount(user_id, DateUtil.findFormatDate().substring(0, 7),2);
			allCount = dec.format(count1 - count2) + "";
			time = DateUtil.findFormatDate().substring(0, 7);
			break;
		case 3:
			count1 = damaMapper.findUserByTimeCodeCount(user_id, "",1);
			count2 = damaMapper.findUserByTimeCodeCount(user_id, "",2);
			allCount = dec.format(count1 - count2) + "";
			time = ""; 
			break;
		}
		List<Order> orders = orderMapper.getCnameDama(user_id,time);
		TodayRecord todayRecord = damaMapper.findUserCodeCountManualChange(user_id,time);
		Order addCodeCount = new Order();
		Order reduceCodeCount = new Order();
		addCodeCount.setCname1("打码增加");
		addCodeCount.setAcount(todayRecord.getDmzengjia());
		reduceCodeCount.setCname1("打码扣除");
		reduceCodeCount.setAcount(todayRecord.getDmkouchu());
		orders.add(addCodeCount);
		orders.add(reduceCodeCount);
		return new JsonResult(allCount,orders);
	}

}