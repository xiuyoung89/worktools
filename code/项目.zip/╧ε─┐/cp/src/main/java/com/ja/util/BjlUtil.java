package com.ja.util;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.HashSet;
import java.util.Random;
import java.util.Set;

import com.ja.domain.Bjldata;

/**
 * 百家乐
 * @author Administrator
 *
 */
public class BjlUtil {
				/**发牌*/
				public  Bjldata bjlData() {
					Bjldata bjldata = new Bjldata();
					/**闲家发牌*/
					int xianj = -1;
					String[] x = dianshu().split(",");
					/**闲家第一张牌*/
					bjldata.setLeisure1(x[0]);
					/**闲家第二张牌*/
					bjldata.setLeisure2(x[1]);
					/**如果闲家第一张牌等于 10，j,q,k 那么他的值等于0*/
					if (bjldata.getLeisure1().equals("10") || bjldata.getLeisure1().equals("j") || bjldata.getLeisure1().equals("q") || bjldata.getLeisure1().equals("k")) {
						xianj = 0;
					/**如果第一张牌等于a,那么他的值等于1*/
					} else if (bjldata.getLeisure1().equals("a")) {
						xianj = 1;
					} else {
					/**如果都不等于那么就直接赋值即可*/
						xianj = new Integer(bjldata.getLeisure1().trim());
					}
					/**第二张牌*/
					if (bjldata.getLeisure2().equals("10") || bjldata.getLeisure2().equals("j") || bjldata.getLeisure2().equals("q") || bjldata.getLeisure2().equals("k")) {
						xianj = 0 + xianj;
					} else if (bjldata.getLeisure2().equals("a")) {
						xianj = 1 + xianj;
					} else {
						xianj = new Integer(bjldata.getLeisure2().trim()) + xianj;
					}
					
					/**庄家发牌*/
					int zhuangj = -1;
					String[] z = dianshu().split(",");
					/**庄家第一张牌*/
					bjldata.setZhuang1(z[0]);
					/**庄家第二张牌*/
					bjldata.setZhuang2(z[1]);
					if (bjldata.getZhuang1().equals("10") || bjldata.getZhuang1().equals("j") || bjldata.getZhuang1().equals("q") || bjldata.getZhuang1().equals("k")) {
						zhuangj = 0;
					} else if (bjldata.getZhuang1().equals("a")) {
						zhuangj = 1;
					} else {
						zhuangj = new Integer(bjldata.getZhuang1().trim());
					}
					/**庄家第二张牌*/
					if (bjldata.getZhuang2().equals("10") || bjldata.getZhuang2().equals("j") || bjldata.getZhuang2().equals("q") || bjldata.getZhuang2().equals("k")) {
						zhuangj = 0 + zhuangj;
					} else if (bjldata.getZhuang2().equals("a")) {
						zhuangj = 1 + zhuangj;
					} else {
						zhuangj = new Integer(bjldata.getZhuang2().trim()) + zhuangj;
					}
					/**对比赢家*/
					if (xianj >= 10) {
						/**只要点数不是11 就走esle*/
						if (xianj != 11) {
							xianj = new Integer(String.valueOf(xianj).replaceAll("1", "").trim());
						} else {
							xianj = 1;
						}
					}
					if (zhuangj >= 10) {
						if (zhuangj != 11) {
							zhuangj = new Integer(String.valueOf(zhuangj).replaceAll("1", "").trim());
						} else {
							zhuangj = 1;
						}
					}
					/**闲家补牌前点数*/
					bjldata.setFrontPointsofIdleReplacementCards(xianj);
					/**庄家补牌前点数*/
					bjldata.setFrontPointsOfZhuangshi(zhuangj);
					/**天生赢家*/
					if (xianj >= 8 || zhuangj >= 8) {
						/**判断是否有闲对*/
						if (bjldata.getLeisure1().equals(bjldata.getLeisure2())) {
							bjldata.setIdleTime(1);
							bjldata.setArbitraryPairs(1);
						}else {
							bjldata.setIdleTime(0);
							bjldata.setArbitraryPairs(0);
						}
						/**判断是否有庄对*/
						if (bjldata.getZhuang1().equals(bjldata.getZhuang2())) {
							bjldata.setZhuangPairs(1);
							bjldata.setArbitraryPairs(1);
						}else {
							bjldata.setZhuangPairs(0);
							if(bjldata.getArbitraryPairs() == null) {
								bjldata.setArbitraryPairs(0);
							}
						}
						/**闲家大于庄家的时候 闲家赢*/
						if (xianj > zhuangj) {
							bjldata.setWinner(0);
							/**闲家的牌*/
							bjldata.setLeisure1(huase()+bjldata.getLeisure1());
							bjldata.setLeisure2(huase()+bjldata.getLeisure2());
							/**庄家的牌*/
							bjldata.setZhuang1(huase()+bjldata.getZhuang1());
							bjldata.setZhuang2(huase()+bjldata.getZhuang2());
							bjldata.setMakerSFinalPoints(zhuangj);
							bjldata.setLeisureHomePoints(xianj);
						}
						/**如果庄家大于闲家那么庄家赢*/
						if (zhuangj > xianj) {
							bjldata.setWinner(1);
							/**闲家的牌*/
							bjldata.setLeisure1(huase()+bjldata.getLeisure1());
							bjldata.setLeisure2(huase()+bjldata.getLeisure2());
							/**庄家的牌*/
							bjldata.setZhuang1(huase()+bjldata.getZhuang1());
							bjldata.setZhuang2(huase()+bjldata.getZhuang2());
							bjldata.setMakerSFinalPoints(zhuangj);
							bjldata.setLeisureHomePoints(xianj);
						}
						/**如果庄家等于闲家或者闲家等于庄家，那么和局*/
						if (zhuangj == xianj) {
							bjldata.setWinner(2);
							/**闲家的牌  bjldata.getLeisure1()+huase()*/
							bjldata.setLeisure1(huase()+bjldata.getLeisure1());
							bjldata.setLeisure2(huase()+bjldata.getLeisure2());
							/**庄家的牌*/
							bjldata.setZhuang1(huase()+bjldata.getZhuang1());
							bjldata.setZhuang2(huase()+bjldata.getZhuang2());
							bjldata.setMakerSFinalPoints(zhuangj);
							bjldata.setLeisureHomePoints(xianj);
						}
						/**小  不用判断  天生赢家  只有四张牌  直接为小即可*/
						bjldata.setSize(0);
						/**判断是否有完美对子*/
						if(bjldata.getZhuang1().equals(bjldata.getZhuang2())  ||
								 bjldata.getLeisure1().equals(bjldata.getLeisure2())) {
							bjldata.setPerfectPair(1);
						}else {
							bjldata.setPerfectPair(0);
						}
						return bjldata;
					}
					/**闲家补牌*/
					Integer xianbupai = null;
					if (xianj == 0 || xianj == 1 || xianj == 2 || xianj == 3 || xianj == 4 || xianj == 5) {
						bjldata.setLeisureCard(bupai(bjldata.getLeisure1(),bjldata.getLeisure2()));
						if (bjldata.getLeisureCard().equals("10") || bjldata.getLeisureCard().equals("j") || bjldata.getLeisureCard().equals("q") || bjldata.getLeisureCard().equals("k")) {
							xianbupai = 0;
						} else if (bjldata.getLeisureCard().equals("a")) {
							xianbupai = 1;
						} else {
							xianbupai = new Integer(bjldata.getLeisureCard());
						}
					}
					/**庄家补牌*/
					Integer zhuangbupai = null;
					if (zhuangj == 0 || zhuangj == 1 || zhuangj == 2) {
						bjldata.setDealerCard(bupai(bjldata.getZhuang1(),bjldata.getZhuang1()));
						if (bjldata.getDealerCard().equals("10") || bjldata.getDealerCard().equals("j") || bjldata.getDealerCard().equals("q") || bjldata.getDealerCard().equals("k")) {
							zhuangbupai = 0;
						} else if (bjldata.getDealerCard().equals("a")) {
							zhuangbupai = 1;
						} else {
							zhuangbupai = new Integer(bjldata.getDealerCard());
						}
					}
					/**当庄家等于3 闲家补牌不等于8时 补牌*/
					if (zhuangj == 3) {
						if(xianbupai != null){
							if (xianbupai != 8) {
								bjldata.setDealerCard(bupai(bjldata.getZhuang1(),bjldata.getZhuang1()));
								if (bjldata.getDealerCard().equals("10") || bjldata.getDealerCard().equals("j") || bjldata.getDealerCard().equals("q") || bjldata.getDealerCard().equals("k")) {
									zhuangbupai = 0;
								} else if (bjldata.getDealerCard().equals("a")) {
									zhuangbupai = 1;
								} else {
									zhuangbupai = new Integer(bjldata.getDealerCard());
								}
							}
						}else{
							bjldata.setDealerCard(bupai(bjldata.getZhuang1(),bjldata.getZhuang2()));
							if (bjldata.getDealerCard().equals("10") || bjldata.getDealerCard().equals("j") || bjldata.getDealerCard().equals("q") || bjldata.getDealerCard().equals("k")) {
								zhuangbupai = 0;
							} else if (bjldata.getDealerCard().equals("a")) {
								zhuangbupai = 1;
							} else {
								zhuangbupai = new Integer(bjldata.getDealerCard());
							}
						}
					}
					if (zhuangj == 4) {
						if(xianbupai != null){
							if (xianbupai != 0 && xianbupai != 1 && xianbupai != 8 && xianbupai != 9) {
								bjldata.setDealerCard(bupai(bjldata.getZhuang1(),bjldata.getZhuang2()));
								if (bjldata.getDealerCard().equals("10") || bjldata.getDealerCard().equals("j") || bjldata.getDealerCard().equals("q") || bjldata.getDealerCard().equals("k")) {
									zhuangbupai = 0;
								} else if (bjldata.getDealerCard().equals("a")) {
									zhuangbupai = 1;
								} else {
									zhuangbupai = new Integer(bjldata.getDealerCard());
								}
							}
						}else{
							bjldata.setDealerCard(bupai(bjldata.getZhuang1(),bjldata.getZhuang2()));
							if (bjldata.getDealerCard().equals("10") || bjldata.getDealerCard().equals("j") || bjldata.getDealerCard().equals("q") || bjldata.getDealerCard().equals("k")) {
								zhuangbupai = 0;
							} else if (bjldata.getDealerCard().equals("a")) {
								zhuangbupai = 1;
							} else {
								zhuangbupai = new Integer(bjldata.getDealerCard());
							}
						}
					}
					if (zhuangj == 5) {
						if(xianbupai != null){
							if (xianbupai != 0 && xianbupai != 1 && xianbupai != 2 && xianbupai != 3 && xianbupai != 8
									&& xianbupai != 9) {
								bjldata.setDealerCard(bupai(bjldata.getZhuang1(),bjldata.getZhuang1()));
								if (bjldata.getDealerCard().equals("10") || bjldata.getDealerCard().equals("j") || bjldata.getDealerCard().equals("q") || bjldata.getDealerCard().equals("k")) {
									zhuangbupai = 0;
								} else if (bjldata.getDealerCard().equals("a")) {
									zhuangbupai = 1;
								} else {
									zhuangbupai = new Integer(bjldata.getDealerCard());
								}
							}
						}else{
							bjldata.setDealerCard(bupai(bjldata.getZhuang1(),bjldata.getZhuang2()));
							if (bjldata.getDealerCard().equals("10") || bjldata.getDealerCard().equals("j") || bjldata.getDealerCard().equals("q") || bjldata.getDealerCard().equals("k")) {
								zhuangbupai = 0;
							} else if (bjldata.getDealerCard().equals("a")) {
								zhuangbupai = 1;
							} else {
								zhuangbupai = new Integer(bjldata.getDealerCard());
							}
						}
					}
					if (zhuangj == 6) {
						if(xianbupai != null){
							if(xianbupai == 6 || xianbupai == 7){
								bjldata.setDealerCard(bupai(bjldata.getZhuang1(),bjldata.getZhuang1()));
								if (bjldata.getDealerCard().equals("10") || bjldata.getDealerCard().equals("j") || bjldata.getDealerCard().equals("q") || bjldata.getDealerCard().equals("k")) {
									zhuangbupai = 0;
								} else if (bjldata.getDealerCard().equals("a")) {
									zhuangbupai = 1;
								} else {
									zhuangbupai = new Integer(bjldata.getDealerCard());
								}
							}
						}
					}
				//	System.out.println(bjldata.getLeisure1()+"点数");
					if(bjldata.getLeisureCard() != null) {
						if (bjldata.getLeisure1().equals(bjldata.getLeisure2()) ||
							bjldata.getLeisure1().equals(bjldata.getLeisureCard()) ||
							bjldata.getLeisure2().equals(bjldata.getLeisureCard())) {
							/**有闲对*/
							bjldata.setIdleTime(1);
							/**任意对子*/
							bjldata.setArbitraryPairs(1);
						}else {
							bjldata.setIdleTime(0);
							/**任意对子*/
							bjldata.setArbitraryPairs(0);
						}
					}else {
						if (bjldata.getLeisure1().equals(bjldata.getLeisure2())) {
							/**有闲对*/
							bjldata.setIdleTime(1);
							/**有任意对子 */
							bjldata.setArbitraryPairs(1);
						}else {
							bjldata.setIdleTime(0);//没有闲对
							if(bjldata.getArbitraryPairs() == null) {
								/**没有任意对子*/
								bjldata.setArbitraryPairs(0);
							}
						}
					}
					if(bjldata.getDealerCard() != null) {
						if (bjldata.getZhuang1().equals(bjldata.getZhuang2()) ||
							bjldata.getZhuang1().equals(bjldata.getDealerCard()) ||
							bjldata.getZhuang2().equals(bjldata.getDealerCard())) {
							/**庄对*/
							bjldata.setZhuangPairs(1);
							/**任意对子*/
							bjldata.setArbitraryPairs(1);
						}else {
							bjldata.setZhuangPairs(0);
							if(bjldata.getArbitraryPairs() == null) {
								/**任意对子*/
								bjldata.setArbitraryPairs(0);
							}
						}
					}else {
						if (bjldata.getZhuang1().equals(bjldata.getZhuang2())) {
							/**zhuangdui = "庄对";*/
							bjldata.setZhuangPairs(1);
							/**任意对子*/
							bjldata.setArbitraryPairs(1);
						}else {
							bjldata.setZhuangPairs(0);
							if(bjldata.getArbitraryPairs() == null) {
								/**任意对子*/
								bjldata.setArbitraryPairs(0);
							}
						}
					}
					/**闲家*/
					if (xianbupai != null) {
						/**闲家最终点数*/
						bjldata.setLeisureHomePoints(xianbupai + xianj);
					} else {
						bjldata.setLeisureHomePoints(xianj);
						if(bjldata.getArbitraryPairs() == null) {
							/**任意对子*/
							bjldata.setArbitraryPairs(0);
						}
					}
					/**当大于10，要缩小*/
					if (bjldata.getLeisureHomePoints() >= 10) {
						if (bjldata.getLeisureHomePoints() != 11) {
							String str = String.valueOf(bjldata.getLeisureHomePoints()).replaceAll("1", "");
							bjldata.setLeisureHomePoints(new Integer(str.trim()));
						} else {
							bjldata.setLeisureHomePoints(1);
							if(bjldata.getArbitraryPairs() == null) {
								/**任意对子*/
								bjldata.setArbitraryPairs(0);
							}
						}
					}
					/** 庄家*/
					if (zhuangbupai != null) {
						/**庄家补牌后点数*/
						bjldata.setMakerSFinalPoints(zhuangbupai + zhuangj);
					} else {
						bjldata.setMakerSFinalPoints(zhuangj);
					}
					/**当大于10去掉前面的1*/
					if (bjldata.getMakerSFinalPoints() >= 10) {
						if (bjldata.getMakerSFinalPoints() != 11) {
							String str = String.valueOf(bjldata.getMakerSFinalPoints()).replace("1", "");
							bjldata.setMakerSFinalPoints(new Integer(str.trim()));
						} else {
							bjldata.setMakerSFinalPoints(1);
						}
					}
					if (bjldata.getLeisureHomePoints() >bjldata.getMakerSFinalPoints()) {
						/**闲家赢*/
						bjldata.setWinner(0);
						/**闲家补牌不等于null就进去保存记录*/
						if (bjldata.getLeisureCard() != null) {
							/**庄家补牌不等于null就进去保存记录*/
							if (bjldata.getDealerCard() != null) {
								/**闲家第一张牌*/
								bjldata.setLeisure1(huase()+bjldata.getLeisure1());
								/**闲家第二张牌*/
								bjldata.setLeisure2(huase()+bjldata.getLeisure2());
								/**闲家补牌*/
								bjldata.setLeisureCard( huase()+bjldata.getLeisureCard());
								/**庄家第一张牌*/
								bjldata.setZhuang1( huase()+bjldata.getZhuang1());
								/**庄家第二张牌*/
								bjldata.setZhuang2( huase()+bjldata.getZhuang2());
								/**庄家补牌*/
								bjldata.setDealerCard( huase()+bjldata.getDealerCard());
							} else {
								/**闲家第一张牌*/
								bjldata.setLeisure1(huase()+bjldata.getLeisure1());
								/**闲家第二张牌*/
								bjldata.setLeisure2(huase()+bjldata.getLeisure2());
								/**闲家补牌*/
								bjldata.setLeisureCard( huase()+bjldata.getLeisureCard());
								/**庄家第一张牌*/
								bjldata.setZhuang1( huase()+bjldata.getZhuang1());
								/**庄家第二张牌*/
								bjldata.setZhuang2( huase()+bjldata.getZhuang2());
							}
						} else {
							if (bjldata.getDealerCard() != null) {
								/**闲家第一张牌*/
								bjldata.setLeisure1(huase()+bjldata.getLeisure1());
								/**闲家第二张牌*/
								bjldata.setLeisure2(huase()+bjldata.getLeisure2());
								/**庄家第一张牌*/
								bjldata.setZhuang1( huase()+bjldata.getZhuang1());
								/**庄家第二张牌*/
								bjldata.setZhuang2( huase()+bjldata.getZhuang2());
								/**庄家补牌*/
								bjldata.setDealerCard( huase()+bjldata.getDealerCard());
							} else {
								/**闲家第一张牌*/
								bjldata.setLeisure1(huase()+bjldata.getLeisure1());
								/**闲家第二张牌*/
								bjldata.setLeisure2(huase()+bjldata.getLeisure2());
								/**庄家第一张牌*/
								bjldata.setZhuang1( huase()+bjldata.getZhuang1());
								/**庄家第二张牌*/
								bjldata.setZhuang2( huase()+bjldata.getZhuang2());
							}
						}
					}
					if (bjldata.getMakerSFinalPoints() > bjldata.getLeisureHomePoints()) {
						/**庄家赢*/
						bjldata.setWinner(1);
						if (bjldata.getDealerCard() != null) {
							if (bjldata.getLeisureCard() != null) {
								/**闲家第一张牌*/
								bjldata.setLeisure1(huase()+bjldata.getLeisure1());
								/**闲家第二张牌*/
								bjldata.setLeisure2(huase()+bjldata.getLeisure2());
								/**闲家补牌*/
								bjldata.setLeisureCard( huase()+bjldata.getLeisureCard());
								/**庄家第一张牌*/
								bjldata.setZhuang1( huase()+bjldata.getZhuang1());
								/**庄家第二张牌*/
								bjldata.setZhuang2( huase()+bjldata.getZhuang2());
								/**庄家补牌*/
								bjldata.setDealerCard( huase()+bjldata.getDealerCard());
							} else {
								/**闲家第一张牌*/
								bjldata.setLeisure1(huase()+bjldata.getLeisure1());
								/**闲家第二张牌*/
								bjldata.setLeisure2(huase()+bjldata.getLeisure2());
								/**庄家第一张牌*/
								bjldata.setZhuang1( huase()+bjldata.getZhuang1());
								/**庄家第二张牌*/
								bjldata.setZhuang2( huase()+bjldata.getZhuang2());
								/**庄家补牌*/
								bjldata.setDealerCard( huase()+bjldata.getDealerCard());
							}
						} else {
							if (bjldata.getLeisureCard() != null) {
								/**闲家第一张牌*/
								bjldata.setLeisure1(huase()+bjldata.getLeisure1());
								/**闲家第二张牌*/
								bjldata.setLeisure2(huase()+bjldata.getLeisure2());
								/**闲家补牌*/
								bjldata.setLeisureCard( huase()+bjldata.getLeisureCard());
								/**庄家第一张牌*/
								bjldata.setZhuang1( huase()+bjldata.getZhuang1());
								/**庄家第二张牌*/
								bjldata.setZhuang2( huase()+bjldata.getZhuang2());
							} else {
								/**闲家第一张牌*/
								bjldata.setLeisure1(huase()+bjldata.getLeisure1());
								/**闲家第二张牌*/
								bjldata.setLeisure2(huase()+bjldata.getLeisure2());
								/**庄家第一张牌*/
								bjldata.setZhuang1( huase()+bjldata.getZhuang1());
								/**庄家第二张牌*/
								bjldata.setZhuang2( huase()+bjldata.getZhuang2());
							}
						}
					}
					if (bjldata.getMakerSFinalPoints() == bjldata.getLeisureHomePoints()) {
						/**和局*/
						bjldata.setWinner(2);
						if (bjldata.getDealerCard() != null) {
							if (bjldata.getLeisureCard() != null) {
								/**闲家第一张牌*/
								bjldata.setLeisure1(huase()+bjldata.getLeisure1());
								/**闲家第二张牌*/
								bjldata.setLeisure2(huase()+bjldata.getLeisure2());
								/**闲家补牌*/
								bjldata.setLeisureCard( huase()+bjldata.getLeisureCard());
								/**庄家第一张牌*/
								bjldata.setZhuang1( huase()+bjldata.getZhuang1());
								/**庄家第二张牌*/
								bjldata.setZhuang2( huase()+bjldata.getZhuang2());
								/**庄家补牌*/
								bjldata.setDealerCard( huase()+bjldata.getDealerCard());
							} else {
								/**闲家第一张牌*/
								bjldata.setLeisure1(huase()+bjldata.getLeisure1());
								/**闲家第二张牌*/
								bjldata.setLeisure2(huase()+bjldata.getLeisure2());
								/**庄家第一张牌*/
								bjldata.setZhuang1( huase()+bjldata.getZhuang1());
								/**庄家第二张牌*/
								bjldata.setZhuang2( huase()+bjldata.getZhuang2());
								/**庄家补牌*/
								bjldata.setDealerCard( huase()+bjldata.getDealerCard());
							}
						} else {
							if (bjldata.getLeisureCard() != null) {
								/**闲家第一张牌*/
								bjldata.setLeisure1(huase()+bjldata.getLeisure1());
								/**闲家第二张牌*/
								bjldata.setLeisure2(huase()+bjldata.getLeisure2());
								/**闲家补牌*/
								bjldata.setLeisureCard( huase()+bjldata.getLeisureCard());
								/**庄家第一张牌*/
								bjldata.setZhuang1( huase()+bjldata.getZhuang1());
								/**庄家第二张牌*/
								bjldata.setZhuang2( huase()+bjldata.getZhuang2());
							} else {
								/**闲家第一张牌*/
								bjldata.setLeisure1(huase()+bjldata.getLeisure1());
								/**闲家第二张牌*/
								bjldata.setLeisure2(huase()+bjldata.getLeisure2());
								/**庄家第一张牌*/
								bjldata.setZhuang1( huase()+bjldata.getZhuang1());
								/**庄家第二张牌*/
								bjldata.setZhuang2( huase()+bjldata.getZhuang2());
							}
						}

					}
					/**判断是大小*/
					if(bjldata.getDealerCard() != null || bjldata.getLeisureCard() != null) {
						bjldata.setSize(1);
					}else {
						bjldata.setSize(0);
					}
					/**判断是否有完美对子*/
					if(bjldata.getZhuang1().equals(bjldata.getZhuang2()) ||
					bjldata.getZhuang1().equals(bjldata.getDealerCard()) ||
					bjldata.getZhuang2().equals(bjldata.getDealerCard()) ||
					bjldata.getLeisure1().equals(bjldata.getLeisure2())  ||
					bjldata.getLeisure1().equals(bjldata.getLeisureCard()) ||
					bjldata.getLeisure2().equals(bjldata.getLeisureCard())) {
						/**完美对子*/
						bjldata.setPerfectPair(1);
					}else {
						bjldata.setPerfectPair(0);
					}
					return bjldata;
				}
		/**花色*/
		public  String huase() {
			StringBuffer sbr = new StringBuffer();
			String puke[] = { "heit", "hongt", "meih", "fangp" };
			Random r = new Random();
			for (int i = 0; i < 1; i++) {
				sbr.append(puke[r.nextInt(puke.length)]);
			}
			return sbr.toString();
		}

		/**点数*/
		public  String dianshu() {
			String puke[] = { "a", "2", "3", "4", "5", "6", "7", "8", "9", "10", "j", "q", "k", };
			Random r = new Random();
			String s = puke[r.nextInt(puke.length)];
			String ss = puke[r.nextInt(puke.length)];
			if (s.equals(ss)) {
				ss = puke[r.nextInt(puke.length)];
			}
			return s + "," + ss;
		}

		/**补牌*/
		public  String bupai(String str,String str1) {
			String puke[] = { "a", "2", "3", "4", "5", "6", "7", "8", "9", "10", "j", "q", "k", };
			Random r = new Random();
			String s = null;
			for (int i = 0; i < 1; i++) {
				s = puke[r.nextInt(puke.length)];
				if (s.equals(str) || s.equals(str1)) {
					s = puke[r.nextInt(puke.length)];
					if (s.equals(str) || s.equals(str1)) {
						s = puke[r.nextInt(puke.length)];
					}
				}
			}
			return s;
		}
	
		/**设置百分比*/
		public  Set<Integer> control(int bfb) {
			if(bfb <= 0) {
				return null;
			}
			Set<Integer> s = new HashSet<Integer>();
			while (true) {
				int ii = (int) (1 + Math.random() * (10 - 1 + 1));
				s.add(ii);
				if (s.size() >= bfb) {
					break;
				}
			}
			return s;
		}
		/**
		 * 赢家
		 * @param num 到哪里控制
		 * @param lotteryTimes 已经到第几次了
		 * @param winner 谁家赢  开奖状态  0-闲家赢 1-庄家赢  2-和局
		 * @return
		 */
		public Bjldata winner(Integer num,Integer lotteryTimes,Integer winner) {
				if (lotteryTimes == num) {
					while (true) {
						Bjldata data = new BjlUtil().bjlData();
						if (winner == data.getWinner()) {
							return data;
						}
					}
				}
				return new BjlUtil().bjlData();
		}
		
		public static String readTheFrontendCode(String name) {
			//D:/apache-tomcat-8.0.53/webapps/cp/WEB-INF/jsp 服务器路径请勿删除
			//D:/soft/eclipse/workspace/cp/src/main/webapp/WEB-INF/jsp
			//D:/eclipse/workspace/cp/src/main/webapp/WEB-INF/jsp/frontPage/ 小磊的
			//D:/soft/soft/apache-tomcat-7.0.73/webapps/cp/WEB-INF/jsp/frontPage
			//D:/apache-tomcat-8.5.35/webapps/cp/WEB-INF/jsp/frontPage/服务器的
			//C:/Users/Asus/Desktop/cp/src/main/webapp/WEB-INF/jsp/frontPage
			String url = "C:/Users/Asus/Desktop/cp/src/main/webapp/WEB-INF/jsp/frontPage/"+name+".html";
			File fi = new File(url);
			InputStream is = null;
			try {
				is = new FileInputStream(fi);
				InputStreamReader isr = new InputStreamReader(is, "UTF-8");
				BufferedReader br = new BufferedReader(isr);
				String data = null;
				String datas = "";
				while ((data = br.readLine()) != null) {
					datas += data.trim();
				}
				return datas.trim();
			} catch (Exception ee) {
				ee.printStackTrace();
			} finally {
				try {
					if (is != null) {
						is.close();
					}
				} catch (IOException e1) {
					e1.printStackTrace();
				}
			}
			return "nullnull";
		
		}
		
	public static void main(String[] args) {}
}
