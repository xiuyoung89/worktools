package com.ja.dao;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.ja.domain.FanshuiJl;
import com.ja.domain.TodayRecord;

public interface FanshuiJlMapper {
	
	 /**增加反水记录*/
	int add(@Param("f")FanshuiJl f);
	
	 /**增加月反水记录*/
	int add1(@Param("f")FanshuiJl f);
	
	/**根据时间和id去查询日反水记录*/
	FanshuiJl getOneFanshui(@Param("id")Integer id, @Param("time")String time4);
	
	/**根据时间和id去查询月反水记录*/
	FanshuiJl getTowFanshui(@Param("id")Integer id, @Param("time")String time4);
	
	/**
	 * 添加今天的运营记录
	 * @param gcRebate 反水设置信息
	 * @return
	 */
	
	int insertTodayRecord(TodayRecord record);
	
	/**
	 * 查询今天的总运营记录
	 * @return
	 */
	TodayRecord findSumTodayRecord(String date);

	/**
	 * 查询今天的运营记录
	 * @return
	 */
	List<TodayRecord> findTodayRecord(Integer type,String date);
	
	/**
	 * 查询某一段时间的总运营记录
	 * @return
	 */
	TodayRecord findSumTermRecord(String date1,String date2,String name,String daili);
	
	/**
	 * 查询某一段时间的运营记录
	 * @return
	 */
	List<TodayRecord> findTermRecord(String date1,String date2,String name,String daili,String type);
	
	
}
