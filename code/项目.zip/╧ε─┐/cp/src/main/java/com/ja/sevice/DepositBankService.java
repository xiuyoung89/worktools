package com.ja.sevice;

import java.util.List;

import com.ja.domain.DepositBank;

public interface DepositBankService {
   
	  /**修改银行卡信息*/
    int updateDepositInfo(DepositBank bank); 
    
    /**添加银行卡信息*/
    int addDepositInfo(DepositBank bank); 
	
	/**查询银行卡信息*/
    List<DepositBank> getAllDepositBank();

    /**删除银行卡信息*/
	int delDepositInfo(Integer id);
    
}
