package com.ja.sevice.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ja.dao.RechargeInterfaceMapper;
import com.ja.dao.RechargeQueryMapper;
import com.ja.domain.PayMoney;
import com.ja.domain.RechargeInterface;
import com.ja.sevice.RechargeInterfaceService;

@Service
public class RechargeInterfaceServiceImpl implements RechargeInterfaceService {
	
	@Autowired
    private RechargeInterfaceMapper rechargeInterfaceMapper;
	
	@Autowired
	private RechargeQueryMapper rechargeQueryMapper;

	@Override
	public List<RechargeInterface> getRecharge() {
		return rechargeInterfaceMapper.getRecharge();
	}
	
	@Override
	public int insertRecharge(RechargeInterface recharge) {
		return rechargeInterfaceMapper.insertRecharge(recharge);
	}

	@Override
	public int updateRecharge(RechargeInterface recharge) {
		recharge.setShopName("apple");
		return rechargeInterfaceMapper.updateRecharge(recharge);
	}

	@Override
	public List<PayMoney> getQueryInfo(Integer id) {
		return rechargeQueryMapper.getQueryInfo(id);
	}

	
}