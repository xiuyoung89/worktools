package com.ja.controller;

import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Random;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.ja.config.WebsiteStateConfig;
import com.ja.domain.AppDownload;
import com.ja.domain.ColorVariety;
import com.ja.domain.Data;
import com.ja.domain.IndexPicture;
import com.ja.domain.Lotter;
import com.ja.domain.Sy;
import com.ja.domain.User;
import com.ja.sevice.IAdminService;
import com.ja.sevice.ILotteryService;
import com.ja.sevice.InfoNoticeService;
import com.ja.util.JsonResult;
/**
 * 
 * 项目名称：cp   
 * 类名称：CommonController.java   
 * 类描述：   pc首页 页面
 * 创建人：   GL
 * 创建时间：2018年10月29日 上午11:08:36   
 * @version v1.0.0
 */
@RequestMapping("/pc")
@Controller
public class PC_CommonController {

	@Autowired
	private IAdminService adminService;
	
	@Autowired
	private InfoNoticeService infoNotiService;
	
	@Autowired
	private ILotteryService lotterService;
	
	/**
	 *   方法名：index   
	 *   描述：     pc端公共页面                     
	 *   参数：    @return 
	 * @return: String
	 */
	@RequestMapping("/index")
	public ModelAndView index(HttpServletRequest request,HttpSession session,ModelAndView model) {
		if (request.getQueryString() != null) {
			String refCode = request.getServerName() + "?" + (request.getQueryString());
			session.setAttribute("refCode", refCode);
		}
		AppDownload app = adminService.findAppImgPath();
		model.setViewName("pc/index");
		model.addObject("app", app);
		model.addObject("url", request.getHeader("Referer"));
		model.addObject("yqm", session.getAttribute("refCode"));
		return model;
	}
	
	/**
	 * 返回PC端支付宝支付页面
	 * @return
	 */
	@RequestMapping("/onlineAlipayzfb")
	public String onlineAlipayzfb(){
		return "pc/personal/onlineAlipayzfb";
	}
	
	
	/**
	 *   方法名：sy   
	 *   描述：     pc端首页页面                    
	 *   参数：    @return  
	 * @return: String
	 */
	@RequestMapping("/sy")
	public String sy() {
		return "pc/sy";
	}
	
	
	
	/**
	 *   方法名：lotter   
	 *   描述：     彩票页面                    
	 *   参数：    @return  
	 * @return: String
	 */
	@RequestMapping("/lotter")
	public String lotter() {
		return "pc/lotter";
	}
	/**
	 *   方法名：sports   
	 *   描述：     体彩页面                     
	 *   参数：    @return 
	 * @return: String
	 */
	@RequestMapping("/sports")
	public String sports() {
		return "/sports";
	}
	
	/**
	 *   方法名：mobilegc   
	 *   描述：     手机购彩页面                    
	 *   参数：    @return 
	 * @return: String
	 */
	@RequestMapping("/mobilegc")
	public ModelAndView mobilegc(ModelAndView model) {  
		AppDownload app = adminService.findAppImgPath();
		model.setViewName("pc/mobilegc");
		model.addObject("app", app);
		return model;
	}
	
	/**
	 *   方法名：activity   
	 *   描述：     pc端优惠活动 页面                    
	 *   参数：    @return 
	 * @return: String
	 */
	@RequestMapping("/activity")
	public String activity() {
		return "pc/activity";
	}
	
	/**
	 *   方法名：drawNotice   
	 *   描述：     pc端开奖公告 页面                    
	 *   参数：    @return 
	 * @return: String
	 */
	@RequestMapping("/drawNotice")
	public String drawNotice() {
		return "pc/drawNotice";
	}
	
	/**
	 *   方法名：trendChart   
	 *   描述：     pc端走势图表 页面                    
	 *   参数：    @return 
	 * @return: String
	 */
	@RequestMapping("/trendChart")
	public String trendChart() {
		return "pc/trendChart";
	}
	
	/**
	 *   方法名：exit   
	 *   描述：     退出登录                  
	 *   参数：    @return 
	 * @return: String
	 */
	@ResponseBody
	@RequestMapping("/exit")
	public JsonResult exit(HttpSession session) {
		session.removeAttribute("user");
		return new JsonResult("退出成功",1);
	}
	
	/**
	 *   方法名：register   
	 *   描述：     pc注册 页面                    
	 *   参数：    @return 
	 * @return: String
	 */
	@RequestMapping("/register")
	public String register() {
		return "pc/register";
	}
	
	
	/**
	 *   方法名：drawdetail   
	 *   描述：     pc开奖公告页面详情                    
	 *   参数：    @return 
	 * @return: String
	 */
	@RequestMapping("/drawdetail")
	public String drawdetail() {
		return "pc/drawdetail";
	}
	
	/**
	 *   方法名：rule   
	 *   描述：     pc玩法规则 页面                    
	 *   参数：    @return 
	 * @return: String
	 */
	@RequestMapping("/rule")
	public String rule() {
		return "pc/rule";
	} 
	
	/**
	 *   方法名：personal   
	 *   描述：     pc端用户中心                    
	 *   参数：    @return 
	 * @return: String
	 */
	@RequestMapping("/personal") 
	public String personal() {
		return "pc/personal";
	}
	
	
	
	
	/**
	 *   方法名：touzhu   
	 *   描述：     pc投注页面                    
	 *   参数：    @return 
	 * @return: String
	 */
	@RequestMapping("/touzhu") 
	public String touzhu() {
		return "pc/touzhu";
	}
	
	/**
	 *   方法名：helpCenter   
	 *   描述：     pc帮助中心页面                    
	 *   参数：    @return 
	 * @return: String
	 */
	@RequestMapping("/help") 
	public String helpCenter() {
		return "pc/help";
	}
	
	/**
	 *   方法名：bjlroom   
	 *   描述：     百家乐房间页面                   
	 *   参数：    @return 
	 * @return: String
	 */
	@RequestMapping("/bjl") 
	public String bjlroom() {
		return "pc/bjl";
	}
	
	/**
	 *   方法名：bjllot   
	 *   描述：     百家乐下注页面                   
	 *   参数：    @return 
	 * @return: String
	 */
	@RequestMapping("/bjllot") 
	public String bjllot() {
		return "pc/bjllot";
	}
	
	/**
	 *   方法名：userCenter   
	 *   描述：     用户中心的个人中心页面                   
	 *   参数：    @return 
	 * @return: String
	 */
	@RequestMapping("/userCenter") 
	public String userCenter() {
		return "pc/personal/userCenter";
	}
	
	
	/**
	 *   方法名：chooseGroup   
	 *   描述：     用户中心的充值类型页面                   
	 *   参数：    @return 
	 * @return: String
	 */
	@RequestMapping("/chooseGroup") 
	public String chooseGroup() {
		return "pc/personal/chooseGroup";
	}
	
	/**
	 *   方法名：rechargeIndex   
	 *   描述：     用户中心的选择金额页面                   
	 *   参数：    @return 
	 * @return: String
	 */
	@RequestMapping("/rechargeIndex") 
	public String rechargeIndex() {
		return "pc/personal/rechargeIndex";
	}

	/**
	 *   方法名：chooseAccount   
	 *   描述：     用户中心的充值填写信息页面                   
	 *   参数：    @return 
	 * @return: String
	 */
	@RequestMapping("/chooseAccount") 
	public String chooseAccount() {
		return "pc/personal/chooseAccount";
	}
	
	/**
	 *   方法名：withdraw   
	 *   描述：     用户中心的提现页面                   
	 *   参数：    @return 
	 * @return: String
	 */
	@RequestMapping("/withdraw") 
	public String withdraw() {
		return "pc/personal/withdraw";
	}
	
	/**
	 *   方法名：czrecord   
	 *   描述：     用户中心的充值记录页面                   
	 *   参数：    @return 
	 * @return: String
	 */
	@RequestMapping("/czrecord") 
	public String czrecord() {
		return "pc/personal/czrecord";
	}
	
	/**
	 *   方法名：txrecord   
	 *   描述：     用户中心的提现记录页面                   
	 *   参数：    @return 
	 * @return: String
	 */
	@RequestMapping("/txrecord") 
	public String txrecord() {
		return "pc/personal/txrecord";
	}
	
	/**
	 *   方法名：transactionRecord   
	 *   描述：     用户中心的交易记录页面                   
	 *   参数：    @return 
	 * @return: String
	 */
	@RequestMapping("/transactionRecord") 
	public String transactionRecord() {
		return "pc/personal/transactionRecord";
	}
	
	/**
	 *   方法名：messageNotice   
	 *   描述：     用户中心的信息公告页面                   
	 *   参数：    @return 
	 * @return: String
	 */
	@RequestMapping("/messageNotice") 
	public String messageNotice() {
		return "pc/personal/messageNotice";
	}
	
	/**
	 *   方法名：agentExplain   
	 *   描述：     用户中心的代理说明页面                   
	 *   参数：    @return 
	 * @return: String
	 */
	@RequestMapping("/agentExplain") 
	public String agentExplain() {
		return "pc/personal/agentExplain";
	}
	
	/**
	 *   方法名：userManage   
	 *   描述：     用户中心的用户管理页面                   
	 *   参数：    @return 
	 * @return: String
	 */
	@RequestMapping("/userManage") 
	public String userManage() {
		return "pc/personal/userManage";
	}
	
	/**
	 *   方法名：agentCommission   
	 *   描述：     用户中心的代理佣金页面                   
	 *   参数：    @return 
	 * @return: String
	 */
	@RequestMapping("/agentCommission") 
	public String agentCommission() {
		return "pc/personal/agentCommission";
	}
	
	/**
	 *   方法名：reportStatistics   
	 *   描述：     用户中心的报表统计页面                   
	 *   参数：    @return 
	 * @return: String
	 */
	@RequestMapping("/reportStatistics") 
	public String reportStatistics() {
		return "pc/personal/reportStatistics";
	}
	
	/* 代理第二套  */
	
	/**
	 *   方法名：agentExplainNew   
	 *   描述：     用户中心的代理说明新页面                   
	 *   参数：    @return 
	 * @return: String
	 */
	@RequestMapping("/agentExplainNew") 
	public String agentExplainNew() {
		return "pc/personal/agentExplainNew";
	}
	
	/**
	 *   方法名：teamReportNew   
	 *   描述：   团队报表新 页面                
	 *   参数：    @return 
	 * @return: String
	 */
	@RequestMapping("/teamReportNew") 
	public String teamReportNew() {
		return "pc/personal/teamReportNew";
	}
	
	
	/**
	 *   方法名：subReportNew   
	 *   描述：     用户中心的下级报表新页面                   
	 *   参数：    @return 
	 * @return: String
	 */
	@RequestMapping("/subReportNew") 
	public String subReportNew() {
		return "pc/personal/subReportNew";
	}
	
	/**
	 *   方法名：subAccountNew   
	 *   描述：     用户中心的下级开户新页面                   
	 *   参数：    @return 
	 * @return: String
	 */
	@RequestMapping("/subAccountNew") 
	public String subAccountNew() {
		return "pc/personal/subAccountNew";
	}
	
	/**
	 *   方法名：subMenageNew   
	 *   描述：     用户中心的下级管理新页面                   
	 *   参数：    @return 
	 * @return: String
	 */
	@RequestMapping("/subManageNew") 
	public String subManageNew() {
		return "pc/personal/subManageNew";
	}
	
	
	/**
	 *   方法名：subBetRecordNew   
	 *   描述：     用户中心的下级投注记录新页面                   
	 *   参数：    @return 
	 * @return: String
	 */
	@RequestMapping("/subBetRecordNew") 
	public ModelAndView subBetRecordNew() {
		ModelAndView m = new ModelAndView("pc/personal/subBetRecordNew");
		return m;
	}
	
	/**
	 *   方法名：subTransitionNew   
	 *   描述：     用户中心的下级交易明细新页面                   
	 *   参数：    @return 
	 * @return: String
	 */
	@RequestMapping("/subTransitionNew") 
	public String subTransitionNew() {
		return "pc/personal/subTransitionNew";
	}
	
	/**
	 *   方法名：onlineAlipay   
	 *   描述：     在线支付宝支付页面                   
	 *   参数：    @return 
	 * @return: String
	 */
	@RequestMapping("/onlineAlipay") 
	public String onlineAlipay() {
		return "pc/personal/onlineAlipay";
	}
	
	
	
	
	/**
	 *   方法名   公共页面   
	 *   描述：     pc公共页面                    
	 *   参数：    @return 
	 * @return: String
	 */
	@ResponseBody
	@RequestMapping("/commonPage")
	public JsonResult commonPage() {  
		AppDownload app = adminService.findAppImgPath();
		return new JsonResult("app",app);
	}
	
	/**
	 *   方法名：kefu   
	 *   描述：     pc客服页面                    
	 *   参数：    @return 
	 * @return: String
	 */
	@RequestMapping("/kefu") 
	public String contactKefu() {
		return "pc/kefu";
	}
	
	@ResponseBody
	@RequestMapping("/useronline")
	public JsonResult useronline(HttpSession session) {
		User user = (User)session.getAttribute("user");
		return new JsonResult("user",user);
	}
	
	@ResponseBody
	@RequestMapping("/homePageDataPc")
	public JsonResult homePageDataPc() {
		//app下载地址
		AppDownload app = adminService.findAppImgPath();
		//轮播图
		IndexPicture indexPicture = infoNotiService.getOneByPictureDesc();
		//开奖数据
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
		List<Data> lotterList = lotterService.getAllLotters1();
		for(Data data :lotterList) {
			data.setNextStopOrderTimeEpoch(data.getNextStopOrderTimeEpoch().replaceAll("-", "/"));
		}
		//中奖数据
		DecimalFormat df = new DecimalFormat("0.00");
		String[] str = {  "北京PK拾","二分PK拾", "幸运赛马","幸运飞艇", "重庆时时彩", "二分时时彩", "天津时时彩","新疆时时彩", "广东快乐十分", "重庆快乐十分", "安徽11选5",
				"广东11选5", "江西11选5", "山东11选5", "上海11选5", "排列三", "福彩3D", "安徽快3", "广西快3", "江苏快3", "北京快3","三分快3","香港六合彩","五分六合彩",
				"北京28","幸运28","加拿大28","百家乐" };
		List<Sy> list2 = new ArrayList<Sy>();
		for (int i = 0; i < str.length-1; i++) {
			Sy o1 = new Sy();
			o1.setHuiyuanzh(createUserName(4));
			o1.setCname1(str[createLotteryName(str.length - 1)]);
			o1.setGoalmoney(new Double(df.format((Math.random() * 1000))));
			list2.add(o1);
		}
		 List<ColorVariety> list = new ArrayList<ColorVariety>();//彩种的状态  1开启  2关闭
		 for(Lotter l : WebsiteStateConfig.lotteryState) {
			 if(!"jlk3".equals(l.getCname().trim()) && !"klpk".equals(l.getCname().trim())  && !"zc".equals(l.getCname().trim())  && !"jnd28".equals(l.getCname().trim())) {
				 list.add(new ColorVariety(l.getCname(),l.getState()));
			 }
		}
	/*	
		//首页公告
		Notice n = new Notice();
		IndexPicture ipe = infoNotiService.getOneByPictureDesc();
		InfoNotice ifne =  infoNotiService.getOneByNoticeDesc("首页公告");
		n.setWangzhantitle(WebsiteStateConfig.configs.get("wangzhantitle"));
		n.setNotice(WebsiteStateConfig.configs.get("notice"));
		n.setPicturePath1(ipe.getPicturePath1());
		n.setPicturePath2(ipe.getPicturePath2());
		n.setPicturePath3(ipe.getPicturePath3());
		n.setPicturePath4(ipe.getPicturePath4());
		n.setPicturePath5(ipe.getPicturePath5());
		n.setNoticePicture(ifne.getNoticePicture());
		n.setNoticeName(ifne.getNoticeName());
		n.setKefusbtime(WebsiteStateConfig.configs.get("kefusbtime"));
		n.setKefuxbtime(WebsiteStateConfig.configs.get("kefuxbtime"));
		n.setPc_welcome(WebsiteStateConfig.configs.get("pc_welcome"));//Pc网站标题
		n.setWangzhantitle(WebsiteStateConfig.configs.get("wangzhantitle"));//网站标题
		n.setPc_wechat(WebsiteStateConfig.configs.get("pc_wechat"));//PC微信图标
		n.setLogo(WebsiteStateConfig.configs.get("logo"));//PClogo
*/		return new JsonResult(sdf.format(new Date()),app,indexPicture,lotterList,list2,list);
	}
	
	 /**
	 * 方法名：createUserName 
	 * 描述：    随机生成用户名                   
	 * 参数：    @param length
	 * 参数：    @return 
	 * @return: String
	 */
	public String createUserName(int length) {
		// 定义一个字符串（A-Z，a-z，0-9）即62位；
		String str = "zxcvbnmlkjhgfdsaqwertyuiopQWERTYUIOPASDFGHJKLZXCVBNM1234567890";
		// 由Random生成随机数
		Random random = new Random();
		StringBuffer sb = new StringBuffer();
		// 长度为几就循环几次
		for (int i = 0; i < length; ++i) {
			// 产生0-61的数字
			int number = random.nextInt(62);
			// 将产生的数字通过length次承载到sb中
			sb.append(str.charAt(number));
		}
		// 将承载的字符转换成字符串
		return sb.toString();
	}

	/***
	 * 方法名：createLotteryName 
	 * 描述：    随机取彩种名称                    
	 * 参数：    @param num
	 * 参数：    @return 
	 * @return: int
	 */
	public int createLotteryName(int num) {
		while (true) {
			int ii = (int) (1 + Math.random() * num);
			if (num >= ii) {
				return ii;
			}
		}
	}
	
}
