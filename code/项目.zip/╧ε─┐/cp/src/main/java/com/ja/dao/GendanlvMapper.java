	package com.ja.dao;

import org.apache.ibatis.annotations.Param;

import com.ja.domain.Gendanlv;

public interface GendanlvMapper {
	
	/**查询跟单推荐费比率*/
	Gendanlv getFindRebate();
	
	/**修改跟单的推荐比率*/
	int updateGendanlv(@Param("g") Gendanlv gendan);
	
	/**添加跟单的推荐费规则*/
	int addGendanlv(@Param("g") Gendanlv gendan);
	
	/**刪除跟单的推荐费规则*/
	int delGendanlv(Integer id);

}