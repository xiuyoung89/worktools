package com.ja.dao;

import org.apache.ibatis.annotations.Param;

import com.ja.domain.BjlMoney;
import com.ja.domain.Data;

public interface BjlMoneyMapper {
	
	/**
	 * 添加用户的下注金额以及开奖金额信息
	 * @param moneys 订单信息
	 * @return
	 */
	int addOrderInfo(@Param("m") BjlMoney moneys);
	
	/**
	 * 查询用户的下注金额以及开奖金额信息
	 * @param moneys 订单信息
	 * @return
	 */
	BjlMoney findUserOrderInfo(@Param("m") BjlMoney moneys);
	
	void insertbjl(@Param("d")Data d);

	Data selectbjl(@Param("bjl")String bjl);
}
