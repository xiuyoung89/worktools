package com.ja.domain;

public class UpDataPage {
	@Override
	public String toString() {
		return "UpDataPage [id=" + id + ", name=" + name + ", page=" + page + ", value=" + value + ", getId()="
				+ getId() + ", getName()=" + getName() + ", getPage()=" + getPage() + ", getValue()=" + getValue()
				+ ", getClass()=" + getClass() + ", hashCode()=" + hashCode() + ", toString()=" + super.toString()
				+ "]";
	}
	private Integer id;
	private String name;
	private String page;
	private Integer value;
	private Integer status;
	public Integer getStatus() {
		return status;
	}
	public void setStatus(Integer status) {
		this.status = status;
	}
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getPage() {
		return page;
	}
	public void setPage(String page) {
		this.page = page;
	}
	public Integer getValue() {
		return value;
	}
	public void setValue(Integer value) {
		this.value = value;
	}
	
	
}
