package com.ja.controller;

import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.ja.config.WebsiteStateConfig;
import com.ja.domain.Jine;
import com.ja.domain.PagingData;
import com.ja.domain.User;
import com.ja.sevice.IUserService;
import com.ja.sevice.JineService;
import com.ja.util.JsonResult;

@RequestMapping("recharge")
@Controller
public class PC_RechargeController {
	
	@Autowired
	private JineService jineService;
	
	@Autowired
	private IUserService userService;
	
	/**
	 * 
	   *   方法名：findMoneyRecord   
	   *   描述：     根据条件查询                  TODO   
	   *   参数：    @param session
	   *   参数：    @param start 开始数
	   *   参数：    @param end 结束数
	   *   参数：    @param date1 开始时间
	   *   参数：    @param date2 结束时间
	   *   参数：    @param orderNum 订单号
	   *   参数：    @param model 查询类型 提款状态-充值方式
	   *   参数：    @param type 查询类型 1 提款 2 充值
	   *   参数：    @return 
	 * @return: JsonResult
	 */
	@RequestMapping("/findMoneyRecord")
	@ResponseBody
	public String findMoneyRecord(PagingData paging, HttpSession session,String date1,String date2,String orderNum,String model,Integer type) { 
		if("全部".equals(model)) {
			model = "";
		}
		User user = (User) session.getAttribute("user");
		Jine jine = new Jine();
		jine.setSqtime(date1);
		jine.setCltime(date2);
		jine.setOrdernum(orderNum);
		jine.setType(type+"");
		jine.setBeizhu(model);
		jine.setUserid(user.getId());
		paging.setAllCount(jineService.findMoneyRecordCounts(jine));
		paging.setList(jineService.findMoneyRecord(paging,jine));
		return PagingData.pagingData(paging);
	} 
	
	/**
	 * 查询用户今日提款情况
	   *   方法名：findUserDrawingInfo   
	   *   描述：                       TODO   
	   *   参数：    @param session
	   *   参数：    @return 
	 * @return: JsonResult
	 */
	@ResponseBody
	@RequestMapping("/findUserDrawingInfo") 
	public JsonResult findUserDrawingInfo(HttpSession session) {
		User user = (User) session.getAttribute("user");
		Map< String, Object> maps = new HashMap<String, Object>();
		Integer count = jineService.findUserTikuanInfoCounts(user.getId());
		Double money = jineService.findUserTikuanInfoSumMoney(user.getId());
		User user1 = userService.getUserByid(user.getId());
		maps.put("yue", user1.getBalance());
		maps.put("ketixianjine", user1.getBalance());
		maps.put("qukuanshijian", WebsiteStateConfig.configs.get("stratchulitime")+"-"+ WebsiteStateConfig.configs.get("endchulitime"));
		maps.put("jinriyitijine", money);
		maps.put("danbixiane", WebsiteStateConfig.configs.get("maxtikuanjine"));
		maps.put("jinriyitikuancishu", count);
		maps.put("meirixianzhicishu", WebsiteStateConfig.configs.get("meiritikuancount"));
		maps.put("meirixianzhijine", 100000);
		return new JsonResult("findUserDrawingInfo",maps); 
	}
	
}

