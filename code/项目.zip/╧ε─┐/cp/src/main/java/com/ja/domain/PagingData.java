package com.ja.domain;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import com.alibaba.fastjson.JSONObject;
import com.ja.util.DateUtil;

public class PagingData implements Serializable{
	
	private static final long serialVersionUID = -83914524657500834L;

	private Integer pageCount; //当前第几页
	
	private Integer startIndex; //当前起始记录数
	
	private Integer lineCount; // 每页的行数
	
	private Integer allCount; //总共的记录数
	
	private List<?> list = new ArrayList<>(); //展示的数据1
	
	private List<?> data = new ArrayList<>(); //展示的数据2
	
	private String replace1; //替代
	
	private String replace2; //替代
	
	private Integer replace3; //替代
	
    
    public static long getSerialversionuid() {
		return serialVersionUID;
	}
	public Integer getTime() {
		return time;
	}

	public void setTime(Integer time) {
		this.time = time;
	}

	private Integer replace4; //替代
	
	private Integer time; //替代
	
	
	public Integer getPageCount() {
		return pageCount;
	}

	public void setPageCount(Integer pageCount) {
		this.pageCount = pageCount;
	}

	public Integer getStartIndex() {
		return startIndex;
	}

	public void setStartIndex(Integer startIndex) {
		this.startIndex = startIndex;
	}

	public Integer getLineCount() {
		return lineCount;
	}

	public void setLineCount(Integer lineCount) {
		this.lineCount = lineCount;
	}
	
	public Integer getAllCount() {
		return allCount;
	}

	public void setAllCount(Integer allCount) {
		this.allCount = allCount;
	}

	public List<?> getList() {
		return list;
	}

	public void setList(List<?> list) {
		this.list = list;
	}

	public List<?> getData() {
		return data;
	}
	public void setData(List<?> data) {
		this.data = data;
	}
	public String getReplace1() {
		return replace1;
	}

	public void setReplace1(String replace1) {
		this.replace1 = replace1;
	}

	public String getReplace2() {
		return replace2;
	}

	public void setReplace2(String replace2) {
		this.replace2 = replace2;
	}

	public Integer getReplace3() {
		return replace3;
	}

	public void setReplace3(Integer replace3) {
		this.replace3 = replace3;
	}

	public Integer getReplace4() {
		return replace4;
	}

	public void setReplace4(Integer replace4) {
		this.replace4 = replace4;
	}

	@Override
	public String toString() {
		return "PagingData [pageCount=" + pageCount + ", startIndex=" + startIndex + ", lineCount=" + lineCount
				+ ", allCount=" + allCount + ", list=" + list + ", data=" + data + ", replace1=" + replace1
				+ ", replace2=" + replace2 + ", replace3=" + replace3 + ", replace4=" + replace4 + ", time=" + time
				+ "]";
	}
	/**
	  * 分页显示数据
	 * @param <T> 传入的泛型
	 * @param list 查询的数据
	 * @param getAllCount 总共多少行
	 * @param pageCount 当前第几页
	 * @param time 当前时间
	 * @param data 显示数据2
	 * @param replace1 其他值显示替换字段1
	 * @return
	 */
	public static String pagingData(PagingData paging) {
		JSONObject data = new JSONObject();
		data.put("sEcho", paging.getPageCount());// 当前展示的第几页
		data.put("iTotalRecords", paging.getAllCount());// 实际总共的行数
		data.put("iTotalDisplayRecords",paging.getAllCount());// 显示的总共行数
		data.put("aaData", paging.getList());// 显示数据1
		data.put("time", DateUtil.getCurrTime());//当前时间
		data.put("data", paging.getData());//显示数据2
		data.put("replace1", paging.getReplace1());//其他值显示替换字段1
		data.put("replace2", paging.getReplace2());//其他值显示替换字段1
		return JSONObject.toJSONString(data);
	}

}