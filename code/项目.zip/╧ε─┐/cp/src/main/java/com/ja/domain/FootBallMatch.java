package com.ja.domain;

import java.io.Serializable;

public class FootBallMatch implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 8990360737828682522L;

	/** 默认初始值 */
	public static final String DEFAULT_INIT_VALUE  = "no" ;
	
    private Integer id ; // 足彩 赛事信息

    private String league = DEFAULT_INIT_VALUE ; //赛事名称

    private String match_time = DEFAULT_INIT_VALUE ; // 滚球 赛事进行实践

    private String start_time = DEFAULT_INIT_VALUE ; //赛事 开始时间

    private String team_h = DEFAULT_INIT_VALUE ; //主队名称

    private String team_c = DEFAULT_INIT_VALUE ; //客队名称

    private String gnum_h = DEFAULT_INIT_VALUE ; //主队编号

    private String gnum_c = DEFAULT_INIT_VALUE ; //客队编号

    private String strong = DEFAULT_INIT_VALUE ; // 滚球图标 区别

    private String ctime = DEFAULT_INIT_VALUE ; //现在时间

    private String roll = DEFAULT_INIT_VALUE ; // 
    
    private Integer fid; //赛事 目录id 

    private String type = DEFAULT_INIT_VALUE ; //玩法类别 单式 波胆 入球数 滚球 半全场 综合过关

    private String types = DEFAULT_INIT_VALUE ; //投注类型 滚球 今日  早盘

    private String dy_h = DEFAULT_INIT_VALUE ; //单式  全场独赢 主队

    private String dy_c = DEFAULT_INIT_VALUE ; //单式  全场独赢 客队

    private String dy_d = DEFAULT_INIT_VALUE ; //单式  全场独赢 和

    private String fh_dy_h = DEFAULT_INIT_VALUE ; //单式  半场独赢 主队

    private String fh_dy_c = DEFAULT_INIT_VALUE ; //单式  半场独赢 客队

    private String fh_dy_d = DEFAULT_INIT_VALUE ; //单式  半场独赢 和

    private String rq_h = DEFAULT_INIT_VALUE ; //单式  全场让球 主队

    private String rq_c = DEFAULT_INIT_VALUE ; //单式  全场让球 客队

    private String des_rq = DEFAULT_INIT_VALUE ; //单式  全场让球 盘口

    private String fh_rq_h = DEFAULT_INIT_VALUE ; //单式  半场让球 主队

    private String fh_rq_c = DEFAULT_INIT_VALUE ; //单式  半场让球 客队

    private String des_fh_rq = DEFAULT_INIT_VALUE ; //单式  半场让球 盘口

    private String dx_h = DEFAULT_INIT_VALUE ; //单式  全场大小 主队

    private String dx_c = DEFAULT_INIT_VALUE ; //单式  全场大小  客队

    private String des_dx_h = DEFAULT_INIT_VALUE ; //单式  全场大小盘口 主队

    private String des_dx_c = DEFAULT_INIT_VALUE ; //单式  全场大小盘口 客队

    private String fh_dx_h = DEFAULT_INIT_VALUE ; //单式  半场大小 主队

    private String fh_dx_c = DEFAULT_INIT_VALUE ; //单式  半场大小 客队

    private String des_fh_dx_h = DEFAULT_INIT_VALUE ; //单式  半场大小盘口  主队

    private String des_fh_dx_c = DEFAULT_INIT_VALUE ; //单式  半场大小盘口  客队

    private String ds_h = DEFAULT_INIT_VALUE ; //单式  全场单双  主队

    private String ds_c = DEFAULT_INIT_VALUE ; //单式  全场单双  客队

    private String score_h = DEFAULT_INIT_VALUE ; //比赛 主队 比分

    private String score_c = DEFAULT_INIT_VALUE ; //比赛 客队 比分
    
    private String fh_score_h = DEFAULT_INIT_VALUE ; //半场比分 主队

    private String fh_score_c = DEFAULT_INIT_VALUE ; //半场比分 客队

    private String redcard_h = DEFAULT_INIT_VALUE ; //比赛 主队 罚牌

    private String redcard_c = DEFAULT_INIT_VALUE ; //比赛 客队 罚牌

    private String bf10_h = DEFAULT_INIT_VALUE ; //波胆 比分 1:0 主队

    private String bf10_c = DEFAULT_INIT_VALUE ; //波胆 比分 1:0 客队

    private String bf20_h = DEFAULT_INIT_VALUE ; //波胆 比分 2:0 主队

    private String bf20_c = DEFAULT_INIT_VALUE ; //波胆 比分 2:0 客队

    private String bf21_h = DEFAULT_INIT_VALUE ; //波胆 比分 2:1 主队

    private String bf21_c = DEFAULT_INIT_VALUE ; //波胆 比分 2:1 客队

    private String bf30_h = DEFAULT_INIT_VALUE ; //波胆 比分 3:0 主队

    private String bf30_c = DEFAULT_INIT_VALUE ; //波胆 比分 3:0 客队

    private String bf31_h = DEFAULT_INIT_VALUE ; //波胆 比分 3:1 主队

    private String bf31_c = DEFAULT_INIT_VALUE ; //波胆 比分 3:1 客队

    private String bf32_h = DEFAULT_INIT_VALUE ; //波胆 比分 3:2 主队

    private String bf32_c = DEFAULT_INIT_VALUE ; //波胆 比分 3:2 客队

    private String bf40_h = DEFAULT_INIT_VALUE ; //波胆 比分 4:0 主队

    private String bf40_c = DEFAULT_INIT_VALUE ; //波胆 比分 4:0 客队

    private String bf41_h = DEFAULT_INIT_VALUE ; //波胆 比分 4:1 主队

    private String bf41_c = DEFAULT_INIT_VALUE ; //波胆 比分 4:1 客队

    private String bf42_h = DEFAULT_INIT_VALUE ; //波胆 比分 4:2 主队

    private String bf42_c = DEFAULT_INIT_VALUE ; //波胆 比分 4:2 客队

    private String bf43_h = DEFAULT_INIT_VALUE ; //波胆 比分 4:3 主队

    private String bf43_c = DEFAULT_INIT_VALUE ; //波胆 比分 4:3 客队
 
    private String bf00 = DEFAULT_INIT_VALUE ; //波胆 比分 0:0

    private String bf11 = DEFAULT_INIT_VALUE ; //波胆 比分 1:1

    private String bf22 = DEFAULT_INIT_VALUE ; //波胆 比分 2:2

    private String bf33 = DEFAULT_INIT_VALUE ; //波胆 比分 3:3

    private String bf44 = DEFAULT_INIT_VALUE ; //波胆 比分 4:4

    private String other = DEFAULT_INIT_VALUE ; //波胆 比分 其他
 
    private String rq01 = DEFAULT_INIT_VALUE ; //入球数 0-1

    private String rq23 = DEFAULT_INIT_VALUE ; //入球数  2-3

    private String rq46 = DEFAULT_INIT_VALUE ; //入球数  4-6

    private String rq7 = DEFAULT_INIT_VALUE ; //入球数  7个及7个以上

    private String hh = DEFAULT_INIT_VALUE ; //半全场 主主

    private String hd = DEFAULT_INIT_VALUE ; //半全场 主和

    private String hc = DEFAULT_INIT_VALUE ; //半全场 主客

    private String dh = DEFAULT_INIT_VALUE ; //半全场  和主

    private String dd = DEFAULT_INIT_VALUE ; //半全场 和和

    private String dc = DEFAULT_INIT_VALUE ; //半全场  和客

    private String ch = DEFAULT_INIT_VALUE ; //半全场 客主

    private String cd = DEFAULT_INIT_VALUE ; //半全场 客和

    private String cc = DEFAULT_INIT_VALUE ; //半全场 客客
    
	private String sg_num = DEFAULT_INIT_VALUE ; //综合过关 串数
	
    private String end_sign = DEFAULT_INIT_VALUE ; // 比赛是否结束 默认没有 

    private String peril = DEFAULT_INIT_VALUE ; // 滚球是是否是危险球  默认不是

    private String isOutDated = DEFAULT_INIT_VALUE ; // 该条比赛信息是否有效：no-没有过期，yes-已经过期
    
    public static long getSerialversionuid() {
		return serialVersionUID;
	}
    
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getLeague() {
		return league;
	}

	public void setLeague(String league) {
		this.league = league;
	}

	public String getMatch_time() {
		return match_time;
	}

	public void setMatch_time(String match_time) {
		this.match_time = match_time;
	}

	public String getStart_time() {
		return start_time;
	}

	public void setStart_time(String start_time) {
		this.start_time = start_time;
	}

	public String getTeam_h() {
		return team_h;
	}

	public void setTeam_h(String team_h) {
		this.team_h = team_h;
	}

	public String getTeam_c() {
		return team_c;
	}

	public void setTeam_c(String team_c) {
		this.team_c = team_c;
	}

	public String getGnum_h() {
		return gnum_h;
	}

	public void setGnum_h(String gnum_h) {
		this.gnum_h = gnum_h;
	}

	public String getGnum_c() {
		return gnum_c;
	}

	public void setGnum_c(String gnum_c) {
		this.gnum_c = gnum_c;
	}

	public String getStrong() {
		return strong;
	}

	public void setStrong(String strong) {
		this.strong = strong;
	}

	public String getCtime() {
		return ctime;
	}

	public void setCtime(String ctime) {
		this.ctime = ctime;
	}

	public String getRoll() {
		return roll;
	}

	public void setRoll(String roll) {
		this.roll = roll;
	}

	public Integer getFid() {
		return fid;
	}

	public void setFid(Integer fid) {
		this.fid = fid;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getTypes() {
		return types;
	}

	public void setTypes(String types) {
		this.types = types;
	}

	public String getDy_h() {
		return dy_h;
	}

	public void setDy_h(String dy_h) {
		this.dy_h = dy_h;
	}

	public String getDy_c() {
		return dy_c;
	}

	public void setDy_c(String dy_c) {
		this.dy_c = dy_c;
	}

	public String getDy_d() {
		return dy_d;
	}

	public void setDy_d(String dy_d) {
		this.dy_d = dy_d;
	}

	public String getFh_dy_h() {
		return fh_dy_h;
	}

	public void setFh_dy_h(String fh_dy_h) {
		this.fh_dy_h = fh_dy_h;
	}

	public String getFh_dy_c() {
		return fh_dy_c;
	}

	public void setFh_dy_c(String fh_dy_c) {
		this.fh_dy_c = fh_dy_c;
	}

	public String getFh_dy_d() {
		return fh_dy_d;
	}

	public void setFh_dy_d(String fh_dy_d) {
		this.fh_dy_d = fh_dy_d;
	}

	public String getRq_h() {
		return rq_h;
	}

	public void setRq_h(String rq_h) {
		this.rq_h = rq_h;
	}

	public String getRq_c() {
		return rq_c;
	}

	public void setRq_c(String rq_c) {
		this.rq_c = rq_c;
	}

	public String getDes_rq() {
		return des_rq;
	}

	public void setDes_rq(String des_rq) {
		this.des_rq = des_rq;
	}

	public String getFh_rq_h() {
		return fh_rq_h;
	}

	public void setFh_rq_h(String fh_rq_h) {
		this.fh_rq_h = fh_rq_h;
	}

	public String getFh_rq_c() {
		return fh_rq_c;
	}

	public void setFh_rq_c(String fh_rq_c) {
		this.fh_rq_c = fh_rq_c;
	}

	public String getDes_fh_rq() {
		return des_fh_rq;
	}

	public void setDes_fh_rq(String des_fh_rq) {
		this.des_fh_rq = des_fh_rq;
	}

	public String getDx_h() {
		return dx_h;
	}

	public void setDx_h(String dx_h) {
		this.dx_h = dx_h;
	}

	public String getDx_c() {
		return dx_c;
	}

	public void setDx_c(String dx_c) {
		this.dx_c = dx_c;
	}

	public String getDes_dx_h() {
		return des_dx_h;
	}

	public void setDes_dx_h(String des_dx_h) {
		this.des_dx_h = des_dx_h;
	}

	public String getDes_dx_c() {
		return des_dx_c;
	}

	public void setDes_dx_c(String des_dx_c) {
		this.des_dx_c = des_dx_c;
	}

	public String getFh_dx_h() {
		return fh_dx_h;
	}

	public void setFh_dx_h(String fh_dx_h) {
		this.fh_dx_h = fh_dx_h;
	}

	public String getFh_dx_c() {
		return fh_dx_c;
	}

	public void setFh_dx_c(String fh_dx_c) {
		this.fh_dx_c = fh_dx_c;
	}

	public String getDes_fh_dx_h() {
		return des_fh_dx_h;
	}

	public void setDes_fh_dx_h(String des_fh_dx_h) {
		this.des_fh_dx_h = des_fh_dx_h;
	}

	public String getDes_fh_dx_c() {
		return des_fh_dx_c;
	}

	public void setDes_fh_dx_c(String des_fh_dx_c) {
		this.des_fh_dx_c = des_fh_dx_c;
	}

	public String getDs_h() {
		return ds_h;
	}

	public void setDs_h(String ds_h) {
		this.ds_h = ds_h;
	}

	public String getDs_c() {
		return ds_c;
	}

	public void setDs_c(String ds_c) {
		this.ds_c = ds_c;
	}

	public String getScore_h() {
		return score_h;
	}

	public void setScore_h(String score_h) {
		this.score_h = score_h;
	}

	public String getScore_c() {
		return score_c;
	}

	public void setScore_c(String score_c) {
		this.score_c = score_c;
	}

	public String getFh_score_h() {
		return fh_score_h;
	}

	public void setFh_score_h(String fh_score_h) {
		this.fh_score_h = fh_score_h;
	}

	public String getFh_score_c() {
		return fh_score_c;
	}

	public void setFh_score_c(String fh_score_c) {
		this.fh_score_c = fh_score_c;
	}

	public String getRedcard_h() {
		return redcard_h;
	}

	public void setRedcard_h(String redcard_h) {
		this.redcard_h = redcard_h;
	}

	public String getRedcard_c() {
		return redcard_c;
	}

	public void setRedcard_c(String redcard_c) {
		this.redcard_c = redcard_c;
	}

	public String getBf10_h() {
		return bf10_h;
	}

	public void setBf10_h(String bf10_h) {
		this.bf10_h = bf10_h;
	}

	public String getBf10_c() {
		return bf10_c;
	}

	public void setBf10_c(String bf10_c) {
		this.bf10_c = bf10_c;
	}

	public String getBf20_h() {
		return bf20_h;
	}

	public void setBf20_h(String bf20_h) {
		this.bf20_h = bf20_h;
	}

	public String getBf20_c() {
		return bf20_c;
	}

	public void setBf20_c(String bf20_c) {
		this.bf20_c = bf20_c;
	}

	public String getBf21_h() {
		return bf21_h;
	}

	public void setBf21_h(String bf21_h) {
		this.bf21_h = bf21_h;
	}

	public String getBf21_c() {
		return bf21_c;
	}

	public void setBf21_c(String bf21_c) {
		this.bf21_c = bf21_c;
	}

	public String getBf30_h() {
		return bf30_h;
	}

	public void setBf30_h(String bf30_h) {
		this.bf30_h = bf30_h;
	}

	public String getBf30_c() {
		return bf30_c;
	}

	public void setBf30_c(String bf30_c) {
		this.bf30_c = bf30_c;
	}

	public String getBf31_h() {
		return bf31_h;
	}

	public void setBf31_h(String bf31_h) {
		this.bf31_h = bf31_h;
	}

	public String getBf31_c() {
		return bf31_c;
	}

	public void setBf31_c(String bf31_c) {
		this.bf31_c = bf31_c;
	}

	public String getBf32_h() {
		return bf32_h;
	}

	public void setBf32_h(String bf32_h) {
		this.bf32_h = bf32_h;
	}

	public String getBf32_c() {
		return bf32_c;
	}

	public void setBf32_c(String bf32_c) {
		this.bf32_c = bf32_c;
	}

	public String getBf40_h() {
		return bf40_h;
	}

	public void setBf40_h(String bf40_h) {
		this.bf40_h = bf40_h;
	}

	public String getBf40_c() {
		return bf40_c;
	}

	public void setBf40_c(String bf40_c) {
		this.bf40_c = bf40_c;
	}

	public String getBf41_h() {
		return bf41_h;
	}

	public void setBf41_h(String bf41_h) {
		this.bf41_h = bf41_h;
	}

	public String getBf41_c() {
		return bf41_c;
	}

	public void setBf41_c(String bf41_c) {
		this.bf41_c = bf41_c;
	}

	public String getBf42_h() {
		return bf42_h;
	}

	public void setBf42_h(String bf42_h) {
		this.bf42_h = bf42_h;
	}

	public String getBf42_c() {
		return bf42_c;
	}

	public void setBf42_c(String bf42_c) {
		this.bf42_c = bf42_c;
	}

	public String getBf43_h() {
		return bf43_h;
	}

	public void setBf43_h(String bf43_h) {
		this.bf43_h = bf43_h;
	}

	public String getBf43_c() {
		return bf43_c;
	}

	public void setBf43_c(String bf43_c) {
		this.bf43_c = bf43_c;
	}

	public String getBf00() {
		return bf00;
	}

	public void setBf00(String bf00) {
		this.bf00 = bf00;
	}

	public String getBf11() {
		return bf11;
	}

	public void setBf11(String bf11) {
		this.bf11 = bf11;
	}

	public String getBf22() {
		return bf22;
	}

	public void setBf22(String bf22) {
		this.bf22 = bf22;
	}

	public String getBf33() {
		return bf33;
	}

	public void setBf33(String bf33) {
		this.bf33 = bf33;
	}

	public String getBf44() {
		return bf44;
	}

	public void setBf44(String bf44) {
		this.bf44 = bf44;
	}

	public String getOther() {
		return other;
	}

	public void setOther(String other) {
		this.other = other;
	}

	public String getRq01() {
		return rq01;
	}

	public void setRq01(String rq01) {
		this.rq01 = rq01;
	}

	public String getRq23() {
		return rq23;
	}

	public void setRq23(String rq23) {
		this.rq23 = rq23;
	}

	public String getRq46() {
		return rq46;
	}

	public void setRq46(String rq46) {
		this.rq46 = rq46;
	}

	public String getRq7() {
		return rq7;
	}

	public void setRq7(String rq7) {
		this.rq7 = rq7;
	}

	public String getHh() {
		return hh;
	}

	public void setHh(String hh) {
		this.hh = hh;
	}

	public String getHd() {
		return hd;
	}

	public void setHd(String hd) {
		this.hd = hd;
	}

	public String getHc() {
		return hc;
	}

	public void setHc(String hc) {
		this.hc = hc;
	}

	public String getDh() {
		return dh;
	}

	public void setDh(String dh) {
		this.dh = dh;
	}

	public String getDd() {
		return dd;
	}

	public void setDd(String dd) {
		this.dd = dd;
	}

	public String getDc() {
		return dc;
	}

	public void setDc(String dc) {
		this.dc = dc;
	}

	public String getCh() {
		return ch;
	}

	public void setCh(String ch) {
		this.ch = ch;
	}

	public String getCd() {
		return cd;
	}

	public void setCd(String cd) {
		this.cd = cd;
	}

	public String getCc() {
		return cc;
	}

	public void setCc(String cc) {
		this.cc = cc;
	}

	public String getSg_num() {
		return sg_num;
	}

	public void setSg_num(String sg_num) {
		this.sg_num = sg_num;
	}

	public String getEnd_sign() {
		return end_sign;
	}

	public void setEnd_sign(String end_sign) {
		this.end_sign = end_sign;
	}

	public String getPeril() {
		return peril;
	}

	public void setPeril(String peril) {
		this.peril = peril;
	}

	public String getIsOutDated() {
		return isOutDated;
	}

	public void setIsOutDated(String isOutDated) {
		this.isOutDated = isOutDated;
	}

	public FootBallMatch() {
		super();
	}

	@Override
	public String toString() {
		return "FootBallMatch [id=" + id + ", league=" + league + ", match_time=" + match_time + ", start_time="
				+ start_time + ", team_h=" + team_h + ", team_c=" + team_c + ", gnum_h=" + gnum_h + ", gnum_c=" + gnum_c
				+ ", strong=" + strong + ", ctime=" + ctime + ", roll=" + roll + ", fid=" + fid + ", type=" + type
				+ ", types=" + types + ", dy_h=" + dy_h + ", dy_c=" + dy_c + ", dy_d=" + dy_d + ", fh_dy_h=" + fh_dy_h
				+ ", fh_dy_c=" + fh_dy_c + ", fh_dy_d=" + fh_dy_d + ", rq_h=" + rq_h + ", rq_c=" + rq_c + ", des_rq="
				+ des_rq + ", fh_rq_h=" + fh_rq_h + ", fh_rq_c=" + fh_rq_c + ", des_fh_rq=" + des_fh_rq + ", dx_h="
				+ dx_h + ", dx_c=" + dx_c + ", des_dx_h=" + des_dx_h + ", des_dx_c=" + des_dx_c + ", fh_dx_h=" + fh_dx_h
				+ ", fh_dx_c=" + fh_dx_c + ", des_fh_dx_h=" + des_fh_dx_h + ", des_fh_dx_c=" + des_fh_dx_c + ", ds_h="
				+ ds_h + ", ds_c=" + ds_c + ", score_h=" + score_h + ", score_c=" + score_c + ", fh_score_h="
				+ fh_score_h + ", fh_score_c=" + fh_score_c + ", redcard_h=" + redcard_h + ", redcard_c=" + redcard_c
				+ ", bf10_h=" + bf10_h + ", bf10_c=" + bf10_c + ", bf20_h=" + bf20_h + ", bf20_c=" + bf20_c
				+ ", bf21_h=" + bf21_h + ", bf21_c=" + bf21_c + ", bf30_h=" + bf30_h + ", bf30_c=" + bf30_c
				+ ", bf31_h=" + bf31_h + ", bf31_c=" + bf31_c + ", bf32_h=" + bf32_h + ", bf32_c=" + bf32_c
				+ ", bf40_h=" + bf40_h + ", bf40_c=" + bf40_c + ", bf41_h=" + bf41_h + ", bf41_c=" + bf41_c
				+ ", bf42_h=" + bf42_h + ", bf42_c=" + bf42_c + ", bf43_h=" + bf43_h + ", bf43_c=" + bf43_c + ", bf00="
				+ bf00 + ", bf11=" + bf11 + ", bf22=" + bf22 + ", bf33=" + bf33 + ", bf44=" + bf44 + ", other=" + other
				+ ", rq01=" + rq01 + ", rq23=" + rq23 + ", rq46=" + rq46 + ", rq7=" + rq7 + ", hh=" + hh + ", hd=" + hd
				+ ", hc=" + hc + ", dh=" + dh + ", dd=" + dd + ", dc=" + dc + ", ch=" + ch + ", cd=" + cd + ", cc=" + cc
				+ ", sg_num=" + sg_num + ", end_sign=" + end_sign + ", peril=" + peril + ", isOutDated=" + isOutDated + "]";
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((bf00 == null) ? 0 : bf00.hashCode());
		result = prime * result + ((bf10_c == null) ? 0 : bf10_c.hashCode());
		result = prime * result + ((bf10_h == null) ? 0 : bf10_h.hashCode());
		result = prime * result + ((bf11 == null) ? 0 : bf11.hashCode());
		result = prime * result + ((bf20_c == null) ? 0 : bf20_c.hashCode());
		result = prime * result + ((bf20_h == null) ? 0 : bf20_h.hashCode());
		result = prime * result + ((bf21_c == null) ? 0 : bf21_c.hashCode());
		result = prime * result + ((bf21_h == null) ? 0 : bf21_h.hashCode());
		result = prime * result + ((bf22 == null) ? 0 : bf22.hashCode());
		result = prime * result + ((bf30_c == null) ? 0 : bf30_c.hashCode());
		result = prime * result + ((bf30_h == null) ? 0 : bf30_h.hashCode());
		result = prime * result + ((bf31_c == null) ? 0 : bf31_c.hashCode());
		result = prime * result + ((bf31_h == null) ? 0 : bf31_h.hashCode());
		result = prime * result + ((bf32_c == null) ? 0 : bf32_c.hashCode());
		result = prime * result + ((bf32_h == null) ? 0 : bf32_h.hashCode());
		result = prime * result + ((bf33 == null) ? 0 : bf33.hashCode());
		result = prime * result + ((bf40_c == null) ? 0 : bf40_c.hashCode());
		result = prime * result + ((bf40_h == null) ? 0 : bf40_h.hashCode());
		result = prime * result + ((bf41_c == null) ? 0 : bf41_c.hashCode());
		result = prime * result + ((bf41_h == null) ? 0 : bf41_h.hashCode());
		result = prime * result + ((bf42_c == null) ? 0 : bf42_c.hashCode());
		result = prime * result + ((bf42_h == null) ? 0 : bf42_h.hashCode());
		result = prime * result + ((bf43_c == null) ? 0 : bf43_c.hashCode());
		result = prime * result + ((bf43_h == null) ? 0 : bf43_h.hashCode());
		result = prime * result + ((bf44 == null) ? 0 : bf44.hashCode());
		result = prime * result + ((cc == null) ? 0 : cc.hashCode());
		result = prime * result + ((cd == null) ? 0 : cd.hashCode());
		result = prime * result + ((ch == null) ? 0 : ch.hashCode());
		result = prime * result + ((dc == null) ? 0 : dc.hashCode());
		result = prime * result + ((dd == null) ? 0 : dd.hashCode());
		result = prime * result + ((des_dx_c == null) ? 0 : des_dx_c.hashCode());
		result = prime * result + ((des_dx_h == null) ? 0 : des_dx_h.hashCode());
		result = prime * result + ((des_fh_dx_c == null) ? 0 : des_fh_dx_c.hashCode());
		result = prime * result + ((des_fh_dx_h == null) ? 0 : des_fh_dx_h.hashCode());
		result = prime * result + ((des_fh_rq == null) ? 0 : des_fh_rq.hashCode());
		result = prime * result + ((des_rq == null) ? 0 : des_rq.hashCode());
		result = prime * result + ((dh == null) ? 0 : dh.hashCode());
		result = prime * result + ((ds_c == null) ? 0 : ds_c.hashCode());
		result = prime * result + ((ds_h == null) ? 0 : ds_h.hashCode());
		result = prime * result + ((dx_c == null) ? 0 : dx_c.hashCode());
		result = prime * result + ((dx_h == null) ? 0 : dx_h.hashCode());
		result = prime * result + ((dy_c == null) ? 0 : dy_c.hashCode());
		result = prime * result + ((dy_d == null) ? 0 : dy_d.hashCode());
		result = prime * result + ((dy_h == null) ? 0 : dy_h.hashCode());
		result = prime * result + ((end_sign == null) ? 0 : end_sign.hashCode());
		result = prime * result + ((fh_dx_c == null) ? 0 : fh_dx_c.hashCode());
		result = prime * result + ((fh_dx_h == null) ? 0 : fh_dx_h.hashCode());
		result = prime * result + ((fh_dy_c == null) ? 0 : fh_dy_c.hashCode());
		result = prime * result + ((fh_dy_d == null) ? 0 : fh_dy_d.hashCode());
		result = prime * result + ((fh_dy_h == null) ? 0 : fh_dy_h.hashCode());
		result = prime * result + ((fh_rq_c == null) ? 0 : fh_rq_c.hashCode());
		result = prime * result + ((fh_rq_h == null) ? 0 : fh_rq_h.hashCode());
		result = prime * result + ((fh_score_c == null) ? 0 : fh_score_c.hashCode());
		result = prime * result + ((fh_score_h == null) ? 0 : fh_score_h.hashCode());
		result = prime * result + ((gnum_c == null) ? 0 : gnum_c.hashCode());
		result = prime * result + ((gnum_h == null) ? 0 : gnum_h.hashCode());
		result = prime * result + ((hc == null) ? 0 : hc.hashCode());
		result = prime * result + ((hd == null) ? 0 : hd.hashCode());
		result = prime * result + ((hh == null) ? 0 : hh.hashCode());
		result = prime * result + ((isOutDated == null) ? 0 : isOutDated.hashCode());
		result = prime * result + ((league == null) ? 0 : league.hashCode());
		result = prime * result + ((match_time == null) ? 0 : match_time.hashCode());
		result = prime * result + ((other == null) ? 0 : other.hashCode());
		result = prime * result + ((redcard_c == null) ? 0 : redcard_c.hashCode());
		result = prime * result + ((redcard_h == null) ? 0 : redcard_h.hashCode());
		result = prime * result + ((rq01 == null) ? 0 : rq01.hashCode());
		result = prime * result + ((rq23 == null) ? 0 : rq23.hashCode());
		result = prime * result + ((rq46 == null) ? 0 : rq46.hashCode());
		result = prime * result + ((rq7 == null) ? 0 : rq7.hashCode());
		result = prime * result + ((rq_c == null) ? 0 : rq_c.hashCode());
		result = prime * result + ((rq_h == null) ? 0 : rq_h.hashCode());
		result = prime * result + ((score_c == null) ? 0 : score_c.hashCode());
		result = prime * result + ((score_h == null) ? 0 : score_h.hashCode());
		result = prime * result + ((sg_num == null) ? 0 : sg_num.hashCode());
		result = prime * result + ((start_time == null) ? 0 : start_time.hashCode());
		result = prime * result + ((strong == null) ? 0 : strong.hashCode());
		result = prime * result + ((team_c == null) ? 0 : team_c.hashCode());
		result = prime * result + ((team_h == null) ? 0 : team_h.hashCode());
		result = prime * result + ((type == null) ? 0 : type.hashCode());
		result = prime * result + ((types == null) ? 0 : types.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		FootBallMatch other = (FootBallMatch) obj;
		if (!type.equals(other.type))
			return false;
		if (!types.equals(other.types))
			return false;
		if (!league.equals(other.league))
			return false;
		if (!team_c.equals(other.team_c))
			return false;
		if (!team_h.equals(other.team_h))
			return false;
		if (!start_time.equals(other.start_time))
			return false;
		
		if (!ds_c.equals(other.ds_c))
			return false;
		if (!ds_h.equals(other.ds_h))
			return false;
		if (!dx_c.equals(other.dx_c))
			return false;
		if (!dx_h.equals(other.dx_h))
			return false;
		if (!dy_c.equals(other.dy_c))
			return false;
		if (!dy_d.equals(other.dy_d))
			return false;
		if (!dy_h.equals(other.dy_h))
			return false;
		if (!des_dx_c.equals(other.des_dx_c))
			return false;
		if (!des_dx_h.equals(other.des_dx_h))
			return false;
		if (!des_fh_dx_c.equals(other.des_fh_dx_c))
			return false;
		if (!des_fh_dx_h.equals(other.des_fh_dx_h))
			return false;
		if (!des_fh_rq.equals(other.des_fh_rq))
			return false;
		if (!des_rq.equals(other.des_rq))
			return false;
		if (!fh_dx_c.equals(other.fh_dx_c))
			return false;
		if (!fh_dx_h.equals(other.fh_dx_h))
			return false;
		if (!fh_dy_c.equals(other.fh_dy_c))
			return false;
		if (!fh_dy_d.equals(other.fh_dy_d))
			return false;
		if (!fh_dy_h.equals(other.fh_dy_h))
			return false;
		if (!fh_rq_c.equals(other.fh_rq_c))
			return false;
		if (!fh_rq_h.equals(other.fh_rq_h))
			return false;
		if (!fh_score_c.equals(other.fh_score_c))
			return false;
		if (!fh_score_h.equals(other.fh_score_h))
			return false;
		
		if (!cc.equals(other.cc))
			return false;
		if (!cd.equals(other.cd))
			return false;
		if (!ch.equals(other.ch))
			return false;
		if (!dc.equals(other.dc))
			return false;
		if (!dd.equals(other.dd))
			return false;
		if (!dh.equals(other.dh))
			return false;
		
		if (!end_sign.equals(other.end_sign))
			return false;
		
		if (!gnum_c.equals(other.gnum_c))
			return false;
		if (!gnum_h.equals(other.gnum_h))
			return false;
		if (!hc.equals(other.hc))
			return false;
		if (!hd.equals(other.hd))
			return false;
		if (!hh.equals(other.hh))
			return false;
		if (!strong.equals(other.strong))
			return false;
		if (!match_time.equals(other.match_time))
			return false;
		if (!this.other.equals(other.other))
			return false;
		if (!redcard_c.equals(other.redcard_c))
			return false;
		if (!redcard_h.equals(other.redcard_h))
			return false;
		if (!rq01.equals(other.rq01))
			return false;
		if (!rq23.equals(other.rq23))
			return false;
		if (!rq46.equals(other.rq46))
			return false;
		if (!rq7.equals(other.rq7))
			return false;
		if (!rq_c.equals(other.rq_c))
			return false;
		if (!rq_h.equals(other.rq_h))
			return false;
		if (!score_c.equals(other.score_c))
			return false;
		if (!score_h.equals(other.score_h))
			return false;
		if (!sg_num.equals(other.sg_num))
			return false;
		if (!bf00.equals(other.bf00))
			return false;
		if(!bf10_c.equals(other.bf10_c))
			return false;
		if (!bf10_h.equals(other.bf10_h))
			return false;
		if (!bf11.equals(other.bf11))
			return false;
		if (!bf20_c.equals(other.bf20_c))
			return false;
		if (!bf20_h.equals(other.bf20_h))
			return false;
		if (!bf21_c.equals(other.bf21_c))
			return false;
		if (!bf21_h.equals(other.bf21_h))
			return false;
		if (!bf22.equals(other.bf22))
			return false;
		if (!bf30_c.equals(other.bf30_c))
			return false;
		if (!bf30_h.equals(other.bf30_h))
			return false;
		if (!bf31_c.equals(other.bf31_c))
			return false;
		if (!bf31_h.equals(other.bf31_h))
			return false;
		if (!bf32_c.equals(other.bf32_c))
			return false;
		if (!bf32_h.equals(other.bf32_h))
			return false;
		if (!bf33.equals(other.bf33))
			return false;
		if (!bf40_c.equals(other.bf40_c))
			return false;
		if (!bf40_h.equals(other.bf40_h))
			return false;
		if (!bf41_c.equals(other.bf41_c))
			return false;
		if (!bf41_h.equals(other.bf41_h))
			return false;
		if (!bf42_c.equals(other.bf42_c))
			return false;
		if (!bf42_h.equals(other.bf42_h))
			return false;
		if (!bf43_c.equals(other.bf43_c))
			return false;
		if (!bf43_h.equals(other.bf43_h))
			return false;
		if (!bf44.equals(other.bf44))
			return false;
		return true;
	}

}