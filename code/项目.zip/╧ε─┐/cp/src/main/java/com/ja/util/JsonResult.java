package com.ja.util;
/**
 * 值对象
 * 封装控制层相关方法返回数据
 * @author Administrator
 *
 */
public class JsonResult {

	public static final int SUCCESS=1;
	public static final int ERROR=0;
	//状态：(SUCCESS,ERROR)
	private int state;
	//状态信息
	private String message;
	//具体数据
	private Object data;
	//具体数据
	private Object data1;
	//具体数据
	private Object data2;
	//具体数据
	private Object data3;
	//具体数据
	private Object data4;
		
	public Object getData4() {
		return data4;
	}
	public void setData4(Object data4) {
		this.data4 = data4;
	}
	public JsonResult(String message,Object data){
		state=SUCCESS;
		this.message = message;
		this.data = data;
	}
	public JsonResult(String message,Object data,Object data1){
		state=SUCCESS;
		this.message = message;
		this.data = data;
		this.data1 = data1;
	}
	public JsonResult(String message,Object data,Object data1,Object data2){
		state=SUCCESS;
		this.message = message;
		this.data = data;
		this.data1 = data1;
		this.data2 = data2;
	}
	public JsonResult(String message,Object data,Object data1,Object data2,Object data3){
		state=SUCCESS;
		this.message = message;
		this.data = data;
		this.data1 = data1;
		this.data2 = data2;
		this.data3 = data3;
	}
	public JsonResult(String message,Object data,Object data1,Object data2,Object data3,Object data4){
		state=SUCCESS;
		this.message = message;
		this.data = data;
		this.data1 = data1;
		this.data2 = data2;
		this.data3 = data3;
		this.data4 = data4;
	}
	public JsonResult(Throwable exp){
		state=ERROR;
		this.message = exp.getMessage();
	}
	public static int getSuccess(){
		return SUCCESS;
	}
	public Object getData1() {
		return data1;
	}
	public void setData1(Object data1) {
		this.data1 = data1;
	}
	public Object getData2() {
		return data2;
	}
	public void setData2(Object data2) {
		this.data2 = data2;
	}
	public Object getData3() {
		return data3;
	}
	public void setData3(Object data3) {
		this.data3 = data3;
	}
	public void setState(int state) {
		this.state = state;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public void setData(Object data) {
		this.data = data;
	}
	public static int getError(){
		return ERROR;
	}
	public int getState(){
		return state;
	}
	public String getMessage(){
		return message;
	}
	public Object getData(){
		return data;
	}
	@Override
	public String toString() {
		return "JsonResult [state=" + state + ", message=" + message + ", data=" + data + "]";
	}
	
}
