package com.ja.sevice;

import com.ja.domain.FalseMoney;
import com.ja.domain.Order;

public interface FalseMoneyService {

	/**添加假金额信息*/
	int addInfo(FalseMoney fm);

	/**查询金额*/
	double getMoneySum(Order o);

}