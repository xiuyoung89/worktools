package com.ja.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.util.DigestUtils;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.ja.config.WebsiteStateConfig;
import com.ja.domain.Admin;
import com.ja.domain.AdminUser;
import com.ja.domain.BankCard;
import com.ja.domain.KeyWords;
import com.ja.domain.PagingData;
import com.ja.domain.User;
import com.ja.sevice.BackManagerService;
import com.ja.sevice.IBankService;
import com.ja.sevice.IKeyWordsService;
import com.ja.sevice.ISystemConfigService;
import com.ja.sevice.IUserService;
import com.ja.sevice.LiushuiService;
import com.ja.sevice.OperationlogService;
import com.ja.sevice.RedPacketService;
import com.ja.util.DateUtil;
import com.ja.util.IpAddrUtil;
import com.ja.util.JsonResult;
import com.ja.util.SessionListenerUtil;
import com.ja.util.Tourist;
import com.ja.util.WebSocketJson;

/**
 * 项目名称：cp   
 * 类名称：BackManagementController.java   
 * 类描述：   
 * 创建人：   GL
 * 创建时间：2019年2月20日 下午3:20:33   
 * @version v1.0.0
 */
@Controller
@RequestMapping("/kajhsgweasdqtwehghasfdnsak6868")
public class Ht_ManageController {
	
	//private static Logger logger = (Logger) LogManager.getLogger(BackManagementController.class);

	@Autowired
	private BackManagerService managerService;

	@Autowired
	private IUserService userService;

	@Autowired
	private IBankService bankService;
	
	@Autowired
	private OperationlogService operationlogService;
	
	@Autowired
	private LiushuiService liushuiService;
	
	@Autowired
	private ISystemConfigService systemConfigService;
	
	@Autowired
	private RedPacketService redPacketService;

	@Autowired
	private IKeyWordsService keyWordsService;

	/**
	 * 
	 * ----TODO：后台登录管理
	 * 
	 */
	
	/**
	 * 方法名：indexPage 
	 * 描述：     后台管理主页页面                   
	 * 参数：    @param session
	 * 参数：    @return 
	 * @return: ModelAndView
	 */
	@RequestMapping("/index")
	public ModelAndView indexPage(HttpSession session) {
		ModelAndView m = new ModelAndView("htgl/inde");
		AdminUser adminUser = (AdminUser) session.getAttribute("admin1");
		m.addObject("user", managerService.findUserJurisdiction(adminUser.getName()));
		return m;
	}
	
	/**
	 * 方法名：login 
	 * 描述：    后台管理登录页面                   
	 * 参数：    @return 
	 * @return: String
	 */
	@RequestMapping("/login")
	public String loginPage() {
		return "htgl/login";
	}
	
	/**
	 * 方法名：backManagerLogin 
	 * 描述：    后台用户登录                   
	 * 参数：    @param name 用户名
	 * 参数：    @param pass 用户密码
	 * 参数：    @param session
	 * 参数：    @param request
	 * 参数：    @return 
	 * @return: JsonResult
	 */
	@RequestMapping("/backManagerLogin")
	@ResponseBody
	public JsonResult backManagerLogin(String name, String pass, HttpSession session, HttpServletRequest request) {
		if (name == null || "".equals(name)) {
			return new JsonResult(null, "账号不能为空!");
		}
		AdminUser adminUser = managerService.admin(name,DigestUtils.md5DigestAsHex(DigestUtils.md5DigestAsHex(pass.getBytes()).getBytes()));
		if(adminUser==null) {
			return new JsonResult("账号或密码不对！", "0");
		}
		if(adminUser.getState()==0) {
			return new JsonResult("账号已被禁用，请联系管理员！", "0");
		}
		session.setAttribute("admin1", adminUser);
		managerService.logonlog(adminUser.getName(), "登录成功", IpAddrUtil.getIpAddr(request),DateUtil.getCurrTime(), DateUtil.findFormatDate());
		return new JsonResult("登录成功！", "1");
	}
	
	/**
	 * 方法名：userLogout 
	 * 描述：    退出后台管理系统                  
	 * 参数：    @param session
	 * 参数：    @return 
	 * @return: String
	 */
	@RequestMapping("/userLogout")
	public String userLogout(HttpSession session) {
		session.removeAttribute("admin1");
		return "/htgl/login";
	}
	
	/**
	 * 方法名：onlineUser 
	 * 描述：    查询在线用户                  
	 * 参数：    @param request
	 * 参数：    @return 
	 * @return: JsonResult
	 */
	@RequestMapping("/onlineUser")
	@ResponseBody
	public JsonResult online(HttpServletRequest request){
		return new JsonResult("success",SessionListenerUtil.onlineNum(request));
	}
	   
	/**
	 * 方法名：logoutOther 
	 * 描述：     强制下线用户                 
	 * 参数：    @param name 用户名称
	 * 参数：    @param request
	 * 参数：    @return 
	 * @return: JsonResult
	 */

	@ResponseBody
	@RequestMapping("/logoutOther")
	public JsonResult logoutOther(String name, HttpServletRequest request) {
		new WebSocketJson(6,name,"已被平台强制下线,请从新登陆或联系客服！").send();
		SessionListenerUtil.singleLogin(request,name);
		Set<User> set = SessionListenerUtil.onlineNum(request);
		WebSocketJson w1 = new WebSocketJson(2,set.size());
		w1.sendAllHt();
		return new JsonResult("success", "已强制下线!!");
	}
	
	/**
	 * 方法名：tourist 
	 * 描述：     查询在线游客                 
	 * 参数：    @return 
	 * @return: JsonResult
	 */
	@ResponseBody
	@RequestMapping("/onlineTourist")
	public JsonResult tourist() {
		return new JsonResult("success",Tourist.tourist);
	}
	
	
 	/**
 	 * 
 	 * ----TODO：平台用户管理
 	 * 
 	 * 
 	 */

	@RequestMapping("/userPage")
	public String userPage() {
		return "htgl/qbhygl";
	}
	/**
	 * 根据下面的条件查询 会员账号
	 * @param paging   分页对象
	 * @param name 会员账号
	 * @param ip 登录ip
	 * @param bankCard  银行卡
	 * @param cname  会员银行卡姓名 真实姓名
	 * @return 查询到则返回list集合包括User对象    没查询到则返回一个空集合
	 */
	@ResponseBody
	@RequestMapping("/findAllUsers")
	public String findAllUsers(PagingData paging,String name,String ip,String bankCard,String cname) {
		System.out.println("[name]="+name+"---[ip]"+ip+"----[bankCard]"+bankCard+"----[cname]"+cname);
		paging.setReplace1(name);
		paging.setAllCount(userService.findAllUserCounts(name, ip, bankCard, cname));
		paging.setList(userService.findAllUsers(paging, ip, bankCard, cname));
		return PagingData.pagingData(paging);
	}
	
	/**
	 * 方法名：findByIdUserInfo 
	 * 描述：     根据id查询用户信息                 
	 * 参数：    @return 
	 * @return: JsonResult
	 */ 
	@RequestMapping("/findByIdUserInfo")
	public ModelAndView findByIdUserInfo(Integer id) {
		ModelAndView m = new ModelAndView("htgl/huiyuanxiangqing");
		m.addObject("user", userService.getUserByid(id));
		return m;
	}
	
	/**
	 * 方法名：findUserInfo 
	 * 描述：    根据用户名查询用户的详情                  
	 * 参数：    @param name 用户名称
	 * 参数：    @return 
	 * @return: JsonResult
	 */
	@ResponseBody
	@RequestMapping("/findUserInfo")
	public JsonResult findUserInfo(String name) {
		User user = userService.checkUser(name);
		String message = "无";
		if(user!=null) {
			User agent = userService.getUserByid(user.getFid());
			if(agent!=null) {
				message = agent.getName();
			}
		}
		return new JsonResult(message,user);
	}
	
	/**
	 * 方法名：createdUserAccountInfo 
	 * 描述：     创建用户和内部账户                  
	 * 参数：    @param user 用户信息
	 * 参数：    @return 
	 * @return: JsonResult
	 */
	@RequestMapping("/createdUserAccountInfo")
	@ResponseBody
	public JsonResult createdUserAccountInfo(HttpServletRequest request,HttpSession session,User user) {
		User userInfo = userService.checkUser(user.getName());
		if(userInfo!=null) {
			return new JsonResult("success", "该账户已经存在,请添加新的账户!");
		}
		System.out.println(user.getState());
		String type = "普通账户!";
		if(user.getState()==3) {
			type = "平台内部账户!";
		}
		String ip = IpAddrUtil.getIpAddr(request);
		user.setRegisterIp(ip);
		user.setLastIp(ip);
		int line = managerService.createdUserAccountInfo(user);
		String remarks = "创建了用户名为："+user.getName()+type;
		operationlogService.addOperationlog((AdminUser)session.getAttribute("admin1"),remarks,"平台用户管理");
		return new JsonResult("success", line);
	}
	
	/**
	 * 方法名：updateUserPassword 
	 * 描述：    修改用户的密码                   
	 * 参数：    @param id 用户id
	 * 参数：    @param pass 修改密码
	 * 参数：    @param request
	 * 参数：    @param session
	 * 参数：    @return 
	 * @return: JsonResult
	 */
	@RequestMapping("/updateUserPassword")
	@ResponseBody
	public JsonResult updateUserPassword(HttpServletRequest request,HttpSession session, User user) {
		String remarks = "修改了用户："+user.getName()+"的密码！";
		String pwd = DigestUtils.md5DigestAsHex(DigestUtils.md5DigestAsHex(user.getPass().getBytes()).getBytes());
		user.setPass(pwd);
		int line = userService.updateUserInfo(user);
		String data = "修改失败!";
		if(line==1){
			data = "修改成功!";
		}
		operationlogService.addOperationlog((AdminUser)session.getAttribute("admin1"),remarks,"平台用户管理");
		new WebSocketJson(5,user.getName(),"该账户已修改密码,请从新登陆！").send();
		SessionListenerUtil.singleLogin(request, user.getName());
		return new JsonResult("success", data); 
	}
	
	/**
	 * 方法名：updateUserAccountState 
	 * 描述：     禁用启用用户的账号                  
	 * 参数：    @param user 1启用 0禁用
	 * 参数：    @param request
	 * 参数：    @return 
	 * @return: JsonResult
	 */
	@RequestMapping("/updateUserAccountState") 
	@ResponseBody 
	public JsonResult updateUserAccountState(HttpServletRequest request,HttpSession session,User user) { 
		String data = "操作失败!";
		int line = userService.updateUserInfo(user);
		if(line==1){
			data = "操作成功!";
		}
		String remarks ="启用了用户："+user.getName()+"的登录账户!";
		if(user.getState()==0) {
			remarks = "禁用了用户："+user.getName()+"的登录账户!";
			new WebSocketJson(4,user.getName(),"该账户已经禁用请联系平台客服!").send();
			SessionListenerUtil.singleLogin(request, user.getName());
		}
		operationlogService.addOperationlog((AdminUser)session.getAttribute("admin1"),remarks,"平台用户管理");
		return new JsonResult("success", data); 
	}
	

	/**
	 * 方法名：findByUserIdBankInfo 
	 * 描述：     根据用户id查询用户的银行卡信息                   
	 * 参数：    @param id 用户id
	 * 参数：    @param session
	 * 参数：    @return 
	 * @return: JsonResult
	 */
	@ResponseBody
	@RequestMapping("/findByUserIdBankInfo")
	public JsonResult findByUserIdBankInfo(HttpSession session, Integer id) {
		BankCard bank = bankService.getBankByUid(id);
		if(bank==null){
			return new JsonResult("success", 0);
		}
		return new JsonResult("success", bank);
	}

	/**
	 * 方法名：updateUserBankInfo 
	 * 描述：   修改用户的银行卡信息                     
	 * 参数：    @param bank 银行卡信息
	 * 参数：    @param session
	 * 参数：    @return 
	 * @return: JsonResult
	 */
	@ResponseBody
	@RequestMapping("/updateUserBankInfo")
	public JsonResult updateUserBankInfo(HttpSession session, BankCard bank) {
		User user = userService.getUserByid(bank.getUserid());
		int line = bankService.save(bank);
		String remarks = "修改了" + user.getName() + "的银行卡信息！";
		operationlogService.addOperationlog((AdminUser)session.getAttribute("admin1"),remarks,"平台用户管理");
		return new JsonResult("success", line);
	}

	/**
	 * 
	 * ----TODO：用户聊天管理
	 * 
	 */
	
	/**
	 * 方法名：userChatRecord 
	 * 描述：    用户聊天管理页面                   
	 * 参数：    @return 
	 * @return: String
	 */
	@RequestMapping("/userChatRecord")
	public String userChatRecord() {
		return "htgl/yonghuliaotianjiluguanli";
	}
	
	/**
	 * 方法名：findUserChatRecord 
	 * 描述：       查询用户聊天室聊天记录                 
	 * 参数：    @return 
	 * @return: JsonResult
	 */
	@RequestMapping("/findUserChatRecord")
	@ResponseBody
	public JsonResult findUserChatRecord() {
		return new JsonResult("success", redPacketService.findUserChatRecord());
	}

	/**
	 * 方法名：deleteUserChatRecord 
	 * 描述：    按时间删除用户聊天记录                    
	 * 参数：    @param time 删除时间
	 * 参数：    @return 
	 * @return: JsonResult
	 */
	@RequestMapping("/deleteUserChatRecord")
	@ResponseBody
	public JsonResult deleteUserChatRecord(HttpSession session,String time) {
		String remarks = "按时间：" + time + "删除了用户的聊天记录！";
		operationlogService.addOperationlog((AdminUser)session.getAttribute("admin1"),remarks,"用户聊天管理");
		return new JsonResult("success", redPacketService.deleteUserChatRecord(time));
	}

	/**
	 * 方法名：deleteByIdUserChatRecord 
	 * 描述：     按照id删除聊天记录                  
	 * 参数：    @param id 删除id
	 * 参数：    @return 
	 * @return: JsonResult
	 */
	@RequestMapping("/deleteByIdUserChatRecord")
	@ResponseBody
	public JsonResult deleteByIdUserChatRecord(HttpSession session,Integer id) {
		String remarks = "按id：" + id + "删除了用户的聊天记录！";
		operationlogService.addOperationlog((AdminUser)session.getAttribute("admin1"),remarks,"用户聊天管理");
		return new JsonResult("success", redPacketService.deleteByIdUserChatRecord(id));
	}
	
	/**
	 * 方法名：findUserChatMinRechargeMoney 
	 * 描述：     查询用户聊天最低充值金额                  
	 * 参数：    @return 
	 * @return: JsonResult
	 */
	@RequestMapping("/findUserChatMinRechargeMoney")
	@ResponseBody
	public JsonResult findUserChatMinRechargeMoney(){
		Admin systemConfig = systemConfigService.findAllConfig();
		return new JsonResult("success",systemConfig.getMoney());
	}
	
	/**
	 * 方法名：updateUserChatMinRechargeMoney 
	 * 描述：     修改用户聊天最低充值金额                  
	 * 参数：    @param money 最低充值金额
	 * 参数：    @return 
	 * @return: JsonResult
	 */
	@RequestMapping("/updateUserChatMinRechargeMoney")
	@ResponseBody
	public JsonResult updateUserChatMinRechargeMoney(HttpSession session,Admin admin){
		if(null == admin.getMoney() || "".equals(admin.getMoney())){
			return new JsonResult("success",0);
		}
		String remarks = "修改了聊天室用户聊天最低充值金额为：" + admin.getMoney() + "元！";
		operationlogService.addOperationlog((AdminUser)session.getAttribute("admin1"),remarks,"用户聊天管理");
		return new JsonResult("success",systemConfigService.updateAllConfig(admin));
	}
	
	/**
	 * 
	 * ----TODO：聊天屏蔽管理
	 * 
	 */
	
	/**
	 * 方法名：userChatPage 
	 * 描述：     用户聊天屏蔽页面                   
	 * 参数：    @return 
	 * @return: String
	 */
	@RequestMapping("userChatPage")
	public String userChatPage() {
		return "/htgl/liaotijilupingbi";
	}
	
	/**
	 * 方法名：findChatShieldingWords 
	 * 描述：     查询用户聊天屏蔽关键词                   
	 * 参数：    @param keyWords
	 * 参数：    @return 
	 * @return: JsonResult
	 */
	@ResponseBody
	@RequestMapping("/findChatShieldingWords")
	public JsonResult findChatShieldingWords(KeyWords keyWords) {
		return new JsonResult("success", keyWordsService.findAll());
	}
	
	/**
	 * 方法名：addChatShieldingWords 
	 * 描述：     添加用户聊天屏蔽关键词                   
	 * 参数：    @param keyWords 添加的屏蔽词
	 * 参数：    @return 
	 * @return: JsonResult
	 */
	@ResponseBody
	@RequestMapping("/addChatShieldingWords")
	public JsonResult addChatShieldingWords(HttpSession session,KeyWords keyWords) {
		String remarks = "新增了一条聊天室用户聊天屏蔽词为：" + keyWords.getStr() + "！";
		operationlogService.addOperationlog((AdminUser)session.getAttribute("admin1"),remarks,"聊天屏蔽管理");
		return new JsonResult("success", keyWordsService.insert(keyWords));
	}

	/**
	 * 方法名：deleteChatShieldingWords 
	 * 描述：    删除用聊天屏蔽关键词                    
	 * 参数：    @param keyWords 删除的id
	 * 参数：    @return 
	 * @return: JsonResult
	 */
	@ResponseBody
	@RequestMapping("/deleteChatShieldingWords")
	public JsonResult deleteChatShieldingWords(HttpSession session,KeyWords keyWords) {
		String remarks = "删除了一条ID为："+keyWords.getId()+"的聊天室用户聊天屏蔽词！";
		operationlogService.addOperationlog((AdminUser)session.getAttribute("admin1"),remarks,"聊天屏蔽管理");
		return new JsonResult("success", keyWordsService.delById(keyWords));
	}
	
	
	/**
	 * 
	 * ----TODO：系统红包管理
	 * 
	 */
	
	/**
	 * 方法名：systemRedPackage 
	 * 描述：    系统红包管理页面                  
	 * 参数：    @return 
	 * @return: String
	 */
	@RequestMapping("/systemRedPackage")
	public String systemRedPackage() {
		return "/htgl/xitongpaifahongbao";
	}
	
	/**
	 * 方法名：findSystemRedPackage 
	 * 描述：   查询派发的系统红包记录                   
	 * 参数：    @return 
	 * @return: JsonResult
	 */
	@ResponseBody
	@RequestMapping("/findSystemRedPackage")
	public JsonResult findSystemRedPackage() {
		return new JsonResult("success", redPacketService.getAllRedPackage());
	}
	
	/**
	 * 方法名：findSystemRedPackgeSetup 
	 * 描述：     查询系统红包设置                 
	 * 参数：    @return 
	 * @return: JsonResult
	 */
	@RequestMapping("/findSystemRedPackgeSetup")
	@ResponseBody
	public JsonResult findSystemRedPackgeSetup(){
		Admin setup = new Admin();
		setup.setTime(WebsiteStateConfig.configs.get("time"));
		setup.setRedenvelopes(WebsiteStateConfig.configs.get("redenvelopes"));
		setup.setLeavingamessage(WebsiteStateConfig.configs.get("leavingamessage"));
		setup.setTypeofredenvelopes(WebsiteStateConfig.configs.get("typeofredenvelopes"));
		setup.setNumberofredpackets(Integer.parseInt(WebsiteStateConfig.configs.get("numberofredpackets")));
		return new JsonResult("success",setup);
	}
	
	/**
	 * 方法名：findChatRedPackageSwitch 
	 * 描述：    查询聊天室系统自动派发红包开启状态                  
	 * 参数：    @return 
	 * @return: JsonResult
	 */
	@RequestMapping("/findChatRedPackageSwitch")
	@ResponseBody
	public JsonResult findChatRedPackageSwitch(){
		return new JsonResult("success",ChatController4.num);
	}
	
	/**
	 * 方法名：updateChatRedPackageState 
	 * 描述：    配置聊天室系统自动派发红包开启状态                  
	 * 参数：    @param num 0 开启  1关闭
	 * 参数：    @return 
	 * @return: JsonResult
	 */
	@RequestMapping("/updateChatRedPackageState")
	@ResponseBody
	public JsonResult updateChatRedPackageState(HttpSession session,int num){
		ChatController4.num = num;
		String type = "开启了";
		if(num == 1) {
			type = "关闭了";
		}
		String remarks = type +"聊天室系统自动派发红包功能！";
		operationlogService.addOperationlog((AdminUser)session.getAttribute("admin1"),remarks,"系统红包管理");
		return new JsonResult("success",num);
	}
	
	/**
	 * 方法名：updateSystemRedPackageSetup 
	 * 描述：     修改系统自动派发红包的配置                 
	 * 参数：    @param admin 配置信息
	 * 参数：    @return 
	 * @return: JsonResult
	 */
	@RequestMapping("/updateSystemRedPackageSetup")
	@ResponseBody
	public JsonResult updateSystemRedPackageSetup(HttpSession session,Admin admin){
		long date = Long.parseLong(admin.getTime().trim())/1000;
		ChatController4.midTime14 = date;
		String remarks ="修改了系统自动派发红包,红包名为："+admin.getLeavingamessage()+"红包类型为：" +admin.getTypeofredenvelopes()+"红包金额为："+admin.getRedenvelopes()+
				"红包个数为："+admin.getNumberofredpackets()+"红包间隔时间为："+date+"秒！";
		operationlogService.addOperationlog((AdminUser)session.getAttribute("admin1"),remarks,"系统红包管理");
		return new JsonResult("success",systemConfigService.updateAllConfig(admin));
	}
	
	/**
	 * 方法名：findUserRedPackageDetails 
	 * 描述：     查询系统红包用户领取详情                 
	 * 参数：    @param user_id 用户id
	 * 参数：    @return 
	 * @return: JsonResult
	 */
	@RequestMapping("/findUserRedPackageDetails")
	@ResponseBody
	public JsonResult findUserRedPackageDetails(String str) {
		List<Integer> ids = new ArrayList<Integer>();
		String[] id = str.split(",");
		for (int i = 0; i < id.length; i++) {
			ids.add(new Integer(id[i]));
		}
		return new JsonResult("success", liushuiService.img(ids));
	}
	
	/**
	 * 
	 * ----TODO：后台用户管理 
	 * 
	 */
	
	/**
	 * 方法名：findAdminUser 
	 * 描述：    查询管理员用户                  
	 * 参数：    @return 
	 * @return: ModelAndView
	 */
	@RequestMapping("/findAdminUser")
	public ModelAndView findAdminUser() {
		ModelAndView m = new ModelAndView("htgl/houtaiyonghuguanli");
		List<AdminUser> user = managerService.findAllAdminInfo();
		m.addObject("user", user);
		return m;
	}
	
	/**
	 * 方法名：registerAdminUser 
	 * 描述：   添加管理员用户                   
	 * 参数：    @param admin 管理员信息
	 * 参数：    @return 
	 * @return: JsonResult
	 */
	@RequestMapping("/addAdminUser")
	@ResponseBody
	public JsonResult registerAdminUser(HttpSession session,AdminUser admin) {
		AdminUser user = managerService.findByAdminUserInfo(admin.getName());
		if (user!=null) {
			return new JsonResult(null, "账号已存在！");
		}
		String pass = DigestUtils.md5DigestAsHex(DigestUtils.md5DigestAsHex(admin.getPass().getBytes()).getBytes());
		admin.setPass(pass);
		admin.setCreated_time(DateUtil.getCurrTime());
		int id = managerService.registerAdminUser(admin);
		AdminUser users = new AdminUser();
		users.setAdminid(id);
		users.setName(admin.getName());
		managerService.addUserJurisdiction(users);
		String remarks = "添加了用户名为："+admin.getName()+",登录IP为："+admin.getIp()+"的后台管理员账号！";
		operationlogService.addOperationlog((AdminUser)session.getAttribute("admin1"),remarks,"后台用户管理");
		return new JsonResult("success", "添加成功！");
	}

	/**
	 * 方法名：updateAdminUser 
	 * 描述：    修改管理员信息                  
	 * 参数：    @param admin
	 * 参数：    @return 
	 * @return: JsonResult
	 */
	@RequestMapping("/updateAdminUser")
	@ResponseBody
	public JsonResult updateAdminUser(HttpSession session,AdminUser admin) {
		if(!"".equals(admin.getPass())) {
			String pass = DigestUtils.md5DigestAsHex(DigestUtils.md5DigestAsHex(admin.getPass().getBytes()).getBytes());
			admin.setPass(pass);
		}
		admin.setCreated_time(DateUtil.getCurrTime());
		String message = managerService.updateAdminUser(admin);
		String remarks = "修改了用户昵称为："+admin.getNick_name()+",登录IP为："+admin.getIp()+"的后台管理员账号！";
		operationlogService.addOperationlog((AdminUser)session.getAttribute("admin1"),remarks,"后台用户管理");
		return new JsonResult("success", message);
	}
	
	/**
	 * 方法名：updateAdminUserState 
	 * 描述：    禁用 启用管理员用户                  
	 * 参数：    @param state 1是启用  0是禁用
	 * 参数：    @param name 用户名
	 * 参数：    @return 
	 * @return: JsonResult
	 */
	@RequestMapping("/updateAdminUserState")
	@ResponseBody
	public JsonResult updateAdminUserState(HttpSession session,int state, String name) {
		if (name == null || "".equals(name)) {
			return new JsonResult("success", "用户名不能为空！");
		}
		String type = "禁用了";
		if(state==1){
			type = "启用了";
		}
		String remarks = type+"用户名为："+name+"的后台管理员账号！";
		operationlogService.addOperationlog((AdminUser)session.getAttribute("admin1"),remarks,"后台用户管理");
		return new JsonResult("success", managerService.jyqy(state, name));
	}

	/**
	 * 方法名：deleteAdminUser 
	 * 描述：    删除管理员用户                  
	 * 参数：    @param id 删除id
	 * 参数：    @return 
	 * @return: JsonResult
	 */
	@RequestMapping("/deleteAdminUser")
	@ResponseBody
	public JsonResult deleteAdminUser(HttpSession session,Integer id) {
		AdminUser admin = managerService.findByIdAmdinUser(id);
		if(admin.getAdmin_type()==4) {
			return new JsonResult("", "不能删除超级管理员用户!");
		}
		managerService.deleteKeFuUser(id);
		String remarks = "删除了用户id为："+id+"的后台管理员账号！";
		operationlogService.addOperationlog((AdminUser)session.getAttribute("admin1"),remarks,"后台用户管理");
		return new JsonResult("success", "删除成功！");
	}

	
	/**
	 * 
	 * ----TODO：用户权限管理 
	 * 
	 */
	

	/**
	 * 方法名：userJurisdictionPage 
	 * 描述：    用户权限管理页面                  
	 * 参数：    @return 
	 * @return: ModelAndView
	 */
	@RequestMapping("/userJurisdictionPage")
	@ResponseBody
	public ModelAndView userJurisdictionPage() {
		ModelAndView m = new ModelAndView("htgl/houtaiquanxianshezhi");
		m.addObject("user", managerService.Allusers());
		return m;
	}
	
	/**
	 * 方法名：findUserJurisdiction 
	 * 描述：     根据用户名查询后台用户的权限                 
	 * 参数：    @param name 用户名
	 * 参数：    @return 
	 * @return: JsonResult
	 */
	@RequestMapping("/findUserJurisdiction")
	@ResponseBody
	public JsonResult findUserJurisdiction(String name) {
		return new JsonResult("success", managerService.findUserJurisdiction(name));
	}
	
	/**
	 * 方法名：updateUserJurisdiction 
	 * 描述：   修改后台用户的权限                   
	 * 参数：    @param user 权限设置
	 * 参数：    @return 
	 * @return: ModelAndView
	 */
	@RequestMapping("/updateUserJurisdiction")
	public ModelAndView updateUserJurisdiction(HttpSession session,AdminUser user) {
		ModelAndView m = new ModelAndView("htgl/houtaiquanxianshezhi");
		managerService.updateUserJurisdiction(user);
		String remarks = "添加了用户名为："+user.getName()+"的后台管理权限！";
		operationlogService.addOperationlog((AdminUser)session.getAttribute("admin1"),remarks,"用户权限管理");
		m.addObject("user", managerService.Allusers());
		return m;
	}

	
	/**
	 * 
	 * ----TODO：登录日志管理 
	 * 
	 */

	/**
	 * 方法名：findUserLoginLog 
	 * 描述：    查询后台用户的登录日志                  
	 * 参数：    @param model
	 * 参数：    @param time 查询时间
	 * 参数：    @return 
	 * @return: ModelAndView
	 */
	@RequestMapping("/findUserLoginLog")
	public ModelAndView findUserLoginLog(ModelAndView model,String time) {
		if(time == null || "".equals(time)) {
			time = DateUtil.findFormatDate();
		}
		model.setViewName("htgl/hyssgn");
		model.addObject("log", managerService.findUserLoginLog(time));
		return model;
	}
	
	
	/**
	 * 
	 * ----TODO：操作日志管理 
	 * 
	 */

	/**
	 * 方法名：findAdminUserOperationLog 
	 * 描述：    查询后台管理员操作日志                  
	 * 参数：    @param time 查询时间
	 * 参数：    @return 
	 * @return: ModelAndView
	 */
	@RequestMapping("/findAdminUserOperationLog")
	public ModelAndView findAdminUserOperationLog(String time) {
		if(time == null || "".equals(time)) {
			time = DateUtil.findFormatDate();
		}
		ModelAndView m = new ModelAndView("htgl/htczrz");
		m.addObject("log", managerService.operationlog(time));
		return m;
	}
	/**
	 * 转移下级
	 * @param name 转到某个代理名下的代理用户名  代理的用户名
	 * @param cname  被转到别的代理名下的 用户名 下级的用户名
	 * @param odds  转过来 的赔率是多少 转移以后的赔率
	 * @return  转移成功则返回1  转移失败则返回0 返回-1用户的赔率不能为空  返回-2赔率不能大于代理可调动的赔率  返回-3设置的赔率格式不对 返回-4代表 这个用户不存在
	 */
	@RequestMapping("/transferSubordinate")
	@ResponseBody
	public JsonResult transferSubordinate(String name,String cname,String odds) {
		System.err.println(odds+"----设置的赔率");
		return new JsonResult(null,userService.transferSubordinate(name, cname, odds));
	}
	
}
