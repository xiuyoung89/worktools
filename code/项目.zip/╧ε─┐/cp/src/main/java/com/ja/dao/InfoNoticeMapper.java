package com.ja.dao;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.ja.domain.InfoNotice;
import com.ja.domain.UpDataPage;
import com.ja.domain.UserNotice;

public interface InfoNoticeMapper {
	/**查询所有的公告信息*/
	List<InfoNotice> getAllInfoNotice();

	/**添加公告信息*/
	int addInfoNotice(InfoNotice info);

	/**修改公告信息*/
	int updInfoNotice(InfoNotice info);
    
	/**删除公告信息*/
	int delInfoNotice(Integer id);
	
	/**根据id查询*/
	InfoNotice getOneByIdNotice(Integer id);
	
	/**查询最新的一条公告*/
	InfoNotice getOneByNoticeDesc(String type);

	/**禁用公告*/
	int updInfoNoticeState(@Param("state")Integer state,@Param("id")Integer id);
	
	
	/**
	 * 
	   *   方法名：findAllUserNotices   
	   *   描述：    查询所有平台内部用户公告                   TODO   
	   *   参数：    @return 
	 * @return: List<UserNotice>
	 */
	List<UserNotice> findAllUserNotices();

	/**
	 * 根据id查询内部公告
	   *   方法名：findByIdAllUserNotices   
	   *   描述：                       TODO   
	   *   参数：    @param id
	   *   参数：    @return 
	 * @return: UserNotice
	 */
	UserNotice findByIdAllUserNotices(Integer id);
	
	/**
	 * 添加内部公告
	   *   方法名：saveUserNotice   
	   *   描述：                       TODO   
	   *   参数：    @param notice
	   *   参数：    @return 
	 * @return: Integer
	 */
	Integer saveUserNotice(UserNotice notice);
	
	/**
	 * 修改内部公告
	   *   方法名：updateUserNotice   
	   *   描述：                       TODO   
	   *   参数：    @param notice
	   *   参数：    @return 
	 * @return: Integer
	 */
	Integer updateUserNotice(UserNotice notice);
	
	/**
	 * 		删除用户内部信息公告
	   *   方法名：deleteUserNotice   
	   *   描述：                       TODO   
	   *   参数：    @param id
	   *   参数：    @return 
	 * @return: String
	 */
	Integer deleteUserNotice(Integer id);
	
	/**
	 * 方法名：更新页面
	 * @return
	 */
	List<UpDataPage> updatePage();
	
	/**
	 * 方法名：更新页面
	 * @param 页面名字
	 * @return 返回当前页面的相关数据
	 */
	UpDataPage  updatePages(@Param("name")String name);
	/**
	 * 方法名：更新页面 查询
	 * @param status 根据状态查询
	 * @return
	 */
	List<UpDataPage>   updatePagesc(@Param("status")int status);
	
	/**
	 * 客服提示语
	 * @return
	 */
	int Tips(String tips);
	
	/**
	 * 查询网址开启还是关闭状态
	 * @return
	 */
	Integer Maintain();
	
	/**
	 * 查询网站维护公告
	 */
	String whNotice();
}
