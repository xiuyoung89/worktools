package com.ja.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.ja.config.WebsiteStateConfig;
import com.ja.domain.IndexPicture;
import com.ja.domain.InfoNotice;
import com.ja.domain.Notice;
import com.ja.sevice.AllExplainService;
import com.ja.sevice.InfoNoticeService;
import com.ja.util.JsonResult;

/**
 * 
 * 项目名称：cp   
 * 类名称：PC_ExplainController   
 * 类描述：   平台的说明类
 * 创建人：GL   
 * 创建时间：2018年10月10日 上午11:27:43   
 * @version
 */
@Controller
@RequestMapping("/explains")
public class PC_ExplainController {  

	@Autowired
	private AllExplainService allExplainService;  
	
	
	@Autowired
	private InfoNoticeService infoNotiService;
	
	/**
	 * 
	   *   方法名：findByIdExplain   
	   *   描述：     根据id查询说明                TODO   
	   *   参数：    @param id
	   *   参数：    @return 
	 * @return: JsonResult
	 */
	@RequestMapping("/findByIdExplain")
	@ResponseBody
	public JsonResult findByIdExplain(Integer id) {
		return new JsonResult("1", allExplainService.findByIdExplain(id));
	}

	/**
	 * 
	   *   方法名：findAllExplain   
	   *   描述：     查询所有帮助的说明                  TODO   
	   *   参数：    type 1 是所有的菜单 2是所有的帮助说明 3是日常说明
	   *   参数：    @return 
	 * @return: JsonResult
	 */
	@RequestMapping("/findAllExplain")
	@ResponseBody
	public JsonResult findAllExplain() {
		return new JsonResult("1", allExplainService.findAllExplain(0));
	}
	
	/**
	 * 
	   *   方法名：findTypeExplain 
	   *   描述：     查询所有的说明                  TODO   
	   *   参数：    type 1 是所有的菜单 2是所有的帮助说明 3是日常说明
	   *   参数：    @return 
	 * @return: JsonResult
	 */
	@RequestMapping("/findTypeExplain")
	@ResponseBody
	public JsonResult findTypeExplain(Integer type) {
		return new JsonResult("1", allExplainService.findAllExplain(type));
	}
	
	/**
	 * PC端公共页数据
	 * @param type
	 * @return  返回PC端公共页数据
	 */
	@RequestMapping("/commonData")
	@ResponseBody
	public JsonResult commonData(Integer type) {
				//首页公告
				Notice n = new Notice();
				IndexPicture ipe = infoNotiService.getOneByPictureDesc();
				InfoNotice ifne =  infoNotiService.getOneByNoticeDesc("首页公告");
				n.setWangzhantitle(WebsiteStateConfig.configs.get("wangzhantitle"));
				n.setNotice(WebsiteStateConfig.configs.get("notice"));
				n.setPicturePath1(ipe.getPicturePath1());
				n.setPicturePath2(ipe.getPicturePath2());
				n.setPicturePath3(ipe.getPicturePath3());
				n.setPicturePath4(ipe.getPicturePath4());
				n.setPicturePath5(ipe.getPicturePath5());
				n.setNoticePicture(ifne.getNoticePicture());
				n.setNoticeName(ifne.getNoticeName());
				n.setKefusbtime(WebsiteStateConfig.configs.get("kefusbtime"));
				n.setKefuxbtime(WebsiteStateConfig.configs.get("kefuxbtime"));
				n.setPc_welcome(WebsiteStateConfig.configs.get("pc_welcome"));//Pc网站标题
				n.setWangzhantitle(WebsiteStateConfig.configs.get("wangzhantitle"));//网站标题
				n.setPc_wechat(WebsiteStateConfig.configs.get("pc_wechat"));//PC微信图标
				n.setLogo(WebsiteStateConfig.configs.get("logo"));//PClogo
		return new JsonResult("1", allExplainService.findAllExplain(type),n,WebsiteStateConfig.getLotter("bjl"));
	}
}
