package com.ja.sevice.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ja.dao.QqKeFuMapper;
import com.ja.domain.QqKeFu;
import com.ja.sevice.QqKeFuService;
import com.ja.util.DateUtil;

/**@DESC 
 * @AUTH LBQ
 * @DATE 2018年1月18日 下午11:05:40
 */
@Service
public class QqKeFuServiceImpl implements QqKeFuService {
	
	@Autowired
	private QqKeFuMapper qqKeFuMapper;

	@Override
	public List<QqKeFu> getAllQqKeFu() {
		return qqKeFuMapper.getAllQqKeFu();
	}

	@Override
	public int addQqKeFuInfo(QqKeFu qq) {
		qq.setCreateTime(DateUtil.getCurrTime());
		qq.setState(1);
		return qqKeFuMapper.addQqKeFuInfo(qq);
	}

	@Override
	public int updateQqKeFuInfo(QqKeFu qq) {
		qq.setCreateTime(DateUtil.getCurrTime());
		return qqKeFuMapper.updateQqKeFuInfo(qq);
	}

	@Override
	public int delQqKeFuInfo(Integer id) {
		return qqKeFuMapper.delQqKeFuInfo(id);
	}


}
