package com.ja.domain;

import java.io.Serializable;
import java.util.Date;

import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.ja.util.JsonDateValue;

public class ParkedDomains implements Serializable {
	private static final long serialVersionUID = 3288436189826670432L;
	
	private Integer id;
	private String domain;
	private String defaultAgency;
	private Integer domainStatus;
	private String defaultIndex;
	private Date createdTime;
	private String operation;
	private String createdUser;
	
	public ParkedDomains() {
		super();
	}
	
	public ParkedDomains(Integer id, String domain, String defaultAgency, Integer domainStatus, String defaultIndex,
			Date createdTime, String operation, String createdUser) {
		super();
		this.id = id;
		this.domain = domain;
		this.defaultAgency = defaultAgency;
		this.domainStatus = domainStatus;
		this.defaultIndex = defaultIndex;
		this.createdTime = createdTime;
		this.operation = operation;
		this.createdUser = createdUser;
	}

    
    public static long getSerialversionuid() {
		return serialVersionUID;
	}
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getDomain() {
		return domain;
	}
	public void setDomain(String domain) {
		this.domain = domain;
	}
	public String getDefaultAgency() {
		return defaultAgency;
	}
	public void setDefaultAgency(String defaultAgency) {
		this.defaultAgency = defaultAgency;
	}
	public Integer getDomainStatus() {
		return domainStatus;
	}
	public void setDomainStatus(Integer domainStatus) {
		this.domainStatus = domainStatus;
	}
	public String getDefaultIndex() {
		return defaultIndex;
	}
	public void setDefaultIndex(String defaultIndex) {
		this.defaultIndex = defaultIndex;
	}
	@JsonSerialize(using=JsonDateValue.class)
	public Date getCreatedTime() {
		return createdTime;
	}
	public void setCreatedTime(Date createdTime) {
		this.createdTime = createdTime;
	}
	public String getOperation() {
		return operation;
	}
	public void setOperation(String operation) {
		this.operation = operation;
	}
	public String getCreatedUser() {
		return createdUser;
	}
	public void setCreated_user(String createdUser) {
		this.createdUser = createdUser;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((createdTime == null) ? 0 : createdTime.hashCode());
		result = prime * result + ((createdUser == null) ? 0 : createdUser.hashCode());
		result = prime * result + ((defaultAgency == null) ? 0 : defaultAgency.hashCode());
		result = prime * result + ((defaultIndex == null) ? 0 : defaultIndex.hashCode());
		result = prime * result + ((domain == null) ? 0 : domain.hashCode());
		result = prime * result + ((domainStatus == null) ? 0 : domainStatus.hashCode());
		result = prime * result + ((id == null) ? 0 : id.hashCode());
		result = prime * result + ((operation == null) ? 0 : operation.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		ParkedDomains other = (ParkedDomains) obj;
		if (createdTime == null) {
			if (other.createdTime != null)
				return false;
		} else if (!createdTime.equals(other.createdTime))
			return false;
		if (createdUser == null) {
			if (other.createdUser != null)
				return false;
		} else if (!createdUser.equals(other.createdUser))
			return false;
		if (defaultAgency == null) {
			if (other.defaultAgency != null)
				return false;
		} else if (!defaultAgency.equals(other.defaultAgency))
			return false;
		if (defaultIndex == null) {
			if (other.defaultIndex != null)
				return false;
		} else if (!defaultIndex.equals(other.defaultIndex))
			return false;
		if (domain == null) {
			if (other.domain != null)
				return false;
		} else if (!domain.equals(other.domain))
			return false;
		if (domainStatus == null) {
			if (other.domainStatus != null)
				return false;
		} else if (!domainStatus.equals(other.domainStatus))
			return false;
		if (id == null) {
			if (other.id != null)
				return false;
		} else if (!id.equals(other.id))
			return false;
		if (operation == null) {
			if (other.operation != null)
				return false;
		} else if (!operation.equals(other.operation))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "ParkedDomains [id=" + id + ", domain=" + domain + ", defaultAgency=" + defaultAgency + ", domainStatus="
				+ domainStatus + ", defaultIndex=" + defaultIndex + ", createdTime=" + createdTime + ", operation="
				+ operation + ", created_user=" + createdUser + "]";
	}
	
	
}
