package com.ja.domain;

public class Lsltjl extends User{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -3779280582902612274L;

	private Integer id;//
	  
	private Integer userid;//
	  
	private String creattime;//
	  
	private String type;//类型：固定   拼手气
	  
	private String jine;//总金额
	  
	private String count;//数量

	private String desc;//留言
	  
	private String redpack;//生成结果
	  
	private Integer state;//0:有效 1:失效
	  
	private String lingqu;//领取情况
	  
    
    public static long getSerialversionuid() {
		return serialVersionUID;
	}
	public Integer getId() {
		return id;
	}


	public void setId(Integer id) {
		this.id = id;
	}


	public Integer getUserid() {
		return userid;
	}


	public void setUserid(Integer userid) {
		this.userid = userid;
	}


	public String getCreattime() {
		return creattime;
	}


	public void setCreattime(String creattime) {
		this.creattime = creattime;
	}


	public String getType() {
		return type;
	}


	public void setType(String type) {
		this.type = type;
	}


	public String getJine() {
		return jine;
	}


	public void setJine(String jine) {
		this.jine = jine;
	}


	public String getCount() {
		return count;
	}


	public void setCount(String count) {
		this.count = count;
	}


	public String getDesc() {
		return desc;
	}


	public void setDesc(String desc) {
		this.desc = desc;
	}


	public String getRedpack() {
		return redpack;
	}


	public void setRedpack(String redpack) {
		this.redpack = redpack;
	}


	public Integer getState() {
		return state;
	}


	public void setState(Integer state) {
		this.state = state;
	}


	public String getLingqu() {
		return lingqu;
	}


	public void setLingqu(String lingqu) {
		this.lingqu = lingqu;
	}


	@Override
	public String toString() {
		return "RedPacket [id=" + id + ", userid=" + userid + ", creattime=" + creattime + ", type=" + type + ", jine="
				+ jine + ", count=" + count + ", desc=" + desc + ", redpack=" + redpack + ", state=" + state
				+ ", lingqu=" + lingqu + "]";
	}

}
