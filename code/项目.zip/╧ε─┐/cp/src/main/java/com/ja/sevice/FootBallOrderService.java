package com.ja.sevice;

import java.util.List;

import com.ja.domain.FootBallOrder;
import com.ja.domain.User;

public interface FootBallOrderService {

	/**
	 * @param footBallOrder 订单信息
	 * @param user 用户信息
	 * @return 添加订单
	 */
	int addFootBallOrder(FootBallOrder footBallOrder,User user);
	
	/**
	 * @param footBallOrder 订单信息
	 * @return 修改订单
	 */
	int updateFootBallOrder(FootBallOrder footBallOrder);

	/**
	 * @return 普通订单信息以及开奖信息
	 */
	List<FootBallOrder> getCheckOrderInfo();
	
	/**
	 * @param id 用户id
	 * @return
	 */
	List<FootBallOrder> findOneAllOrder(Integer id);

	/**
	 * @param id 订单id
	 * @return 根据id查询 订单详情
	 */
	FootBallOrder findOrderInfo(Integer id);

	/**
	 * @return 综合过关订单以及开奖信息  
	 */
	List<FootBallOrder> getCheckOrderSeries();
	
	/**
	 * 综合过关订单
	 * @param order_num 订单号
	 * @return List集合
	 */
	List<FootBallOrder> getCheckOrderSeriesInfo(String order_num);

	/**
	 * 修改综合过关的子订单
	 * @param order 订单信息
	 * @return int 操作行数
	 */
	int updateFootBallSeries(FootBallOrder order);

	/**
	 * 添加综合过关子订单
	 * @param fo 订单信息
	 * @return 操作行数
	 */
	int addFootBallSeriesInfo(FootBallOrder fo);

	/**
	 * 根据id查询子订单信息
	 * @param statu
	 * @return 子订单信息
	 */
	FootBallOrder getLastMoney(Integer statu);

	/**
	 * 退还本金
	 * @param order 退还的金额
	 * @param user 用户信息
	 * @param state 中奖以及退钱
	 * @return
	 */
	int returMoney(FootBallOrder order, User user, boolean state);
	

}