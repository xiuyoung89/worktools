package com.ja.sevice;

import java.util.List;

import com.ja.domain.ColorVariety;
import com.ja.domain.Data;
import com.ja.domain.Lotter;
import com.ja.domain.LotterExample;

public interface ILotteryService {
	

	/**
	 * 方法名：updateLotterySetupInfo 
	 * 描述：     修改彩种的各种设置信息                  TODO
	 * 参数：    @param lotter 设置信息
	 * 参数：    @return 
	 * @return: int
	 */
	int updateLotterySetupInfo(Lotter lotter);
	
	
	/**查询开奖号*/
	Data inquir(String cName,String period);
	
	/**插入开奖号*/
	
	int updataawardnumber(String cName,String period,String lotterNumber);
	
	/**获取所有彩种信息*/
	List<LotterExample> getAllLotters();

	/**获取所有彩种最新开奖数据*/
	List<Data> getAllLotters1();
	
	LotterExample getLotterByCname(String cName);

	/**根据id查询彩种的信息*/
	Lotter getLotterById(Integer lotterid);
	
	/**查询所有的彩种信息*/
	List<Lotter> getAllLotter();

	int delLotter(int id);

	int resetLotter(int id);

	/**查询彩种的开奖时间差*/
	public String getTimeSpace(String cname);
	
	/**查询北京pk10的彩种信息*/
	Lotter getBjpk10();
	
	/**根据彩种英文名查询彩种信息*/
	Lotter getByCname(String cname);

	/**
	 *彩种基本设置  
	 */
	
	/**开启或关闭彩种*/
	int updatecz(Integer id,Integer state);

	/**根据名称查询彩种信息*/
	Lotter getCzxinxi(String name);

	/**
	 *彩种赔率设置  
	 */
	
	/**修改彩种的玩法的赔率*/
	int upczpv(Lotter lotter);
	
	/**根据玩法来查询当前彩种单个玩法的赔率*/
	Lotter getLotterPlay(String cname, Integer id);

	/**系统彩彩种*/
	List<Lotter> xitongcaicz();

	/**每天开奖次数*/
	int updateCounts(int c2, String cname);
	
	/**香港六合彩*/
	LotterExample xglhc(String cname,int xg6hcstate);
	
	/**最小*/
	int xg6hczx(String cName);
	
	/**最大*/
	int xg6hczd(String cName);
	
	/**根据用户名删除数据*/
	int userdelete(String name,String period);
	
	int iddelete(Integer id);
	
	/**修改重启时时彩开奖时间差*/
	int updateTimespace(String timespace);
	

	/**查询所有的彩种信息*/
	List<Lotter> getAlloter();
	
	/**
	 * 修改彩种打码开启和关闭
	 * @param id
	 * @param state
	 * @return
	 */
	int updatestate(Integer id,Integer state);
	
	/**
	 * 
	 *   方法名：findOnelotter   
	 *   描述：     查询单个彩种信息                  TODO   
	 *   参数：    @param cname
	 *   参数：    @return 
	 * @return: Lotter
	 */
	Lotter findOnelotter(String cname);
	
	/**
	 * 方法名：findAllLotteryState 
	 * 描述：    查询所有彩种的开启状态                   TODO
	 * 参数：    @return 
	 * @return: Lotter
	 */
	List<Lotter> findAllLotteryState();
	 /**
	  * 查询彩种当前状态  就只是单独的查询了 彩种名cname 和 他的state状态 不管开启还是关闭都会被查询出来
	  * @return 查询到则返回list集合包含colorVariety实体数据 没有查询到则返回空集合
	  */
	List<ColorVariety> colorVariety();

	/**
	 * 方法名：findSameTypeLottery 
	 * 描述：     查询彩种的分类                 
	 * 参数：    @return 
	* @return: List<Lotter>
	*/
	List<Lotter> findSameTypeLottery();
	/**
	 * 根据当前彩种名称查询当前彩种的赔率以及 开奖数据
	 * @param cname 彩种名称
	 * @return 返回当前彩种的赔率以及 开奖数据
	 */
	LotterExample syLotterrs(String cname);

}