package com.ja.util;

import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.servlet.HandlerInterceptor;
import org.springframework.web.servlet.ModelAndView;

import com.ja.config.WebsiteStateConfig;

public class InterceptorClient implements HandlerInterceptor {
	
	@Override
	public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler)
			throws Exception {
		if(Integer.parseInt(WebsiteStateConfig.configs.get("weihukaiguan"))==0){//网站维护中
			//请勿删除。以防后面有用，暂时注释
			/*request.getSession().setAttribute("reason", WebsiteStateConfig.configs.get("weihuyuanyin"));
			System.out.println("网站已经开启维护啦");
			response.sendRedirect(request.getContextPath()+"/error.jsp");
			  request.getRequestDispatcher(request.getContextPath()+"/error.jsp").forward(request, response);//转发到登录界面 */			
			ServletOutputStream out = response.getOutputStream();
			out.print(60);//返回给前端页面的未登陆标识
			 out.flush();
            out.close();
			return false;
		}
		return true;
	}

	@Override
	public void postHandle(HttpServletRequest request, HttpServletResponse response, Object handler,
			ModelAndView modelAndView) throws Exception {
		
	}

	@Override
	public void afterCompletion(HttpServletRequest request, HttpServletResponse response, Object handler, Exception ex)
			throws Exception {
		
	}

}
