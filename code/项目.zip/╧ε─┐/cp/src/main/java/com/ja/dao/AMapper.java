package com.ja.dao;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.ja.domain.Admin;
import com.ja.domain.AdminUser;
import com.ja.domain.Logonlog;
import com.ja.domain.Operationlog;
import com.ja.domain.Qxgl;

public interface AMapper {
	
	
	/**
	 * 添加后台用户
	 * @param admin 用户信息
 	 * @return
	 */
	int registerAdminUser(AdminUser admin);
	
	/**
	 * 
	   *   方法名：insertPower   
	   *   描述：  添加用户权限                     TODO   
	   *   参数：    @param admin 后台用户信息
	   *   参数：    @return 
	 * @return: int
	 */
	int insertPower(AdminUser admin);
	
	/**
	 * 修改后台用户信息
	 * @param admin 用户信息
	 * @return
	 */
	int updateAdminUser(AdminUser admin);
	
	/**
	 * 用户登录
	 * @param name
	 * @param pass
	 * @return
	 */
	public AdminUser admin(@Param("name")String name,@Param("pass") String pass);
	/**
	 * 查询所有后台用户
	 * @return
	 */
	public List<AdminUser> Allusers();
	/**
	 * 后台用户登录日志
	 * @return
	 */
	int logonlog(@Param("accountnumber")String accountnumber,@Param("superrecord") String superrecord,@Param("ip") String ip,@Param("operationtime") String operationtime,@Param("time")String time);
	
	/**
	 * 验证IP
	 * @param ip
	 * @return
	 */
	AdminUser IP(String ip);

	/**
	 * 禁用-启用
	 * @param state
	 * @return
	 */
	int jyqy(@Param("state")int state,@Param("name") String name);
	/**
	 * 删除后台用户
	 */
	int adminsc(String name);
	
	List<Operationlog> operationlog(String time);
	
	int register(@Param("name")String name,@Param("balance")double balance, @Param("pass")String pass, @Param("qq")String qq, @Param("ip")String ip,@Param("telephone")String telephone,@Param("state")int state);
	
	String yhcx(String name);
	
	int modifyurl(String url);
	
	int setup(String money);
	
	int updatawhole(@Param("time")String time,@Param("redenvelopes")String redenvelopes,@Param("leavingamessage")String leavingamessage,@Param("typeofredenvelopes")String typeofredenvelopes,@Param("numberofredpackets")int numberofredpackets);
	
	Admin inquireAll();
	
	/**
	 * 根据id查询客服的信息
	 * @param id 客服id
	 * @return
	 */
	AdminUser findByIdAmdinUser(Integer id);

	/**
	 * 查询所有的在线客服
	 * @return
	 */
	List<AdminUser> findAllKeFuUser();
	
	/**
	 * 根据类型查询在线客服的信息
	 * @param type 客服类型
	 * @return
	 */
	List<AdminUser> findByTypeKeFuUser(Integer type);

	/**
	 * 删除在线客服
	 * @param id 客服id
	 * @return
	 */
	int deleteKeFuUser(Integer id);
	
	/**
	 * 查询所有的管理员用户
	 * @return
	 */
	List<AdminUser> findAllAdminInfo();

	/**
	 * 删除用户权限
	 * @param id
	 * @return
	 */
	int delPower(Integer id);

	/**
	 * 修改公告
	 * @return
	 */
	int updatagg(@Param("notice")String notice);
	/**
	 * 查询公告
	 * @return
	 */
	String querygg();
	/**
	 * 
	 * @param q：权限信息
	 * @return
	 */
	int qxgl(@Param("q")Qxgl q);

	/**
	 * 查询总条数
	 * @return
	 */
	int getTotalrecord();
	
	List<Logonlog> getPageData(@Param("pageindex")int pageindex,@Param("row")int row);
	
	
	/**
	 * 方法名：findByAdminUserInfo 
	 * 描述：     根据用户名查询用户                 
	 * 参数：    @param name
	 * 参数：    @return 
	 * @return: AdminUser
	 */
	AdminUser findByAdminUserInfo(String name);
	
	/**
	 * 方法名：findUserJurisdiction 
	 * 描述：    查询后台用户的权限                  
	 * 参数：    @param name 用户名
	 * 参数：    @return 
	 * @return: AdminUser
	 */
	AdminUser findUserJurisdiction(String name);
	
	/**
	 * 方法名：addUserJurisdiction 
	 * 描述：     添加后台用户管理权限                 
	 * 参数：    @param users 用户信息
	 * 参数：    @return 
	 * @return: int
	 */
	int addUserJurisdiction(AdminUser users);

	/**
	 * 方法名：updateUserJurisdiction 
	 * 描述：     修改后台用户的权限                 
	 * 参数：    @param user 权限信息
	 * 参数：    @return 
	 * @return: int
	 */
	int updateUserJurisdiction(AdminUser user);
	
	/**
	 * 方法名：findUserLoginLog 
	 * 描述：     查询后台用户登录日志                 
	 * 参数：    @param time
	 * 参数：    @return 
	 * @return: List<Logonlog>
	 */
	List<Logonlog> findUserLoginLog(String time);
	
}
