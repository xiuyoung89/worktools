package com.ja.dao;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.ja.domain.FootBallMatch;
import com.ja.domain.FootballMatchResult;

/**
 * 
 */
public interface FootBallMatchMapper {

	/**
	 * @param play 玩法
	 * @param type 投注类型
	 * @return 根据玩法以及投注类型查询赛事信息
	 */
	List<FootBallMatch> findTypeMatch(@Param("type")String play, @Param("types")String type,@Param("time")String time);
	
	/**
	 * 
	 * @param cname 赛事英文名称
	 * @param play 玩法
	 * @param type 投注类型
	 * @param time 时间
	 * @return 根据赛事目录查询相关的赛事信息
	 */
	List<FootBallMatch> findMatch(@Param("cname")String cname,@Param("type")String play, @Param("types")String type, @Param("time")String time);
	
	/**
	 * @param id 赛事id
	 * @return 根据类型查询具体的赛事信息
	 */
	FootBallMatch findMatchInfo(Integer id);
    
	/**
	 * 保存比赛
	 * @param match
	 * @return
	 */
	int insertByBatch(@Param("matches")List<FootBallMatch> matches);

	/**
	 * 批量更新比赛中的赛果数据
	 * @return
	 */
	void updateResultByBatch(@Param("results")List<FootballMatchResult> results);
	
	/**
	 * 批量更新盘口数据
	 * @param results
	 */
	void updateMatchByBatch(@Param("matches")List<FootBallMatch> matches);
	
	/**
	 * 更新一条盘口数据
	 * @param results
	 */
	void update(@Param("matche")FootBallMatch matche);

	/**
	 * 非滚球非单式玩法的数据查询
	 * @param type
	 * @param types
	 * @param league
	 * @param start_time
	 * @param team_h
	 * @param team_c
	 * @return
	 */
	List<FootBallMatch> findByMatchInfoOfNotDSAndNotGQ(@Param("type")String type, @Param("types")String types, 
			@Param("league")String league, @Param("start_time")String start_time, 	
			@Param("team_h")String team_h, @Param("team_c")String team_c);
	
	/**
	 * 根据条件查询比赛的开始时间
	 * @param league
	 * @param team_h
	 * @param team_c
	 * @param substring
	 * @return
	 */
	List<String> findStartTime(@Param("league")String league, @Param("team_h")String team_h, 
			@Param("team_c")String team_c, @Param("date")String date);

	/**
	 * 查询数据库中最新的比赛信息的ID
	 * @return
	 */
	List<Integer> findIdsOfLatest();
	
	/**
	 * 根据id列表批量更新过期状态字段isOutDated为yes
	 * @param idsOfDeleted
	 */
	void updateOutDatedByBatch(@Param("idsOfDeleted")List<Integer> idsOfDeleted);

	/**
	 * 单式和滚球玩法的数据查询
	 * @param newMatch
	 * @return
	 */
	List<FootBallMatch> findByMatchInfoOfDSAndGQ(@Param("match")FootBallMatch match);
	
	/**
	 * 根据时间查询赛事结果
	 * @param date 查询时间
	 * @return
	 */
	List<FootBallMatch> findMatchResult(String date);
	
}


