package com.ja.sevice.impl;

import org.springframework.stereotype.Service;

import com.ja.sevice.YunyingJlService;

@Service
public class YunyingJlServiceImpl implements YunyingJlService {
	
}