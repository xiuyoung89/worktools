package com.ja.dao;

public interface YunyingJlMapper {
	
	
	
}
