package com.ja.domain;

import java.io.Serializable;

public class XitongcaiJl implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -4479808171926948922L;

	private Integer id;  //系统彩预设记录
	
	private String cname; //彩种英文名

    private String gameNameInChinese; //彩种中文名称

    private String period; //预设期号

    private String lotterNumber; //预设号码

    private String lotterTime; //预设时间

    private String state; //状态
    
    private String noteTime; //状态
    
    private String paijtime; //开奖时间
    
    private String czname; //预设操作人
    
    private String nextStopOrderTimeEpoch;// 下期开奖时间
    
	private String nextperiod; //下期期号
    
    
    public static long getSerialversionuid() {
		return serialVersionUID;
	}
    public String getNextStopOrderTimeEpoch() {
		return nextStopOrderTimeEpoch;
	}

	public void setNextStopOrderTimeEpoch(String nextStopOrderTimeEpoch) {
		this.nextStopOrderTimeEpoch = nextStopOrderTimeEpoch;
	}

	public String getNextperiod() {
		return nextperiod;
	}

	public void setNextperiod(String nextperiod) {
		this.nextperiod = nextperiod;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

    public Integer getId() {
        return id;
    }

    public String getPaijtime() {
		return paijtime;
	}

	public void setPaijtime(String paijtime) {
		this.paijtime = paijtime;
	}

	public void setId(Integer id) {
        this.id = id;
    }

	public String getCname() {
		return cname;
	}

	public String getPeriod() {
		return period;
	}

	public void setPeriod(String period) {
		this.period = period;
	}

	public String getLotterNumber() {
		return lotterNumber;
	}

	public void setLotterNumber(String lotterNumber) {
		this.lotterNumber = lotterNumber;
	}

	public String getLotterTime() {
		return lotterTime;
	}

	public void setLotterTime(String lotterTime) {
		this.lotterTime = lotterTime;
	}

	public String getCzname() {
		return czname;
	}

	public void setCzname(String czname) {
		this.czname = czname;
	}

	public void setCname(String cname) {
		this.cname = cname;
	}
	
	public String getNoteTime() {
		return noteTime;
	}

	public void setNoteTime(String noteTime) {
		this.noteTime = noteTime;
	}

	public String getGameNameInChinese() {
		return gameNameInChinese;
	}

	public void setGameNameInChinese(String gameNameInChinese) {
		this.gameNameInChinese = gameNameInChinese;
	}

	@Override
	public String toString() {
		return "XitongcaiJl [id=" + id + ", cname=" + cname + ", gameNameInChinese=" + gameNameInChinese + ", period="
				+ period + ", lotterNumber=" + lotterNumber + ", lotterTime=" + lotterTime + ", state=" + state
				+ ", noteTime=" + noteTime + ", paijtime=" + paijtime + ", czname=" + czname + "]";
	}

	public XitongcaiJl() {
		super();
	}
    
}