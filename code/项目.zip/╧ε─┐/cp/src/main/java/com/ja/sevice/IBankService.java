package com.ja.sevice;

import java.util.List;

import com.ja.domain.BankCard;
import com.ja.domain.User;

/**@DESC 
 * @AUTH LBQ
 * @DATE 2018年1月18日 下午11:07:14
 */
public interface IBankService {

	/**添加-修改银行卡信息以及支付密码*/
	int save(BankCard bank);

	/**根据用户id查询当前用户的银行卡信息*/
	BankCard getBankByUid(Integer id);

	/**查询所有的用户的银行卡信息*/
	List<BankCard> getAll();

	/**对比支付密码*/
	BankCard checkPass(String zhifupass, Integer id);
	
	/**根据用户id查询当前用户*/
	User queryUser(User user);
	
	/**加上赠送金额*/
	int updataUser(User user);
	/**
	 * 查询银行卡
	 * @param str
	 * @return
	 */
	BankCard inquiryBankCard(String str);
}
