package com.ja.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
/**
 * 
 * 项目名称：cp   
 * 类名称：PC_InfoController.java   
 * 类描述：   pc 页面信息 - 图片 - 说明
 * 创建人：   GL
 * 创建时间：2018年10月29日 上午11:08:36   
 * @version v1.0.0
 */
@RequestMapping("/infos")
@Controller
public class PC_InfoController {
	
	
}
