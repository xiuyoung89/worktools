package com.ja.domain;

import java.io.Serializable;

public class Therebate implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 8648183887323727474L;

	private Integer id;// 代理返点

	private Integer userid;// 用户id
	private String cname;//用户名
	private String sname;// 上级帐号

	private String subordinate; // 上级 id

	private String thelowertherebate; // 上级返点率

	private String money;// 上级返点金额

	private String ssname;// 上上级帐号

	private String underlowerrebate;// 上上级id

	private String lowerandlowerlevel;// 上上级返点率

	private String lowerandlowerlevels;// 上上级返点金额

	private String time; // 创建时间
	
    public static long getSerialversionuid() {
		return serialVersionUID;
	}
	public String getCname() {
		return cname;
	}

	public void setCname(String cname) {
		this.cname = cname;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getSname() {
		return sname;
	}

	public void setSname(String sname) {
		this.sname = sname;
	}

	public String getSsname() {
		return ssname;
	}

	public void setSsname(String ssname) {
		this.ssname = ssname;
	}

	public Integer getUserid() {
		return userid;
	}

	public void setUserid(Integer userid) {
		this.userid = userid;
	}

	public String getThelowertherebate() {
		return thelowertherebate;
	}

	public void setThelowertherebate(String thelowertherebate) {
		this.thelowertherebate = thelowertherebate;
	}

	public String getSubordinate() {
		return subordinate;
	}

	public void setSubordinate(String subordinate) {
		this.subordinate = subordinate;
	}

	public String getTime() {
		return time;
	}

	public void setTime(String time) {
		this.time = time;
	}

	public String getMoney() {
		return money;
	}

	public void setMoney(String money) {
		this.money = money;
	}

	public String getLowerandlowerlevel() {
		return lowerandlowerlevel;
	}

	public void setLowerandlowerlevel(String lowerandlowerlevel) {
		this.lowerandlowerlevel = lowerandlowerlevel;
	}

	public String getUnderlowerrebate() {
		return underlowerrebate;
	}

	public void setUnderlowerrebate(String underlowerrebate) {
		this.underlowerrebate = underlowerrebate;
	}

	public String getLowerandlowerlevels() {
		return lowerandlowerlevels;
	}

	public void setLowerandlowerlevels(String lowerandlowerlevels) {
		this.lowerandlowerlevels = lowerandlowerlevels;
	}

	@Override
	public String toString() {
		return "Therebate [id=" + id + ", userid=" + userid + ", cname=" + cname + ", sname=" + sname + ", subordinate="
				+ subordinate + ", thelowertherebate=" + thelowertherebate + ", money=" + money + ", ssname=" + ssname
				+ ", underlowerrebate=" + underlowerrebate + ", lowerandlowerlevel=" + lowerandlowerlevel
				+ ", lowerandlowerlevels=" + lowerandlowerlevels + ", time=" + time + "]";
	}

}
