package com.ja.sevice;

import java.util.List;

import com.ja.domain.AdminUser;
import com.ja.domain.Dama;
import com.ja.domain.Damal;
import com.ja.util.JsonResult;

public interface DamalService {
	
	/**
	 *   方法名：updateCodeCount   
	 *   描述：     修改用户的打码量                  TODO   
	 *   参数：    @param dama
	 *   参数：    @param admin
	 *   参数：    @return 
	 * @return: JsonResult
	 */
	JsonResult updateCodeCount(Dama dama, AdminUser admin);
	
	

	/**查询所有会员的打码量及提款所需*/
	List<Damal> getAlldamal();
	
	/**开启或关闭当前用户的打码*/
	int upDamal(Integer id, Integer state);

	/**修改当前会员的打码量 -增加打码量记录*/
	int updateDamal(Damal damal, Dama da);

	/**根据id查询当前用户的打码信息*/
	Damal getOnedamal(Integer id);

	/**添加会员的打码信息*/
	int addamal(Damal damal);

	/** 根据条件查询会员打码量及提款所需 */
	List<Damal> mhOneDama(Damal damal);


}
