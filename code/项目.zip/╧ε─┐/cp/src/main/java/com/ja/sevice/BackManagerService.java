package com.ja.sevice;

import java.util.List;

import com.ja.domain.Admin;
import com.ja.domain.AdminUser;
import com.ja.domain.Logonlog;
import com.ja.domain.Operationlog;
import com.ja.domain.User;

public interface BackManagerService {
	/**
	 * 方法名：addUserAccountInfo 
	 * 描述：    创建用户和内部账户                  TODO
	 * 参数：    @param user 账户信息
	 * 参数：    @return 
	 * @return: int
	 */
	int createdUserAccountInfo(User user);
	
	
	
	
	/**
	 * 后台用户登录
	 * @param name
	 * @param pass
	 * @return
	 */
	public AdminUser admin(String name,String pass);
	/**
	 * 查询所有后台用户
	 * @return
	 */
	public List<AdminUser> Allusers();
	
	/**
	 * 后台用户登录日志
	 */
	public void logonlog(String accountnumber,String superrecord,String ip,String operationtime,String time);

	public List<Operationlog> operationlog(String time);
	
	/**
	 * 添加后台用户
	 * @param admin 用户信息
	 * @return
	 */
	Integer registerAdminUser(AdminUser admin);
	
	/**
	 * 验证ip
	 * @param ip
	 * @return
	 */
	public AdminUser IP(String ip); 
	
	/**
	 * 修改后台用户质料
	 * @param admin 用户信息
	 * @return
	 */
	public String updateAdminUser(AdminUser admin);
	
	/**
	 * 禁用-启用
	 */
	public int jyqy(int state,String name);
	/**
	 * 删除后台用户
	 * @param name
	 * @return
	 */
	public int adminsc(String name);
	
	/**添加用户接口*/
	int register(String name,  double balance,String pass, String qq, String ip,String telephone,int state);
	
	int modifyurl(String url);
	
	int setup(String money);
	
	int updatawhole(String time,String redenvelopes,String leavingamessage,String typeofredenvelopes,int numberofredpackets);
	
	Admin inquireAll();
	
	/**
	 * 查询所有的管理员用户
	 * @return
	 */
	List<AdminUser> findAllAdminInfo();
	
	/**
	 * 删除后台用户
	 * @param id 用户id
	 * @return
	 */
	int deleteKeFuUser(Integer id);
	
	/**
	 * 根据id查询用户信息
	 * @param id 用户id 
	 * @return
	 */
	public AdminUser findByIdAmdinUser(Integer id);
	/**
	 * notice:公告内容
	 * 修改公告
	 * @return
	 */
	int updatagg(String notice);
	/**
	 * 查询公告
	 * @return
	 */
	String querygg();
	
	/**
	 * 方法名：recyclingTrialAccount 
	 * 描述：    每天回收试玩用户                  
	 * 参数：    @return 
	 * @return: int
	 */
	int recyclingTrialAccount();
	
	/**
	 * 方法名：findByAdminUserInfo 
	 * 描述：     根据用户名查询用户                 
	 * 参数：    @param name
	 * 参数：    @return 
	 * @return: AdminUser
	 */
	AdminUser findByAdminUserInfo(String name);

	/**
	 * 方法名：findUserJurisdiction 
	 * 描述：    查询后台用户的权限                  
	 * 参数：    @param name 用户名
	 * 参数：    @return 
	 * @return: AdminUser
	 */
	AdminUser findUserJurisdiction(String name);
	
	/**
	 * 方法名：addUserJurisdiction 
	 * 描述：     添加后台用户管理权限                 
	 * 参数：    @param users 用户信息
	 * 参数：    @return 
	 * @return: int
	 */
	int addUserJurisdiction(AdminUser users);

	/**
	 * 方法名：updateUserJurisdiction 
	 * 描述：     修改后台用户的权限                 
	 * 参数：    @param user 权限信息
	 * 参数：    @return 
	 * @return: int
	 */
	int updateUserJurisdiction(AdminUser user);

	/**
	 * 方法名：findUserLoginLog 
	 * 描述：     查询后台用户登录日志                 
	 * 参数：    @param time
	 * 参数：    @return 
	 * @return: List<Logonlog>
	 */
	List<Logonlog> findUserLoginLog(String time);
}
