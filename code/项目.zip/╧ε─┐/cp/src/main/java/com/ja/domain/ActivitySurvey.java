package com.ja.domain;

import java.io.Serializable;

/**
 *活动参加情况
 */
public class ActivitySurvey  implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = -7711213829898660332L;

	private Integer id;//活动参加情况
	
	private String name;//用户名称
	
	private String activityName;//活动名称
	
	private String createTime;//创建时间
	
	private Double money;//领取多少钱
	
	private Integer actid;//活动id
	
	private Integer userid;//用户id
	
	public String getCreateTime() {
		return createTime;
	}

	public void setCreateTime(String createTime) {
		this.createTime = createTime;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getActivityName() {
		return activityName;
	}

	public void setActivityName(String activityName) {
		this.activityName = activityName;
	}

	public String getCreatedTime() {
		return createTime;
	}

	public void setCreatedTime(String createdTime) {
		this.createTime = createdTime;
	}

	public Double getMoney() {
		return money;
	}

	public void setMoney(Double money) {
		this.money = money;
	}

	public Integer getActid() {
		return actid;
	}

	public void setActid(Integer actid) {
		this.actid = actid;
	}

	public Integer getUserid() {
		return userid;
	}

	public void setUserid(Integer userid) {
		this.userid = userid;
	}

	@Override
	public String toString() {
		return "ActivitySurvey [id=" + id + ", name=" + name + ", activityName=" + activityName + ", createTime="
				+ createTime + ", money=" + money + ", actid=" + actid + ", userid=" + userid + "]";
	}

	public ActivitySurvey() {
		super();
	}
	
	
}
