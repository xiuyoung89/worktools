package com.ja.dao;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.ja.domain.Data;
import com.ja.domain.XitongcaiJl;

public interface XitongcaiJlMapper {

	/**
	 * 系统彩预设记录
	 * @param startIndex
	 * @param lineCount
	 * @param model 
	 * @return
	 */
	List<XitongcaiJl> getPageData(@Param("startIndex")Integer startIndex, @Param("lineCount")Integer lineCount, @Param("model")int model);
	
	/**
	 * 模糊查询系统彩记录
	 * @param startIndex 
	 * @param lineCount 
	 * @param model 
	 */
	List<XitongcaiJl> findSystemJl(@Param("startIndex")Integer startIndex, @Param("lineCount")Integer lineCount, @Param("cname")String cname, @Param("period")String period, @Param("date1")String date1,  @Param("date2")String date2,@Param("model")int model);
	
	/**
	 * 
	    *   方法名：getPageDataCounts   
	    *   描述：     查询私彩的记录数                  TODO   
	    *   参数：    @return 
	 * @return: Integer
	 */
	Integer getPageDataCounts();
	/**
	 * 查询私彩预设管理记录 统计
	 * @param data data对象 参数
	 * @param date1 需要查询的开始时间
	 * @param date2  需要查询的结束时间
	 * @return  查询到责返回总条数 没有查询到则返回0
	 */
	Integer findSystemJlCounts(@Param("data")Data data,@Param("date1")String date1,@Param("date2")String date2);

}
