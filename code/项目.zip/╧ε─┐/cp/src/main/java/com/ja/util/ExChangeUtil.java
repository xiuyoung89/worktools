package com.ja.util;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Controller;

import com.ja.check.action.CheckOrder;

@Controller
public class ExChangeUtil {

	public static double rebate(String str) {
		ArrayList<Double> list = new ArrayList<Double>();
		if (!str.equals("")) {
			String[] str1 = str.split(",");
			for (int i = 0; i < str1.length; i++) {
				list.add(Double.parseDouble(str1[i]));
			}
		}
		double maxRebate = Collections.max(list);
		return maxRebate;
	}

	public static double dxds(String[] str, String[] pv) {
		int a1 = 0;
		int a2 = 0;
		int a3 = 0;
		int a4 = 0;
		double money = 0.0;
		for (int i = 0; i < str.length; i++) {
			if (str[i].equals("单")) {
				a1 = 1;
			}
			if (str[i].equals("双")) {
				a2 = 1;
			}
			if (str[i].equals("大")) {
				a3 = 1;
			}
			if (str[i].equals("小")) {
				a4 = 1;
			}
		}
		money = a1 * Double.parseDouble(pv[0]) + a2 * Double.parseDouble(pv[1]) + a3 * Double.parseDouble(pv[2])
				+ a4 * Double.parseDouble(pv[3]);
		return money;
	}

	public static double dxdslh(String[] str, String[] pv) {
		int a1 = 0;
		int a2 = 0;
		int a3 = 0;
		int a4 = 0;
		int a5 = 0;
		int a6 = 0;
		int a7 = 0;
		double money = 0.0;
		for (int i = 0; i < str.length; i++) {
			if (str[i].equals("单")) {
				a1 = 1;
			}
			if (str[i].equals("双")) {
				a2 = 1;
			}
			if (str[i].equals("大")) {
				a3 = 1;
			}
			if (str[i].equals("小")) {
				a4 = 1;
			}
			if (str[i].equals("龙")) {
				a5 = 1;
			}
			if (str[i].equals("虎")) {
				a6 = 1;
			}
			if (str[i].equals("和")) {
				a7 = 1;
			}
		}
		money = a1 * Double.parseDouble(pv[0]) + a2 * Double.parseDouble(pv[1]) + a3 * Double.parseDouble(pv[2])
				+ a4 * Double.parseDouble(pv[3]) + a5 * Double.parseDouble(pv[4]) + a6 * Double.parseDouble(pv[5])
				+ a7 * Double.parseDouble(pv[6]);
		return money;
	}

	public static double d1d10m(String play, String[] str, String[] pv) {
		String[] qiu1 = { "66", "55", "44", "33", "22", "11", "01", "02", "03", "04", "05", "06", "07", "08", "09",
				"10" };
		String[] qiu2 = { "55", "44", "33", "22", "01", "02", "03", "04", "05", "06", "07", "08", "09", "10" };
		int a1 = 0;
		int a2 = 0;
		int a3 = 0;
		int a4 = 0;
		int a5 = 0;
		int a6 = 0;
		int a7 = 0;
		int b = 0;
		double money = 0.0;
		if (play.equals("gj") || play.equals("yj") || play.equals("d3m") || play.equals("d4m") || play.equals("d5m")) {
			for (int i = 0; i < str.length; i++) {
				if (str[i].equals("单")) {
					a1 = 1;
				}
				if (str[i].equals("双")) {
					a2 = 1;
				}
				if (str[i].equals("大")) {
					a3 = 1;
				}
				if (str[i].equals("小")) {
					a4 = 1;
				}
				if (str[i].equals("龙")) {
					a5 = 1;
				}
				if (str[i].equals("虎")) {
					a6 = 1;
				}
				for (int j = 0; j < qiu1.length; j++) {
					if (str[i].equals(qiu1[j])) {
						a7 = 1;
						b = j;
					}
				}
			}
			money = a1 * Double.parseDouble(pv[0]) + a2 * Double.parseDouble(pv[1]) + a3 * Double.parseDouble(pv[2])
					+ a4 * Double.parseDouble(pv[3]) + a5 * Double.parseDouble(pv[4]) + a6 * Double.parseDouble(pv[5])
					+ a7 * Double.parseDouble(pv[b]);
		} else {
			for (int i = 0; i < str.length; i++) {
				if (str[i].equals("单")) {
					a1 = 1;
				}
				if (str[i].equals("双")) {
					a2 = 1;
				}
				if (str[i].equals("大")) {
					a3 = 1;
				}
				if (str[i].equals("小")) {
					a4 = 1;
				}
				for (int j = 0; j < qiu2.length; j++) {
					if (str[i].equals(qiu2[j])) {
						a5 = 1;
						b = j;

					}
				}
			}
			money = a1 * Double.parseDouble(pv[0]) + a2 * Double.parseDouble(pv[1]) + a3 * Double.parseDouble(pv[2])
					+ a4 * Double.parseDouble(pv[3]) + a5 * Double.parseDouble(pv[b]);
		}
		return money;
	}

	public static double sscd1d5q(String[] str, String[] pv) {
		String[] qiu = { "11", "22", "33", "44", "0", "1", "2", "3", "4", "5", "6", "7", "8", "9" };
		int a1 = 0;
		int a2 = 0;
		int a3 = 0;
		int a4 = 0;
		int a5 = 0;
		int b = 0;
		double money = 0.0;
		for (int i = 0; i < str.length; i++) {
			if (str[i].equals("单")) {
				a1 = 1;
			}
			if (str[i].equals("双")) {
				a2 = 1;
			}
			if (str[i].equals("大")) {
				a3 = 1;
			}
			if (str[i].equals("小")) {
				a4 = 1;
			}
			for (int j = 0; j < qiu.length; j++) {
				if (str[i].equals(qiu[j])) {
					a5 = 1;
					b = j;

				}
			}
		}
		money = a1 * Double.parseDouble(pv[0]) + a2 * Double.parseDouble(pv[1]) + a3 * Double.parseDouble(pv[2])
				+ a4 * Double.parseDouble(pv[3]) + a5 * Double.parseDouble(pv[b]);
		return money;
	}

	public static double syx5d1d5q(String[] str, String[] pv) {
		String[] qiu = { "22", "33", "44", "55", "01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11" };
		int a1 = 0;
		int a2 = 0;
		int a3 = 0;
		int a4 = 0;
		int a5 = 0;
		int b = 0;
		double money = 0.0;
		for (int i = 0; i < str.length; i++) {
			if (str[i].equals("单")) {
				a1 = 1;
			}
			if (str[i].equals("双")) {
				a2 = 1;
			}
			if (str[i].equals("大")) {
				a3 = 1;
			}
			if (str[i].equals("小")) {
				a4 = 1;
			}
			for (int j = 0; j < qiu.length; j++) {
				if (str[i].equals(qiu[j])) {
					a5 = 1;
					b = j;

				}
			}
		}
		money = a1 * Double.parseDouble(pv[0]) + a2 * Double.parseDouble(pv[1]) + a3 * Double.parseDouble(pv[2])
				+ a4 * Double.parseDouble(pv[3]) + a5 * Double.parseDouble(pv[b]);
		return money;
	}

	public static double maxRebate(String[] str, String[] pv, String[] sc) {
		List<Double> list = new ArrayList<Double>();
		List<Double> listd = new ArrayList<Double>();
		List<Integer> co = new ArrayList<Integer>();
		double money = 0.0;
		for (int i = 0; i < pv.length; i++) {
			list.add(Double.parseDouble(pv[i]));
		}
		for (int i = 0; i < str.length; i++) {
			for (int j = 0; j < sc.length; j++) {
				if (str[i].equals(sc[j])) {
					co.add(j);
				}
			}
		}
		for (int i = 0; i < co.size(); i++) {
			listd.add(list.get(co.get(i)));
		}
		money = Collections.max(listd);
		return money;
	} 

	public static double k3zh(String[] str, String[] pv) {
		String[] qiu = { "3", "4", "5", "6", "7", "8", "9", "10", "11", "12", "13", "14", "15", "16", "17", "18" };
		int a1 = 0;
		int a2 = 0;
		int a3 = 0;
		int a4 = 0;
		double money = 0.0;
		List<Double> list = new ArrayList<Double>();
		List<Double> listd = new ArrayList<Double>();
		List<Integer> co = new ArrayList<Integer>();
		for (int i = 0; i < pv.length; i++) {
			list.add(Double.parseDouble(pv[i]));
		}
		for (int i = 0; i < str.length; i++) {
			for (int j = 0; j < qiu.length; j++) {
				if (str[i].equals(qiu[j])) {
					co.add(j);
				}
			}
		}
		for (int i = 0; i < co.size(); i++) {
			listd.add(list.get(co.get(i)));
		}
		for (int i = 0; i < str.length; i++) {
			if (str[i].equals("大")) {
				a1 = 1;
			}
			if (str[i].equals("小")) {
				a2 = 1;
			}
			if (str[i].equals("单")) {
				a3 = 1;
			}
			if (str[i].equals("双")) {
				a4 = 1;
			}
		}
		double a = 0.00;
		if (listd.size() != 0) {
			a = Collections.max(listd);
		}
		money = a + a1 * Double.parseDouble(pv[16]) + a2 * Double.parseDouble(pv[17]) + a3 * Double.parseDouble(pv[18])
				+ a4 * Double.parseDouble(pv[19]);
		return money;
	}

	public static String calZodiac(int year) {
		String zodiac = "";
		int remainder = year % 12;
		switch (remainder) {
		case 0:
			zodiac = "申猴";
			break;
		case 1:
			zodiac = "酉鸡";
			break;
		case 2:
			zodiac = "戌狗";
			break;
		case 3:
			zodiac = "亥猪";
			break;
		case 4:
			zodiac = "子鼠";
			break;
		case 5:
			zodiac = "丑牛";
			break;
		case 6:
			zodiac = "寅虎";
			break;
		case 7:
			zodiac = "卯兔";
			break;
		case 8:
			zodiac = "辰龙";
			break;
		case 9:
			zodiac = "巳蛇";
			break;
		case 10:
			zodiac = "午马";
			break;
		case 11:
			zodiac = "未羊";
			break;
		}
		return zodiac;
	}

	public static double ws(String[] str, String[] pv) {
		String[] w1 = { "0尾", "1尾", "2尾", "3尾", "4尾", "5尾", "6尾", "7尾", "8尾", "9尾" };
		int a1 = 0;
		int a2 = 0;
		int a3 = 0;
		int a4 = 0;
		double money = 0.0;
		List<Double> list = new ArrayList<Double>();
		List<Double> listd = new ArrayList<Double>();
		List<Integer> co = new ArrayList<Integer>();
		for (int i = 0; i < pv.length; i++) {
			list.add(Double.parseDouble(pv[i]));
		}
		for (int i = 0; i < str.length; i++) {
			for (int j = 0; j < w1.length; j++) {
				if (str[i].equals(w1[j])) {
					co.add(j);
				}
			}
		}
		for (int i = 0; i < co.size(); i++) {
			listd.add(list.get(co.get(i)));
		}
		for (int i = 0; i < str.length; i++) {
			if (str[i].equals("大")) {
				a1 = 1;
			}
			if (str[i].equals("小")) {
				a2 = 1;
			}
			if (str[i].equals("单")) {
				a3 = 1;
			}
			if (str[i].equals("双")) {
				a4 = 1;
			}
		}
		double a = 0.00;
		if (listd.size() != 0) {
			a = Collections.max(listd);
		}
		money = a + a1 * Double.parseDouble(pv[10]) + a2 * Double.parseDouble(pv[11]) + a3 * Double.parseDouble(pv[12])
				+ a4 * Double.parseDouble(pv[13]);
		return money;
	}

	public static double zxds(String[] str, String[] pv) {
		String[] z1 = { "2肖", "3肖", "4肖", "5肖", "6肖", "7肖" };
		int a1 = 0;
		int a2 = 0;
		double money = 0.0;
		List<Double> list = new ArrayList<Double>();
		List<Double> listd = new ArrayList<Double>();
		List<Integer> co = new ArrayList<Integer>();
		for (int i = 0; i < pv.length; i++) {
			list.add(Double.parseDouble(pv[i]));
		}
		for (int i = 0; i < str.length; i++) {
			for (int j = 0; j < z1.length; j++) {
				if (str[i].equals(z1[j])) {
					co.add(j);
				}
			}
		}
		for (int i = 0; i < co.size(); i++) {
			listd.add(list.get(co.get(i)));
		}
		for (int i = 0; i < str.length; i++) {
			if (str[i].equals("单")) {
				a1 = 1;
			}
			if (str[i].equals("双")) {
				a2 = 1;
			}
		}
		double a = 0.00;
		if (listd.size() != 0) {
			a = Collections.max(listd);
		}
		money = a + a1 * Double.parseDouble(pv[6]) + a2 * Double.parseDouble(pv[7]);
		return money;
	}

	/**
	 * 
	   *   方法名：checkLotterMoney1   
	   *   描述：     北京PK10中奖金额最多的玩法                  TODO   
	   *   参数：    @param play 下注玩法名称
	   *   参数：    @param cplay1 下注玩法属性
	   *   参数：    @param pv 下注的赔率
	   *   参数：    @param oMoney 单注金额
	   *   参数：    @return 
	 * @return: double
	 */
	public static double checkLotterMoney1(String play, String[] cplay1, String[] pv, double oMoney) { // TODO 中奖金额统计
		double money = 0.00;
		String[] qiu = { "单", "双", "大", "小", "龙", "虎", "01", "02", "03", "04", "05", "06", "07", "08", "09", "10" };
		String[] qiu1 = { "单", "双", "大", "小", "01", "02", "03", "04", "05", "06", "07", "08", "09", "10" };
		int a1 = 0;
		int a2 = 0;
		int a3 = 0;
		int a4 = 0;
		int a5 = 0;
		int a6 = 0;
		int a7 = 0;
		int b = 0;
		switch (play) {
		case "gyhz":
			for (int i = 0; i < cplay1.length; i++) {
				if (cplay1[i].equals("单")) {
					a1 = 1;
				}
				if (cplay1[i].equals("双")) {
					a2 = 1;
				}
				if (cplay1[i].equals("大")) {
					a3 = 1;
				}
				if (cplay1[i].equals("小")) {
					a4 = 1;
				}
			}
			money = a1 * oMoney * Double.parseDouble(pv[0]) + a2 * oMoney * Double.parseDouble(pv[1])
					+ a3 * oMoney * Double.parseDouble(pv[2]) + a4 * oMoney * Double.parseDouble(pv[3]);
			break;
		case "gj":
			for (int i = 0; i < cplay1.length; i++) {
				if (cplay1[i].equals("单")) {
					a1 = 1;
				}
				if (cplay1[i].equals("双")) {
					a2 = 1;
				}
				if (cplay1[i].equals("大")) {
					a3 = 1;
				}
				if (cplay1[i].equals("小")) {
					a4 = 1;
				}
				if (cplay1[i].equals("龙")) {
					a5 = 1;
				}
				if (cplay1[i].equals("虎")) {
					a6 = 1;
				}
				for (int j = 0; j < qiu.length; j++) {
					if (cplay1[i].equals(qiu[j])) {
						a7 = 1;
						b = j;
					}
				}
			}
			money = a1 * oMoney * Double.parseDouble(pv[0]) + a2 * oMoney * Double.parseDouble(pv[1])
					+ a3 * oMoney * Double.parseDouble(pv[2]) + a4 * oMoney * Double.parseDouble(pv[3])
					+ a5 * oMoney * Double.parseDouble(pv[4]) + a6 * oMoney * Double.parseDouble(pv[5])
					+ a7 * oMoney * Double.parseDouble(pv[b]);
			break;
		// 亚军
		case "yj":
			for (int i = 0; i < cplay1.length; i++) {
				if (cplay1[i].equals("单")) {
					a1 = 1;
				}
				if (cplay1[i].equals("双")) {
					a2 = 1;
				}
				if (cplay1[i].equals("大")) {
					a3 = 1;
				}
				if (cplay1[i].equals("小")) {
					a4 = 1;
				}
				if (cplay1[i].equals("龙")) {
					a5 = 1;
				}
				if (cplay1[i].equals("虎")) {
					a6 = 1;
				}
				for (int j = 0; j < qiu.length; j++) {
					if (cplay1[i].equals(qiu[j])) {
						a7 = 1;
						b = j;
					}
				}
			}
			money = a1 * oMoney * Double.parseDouble(pv[0]) + a2 * oMoney * Double.parseDouble(pv[1])
					+ a3 * oMoney * Double.parseDouble(pv[2]) + a4 * oMoney * Double.parseDouble(pv[3])
					+ a5 * oMoney * Double.parseDouble(pv[4]) + a6 * oMoney * Double.parseDouble(pv[5])
					+ a7 * oMoney * Double.parseDouble(pv[b]);
			break;
		// 第3名
		case "d3m":
			for (int i = 0; i < cplay1.length; i++) {
				if (cplay1[i].equals("单")) {
					a1 = 1;
				}
				if (cplay1[i].equals("双")) {
					a2 = 1;
				}
				if (cplay1[i].equals("大")) {
					a3 = 1;
				}
				if (cplay1[i].equals("小")) {
					a4 = 1;
				}
				if (cplay1[i].equals("龙")) {
					a5 = 1;
				}
				if (cplay1[i].equals("虎")) {
					a6 = 1;
				}
				for (int j = 0; j < qiu.length; j++) {
					if (cplay1[i].equals(qiu[j])) {
						a7 = 1;
						b = j;
					}
				}
			}
			money = a1 * oMoney * Double.parseDouble(pv[0]) + a2 * oMoney * Double.parseDouble(pv[1])
					+ a3 * oMoney * Double.parseDouble(pv[2]) + a4 * oMoney * Double.parseDouble(pv[3])
					+ a5 * oMoney * Double.parseDouble(pv[4]) + a6 * oMoney * Double.parseDouble(pv[5])
					+ a7 * oMoney * Double.parseDouble(pv[b]);
			break;
		// 第4名
		case "d4m":
			for (int i = 0; i < cplay1.length; i++) {
				if (cplay1[i].equals("单")) {
					a1 = 1;
				}
				if (cplay1[i].equals("双")) {
					a2 = 1;
				}
				if (cplay1[i].equals("大")) {
					a3 = 1;
				}
				if (cplay1[i].equals("小")) {
					a4 = 1;
				}
				if (cplay1[i].equals("龙")) {
					a5 = 1;
				}
				if (cplay1[i].equals("虎")) {
					a6 = 1;
				}
				for (int j = 0; j < qiu.length; j++) {
					if (cplay1[i].equals(qiu[j])) {
						a7 = 1;
						b = j;
					}
				}
			}
			money = a1 * oMoney * Double.parseDouble(pv[0]) + a2 * oMoney * Double.parseDouble(pv[1])
					+ a3 * oMoney * Double.parseDouble(pv[2]) + a4 * oMoney * Double.parseDouble(pv[3])
					+ a5 * oMoney * Double.parseDouble(pv[4]) + a6 * oMoney * Double.parseDouble(pv[5])
					+ a7 * oMoney * Double.parseDouble(pv[b]);
			break;
		// 第5名
		case "d5m":
			for (int i = 0; i < cplay1.length; i++) {
				if (cplay1[i].equals("单")) {
					a1 = 1;
				}
				if (cplay1[i].equals("双")) {
					a2 = 1;
				}
				if (cplay1[i].equals("大")) {
					a3 = 1;
				}
				if (cplay1[i].equals("小")) {
					a4 = 1;
				}
				if (cplay1[i].equals("龙")) {
					a5 = 1;
				}
				if (cplay1[i].equals("虎")) {
					a6 = 1;
				}
				for (int j = 0; j < qiu.length; j++) {
					if (cplay1[i].equals(qiu[j])) {
						a7 = 1;
						b = j;
					}
				}
			}
			money = a1 * oMoney * Double.parseDouble(pv[0]) + a2 * oMoney * Double.parseDouble(pv[1])
					+ a3 * oMoney * Double.parseDouble(pv[2]) + a4 * oMoney * Double.parseDouble(pv[3])
					+ a5 * oMoney * Double.parseDouble(pv[4]) + a6 * oMoney * Double.parseDouble(pv[5])
					+ a7 * oMoney * Double.parseDouble(pv[b]);
			break;
		// 第6名
		case "d6m":
			for (int i = 0; i < cplay1.length; i++) {
				if (cplay1[i].equals("单")) {
					a1 = 1;
				}
				if (cplay1[i].equals("双")) {
					a2 = 1;
				}
				if (cplay1[i].equals("大")) {
					a3 = 1;
				}
				if (cplay1[i].equals("小")) {
					a4 = 1;
				}
				for (int j = 0; j < qiu1.length; j++) {
					if (cplay1[i].equals(qiu1[j])) {
						a5 = 1;
						b = j;
					}
				}
			}
			money = a1 * oMoney * Double.parseDouble(pv[0]) + a2 * oMoney * Double.parseDouble(pv[1])
					+ a3 * oMoney * Double.parseDouble(pv[2]) + a4 * oMoney * Double.parseDouble(pv[3])
					+ a5 * oMoney * Double.parseDouble(pv[b]);

			break;
		// 第7名
		case "d7m":
			for (int i = 0; i < cplay1.length; i++) {
				if (cplay1[i].equals("单")) {
					a1 = 1;
				}
				if (cplay1[i].equals("双")) {
					a2 = 1;
				}
				if (cplay1[i].equals("大")) {
					a3 = 1;
				}
				if (cplay1[i].equals("小")) {
					a4 = 1;
				}
				for (int j = 0; j < qiu1.length; j++) {
					if (cplay1[i].equals(qiu1[j])) {
						a5 = 1;
						b = j;
					}
				}
			}
			money = a1 * oMoney * Double.parseDouble(pv[0]) + a2 * oMoney * Double.parseDouble(pv[1])
					+ a3 * oMoney * Double.parseDouble(pv[2]) + a4 * oMoney * Double.parseDouble(pv[3])
					+ a5 * oMoney * Double.parseDouble(pv[b]);

			break;
		// 第8名
		case "d8m":
			for (int i = 0; i < cplay1.length; i++) {
				if (cplay1[i].equals("单")) {
					a1 = 1;
				}
				if (cplay1[i].equals("双")) {
					a2 = 1;
				}
				if (cplay1[i].equals("大")) {
					a3 = 1;
				}
				if (cplay1[i].equals("小")) {
					a4 = 1;
				}
				for (int j = 0; j < qiu1.length; j++) {
					if (cplay1[i].equals(qiu1[j])) {
						a5 = 1;
						b = j;
					}
				}
			}
			money = a1 * oMoney * Double.parseDouble(pv[0]) + a2 * oMoney * Double.parseDouble(pv[1])
					+ a3 * oMoney * Double.parseDouble(pv[2]) + a4 * oMoney * Double.parseDouble(pv[3])
					+ a5 * oMoney * Double.parseDouble(pv[b]);

			break;
		// 第9名
		case "d9m":
			for (int i = 0; i < cplay1.length; i++) {
				if (cplay1[i].equals("单")) {
					a1 = 1;
				}
				if (cplay1[i].equals("双")) {
					a2 = 1;
				}
				if (cplay1[i].equals("大")) {
					a3 = 1;
				}
				if (cplay1[i].equals("小")) {
					a4 = 1;
				}
				for (int j = 0; j < qiu1.length; j++) {
					if (cplay1[i].equals(qiu1[j])) {
						a5 = 1;
						b = j;
					}
				}
			}
			money = a1 * oMoney * Double.parseDouble(pv[0]) + a2 * oMoney * Double.parseDouble(pv[1])
					+ a3 * oMoney * Double.parseDouble(pv[2]) + a4 * oMoney * Double.parseDouble(pv[3])
					+ a5 * oMoney * Double.parseDouble(pv[b]);

			break;
		// 第10名
		case "d10m":
			for (int i = 0; i < cplay1.length; i++) {
				if (cplay1[i].equals("单")) {
					a1 = 1;
				}
				if (cplay1[i].equals("双")) {
					a2 = 1;
				}
				if (cplay1[i].equals("大")) {
					a3 = 1;
				}
				if (cplay1[i].equals("小")) {
					a4 = 1;
				}
				for (int j = 0; j < qiu1.length; j++) {
					if (cplay1[i].equals(qiu1[j])) {
						a5 = 1;
						b = j;
					}
				}
			}
			money = a1 * oMoney * Double.parseDouble(pv[0]) + a2 * oMoney * Double.parseDouble(pv[1])
					+ a3 * oMoney * Double.parseDouble(pv[2]) + a4 * oMoney * Double.parseDouble(pv[3])
					+ a5 * oMoney * Double.parseDouble(pv[b]);
			break;
		}
		return money;
	}

	/**
	 * 
	   *   方法名：checkLotterMoney   
	   *   描述：     重庆时时彩中奖金额最多的玩法                  TODO   
	   *   参数：    @param play 下注玩法名称
	   *   参数：    @param cplay1 下注玩法属性
	   *   参数：    @param pv 下注的赔率
	   *   参数：    @param oMoney 单注金额
	   *   参数：    @return 
	 * @return: double
	 */
	public static double checkLotterMoney(String play, String[] cplay1, String[] pv, double oMoney) { // TODO 中奖金额统计
		double money = 0.00;
		String[] qiu2 = { "单", "双", "大", "小", "0", "1", "2", "3", "4", "5", "6", "7", "8", "9" }; // TODO 2fssc
		int a1 = 0;
		int a2 = 0;
		int a3 = 0;
		int a4 = 0;
		int a5 = 0;
		int a6 = 0;
		int a7 = 0;
		int b = 0;
		switch (play) {
		// 总和
		case "zh":
			for (int i = 0; i < cplay1.length; i++) {
				if ("单".equals(cplay1[i])) {
					a1 = 1;
				}
				if ("双".equals(cplay1[i])) {
					a2 = 1;
				}
				if ("大".equals(cplay1[i])) {
					a3 = 1;
				}
				if ("小".equals(cplay1[i])) {
					a4 = 1;
				}
				if ("龙".equals(cplay1[i])) {
					a5 = 1;
				}
				if ("虎".equals(cplay1[i])) {
					a6 = 1;
				}
				if ("和".equals(cplay1[i])) {
					a7 = 1;
				}
				money = a1 * oMoney * Double.parseDouble(pv[0]) + a2 * oMoney * Double.parseDouble(pv[1])
						+ a3 * oMoney * Double.parseDouble(pv[2]) + a4 * oMoney * Double.parseDouble(pv[3])
						+ a5 * oMoney * Double.parseDouble(pv[4]) + a6 * oMoney * Double.parseDouble(pv[5])
						+ a7 * oMoney * Double.parseDouble(pv[6]);
			}
			break;

		// 第1球
		case "d1q":
			for (int i = 0; i < cplay1.length; i++) {
				if (cplay1[i].equals("单")) {
					a1 = 1;
				}
				if (cplay1[i].equals("双")) {
					a2 = 1;
				}
				if (cplay1[i].equals("大")) {
					a3 = 1;
				}
				if (cplay1[i].equals("小")) {
					a4 = 1;
				}
				for (int j = 0; j < qiu2.length; j++) {
					if (cplay1[i].equals(qiu2[j])) {
						a5 = 1;
						b = j;
					}
				}
			}
			money = a1 * oMoney * Double.parseDouble(pv[0]) + a2 * oMoney * Double.parseDouble(pv[1])
					+ a3 * oMoney * Double.parseDouble(pv[2]) + a4 * oMoney * Double.parseDouble(pv[3])
					+ a5 * oMoney * Double.parseDouble(pv[b]);
			break;

		// 第2球
		case "d2q":
			for (int i = 0; i < cplay1.length; i++) {
				if (cplay1[i].equals("单")) {
					a1 = 1;
				}
				if (cplay1[i].equals("双")) {
					a2 = 1;
				}
				if (cplay1[i].equals("大")) {
					a3 = 1;
				}
				if (cplay1[i].equals("小")) {
					a4 = 1;
				}
				for (int j = 0; j < qiu2.length; j++) {
					if (cplay1[i].equals(qiu2[j])) {
						a5 = 1;
						b = j;
					}
				}
			}
			money = a1 * oMoney * Double.parseDouble(pv[0]) + a2 * oMoney * Double.parseDouble(pv[1])
					+ a3 * oMoney * Double.parseDouble(pv[2]) + a4 * oMoney * Double.parseDouble(pv[3])
					+ a5 * oMoney * Double.parseDouble(pv[b]);
			break;
		// 第3球
		case "d3q":
			for (int i = 0; i < cplay1.length; i++) {
				if (cplay1[i].equals("单")) {
					a1 = 1;
				}
				if (cplay1[i].equals("双")) {
					a2 = 1;
				}
				if (cplay1[i].equals("大")) {
					a3 = 1;
				}
				if (cplay1[i].equals("小")) {
					a4 = 1;
				}
				for (int j = 0; j < qiu2.length; j++) {
					if (cplay1[i].equals(qiu2[j])) {
						a5 = 1;
						b = j;
					}
				}
			}
			money = a1 * oMoney * Double.parseDouble(pv[0]) + a2 * oMoney * Double.parseDouble(pv[1])
					+ a3 * oMoney * Double.parseDouble(pv[2]) + a4 * oMoney * Double.parseDouble(pv[3])
					+ a5 * oMoney * Double.parseDouble(pv[b]);
			break;
		// 第4球
		case "d4q":
			for (int i = 0; i < cplay1.length; i++) {
				if (cplay1[i].equals("单")) {
					a1 = 1;
				}
				if (cplay1[i].equals("双")) {
					a2 = 1;
				}
				if (cplay1[i].equals("大")) {
					a3 = 1;
				}
				if (cplay1[i].equals("小")) {
					a4 = 1;
				}
				for (int j = 0; j < qiu2.length; j++) {
					if (cplay1[i].equals(qiu2[j])) {
						a5 = 1;
						b = j;
					}
				}
			}
			money = a1 * oMoney * Double.parseDouble(pv[0]) + a2 * oMoney * Double.parseDouble(pv[1])
					+ a3 * oMoney * Double.parseDouble(pv[2]) + a4 * oMoney * Double.parseDouble(pv[3])
					+ a5 * oMoney * Double.parseDouble(pv[b]);
			break;
		case "d5q":
			// 第5球
			for (int i = 0; i < cplay1.length; i++) {
				if (cplay1[i].equals("单")) {
					a1 = 1;
				}
				if (cplay1[i].equals("双")) {
					a2 = 1;
				}
				if (cplay1[i].equals("大")) {
					a3 = 1;
				}
				if (cplay1[i].equals("小")) {
					a4 = 1;
				}
				for (int j = 0; j < qiu2.length; j++) {
					if (cplay1[i].equals(qiu2[j])) {
						a5 = 1;
						b = j;
					}
				}
			}
			money = a1 * oMoney * Double.parseDouble(pv[0]) + a2 * oMoney * Double.parseDouble(pv[1])
					+ a3 * oMoney * Double.parseDouble(pv[2]) + a4 * oMoney * Double.parseDouble(pv[3])
					+ a5 * oMoney * Double.parseDouble(pv[b]);

			break;
		case "q3":
			// 前三
			for (int i = 0; i < cplay1.length; i++) {
				if ("豹子".equals(cplay1[i])) {
					a1 = 1;
				}
				if ("顺子".equals(cplay1[i])) {
					a2 = 1;
				}
				if ("对子".equals(cplay1[i])) {
					a3 = 1;
				}
				if ("半顺".equals(cplay1[i])) {
					a4 = 1;
				}
				if ("杂六".equals(cplay1[i])) {
					a5 = 1;
				}
			}
			money = a1 * oMoney * Double.parseDouble(pv[0]) + a2 * oMoney * Double.parseDouble(pv[1])
					+ a3 * oMoney * Double.parseDouble(pv[2]) + a4 * oMoney * Double.parseDouble(pv[3])
					+ a5 * oMoney * Double.parseDouble(pv[4]);
			break;
		case "z3":
			// 中三
			for (int i = 0; i < cplay1.length; i++) {
				if ("豹子".equals(cplay1[i])) {
					a1 = 1;
				}
				if ("顺子".equals(cplay1[i])) {
					a2 = 1;
				}
				if ("对子".equals(cplay1[i])) {
					a3 = 1;
				}
				if ("半顺".equals(cplay1[i])) {
					a4 = 1;
				}
				if ("杂六".equals(cplay1[i])) {
					a5 = 1;
				}
			}
			money = a1 * oMoney * Double.parseDouble(pv[0]) + a2 * oMoney * Double.parseDouble(pv[1])
					+ a3 * oMoney * Double.parseDouble(pv[2]) + a4 * oMoney * Double.parseDouble(pv[3])
					+ a5 * oMoney * Double.parseDouble(pv[4]);
			break;
		case "h3":
			// 后三
			for (int i = 0; i < cplay1.length; i++) {
				if ("豹子".equals(cplay1[i])) {
					a1 = 1;
				}
				if ("顺子".equals(cplay1[i])) {
					a2 = 1;
				}
				if ("对子".equals(cplay1[i])) {
					a3 = 1;
				}
				if ("半顺".equals(cplay1[i])) {
					a4 = 1;
				}
				if ("杂六".equals(cplay1[i])) {
					a5 = 1;
				}
			}
			money = a1 * oMoney * Double.parseDouble(pv[0]) + a2 * oMoney * Double.parseDouble(pv[1])
					+ a3 * oMoney * Double.parseDouble(pv[2]) + a4 * oMoney * Double.parseDouble(pv[3])
					+ a5 * oMoney * Double.parseDouble(pv[4]);
			break;

		case "q2zhix0":
			// 前二直选
			money = oMoney * Double.parseDouble(pv[0]);
			break;
		case "q2zhix1":
			// 前二直选
			money = oMoney * Double.parseDouble(pv[0]);
			break;
		case "h2zhix0":
			// 后二直选
			money = oMoney * Double.parseDouble(pv[0]);
			break;
		case "h2zhix1":
			// 后二直选
			money = oMoney * Double.parseDouble(pv[0]);
			break;
		case "q3zhix0":
			// 前三直选
			money = oMoney * Double.parseDouble(pv[0]);
			break;
		case "q3zhix1":
			// 前三直选
			money = oMoney * Double.parseDouble(pv[0]);
			break;
		case "q3zhix2":
			// 前三直选
			money = oMoney * Double.parseDouble(pv[0]);
			break;
		case "z3zhix0":
			// 中三直选
			money = oMoney * Double.parseDouble(pv[0]);
			break;
		case "z3zhix1":
			// 中三直选
			money = oMoney * Double.parseDouble(pv[0]);
			break;
		case "z3zhix2":
			// 中三直选
			money = oMoney * Double.parseDouble(pv[0]);
			break;
		case "h3zhix0":
			// 后三直选

			money = oMoney * Double.parseDouble(pv[0]);
			break;
		case "h3zhix1":
			// 后三直选

			money = oMoney * Double.parseDouble(pv[0]);
			break;
		case "h3zhix2":
			// 后三直选

			money = oMoney * Double.parseDouble(pv[0]);
			break;
		case "q2zx":
			// 前二组选
			money = oMoney * Double.parseDouble(pv[0]);
			break;
		case "h2zx":
			// 后二组选
			money = oMoney * Double.parseDouble(pv[0]);
			break;
		case "q3z6":
			money = oMoney * Double.parseDouble(pv[0]);
			break;
		case "z3z6":
			// 中三组六
			money = oMoney * Double.parseDouble(pv[0]);
			break;
		case "h3z6":
			// 后三组六
			money = oMoney * Double.parseDouble(pv[0]);
			break;
		case "q3z3":
			// 前三组三
			money = oMoney * Double.parseDouble(pv[0]);
			break;
		case "z3z3":
			// 中三组三
			money = oMoney * Double.parseDouble(pv[0]);
			break;
		case "h3z3":
			// 后三组三
			money = oMoney * Double.parseDouble(pv[0]);
			break;
		}
		return money;
	}

	/**
	 * 
	   *   方法名：checkLotterMoney2   
	   *   描述：     三分快三中奖金额最多的玩法                  TODO   
	   *   参数：    @param play 下注玩法名称
	   *   参数：    @param cplay1 下注玩法属性
	   *   参数：    @param pv 下注的赔率
	   *   参数：    @param oMoney 单注金额
	   *   参数：    @return 
	 * @return: double
	 */
	public static double checkLotterMoney2(String play, String[] cplay1, String[] pv, double oMoney) { // TODO 中奖金额统计
		double money = 0.00;
		int a1 = 0;
		int a2 = 0;
		int a3 = 0;
		int a4 = 0;
		int a5 = 0;
		int b = 0;
		String[] qiu3 = { "11", "22", "33", "44", "55", "66" };
		String[] qiu4 = { "111", "222", "333", "444", "555", "666", };
		String[] qiu5 = { "3", "4", "5", "6", "7", "8", "9", "10", "11", "12", "13", "14", "15", "16", "17", "18", "大",
				"小", "单", "双" };
		switch (play) {
		// 总和
		case "c1gh":
			// 猜一个号
			money = oMoney * Double.parseDouble(pv[0]);
			break;
		case "slhtx":
			// 三连号通选
			money = oMoney * Double.parseDouble(pv[0]);
			break;
		case "ethfx":
			// 二同号复选
			for (int i = 0; i < cplay1.length; i++) {
				for (int j = 0; j < qiu3.length; j++) {
					if (cplay1[i].equals(qiu3[j])) {
						a1 = 1;
						b = j;
					}
				}
			}
			money = a1 * oMoney * Double.parseDouble(pv[b]);
			break;
		case "ethdx1":
		case "ethdx2":
			// 二同号单选
			for (int i = 0; i < cplay1.length; i++) {
				for (int j = 0; j < cplay1.length; j++) {
					a1 = 1;
				}
			}
			money = a1 * oMoney * Double.parseDouble(pv[0]);
			break;
		case "ebth":
			// 二不同号
			money = a1 * oMoney * Double.parseDouble(pv[0]);
			break;
		case "ebthdt1":
		case "ebthdt2":
			// 二不同号胆拖
			money = oMoney * Double.parseDouble(pv[0]);
			break;
		case "sthtx":
			// 三同号通选
			money = oMoney * Double.parseDouble(pv[0]);
			break;
		case "sthdx":
			// 三同号单选
			for (int i = 0; i < cplay1.length; i++) {
				for (int j = 0; j < qiu4.length; j++) {
					if (cplay1[i].equals(qiu4[j])) {
						a1 = 1;
						b = j;
					}
				}
			}
			money = a1 * oMoney * Double.parseDouble(pv[b]);
			break;
		case "sbth":
			// 三不同号

			money = oMoney * Double.parseDouble(pv[0]);  
			break;
		case "xt":
			// 形态
			for (int i = 0; i < cplay1.length; i++) {
				if ("豹子".equals(cplay1[i])) {
					a1 = 1;
				} else if ("顺子".equals(cplay1[i])) {
					a2 = 1;
				} else if ("对子".equals(cplay1[i])) {
					a3 = 1;
				} else if ("半顺".equals(cplay1[i])) {
					a4 = 1;
				} else if ("杂六".equals(cplay1[i])) {
					a5 = 1;
				}
			}
			money = a1 * oMoney * Double.parseDouble(pv[0]) + a2 * oMoney * Double.parseDouble(pv[1])
					+ a3 * oMoney * Double.parseDouble(pv[2]) + a3 * oMoney * Double.parseDouble(pv[3])
					+ a5 * oMoney * Double.parseDouble(pv[4]);
			break;
		case "zh":
			// 总和-和值
			for (int i = 0; i < cplay1.length; i++) {
				for (int j = 0; j < qiu5.length; j++) {
					if (cplay1[i].equals(qiu5[j])) {
						a1 = 1;
						b = j;
					}
					if (cplay1[i].equals("大")) {
						a2 = 1;
					}
					if (cplay1[i].equals("小")) {
						a3 = 1;
					}
					if (cplay1[i].equals("单")) {
						a4 = 1;
					}
					if (cplay1[i].equals("双")) {
						a5 = 1;
					}
				}
			}
			money = a1 * oMoney * Double.parseDouble(pv[b]) + a2 * oMoney * Double.parseDouble(pv[16])
					+ a3 * oMoney * Double.parseDouble(pv[17]) + a4 * oMoney * Double.parseDouble(pv[18])
					+ a5 * oMoney * Double.parseDouble(pv[19]);
			break;
		}
		return money;
	}

	/**
	 * 
	   *   方法名：checkLotterMoney1   
	   *   描述：     5分六合彩中奖金额最多的玩法                  TODO   
	   *   参数：    @param play 下注玩法名称
	   *   参数：    @param cplay1 下注玩法属性
	   *   参数：    @param pv 下注的赔率
	   *   参数：    @param oMoney 单注金额
	   *   参数：    @return 
	 * @return: double
	 */
	public static double checkLotterMoney3(String cplay, String[] cplay1, String[] pv, Double oMoney) {
		double money = 0.00;
		int a1 = 0;
		int a2 = 0;
		int a3 = 0;
		int a4 = 0;
		int a5 = 0;
		int b = 0;
		/** tmab */
		String[] tm = { "01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12", "13", "14",
				"15", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25", "26", "27", "28", "29", "30",
				"31", "32", "33", "34", "35", "36", "37", "38", "39", "40", "41", "42", "43", "44", "45", "46",
				"47", "48", "49" };
		/** 生肖 1 */
		CheckOrder orc = new CheckOrder();
		Map<String, Object> map = orc.attribute1();
		String[] sx1 = (String[]) map.get("attr");
		String[][] sx2 = (String[][]) map.get("content");
		/** 总和合数 */
		
		
		String[][][] jqyss = new String[4][6][5];
		List<Integer> idss = new ArrayList<Integer>();
		String[] sxss = { "鼠", "牛", "虎", "兔", "龙", "蛇", "马", "羊", "猴", "鸡", "狗", "猪" };
		for (int i10 = 0; i10 < sxss.length; i10++) {
			for (int j10 = 0; j10 < sx1.length; j10++) {
				if (sxss[i10].equals(sx1[j10])) {
					idss.add(j10);
				}
			}
		}

		String[] jqysss = { "家肖", "野肖", "天肖", "地肖" };
		/** jiax */
		jqyss[0][0] = sx2[idss.get(1)];
		jqyss[0][1] = sx2[idss.get(6)];
		jqyss[0][2] = sx2[idss.get(7)];
		jqyss[0][3] = sx2[idss.get(9)];
		jqyss[0][4] = sx2[idss.get(10)];
		jqyss[0][5] = sx2[idss.get(11)];
		/** yex */
		jqyss[1][0] = sx2[idss.get(0)];
		jqyss[1][1] = sx2[idss.get(2)];
		jqyss[1][2] = sx2[idss.get(3)];
		jqyss[1][3] = sx2[idss.get(4)];
		jqyss[1][4] = sx2[idss.get(5)];
		jqyss[1][5] = sx2[idss.get(8)];
		/** tianx */
		jqyss[2][0] = sx2[idss.get(1)];
		jqyss[2][1] = sx2[idss.get(3)];
		jqyss[2][2] = sx2[idss.get(4)];
		jqyss[2][3] = sx2[idss.get(6)];
		jqyss[2][4] = sx2[idss.get(8)];
		jqyss[2][5] = sx2[idss.get(11)];
		/** dix */
		jqyss[3][0] = sx2[idss.get(0)];
		jqyss[3][1] = sx2[idss.get(2)];
		jqyss[3][2] = sx2[idss.get(5)];
		jqyss[3][3] = sx2[idss.get(7)];
		jqyss[3][4] = sx2[idss.get(9)];
		jqyss[3][5] = sx2[idss.get(10)];
		/** 头数 */
		String[] t1 = { "0头", "1头", "2头", "3头", "4头" };
		String[][] t2 = { { "01", "02", "03", "04", "05", "06", "07", "08", "09" },
				{ "10", "11", "12", "13", "14", "15", "16", "17", "18", "19" },
				{ "20", "21", "22", "23", "24", "25", "26", "27", "28", "29" },
				{ "30", "31", "32", "33", "34", "35", "36", "37", "38", "39" },
				{ "40", "41", "42", "43", "44", "45", "46", "47", "48", "49" } };
		/** 尾数 */
		String[] w1 = { "0尾", "1尾", "2尾", "3尾", "4尾", "5尾", "6尾", "7尾", "8尾", "9尾" };
		String[][] w2 = { { "10", "20", "30", "40", "50" }, { "01", "11", "21", "31", "41" },
				{ "02", "12", "22", "32", "42" }, { "03", "13", "23", "33", "43" },
				{ "04", "14", "24", "34", "44" }, { "05", "15", "25", "35", "45" },
				{ "06", "16", "26", "36", "46" }, { "07", "17", "27", "37", "47" },
				{ "08", "18", "28", "38", "48" }, { "09", "19", "29", "39", "49" } };
		String[] w3 = { "0", "1", "2", "3", "4", "5", "6", "7", "8", "9" };
		/** 五行 */
		Map<String, Object> maps = orc.attribute2();
		String[] x1 = (String[]) maps.get("attrs");
		String[][] x2 = (String[][]) maps.get("contents");
		/** 合数 */
		// int hss = (d[6] % 100) / 10 + d[6] % 10;
		/** 总肖 */
		String[] z1 = { "2肖", "3肖", "4肖", "5肖", "6肖", "7肖" };
		/** 波色-红波-蓝波-绿波 */
		String[] b1 = { "红", "蓝", "绿" };
		/** 半波 */
		String[] bb1 = { "红大", "红小", "红单", "红双", "蓝大", "蓝小", "蓝单", "蓝双", "绿大", "绿小", "绿单", "绿双" };
		/** 半半波 */
		String[] bbb1 = { "红大单", "红大双", "红小单", "红小双", "蓝大单", "蓝大双", "蓝小单", "蓝小双", "绿大单", "绿大双", "绿小单", "绿小双" };
		switch (cplay) {
		// 特码A
		case "tma":
			for (int i = 0; i < cplay1.length; i++) {
				for (int j = 0; j < tm.length; j++) {
					if (tm[j].equals(cplay1[i])) {
							a1 = 1;
							b = j;
					}
				}
			}
			money = a1 * oMoney * Double.parseDouble(pv[b]);
			break;
			
		// 特码B
		case "tmb":
			for (int i = 0; i < cplay1.length; i++) {
				for (int j = 0; j < tm.length; j++) {
					if (tm[j].equals(cplay1[i])) {
							a1 = 1;
							b = j;
					}
				}
			}
			money = a1 * oMoney * Double.parseDouble(pv[b]);
			break;
			
		// 特码生肖
		case "tmsx":
			for (int i = 0; i < sx1.length; i++) {
				for (int j = 0; j < sx2[i].length; j++) {
					for (int k = 0; k < cplay1.length; k++) {
						if (sx1[i].equals(cplay1[k])) {
							a1 = 1;
							b = i;
						}
					}
				}
			}
			money = a1 * oMoney * Double.parseDouble(pv[b]);
			break;
			
		// 大小单双
		case "dxds":
			for (int i = 0; i < cplay1.length; i++) {
				if ( cplay1[i].equals("单")) {
					a1=1;
				}
				if (cplay1[i].equals("双")) {
					a2=1;
				}
				if (cplay1[i].equals("大")) {
					a3=3;
				}
				if (cplay1[i].equals("小")) {
					a4=4;
				}
			}
			money = a1 * oMoney * Double.parseDouble(pv[0]) + a2 * oMoney * Double.parseDouble(pv[1])
					+ a3 * oMoney * Double.parseDouble(pv[2]) + a4 * oMoney * Double.parseDouble(pv[3]);
			break;
			
		// 家禽野兽
		case "jqys":
			for (int i = 0; i < jqyss.length; i++) {
				for (int j = 0; j < jqyss[i].length; j++) {
					for (int k = 0; k < jqyss[i][j].length; k++) {
						for (int m = 0; m < cplay1.length; m++) {
								if (jqysss[i].equals(cplay1[m])
										&& cplay1[m].equals("家肖")) {
									a1 = 1;
								}
								if (jqysss[i].equals(cplay1[m])
										&& cplay1[m].equals("野肖")) {
									a2 = 1;
								}
								if (jqysss[i].equals(cplay1[m])
										&& cplay1[m].equals("天肖")) {
									a3 = 1;
								}
								if (jqysss[i].equals(cplay1[m])
										&& cplay1[m].equals("地肖")) {
									a4 = 1;
								}
							}
						}
					}
			money = a1 * oMoney * Double.parseDouble(pv[0]) + a2 * oMoney * Double.parseDouble(pv[1])
					+ a3 * oMoney * Double.parseDouble(pv[2]) + a4 * oMoney * Double.parseDouble(pv[3]);
		}
		break;
			
		// 头数
		case "ts":
			for (int i = 0; i < t2.length;i++) {
					for (int k = 0; k < t1.length; k++) {
						for (int m = 0; m < cplay1.length; m++) {
							if (t1[k].equals(cplay1[m]) && (t1[i].equals(cplay1[m]))) {
								b = i;
								a1=1;
							}
						}
					}
			money = a1 * oMoney * Double.parseDouble(pv[b]);
		}
		break;
			
		// 尾数
		case "ws":
			for (int i = 0; i < w2.length; i++) {
				for (int j = 0; j < w2[i].length; j++) {
					for (int k = 0; k < w1.length; k++) {
						for (int m = 0; m < cplay1.length; m++) {
									if (w1[k].equals(cplay1[m])) {
										b = i;
										a1 = 1;
									}
									if (cplay1[m].equals("大")) {
											a2 = 1;
									}
									if (cplay1[m].equals("小")) {
											a3 = 1;
									}
									if (cplay1[m].equals("单")) {
											a4 = 1;
									}
									if (cplay1[m].equals("双")) {
											a5 = 1;
									}
								}
							}
				}
			money = a1 * oMoney * Double.parseDouble(pv[b]) + a2 * oMoney * Double.parseDouble(pv[10])
					+ a3 * oMoney * Double.parseDouble(pv[11]) + a4 * oMoney * Double.parseDouble(pv[12])
					+ a5 * oMoney * Double.parseDouble(pv[13]);
		}
		break;
		
		// 五行
		case "wx":
			for (int i = 0; i < x1.length; i++) {
				for (int j = 0; j < x2[i].length; j++) {
					for (int k = 0; k < cplay1.length; k++) {
						if (cplay1[k].equals(x1[i])) {
							a1 = 1;
							b = i;
						}
					}
				}
			}
			money = a1 * oMoney * Double.parseDouble(pv[b]);
		break;
		
		// 总和
		case "zh" :
			for (int i = 0; i < cplay1.length; i++) {
				if (cplay1[i].equals("单")) {
						a1 = 1;
				}
				if (cplay1[i].equals("双")) {
						a2 = 1;
				}
				if (cplay1[i].equals("大")) {
						a3 = 1;
				}
				if (cplay1[i].equals("小")) {
						a4 = 1;
				}
			}
			money = a1 * oMoney * Double.parseDouble(pv[0]) + a2 * oMoney * Double.parseDouble(pv[1])
					+ a3 * oMoney * Double.parseDouble(pv[2]) + a4 * oMoney * Double.parseDouble(pv[3]);
		break;
		
		// 合数
		case "hs":
			for (int i = 0; i < cplay1.length; i++) {
				if (cplay1[i].equals("单")) {
						a1 = 1;
				}
				if (cplay1[i].equals("双")) {
						a2 = 1;
				}
				if (cplay1[i].equals("大")) {
						a3 = 1;
				}
				if (cplay1[i].equals("小")) {
						a4 = 1;
				}
			}
			money = a1 * oMoney * Double.parseDouble(pv[0]) + a2 * oMoney * Double.parseDouble(pv[1])
					+ a3 * oMoney * Double.parseDouble(pv[2]) + a4 * oMoney * Double.parseDouble(pv[3]);
		break;
		
		// 独平
		case "dp":
			for (int i = 0; i < cplay1.length; i++) {
				for (int j = 0; j < tm.length; j++) {
						if (tm[j].equals(cplay1[i])) {
							a1 = 1;
						}
					}
				}
			money = a1 * oMoney * Double.parseDouble(pv[0]);
		break;
		
		// 平二中二
		case "p2z2":
			for (int i = 0; i < cplay1.length; i++) {
					b++;
			}
			if (b > 1) {
				a1 = 1;
			}
			money = a1 * oMoney * Double.parseDouble(pv[0]);
		break;
		
		// 平三中三
		case "p3z3":
			for (int i = 0; i < cplay1.length; i++) {
				b++;
			}
			if (b > 2) {
				a1 = 1;
			}
		money = a1 * oMoney * Double.parseDouble(pv[0]);
		break;
		
		// 平三中二
		case "p3z2":
			for (int i = 0; i < cplay1.length; i++) {
				b++;
			}
			if (b > 1) {
				a1 = 1;
			}
		money = a1 * oMoney * Double.parseDouble(pv[0]);
		break;
		
		// 四肖中特
		case "sxzt":
			for (int i = 0; i < sx1.length; i++) {
				for (int j = 0; j < sx2[i].length; j++) {
					for (int k = 0; k < cplay1.length; k++) {
						if (cplay1[k].equals(sx1[i])) {
							a1 = 1;
							b = i;
						}
					}
				}
			}
			money = a1 * oMoney * Double.parseDouble(pv[b]);
		break;
		
		// 五肖中特
		case "wxzt":
			for (int i = 0; i < sx1.length; i++) {
				for (int j = 0; j < sx2[i].length; j++) {
					for (int k = 0; k < cplay1.length; k++) {
						if (cplay1[k].equals(sx1[i])) {
							a1 = 1;
							b = i;
						}
					}
				}
			}
			money = a1 * oMoney * Double.parseDouble(pv[b]);
		break;
		
		// 六肖中特
		case "lxzt":
			for (int i = 0; i < sx1.length; i++) {
				for (int j = 0; j < sx2[i].length; j++) {
					for (int k = 0; k < cplay1.length; k++) {
						if (cplay1[k].equals(sx1[i])) {
							a1 = 1;
							b = i;
						}
					}
				}
			}
			money = a1 * oMoney * Double.parseDouble(pv[b]);
			break;
			
		// 平特1肖
		case "pt1x":	
			List<Integer> list1 = new ArrayList<Integer>();
			List<Double> list2 = new ArrayList<Double>();
			for (int i = 0; i < sx1.length; i++) {
				for (int j = 0; j < sx2[i].length; j++) {
					for (int k = 0; k < cplay1.length; k++) {
							if (cplay1[k].equals(sx1[i])) {// i就是data中对应的生肖
								a1 = 1;
								b = i;
								list1.add(b);
							}
						}
					}
				}
			for (int i = 0; i < list1.size() - 1; i++) {
				for (int j = list1.size() - 1; j > i; j--) {
					if (list1.get(j).equals(list1.get(i))) {
						list1.remove(j);
					}
				}
			}
			for (int i = 0; i < list1.size(); i++) {
				Double c1 = Double.parseDouble(pv[list1.get(i)]);
				list2.add(c1);
			}
			try {
				Double c3 = Collections.min(list2);// 获取最小值 本命肖
				Double c4 = Collections.max(list2);// 获取最大值 中奖的 二选1
				if (list2.size() > 1) {
					if (c3 != null) {
						money = a1 * oMoney * c3;
					} else {
						money = a1 * oMoney * c4;
					}
				} else {
					money = a1 * oMoney * Double.parseDouble(pv[list1.get(0)]);
				}
			} catch (Exception e) {
				money = a1 * oMoney * Double.parseDouble(pv[list1.get(0)]);
			}
		break;
		
		// 平特2肖
		case "pt2x":
			List<Integer> list3 = new ArrayList<Integer>();
			List<Double> list4 = new ArrayList<Double>();
			for (int i = 0; i < sx1.length; i++) {
				for (int j = 0; j < sx2[i].length; j++) {
					for (int k = 0; k < cplay1.length; k++) {
							if (cplay1[k].equals(sx1[i])) {
								b = i;
								list3.add(b);
							}
						}
					}
				}
			for (int i = 0; i < list3.size() - 1; i++) {
				for (int j = list3.size() - 1; j > i; j--) {
					if (list3.get(j).equals(list3.get(i))) {
						list3.remove(j);
					}
				}
			}
			if (list3.size() > 1) {
				a1 = 1;
			}
			for (int i = 0; i < list3.size(); i++) {
				Double c1 = Double.parseDouble(pv[list3.get(i)]);
				list4.add(c1);
			}
			try {
				Double c3 = Collections.min(list4);
				Double c4 = Collections.max(list4);
				if (list4.size() > 1) {
					if (c3 != null) {
						money = a1 * oMoney * c3;
					} else {
						money = a1 * oMoney * c4;
					}
				} else {
					money = a1 * oMoney * Double.parseDouble(pv[list3.get(0)]);
				}
			} catch (Exception e) {
				money = a1 * oMoney * Double.parseDouble(pv[list3.get(0)]);
			}
		break;
		
		// 平特3肖
		case "pt3x":
			List<Integer> list5 = new ArrayList<Integer>();
			List<Double> list6 = new ArrayList<Double>();
			for (int i = 0; i < sx1.length; i++) {
				for (int j = 0; j < sx2[i].length; j++) {
					for (int k = 0; k < cplay1.length; k++) {
							if (cplay1[k].equals(sx1[i])) {
								b = i;
								list5.add(b);
							}
						}
					}
				}
			for (int i = 0; i < list5.size() - 1; i++) {
				for (int j = list5.size() - 1; j > i; j--) {
					if (list5.get(j).equals(list5.get(i))) {
						list5.remove(j);
					}
				}
			}
			if (list5.size() > 2) {
				a1 = 1;
			}
			for (int i = 0; i < list5.size(); i++) {
				Double c1 = Double.parseDouble(pv[list5.get(i)]);
				list6.add(c1);
			}
			try {
				Double c3 = Collections.min(list6);
				Double c4 = Collections.max(list6);
				if (list6.size() > 1) {
					if (c3 != null) {
						money = a1 * oMoney * c3;
					} else {
						money = a1 * oMoney * c4;
					}
				} else {
					money = a1 * oMoney * Double.parseDouble(pv[list5.get(0)]);
				}
			} catch (Exception e) {
				money = a1 * oMoney * Double.parseDouble(pv[list5.get(0)]);
			}
			break;
			
		// 平特4肖
		case "pt4x":
			List<Integer> list7 = new ArrayList<Integer>();
			List<Double> list8 = new ArrayList<Double>();
			for (int i = 0; i < sx1.length; i++) {
				for (int j = 0; j < sx2[i].length; j++) {
					for (int k = 0; k < cplay1.length; k++) {
							if (cplay1[k].equals(sx1[i])) {
								b = i;
								list7.add(b);
							}
						}
					}
				}
			for (int i = 0; i < list7.size() - 1; i++) {
				for (int j = list7.size() - 1; j > i; j--) {
					if (list7.get(j).equals(list7.get(i))) {
						list7.remove(j);
					}
				}
			}
			if (list7.size() > 3) {
				a1 = 1;
			}
			for (int i = 0; i < list7.size(); i++) {
				Double c1 = Double.parseDouble(pv[list7.get(i)]);
				list8.add(c1);
			}
			try {
				Double c3 = Collections.min(list8);
				Double c4 = Collections.max(list8);
				if (list8.size() > 1) {
					if (c3 != null) {
						money = a1 * oMoney * c3;
					} else {
						money = a1 * oMoney * c4;
					}
				} else {
					money = a1 * oMoney * Double.parseDouble(pv[list7.get(0)]);
				}
			} catch (Exception e) {
				money = a1 * oMoney * Double.parseDouble(pv[list7.get(0)]);
			}
		break;
		
		// 平特1尾
		case "pt1w":
			List<Integer> list9 = new ArrayList<Integer>();
			List<Double> list10 = new ArrayList<Double>();
			for (int i = 0; i < w3.length; i++) {
				for (int j = 0; j < w2[i].length; j++) {
					for (int k = 0; k < cplay1.length; k++) {
							if (cplay1[k].equals(w3[i])) {
								a1 = 1;
								b = i;
								list9.add(b);
							}
						}
					}
				}
			for (int i = 0; i < list9.size() - 1; i++) {
				for (int j = list9.size() - 1; j > i; j--) {
					if (list9.get(j).equals(list9.get(i))) {
						list9.remove(j);
					}
				}
			}
			for (int i = 0; i < list9.size(); i++) {
				Double c1 = Double.parseDouble(pv[list9.get(i)]);
				list10.add(c1);
			}
			try {
				Double c3 = Collections.max(list10);
				Double c4 = Collections.min(list10);
				if (list10.size() > 1) {
					if (c3 != null) {
						money = a1 * oMoney * c3;
					} else {
						money = a1 * oMoney * c4;
					}
				} else {
					money = a1 * oMoney * Double.parseDouble(pv[list9.get(0)]);
				}
			} catch (Exception e) {
				money = a1 * oMoney * Double.parseDouble(pv[list9.get(0)]);
			}
		break;
		
		// 平特2尾
		case "pt2w":
			List<Integer> list11 = new ArrayList<Integer>();
			List<Double> list12 = new ArrayList<Double>();
			for (int i = 0; i < w3.length; i++) {
				for (int j = 0; j < w2[i].length; j++) {
					for (int k = 0; k < cplay1.length; k++) {
							if (cplay1[k].equals(w3[i])) {
								b = i;
								list11.add(b);
							}
						}
					}
				}
			for (int i = 0; i < list11.size() - 1; i++) {
				for (int j = list11.size() - 1; j > i; j--) {
					if (list11.get(j).equals(list11.get(i))) {
						list11.remove(j);
					}
				}
			}
			if (list11.size() > 1) {
				a1 = 1;
			}
			for (int i = 0; i < list11.size(); i++) {
				Double c1 = Double.parseDouble(pv[list11.get(i)]);
				list12.add(c1);
			}
			try {
				Double c3 = Collections.max(list12);
				Double c4 = Collections.min(list12);
				if (list12.size() > 1) {
					if (c3 != null) {
						money = a1 * oMoney * c3;
					} else {
						money = a1 * oMoney * c4;
					}
				} else {
					money = a1 * oMoney * Double.parseDouble(pv[list11.get(0)]);
				}
			} catch (Exception e) {
				money = a1 * oMoney * Double.parseDouble(pv[list11.get(0)]);
			}
			break;
			
		// 平特3尾
		case "pt3w":
			List<Integer> list13 = new ArrayList<Integer>();
			List<Double> list14 = new ArrayList<Double>();
			for (int i = 0; i < w3.length; i++) {
				for (int j = 0; j < w2[i].length; j++) {
					for (int k = 0; k < cplay1.length; k++) {
							if (cplay1[k].equals(w3[i])) {
								b = i;
								list13.add(b);
							}
						}
					}
				}
			for (int i = 0; i < list13.size() - 1; i++) {
				for (int j = list13.size() - 1; j > i; j--) {
					if (list13.get(j).equals(list13.get(i))) {
						list13.remove(j);
					}
				}
			}
			if (list13.size() > 2) {
				a1 = 1;
			}
			for (int i = 0; i < list13.size(); i++) {
				Double c1 = Double.parseDouble(pv[list13.get(i)]);
				list14.add(c1);
			}
			try {
				Double c3 = Collections.max(list14);
				Double c4 = Collections.min(list14);
				if (list14.size() > 1) {
					if (c3 != null) {
						money = a1 * oMoney * c3;
					} else {
						money = a1 * oMoney * c4;
					}
				} else {
					money = a1 * oMoney * Double.parseDouble(pv[list13.get(0)]);
				}
			} catch (Exception e) {
				money = a1 * oMoney * Double.parseDouble(pv[list13.get(0)]);
			}
		break;
		
		// 平特4尾
		case "pt4w":
			List<Integer> list15 = new ArrayList<Integer>();
			List<Double> list16 = new ArrayList<Double>();
			for (int i = 0; i < w3.length; i++) {
				for (int j = 0; j < w2[i].length; j++) {
					for (int k = 0; k < cplay1.length; k++) {
							if (cplay1[k].equals(w3[i])) {
								b = i;
								list15.add(b);
							}
						}
					}
				}
			for (int i = 0; i < list15.size() - 1; i++) {
				for (int j = list15.size() - 1; j > i; j--) {
					if (list15.get(j).equals(list15.get(i))) {
						list15.remove(j);
					}
				}
			}
			if (list15.size() > 3) {
				a1 = 1;
			}
			for (int i = 0; i < list15.size(); i++) {
				Double c1 = Double.parseDouble(pv[list15.get(i)]);
				list16.add(c1);
			}
			try {
				Double c3 = Collections.max(list16);
				Double c4 = Collections.min(list16);
				if (list16.size() > 1) {
					if (c3 != null) {
						money = a1 * oMoney * c3;
					} else {
						money = a1 * oMoney * c4;
					}
				} else {
					money = a1 * oMoney * Double.parseDouble(pv[list15.get(0)]);
				}
			} catch (Exception e) {
				money = a1 * oMoney * Double.parseDouble(pv[list15.get(0)]);
			}
		break;
		
		// 五不中
		case "wbz":
			for (int i = 0; i < cplay1.length; i++) {
					b++;
			}
			if (b != 0) {
				a1 = 1;
			} 
			money = a1 * oMoney * Double.parseDouble(pv[0]);
		break;
		
		// 六不中
		case "lbz":
			for (int i = 0; i < cplay1.length; i++) {
				b++;
			}
			if (b != 0) {
				a1 = 1;
			} 
			money = a1 * oMoney * Double.parseDouble(pv[0]);
		break;
		// 七不中
	case "qbz":
			for (int i = 0; i < cplay1.length; i++) {
				b++;
			}
			if (b != 0) {
				a1 = 1;
			}
			money = a1 * oMoney * Double.parseDouble(pv[0]);
			break;
			
		// 八不中
		case "bbz":
			for (int i = 0; i < cplay1.length; i++) {
				b++;
			}
			if (b != 0) {
				a1  = 1;
			}
			money = a1 * oMoney * Double.parseDouble(pv[0]);
		break;
		
		// 九不中
		case "jbz":
			for (int i = 0; i < cplay1.length; i++) {
						b++;
					}
			if (b != 0) {
				a1 = 1;
			}
			money = a1 * oMoney * Double.parseDouble(pv[0]);
		break;
		
		// 十不中
		case "shbz":
			for (int i = 0; i < cplay1.length; i++) {
						b++;
					}
			if (b!= 0) {
				a1 = 1;
			} 
			money = a1 * oMoney * Double.parseDouble(pv[0]);
		break;
		
		// 十一不中
		case "sh1bz":
			for (int i = 0; i < cplay1.length; i++) {
				b++;
			}
			if (b != 0) {
				a1 = 1;
			}
			money = a1 * oMoney * Double.parseDouble(pv[0]);
		break;
		// 十二不中
		case "sh2bz":
			for (int i = 0; i < cplay1.length; i++) {
				b++;
			}
			if (b != 0) {
				a1 = 1;
			}
			money = a1 * oMoney * Double.parseDouble(pv[0]);
		break;
		
		// 十三不中
		case "sh3bz":
			for (int i = 0; i < cplay1.length; i++) {
				b++;
			}
			if (b != 0) {
				a1 = 1;
			}
			money = a1 * oMoney * Double.parseDouble(pv[0]);
		break;
		
		// 十四不中
		case "sh4bz":
			for (int i = 0; i < cplay1.length; i++) {
				b++;
			}
			if (b != 0) {
				a1 = 1;
			}
			money = a1 * oMoney * Double.parseDouble(pv[0]);
		break;
		
		// 十五不中
		case "sh5bz":
			for (int i = 0; i < cplay1.length; i++) {
				b++;
			}
			if (b != 0) {
				a1 = 1;
			}
			money = a1 * oMoney * Double.parseDouble(pv[0]);
		break;
		
		// 总肖
		case "zx":
			List<Integer> zxs = new ArrayList<>();
					for (int i = 0; i < z1.length; i++) {
						for (int k = 0; k < cplay1.length; k++) {
							if (z1[i].equals(cplay1[k])) {
								zxs.add(i);
								a1 = 1;
							}
						}
					}
			money = a1 * oMoney * Double.parseDouble(pv[zxs.get(0)]);
		break;
		
		// 色波
		case "sb":
			for (int i = 0; i < b1.length; i++) {
					for (int m = 0; m < cplay1.length; m++) {
						if (cplay1[m].contains(b1[i])) {
							a1 = 1;
							b = i;
						}
					}
			}
			money = a1 * oMoney * Double.parseDouble(pv[b]);
		break;
		
		// 半波
		case "bb":
			int e1 =0;
			int c11 =0;
			List<Integer> list20 = new ArrayList<Integer>();
			for (int i = 0; i < cplay1.length; i++) {
				for (int j = 0; j < bb1.length; j++) {
					if (cplay1[i].equals(bb1[j])) {
							e1 = j;
							list20.add(e1);
							if (cplay1[i].contains("大")) {
								b = 1;
							}
							if (cplay1[i].contains("小")) {
								b = 1;
							}
							if (cplay1[i].contains("单")) {
								c11 = 1;
							}
							if (cplay1[i].contains("双")) {
								c11 = 1;
							}
						}
					}
			}
			double m1 = 0.00;
			double m2 = 0.00;
			if (list20.size() > 0) {
				if (b != 0) {
					m1 = b * oMoney * Double.parseDouble(pv[list20.get(0)]);
				} else {
					m1 = c11 * oMoney * Double.parseDouble(pv[list20.get(0)]);
				}
			}
			if (list20.size() > 1) {
				if (b != 0) {
					m2 = b * oMoney * Double.parseDouble(pv[list20.get(0 + 1)]);
				} else {
					m2 = c11 * oMoney * Double.parseDouble(pv[list20.get(0 + 1)]);
				}
			}
			money = m2 + m1;
		break;
		
		// 半半波
		case "bbb":
			List<Integer> list21 = new ArrayList<Integer>();
			int a8 = 0;
			int e2 = 0;
			int c5 = 0;
			for (int i = 0; i < cplay1.length; i++) {
				for (int j = 0; j < bb1.length; j++) {
					// 下注的匹配上半半波中的某个
					if (cplay1[i].equals(bbb1[j])) {
						// 下注的包含了中奖的某一个颜色
						if (cplay1[i].contains(b1[a8])) {
							if (cplay1[i].contains("大单")) {
									// e代表中奖的有 赔率中的哪几个
									e2 = j;
									list21.add(e2);
									c5 = 1;
							}
							if (cplay1[i].contains("大双"))
									e2 = j;
									list21.add(e2);
									c5 = 1;
							}
							if (cplay1[i].contains("小单")) {
									e2 = j;
									list21.add(e2);
									c5 = 1;
							}
							if (cplay1[i].contains("小双")) {
									e2 = j;
									list21.add(e2);
									c5 = 1;
							}
						}
					}
				}
			if (list21.size() > 0) {
				money = c5 * oMoney * Double.parseDouble(pv[list21.get(0)]);
			} else {
				money = 0.00;
			}
			break;
		}
		return money;
	}
	
	
	
	
	
	
	/**
	 * 
	 * 
	 * 
	 * 
	 * ----------------------彩种下注属性判断是否符合规定
	 * 
	 * 
	 * 
	 * 
	 * 
	 */
	
	/**
	 * 
	   *   方法名：judgeAttr   
	   *   描述：     判断香港六合彩平特不中下注属性                  TODO   
	   *   参数：    @param str
	   *   参数：    @param attr
	   *   参数：    @return 
	 * @return: boolean
	 */
	public static boolean judgeAttr(String[] str,String[] attr) {
		boolean flag = false;
		int count = 0;
		for(int i=0;i<str.length;i++) {
			for(int j=0;j<attr.length;j++) {
				if(str[i].equals(attr[j])) {
					count++;
				}
			}
		}
		if(count<str.length) {
			flag = true;
		}
		return flag; 
	}  
	
	
	/**
	 * 
	   *   方法名：checkLotterMoney4   
	   *   描述：     加拿大28奖金额最多的玩法                  TODO   
	   *   参数：    @param play 下注玩法名称
	   *   参数：    @param cplay1 下注玩法属性
	   *   参数：    @param pv 下注的赔率
	   *   参数：    @param oMoney 单注金额
	   *   参数：    @return 
	 * @return: double
	 */
	public static double checkLotterMoney4(String play, String[] cplay1, String[] pv, double oMoney) { // TODO 中奖金额统计
		double money = 0.00;
		int a1 = 0;
		int a2 = 0;
		int a3 = 0;
		int a4 = 0;
		int a5 = 0;
		int b = 0;
		
		String [] tms1 = {"0","1","2","3","4","5","6","7","8","9","10","11","12","13","14","15","16","17","18","19","20",
				"21","22","23","24","25","26","27"}; 
		
		//波色
		String [][] bose = {{"1","4","7","10","16","19","22","25"},{"2","5","8","11","17","20","23","26"},{"3","6","9","12","15","18","21","24"}};

		switch (play) {
		//混合
		case "hunhe":
		int a6 =0;
		int a7 =0;
		int a8 =0;
		int a9 =0;
		int a10 =0;
		for(int i=0;i<cplay1.length;i++) {
			if("大".equals(cplay1[i])) {
					a1 = 1;
			}
			
			if("小".equals(cplay1[i])) {
					a2 = 1;
			}
			
			if("单".equals(cplay1[i])) {
					a3 = 0;
			}
			
			if("双".equals(cplay1[i])) {
					a4 = 0;
			}
			
			if("大单".equals(cplay1[i])) {
					a5=1;
			}
			
			if("大双".equals(cplay1[i])) {
					a6=1;
			}
			
			if("小单".equals(cplay1[i])) {
					a7=1;
			}
			
			if("小双".equals(cplay1[i])) {
					a8=1;
			}
			
			if("极大".equals(cplay1[i])) {
					a9=1;
			}
			
			if("极小".equals(cplay1[i])) {
					a10 = 1;
			}
		}
		money = a1 * oMoney * Double.parseDouble(pv[0])
				+  a2 * oMoney * Double.parseDouble(pv[1])
				+  a3 * oMoney * Double.parseDouble(pv[2])
				+  a4 * oMoney * Double.parseDouble(pv[3])
				+  a5 * oMoney * Double.parseDouble(pv[4])
				+  a6 * oMoney * Double.parseDouble(pv[5])
				+  a7 * oMoney * Double.parseDouble(pv[6])
				+  a8 * oMoney * Double.parseDouble(pv[7])
				+  a9 * oMoney * Double.parseDouble(pv[8])
				+  a10 * oMoney * Double.parseDouble(pv[9]);
		break;
		
		// 特码
		case "tema":
			for(int i=0;i<cplay1.length;i++) {
				for(int j=0;j<tms1.length;j++) {
					if(cplay1[i].equals(tms1[j])) {
						b = i;
						a1=1;
					}
				}
			}
			money = a1 * oMoney * Double.parseDouble(pv[b]);
			break;
		
		//特码包三
		case "tmb3":
			for(int i=0;i<cplay1.length;i++) {
				for(int j=0;j<tms1.length;j++) {
					if(cplay1[i].equals(tms1[j])) {
						b = i;
						a1=1;
					}
				}
			}
			money = a1 * oMoney * Double.parseDouble(pv[b]);
			break;
		
		//波色	
		case "bs":
			for(int i=0;i<bose.length;i++) {
				for(int j=0;j<bose[i].length;j++) {
					for(int k =0;k<cplay1.length;k++) {
						if(cplay1[k].equals(bose[i][j])) {
							b = i;
							a1 = 1;
						}
					}
				}
			}
			money = a1 * oMoney * Double.parseDouble(pv[b]);
			break;

		//豹子	
		case "bz":
			money =  oMoney * Double.parseDouble(pv[0]);
			break;
		}
		return money;
	}
	
	

}
