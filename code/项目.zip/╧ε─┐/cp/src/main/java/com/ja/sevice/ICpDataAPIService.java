package com.ja.sevice;

import java.util.List;

/**
 * @DESC: 
 * @AUTH: qhzh 
 * @DATE: 2018年9月15日 上午9:36:59
 */
public interface ICpDataAPIService {

	List<String> findValidApiUrls();
}
