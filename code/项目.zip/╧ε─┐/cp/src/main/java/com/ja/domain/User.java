package com.ja.domain;

import java.io.Serializable;

public class User implements Serializable {
	
	private static final long serialVersionUID = 199846137935672251L;

	private Integer id; 

    private String name;//用户名
    
    private String nicheng;//用户昵称

    private String pass;//密码

    private String avatar;//头像

    private String qq;//qq

    private String telephone;//电话号码
    
    private Double betacount;//单注金额

    private Double balance;//余额
    
    private Integer fid;//上级id 

    private String icode;//邀请链接
    
	private Double money; //代理金额
    
    private Double odds;//上级设置的赔率
    
    private Double remainder;//上家给到我这里还有多少可调动的空间
    
    private Integer gamePlayer;//代理还是玩家  0-玩家   1-代理    这个是第二套代理系统的 不要乱改

	private String lastTime;//最后登录时间
    
    private String notTime;//未登录时间
    
    private String registerIp;//注册ip 
    
    private String registerTime;//注册时间

    private String lastIp;//最后登录ip

    private Integer agent_type; //用户类型 0会员 1代理 2总代理
    
    private Integer user_type;//用户类型 
    
    private Integer agent_id;//上级代理id
    
    private String createtime;//登录时间
    
    private String vip;//会员等级

	private Integer statu;// 提款状态 0是不用验证码 1是用验证码
    
    private Integer state;//用户状态
    
	public User() {
		super();
	}
	
	public User(String name, String pass) {
		super();
		this.name = name;
		this.pass = pass;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getNicheng() {
		return nicheng;
	}

	public void setNicheng(String nicheng) {
		this.nicheng = nicheng;
	}
	public Double getOdds() {
			return odds;
	}

	public void setOdds(Double odds) {
		this.odds = odds;
	}
	public String getPass() {
		return pass;
	}

	public void setPass(String pass) {
		this.pass = pass;
	}

	public String getAvatar() {
		return avatar;
	}

	public void setAvatar(String avatar) {
		this.avatar = avatar;
	}

	public String getQq() {
		return qq;
	}

	public void setQq(String qq) {
		this.qq = qq;
	}

	public String getTelephone() {
		return telephone;
	}

	public void setTelephone(String telephone) {
		this.telephone = telephone;
	}

	public Double getBetacount() {
		return betacount;
	}

	public void setBetacount(Double betacount) {
		this.betacount = betacount;
	}

	public Double getBalance() {
		return balance;
	}

	public void setBalance(Double balance) {
		this.balance = balance;
	}

	public Integer getFid() {
		return fid;
	}

	public void setFid(Integer fid) {
		this.fid = fid;
	}

	public String getIcode() {
		return icode;
	}

	public void setIcode(String icode) {
		this.icode = icode;
	}

	public Double getMoney() {
		return money;
	}

	public void setMoney(Double money) {
		this.money = money;
	}

	public String getLastTime() {
		return lastTime;
	}

	public void setLastTime(String lastTime) {
		this.lastTime = lastTime;
	}

	public String getNotTime() {
		return notTime;
	}

	public void setNotTime(String notTime) {
		this.notTime = notTime;
	}

	public String getRegisterIp() {
		return registerIp;
	}

	public void setRegisterIp(String registerIp) {
		this.registerIp = registerIp;
	}

	public String getRegisterTime() {
		return registerTime;
	}

	public void setRegisterTime(String registerTime) {
		this.registerTime = registerTime;
	}

	public String getLastIp() {
		return lastIp;
	}

	public void setLastIp(String lastIp) {
		this.lastIp = lastIp;
	}

	public Integer getAgent_type() {
		return agent_type;
	}

	public void setAgent_type(Integer agent_type) {
		this.agent_type = agent_type;
	}

	public Integer getUser_type() {
		return user_type;
	}

	public void setUser_type(Integer user_type) {
		this.user_type = user_type;
	}

	public Integer getAgent_id() {
		return agent_id;
	}

	public void setAgent_id(Integer agent_id) {
		this.agent_id = agent_id;
	}

	public String getCreatetime() {
		return createtime;
	}

	public void setCreatetime(String createtime) {
		this.createtime = createtime;
	}

	public Integer getStatu() {
		return statu;
	}

	public void setStatu(Integer statu) {
		this.statu = statu;
	}

	public Integer getState() {
		return state;
	}

	public void setState(Integer state) {
		this.state = state;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	public Integer getGamePlayer() {
		return gamePlayer;
	}

	public void setGamePlayer(Integer gamePlayer) {
		this.gamePlayer = gamePlayer;
	}
	public Double getRemainder() {
		return remainder;
	}

	public void setRemainder(Double remainder) {
		this.remainder = remainder;
	}
	public String getVip() {
		return vip;
	}

	public void setVip(String vip) {
		this.vip = vip;
	}
	@Override
	public String toString() {
		return "User [id=" + id + ", name=" + name + ", nicheng=" + nicheng + ", pass=" + pass + ", avatar=" + avatar
				+ ", qq=" + qq + ", telephone=" + telephone + ", betacount=" + betacount + ", balance=" + balance
				+ ", fid=" + fid + ", icode=" + icode + ", money=" + money + ", lastTime=" + lastTime + ", notTime="
				+ notTime + ", registerIp=" + registerIp + ", registerTime=" + registerTime + ", lastIp=" + lastIp
				+ ", agent_type=" + agent_type + ", user_type=" + user_type + ", agent_id=" + agent_id + ", createtime="
				+ createtime + ", statu=" + statu + ", state=" + state + "]";
	}
}