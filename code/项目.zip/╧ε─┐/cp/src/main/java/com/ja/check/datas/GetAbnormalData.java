package com.ja.check.datas;

import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

import org.json.JSONArray;
import org.json.JSONObject;
import org.jsoup.Connection.Response;
import org.jsoup.Jsoup;

import com.ja.check.data.SslUtils;
import com.ja.domain.Data;

/**
 * 当插入一条异常数据到数据库里面的时候，掉用这个方法一次
 * @author Administrator
 *NB
 */
public class GetAbnormalData {
	/**
	 * 异常数据集合
	 */
	public static CopyOnWriteArrayList<Data> ste = new CopyOnWriteArrayList<Data>();
	/**
	 * 当没有爬到数据的时候启动这个类去尝试获取数据
	 */
	public static String C6 = "https://www.5555c6.com/api/v1/result/service/mobile/results/hist/"; 
	String BJSC = "HF_BJPK10?limit=500";
	String AH11X5 = "HF_AHD11?limit=500";
	String AHK3 = "HF_AHK3?limit=500";
	String BJK3 = "HF_BJK3?limit=500";
	String CQKL10F = "HF_CQKL10F?limit=500";
	String CQSSC = "HF_CQSSC?limit=500";
	String GD11X5 = "HF_GDD11?limit=500";
	String GXK3 = "HF_GXK3?limit=500";
	String JSK3 = "HF_JSK3?limit=500";
	String JX11X5 = "HF_JXD11?limit=500";
	String SD11X5 = "HF_SDD11?limit=500";
	String SH11X5 = "HF_SHD11?limit=500";
	String SHSSL = "HF_SHSSL?limit=500";
	String TJSSC = "HF_TJSSC?limit=500";
	String XJSSC = "HF_XJSSC?limit=500";
	String XYFT = "HF_XYFT?limit=500";
	String GDKL10F = "HF_GDKL10F?limit=500";
	String BJ28 = "HF_BJ28?limit=500";
	String PL3 = "PL3?limit=500";
	//String F3D = "f3d";
	public static String kj = "https://kj.13322.com/trend/lottery.findLotteryIssue.do?lottery=";
	/**
	 * 获取彩种数据
	 */
	public final static String tmcp4455Cqssc = "https://tmcp4455.com/Result/GetLotteryResultList?gameID=26&pageSize=30&pageIndex=1&_=1540259963910";//重庆时时彩
	public final static String tmcp4455Ahk3 = "https://tmcp4455.com/Result/GetLotteryResultList?gameID=81&pageSize=20&pageIndex=1&_=1547715279662";//安徽快3
	public final static String tmcp4455Bjpk10 = "https://tmcp4455.com/Result/GetLotteryResultList?gameID=29&pageSize=30&pageIndex=1&_=1540780603486";//北京PK10
	public final static String tmcp4455Jx11x5 = "https://tmcp4455.com/Result/GetLotteryResultList?gameID=46&pageSize=30&pageIndex=1&_=1540780628867";//江西11选5
	public final static String tmcp4455Sd11x5 = "https://tmcp4455.com/Result/GetLotteryResultList?gameID=32&pageSize=30&pageIndex=1&_=1540780654648";//山东11选5
	public final static String tmcp4455Cqkl10f = "https://tmcp4455.com/Result/GetLotteryResultList?gameID=13&pageSize=30&pageIndex=1&_=1540780674511";//重庆快乐10分
	public static boolean bjpk10 = true;
	public static boolean ah11x5 = true;
	public static boolean ahk3 = true;
	public static boolean cqkl10f = true;
	public static boolean cqssc = true;
	public static boolean xjssc = true;
	public static boolean gd11x5 = true;
	public static boolean gdkl10f = true;
	public static boolean gxk3 = true;
	public static boolean jsk3 = true;
	public static boolean jx11x5 = true;
	public static boolean sd11x5 = true;
	public static boolean sh11x5 = true;
	public static boolean shssl = true;
	public static boolean tjssc = true;
	public static boolean xyft = true;
	public static boolean bjk3 = true;
	public static boolean fc3d = true;
	public static boolean pl3 = true;
	public static boolean bj28 = true;
	/**
	 * 异常数据
	 * @param period：期号
	 * @param cName：彩种名称
	 */
	public void abnormalData(Data d) {
		//System.out.println("--------------------------"+d.getCname()+"---------------------------返回的值"+chakanshifyouzaitiaoshuj(d));
		//将异常数据添加到集合里面
		if(chakanshifyouzaitiaoshuj(d)) {
			ste.add(d);
			////System.out.println(ste);
		if(bjpk10) {
			if("bjpk10".equals(d.getCname())) {
				Thread t = new Thread() {
					@Override
					public void run() {
						timedTask(C6+BJSC,d.getCname());
					}
				};
				t.start();
				bjpk10 = false;
			}else {
				////System.out.println("异常数据对比不相等bjpk10---------"+d.getCname()+"----"+d.getPeriod());
			}
		}
		if(ah11x5) {
			if("ah11x5".equals(d.getCname())) {
				Thread t = new Thread() {
					@Override
					public void run() {
						System.out.println("我进来了");
						timedTask(C6+AH11X5,d.getCname());
					}
				};
				t.start();
				ah11x5 = false;
			}else {
				////System.out.println("异常数据对比不相等ah11x5-----------"+d.getCname()+"----"+d.getPeriod());
			}
		}
		if(ahk3) {
			if("ahk3".equals(d.getCname())) {
				Thread t = new Thread() {
					@Override
					public void run() {
						timedTask(C6+AHK3,d.getCname());
					}
				};
				ahk3 = false;
				t.start();
			}else {
				////System.out.println("异常数据对比不相等ahk3-----------"+d.getCname()+"----"+d.getPeriod());
			}
		}
		if(cqkl10f) {
			if("cqkl10f".equals(d.getCname())) {
				Thread t = new Thread() {
					@Override
					public void run() {
						timedTask(C6+CQKL10F,d.getCname());
					}
				};
				cqkl10f = false;
				t.start();
			}else {
				//System.out.println("异常数据对比不相等cqkl10f-----------"+d.getCname()+"----"+d.getPeriod());
			}
		}
		if(cqssc) {
			if("cqssc".equals(d.getCname())) {
				Thread t = new Thread() {
					@Override
					public void run() {
						timedTask(C6+CQSSC,d.getCname());
					}
				};
				cqssc = false;
				t.start();
			}else {
				//System.out.println("异常数据对比不相等cqssc-----------"+d.getCname()+"----"+d.getPeriod());
			}
		}
		if(xjssc) {
			if("xjssc".equals(d.getCname())) {
				Thread t  = new Thread() {
					@Override
					public void run() {
						timedTask(C6+XJSSC,d.getCname());
					}
				};
				xjssc = false;
				t.start();
			}else {
				//System.out.println("异常数据对比不相等xjssc-----------"+d.getCname()+"----"+d.getPeriod());
			}
		}
		if(gd11x5) {
			if("gd11x5".equals(d.getCname())) {
				Thread t = new Thread() {
					@Override
					public void run() {
						timedTask(C6+GD11X5,d.getCname());
					}
				};
				gd11x5 = false;
				t.start();
			}else {
				//System.out.println("异常数据对比不相等gd11x5-----------"+d.getCname()+"----"+d.getPeriod());
			}
		}
		if(gdkl10f) {
			if("gdkl10f".equals(d.getCname())) {
				Thread t = new Thread() {
					@Override
					public void run() {
						timedTask(C6+GDKL10F,d.getCname());
					}
				};
				gdkl10f = false;
				t.start();
			}else {
				//System.out.println("异常数据对比不相等gdkl10f-----------"+d.getCname()+"----"+d.getPeriod());
			}
		}
		if(gxk3) {
			if("gxk3".equals(d.getCname())) {
				Thread t = new Thread() {
					@Override
					public void run() {
						timedTask(C6+GXK3,d.getCname());
					}
				};
				gxk3 = false;
				t.start();
			}else {
				//System.out.println("异常数据对比不相等gxk3-----------"+d.getCname()+"----"+d.getPeriod());
			}
		}
		if(jsk3) {
			if("jsk3".equals(d.getCname())) {
				Thread t = new Thread() {
					@Override
					public void run() {
						timedTask(C6+JSK3,d.getCname());
					}
				};
				jsk3 = false;
				t.start();
			}else {
				//System.out.println("异常数据对比不相等jsk3-----------"+d.getCname()+"----"+d.getPeriod());
			}
		}
		if(jx11x5) {
			if("jx11x5".equals(d.getCname())) {
				Thread t  = new  Thread() {
					@Override
					public void run() {
						timedTask(C6+JX11X5,d.getCname());
					}
				};
				jx11x5 = false;
				t.start();
			}else {
				//System.out.println("异常数据对比不相等jx11x5-----------"+d.getCname()+"----"+d.getPeriod());
			}
		}
		if(sd11x5) {
			if("sd11x5".equals(d.getCname())) {
				Thread t  = new Thread() {
					@Override
					public void run() {
						timedTask(C6+SD11X5,d.getCname());
					}
				};
				sd11x5 = false;
				t.start();
			}else {
				//System.out.println("异常数据对比不相等sd11x5-----------"+d.getCname()+"----"+d.getPeriod());
			}
		}
		if(sh11x5) {
			if("sh11x5".equals(d.getCname())) {
				Thread t = new Thread() {
					@Override
					public void run() {
						timedTask(C6+SH11X5,d.getCname());
					}
				};
				sh11x5 = false;
				t.start();
			}else {
				//System.out.println("异常数据对比不相等sh11x5-----------"+d.getCname()+"----"+d.getPeriod());
			}
		}
		if(shssl) {
			if("shssl".equals(d.getCname())) {
				Thread t  = new Thread() {
					@Override
					public void run() {
						timedTask(C6+SHSSL,d.getCname());
					}
				};
				shssl = false;
				t.start();
			}else {
				//System.out.println("异常数据对比不相等shssl-----------"+d.getCname()+"----"+d.getPeriod());
			}
		}
		if(tjssc) {
			if("tjssc".equals(d.getCname())) {
				Thread t  = new Thread() {
					@Override
					public void run() {
						timedTask(C6+TJSSC,d.getCname());
					}
				};
				tjssc = false;
				t.start();
			}else {
				//System.out.println("异常数据对比不相等tjssc-----------"+d.getCname()+"----"+d.getPeriod());
			}
		}
		if(xyft) {
			if("xyft".equals(d.getCname())) {
				Thread t = new Thread() {
					@Override
					public void run() {
						timedTask(C6+XYFT,d.getCname());
					}
				};
				xyft = false;
				t.start();
			}else {
				//System.out.println("异常数据对比不相等xyft-----------"+d.getCname()+"----"+d.getPeriod());
			}
		}
		if(bjk3) {
			if("bjk3".equals(d.getCname())) {
				Thread t  = new Thread() {
					@Override
					public void run() {
						timedTask(C6+BJK3,d.getCname());
					}
				};
				bjk3 = false;
				t.start();
			}else {
				//System.out.println("异常数据对比不相等bjk3-----------"+d.getCname()+"----"+d.getPeriod());
			}
		}
		if(bj28) {
			if("bj28".equals(d.getCname())) {
				Thread t  = new Thread() {
					@Override
					public void run() {
						timedTask(C6+BJ28,d.getCname());
					}
				};
				bj28 = false;
				t.start();
			}else {
				//System.out.println("异常数据对比不相等bj28-----------"+d.getCname()+"----"+d.getPeriod());
			}
		}
/*		if(fc3d) {
			if("fc3d".equals(d.getCname())) {
				Thread t  = new Thread() {
					@Override
					public void run() {
						timedTask(C6+F3D,d.getCname());
					}
				};
				fc3d = false;
				t.start();
			}else {
				//System.out.println("异常数据对比不相等fc3d"+d.getCname()+"----"+d.getPeriod());
			}
		}*/
		if(pl3) {
			if("pl3".equals(d.getCname())) {
				Thread t  = new Thread() {
					@Override
					public void run() {
						timedTask(C6+PL3,d.getCname());
					}
				};
				pl3 = false;
				t.start();
			}else {
				//System.out.println("异常数据对比不相等pl3-----------"+d.getCname()+"----"+d.getPeriod());
			}
		}
	}
	}
	/**
	 * 定时任务获取异常数据 北京PK10
	 * @param URL：地址
	 * @param period：期号
	 * @param cName：彩种名称
	 */
	public void timedTask(String URL,String cName) {
		while(true) {
			if(cName.equals("ah11x5")) {
				System.out.println("安徽11选5我进来了");
			}
			//System.out.println(Thread.activeCount()+"--------------当前活跃的线程数量");
			//System.out.println("----------------------正在获取异常数据-------"+cName+"-------------------------");
			String json = getJsonStrUseAgent(URL,3000);
			if(json != null) {
				JSONArray arr = new JSONArray(json);
				for (int i = 0; i < arr.length(); i++) {
					JSONObject obj = arr.getJSONObject(i);
					ste.forEach(item -> {
						if(cName.equals(item.getCname())) {
							if(String.valueOf(obj.get("uniqueIssueNumber")).trim().equals(item.getPeriod())) {
								if(obj.getString("openCode") != null && !"".equals(obj.getString("openCode"))) {
									//拿到异常数据，添加到集合里面
									Data data = new Data();
									data.setCname(cName);//彩种名称
									data.setLotternumber(obj.getString("openCode"));//开奖号
									data.setPeriod(String.valueOf(obj.get("uniqueIssueNumber")));//期号
									//调用开奖接口插入异常数据
									upateData(data);
									ste.remove(item);
									//System.out.println(ste);
								}
							}
						}
					
					  });
				}
			}
			try {
				Thread.sleep(15000);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			if(inspect(cName)) {
				termination(cName);
				return;
			}
		}
	}
	public void termination(String cName) {
		switch (cName) {
		case "bjpk10":
			bjpk10 = true;
			return;
		case "ah11x5":
			ah11x5= true;
			return;
		case "ahk3":
			ahk3= true;
			return;
		case "cqkl10f":
			cqkl10f = true;
			return;
		case "cqssc":
			cqssc = true;
			return;
		case "xjssc":
			xjssc= true;
			return;
		case "gd11x5":
			gd11x5= true;
			return;
		case "gdkl10f":
			gdkl10f= true;
			return;
		case "gxk3":
			gxk3= true;
			return;
		case "jsk3":
			jsk3= true;
			return;
		case "jx11x5":
			jx11x5= true;
			return;
		case "sd11x5":
			sd11x5= true;
			return;
		case "sh11x5":
			sh11x5= true;
			return;
		case "shssl":
			shssl= true;
			return;
		case "tjssc":
			tjssc = true;
			return;
		case "xyft":
			 xyft= true;
			 return;
		case "bjk3":
			 bjk3= true;
			 return;
		case "fc3d":
			 fc3d= true;
			 return;
		case "pl3":
			 pl3 = true;
			 return;
		case "bj28":
			bj28 = true;
			return;
		default:
			//System.out.println("没有找到匹配的");
		}
	}
	/**
	 * 工作人员后台填写开奖号以及，删除集合里面的开奖号和期号
	 * @param data：数据对象
	 */
	public static void haveBeenAwardedAPrize(Data data) {
		for (Data d : ste) {
			if(d.getCname().equals(data.getCname())) {
				if(d.getPeriod().equals(data.getPeriod())) {
					ste.remove(d);
					break;
				}
			}
		}
	}
	/**
	 * 获取数据库里面异常的数据 并且把官方开奖异常的去除掉
	 */
/*	public void databaseExceptionData() {
		 //得到时间类
        Calendar date = Calendar.getInstance();
        //设置时间为 xx-xx-xx 00:00:00
        date.set(date.get(Calendar.YEAR), date.get(Calendar.MONTH), date.get(Calendar.DATE), 0, 0, 0);
        //一天的毫秒数
        long daySpan = 24 * 60 * 60 * 1000;
        //得到定时器实例
        Timer t = new Timer();
        //使用匿名内方式进行方法覆盖
        t.schedule(new TimerTask() {
            public void run() {
                //run中填写定时器主要执行的代码块
               //System.out.println("异常数据里面正在执行..");
               List<Data> d = new Publicmethods().databaseExceptionData();
               Iterator<Data> iterator = list.iterator();
               while(iterator.hasNext()) {
            	   Data data = iterator.next();
            	   Iterator<Data> iterator1 = d.iterator();
            	   while(iterator1.hasNext()) {
            		   Data it = iterator1.next();
            		   if(data.getCname().equals(it.getCname())) {
            			   
            		   }else {
            			   //System.out.println("数据库异常数据判断值不相等"+data.getCname()+"--------"+it.getCname());
            		   }
            	   }
               }
            }
        }, date.getTime(), daySpan); //daySpan是一天的毫秒数，也是执行间隔
	}*/
	/**
	 * 判断集合里面是否有在调数据的存在
	 * @param period
	 * @param cName
	 * @return
	 */
	public boolean chakanshifyouzaitiaoshuj(Data d) {
		for (Data data : ste) {
			if(String.valueOf(data.getPeriod()).equals(String.valueOf(d.getPeriod())) && String.valueOf(data.getCname()).equals(String.valueOf(d.getCname()))) {
				return false;
			}
		}
		return true;
	}
	/**
	 * 将异常数据插入数据并掉开奖接口
	 * @param data：数据对象
	 */
	public void upateData(Data data) {
		//调用插入语句，将数据插入数据库
		Publicmethods p = new Publicmethods();
		//System.out.println("获取到一条异常数据----"+data.getCname()+"------------"+data.getPeriod()+"-------------"+data.getLotternumber());
		p.updataData(data);
	}
	
	public static void abnormalDataInDatabase() {
	//	System.out.println("-----------我进来啦-------------");
		GetAbnormalData g = new GetAbnormalData();
		Publicmethods p = new Publicmethods();
		List<Data> list = p.databaseExceptionData();
		for(Data d : list) {
			if(ste.size() > 0) {
				for(Data b :ste) {
					if(d.getCname().equals(b.getCname()) && d.getPeriod().equals(b.getPeriod())) {
					//	System.out.println(d.toString()+"-------------集合里面已经有异常数据了");
					}else {
					//	System.out.println(d.toString()+"-------------正在开启异常数据爬取");
						g.abnormalData(d);
					}
				}
			}else {
				//System.out.println(d.toString()+"-------------正在开启异常数据爬取");
				g.abnormalData(d);
			}
		}
	}
	/**
	 * 查看是否有这个彩种的异常数据
	 * @param cName
	 * @return
	 */
	public boolean inspect(String cName) {
		for (Data d : ste) {
			if(cName.equals(d.getCname())) {
				return false;
			}
		}
		return true;
	}
	/**
	 * 获取json数据
	 * @param url：连接
	 * @param timeoutMillis：尝试连接时间
	 * @return
	 */
	public  String getJsonStrUseAgent(String url, int timeoutMillis) {
		try {
			SslUtils.ignoreSsl();
			Response r = Jsoup.connect(url).timeout(timeoutMillis).userAgent(
					"Mozilla/5.0(Macintosh;IntelMacOSX10_7_0)AppleWebKit/535.11(KHTML,likeGecko)Chrome/17.0.963.56Safari/535.11")
					.cookie("auth", "token").ignoreContentType(true).execute();
			return r.body();
		} catch (Exception e) {
			/**System.out.println("["+DateUtil.getCurrTime()+"] url="+url+"--Exception--"+e.getMessage());
			e.printStackTrace();*/
		}catch (Error e) {
			/**System.out.println("["+DateUtil.getCurrTime()+"] url="+url+"--Error--"+e.getMessage());
			e.printStackTrace();*/
		}
		return null;
	}
	/**
	 * jiang
	 * @param str
	 * @return
	 */
	public List<String> transformation(String str){
	
		return null;
	}
	/**
	 * 测试方法
	 * @param args
	 */
	public static void main(String[] args) {
		Data d = new Data();
		d.setPeriod("12412435235");
		d.setNextperiod("12412435235");
		if(d.getPeriod().equals(d.getNextperiod())) {
			//System.out.println("相等");
		}
		//System.out.println("我出来了");
		/*String str = new GetAbnormalData().getJsonStrUseAgent(tmcp4455Bjpk10, 3000);
		//System.out.println(str);*/
	}
	
}
