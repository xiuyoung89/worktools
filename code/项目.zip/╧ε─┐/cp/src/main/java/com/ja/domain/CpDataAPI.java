package com.ja.domain;

import java.io.Serializable;

/**
 * @DESC: 
 * @AUTH: qhzh 
 * @DATE: 2018年9月15日 上午9:27:20
 */
public class CpDataAPI implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = -2538442384502154311L;

	private Integer id;
	
	private String webName;
	
	private String cname;
	
	private String chineseName;
	
	private String apiUrl;
	
	private Integer status;

	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getWebName() {
		return webName;
	}

	public void setWebName(String webName) {
		this.webName = webName;
	}

	public String getCname() {
		return cname;
	}

	public void setCname(String cname) {
		this.cname = cname;
	}

	public String getChineseName() {
		return chineseName;
	}

	public void setChineseName(String chineseName) {
		this.chineseName = chineseName;
	}

	public String getApiUrl() {
		return apiUrl;
	}

	public void setApiUrl(String apiUrl) {
		this.apiUrl = apiUrl;
	}

	public Integer getStatus() {
		return status;
	}

	public void setStatus(Integer status) {
		this.status = status;
	}
	
}
