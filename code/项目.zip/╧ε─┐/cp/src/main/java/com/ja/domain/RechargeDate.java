package com.ja.domain;

import java.io.Serializable;

public class RechargeDate implements Serializable{
    /**
	 * 
	 */
	private static final long serialVersionUID = 7742167541654603389L;

	private Integer id;

    private Double recharge;

    private String rechargeTime;

    private Integer userid;

    
    public static long getSerialversionuid() {
		return serialVersionUID;
	}
    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Double getRecharge() {
        return recharge;
    }

    public void setRecharge(Double recharge) {
        this.recharge = recharge;
    }

    public String getRechargeTime() {
        return rechargeTime;
    }

    public void setRechargeTime(String rechargeTime) {
        this.rechargeTime = rechargeTime == null ? null : rechargeTime.trim();
    }

    public Integer getUserid() {
        return userid;
    }

    public void setUserid(Integer userid) {
        this.userid = userid;
    }
}