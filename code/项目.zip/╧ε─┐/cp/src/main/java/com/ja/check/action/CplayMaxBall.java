package com.ja.check.action;

import java.util.Arrays;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.ja.domain.Lotter;
import com.ja.domain.PlayCount;

/**
 * 
 * 最大 和 最小 玩法 下注最少的球
 * 
 * @author GL
 *
 */

public class CplayMaxBall {

	/**
	 * 
	  * 方法名：maxCplay 
	  * 描述： 系统彩下注中奖最高的玩法 
	 * TODO 参数： @param 
	 * cplay1 参数： @return
	 * @return: String
	 */
	public String maxCplay (List<PlayCount> cplays)throws Exception {
		Map<String, Double> map = new HashMap<>();
		for (PlayCount play : cplays) {
			map.put(play.getCplay(), play.getPayMoney());
		}
		if(map.size()==0) {
			return "&0";
		}
		String maxKey = "";
		Collection<Double> c = map.values();
		Object[] obj = c.toArray();
		Arrays.sort(obj);
		Object maxVal = obj[obj.length-1];
		for (String key : map.keySet()) {
			double val = map.get(key);
			if ((Double) maxVal == val) {
				maxKey = key;
			}
		}
		return maxKey+"&1";
	}
	
	/**
	 * 
	 * 方法名：maxAttribute 描述： bjPk10下注中奖最高的玩法 下注最多的属性 TODO 参数： @param cplay1
	 * 参数： @return
	 * 
	 * @return: String
	 */
	public String maxAttribute2fpk10 (String cplay, PlayCount play, Lotter lotters) throws Exception{
		Map<String, Double> maps = new HashMap<String, Double>();
		String[] rebates = {};
		switch (cplay) {
		case "gyhz":
			rebates = lotters.getRebate1().split(",");
			maps.put("dan", play.getDan() * Double.parseDouble(rebates[0]));
			maps.put("shuang", play.getShuang() * Double.parseDouble(rebates[1]));
			maps.put("da", play.getDa() * Double.parseDouble(rebates[2]));
			maps.put("xiao", play.getXiao() * Double.parseDouble(rebates[3]));
			break;
		case "gj":
		case "yj":
		case "d3m":
		case "d4m":
		case "d5m":
			switch (cplay) {
			case "gj":
				rebates = lotters.getRebate2().split(",");
				break;
			case "yj":
				rebates = lotters.getRebate3().split(",");
				break;
			case "d3m":
				rebates = lotters.getRebate4().split(",");
				break;
			case "d4m":
				rebates = lotters.getRebate5().split(",");
				break;
			case "d5m":
				rebates = lotters.getRebate6().split(",");
				break;
			}
			maps.put("dan", play.getDan() * Double.parseDouble(rebates[0]));
			maps.put("shuang", play.getShuang() * Double.parseDouble(rebates[1]));
			maps.put("da", play.getDa() * Double.parseDouble(rebates[2]));
			maps.put("xiao", play.getXiao() * Double.parseDouble(rebates[3]));
			maps.put("longs", play.getLongs() * Double.parseDouble(rebates[4]));
			maps.put("hu", play.getHu() * Double.parseDouble(rebates[5]));
			maps.put("he", play.getHe() * Double.parseDouble(rebates[6]));
			lotterAttr3(rebates, maps,play);
			break;
		case "d6m":
		case "d7m":
		case "d8m":
		case "d9m":
		case "d10m":
			switch (cplay) {
			case "d6m":
				rebates = lotters.getRebate7().split(",");
				break;
			case "d7m":
				rebates = lotters.getRebate8().split(",");
				break;
			case "d8m":
				rebates = lotters.getRebate9().split(",");
				break;
			case "d9m":
				rebates = lotters.getRebate10().split(",");
				break;
			case "d10m":
				rebates = lotters.getRebate11().split(",");
				break;
			}
			maps.put("dan", play.getDan() * Double.parseDouble(rebates[0]));
			maps.put("shuang", play.getShuang() * Double.parseDouble(rebates[1]));
			maps.put("da", play.getDa() * Double.parseDouble(rebates[2]));
			maps.put("xiao", play.getXiao() * Double.parseDouble(rebates[3]));
			lotterAttr1(rebates, maps,play);
			break;
		
		}
		String maxKey = "";
		Collection<Double> map = maps.values();
		Object[] obj = map.toArray();
		Arrays.sort(obj);
		Object minVal = obj[obj.length - 1];
		for (String key : maps.keySet()) {
			double val = maps.get(key);
			if ((Double) minVal == val) {
				maxKey = key;
			}
		}
		System.out.println("玩法：" + cplay + "  属性中奖最多的值： " + maxKey);
		return maxKey;
	}
	

	/**
	 * 
	 * 方法名：maxAttribute 描述： 2fssc下注中奖最高的玩法 下注最多的属性 TODO 参数： @param cplay1
	 * 参数： @return
	 * 
	 * @return: String
	 */
	public String maxAttribute(String cplay, PlayCount play, Lotter lotters) throws Exception{
		Map<String, Double> maps = new HashMap<String, Double>();
		String[] rebates = {};
		switch (cplay) {
		case "zh":
			rebates = lotters.getRebate1().split(",");
			maps.put("dan", play.getDan() * Double.parseDouble(rebates[0]));
			maps.put("shuang", play.getShuang() * Double.parseDouble(rebates[1]));
			maps.put("da", play.getDa() * Double.parseDouble(rebates[2]));
			maps.put("xiao", play.getXiao() * Double.parseDouble(rebates[3]));
			maps.put("longs", play.getLongs() * Double.parseDouble(rebates[4]));
			maps.put("hu", play.getHu() * Double.parseDouble(rebates[5]));
			maps.put("he", play.getHe() * Double.parseDouble(rebates[6]));
			break;
		case "d1q":
		case "d2q":
		case "d3q":
		case "d4q":
		case "d5q":
			switch (cplay) {
			case "d1q":
				rebates = lotters.getRebate2().split(",");
				break;
			case "d2q":
				rebates = lotters.getRebate3().split(",");
				break;
			case "d3q":
				rebates = lotters.getRebate4().split(",");
				break;
			case "d4q":
				rebates = lotters.getRebate5().split(",");
				break;
			case "d5q":
				rebates = lotters.getRebate6().split(",");
				break;
			}
			maps.put("dan", play.getDan() * Double.parseDouble(rebates[0]));
			maps.put("shuang", play.getShuang() * Double.parseDouble(rebates[1]));
			maps.put("da", play.getDa() * Double.parseDouble(rebates[2]));
			maps.put("xiao", play.getXiao() * Double.parseDouble(rebates[3]));
			lotterAttr1(rebates, maps,play);
			break;
		case "q3":
		case "z3":
		case "h3":
			switch (cplay) {
			case "q3":
				rebates = lotters.getRebate7().split(",");
				break;
			case "z3":
				rebates = lotters.getRebate8().split(",");
				break;
			case "h3":
				rebates = lotters.getRebate9().split(",");
				break;
			}
			maps.put("baozi", play.getBaozi() * Double.parseDouble(rebates[0]));
			maps.put("shunzi", play.getShunzi() * Double.parseDouble(rebates[1]));
			maps.put("duizi", play.getDuizi() * Double.parseDouble(rebates[2]));
			maps.put("banshun", play.getBanshun() * Double.parseDouble(rebates[3]));
			maps.put("zaliu", play.getZaliu() * Double.parseDouble(rebates[4]));
			break;
		case "q2zhix0":
		case "q2zhix1":
			rebates = lotters.getRebate10().split(",");
			lotterAttr0(rebates, maps,play);
			break;
		case "h2zhix0":
		case "h2zhix1":
			rebates = lotters.getRebate11().split(",");
			lotterAttr0(rebates, maps,play);
			break;
		case "q3zhix0":
		case "q3zhix1":
		case "q3zhix2":
			rebates = lotters.getRebate12().split(",");
			lotterAttr0(rebates, maps,play);
			break;
		case "z3zhix0":
		case "z3zhix1":
		case "z3zhix2":
			rebates = lotters.getRebate13().split(",");
			lotterAttr0(rebates, maps,play);
			break;
		case "h3zhix0":
		case "h3zhix1":
		case "h3zhix2":
			rebates = lotters.getRebate14().split(",");
			lotterAttr0(rebates, maps,play);
			break;
		case "q2zx":
			rebates = lotters.getRebate15().split(",");
			lotterAttr0(rebates, maps,play);
			break;
		case "h2zx":
			rebates = lotters.getRebate16().split(",");
			lotterAttr0(rebates, maps,play);
			break;
		case "q3z6":
			rebates = lotters.getRebate17().split(",");
			lotterAttr0(rebates, maps,play);
			break;
		case "z3z6":
			rebates = lotters.getRebate18().split(",");
			lotterAttr0(rebates, maps,play);
			break;
		case "h3z6":
			rebates = lotters.getRebate19().split(",");
			lotterAttr0(rebates, maps,play);
			break;
		case "q3z3":
			rebates = lotters.getRebate20().split(",");
			lotterAttr0(rebates, maps,play);
			break;
		case "z3z3":
			rebates = lotters.getRebate21().split(",");
			lotterAttr0(rebates, maps,play);
			break;
		case "h3z3":
			rebates = lotters.getRebate22().split(",");
			lotterAttr0(rebates, maps,play);
			break;
		}
		String maxKey = "";
		Collection<Double> map = maps.values();
		Object[] obj = map.toArray();
		Arrays.sort(obj);
		Object minVal = obj[obj.length - 1];
		for (String key : maps.keySet()) {
			double val = maps.get(key);
			if ((Double) minVal == val) {
				maxKey = key;
			}
		}
		System.out.println("玩法：" + cplay + "  属性中奖最多的值： " + maxKey);
		return maxKey;
	}
	
	/**
	 * 
	 * 方法名：maxAttributesfk3 描述： sfk3下注中奖最高的玩法 下注最多的属性 TODO 参数： @param cplay1
	 * 参数： @return
	 * 
	 * @return: String
	 */
	public String maxAttributesfk3(String cplay, PlayCount play, Lotter lotters) throws Exception{
		Map<String, Double> maps = new HashMap<String, Double>();
		String[] rebates = {};
		switch (cplay) {
		case "c1gh":
		case "ebth":
		case "ebthdt1":
		case "ebthdt2":
		case "sbth":
			switch (cplay) {
			case "c1gh":
				rebates = lotters.getRebate1().split(",");
				break;
			case "ebth":
				rebates = lotters.getRebate5().split(",");
				break;
			case "ebthdt1":
			case "ebthdt2":
				rebates = lotters.getRebate6().split(",");
				break;
			case "sbth":
				rebates = lotters.getRebate9().split(",");
				break;
			}
			lotterAttr5(rebates, maps,play);
			break;
		case "ethfx":
		case "ethdx1":
		case "ethdx2":
		case "sthdx":
			switch (cplay) {
			case "ethfx":
				rebates = lotters.getRebate3().split(",");
				break;
			case "ethdx1":
			case "ethdx2":
				rebates = lotters.getRebate5().split(",");
				break;
			case "sthdx":
				rebates = lotters.getRebate8().split(",");
				break;
			}
			lotterAttr6(rebates, maps,play);
			break;
		case "slhtx":
			rebates = lotters.getRebate11().split(",");
			maps.put("slhtx", play.getSlhtx() * Double.parseDouble(rebates[0]));
			break;
		case "sthtx":
			rebates = lotters.getRebate2().split(",");
			maps.put("sthtx", play.getSthtx() * Double.parseDouble(rebates[0]));
			break;
		case "xt":
			rebates = lotters.getRebate10().split(",");
			maps.put("baozi", play.getBaozi() * Double.parseDouble(rebates[0]));
			maps.put("shunzi", play.getShunzi() * Double.parseDouble(rebates[1]));
			maps.put("duizi", play.getDuizi() * Double.parseDouble(rebates[2]));
			maps.put("banshun", play.getBanshun() * Double.parseDouble(rebates[3]));
			maps.put("zaliu", play.getZaliu() * Double.parseDouble(rebates[4]));
			break;
		case "zh":
			rebates = lotters.getRebate11().split(",");
			maps.put("d1q", play.getD1q()* Double.parseDouble(rebates[0]));
			maps.put("d2q",  play.getD2q()* Double.parseDouble(rebates[1]));
			maps.put("d3q", play.getD3q()* Double.parseDouble(rebates[2]));
			maps.put("d4q",  play.getD4q()*Double.parseDouble(rebates[3]));
			maps.put("d5q",  play.getD5q()*Double.parseDouble(rebates[4]));
			maps.put("d6q",  play.getD6q()*Double.parseDouble(rebates[5]));
			maps.put("d7q",  play.getD7q()*Double.parseDouble(rebates[6]));
			maps.put("d8q",  play.getD8q()*Double.parseDouble(rebates[7]));
			maps.put("d9q",  play.getD9q()*Double.parseDouble(rebates[8]));
			maps.put("d10q",  play.getD10q()*Double.parseDouble(rebates[9]));
			maps.put("d11q",  play.getD11q()*Double.parseDouble(rebates[10]));
			maps.put("d12q",  play.getD12q()*Double.parseDouble(rebates[11]));
			maps.put("d13q",  play.getD13q()*Double.parseDouble(rebates[12]));
			maps.put("d14q",  play.getD14q()*Double.parseDouble(rebates[13]));
			maps.put("d15q",  play.getD15q()*Double.parseDouble(rebates[14]));
			maps.put("d16q",  play.getD16q()*Double.parseDouble(rebates[15]));
			maps.put("da",  play.getDa()*Double.parseDouble(rebates[16]));
			maps.put("xiao",  play.getXiao()*Double.parseDouble(rebates[17]));
			maps.put("dan",  play.getDan()*Double.parseDouble(rebates[18]));
			maps.put("shuang",  play.getShuang()*Double.parseDouble(rebates[19]));
			break;
		}
		String maxKey = "";
		Collection<Double> map = maps.values();
		Object[] obj = map.toArray();
		Arrays.sort(obj);
		Object minVal = obj[obj.length - 1];
		for (String key : maps.keySet()) {
			double val = maps.get(key);
			if ((Double) minVal == val) {
				maxKey = key;
			}
		}
		System.out.println("玩法：" + cplay + "  属性中奖最多的值： " + maxKey);
		return maxKey;
	}
	

	/**
	 * xg6hc
	 * 方法名：maxAttributexg6hc 描述： 下注中奖最高的玩法 下注最多的属性 TODO 参数： @param cplay1
	 * 参数： @return
	 * 
	 * @return: String
	 */
	public String maxAttributexg6hc(String cplay, PlayCount play, Lotter lotters) throws Exception{
		Map<String, Double> maps = new HashMap<String, Double>();
		String[] rebates = {};
		switch (cplay) {
		case "tma":
		case "tmb":
		case "dp":
			switch (cplay) {
			case "tma":
				rebates = lotters.getRebate1().split(",");
				break;
			case "tmb":
				rebates = lotters.getRebate2().split(",");
				break;
			case "dp":
				rebates = lotters.getRebate11().split(",");
				break;
			}
			lotterAttr7(rebates, maps,play);
			break;
			
		case "p2z2":
		case "p3z3":
		case "p3z2":
		case "wbz":
		case "lbz":
		case "qbz":
		case "bbz":
		case "jbz":
		case "shbz":
		case "sh1bz":
		case "sh2bz":
		case "sh3bz":
		case "sh4bz":
		case "sh5bz":
			switch (cplay) {
			case "p2z2":
				rebates = lotters.getRebate12().split(",");
				break;
			case "p3z3":
				rebates = lotters.getRebate13().split(",");
				break;
			case "p3z2":
				rebates = lotters.getRebate14().split(",");
				break;
			case "wbz":
				rebates = lotters.getRebate26().split(",");
				break;
			case "lbz":
				rebates = lotters.getRebate27().split(",");
				break;
			case "qbz":
				rebates = lotters.getRebate28().split(",");
				break;
			case "bbz":
				rebates = lotters.getRebate29().split(",");
				break;
			case "jbz":
				rebates = lotters.getRebate30().split(",");
				break;
			case "shbz":
				rebates = lotters.getRebate31().split(",");
				break;
			case "sh1bz":
				rebates = lotters.getRebate32().split(",");
				break;
			case "sh2bz":
				rebates = lotters.getRebate33().split(",");
				break;
			case "sh3bz":
				rebates = lotters.getRebate34().split(",");
				break;
			case "sh4bz":
				rebates = lotters.getRebate35().split(",");
				break;
			case "sh5bz":
				rebates = lotters.getRebate36().split(",");
				break;
			}
			lotterAttr11(rebates, maps,play);
			break;
			
		case "tmsx":
		case "sxzt":
		case "wxzt":
		case "lxzt":
		case "pt1x":
		case "pt2x":
		case "pt3x":
		case "pt4x":
			switch (cplay) {
			case "tmsx":
				rebates = lotters.getRebate3().split(",");
				break;
			case "sxzt":
				rebates = lotters.getRebate15().split(",");
				break;
			case "wxzt":
				rebates = lotters.getRebate16().split(",");
				break;
			case "lxzt":
				rebates = lotters.getRebate17().split(",");
				break;
			case "pt1x":
				rebates = lotters.getRebate18().split(",");
				break;
			case "pt2x":
				rebates = lotters.getRebate19().split(",");
				break;
			case "pt3x":
				rebates = lotters.getRebate20().split(",");
				break;
			case "pt4x":
				rebates = lotters.getRebate21().split(",");
				break;
			}
			lotterAttr8(rebates, maps,play);
			break;
		case "dxds":
		case "zh":
		case "hs":
			switch (cplay) {
			case "dxds":
				rebates = lotters.getRebate4().split(",");
				break;
			case "zh":
				rebates = lotters.getRebate9().split(",");
				break;
			case "hs":
				rebates = lotters.getRebate10().split(",");
				break;
			}
			lotterAttr9(rebates, maps,play);
			break;
		case "jqys":
			rebates = lotters.getRebate5().split(",");
			maps.put("jiaxiao", play.getJiaxiao() * Double.parseDouble(rebates[0]));
			maps.put("yexiao", play.getYexiao() * Double.parseDouble(rebates[1]));
			maps.put("tianxiao", play.getTianxiao() * Double.parseDouble(rebates[2]));
			maps.put("dixiao", play.getDixiao() * Double.parseDouble(rebates[3]));
			break;
		case "ts":
			rebates = lotters.getRebate6().split(",");
			maps.put("lingtou", play.getLingtou() * Double.parseDouble(rebates[0]));
			maps.put("yitou", play.getYitou() * Double.parseDouble(rebates[1]));
			maps.put("ertou", play.getErtou() * Double.parseDouble(rebates[2]));
			maps.put("santou", play.getSantou() * Double.parseDouble(rebates[3]));
			maps.put("sitou", play.getSitou() * Double.parseDouble(rebates[4]));
			break;
		case "ws":
			rebates = lotters.getRebate7().split(",");
			maps.put("lingwei", play.getLingwei()* Double.parseDouble(rebates[0]));
			maps.put("yiwei",  play.getYiwei()* Double.parseDouble(rebates[1]));
			maps.put("erwei", play.getErwei()* Double.parseDouble(rebates[2]));
			maps.put("sanwei",  play.getSanwei()*Double.parseDouble(rebates[3]));
			maps.put("siwei",  play.getSiwei()*Double.parseDouble(rebates[4]));
			maps.put("wuwei",  play.getWuwei()*Double.parseDouble(rebates[5]));
			maps.put("liuwei",  play.getLiuwei()*Double.parseDouble(rebates[6]));
			maps.put("qiwei",  play.getQiwei()*Double.parseDouble(rebates[7]));
			maps.put("bawei",  play.getBawei()*Double.parseDouble(rebates[8]));
			maps.put("jiuwei",  play.getJiuwei()*Double.parseDouble(rebates[9]));
			maps.put("da",  play.getDa()*Double.parseDouble(rebates[10]));
			maps.put("xiao",  play.getXiao()*Double.parseDouble(rebates[11]));
			maps.put("dan",  play.getDan()*Double.parseDouble(rebates[12]));
			maps.put("shuang",  play.getShuang()*Double.parseDouble(rebates[13]));
			break;
		case "wx":
			rebates = lotters.getRebate8().split(",");
			maps.put("jin", play.getJin()* Double.parseDouble(rebates[0]));
			maps.put("mu",  play.getMu()* Double.parseDouble(rebates[1]));
			maps.put("shui", play.getShui()* Double.parseDouble(rebates[2]));
			maps.put("huo",  play.getHuo()*Double.parseDouble(rebates[3]));
			maps.put("tus",  play.getTus()*Double.parseDouble(rebates[4]));
			break;
		case "pt1w":
		case "pt2w":
		case "pt3w":
		case "pt4w":
			switch (cplay) {
			case "pt1w":
				rebates = lotters.getRebate22().split(",");
				break;
			case "pt2w":
				rebates = lotters.getRebate23().split(",");
				break;
			case "pt3w":
				rebates = lotters.getRebate24().split(",");
				break;
			case "pt4w":
				rebates = lotters.getRebate25().split(",");
				break;
			}
			lotterAttr10(rebates, maps,play);
			break;
		case "zx":
			rebates = lotters.getRebate37().split(",");
			maps.put("erxiao", play.getErxiao()* Double.parseDouble(rebates[0]));
			maps.put("sanxiao",  play.getSanxiao()* Double.parseDouble(rebates[1]));
			maps.put("sixiao", play.getSixiao()* Double.parseDouble(rebates[2]));
			maps.put("wuxiao",  play.getWuxiao()*Double.parseDouble(rebates[3]));
			maps.put("liuxiao",  play.getLiuxiao()*Double.parseDouble(rebates[4]));
			maps.put("qixiao",  play.getQixiao()*Double.parseDouble(rebates[5]));
			maps.put("dan",  play.getDan()*Double.parseDouble(rebates[6]));
			maps.put("shuang",  play.getShuang()*Double.parseDouble(rebates[7]));
			break;
		case "sb":
			rebates = lotters.getRebate38().split(",");
			maps.put("hongbo", play.getHongbo()* Double.parseDouble(rebates[0]));
			maps.put("lanbo",  play.getLanbo()* Double.parseDouble(rebates[1]));
			maps.put("lvbo", play.getLvbo()* Double.parseDouble(rebates[2]));
			break;
		case "bb":
			rebates = lotters.getRebate39().split(",");
			maps.put("hongda", play.getHongda()* Double.parseDouble(rebates[0]));
			maps.put("hongxiao",  play.getHongxiao()* Double.parseDouble(rebates[1]));
			maps.put("hongdan", play.getHongdan()* Double.parseDouble(rebates[2]));
			maps.put("hongshuang",  play.getHongshuang()*Double.parseDouble(rebates[3]));
			maps.put("landa",  play.getLanda()*Double.parseDouble(rebates[4]));
			maps.put("lanxiao",  play.getLanxiao()*Double.parseDouble(rebates[5]));
			maps.put("landan",  play.getLandan()*Double.parseDouble(rebates[6]));
			maps.put("lanshuang",  play.getLanshuang()*Double.parseDouble(rebates[7]));
			maps.put("lvda",  play.getLvda()*Double.parseDouble(rebates[8]));
			maps.put("lvxiao",  play.getLvxiao()*Double.parseDouble(rebates[9]));
			maps.put("lvdan",  play.getLvdan()*Double.parseDouble(rebates[10]));
			maps.put("lvshuang",  play.getLvshuang()*Double.parseDouble(rebates[11]));
			break;
		case "bbb":
			rebates = lotters.getRebate40().split(",");
			maps.put("hongdadan", play.getHongdadan()* Double.parseDouble(rebates[0]));
			maps.put("hongdashuang",  play.getHongdashuang()* Double.parseDouble(rebates[1]));
			maps.put("hongxiaodan", play.getHongxiaodan()* Double.parseDouble(rebates[2]));
			maps.put("hongxiaoshuang",  play.getHongxiaoshuang()*Double.parseDouble(rebates[3]));
			maps.put("landadan",  play.getLandadan()*Double.parseDouble(rebates[4]));
			maps.put("landashuang",  play.getLandashuang()*Double.parseDouble(rebates[5]));
			maps.put("lanxiaodan",  play.getLanxiaodan()*Double.parseDouble(rebates[6]));
			maps.put("lanxiaoshuang",  play.getLanxiaoshuang()*Double.parseDouble(rebates[7]));
			maps.put("lvdadan",  play.getLvdadan()*Double.parseDouble(rebates[8]));
			maps.put("lvdashuang",  play.getLandashuang()*Double.parseDouble(rebates[9]));
			maps.put("lvxiaodan",  play.getLvxiaodan()*Double.parseDouble(rebates[10]));
			maps.put("lvxiaoshuang",  play.getLvxiaoshuang()*Double.parseDouble(rebates[11]));
			break;
		}
		String maxKey = "";
		Collection<Double> map = maps.values();
		Object[] obj = map.toArray();
		Arrays.sort(obj);
		Object minVal = obj[obj.length - 1];
		for (String key : maps.keySet()) {
			double val = maps.get(key);
			if ((Double) minVal == val) {
				maxKey = key;
			}
		}
		System.out.println("玩法：" + cplay + "  属性中奖最多的值： " + maxKey);
		return maxKey;
	}
	
	/**
	 * 
	 * 方法名：maxAttributesfk3 描述： sfk3下注中奖最高的玩法 下注最多的属性 TODO 参数： @param cplay1
	 * 参数： @return
	 * 
	 * @return: String
	 */
	public String maxAttributeJnd28(String cplay, PlayCount play, Lotter lotters) throws Exception{
		Map<String, Double> maps = new HashMap<String, Double>();
		String[] rebates = {};
		switch (cplay) {
		case "hunhe":
			rebates = lotters.getRebate1().split(",");
			maps.put("da", play.getDa() * Double.parseDouble(rebates[0]));
			maps.put("xiao", play.getXiao() * Double.parseDouble(rebates[1]));
			maps.put("dan", play.getDan() * Double.parseDouble(rebates[2]));
			maps.put("shuang", play.getShuang() * Double.parseDouble(rebates[3]));
			maps.put("dadan", play.getDadan() * Double.parseDouble(rebates[4]));
			maps.put("dashuang", play.getDashuang() * Double.parseDouble(rebates[5]));
			maps.put("xiaodan", play.getXiaodan() * Double.parseDouble(rebates[6]));
			maps.put("xiaoshuang", play.getXiaoshuang() * Double.parseDouble(rebates[7]));
			maps.put("jida", play.getJida() * Double.parseDouble(rebates[8]));
			maps.put("jixiao", play.getJixiao() * Double.parseDouble(rebates[9]));
			break;
		case "tema":
		case "tmb3":
			switch (cplay) {
			case "tema":
				rebates = lotters.getRebate2().split(",");
				break;
			case "tmb3":
				rebates = lotters.getRebate3().split(",");
				break;
			}
			lotterAttr12(rebates, maps,play);
			break;
		case "bs":
			rebates = lotters.getRebate4().split(",");
			maps.put("hongbo", play.getSlhtx() * Double.parseDouble(rebates[0]));
			maps.put("lvbo", play.getSlhtx() * Double.parseDouble(rebates[1]));
			maps.put("lanbo", play.getSlhtx() * Double.parseDouble(rebates[2]));
			break;
		case "bz":
			rebates = lotters.getRebate5().split(",");
			maps.put("bz", play.getBaozi() * Double.parseDouble(rebates[0]));
			break;
		}
		String maxKey = "";
		Collection<Double> map = maps.values();
		Object[] obj = map.toArray();
		Arrays.sort(obj);
		Object minVal = obj[obj.length - 1];
		for (String key : maps.keySet()) {
			double val = maps.get(key);
			if ((Double) minVal == val) {
				maxKey = key;
			}
		}
		System.out.println("玩法：" + cplay + "  属性中奖最多的值： " + maxKey);
		return maxKey;
	}
	

	/**
	 * 
	   *   方法名：lotterAttr12   
	   *   描述：   加拿大28 特码以及特码包3                    TODO   
	   *   参数：    @param rebates
	   *   参数：    @param maps
	   *   参数：    @param play 
	 * @return: void
	 */
	public void lotterAttr12(String[] rebates, Map<String, Double> maps, PlayCount play) {
		maps.put("d1q", play.getD1q()* Double.parseDouble(rebates[0]));
		maps.put("d2q",  play.getD2q()* Double.parseDouble(rebates[1]));
		maps.put("d3q", play.getD3q()* Double.parseDouble(rebates[2]));
		maps.put("d4q",  play.getD4q()*Double.parseDouble(rebates[3]));
		maps.put("d5q",  play.getD5q()*Double.parseDouble(rebates[4]));
		maps.put("d6q",  play.getD6q()*Double.parseDouble(rebates[5]));
		maps.put("d7q",  play.getD7q()*Double.parseDouble(rebates[6]));
		maps.put("d8q",  play.getD8q()*Double.parseDouble(rebates[7]));
		maps.put("d9q",  play.getD9q()*Double.parseDouble(rebates[8]));
		maps.put("d10q",  play.getD10q()*Double.parseDouble(rebates[9]));
		maps.put("d11q",  play.getD11q()*Double.parseDouble(rebates[10]));
		maps.put("d12q",  play.getD12q()*Double.parseDouble(rebates[11]));
		maps.put("d13q",  play.getD13q()*Double.parseDouble(rebates[12]));
		maps.put("d14q",  play.getD14q()*Double.parseDouble(rebates[13]));
		maps.put("d15q",  play.getD15q()*Double.parseDouble(rebates[14]));
		maps.put("d16q",  play.getD16q()*Double.parseDouble(rebates[15]));
		maps.put("d17q",  play.getD17q()*Double.parseDouble(rebates[16]));
		maps.put("d18q",  play.getD18q()*Double.parseDouble(rebates[17]));
		maps.put("d19q",  play.getD19q()*Double.parseDouble(rebates[18]));
		maps.put("d20q",  play.getD20q()*Double.parseDouble(rebates[19]));
		maps.put("d21q",  play.getD21q()*Double.parseDouble(rebates[20]));
		maps.put("d22q",  play.getD22q()*Double.parseDouble(rebates[21]));
		maps.put("d23q",  play.getD23q()*Double.parseDouble(rebates[22]));
		maps.put("d24q",  play.getD24q()*Double.parseDouble(rebates[23]));
		maps.put("d25q",  play.getD25q()*Double.parseDouble(rebates[24]));
		maps.put("d26q",  play.getD26q()*Double.parseDouble(rebates[25]));
		maps.put("d27q",  play.getD27q()*Double.parseDouble(rebates[26]));
		maps.put("d28q",  play.getD27q()*Double.parseDouble(rebates[27]));
	}

	/**
	 * 
	   *   方法名：lotterAttr7  
	   *   描述：                       TODO   
	   *   参数：    @param rebates
	   *   参数：    @param maps
	   *   参数：    @param play 
	 * @return: void
	 */
	private void lotterAttr7(String[] rebates, Map<String, Double> maps, PlayCount play) throws Exception{
		maps.put("d1q", play.getD1q()* Double.parseDouble(rebates[0]));
		maps.put("d2q",  play.getD2q()* Double.parseDouble(rebates[1]));
		maps.put("d3q", play.getD3q()* Double.parseDouble(rebates[2]));
		maps.put("d4q",  play.getD4q()*Double.parseDouble(rebates[3]));
		maps.put("d5q",  play.getD5q()*Double.parseDouble(rebates[4]));
		maps.put("d6q",  play.getD6q()*Double.parseDouble(rebates[5]));
		maps.put("d7q",  play.getD7q()*Double.parseDouble(rebates[6]));
		maps.put("d8q",  play.getD8q()*Double.parseDouble(rebates[7]));
		maps.put("d9q",  play.getD9q()*Double.parseDouble(rebates[8]));
		maps.put("d10q",  play.getD10q()*Double.parseDouble(rebates[9]));
		maps.put("d11q",  play.getD11q()*Double.parseDouble(rebates[10]));
		maps.put("d12q",  play.getD12q()*Double.parseDouble(rebates[11]));
		maps.put("d13q",  play.getD13q()*Double.parseDouble(rebates[12]));
		maps.put("d14q",  play.getD14q()*Double.parseDouble(rebates[13]));
		maps.put("d15q",  play.getD15q()*Double.parseDouble(rebates[14]));
		maps.put("d16q",  play.getD16q()*Double.parseDouble(rebates[15]));
		maps.put("d17q",  play.getD17q()*Double.parseDouble(rebates[16]));
		maps.put("d18q",  play.getD18q()*Double.parseDouble(rebates[17]));
		maps.put("d19q",  play.getD19q()*Double.parseDouble(rebates[18]));
		maps.put("d20q",  play.getD20q()*Double.parseDouble(rebates[19]));
		maps.put("d21q",  play.getD21q()*Double.parseDouble(rebates[20]));
		maps.put("d22q",  play.getD22q()*Double.parseDouble(rebates[21]));
		maps.put("d23q",  play.getD23q()*Double.parseDouble(rebates[22]));
		maps.put("d24q",  play.getD24q()*Double.parseDouble(rebates[23]));
		maps.put("d25q",  play.getD25q()*Double.parseDouble(rebates[24]));
		maps.put("d26q",  play.getD26q()*Double.parseDouble(rebates[25]));
		maps.put("d27q",  play.getD27q()*Double.parseDouble(rebates[26]));
		maps.put("d28q",  play.getD28q()*Double.parseDouble(rebates[27]));
		maps.put("d29q",  play.getD29q()*Double.parseDouble(rebates[28]));
		maps.put("d30q",  play.getD30q()*Double.parseDouble(rebates[29]));
		maps.put("d31q",  play.getD31q()*Double.parseDouble(rebates[30]));
		maps.put("d32q",  play.getD32q()*Double.parseDouble(rebates[31]));
		maps.put("d33q",  play.getD33q()*Double.parseDouble(rebates[32]));
		maps.put("d34q",  play.getD34q()*Double.parseDouble(rebates[33]));
		maps.put("d35q",  play.getD35q()*Double.parseDouble(rebates[34]));
		maps.put("d36q",  play.getD36q()*Double.parseDouble(rebates[35]));
		maps.put("d37q",  play.getD37q()*Double.parseDouble(rebates[36]));
		maps.put("d38q",  play.getD38q()*Double.parseDouble(rebates[37]));
		maps.put("d39q",  play.getD39q()*Double.parseDouble(rebates[38]));
		maps.put("d40q",  play.getD40q()*Double.parseDouble(rebates[39]));
		maps.put("d41q",  play.getD41q()*Double.parseDouble(rebates[40]));
		maps.put("d42q",  play.getD42q()*Double.parseDouble(rebates[41]));
		maps.put("d43q",  play.getD43q()*Double.parseDouble(rebates[42]));
		maps.put("d44q",  play.getD44q()*Double.parseDouble(rebates[43]));
		maps.put("d45q",  play.getD45q()*Double.parseDouble(rebates[44]));
		maps.put("d46q",  play.getD46q()*Double.parseDouble(rebates[45]));
		maps.put("d47q",  play.getD47q()*Double.parseDouble(rebates[46]));
		maps.put("d48q",  play.getD48q()*Double.parseDouble(rebates[47]));
		maps.put("d49q",  play.getD49q()*Double.parseDouble(rebates[48]));
	}

	/**
	 * 
	   *   方法名：lotterAttr8   
	   *   描述：                       TODO   
	   *   参数：    @param rebates
	   *   参数：    @param maps
	   *   参数：    @param play 
	 * @return: void
	 */
	private void lotterAttr8(String[] rebates, Map<String, Double> maps, PlayCount play) throws Exception{
		maps.put("shu", play.getShu()* Double.parseDouble(rebates[0]));
		maps.put("niu",  play.getNiu()* Double.parseDouble(rebates[1]));
		maps.put("hu", play.getHu()* Double.parseDouble(rebates[2]));
		maps.put("tu",  play.getTu()*Double.parseDouble(rebates[3]));
		maps.put("longs",  play.getLongs()*Double.parseDouble(rebates[4]));
		maps.put("she",  play.getShe()*Double.parseDouble(rebates[5]));
		maps.put("ma",  play.getMa()*Double.parseDouble(rebates[6]));
		maps.put("yang",  play.getYang()*Double.parseDouble(rebates[7]));
		maps.put("hou",  play.getHou()*Double.parseDouble(rebates[8]));
		maps.put("ji",  play.getJi()*Double.parseDouble(rebates[9]));
		maps.put("gou",  play.getGou()*Double.parseDouble(rebates[10]));
		maps.put("zhu",  play.getZhu()*Double.parseDouble(rebates[11]));
	}

	/**
	 * 
	   *   方法名：lotterAttr9   
	   *   描述：                       TODO   
	   *   参数：    @param rebates
	   *   参数：    @param maps
	   *   参数：    @param play 
	 * @return: void
	 */
	private void lotterAttr9(String[] rebates, Map<String, Double> maps, PlayCount play) throws Exception{
		maps.put("dan", play.getDan()* Double.parseDouble(rebates[0]));
		maps.put("shuang",  play.getShuang()* Double.parseDouble(rebates[1]));
		maps.put("da", play.getDa()* Double.parseDouble(rebates[2]));
		maps.put("xiao",  play.getXiao()*Double.parseDouble(rebates[3]));
	}

	/**
	 * 
	   *   方法名：lotterAttr10   
	   *   描述：                       TODO   
	   *   参数：    @param rebates
	   *   参数：    @param maps
	   *   参数：    @param play 
	 * @return: void
	 */
	private void lotterAttr10(String[] rebates, Map<String, Double> maps, PlayCount play) throws Exception{
		maps.put("d1q", play.getD1q()* Double.parseDouble(rebates[0]));
		maps.put("d2q",  play.getD2q()* Double.parseDouble(rebates[1]));
		maps.put("d3q", play.getD3q()* Double.parseDouble(rebates[2]));
		maps.put("d4q",  play.getD4q()*Double.parseDouble(rebates[3]));
		maps.put("d5q",  play.getD5q()*Double.parseDouble(rebates[4]));
		maps.put("d6q",  play.getD6q()*Double.parseDouble(rebates[5]));
		maps.put("d7q",  play.getD7q()*Double.parseDouble(rebates[6]));
		maps.put("d8q",  play.getD8q()*Double.parseDouble(rebates[7]));
		maps.put("d9q",  play.getD9q()*Double.parseDouble(rebates[8]));
		maps.put("d10q",  play.getD10q()*Double.parseDouble(rebates[9]));
		
	}
	
	/**
	 * 
	   *   方法名：lotterAttr11   
	   *   描述：                       TODO   
	   *   参数：    @param rebates
	   *   参数：    @param maps
	   *   参数：    @param play 
	 * @return: void
	 */
	private void lotterAttr11(String[] rebates, Map<String, Double> maps, PlayCount play) throws Exception{
		maps.put("d1q", play.getD1q()* Double.parseDouble(rebates[0]));
		maps.put("d2q",  play.getD2q()* Double.parseDouble(rebates[0]));
		maps.put("d3q", play.getD3q()* Double.parseDouble(rebates[0]));
		maps.put("d4q",  play.getD4q()*Double.parseDouble(rebates[0]));
		maps.put("d5q",  play.getD5q()*Double.parseDouble(rebates[0]));
		maps.put("d6q",  play.getD6q()*Double.parseDouble(rebates[0]));
		maps.put("d7q",  play.getD7q()*Double.parseDouble(rebates[0]));
		maps.put("d8q",  play.getD8q()*Double.parseDouble(rebates[0]));
		maps.put("d9q",  play.getD9q()*Double.parseDouble(rebates[0]));
		maps.put("d10q",  play.getD10q()*Double.parseDouble(rebates[0]));
		maps.put("d11q",  play.getD11q()*Double.parseDouble(rebates[0]));
		maps.put("d12q",  play.getD12q()*Double.parseDouble(rebates[0]));
		maps.put("d13q",  play.getD13q()*Double.parseDouble(rebates[0]));
		maps.put("d14q",  play.getD14q()*Double.parseDouble(rebates[0]));
		maps.put("d15q",  play.getD15q()*Double.parseDouble(rebates[0]));
		maps.put("d16q",  play.getD16q()*Double.parseDouble(rebates[0]));
		maps.put("d17q",  play.getD17q()*Double.parseDouble(rebates[0]));
		maps.put("d18q",  play.getD18q()*Double.parseDouble(rebates[0]));
		maps.put("d19q",  play.getD19q()*Double.parseDouble(rebates[0]));
		maps.put("d20q",  play.getD20q()*Double.parseDouble(rebates[0]));
		maps.put("d21q",  play.getD21q()*Double.parseDouble(rebates[0]));
		maps.put("d22q",  play.getD22q()*Double.parseDouble(rebates[0]));
		maps.put("d23q",  play.getD23q()*Double.parseDouble(rebates[0]));
		maps.put("d24q",  play.getD24q()*Double.parseDouble(rebates[0]));
		maps.put("d25q",  play.getD25q()*Double.parseDouble(rebates[0]));
		maps.put("d26q",  play.getD26q()*Double.parseDouble(rebates[0]));
		maps.put("d27q",  play.getD27q()*Double.parseDouble(rebates[0]));
		maps.put("d28q",  play.getD28q()*Double.parseDouble(rebates[0]));
		maps.put("d29q",  play.getD29q()*Double.parseDouble(rebates[0]));
		maps.put("d30q",  play.getD30q()*Double.parseDouble(rebates[0]));
		maps.put("d31q",  play.getD31q()*Double.parseDouble(rebates[0]));
		maps.put("d32q",  play.getD32q()*Double.parseDouble(rebates[0]));
		maps.put("d33q",  play.getD33q()*Double.parseDouble(rebates[0]));
		maps.put("d34q",  play.getD34q()*Double.parseDouble(rebates[0]));
		maps.put("d35q",  play.getD35q()*Double.parseDouble(rebates[0]));
		maps.put("d36q",  play.getD36q()*Double.parseDouble(rebates[0]));
		maps.put("d37q",  play.getD37q()*Double.parseDouble(rebates[0]));
		maps.put("d38q",  play.getD38q()*Double.parseDouble(rebates[0]));
		maps.put("d39q",  play.getD39q()*Double.parseDouble(rebates[0]));
		maps.put("d40q",  play.getD40q()*Double.parseDouble(rebates[0]));
		maps.put("d41q",  play.getD41q()*Double.parseDouble(rebates[0]));
		maps.put("d42q",  play.getD42q()*Double.parseDouble(rebates[0]));
		maps.put("d43q",  play.getD43q()*Double.parseDouble(rebates[0]));
		maps.put("d44q",  play.getD44q()*Double.parseDouble(rebates[0]));
		maps.put("d45q",  play.getD45q()*Double.parseDouble(rebates[0]));
		maps.put("d46q",  play.getD46q()*Double.parseDouble(rebates[0]));
		maps.put("d47q",  play.getD47q()*Double.parseDouble(rebates[0]));
		maps.put("d48q",  play.getD48q()*Double.parseDouble(rebates[0]));
		maps.put("d49q",  play.getD49q()*Double.parseDouble(rebates[0]));
	}


	/**
	 * cqssc 1-5球
	 * 方法名：lotterAttr0 描述： 下注属性统计直选 TODO 参数： @param rebates 参数： @param maps
	 * 
	 * @return: void
	 */
	public void lotterAttr0(String[] rebates, Map<String, Double> maps,PlayCount play) throws Exception{
		maps.put("d1q", play.getD1q()* Double.parseDouble(rebates[0]));
		maps.put("d2q",  play.getD2q()* Double.parseDouble(rebates[0]));
		maps.put("d3q", play.getD3q()* Double.parseDouble(rebates[0]));
		maps.put("d4q",  play.getD4q()*Double.parseDouble(rebates[0]));
		maps.put("d5q",  play.getD5q()*Double.parseDouble(rebates[0]));
		maps.put("d6q",  play.getD6q()*Double.parseDouble(rebates[0]));
		maps.put("d7q",  play.getD7q()*Double.parseDouble(rebates[0]));
		maps.put("d8q",  play.getD8q()*Double.parseDouble(rebates[0]));
		maps.put("d9q",  play.getD9q()*Double.parseDouble(rebates[0]));
		maps.put("d10q",  play.getD10q()*Double.parseDouble(rebates[0]));
	}
	
	/**
	 * bjpk10 - 6-10 名
	 * 方法名：lotterAttr 描述： 下注属性统计1-5q TODO 参数： @param rebates 参数： @param maps
	 * @param play 
	 * 
	 * @return: void
	 */
	public void lotterAttr1(String[] rebates, Map<String, Double> maps, PlayCount play) throws Exception{
		maps.put("d1q", play.getD1q()* Double.parseDouble(rebates[4]));
		maps.put("d2q",  play.getD2q()* Double.parseDouble(rebates[5]));
		maps.put("d3q", play.getD3q()* Double.parseDouble(rebates[6]));
		maps.put("d4q",  play.getD4q()*Double.parseDouble(rebates[7]));
		maps.put("d5q",  play.getD5q()*Double.parseDouble(rebates[8]));
		maps.put("d6q",  play.getD6q()*Double.parseDouble(rebates[9]));
		maps.put("d7q",  play.getD7q()*Double.parseDouble(rebates[10]));
		maps.put("d8q",  play.getD8q()*Double.parseDouble(rebates[11]));
		maps.put("d9q",  play.getD9q()*Double.parseDouble(rebates[12]));
		maps.put("d10q",  play.getD10q()*Double.parseDouble(rebates[13]));
	}
	
	
	/**
	 * bjpk10 1-5名
	 * 方法名：lotterAttr 描述： 下注属性统计1-5q TODO 参数： @param rebates 参数： @param maps
	 * @param play 
	 * 
	 * @return: void
	 */
	public void lotterAttr3(String[] rebates, Map<String, Double> maps, PlayCount play) throws Exception{
		maps.put("d1q", play.getD1q()* Double.parseDouble(rebates[6]));
		maps.put("d2q",  play.getD2q()* Double.parseDouble(rebates[7]));
		maps.put("d3q", play.getD3q()* Double.parseDouble(rebates[8]));
		maps.put("d4q",  play.getD4q()*Double.parseDouble(rebates[9]));
		maps.put("d5q",  play.getD5q()*Double.parseDouble(rebates[10]));
		maps.put("d6q",  play.getD6q()*Double.parseDouble(rebates[11]));
		maps.put("d7q",  play.getD7q()*Double.parseDouble(rebates[12]));
		maps.put("d8q",  play.getD8q()*Double.parseDouble(rebates[13]));
		maps.put("d9q",  play.getD9q()*Double.parseDouble(rebates[14]));
		maps.put("d10q",  play.getD10q()*Double.parseDouble(rebates[15]));
	}

	/**
	 * 3fk3 
	 * 方法名：lotterAttr5 描述： 下注属性统计直选 TODO 参数： @param rebates 参数： @param maps
	 * 
	 * @return: void
	 */
	public void lotterAttr5(String[] rebates, Map<String, Double> maps,PlayCount play) throws Exception{
		maps.put("d1q", play.getD1q()* Double.parseDouble(rebates[0]));
		maps.put("d2q",  play.getD2q()* Double.parseDouble(rebates[0]));
		maps.put("d3q", play.getD3q()* Double.parseDouble(rebates[0]));
		maps.put("d4q",  play.getD4q()*Double.parseDouble(rebates[0]));
		maps.put("d5q",  play.getD5q()*Double.parseDouble(rebates[0]));
		maps.put("d6q",  play.getD6q()*Double.parseDouble(rebates[0]));
	}
	
	/**
	 * 3fk3
	 * 方法名：lotterAttr5 描述： 下注属性统计直选 TODO 参数： @param rebates 参数： @param maps
	 * 
	 * @return: void
	 */
	public void lotterAttr6(String[] rebates, Map<String, Double> maps,PlayCount play) throws Exception{
		maps.put("d1q", play.getD1q()* Double.parseDouble(rebates[0]));
		maps.put("d2q",  play.getD2q()* Double.parseDouble(rebates[1]));
		maps.put("d3q", play.getD3q()* Double.parseDouble(rebates[2]));
		maps.put("d4q",  play.getD4q()*Double.parseDouble(rebates[3]));
		maps.put("d5q",  play.getD5q()*Double.parseDouble(rebates[4]));
		maps.put("d6q",  play.getD6q()*Double.parseDouble(rebates[5]));
	}

}
