package com.ja.dao;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.ja.domain.Operationlog;

public interface OperationlogMapper {

	/**添加操作日志*/
	Integer addOperationlog(@Param("o")Operationlog o);

	/**查询所有的操作记录*/
	List<Operationlog> getAllOperationlog();
	
	/**根据条件查询操作记录*/
	List<Operationlog> findOperationlog(@Param("o")Operationlog o);
	
	/**删除操作记录*/
	Integer delOperationlog(Integer id);

}


