package com.ja.domain;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class Agents implements Serializable{
	
	private static final long serialVersionUID = 2450137545240446605L;

	private Integer user_id; //用户id
	
	private String user_name; //用户帐号
	
	private Integer agent_grade; //代理等级
	
	private Double balance; //用户余额
	
	private Integer parent_id; //上级id
	
	private List<Agents> child_list = new ArrayList<Agents>();
	
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	
	public Integer getUser_id() {
		return user_id;
	}

	public void setUser_id(Integer user_id) {
		this.user_id = user_id;
	}

	public String getUser_name() {
		return user_name;
	}

	public void setUser_name(String user_name) {
		this.user_name = user_name;
	}

	public Integer getAgent_grade() {
		return agent_grade;
	}

	public void setAgent_grade(Integer agent_grade) {
		this.agent_grade = agent_grade;
	}

	public Double getBalance() {
		return balance;
	}

	public void setBalance(Double balance) {
		this.balance = balance;
	}

	public Integer getParent_id() {
		return parent_id;
	}

	public void setParent_id(Integer parent_id) {
		this.parent_id = parent_id;
	}

	public List<Agents> getChild_list() {
		return child_list;
	}

	public void setChild_list(List<Agents> child_list) {
		this.child_list = child_list;
	}

	public Agents() {
		super();
	}

	@Override
	public String toString() {
		return "Agents [user_id=" + user_id + ", user_name=" + user_name + ", agent_grade=" + agent_grade + ", balance="
				+ balance + ", parent_id=" + parent_id + ", child_list=" + child_list + "]";
	}
	
}
