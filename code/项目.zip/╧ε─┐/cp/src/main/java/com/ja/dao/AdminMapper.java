package com.ja.dao;

import org.apache.ibatis.annotations.Param;

import com.ja.domain.Admin;

/**
 * 项目名称：cp   
 * 类名称：AdminMapper.java   
 * 类描述：   网站各种配置状态相关类
 * 创建人：   GL
 * 创建时间：2019年2月13日 上午10:01:09   
 * @version v1.0.0
 */
public interface AdminMapper {
	
	/**
	 * 方法名：findAllConfig 
	 * 描述：    查询所有的系统配置                   TODO
	 * 参数：    @return 
	 * @return: Admin
	 */
	Admin findAllConfig();
	
	/**
	 * 聊天室开启或关闭
	 * @param flag 开启或关闭
	 * @return
	 */
	int updateChatRoom(Integer flag);
	
	/**
	 * 方法名：messageFlag 
	 * 描述：                       TODO
	 * 参数：    @param state
	 * 参数：    @return 
	 * @return: int
	 */
	int messageFlag(Integer state);
	

	/**首页轮播图设置*/
	int update(@Param("admin")Admin admin);

	/**首页通知设置*/
	int updateTongzhi(String notice);
	
	/*
	 * 系统设置
	 * 
	 */

	/**网站维护设置*/
	int upwangzhanflag(Integer weihukaiguan);

	/**网站维护原因*/
	int upweihuyuanyin(String weihuyuanyin);

	/**帐变开关*/
	int upzhangbianflag(Integer zhangbiankaiguan);

	/**白名单开关*/
	int upbaimingdanflag(Integer baimingdankaiguan);
	
	/**跟单-第几单开始跟单以及倍数 */
	int updateGendanDate(@Param("count") Integer count);

	/**跟单-合买*/
	int updateFlag(@Param("parameter")String parameter,@Param("flag")Integer flag);

	/**试玩账号*/
	Integer getCplay();
	
	/**修改反水规则内容*/
	int defectionRuleUp(@Param("admin")Admin admin);
	
	/**签到规则设置*/
	int updateData(@Param("a")Admin admin);

	/**红包规则设置*/
	int updateSystemEnvelope(@Param("a")Admin admin);
	
	/**红包所需*/
	Admin getRedPackSx();

	/**红包资格*/
	Admin getTongJi(@Param("id")Integer id, @Param("date1")String date1,@Param("date2")String date2);

	/**修改或开启关闭转盘*/
	int updateLuckyFlag(@Param("a")Admin admin);
	
	/**修改下注单注金额*/
	int modifyBuy(@Param("a")Admin admin);
	
	/**
	 * 跟新提款手续费-次数手续费设置
	 * @param admin 设置信息
	 * @return
	 */
	int updateDrawingSteup(Admin admin);
	
	/**
	 * 查询表数据数量
	 * @param dataBaseName 表名
	 */
	Integer findDatabaseCounts(@Param("dataBaseName")String dataBaseName);
	
	/**
	 * 查询满足清理条件的表，数据id
	 * @param dataBaseName 表名
	 */
	Integer findDatabaseLimit(@Param("dataBaseName")String dataBaseName);

	/**
	 * 批量删除数据
	 * @param id 删除的最大的id
	 * @param dataBaseName 删除的表名
	 */
	int deleteData(@Param("id")Integer id, @Param("dataBaseName") String dataBaseName); 


}


