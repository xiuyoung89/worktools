package com.ja.domain;

import java.io.Serializable;

public class LuckyRecord implements Serializable{
	
    /**
	 * 
	 */
	private static final long serialVersionUID = -2518923502637322863L;

	private Integer id;//幸运转盘记录
    
    private String name;//会员帐号
    
    private String type;//中奖类型

    private Double money;//中奖金额
    
    private Integer scope;//中奖圈数;

    private String createTime;//创建时间

    private Integer userid;//用户id

    
    public static long getSerialversionuid() {
		return serialVersionUID;
	}
    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public Double getMoney() {
		return money;
	}

	public void setMoney(Double money) {
		this.money = money;
	}

	public Integer getScope() {
		return scope;
	}

	public void setScope(Integer scope) {
		this.scope = scope;
	}

	public String getCreateTime() {
		return createTime;
	}

	public void setCreateTime(String createTime) {
		this.createTime = createTime;
	}

	public Integer getUserid() {
		return userid;
	}

	public void setUserid(Integer userid) {
		this.userid = userid;
	}

	public LuckyRecord() {
		super();
	}

	@Override
	public String toString() {
		return "LuckyRecord [id=" + id + ", name=" + name + ", type=" + type + ", money=" + money + ", scope=" + scope
				+ ", createTime=" + createTime + ", userid=" + userid + "]";
	}
}