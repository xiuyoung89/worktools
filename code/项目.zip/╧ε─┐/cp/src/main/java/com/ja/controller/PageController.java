package com.ja.controller;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.ja.domain.LotterExample;
import com.ja.domain.UpDataPage;
import com.ja.domain.User;
import com.ja.sevice.ILotteryService;
import com.ja.sevice.InfoNoticeService;
import com.ja.util.BjlUtil;
import com.ja.util.JsonResult;

@Controller
public class PageController {
	
	@Autowired
	private ILotteryService lotterService;
	
	@Autowired
	private InfoNoticeService infoNotiService;
	public static Map<String, String> is = Collections.synchronizedMap(new HashMap<String, String>());
	public static List<UpDataPage> list = null;
	/**1 代表只读取一次   0代表每次读取*/
	public final static  Integer open =0;
	
	public void initialization() {
	}
	
	@ResponseBody
	@RequestMapping("/error")
	public JsonResult error() {
		/*** 维护页面*/
		if(is.get("error") != null && open == 1) 
			return new JsonResult("error",is.get("error"));
		else 
			is.put("error", readTheFrontendCode("error"));
			return new JsonResult("error",is.get("error"));
	}
	/**long startTime = System.currentTimeMillis();  
	 * long endTime = System.currentTimeMillis();  
	   float seconds = (endTime - startTime) / 1000F;  
	   System.out.println(Float.toString(seconds) + " seconds.   首页");  
	 */
	
	/** 查询首页页面所有信息- */
	@ResponseBody
	@RequestMapping("/xfm")
	public JsonResult xfm(HttpSession session,String page) {
		User user = (User)session.getAttribute("user");
		String yqm = (String)session.getAttribute("refCode");
		if(page == null || "".equals(page)) {
			return new JsonResult(null,"请正确填写参数");
		}
		if(list == null) {
			list = infoNotiService.updatePagesc(2);
		}
		String string = null;
		String string2 = null;
		String str = "1";
		for(UpDataPage p : list) {
			if(p.getPage().equals(page)) {
				if(is.get(p.getPage()) != null && open == 1) {
					return new JsonResult(str,is.get(p.getPage()));
				}else {
					if("sy".equals(p.getPage())) {
						is.put(p.getPage(),  sy(user,yqm));
					} else if("gc".equals(p.getPage())) {
						is.put(p.getPage(),  gc());
					} else if("zs".equals(p.getPage())) {
						is.put(p.getPage(),  zs());
					} else if("kj".equals(p.getPage())) {
						is.put(p.getPage(), kj(session));
					}else {
						is.put(p.getPage(), readTheFrontendCode(p.getPage()));
					}
					return new JsonResult(str,is.get(p.getPage()));
				}
			}
		}
		new Integer("没有找到这个页面----------------"+page);
		return new JsonResult(str,string+string2);
	}
		
	/**
	 * 读取前端代码并返回
	 * @param name  文件名
	 * @return  如果读取成功则返回前端代码 字符串的形式 如果读取失败者返回null
	 */
	public static String readTheFrontendCode(String name) {
		return BjlUtil.readTheFrontendCode(name);
	}
	/**
	 * 返回首页页面
	 * @param user
	 * @param yqm
	 * @return
	 */
	public String sy(User user,String yqm) {
		List<LotterExample> lotterList = lotterService.getAllLotters();
		int[] arr=  {21,17,18,16,31,6,2,19,7,3,5,28,13,12,8,9,15};
		String string = "<style> .body .aaa li{display: block;width: 20%;float: left;} .body .aaa li a{font-size:12px ;display: block;line-height:41px;} .body .aaa li a img{height: 50px;width: 50px;} .fl{margin: 0 5px;} #zjxx tr *{font-size: 13px;} #zjxx tr td:nth-child(1){padding-left: 10px;} #zjxx tr td:nth-child(2) span{color: red;} .icon { width: 1em; height: 1em; vertical-align: -0.15em; fill: currentColor; overflow: hidden; } #cai li{float: left;width: 33.3%;border-right:1px solid #E7E1E1;border-top:1px solid #E7E1E1;padding: 10px 0;height:100px;} .removeBr{border-right:1px solid white!important;} .bb{border-bottom:1px solid #E7E1E1;} #cai img{height:50px;} .modal-dialog { top:20%; } .div-c-chooseChatWrapper, .div-c-chooseChatWrapper > div { display:flex; align-items:center; } .div-c-chooseChatWrapper > div > span { margin-left:16px; } .modal-body .div-c-chooseChatWrapper + .div-c-chooseChatWrapper { border-top:1px solid #cecece; } .div-c-chooseChatWrapper { justify-content:space-between; padding:2vh; } .div-c-chooseChatWrapper svg { width:6vh; height:6vh; max-width:40px; max-height:40px; } .span-pointMoney { color:red!important; font-weight: bold; font-size:13px!important; } #span-i-websiteTitle { white-space: nowrap; } #cai li.cz, .div-c-chooseChatWrapper { cursor: pointer; } #table-i-lotterInfo td { text-align: left; } .modal { position: absolute; } body { padding-right:0!important; } *.modal-open { overflow-y: auto; padding-right: 0 !important; } .b1white { cursor: pointer; } #cai1 img{height:4rem;max-width:4.5rem;} /* #cai1 .col-xs-6{padding:13px;border:1px solid #F2F2F2} #cai1 .col-xs-4,#cai1 .col-xs-8{padding:0;} #cai1 .col-xs-8{text-align: left;padding-left:10px;} */ #cai1 .name{font-size:15px;} #cai1 .des{font-size:12px;color:#AEAEAE;line-height:20px;} #cai1 td{padding:10px 0px 10px 5px;border-bottom:1px solid #F2F2F2} #cai1 tr td:nth-child(3){border-left:1px solid #F2F2F2} #cai1 tr:nth-child(1) td{border-top:1px solid #F2F2F2} #cai1 tr td:nth-child(1),#cai1 tr td:nth-child(3){width: 18%;} #cai1 tr td:nth-child(2),#cai1 tr td:nth-child(4){width: 32%;text-align: left;} </style>" + 
				"<div class='wapper' id='sy'>" + 
				"	<div class=\"main clearfix\">\r\n" + 
				"		<div class=\"bg-theme col-xs-12 col-sm-4 col-sm-offset-4 text-center top\" style=\"height: 50px;padding:0;position: fixed;\">\r\n" + 
				"			<div id='head-message' style=\"height: 50px;position: relative;\">\r\n"+
				"			</div>\r\n"+
				"		</div>\r\n" + 
				"	</div>\r\n" + 
				"	<div class=\"col-xs-12 col-sm-4 col-sm-offset-4 text-center body clearfix\" style=\"padding: 0;\">\r\n" + 
				"		<!-- 正文开始 -->\r\n" + 
				"		<div id=\"myCarousel\" class=\"carousel slide\" style=\"margin:0px;\">\r\n" + 
				"		    <ol class=\"carousel-indicators\">\r\n" + 
				"		    </ol>   \r\n" + 
				"		    <div class=\"carousel-inner\">\r\n" + 
				"		    </div>\r\n" + 
				"		    <a class=\"carousel-control left\" href=\"#myCarousel\" data-slide=\"prev\">&lsaquo;</a>\r\n" + 
				"		    <a class=\"carousel-control right\" href=\"#myCarousel\" data-slide=\"next\">&rsaquo;</a>\r\n" + 
				"		</div>\r\n" + 
				"		<div id=\"noticeWrapper\" style=\"height: 30px;background: white;overflow:hidden;width:100%;position: relative;\">\r\n" + 
				"			<span style=\"font-size: 20px;background: white;z-index: 10;position:absolute;top: 50%;left:0px; padding: 0 5px;transform:translateY(-50%);display:inline-flex;align-items:center;\"><span style=\"font-size:12px;color: #059BF3;margin-right:6px;\">公告</span><span class=\"speak glyphicon glyphicon-volume-up\" style=\"color: #059BF3;top:0px;\"></span></span>\r\n" + 
				"			<!-- <nobr id=\"test1\" style=\"position: fixed;margin-left: 100%;left: 0px;z-index:90;margin-top: -5px;\"> -->\r\n" + 
				/*"			<span id=\"span-i-webSiteNoticeScroll\" style=\"white-space:nowrap;margin-left: 40px;font-size: 13px;color: #059BF3;display:inline-block;position: relative;top:3px;transform:translateX(100%);\"></span>\r\n" + */
				"			<span style=\"white-space:nowrap;margin-left: 40px;font-size: 13px;color: #059BF3;display:inline-block;position: relative;top:3px;\" id=\"span-i-webSiteNoticeScroll\"></span>\r\n" + 
				"			<!-- </nobr> -->\r\n" + 
				"		</div>\r\n" + 
				"		<ul class=\"aaa clearfix\" style=\"width: 100%; margin-top: 10px;\">\r\n" + 
				"	\r\n" + 
				"			<li style=\"cursor: pointer;\"><a class=\"color-theme\"  id=\"li-cz\"> <img\r\n" + 
				"					src=\"/img/first/chongzhitixian.png\" /><br>充值/提款\r\n" + 
				"			</a></li>\r\n" + 
				"			<li><a class=\"color-theme\" id=\"a-i-zhuanpan\"> <img\r\n" + 
				"					src=\"/img/first/xyzp.png\" /><br>幸运转盘\r\n" + 
				"			</a></li>\r\n" + 
				"			<li><a class=\"color-theme\"  id=\"a-i-youhuiHref\"> <img\r\n" + 
				"					src=\"/img/first/yhhd.png\" /><br>优惠活动\r\n" + 
				"			</a></li>			\r\n" + 
				"			<li><a class=\"color-theme\" id=\"a-i-chatFlag\"> <img\r\n" + 
				"					src=\"/img/first/youhuihuodong.png\" /><br>在线交流\r\n" + 
				"			</a></li>\r\n" + 
				"			<li><a class=\"color-theme\" id=\"a-i-chooseKeFuType\"> <img\r\n" + 
				"					src=\"/img/first/zaixiankefu.png\" /><br>联系客服\r\n" + 
				"			</a></li>\r\n" + 
				"		</ul>\r\n" + 
				"		<div id=\"cai1\" class=\"clearfix\" style=\"width: 100%;\"> \r\n" + 
				"			<div style=\"text-align: left;\">\r\n" + 
				"				　<span class=\"glyphicon glyphicon-fire\" style=\"color: red;\"></span>\r\n" + 
				"				<strong> 热门彩种</strong>\r\n" + 
				"			</div>\r\n" + 
				"			<div id=\"rmcz\"><table style='width:100%;'><tr>\r\n";
						int x = 1;
						for(int i = 0;i<arr.length;i++) {
							for(LotterExample l : lotterList) {
								if(l.getId()==arr[i]){
									if(l.getState() == 0) {
										string +="<td class='"+l.getCname()+" gray'><img src='/img/caizhong/gray_"+l.getImg()+".png' /></td>\r\n" + 
												"<td class="+l.getCname()+"><span class='name'>"+l.getName()+"</span><br><span class='des'>"+l.getDes()+"</span></td>\r\n";
									}else {
										string +="<td class="+l.getCname()+"><img src='/img/caizhong/"+l.getImg()+".png' /></td>\r\n" + 
										"<td class="+l.getCname()+"><span class='name'>"+l.getName()+"</span><br><span class='des'>"+l.getDes()+"</span></td>\r\n";
									}
									if((x++)%2==0) {
										string +="<tr></tr>\r\n";
									}
								}
							}
						}
	   string +="			<td class='moreLotter'><img src='/img/caizhong/more.png' style='width:3.5rem;max-width:4rem;height:3.5rem;max-height:4rem;' /></td><td class=\"moreLotter\"><span class='name'>更多游戏</span></td></tr><table/>\r\n";
	   string +="			</div>\r\n" +
				"		</div>\r\n" + 
				"	</div>\r\n" + 
				"	\r\n";
	   string +="	<div class=\"col-xs-12 col-sm-4 col-sm-offset-4 div-c-lotterInfoWrapper\" style=\"margin-bottom: 10px;\">\r\n" + 
				"			　<span class=\"glyphicon glyphicon-tower\" style=\"color: orange;\"></span>\r\n" + 
				"			<strong> 最新中奖榜</strong>\r\n" + 
				"		</div>\r\n" + 
				"	<div class=\"col-xs-12 col-sm-4 col-sm-offset-4 div-c-lotterInfoWrapper\" id=\"zjxx\" style=\"z-index: -10;height: 358px;overflow: hidden;\">\r\n" + 
				"		<table id=\"table-i-lotterInfo\" style=\"touch-action: pan-y; user-select: none; -webkit-user-drag: none; -webkit-tap-highlight-color: rgba(0, 0, 0, 0); width: 100%;\">\r\n" + 
				"		<tbody></tbody>\r\n" + 
				"		</table>\r\n" + 
				"	</div>\r\n";
				if(yqm == null || user != null) {
					string +="		 <div class=\"col-xs-12 col-sm-4 col-sm-offset-4 download\" style=\"overflow:hidden;padding:0;padding-top:29px;position: fixed;bottom: 50px;left:0;background: url('/img/download-bg.png');height:60px;background-size:100% 60px; \">" + 
							"			<span class=\"glyphicon glyphicon-remove-sign\" style=\"color:white;padding-left: 3px;font-size:12px;\"></span>\r\n" + 
							"			<font style=\"color:white;padding-left: 0px;font-size:12px;\">下载APP，体验更多购彩乐趣</font>\r\n" + 
							"			<a href=\"/download.do\" class=\"fr\" target=\"_blank\" id=\"app_path\" style=\"background: white;border-radius: 3px;border:0;margin-right: 3px;padding:3px;font-size:12px;display: inline-block;\">安卓APP</a>" + 
							"			<a href=\"/download.do\" class=\"fr\" target=\"_blank\" id=\"ios_path\" style=\"background: white;border-radius: 3px;border:0;margin-right: 12px;padding:3px;font-size:12px;display: inline-block;\">苹果APP</a>" + 
							"		</div>\r\n";
				}
	   		string +="<div class=\"modal fade\" id=\"kefuModal\" role=\"dialog\" aria-labelledby=\"kefuModal\" aria-hidden=\"true\">\r\n" + 
				"    <div class=\"modal-dialog\" style=\"max-width:400px;\">\r\n" + 
				"        <div class=\"modal-content\">\r\n" + 
				"            <div class=\"modal-header\">\r\n" + 
				"                <h4 class=\"modal-title\" style=\"text-align: center;\" id=\"myModalLabel\">选择客服类型</h4>\r\n" + 
				"            </div>\r\n" + 
				"            <div class=\"modal-body\" style=\"padding-bottom:0;\">\r\n" + 
				"            	<div class=\"div-c-chooseChatWrapper\" data-type=\"kefu\">\r\n" + 
				"            		<div>\r\n" + 
				"            			<svg class=\"icon\" aria-hidden=\"true\" style=\"fill: #059BF3;\">\r\n" + 
				"					  	  <use xlink:href=\"#icon-kefu\"></use>\r\n" + 
				"						</svg>\r\n" + 
				"						<span>在线客服</span>\r\n" + 
				"            		</div>\r\n" + 
				"             			<svg class=\"icon\" aria-hidden=\"true\" style=\"fill: #059BF3;\">\r\n" + 
				"					  	  <use xlink:href=\"#icon-1202youjiantou\"></use>\r\n" + 
				"						</svg>           		\r\n" + 
				"            	</div>\r\n" + 
				"            </div>\r\n" + 
				"            <div class=\"modal-footer\" style=\"text-align: center;border-top:none;\">\r\n" + 
				"                <button type=\"button\" class=\"btn btn-default\" style=\"width:70%;\" data-dismiss=\"modal\">关闭</button>\r\n" + 
				"            </div>\r\n" + 
				"        </div><!-- /.modal-content -->\r\n" + 
				"    </div><!-- /.modal-dialog -->\r\n" + 
				"</div>	\r\n" + 
				"\r\n" + 
				"<div class=\"modal fade\" id=\"kefuModal1\" role=\"dialog\" aria-labelledby=\"kefuModal\" aria-hidden=\"true\">\r\n" + 
				"    <div class=\"modal-dialog\" style=\"max-width:300px;margin:0 auto;\">\r\n" + 
				"        <div class=\"modal-content\">\r\n" + 
				"            <div class=\"modal-header\">\r\n" + 
				"                <h4 class=\"modal-title\" style=\"text-align: center;\" id=\"myModalLabel\">温馨提示！</h4>\r\n" + 
				"            </div>\r\n" + 
				"            <div class=\"modal-body\" style=\"padding-bottom:0;\">\r\n" + 
				"            	<div class=\"div-c-chooseChatWrapper\" data-type=\"kefu\">\r\n" + 
				"            		<div style=\"font-size: 13px;\">当前聊天系统暂未开启，请稍后再试</div>         		\r\n" + 
				"            	</div>\r\n" + 
				"            </div>\r\n" + 
				"            <div class=\"modal-footer\" style=\"text-align: center;border-top:none;\">\r\n" + 
				"                <button type=\"button\" class=\"btn btn-default\" style=\"width:70%;\" data-dismiss=\"modal\">关闭</button>\r\n" + 
				"            </div>\r\n" + 
				"        </div><!-- /.modal-content -->\r\n" + 
				"    </div><!-- /.modal-dialog -->\r\n" + 
				"</div>	\r\n" + 
				"\r\n" + 
				"<div class=\"modal-div-fakeModal\" id=\"div-i-noticeGenDan\">\r\n" + 
				"	<div class=\"div-c-modalContent\">\r\n" + 
				"		<h3 class=\"fakemodal-title\"></h3>\r\n" + 
				"		<div class=\"fakemodal-content\"></div>\r\n" + 
				"		<div class=\"fakemodal-btnsGroup\"><button class=\"btn btn-default btn-class-closeFakeModal\">关闭</button></div>\r\n" + 
				"	</div>\r\n" + 
				"</div>		\r\n" + 
				"		<div class=\"modal-div-fakeModal\" id=\"div-i-notice\">\r\n" + 
				"		<div class=\"div-c-modalContent\">\r\n" + 
				"			<h3 class=\"fakemodal-title\"></h3>\r\n" + 
				"			<div class=\"fakemodal-content\"></div>\r\n" + 
				"			<div class=\"fakemodal-btnsGroup\"><button class=\"btn btn-default btn-class-closeFakeModal\">关闭</button></div>\r\n" + 
				"		</div>\r\n" + 
				"		</div>\r\n" + 
				"		</div>";
		String string2 ="<script>\r\n" + 
				  "	var allWidth=document.querySelector(\"body\").clientWidth \r\n" +
				  "for(i=0;i<lotterFlag.length;i++){\r\n" + 
				  "		lotterDisabled(lotterFlag[i])\r\n" + 
				  " }\r\n" + 
				  "			$.ajax({\r\n" + 
				  "				type:\"post\",\r\n" + 
				  "				url:\"/findUserNotices.do\",\r\n" + 
				  "				success:function(data){\r\n" + 
				  "					if(data == 50) { \r\n" + 
				  "						save.push(\"sy\")\r\n" + 
				  "						bindSetData(\"login\") \r\n" + 
			      "						return;\r\n" + 
				  "		   			}else if(data==60){\r\n" + 
				  "   					pagePreserve();\r\n" + 
				  "   					return;\r\n" + 
				  "   				}\r\n" +
				  "					var html='';\r\n" + 
				  "					var newData=data.data\r\n" + 
				  "					for(i=0;i<newData.length;i++){\r\n" + 
				  "						html += newData[i].contents + \"\\xa0\\xa0\\xa0\\xa0\\xa0\\xa0\\xa0\\xa0\\xa0\\xa0\\xa0\\xa0\"\r\n" + 	
				  "					}\r\n" + 
				  "					$(\"#span-i-webSiteNoticeScroll\").text(html);\r\n" + 
				  "		            \r\n" +
				  "					var i = allWidth\r\n" + 
				  "					isTrue=true;\r\n" +
				  "					if(isTrue){\r\n" +
				  "						var notice1=setInterval(function() {\r\n" +
				  "							isTrue=false;\r\n" +
				  "           				if($(\"#span-i-webSiteNoticeScroll\").length==0){\r\n" +
				  "          	 				clearInterval(notice1)\r\n" +
				  "								return;\r\n" +
				  "           				}else{\r\n" + 
				  "				        		var  noticeWidth = document.querySelector(\"#span-i-webSiteNoticeScroll\").clientWidth-60\r\n" +
				  "								i--\r\n" +
				  "								$(\"#span-i-webSiteNoticeScroll\").css({\r\n" + 
				  "									\"transform\": \"translateX(\" + i + \"px)\"\r\n" + 
				  "								})\r\n" + 
				  "								if (Math.abs(i) == noticeWidth) {\r\n" + 
				  "									i =allWidth\r\n" + 
				  "								}\r\n" + 
				  "							}\r\n" + 
				  "						}, 20)\r\n" + 
				  "					}\r\n" + 
				  "				}\r\n" + 
				  "			})\r\n" + 
				  " $(\"#rmcz td\").on(\"click\",function(){\r\n" + 
				  "			if(statu!=1){\r\n" + 
				  "			 	GotoLogin()\r\n" + 
				  "			 	return;\r\n" + 
				  "			}\r\n" + 
				  "		   save.push(\"sy\")\r\n" +
				  "		   if($(this).attr(\"class\")==\"moreLotter\"){\r\n" + 
				  "		    	bindSetData(\"gc\")\r\n" + 
				  "		    }else{\r\n" + 
				  "		      caizhong_cname=$(this).attr(\"class\")\r\n" + 
				  "			if($(this).hasClass('gray')){\r\n" + 
				  "				layer.msg('该玩法维护中,暂停开放')\r\n" +
				  "				return;				 \r\n" + 
				  "		    }\r\n" +
				  "			   bindsetLotterData(caizhong_cname)\r\n" + 
				  "		    }\r\n" + 
				  "			 \r\n" + 
				  "	})\r\n" + 
				"				$(\".aaa a\").on(\"click\",function(){\r\n" +
				"					if($(this).attr(\"id\")==\"a-i-chooseKeFuType\"){\r\n" + 
				"						return;\r\n" + 
				"					}\r\n" +
				"					var that=this\r\n" + 
				"					if(statu==0){\r\n" + 
				"			 			GotoLogin()\r\n" + 
				"			 			return;\r\n" + 
				"					}else{\r\n" +
				"						if($(this).attr(\"id\")==\"a-i-youhuiHref\"){\r\n" +
				"							save.push(\"sy\")\r\n" + 
				"							bindSetData(\"yHactivity\")\r\n" + 
				"			 				return;\r\n" + 
				"						}\r\n" + 
				"			      		if(statu==2){\r\n" + 
				"							layer.msg(\"请先成为正式会员！\")\r\n" + 
				"			 				bindAllCloseFakeModalBtns(); \r\n" + 
				"			 				return;\r\n" + 
				"			 			}\r\n" +
				"			    		save.push(\"sy\")\r\n" + 
				"						if($(that).attr(\"id\")==\"li-cz\"){\r\n" + 
				"							bindSetData(\"chongzhi\")\r\n" + 
				"						}\r\n" + 
				"						if($(that).attr(\"id\")==\"a-i-zhuanpan\"){\r\n" + 
				"							bindSetData(\"zhuanpan\")\r\n" + 
				"						}\r\n" + 
				"						if($(that).attr(\"id\")==\"a-i-chatFlag\"){\r\n" + 
				"							$.ajax({ \r\n" + 
				"								url: '/chatroom.do', \r\n" + 
				"								type: 'post', \r\n" + 
				"								data: {}, \r\n" + 
				"								success: function(data) { \r\n" + 
				"									if(data.data==0){ \r\n" + 
				"										layer.msg('聊天室暂未开启');\r\n" + 
				"									}else{\r\n" + 
				"										bindSetData(\"onLineJL\")\r\n" + 
				"									}\r\n" + 
				"								}\r\n" + 
				"							})\r\n" + 
				"						}\r\n" +
				"					}\r\n" +
				"				})\r\n" +
				"$(\".download span\").click(function(){\r\n" + 
				"	$(\".download\").addClass(\"hidden\")\r\n" + 
				"})\r\n" + 
				"\r\n" + 
				"$(\".b1white\").on(getEndClickEvent(), function(e) {\r\n" + 
				"bindSetData(editMessage)\r\n" + 
				"})\r\n" + 
				"var titleObj = {}\r\n" + 
				"var nowTime\r\n" + 
				"\r\n" + 
				"function createQQChatItem(item, index) {\r\n" + 
				"	var html =\r\n" + 
				"		\"<div class='div-c-chooseChatWrapper' data-qqnum='\" + item.number + \"' data-type='qq'>\"+\r\n" + 
				"			\"<div>\"+\r\n" + 
				"					\"<svg class='icon' aria-hidden='true' style='fill:rgb(253,107,84);'>\"+\r\n" + 
				"			  	  \"<use xlink:href='#icon-social-qq'></use>\"+\r\n" + 
				"				\"</svg>\"+           		\r\n" + 
				"				\"<span>客服-\" + item.note + \"</span>\"+\r\n" + 
				"			\"</div>\"+\r\n" + 
				"		     	\"<svg class='icon' aria-hidden='true' style='fill:rgb(253,107,84);'>\"+\r\n" + 
				"			  	  \"<use xlink:href='#icon-1202youjiantou'></use>\"+\r\n" + 
				"				\"</svg>\"+    \r\n" + 
				"		\"</div>\"		\r\n" + 
				"	return html\r\n" + 
				"}\r\n"+ 
				"\r\n" + 
				"\r\n" + 
				"\r\n" + 
				" 		var setTableData = function() {\r\n" + 
				"		 	var urlPath = \"/homePageData.do\"\r\n" + 
				"				var newRequest = {\r\n" + 
				"					url: urlPath,\r\n" + 
				"					type: \"post\",\r\n" + 
				"					data: {},\r\n" + 
				"					success: function(data) {\r\n" +
				"							if(data == 50) { \r\n" + 
				"								save.push(\"sy\")\r\n" + 
				"								bindSetData(\"login\") \r\n" + 
				"								return;\r\n" + 
				"		   					}else if(data==60){\r\n" + 
				"   							pagePreserve();\r\n" + 
				"   							return;\r\n" + 
				"   						}\r\n" + 
				"						var data=JSON.parse(data);\r\n" +
				"						var html=\"\"\r\n"+
				"						$('#head-message').empty()\r\n"+
				"						if(data.data==0){\r\n" + 
				"							statu=0\r\n" +
				"							$(\".download\").hide()\r\n" + 
				"							html+=\"<a class='GoToPage zhuce fl' style='margin-left: 10px;'><span>注册</span></a>\"+\r\n" + 
				"							\"<a class='GoToPage login fr' style='margin-right: 10px;'><span>登录</span></a>\"+\r\n" + 
				"							\"<span id='span-i-websiteTitle' style='position: absolute;top: 50%;left:50%;transform:translateX(-50%) translateY(-50%);'></span>\"\r\n"+
				"							$('#head-message').append(html)\r\n" +
				"						}else{\r\n" +
				"							if(data.data==1 || data.data==3){\r\n" +
				"								statu=1\r\n" +
				"							}\r\n" +
				"							if(data.data==2){\r\n" +
				"								statu=2\r\n" +
				"							}\r\n" +
				"							if(rews=='null' || rews==null){\r\n" +
				"								reconnect()\r\n" +
				"							}\r\n" +
				"							$(\".download\").show()\r\n" +
				"							html+=\"<img class='fl b1white br3' style='width: 30px;height: 30px; margin: 10px;' />\"+\r\n" + 
				"							\"<span id='span-i-websiteTitle' style='position: absolute;top: 50%;left:50%;transform:translateX(-50%) translateY(-50%);'></span>\"\r\n"+
				"							$('#head-message').append(html)\r\n" +
				"							$('#head-message .b1white').attr(\"src\",\"d/cp/\"+data.message+\"\")\r\n" +
				"							$('#head-message .b1white').on('click',function(){\r\n" +
				"								save.push(\"sy\")\r\n" + 
				"								bindSetData(\"userMessage\")\r\n" + 
				"							})\r\n" +
				"						}\r\n" +
				"						var data1=data.data1;\r\n" +
				"						for(i=0;i<data1.length;i++){\r\n" + 
				"							var cname=data1[i].cname\r\n" + 
				"							if(data1[i].state==0){\r\n" + 
				"								if(lotterFlag.indexOf(cname)==-1){\r\n" +
				"									lotterFlag.push(cname)\r\n" +
				"								}\r\n" +
				"								$('#rmcz').find('.'+cname).addClass('gray')\r\n" +
				"								$('#rmcz').find('.'+cname).find('img').attr(\"src\",\"/img/caizhong/gray_\"+cname+\".png\")\r\n" +
				"							}else{\r\n" +
				"								if(lotterFlag.indexOf(cname)==-1){\r\n" +
				"									removeByValue(lotterFlag,cname)\r\n" +
				"								}\r\n" +
				"								$('#rmcz').find('.'+cname).removeClass('gray')\r\n" +
				"								$('#rmcz').find('.'+cname).find('img').attr(\"src\",\"/img/caizhong/\"+cname+\".png\")\r\n" +
				"							}\r\n" + 
				"						}\r\n" + 
				
				"						var data2=data.data2;\r\n" +
				"						$(\"#kefuModal .modal-body .div-c-chooseChatWrapper\").eq(0).nextAll().remove();\r\n" +
				"						var len = data2.length > 3 ? 3: data2.length\r\n" + 
				"						for (var i = 0; i < len; i++) {\r\n" + 
				"							var item = data2[i]\r\n" + 
				"							$(\"#kefuModal .modal-body\").append(createQQChatItem(item, i + 1))\r\n" + 
				"						}\r\n" + 
				
				"						var data3=data.data3;\r\n" +
				"						for (var j = 0; j < data3.length; j++) {\r\n" + 
				"							var item = data3[j]\r\n" + 
				"							var zhanghao = \"\"\r\n" + 
				"							if(item.huiyuanzh.length>6){\r\n" + 
				"								zhanghao = item.huiyuanzh.slice(0, 2) + \"*\" + item.huiyuanzh.slice(item.huiyuanzh.length-2, item.huiyuanzh.length)\r\n" + 
				"							}else{\r\n" + 
				"								zhanghao = item.huiyuanzh.slice(0, item.huiyuanzh.length - 1) + \"*\"\r\n" + 
				"							}\r\n" + 
				"							var html1 = \"<tr style='background:#F7F7F7;border-bottom:10px solid white;'><td style='line-height:30px;'><nobr><span class='glyphicon glyphicon-user' style='color:#DE3B28;'>　</span>\" + zhanghao + \"</nobr></td><td><nobr>购买\" + item.cname1 + \"</nobr></td><td><span>喜中<span class='span-pointMoney'>\" + item.goalmoney + \"</span>元</span></td></tr>\"\r\n" + 
				"							$(\"#table-i-lotterInfo tbody\").append(html1)\r\n" + 
				"						}\r\n" + 
				"						var dsitance=window.setInterval(function() {\r\n" + 
				"    						if($(\"#zjxx\").length==0){\r\n" +
				"								clearInterval(dsitance)\r\n" +
				"								return;\r\n" +
				"							}\r\n" +
				"							var x = Number($(\"#zjxx table\").css(\"margin-top\").replace(\"px\", \"\"));\r\n" + 
				"							if (x < -Number($(\"#zjxx table\").css(\"height\").replace(\"px\", \"\"))) {\r\n" + 
				"								$(\"#zjxx table\").css(\"margin-top\", \"0px\");\r\n" + 
				"							} else {\r\n" + 
				"								$(\"#zjxx table\").css(\"margin-top\", (x - 1) + \"px\");\r\n" + 
				"							}\r\n" + 
				"						}, 60)		\r\n" +
				"						var data4=data.data4;\r\n" +
				"						titleObj=data4\r\n" +
				"						if(indexNotice==0){\r\n" +
				"							showAlertNotice(data4.noticeName, data4.noticePicture, \"\")\r\n" +
				"						}\r\n" +
				"						$(\".foot\").show();\r\n" +
				" 						$(\".kd-loading\").hide();\r\n" + 
				"						$(\"#xfm\").show(); \r\n" + 
				"						indexNotice=1\r\n" +
				"						$(\"#span-i-websiteTitle\").text(data4.wangzhantitle)	\r\n" + 
				/*"						$(\"#span-i-webSiteNoticeScroll\").text(data4.notice)\r\n" + */
				"						for (var i = 1; i < 6; i++) {\r\n" + 
				"							var picItem = data4[\"picturePath\" + i]\r\n" + 
				"							if (picItem == \"\") {\r\n" + 
				"								continue\r\n" + 
				"							}\r\n" + 
				"							var childNum = $(\"#myCarousel .carousel-indicators\").find(\"li\").length\r\n" + 
				"							$(\"#myCarousel .carousel-indicators\").append(\"<li data-target='#myCarousel' data-slide-to='\" + childNum + \"'></li>\")\r\n" + 
				"							$(\"#myCarousel .carousel-inner\").append(\"<div class='item'><img src='/d/cp/\" + picItem + \"'></div>\")\r\n" + 
				"						}\r\n" + 
				"						$(\"#myCarousel .carousel-indicators\").find(\"li\").eq(0).addClass(\"active\")\r\n" + 
				"						$(\"#myCarousel .carousel-inner\").find(\"div\").eq(0).addClass(\"active\")\r\n" + 
				"						$(\"#myCarousel\").carousel('cycle')\r\n" +
				"					},\r\n" + 
				"					error: function(status) {\r\n" + 
				"					}\r\n" + 
				"				}\r\n" + 
				"				ajax(newRequest)			\r\n" + 
				"		} \r\n" + 
				"		    setTableData()  \r\n" + 
				"		$(\"#cai li:gt(8)\").addClass(\"bb\")\r\n" + 
				"		$(\"#cai li:nth-child(3n+4)\").addClass(\"removeBr\")\r\n" + 
				"			var volume=window.setInterval(\r\n" + 
				"			function() {\r\n" +
				"           	if($(\"#sy\").length==0){\r\n" + 
				"           		clearInterval(volume)\r\n" +
				"					return;\r\n" +
				"				}else{\r\n" +
				"					if ($(\".speak\").attr(\"class\").indexOf(\"glyphicon-volume-down\") == -1)\r\n" + 
				"						$(\".speak\").removeClass(\"glyphicon-volume-up\").addClass(\"glyphicon-volume-down\");\r\n" + 
				"					else\r\n" + 
				"						$(\".speak\").removeClass(\"glyphicon-volume-down\").addClass(\"glyphicon-volume-up\");\r\n" + 
				"				}\r\n" + 
				"			}, 300)\r\n" + 
				"		\r\n" + 
				"		$(\"html\").css(\"font-size\",\"12px\")\r\n"+
				"			$(\"#a-i-chooseKeFuType\").on('click', function() {\r\n" + 
				"			$(\"#kefuModal\").modal(\"show\")	\r\n" + 
				"		})\r\n" + 
				"		\r\n" + 
				"	 	\r\n" + 
				"		\r\n" + 
				"		$(\"#kefuModal\").on(getEndClickEvent(), \".div-c-chooseChatWrapper\", function(event) {\r\n" + 
				"			var self = event.currentTarget\r\n" + 
				"			var qqNum = self.dataset.qqnum\r\n" + 
				"			if (self.dataset.type == \"qq\") {\r\n" + 
				"				if (window.ontouchend === null) {\r\n" + 
				"					location.href = \"mqqwpa://im/chat?chat_type=wpa&uin=\" + qqNum + \"&version=1&src_type=web&web_src=oicqzone.com\"\r\n" + 
				"				}\r\n" + 
				"				else if (window.ontouchend === undefined) {\r\n" + 
				"					location.href = \"http://wpa.qq.com/msgrd?v=3&uin=\" + qqNum + \"&site=qq&menu=yes\"\r\n" + 
				"				}\r\n" + 
				"			} else {\r\n" + 
				"				var shangbanTimeHour = Number(titleObj.kefusbtime.slice(0, 2))\r\n" + 
				"				var shangbanTimeMin = Number(titleObj.kefusbtime.slice(2, 4))\r\n" + 
				"				var xiabanTimeHour = Number(titleObj.kefuxbtime.slice(0, 2))\r\n" + 
				"				var xiabanTimeMin = Number(titleObj.kefuxbtime.slice(2, 4))\r\n" + 
				"				var nowHour = new Date().getHours()\r\n" + 
				"				var nowMin = new Date().getMinutes()\r\n" + 
				"				console.log(shangbanTimeHour,shangbanTimeMin,xiabanTimeHour,xiabanTimeMin,nowHour,nowMin)\r\n" + 
								/*  如果上班时间大于下班时间,则下班时间到次日  */
				"				if(Number(titleObj.kefusbtime)>Number(titleObj.kefuxbtime)){\r\n" + 
				"    				if((nowHour>xiabanTimeHour && nowHour<shangbanTimeHour) || (nowHour===shangbanTimeHour && nowMin>xiabanTimeMin) || (nowHour===xiabanTimeHour && nowMin<shangbanTimeMin) ){\r\n" +
				"						showNormalNoticeModal(\"#div-i-noticeGenDan\", \"提示：\", \"非客服工作时间，客服工作时间为今日\" + shangbanTimeHour + \":\" + shangbanTimeMin + \"~次日\" + xiabanTimeHour + \":\" + xiabanTimeMin)\r\n" + 
				"						bindAllCloseFakeModalBtns()\r\n" + 
				"						return\r\n" + 
				"					}\r\n" +
				"				}\r\n" + 
				"				if(Number(titleObj.kefusbtime)<Number(titleObj.kefuxbtime)){\r\n" + 
				"					if ((nowHour < shangbanTimeHour || nowHour > xiabanTimeHour) || (nowHour === shangbanTimeHour && nowMin < shangbanTimeMin) || (nowHour === xiabanTimeHour && nowMin > xiabanTimeMin)) {\r\n" + 
				"						showNormalNoticeModal(\"#div-i-noticeGenDan\", \"提示：\", \"非客服工作时间，客服工作时间为\" +  shangbanTimeHour + \":\" + shangbanTimeMin + \"~\" + xiabanTimeHour + \":\" + xiabanTimeMin)\r\n" + 
				"						bindAllCloseFakeModalBtns()\r\n" + 
				"						return\r\n" + 
				"					}\r\n" + 
				"				}\r\n" +
				
				"				$.ajax({\r\n" + 
				"					url: \"/u/panduanshifudenglu.do\",\r\n" + 
				"					type: \"post\",\r\n" + 
				"					data: {},\r\n" + 
				"						success: function(data) {\r\n" + 
				"							if(data == 50) { \r\n" + 
				"								save.push(\"sy\")\r\n" + 
				"								bindSetData(\"login\") \r\n" + 
				"								return;\r\n" + 
				"		   					}else if(data==60){\r\n" + 
				"   							pagePreserve();\r\n" + 
				"   							return;\r\n" + 
				"   						}\r\n" +
				"						$(\"body\").removeClass('modal-open')\r\n" + 
				"						if(data.data==0){\r\n" +
				"							$(\".modal-backdrop\").hide()\r\n" +
				"							save.push(\"sy\")\r\n" + 
				"							bindSetData(\"login\")\r\n" + 
				"						}else{\r\n" + 
				"							$(\".modal-backdrop\").hide()\r\n" +
				"							save.push(\"sy\")\r\n" + 
				"							bindSetData(\"contactKF\")\r\n" + 
				"						}\r\n" + 
				"					}\r\n" + 
				"				})\r\n" +
				"			}\r\n" + 
				"		})\r\n" + 
				"		\r\n" + 
				"		\r\n" + 
				"		window.onload=function () {  \r\n" + 
				"        	document.addEventListener('touchstart',function (event) {  \r\n" + 
				"            	if(event.touches.length>1){  \r\n" + 
				"              	  event.preventDefault();  \r\n" + 
				"            	}  \r\n" + 
				"        })  \r\n" + 
				"        var lastTouchEnd=0;  \r\n" + 
				"        document.addEventListener('touchend',function (event) {  \r\n" + 
				"            var now=(new Date()).getTime();  \r\n" + 
				"            if(now-lastTouchEnd<=300){  \r\n" + 
				"                event.preventDefault();  \r\n" + 
				"            }  \r\n" + 
				"            lastTouchEnd=now;  \r\n" + 
				"        },false)  \r\n" + 
				"    }\r\n" + 
				"		\r\n" + 
				"\r\n"+
				"</script>";
		return string+string2;
	}
	/**
	 * 返回购彩页面
	 * @return
	 */
	public String gc() {
		List<LotterExample> list = new ArrayList<LotterExample>();
		List<LotterExample> lotters = new ArrayList<LotterExample>();
		for(LotterExample data : lotterService.getAllLotters()) {
			if("kuai3".equals(data.getClasst().split(" ")[2])) {
				data.setNextStopOrderTimeEpoch(data.getNextStopOrderTimeEpoch().replaceAll("-", "/"));//如果是快3放到新集合
				list.add(data);
			}else {
				data.setNextStopOrderTimeEpoch(data.getNextStopOrderTimeEpoch().replaceAll("-", "/"));
				lotters.add(data);
			}
		}
		list.addAll(lotters);
		String string ="<style> *{font-size: 16px;} .gray{font-size: 13px;}.main{position:absolute;top:72px;width:100%;} .name{font-weight: bold;} .not1{color: red!important;font-size: 14px!important;margin-top: 5px;} * { user-select: none; -webkit-user-select:none;-moz-user-select:none;-ms-user-select:none; } .cai1{float: left;padding-top: 70px;} .cai1 li{float: left;width: 33.3%;border-top: 1px solid #f0f0f0;padding: 25px 0px;} .cai1 img{width: 70px;height: 70px;} .cai1 .not,.cai1 .not1,.cai1 .br1,.cai1 .qishu{display: none;} .cai2{margin-top: 0px;} .cai2 li{margin-top: 10px; height: 80px;border-top: 1px solid #f0f0f0;padding-top: 8px;} .cai2 img{width: 60px;height: 60px;margin:6px 10px 0px 0px;} .cai2 .not{left: 80px;position: absolute;margin-top:10px;} .cai2 .djs,.cai2 .qishu{right: 10px;position: absolute;} .djs{margin-top: 8px;color: #A7A7A7;font-weight: bold;} .cai2 .br{display: none;} .cai2 img,.cai2 .name,.cai2{float: left;} #cai .cz, .nav1 select, #hhh { cursor: pointer; } .cai2 li:first-child { border-top:none; } .c-span-lastPeriod { font-size:13px!important; } .zhengzaikaijiang { background-color:red; margin:1px; color:white; width:0.46rem; height:0.46rem; line-height:0.46rem; font-size:0.33rem; display:inline-block; border-radius: 50%; } [data-cname='bjl'] { position: relative; } [data-cname='bjl'] .qishu, [data-cname='bjl'] .not1, [data-cname='bjl'] .djs { visibility: hidden; } [data-cname='bjl'] .not { font-size:12px; color:#a7a7a7; font-weight:bold; left:70px; text-align: left; bottom:4px; } .xg6hc .djs { display:none; } .c-span-nextPeriod { font-size:13px!important; } .clearfix:after { content:\"\"; display:block; clear:both; } .span-c-placeholder { color:white; } .span-c-nextPeriodStatus { font-size:13px; color:red; } .span-c-placeholder{display: none;} .dice{ width:2.2rem; display:flex; justify-content: space-between; } .shaizi{ display:inline-block ; width: 0.56rem; height: 0.56rem; } </style>";
			string += "<div class='wapper' id='gc'>" + 
					"		<div class=\"bg-theme col-xs-12 col-sm-4 col-sm-offset-4 text-center top\" stlye=\"padding-left:10px;padding-right:10px;\">" + 
					"			<!-- <a class=\"glyphicon glyphicon-chevron-left fl\" style=\"cursor:pointer; color: white;position:absolute;top:50%;transform:translateY(-50%);font-size: 20px;left:10px;\"></a> -->" + 
					"			<span style=\"font-weight:700;\">购彩大厅</span>\r\n" + 
					"			<span id=\"hhh\" class=\"glyphicon glyphicon-th-large fr\" onclick=\"changImg()\" style=\"position:absolute;top:50%;transform:translateY(-50%);right:10px;font-size: 25px;\"></span>" + 
					"		</div>" + 
					"		<div class=\"col-xs-12 col-sm-4 col-sm-offset-4 text-center nav1\" style=\"height: 30px;line-height: 30px;position: fixed;top: 50px;z-index: 50;background:white ;\">" + 
					"			<select style=\"border: 0;background:white ;outline: none; font-size: 15px;font-weight: bold;color: #059BF3;\">" + 
					"				<option value=\"cz\" selected=\"selected\">全部彩种(点击选择) </option>" + 
					"				<option value=\"kuai3\">快3(点击选择) </option>\r\n" + 
					"				<option value=\"ssc\">时时彩(点击选择) </option>" + 
					"				<option value=\"pcdd\">PC蛋蛋(点击选择) </option>\r\n" + 
					"				<option value=\"pk10\">PK拾(点击选择) </option>\r\n" + 
					"				<option value=\"115\">11选5(点击选择) </option>\r\n" + 
					"				<option value=\"gpc\">高频彩(点击选择) </option>\r\n" + 
					"				<option value=\"dpc\">低频彩(点击选择) </option>\r\n" + 
					"				<option value=\"bjl\">百家乐(点击选择)  </option>\r\n" + 
					"			</select>\r\n" + 
					"		</div>\r\n" + 
					"<main>\r\n" +
					"		<div id=\"cai\" class=\"col-xs-12 col-sm-4 col-sm-offset-4 text-center body cai2\" style=\"padding: 75px 10px;overflow:scroll;\">\r\n";
							int i = 0;
							for(LotterExample lotter : list) {
									i++;
									if(lotter.getId() != 31) {
										string +=	"<li data-nogetindex=\"0\" data-cname='"+lotter.getCname()+"' class='"+lotter.getClasst()+" Caiz  cz"+ lotter.getCname()+" clearfix'>\r\n" + 
													"<img src='/img/caizhong/"+lotter.getImg()+".png' /><br class='br'>\r\n" + 
													"<span class='name'>"+lotter.getName()+"</span><span class='qishu gray' style=\"color:red;\">第<span class=\"c-span-lastPeriod "+lotter.getCname()+"lastPeriod\" style=\"color:red;\">"+lotter.getPeriod()+"</span>期</span><br class='br1'>\r\n" + 
													"<span  class='not1 "+lotter.getCname()+"number' style=\"float:left;font-size:13px!important;color:red;\">"+lotter.getLotternumber().replaceAll(",", " ")+"</span><br>\r\n" + 
													"<span class='not gray'>\r\n";
													if(!"xg6hc".equals(lotter.getCname()) && !"5f6hc".equals(lotter.getCname())) {
														string +=	"<span class=\"span-period\" style=\"font-size:13px!important;color:#A7A7A7;\">距第<span class=\"c-span-nextPeriod "+lotter.getCname()+"period\" style=\"font-size:13px;\">"+lotter.getPeriod()+1+"</span>期截止还有</span>";
													}
													if("xg6hc".equals(lotter.getCname()) || "5f6hc".equals(lotter.getCname())) {
														string +="<span style=\"font-size:13px!important;color:#A7A7A7;\">距第<span  class=\"c-span-nextPeriod "+lotter.getCname()+"period\" style=\"font-size:13px;\">"+lotter.getNextperiod()+"</span>期截止还有</span></span>\r\n" + 
														"<span class=\"span-c-nextPeriodStatus\" id='djs"+lotter.getCname()+"' style=\"color:#A7A7A7;font-weight:bold;font-size:13px;margin-top: 10px;float: right;\"></span>\r\n";

													}
													string +="</span>";
													if(!"xg6hc".equals(lotter.getCname()) && !"5f6hc".equals(lotter.getCname())) {
														string +=	"<span id='djs"+lotter.getCname()+"' class='djs gray' style=\"right:10px;text-align: left;margin-top :10px;font-size:13px;display:block !important\">00:00:00</span>\r\n" + 
														"<span hidden=\"\" id=\"ts"+i+1+"\" >"+lotter.getTimespace()+"</span>\r\n";
													}
													string += "</li>";
												}
										}
						string += "</div>\r\n"+
								"</main>\r\n"+
							"</div>";
					String string2 = "<script>\r\n" + 
				"	for(i=0;i<lotterFlag.length;i++){\r\n" + 
				"		lotterDisabled(lotterFlag[i])\r\n" + 
				" 	}\r\n" + 
				"	//var NOT_STOP = [\"2fpk10\", \"2fssc\", \"xysm\", \"3fk3\"]\r\n" +
				"	var ISFIRSTLOTTER_flag = true\r\n" + 
				"		!function() {\r\n" + 
				"		jianrong()\r\n" +
				"var u = navigator.userAgent, app = navigator.appVersion;\r\n" + 
				
				"			if (navigator.userAgent.indexOf('UCBrowser') > -1) {\r\n" + 
				"				if(isIOS()) {\r\n" + 
				"				$('select').on(\"focus\",function(){\r\n" + 
				"					$('.foot').hide();\r\n" + 
				"					$('.top').hide();\r\n" +
				"					$('select').hide();\r\n" +
				"				})\r\n" +
				"				$('select').on(\"blur\",function(){\r\n" + 
				"					$('.foot').show();\r\n" + 
				"					$('.top').show();\r\n" +
				"					$('select').show();\r\n" +
				"				});\r\n" + 
				"				}\r\n" +
				"			}\r\n" +
				"			countDowns()\r\n" + 
				"           clearInterval(elapse)\r\n" + 
				"			var elapse= setInterval(countDowns, 7000);\r\n" + 
				"			var falses = false\r\n" + 
				"			function countDowns() {\r\n" +
				"           if($(\"#gc\").length==0){\r\n" + 
				"           clearInterval(elapse)\r\n" + 
				"           return;\r\n" + 
				"           }else{\r\n" + 
				"				$.ajax({\r\n" + 
				"					url: \"/syLotterr1.do\",\r\n" + 
				"					type: \"post\",\r\n" + 
				"					data: {},\r\n" + 
				"					success: function(data, xhr) {\r\n" + 
				"							if(data == 50) { \r\n" + 
				"								save.push(\"sy\")\r\n" + 
				"								bindSetData(\"login\") \r\n" + 
				"								return;\r\n" + 
				"		   					}else if(data==60){\r\n" + 
				"   							pagePreserve();\r\n" + 
				"   							return;\r\n" + 
				"   						}\r\n" +
				"						for(var i = 0;i<data.data.length;i++){\r\n" + 
				"							var start = new Date(data.message)\r\n" + 
				"							 var end = new Date(data.data[i].nextStopOrderTimeEpoch)\r\n" + 
				"							 var time1 = start.getTime()//当前系统时间\r\n" + 
				"							 var time = end.getTime()//下期时间\r\n" + 
				"							 var lotterNumber\r\n" +
				"							 var countDown  = (time-time1)/1000\r\n" + 
				"							if(data.data[i].cname=='xy28' || data.data[i].cname=='bj28' ){\r\n" + 
				"								var lotternumber=data.data[i].lotternumber.split(',');\r\n" +
				"								var total=Number(lotternumber[0])+Number(lotternumber[1])+Number(lotternumber[2])\r\n" +
				"								$(\".\"+data.data[i].cname+\"number\").text(\"\"+lotternumber[0]+\"+\"+lotternumber[1]+\"+\"+lotternumber[2]+\"=\"+total+\"\")\r\n" +	
				"								lotterNumber=$(\".\"+data.data[i].cname+\"number\").text()\r\n" +
				"							}else{\r\n"+
				"								lotterNumber=data.data[i].lotternumber.replace(/,/g, \" \")\r\n" +	
				"							}\r\n" +
				"							 if(falses){\r\n" + 
				"								 if($(\"#djs\"+data.data[i].cname).text() == \"正在开奖\"){\r\n" + 
				"									 timedTask(countDown,data.data[i].cname,data.data[i].nextperiod,data.data[i].period,lotterNumber)\r\n" + 
				"								 }\r\n" + 
				"							 } else{\r\n" + 
				"								 timedTask(countDown,data.data[i].cname,data.data[i].nextperiod,data.data[i].period,lotterNumber)\r\n" + 
				"							 } \r\n" + 
				"						}\r\n" + 
				"						 if(!falses){\r\n" + 
				"							 falses = true\r\n" + 
				"						} \r\n" + 
				"					  }\r\n" + 
				"				}) \r\n" + 
				"			} \r\n" + 
				"			}\r\n" + 
				"			 function timedTask(data,name,nextperiod,period,lotternumber){\r\n" + 
				"if(name == 'xg6hc') {\r\n" + 
				"						console.log(data,name,nextperiod,period,lotternumber);\r\n" + 
				"					}\r\n" + 
				"				var timer1 = setInterval(CountDown, 1000);\r\n" + 
				"				 function CountDown() {\r\n" +
				"					if($(\"#gc\").length==0) {\r\n" +
				"						clearInterval(timer1)\r\n" +
				"						return;\r\n" +
				"					}else {\r\n" +
				"						data--\r\n" + 
				"				       	var h = parseInt(data/ 60 / 60 % 60)\r\n" + 
				"				       	var m = parseInt(data/ 60 % 60)\r\n" + 
				"						var s = parseInt(data% 60)\r\n" + 
				"						if(h <= 0 && m <= 0 && s <= 0){\r\n" + 
				"							$(\"#djs\"+name).html(\"正在开奖<span class='span-c-placeholder'></span>\")\r\n" + 
				"							clearInterval(timer1)\r\n" +
				"						}else{\r\n" + 
				"							if(h < 10){\r\n" + 
				"								h = \"0\"+h\r\n" + 
				"							}\r\n" + 
				"							if(m < 10){\r\n" + 
				"								m = \"0\"+m\r\n" + 
				"							}\r\n" + 
				"							if(s < 10){\r\n" + 
				"								s = \"0\"+s\r\n" + 
				"							}\r\n" + 
				"							$(\"#djs\"+name).html(h+\":\"+m+\":\"+s)\r\n" + 
				"						}\r\n" + 
				"						$(\".\"+name+\"number\").text(lotternumber)\r\n" + 
				"						$(\".\"+name+\"lastPeriod\").text(period)\r\n" + 
				"						$(\".\"+name+\"period\").text(nextperiod)\r\n" + 
				"					}\r\n" +
				"		   		 }\r\n" + 
				"			 }\r\n" + 
				"			var allLiItems = $(\"#cai li\")\r\n" + 
				"			for (var i = 0; i < allLiItems.length; i++) {\r\n" + 
				"				var item = allLiItems[i]\r\n" + 
				"				if (item.dataset.cname == \"bjl\") {\r\n" + 
				"					$(item).find(\".not\").html(\"在线百家乐，30秒一期，好玩又刺激!<br>最高中奖10万人民币！\")\r\n" + 
				"				}\r\n" + 
				"			}\r\n" + 
				"			$(\"#cai li\").click(function(){\r\n" +
				"				if($(this).hasClass('gray')){\r\n" + 
				"					layer.msg('该玩法维护中,暂停开放')\r\n" +
				"					return;				 \r\n" + 
				"		   		 }\r\n" +
				"				caizhong_cname=$(this).attr(\"data-cname\")\r\n" +
				"				bindsetLotterData(caizhong_cname)\r\n" +
				"				save.push(\"gc\")\r\n" +
				"			});\r\n" + 
				"		}.call() \r\n"+
				"$(function(){"+
				"	$(\".nav1 select\").change(function(){"+
				"		var cla=$(\".nav1 select\").val();"+
				"		$(\".Caiz\").addClass(\"hidden\");"+
				"		$(\".\"+cla).removeClass(\"hidden\");"+
				"	});"+
				"}); "+
				"</script>";
		return string+string2;
	}
	/**
	 * 返回开奖页面
	 * @param session
	 * @return
	 */
	public String kj(HttpSession session) {
		List<LotterExample> lotterList = lotterService.getAllLotters();
		String string = "<style>[data-cname='bjl'] .not {font-size: 12px !important;color: #a7a7a7 !important;font-weight: bold;left: 64px !important;text-align: left;bottom: 4px;top:25px;} .qiu0{background: #D8D21C!important;} .qiu1{background: #D8D21C!important;} .qiu2{background: #3273F9!important;} .qiu3{background: #515567!important;} .qiu4{background: #E6962D!important;} .qiu5{background: #0EC2C4!important;} .qiu6{background: #2D35D0!important;} .qiu7{background: #AEAFC5!important;} .qiu8{background: #E63131!important;} .qiu9{background: #7C1F1F!important;} .qiu10{background: #2DCC21!important;} .xg1,.xg2,.xg7,.xg8,.xg01,.xg02,.xg07,.xg08,.xg12,.xg13,.xg18,.xg19,.xg23,.xg24,.xg29,.xg30,.xg34,.xg35,.xg40,.xg45,.xg46{background:#F02828!important;} .xg16,.xg17,.xg21,.xg22,.xg27,.xg28,.xg32,.xg33,.xg38,.xg39,.xg43,.xg44,.xg49,.xg5,.xg6,.xg05,.xg06,.xg11{background:#09B832!important;} .xg3,.xg4,.xg03,.xg04,.xg09,.xg9,.xg10,.xg14,.xg15,.xg20,.xg25,.xg26,.xg31,.xg36,.xg37,.xg41,.xg42,.xg47,.xg48{background:#336DCC!important;} *{font-size: 16px;font-family: \"微软雅黑\"} .gray{color:gray;font-weight: lighter;} .not1{color: red!important;font-size: 14px!important;margin-top: 10px;position: absolute;left:74px;} * { user-select: none; -webkit-user-select:none;-moz-user-select:none;-ms-user-select:none; } .cai2{margin-top: 0px;} .cai2 li{margin-top: 22px; height: 62px;border-top: 1px solid #f0f0f0;padding-top: 6px;} .cai2 img{width: 55px;height: 55px;margin:4px 10px 0px 0px;} .cai2 .not{left: 80px;position: absolute;margin-top:10px;} .cai2 .djs,.cai2 .qishu{right: 10px;position: absolute;} .djs{margin-top: 8px;color: red;font-weight: bold;} .cai2 .br{display: none;} .cai2 img,.cai2 .name,.cai2{float: left;} .qiu{margin:1px;color:white;width:0.46rem;height:0.46rem;line-height:0.46rem;font-size:0.28rem;display:inline-block;background: #E63131;border-radius:50%;} .shengxiao{margin:1px;color:black;width:0.46rem;height:0.46rem;line-height:0.46rem;font-size:0.28rem;display:inline-block;border-radius:50%;} #cai .cz, .nav1 select, #hhh { cursor: pointer; } .cai2 li:first-child { border-top:none; } /* .c-span-lastPeriod { font-size:13px!important; } */ .zhengzaikaijiang { background-color:red; margin:1px; color:white; width:0.46rem; height:0.46rem; line-height:0.46rem; font-size:0.33rem; display:inline-block; border-radius: 20px; } [data-cname='bjl'] { position: relative; } [data-cname='bjl'] .qishu, [data-cname='bjl'] .not1, [data-cname='bjl'] .djs { visibility: hidden; } [data-cname='bjl'] .not { font-size:12px; color:red; font-weight:bold; left:70px; text-align: left; bottom:4px; } .xg6hc .djs { display:none; } .c-span-nextPeriod { font-size:13px!important; } .clearfix:after { content:\"\"; display:block; clear:both; } .span-c-placeholder { color:white; } .span-c-nextPeriodStatus { font-size:13px; color:red; } .green{border-radius:10px; border:1px solid silver ;box-shadow: 2px 3px 1px silver;padding:10px;padding-left:10px; ;line-height:30px;margin-bottom: 20px;text-align: left;} .green{border-top:5px solid green;} .span-item-circle { display: inline-flex; background: red; margin: 1px; border-radius: 50%; color: white; font-size: 0.33rem; width: 0.46rem; height: 0.46rem; justify-content:center; align-items:center; max-width:26px; max-height:26px; } .hezhi{margin-top: 12px;display: inline-block;position: absolute;left:3.8rem;z-index:10;} .hezhi1{margin-left: 1rem;} /* .name,.c-span-lastPeriod,.gray{font-size:13px!important;} */ .shaizi{ display:block; float:left; margin-right:10px; width: 0.56rem; height: 0.56rem; margin-top: 3px; } </style>\r\n" + 
				"<div class='wapper' id='kj'>" + 
				"		<div class=\"bg-theme col-xs-12 col-sm-4 col-sm-offset-4 text-center top\" stlye=\"padding-left:10px;padding-right:10px;\">\r\n" + 
				"			<!-- <a onclick=\"back()\" class=\"glyphicon glyphicon-chevron-left fl\" style=\"cursor:pointer; color: white;position:absolute;top:50%;transform:translateY(-50%);font-size: 20px;left:10px;\"></a> -->\r\n" + 
				"			<span style=\"font-weight:700;\">开奖大厅</span>\r\n" + 
				"		</div>\r\n" + 
				"		<div id=\"cai\" class=\"col-xs-12 col-sm-4 col-sm-offset-4 text-center body cai2\" style=\"overflow:scroll;padding: 28px 10px 60px 10px;\">\r\n" ; 
								String date=new SimpleDateFormat("yyyy-MM-dd").format(new Date());
								session.setAttribute("date", date);
							int i = 0;
							for(LotterExample l : lotterList) {
								i++;
								if(l.getLottertime() != null) {
									if(!l.getCname().contains("bjl")&&!l.getCname().contains("zc")) {
										string  +="					<li data-nogetindex=\"0\" data-cname='"+l.getCname()+"' class='"+l.getClasst()+" cz"+i+1+" clearfix a-i-lotterRecord'>\r\n"+
												"						<img src='/img/caizhong/"+l.getImg()+".png' /><br class='br'>\r\n"+
												"						<span class='name' style=\"margin-top: 5px;font-weight: bold;\">"+l.getName()+" <span class=\"gray\">第</span><span class=\"c-span-lastPeriod gray "+l.getCname()+"lastPeriod\">"+l.getPeriod()+"</span><span class=\"gray\">期</span> <span class=\"gray "+l.getName()+"time\">"+l.getLottertime().substring(11,19)+"</span></span>\r\n"+
												"						<br class='br1'>\r\n"+
												"						\r\n";
												String[] str0 = l.getLotternumber().split(",");
												String str1 = "";
												for(int j = 0;j<str0.length;j++) {
													if(l.getCname().equals("bjpk10") || l.getCname().equals("2fpk10") || l.getCname().equals("xyft") || l.getCname().equals("xysm") || l.getCname().equals("2fft")) {
														if(new Integer(str0[j]) < 10) {
															str1+="<span class='qiu qiu"+new Integer(str0[j])+"'>0"+new Integer(str0[j])+"</span>";
														}else {
															str1+="<span class='qiu qiu"+new Integer(str0[j])+"'>"+new Integer(str0[j])+"</span>";
														}
													} else if(l.getCname().equals("xg6hc") || l.getCname().equals("5f6hc")) {
														if(j == str0.length-1) {
															str1+="<span style='font-size:16px;font-weight:bold;color:black'>+</span>";
														}
														str1+="<span class='qiu xg"+str0[j]+"'>"+str0[j]+"</span>";
													} else if(l.getCname().equals("ahk3") || l.getCname().equals("gxk3") || l.getCname().equals("jsk3") || l.getCname().equals("3fk3") || l.getCname().equals("bjk3") | l.getCname().equals("2fk3")) {
														str1+="<span class='shaizi sz"+str0[j]+"'></span>";
													} /*else	if(l.getCname().equals("gdkl10f") || l.getCname().equals("cqkl10f")) {
														str1+="<span class='klsf sg"+str0[j]+"'></span>";
													}*/else if(l.getCname().equals("bj28") || l.getCname().equals("xy28")) {
														String total= String.valueOf(new Integer(str0[0])+new Integer(str0[1])+new Integer(str0[2]));
														if(j<str0.length-1){
															str1+="<span class='qiu'>"+str0[j]+"</span><span>+</span>";
														}else {
															str1+="<span class='qiu'>"+str0[j]+"</span><span>=</span>"+"<span class='qiu'>"+total+"</span>";
														}
													}else {
														str1+="<span class='qiu'>"+str0[j]+"</span>";
													}
												}
										string  +="						<span class='not1 "+l.getCname()+"lotternumber' style=\"float:left;color:red;\">"+str1+"</span>\r\n"; 
																		if(l.getCname().contains("k3")){
																			string  +="<span class=\"hezhi\">"+l.getPlayResult()+"</span>\r\n";
									  									}
																		if(l.getCname().contains("ssc")){
																			string  +="<span class=\"hezhi hezhi1\">"+l.getPlayResult()+"</span>\r\n";
										  								}
																		if(l.getCname().contains("6hc")){
																			string  +="<br><span style=\"margin-top: 10px;position: absolute;left:74px\" class=\"xg6hc1\"></span>\r\n";
										  								}
											string  +="						<br>\r\n" + 
													"						<span class='not gray'>\r\n" + 
													"						</span>\r\n" + 
													"						<br>\r\n" + 
													"						<span hidden=\"\" id='ts"+i+1+"' >"+l.getTimespace()+"</span>\r\n" + 
													"					</li>\r\n";
									}else if(l.getCname().contains("bjl")) {
										string  +="					<li data-nogetindex=\"0\" data-cname='"+l.getCname()+"' class='GoToPage kaijiangJl bjl clearfix a-i-lotterRecord'>\r\n"+
												"						<img src='/img/caizhong/"+l.getImg()+".png' /><br class='br'>\r\n"+
												"						<span class='name' style=\"margin-top: 5px;font-weight: bold;\">百家乐</span>\r\n"+
												"						<span class='not gray'>在线百家乐，一分钟一期，好玩又刺激!<br>最高中奖10万人民币！</span>\r\n"+
												"						\r\n";
									}
								}
							}
				
	  string  +="</div>\r\n" + 
				"<div class=\"modal fade\" id=\"myModal\" tabindex=\"-1\" role=\"dialog\" aria-labelledby=\"myModalLabel\" aria-hidden=\"true\">\r\n" + 
				"    <div class=\"modal-dialog\" style=\"width:90vw;max-width:600px;\">\r\n" + 
				"        <div class=\"modal-content\">\r\n" + 
				"            <div class=\"modal-header\">\r\n" + 
				"                <h4 class=\"modal-title\" id=\"myModalLabel\" style=\"text-align: center;letter-spacing: 3px;\"></h4>\r\n" + 
				"            </div>\r\n" + 
				"            <div class=\"modal-body\" style=\"height:65vh;overflow:auto;\">\r\n" + 
				" 				\r\n" + 
				"            </div>\r\n" + 
				"            <div class=\"modal-footer\">\r\n" + 
				"                <button type=\"button\" class=\"btn btn-primary\" data-dismiss=\"modal\">关　闭</button>\r\n" + 
				"            </div>\r\n" + 
				"        </div><!-- /.modal-content -->\r\n" + 
				"    </div><!-- /.modal-dialog -->\r\n" + 
				"</div>\r\n" + 
				"</div>";
	  
	  
	 String string2 ="<script>var width=$(\"#cai\").width()\r\n" + 
			"		for(i=0;i<lotterFlag.length;i++){\r\n" + 
			"			lotterDisabled(lotterFlag[i])\r\n" + 
			" 		}\r\n" +
			"		$(\"#cai li\").on(\"click\",function(){\r\n" + 
			"			console.log($(this).hasClass('gray'))\r\n" +
			"			if($(this).hasClass('gray')){\r\n" + 
			"				layer.msg('该玩法维护中,暂停开放')\r\n" +
			"				return;				 \r\n" + 
			"		    }\r\n" +
			"		caizhong_cname=$(this).attr(\"data-cname\")\r\n" + 
			"		bindSetData('kaijiangJl')\r\n" +
			"		save.push(\"kj\")\r\n" +
			"		})\r\n" +
	  		"	if(width<=300){\r\n" + 
	  		"		$(\".name\").css(\"font-size\",\"12px\")\r\n" + 
	  		"		$(\".c-span-lastPeriod\").css(\"font-size\",\"12px\")\r\n" + 
	  		"		$(\".gray\").css(\"font-size\",\"12px\")\r\n" + 
	  		"	}else{\r\n" + 
	  		"		$(\".name\").css(\"font-size\",\"13px\")\r\n" + 
	  		"		$(\".c-span-lastPeriod\").css(\"font-size\",\"13px\")\r\n" + 
	  		"		$(\".gray\").css(\"font-size\",\"13px\")\r\n" + 
	  		"	}\r\n" + 
	  		"		!function() {\r\n" + 
	  		"	 		\r\n" + 
	  		"			jianrong()\r\n" + 
	  		"			$(function(){\r\n" + 
	  		"				$(\".nav1 select\").change(function(){\r\n" + 
	  		"					var cla=$(\".nav1 select\").val();\r\n" + 
	  		"					$(\".cz\").addClass(\"hidden\");\r\n" + 
	  		"					$(\".\"+cla).removeClass(\"hidden\");\r\n" + 
	  		"				});\r\n" + 
	  		"			});\r\n" + 
	  		"			countdown()\r\n" + 
	  		"			daojishi2=window.setInterval(countdown, 7000)\r\n" + 
	  		"			function countdown(){\r\n" + 
	  		"           if($(\"#kj\").length==0){\r\n" + 
			"           clearInterval(daojishi2)\r\n" + 
			"           return;\r\n" + 
			"           }\r\n" +
	  		"				$.ajax({\r\n" + 
	  		"					url: \"/syLotterr1.do\",\r\n" + 
	  		"					type:'post',\r\n" + 
	  		"					data:{},\r\n" + 
	  		"					success:function(data){\r\n" + 
	  		"							if(data == 50) { \r\n" + 
			"								save.push(\"sy\")\r\n" + 
			"								bindSetData(\"login\") \r\n" + 
			"								return;\r\n" + 
			"		   					}else if(data==60){\r\n" + 
			"   							pagePreserve();\r\n" + 
			"   							return;\r\n" + 
			"   						}\r\n" +
	  		"						var timeSpace = data.data.timespace\r\n" + 
	  		"						var qihao = data.data.period\r\n" + 
	  		"						for(var j = 0;j<data.data.length;j++){\r\n" + 
	  		"							var item = data.data[j]\r\n" + 
	  		"						 	$(\".\"+item.cname+\"lotternumber\").html(\"\")\r\n" +
	  		"							var $nextPeriod = $(\".\"+item.cname+\"lastPeriod\").text(item.period)\r\n" + 
	  		"							/* var $nextPeriod = $(\".\"+item.cname+\"time\").text(item.lottertime.split(\" \")[1])	 */\r\n" + 
	  		"							var d = item.lotternumber.split(\",\")\r\n" + 
	  		"							var x = \"\";\r\n" + 
	  		"							 for(var i=0;i<d.length-1;i++){\r\n" + 
	  		"								if(item.cname==\"bjpk10\"||item.cname==\"2fpk10\"||item.cname==\"xyft\"||item.cname==\"xysm\" ||item.cname==\"2fft\"){\r\n" + 
	  		"									x+=\"<span class='qiu qiu\"+Number(d[i])+\"'>\"+d[i]+\"</span>\"\r\n" + 
	  		"									$(\".\"+item.cname+\"lotternumber\").html(x) \r\n" + 
	  		"								}else if(item.cname==\"xg6hc\" || item.cname==\"5f6hc\"){\r\n" + 
	  		"									if(i==d.length-2){\r\n" + 
	  		"										x+=\"<span style='font-size:16px;font-weight:bold;color:black'>+</span>\";\r\n" + 
	  		"									}\r\n" + 
	  		"									x+=\"<span class='qiu xg\"+Number(d[i])+\"'>\"+d[i]+\"</span>\"\r\n" + 
	  		"									$(\".\"+item.cname+\"lotternumber\").html(x) \r\n" + 
	  		"									$(\".\"+item.cname+\"lotternumber\").next().text(item.playResult)\r\n" +
	  		"								} else if(item.cname==\"ahk3\" || item.cname==\"gxk3\" || item.cname==\"jsk3\" || item.cname==\"3fk3\" || item.cname==\"bjk3\" || item.cname==\"2fk3\"){\r\n" + 
	  		"									x+=\"<span class='shaizi sz\"+d[i]+\"'></span>\"\r\n" + 
	  		"									$(\".\"+item.cname+\"lotternumber\").html(x) \r\n" + 
	  		"									$(\".\"+item.cname+\"lotternumber\").next().text(item.playResult)\r\n" +
	  		"								}else if(item.cname==\"bj28\" || item.cname==\"xy28\") {\r\n" + 
	  		"									var total=Number(d[0])+Number(d[1])+Number(d[2])\r\n" +
	  		"									if(i<d.length-2){\r\n" + 
	  		"										x+=\"<span class='qiu'>\"+d[i]+\"</span><span>+</span>\";\r\n" + 
	  		"									}else {\r\n" + 
	  		"										x+=\"<span class='qiu'>\"+d[i]+\"</span><span>=</span>\"+\"<span class='qiu'>\"+total+\"</span>\";\r\n" + 
	  		"									}\r\n" + 
	  		"									$(\".\"+item.cname+\"lotternumber\").html(x) \r\n" + 
	  		"								}else if(item.cname == 'xg6hc' || item.cname == '5f6hc'){\r\n" + 
		  	"									if(i==d.length-2){\r\n" + 
		  	"										x1+=\"<span style='font-size:16px;font-weight:bold;color:black'>+</span>\";\r\n" + 
		  	"									}\r\n" + 
		  	"									x1+=\"<span class='shengxiao'>\"+d[i]+\"</span>\"\r\n" +
		  	"									$(\".\"+item.cname+\"lotternumber\").html(x) \r\n" + 
		  	"									$(\".\"+item.cname+\"lotternumber\").next().text(item.playResult)\r\n" + 
		  	"									if (blueArr.indexOf(d[i]) != -1) {\r\n" + 
		  	"										xg6hcBackGround = \"style='background-color:#336DCC;'\"\r\n" + 
		  	"									}\r\n" + 
		  	"									else if (greenArr.indexOf(d[i]) != -1) {\r\n" + 
		  	"										xg6hcBackGround = \"style='background-color:#09B832;'\"\r\n" + 
		  	"									}	\r\n" + 
		  	"								}else{\r\n" + 
	  		"									x+=\"<span class='qiu'>\"+d[i]+\"</span>\"\r\n" + 
	  		"									$(\".\"+item.cname+\"lotternumber\").html(x) \r\n" + 
	  		"									if(item.cname.indexOf('ssc')!=-1){\r\n" +
	  		"										$(\".\"+item.cname+\"lotternumber\").next().text(item.playResult)\r\n" +
	  		"									}\r\n" +
	  		"								}\r\n" + 
	  		"							} \r\n" + 
	  		"						}\r\n" + 
	  		"					},\r\n" + 
	  		"			  }) \r\n" +
	  		"			}\r\n" + 
	  		"			var allLiItems = $(\"#cai li\")\r\n" + 
	  		"			for (var i = 0; i < allLiItems.length; i++) {\r\n" + 
	  		"				var item = allLiItems[i]\r\n" + 
	  		"				if (item.dataset.cname == \"bjl\") {\r\n" + 
	  		"					$(item).find(\".not\").html(\"在线百家乐，30秒一期，好玩又刺激!<br>最高中奖10万人民币！\")\r\n" + 
	  		"				}\r\n" + 
	  		"			}\r\n" + 
	  		"		}.call() </script>";
	  return string+string2;
	}
	
	public String zs() {
		List<LotterExample> lotterList = lotterService.getAllLotters();
		String string = "<style type=\"text/css\"> html, body{ width:100%; }.red{color:red;}.kl28 .div-c-qihaoTableItem:last-child{border-bottom:1px solid #eaeaea;} .borderLine{border-left:1px solid #eaeaea;line-height:30px;}.div-c-qihaoTableItem .borderLine:last-child{border-right:1px solid #eaeaea;}    #dataContent { overflow:auto; -webkit-overflow-scrolling : touch; position: relative; } .div-c-tabBar { display:flex; flex-wrap:wrap; justify-content:center; background-color:white; } .div-c-tabItem { border-radius: 4px; border:1px solid #ddd; display:inline-block; font-size:16px; font-weight:bold; width:18%; margin:2px; text-align: center; } .div-c-tabItem-active { color:white; background-color:#059BF3; border:1px solid #059BF3; } .div-c-contentQihaoTitle { font-size:12px; display:flex; justify-content:center; align-items:center; flex:4; } #dataContent .div-c-qihaoTableItem:nth-child(odd) { background-color: rgb(221, 221, 221); } .div-c-qihaoTableItem { display:flex; } .div-c-contentQihaoTitleItem { display:inline-flex; justify-content:center; align-items:center; padding:2px; font-size:12px; flex:1; border-left:1px solid #bdbdbd; } .div-c-contentQihaoTitleItem > span { font-size:12px; } .div-c-hideNumber { color:#aaa; } .site-welcome { position: fixed; top:0; left:0; right:0; bottom:0; display: none; align-items:center; justify-content:center; background-color:#ded9d9; z-index: 300; } .site-welcome.active { display:flex; } .lotterNumber { color:#fff; background-color:#5891db; border-radius: 50%; padding:0; font-size:13px; width:5.5vw; height:5.5vw; max-width:25px; max-height:25px; display:inline-flex; justify-content:center; align-items:center; z-index:2; } .canvas-c-qiuLine { position: absolute; top:0; left:0; } .div-c-contentDataDiv { position: relative; } /*div-c-tabItem-active*/ .loaddingCircle { width: 200px; height: 200px; position: relative; }  .loaddingCircle::before, .loaddingCircle::after { content: ''; width: 200px; height: 200px; background-color: rgba(73, 143, 199, 1); top: 0; left: 0; bottom: 0; right: 0; position: absolute; margin: auto; opacity: 0; border-radius: 50%; /*      -webkit-animation-name: bigger; -webkit-animation-duration: 1.5s; -webkit-animation-timing: linear; -webkit-animation-iteration-count: infinite; -webkit-backface-visibility: hidden;  */ -webkit-animation:bigger 1.5s linear infinite; }  @-webkit-keyframes bigger { from { -webkit-transform:scale(0); opacity: 1; } to { -webkit-transform:scale(1); opacity: 0; } }  .loaddingCircle::after { -webkit-animation-delay: 0.4s; } .div-c-headerWrapper { /* position: fixed; */ position: fixed; width:100%; top:0; z-index:250; -webkit-transform:translateX(-50%); transform:translateX(-50%); left:50%; } .div-c-tabItem { cursor: pointer; } </style>\r\n" + 
				"	<div class='wapper' id='zs' style=\"background: #F1F1F1 ;\">\r\n" + 
				"	    <div class=\"site-welcome\">\r\n" + 
				"	        <div class=\"loaddingCircle\"></div>\r\n" + 
				"	    </div>	\r\n" + 
				"		<div class=\"bg-theme col-xs-12 col-sm-4 col-sm-offset-4 text-center top\" stlye=\"padding-left:10px;padding-right:10px;\">\r\n" + 
				"			<!-- <a class=\"glyphicon glyphicon-chevron-left fl\" style=\"cursor:pointer; color: white;position:absolute;top:50%;transform:translateY(-50%);font-size: 20px;left:10px;\"></a> -->\r\n" + 
				"			<span style=\"font-weight:700;\"  id=\"strong-i-name\"></span>\r\n" + 
				"			<span id=\"hhh1\" class=\"glyphicon glyphicon-th-large fr\"  style=\"position:absolute;top:50%;transform:translateY(-50%);right:10px;font-size: 25px;\"></span>\r\n" + 
				"		</div>\r\n" + 
				"	    \r\n" + 
				"		<div class=\"div-c-main col-xs-12 col-sm-4 col-sm-offset-4\" style=\"margin-bottom: 60px;z-index: -1;overflow:scroll;\">\r\n" + 
				"			<div class=\"div-c-headerWrapper\" style=\"padding-left:0;padding-right:-10px;;\">\r\n" + 
				"				<div class=\"div-c-tabBar col-xs-12 col-sm-4 col-sm-offset-4\" style=\"margin-top: 50px;\">\r\n" + 
				"				</div>	\r\n" + 
				"			</div>\r\n" + 
				"			<div id=\"dataContent\" class='kl28'>\r\n" + 
				"				<canvas class=\"canvas-c-qiuLine\" style=\"margin-left: -3%;\"></canvas>\r\n" + 
				"			</div>\r\n" + 
				"		</div>	\r\n" + 
				"		<div class=\"modal fade   col-xs-12 col-sm-4 col-sm-offset-4\" id=\"myModal2\" tabindex=\"-1\" role=\"dialog\" aria-labelledby=\"myModalLabel\" aria-hidden=\"true\">\r\n" + 
				"		    <div class=\"modal-dialog\" style=\"max-width:100%;margin:0;margin-top: 50px;\">\r\n" + 
				"		        <div class=\"modal-content\" style=\"border-radius:0px;\">\r\n" + 
				"		            <div class=\"modal-body\" style=\"padding:10px 0;\">\r\n";
										for(LotterExample l : lotterList) {
											if(!"bjl".equals(l.getCname().trim())) {
												string +=	"<button cname="+l.getCname() +" class=\"btn btn-default bt	n-lg butter\" style=\"width:30%;margin: 1%;border-radius:1px;box-shadow: 3px 3px 3px gray;font-size: 13px;padding: 10px;text-align: center;\">"+l.getName()+"</button>\r\n";
											}
										}
	   string +="		            </div>\r\n" + 
				"		        </div>\r\n" + 
				"		    </div>\r\n" + 
				"		</div>\r\n" + 
				"	</div>"+
			   "	<div class=\"modal-div-fakeModal\" id=\"div-i-notice\">\r\n" + 
			   "			<div class=\"div-c-modalContent\">\r\n" + 
			   "				<h3 class=\"fakemodal-title\"></h3>\r\n" + 
			   "				<div class=\"fakemodal-content\"></div>\r\n" + 
			   "				<div class=\"fakemodal-btnsGroup\"><button class=\"btn btn-default btn-class-closeFakeModal\">关闭</button></div>\r\n" + 
			   "			</div>\r\n" + 
			   "		</div>\r\n";
	   String string2 = "	<script>\r\n" + 
			   "$(\"body\").css(\"height\",\"initial\")\r\n" + 
			"		lotterName=localStorage.getItem(\"lottername\")\r\n" + 
			"		if(lotterName==null || lotterName==undefined){\r\n" + 
			"			lotterName=\"北京PK拾\"\r\n" + 
			"		}\r\n" + 
			"		$(\"#strong-i-name\").text(lotterName)\r\n" + 
			"		$(\"#myModal2\").on(\"click\",\".butter\",function(){	\r\n" + 
			"			lotterName=$(this).text()\r\n" + 
			"			if(lotterName==\"广东快乐十分\" || lotterName==\"重庆快乐十分\" || lotterName==\"香港六合彩\" || lotterName==\"五分六合彩\" ){\r\n" + 
			"				 $(\"#myModal2\").modal(\"hide\")\r\n" + 
			"				showNormalNoticeModal(\"#div-i-notice\", \"提示\",lotterName+ \"暂无走势图\")\r\n" + 
			"					   setTimeout(function() {\r\n" + 
			"						    $(\"#div-i-notice\").attr(\"data-lock\",\"false\")\r\n" + 
			"						    $(\"#div-i-notice\").fadeOut();\r\n" + 
			"				 }, 1000)\r\n" + 
			"			}else{\r\n" + 
			"				$(\".div-c-qihaoTableItem\").remove();\r\n" + 
			"				localStorage.setItem(\"lottername\",lotterName)\r\n" + 
			"				localStorage.setItem(\"cname\",$(this).attr(\"cname\"))\r\n" + 
			"				$(\"#strong-i-name\").text($(this).text())\r\n" + 
			"				createHeaderAndTabItem()\r\n" + 
			"				$(\"#myModal2\").modal(\"hide\")\r\n" + 
			"			}\r\n" + 
			"		});"+
	   		"		$(\"#hhh1\").click(function(){\r\n" + 
	   		"			$(\"#myModal2\").modal(\"show\")\r\n" + 
	   		"		});\r\n" +
	   		"	 	var tabObj = {\r\n" + 
	   		"				\"1\": {\"tab\": [\"一位\", \"二位\", \"三位\", \"四位\", \"五位\",\"六位\", \"七位\", \"八位\", \"九位\", \"十位\"], \"qiushu\": [1,2,3,4,5,6,7,8,9,10],\"lotter\":[\"01\",\"02\",\"03\",\"04\",\"05\",\"06\",\"07\",\"08\",\"09\",\"10\"]},\r\n" + 
	   		"				\"2\": {\"tab\": [\"万\",\"千\",\"百\",\"十\",\"个\"], \"qiushu\": [0,1,2,3,4,5,6,7,8,9],\"lotter\":[\"0\",\"1\",\"2\",\"3\",\"4\",\"5\",\"6\",\"7\",\"8\",\"9\",]},\r\n" + 
	   		"				\"5\": {\"tab\":[\"万\",\"千\",\"百\",\"十\",\"个\"], \"qiushu\": [1,2,3,4,5,6,7,8,9,10,11],\"lotter\":[\"01\",\"02\",\"03\",\"04\",\"05\",\"06\",\"07\",\"08\",\"09\",\"10\",\"11\"]},\r\n" + 
	   		"				\"6\": {\"tab\":[\"香港\"]},\r\n" + 
	   		"				\"7\": {\"tab\":[\"百\",\"十\",\"个\"], \"qiushu\": [0,1,2,3,4,5,6,7,8,9],\"lotter\":[\"0\",\"1\",\"2\",\"3\",\"4\",\"5\",\"6\",\"7\",\"8\",\"9\",]},\r\n" + 
	   		"				\"8\": {\"tab\":[\"百\",\"十\",\"个\"], \"qiushu\": [1,2,3,4,5,6,],\"lotter\":[\"1\",\"2\",\"3\",\"4\",\"5\",\"6\"]},\r\n" + 
	   		"			/* 	\"4\": {\"tab\": [\"千万\",\"百万\",\"十万\",\"万\",\"千\",\"百\",\"十\",\"个\"], \"qiushu\": [0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19],\"lotter\":[\"0\",\"1\",\"2\",\"3\",\"4\",\"5\",\"6\",\"7\",\"8\",\"9\",\"10\",\"11\",\"12\",\"13\",\"14\",\"15\",\"16\",\"17\",\"18\",\"19\"]}, */\r\n" + 
	   		"		}\r\n" + 
	   		"	 	var CAIZHONG_STATE 	\r\n" + 
	   		"	 	var CAIZHONG_NAME = \"\"\r\n" + 
	   		" 		var setRestHeight = function() {\r\n" + 
	   		" 			var allHeight = document.documentElement.clientHeight\r\n" + 
	   		" 			var headerHeight = document.querySelector(\".bg-theme\").clientHeight\r\n" + 
	   		" 			var tabHeight = document.querySelector(\".div-c-tabBar\").clientHeight\r\n" + 
	   		" 			var restHeight = allHeight - headerHeight - tabHeight\r\n" + 
	   		" 			document.querySelector(\"#dataContent\").style.height = restHeight + \"px\"\r\n" + 
	   		" 		}\r\n" + 
	   		"	 	window.onload=function () {\r\n" + 
	   		"		    document.addEventListener('touchstart',function (event) {\r\n" + 
	   		"		        if(event.touches.length>1){\r\n" + 
	   		"		            event.preventDefault();\r\n" + 
	   		"		        }\r\n" + 
	   		"		    })\r\n" + 
	   		"		    var lastTouchEnd=0;\r\n" + 
	   		"		    document.addEventListener('touchend',function (event) {\r\n" + 
	   		"		        var now=(new Date()).getTime();\r\n" + 
	   		"		        if(now-lastTouchEnd<=300){\r\n" + 
	   		"		            event.preventDefault();\r\n" + 
	   		"		        }\r\n" + 
	   		"		        lastTouchEnd=now;\r\n" + 
	   		"		    },false)\r\n" + 
	   		"		}\r\n" + 
	   		"		\r\n" + 
	   		"	 	var ALL_DATA\r\n" + 
	   		" 		function drawLine(x1, y1, x2, y2) {\r\n" + 
	   		"	 		var selfHeight = (document.documentElement.clientWidth * 0.055)\r\n" + 
	   		"	 		if (selfHeight > 25) {\r\n" + 
	   		"	 			selfHeight = 25\r\n" + 
	   		"	 		}\r\n" + 
	   		"	 		selfHeight = selfHeight / 2\r\n" + 
	   		"	 		var moreHeight = document.querySelector(\"#dataContent\").offsetTop\r\n" + 
	   		" 			var CANVAS_CONTEXT = document.querySelector(\".canvas-c-qiuLine\").getContext(\"2d\")\r\n" + 
	   		"		    CANVAS_CONTEXT.lineWidth = 3 //lineWidth\r\n" + 
	   		"		    CANVAS_CONTEXT.lineJoin = \"round\" //是 canvas 画板让笔更加连续\r\n" + 
	   		"		    CANVAS_CONTEXT.lineCap = \"round\"\r\n" + 
	   		"		    CANVAS_CONTEXT.stfillStyle = \"rgb(88,145,217)\"\r\n" + 
	   		"		    CANVAS_CONTEXT.strokeStyle = \"rgb(88,145,217)\"\r\n" + 
	   		"		    CANVAS_CONTEXT.beginPath();\r\n" + 
	   		"	 		var xOffsetValue = document.querySelector(\".div-c-main\").offsetLeft\r\n" + 
	   		"		    CANVAS_CONTEXT.moveTo(x1 + selfHeight - xOffsetValue, y1 - moreHeight + selfHeight) // 起点\r\n" + 
	   		"		    CANVAS_CONTEXT.lineTo(x2 + selfHeight - xOffsetValue, y2 - moreHeight + selfHeight) // 终点\r\n" + 
	   		"		    CANVAS_CONTEXT.stroke()\r\n" + 
	   		"		    CANVAS_CONTEXT.closePath()\r\n" + 
	   		"		} 	\r\n" + 
	   		"		var bindTabItemEvent = function() {\r\n" + 
	   		"			$(\".div-c-tabBar .div-c-tabItem\").on(getEndClickEvent(), function(event) {\r\n" + 
	   		"				$(\".div-c-tabItem-active\").removeClass(\"div-c-tabItem-active\")\r\n" + 
	   		"				$(event.target).addClass(\"div-c-tabItem-active\")\r\n" + 
	   		"				$(\".lotterNumber\").removeClass(\"lotterNumber\").each(function(index, element) {\r\n" + 
	   		"					$(element).text($(element).closest(\".div-c-lotterNumberDiv\").index() - 1)\r\n" + 
	   		"				})\r\n" + 
	   		"				setLotterNumber(Number(event.target.dataset.index))\r\n" + 
	   		"				var allHighLightItems = document.querySelectorAll(\".lotterNumber\")\r\n" + 
	   		"				for (var j = 0; j < allHighLightItems.length; j++) {\r\n" + 
	   		"				if ((j + 1) == allHighLightItems.length) {\r\n" + 
	   		"					break\r\n" + 
	   		"				}\r\n" + 
	   		"				drawLine($(allHighLightItems[j]).offset().left, $(allHighLightItems[j]).offset().top,  $(allHighLightItems[j + 1]).offset().left, $(allHighLightItems[j + 1]).offset().top)\r\n" + 
	   		"			}					\r\n" + 
	   		"			})\r\n" + 
	   		"		}\r\n" + 
	   		"		\r\n" + 
	   		"		\r\n" + 
	   		"		var setLotterNumber = function(index) {\r\n" + 
	   		"			for (var i = 0; i < ALL_DATA.length; i++) {\r\n" + 
	   		"				var lotterResult = ALL_DATA[i].lotternumber\r\n" + 
	   		"				var lotterArray = lotterResult.slice(0, lotterResult.length - 1).split(\",\")\r\n" + 
	   		"				var qiuItem = lotterArray[index]\r\n" + 
	   		"				var qiuIndex = tabObj[CAIZHONG_STATE].lotter.indexOf(qiuItem)\r\n" + 
	   		"				var spanElement = $(\"#dataContent\").find(\".div-c-lotterNumberDiv\")[i].querySelectorAll(\".div-c-hideNumber\")[qiuIndex].querySelector(\"span\")\r\n" + 
	   		"				spanElement.classList.add(\"lotterNumber\")\r\n" + 
	   		"				if (qiuItem[0] == \"0\" && qiuItem.length > 1) {\r\n" + 
	   		"					qiuItem = qiuItem.slice(1, qiuItem.length)\r\n" + 
	   		"				}\r\n" + 
	   		"				spanElement.textContent = qiuItem\r\n" + 
	   		"			}\r\n" + 
	   		"			var cans = document.querySelector(\"#dataContent\").querySelector(\".canvas-c-qiuLine\")\r\n" + 
	   		"			var w = document.querySelector(\"#dataContent\").clientWidth\r\n" + 
	   		"			var h = document.querySelector(\"#dataContent\").clientHeight \r\n" + 
	   		"			cans.width = w\r\n" + 
	   		"			cans.height = h\r\n" + 
	   		"		}\r\n" + 
	   		"		\r\n" + 
	   		"		var lineAllLotterNumber = function() {\r\n" + 
	   		"			$(\".div-c-contentDataDiv\").each(function(index, element) {\r\n" + 
	   		"				var canvas = \"<canvas class='canvas-c-qiuLine'></canvas>\"\r\n" + 
	   		"				$(element).append(canvas)\r\n" + 
	   		"			})\r\n" + 
	   		"		}\r\n" + 
	   		"		\r\n" + 
	   		"		var setHaoMaData = function() {\r\n" + 
	   		"		var documentFragment = document.createDocumentFragment()\r\n" +
	   		"		if(CAIZHONG_NAME=='bj28' || CAIZHONG_NAME=='xy28'){\r\n" +
	   		"		$('.canvas-c-qiuLine').hide()\r\n" +
	   		"		var hongbo = ['1', '2', '7', '8', '12', '13','18', '19', '23', '24']\r\n" +
			"		var lanbo = ['3', '4', '9', '10', '14', '15', '20', '25', '26']\r\n" +
			"		var lvbo= ['0','5', '6', '11','16', '17', '21', '22', '27']\r\n" +
	   		"			for (var i = 0; i < ALL_DATA.length; i++) {\r\n" +
	   		"				var temp = \"\"\r\n" +
	   		"				var lotternumber=ALL_DATA[i].lotternumber.split(',')\r\n" +
	   		"				var total =Number(lotternumber[0])+Number(lotternumber[1])+Number(lotternumber[2]) \r\n" + 
	   		"				var allNumber=\"\"+lotternumber[0]+\"+\"+lotternumber[1]+\"+\"+lotternumber[2]+\"=\"+total+\"\"\r\n" +
	   		"				var size\r\n" +
	   		"				var oddEven\r\n" +
	   		"				var playing\r\n" +
	   		"				var boson\r\n" +
	   		"				if(total>0 && total<14){\r\n" + 
	   		"					size='小'\r\n" + 
	   		"				}else if(total>13 && total<28){\r\n" + 
	   		"					size='大'\r\n" + 
	   		"				}\r\n" + 
	   		"				if(total%2==0){\r\n" + 
	   		"					oddEven='双'\r\n" + 
	   		"				}else{\r\n" + 
	   		"					oddEven='单'\r\n" + 
	   		"				}\r\n" + 
	   		"				playing=size+oddEven\r\n" + 
	   		"				if(hongbo.indexOf(total+'')!=-1){\r\n" + 
	   		"					boson='红波'\r\n" + 
	   		"				}else if(lanbo.indexOf(total+'')!=-1){\r\n" + 
	   		"					boson='蓝波'\r\n" + 
	   		"				}else if(lvbo.indexOf(total+'')!=-1){\r\n" + 
	   		"					boson='绿波'\r\n" + 
	   		"				}\r\n" +
	   		"				var div = document.createElement(\"div\")\r\n" + 
	   		"				div.className = \"div-c-qihaoTableItem\"\r\n" + 
	   		"				div.innerHTML = \"<span class='div-c-contentQihaoTitle borderLine '>\"+ ALL_DATA[i].period +\"</span><span class='div-c-contentQihaoTitle borderLine red'>\"+ allNumber +\"</span>\"+\r\n" +
	   		"								\"<span class='div-c-contentQihaoTitle borderLine'>\"+ playing +\"</span><span class='div-c-contentQihaoTitle borderLine'>\"+ boson +\"</span>\"\r\n"+
	   		"				documentFragment.appendChild(div)\r\n" +
	   		"				$(\"#dataContent\")[0].appendChild(documentFragment)\r\n" +
	   		"			}\r\n" + 
	   		"		}else{\r\n" +
	   		"			$('.canvas-c-qiuLine').show()\r\n" +
	   		"			for (var i = 0; i < ALL_DATA.length; i++) {\r\n" +
	   		"				var temp = \"\"\r\n" + 
	   		"				for (var j = 0; j < tabObj[CAIZHONG_STATE].qiushu.length; j++) {\r\n" + 
	   		"					temp += \"<span class='div-c-contentQihaoTitleItem div-c-hideNumber'><span></span></span>\"\r\n" + 
	   		"				}\r\n" + 
	   		
	   		"				var div = document.createElement(\"div\")\r\n" + 
	   		"				div.className = \"div-c-qihaoTableItem div-c-lotterNumberDiv\"\r\n" + 
	   		"				div.innerHTML = \"<span class='div-c-contentQihaoTitle'>\"+ ALL_DATA[i].period +\"</span>\" + temp\r\n" + 
	   		"				if($(\"#dataContent\").length!=0){\r\n" +
	   		"					documentFragment.appendChild(div)\r\n" + 
	   		"				}\r\n" + 
	   		"				$(\"#dataContent\")[0].appendChild(documentFragment)\r\n" + 
	   		"			}\r\n" + 
	   		"			$(\".div-c-lotterNumberDiv\").each(function(index, element) {\r\n" + 
	   		"				var $Parent = $(element)\r\n" + 
	   		"				$Parent.find(\".div-c-hideNumber\").each(function(index, element) {\r\n" + 
	   		"					$(element).find(\"span\")[0].textContent = $Parent.index() - 1\r\n" + 
	   		"				})\r\n" + 
	   		"			})			\r\n" + 
	   		"			$(\".div-c-tabItem-active\").trigger(getEndClickEvent())\r\n" +
	   		"		}\r\n" + 
	   		"		}\r\n" + 
	   		"		var getHaoMaData = function() {\r\n" + 
	   		"		 	var urlPath = \"/caizhongjl.do\"\r\n" + 
	   		"				var newRequest = {\r\n" + 
	   		"					url: urlPath,\r\n" + 
	   		"					type: \"post\",\r\n" + 
	   		"					data: {cname: CAIZHONG_NAME},\r\n" + 
	   		"					success: function(data) {\r\n" + 
	   		"							if(data == 50) { \r\n" + 
			"								save.push(\"sy\")\r\n" + 
			"								bindSetData(\"login\") \r\n" + 
			"								return;\r\n" + 
			"		   					}else if(data==60){\r\n" + 
			"   							pagePreserve();\r\n" + 
			"   							return;\r\n" + 
			"   						}\r\n" +
	   		"						var newData = JSON.parse(data)\r\n" + 
	   		"						ALL_DATA = newData.data\r\n" + 
	   		"						setHaoMaData()\r\n" + 
	   		"					},\r\n" + 
	   		"					error: function(status) {\r\n" + 
	   		"					}\r\n" + 
	   		"				}\r\n" + 
	   		"				ajax(newRequest)\r\n" + 
	   		"		}\r\n" + 
	   		"		\r\n" + 
	   		"		var createHaoMaDiv = function() {\r\n" + 
	   		"		var kl28Array=['期号','开奖号码','大小单双','波色']\r\n" +
	   		"			var html = \"\"\r\n" + 
	   		"				if(CAIZHONG_NAME=='bj28' || CAIZHONG_NAME=='xy28' ) {\r\n" + 
	   		"				for (var i = 0; i < kl28Array.length; i++) {\r\n" + 
	   		"					var temp = \"<span class='div-c-contentQihaoTitle borderLine'>\" + kl28Array[i] + \"</span>\"\r\n" + 
	   		"					html += temp\r\n" + 
	   		"				}\r\n" +
	   		"				html = \"<div class='div-c-qihaoTableItem' style='border-top:1px solid #eaeaea; background: cadetblue;color: #fff;'>\" + html + \"</div>\"\r\n" +
	   		"				$(\"#dataContent\").append(html)\r\n" + 
	   		"				if($('#dataContent').length==1){\r\n" + 
	   		"					$(\"#dataContent\").css(\"margin-top\", (document.querySelector(\".div-c-headerWrapper\").clientHeight+20) + \"px\")\r\n" +
	   		"				}\r\n" + 
	   		"				getHaoMaData()\r\n" + 	
	   		"		   			\r\n" + 
	   		"		   		}else {\r\n" +
	   		"			var dataArray = tabObj[CAIZHONG_STATE].qiushu\r\n" + 
	   		"			for (var i = 0; i < dataArray.length; i++) {\r\n" + 
	   		"				var temp = \"<span class='div-c-contentQihaoTitleItem'>\" + dataArray[i] + \"</span>\"\r\n" + 
	   		"				html += temp\r\n" + 
	   		"			}\r\n" + 
	   		"			html = \"<div class='div-c-qihaoTableItem'><span class='div-c-contentQihaoTitle'>期号</span>\" + html + \"</div>\"\r\n" + 
	   		"			$(\"#dataContent\").append(html)\r\n" + 
	   		"			if($('#dataContent').length==1){\r\n" + 
	   		"				$(\"#dataContent\").css(\"margin-top\", (document.querySelector(\".div-c-headerWrapper\").clientHeight) + \"px\")\r\n" +
	   		"			}\r\n" + 
	   		"			getHaoMaData()\r\n" + 
	   		"			}\r\n" + 
	   		"		}\r\n" + 
	   		"		var createHeaderAndTabItem = function() {\r\n" + 
	   		" 			CAIZHONG_NAME = localStorage.getItem(\"cname\")\r\n" + 
	   		" 			if(CAIZHONG_NAME==null){\r\n" + 
	   		" 				CAIZHONG_NAME=\"bjpk10\";\r\n" + 
	   		" 			}\r\n" + 
	   		" 			\r\n" + 
	   		" 		 	var urlPath =\"/lotter/zoushitu.do\"\r\n" + 
	   		"				var newRequest = {\r\n" + 
	   		"					url: urlPath,\r\n" + 
	   		"					type: \"post\",\r\n" + 
	   		"					data: {cname: CAIZHONG_NAME},\r\n" + 
	   		"					success: function(data) {\r\n" + 
	   		"							if(data == 50) { \r\n" + 
			"								save.push(\"sy\")\r\n" + 
			"								bindSetData(\"login\") \r\n" + 
			"								return;\r\n" + 
			"		   					}else if(data==60){\r\n" + 
			"   							pagePreserve();\r\n" + 
			"   							return;\r\n" + 
			"   						}\r\n" + 
	   		"						$(\".div-c-tabBar\").empty()\r\n" + 
	   		"						CAIZHONG_STATE = data.data.zoushitu\r\n" + 
	   		"					/* 	try{ */\r\n" + 
	   		"						/* if(CAIZHONG_STATE==4 ||CAIZHONG_STATE==6){\r\n" + 
	   		"							alert(\"暂无走势图\")\r\n" + 
	   		"							CAIZHONG_STATE=1;\r\n" + 
	   		"							localStorage.setItem(\"cname\",\"bjpk10\")\r\n" + 
	   		"							localStorage.setItem(\"lottername\",\"北京PK拾\")\r\n" + 
	   		"						} */\r\n" +
	   		"						 if(CAIZHONG_STATE!=3){\r\n" + 
	   		"							var dataArray = tabObj[CAIZHONG_STATE][\"tab\"]\r\n" + 
	   		"							$(\".div-c-tabBar\").html(\"\")\r\n" + 
	   		"							for (var i = 0; i < dataArray.length; i++) {\r\n" + 
	   		"								var item = dataArray[i]\r\n" + 
	   		"								var html = \"<span class='div-c-tabItem' data-index='\" + i + \"'>\" + item + \"</span>\"\r\n" + 
	   		"								$(\".div-c-tabBar\").append(html)\r\n" + 
	   		"							}\r\n" + 
	   		"							$(\".div-c-tabBar .div-c-tabItem:first-child\").addClass(\"div-c-tabItem-active\")\r\n" + 
	   		"						}\r\n" + 
	   		"							//setRestHeight()\r\n" + 
	   		"							 createHaoMaDiv()\r\n" + 
	   		"							bindTabItemEvent() \r\n" + 
	   		"						/* }catch(e){\r\n" + 
	   		"						 	    alert(\"暂无走势图\")\r\n" + 
	   		"							localStorage.setItem(\"cname\",\"bjpk10\")\r\n" + 
	   		"							localStorage.setItem(\"lottername\",\"北京PK拾\")\r\n" + 
	   		"						} */\r\n" + 
	   		"						\r\n" + 
	   		"					},\r\n" + 
	   		"				}\r\n" + 
	   		"				$.ajax(newRequest)			\r\n" + 
	   		" 		}"+ 
	   		"	\r\n" + 
	   		"		var __main = function() {\r\n" + 
	   		" 			createHeaderAndTabItem()\r\n" + 
	   		" 		}\r\n" + 
	   		" 		__main()\r\n" + 
	   		"	</script>";
	   return string+string2;
	}
}
