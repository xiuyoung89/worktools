package com.ja.domain;

import java.io.Serializable;

public class AppDownload implements Serializable{
	
    /**
	 * 
	 */
	private static final long serialVersionUID = 1863762836708757299L;

	private Integer id;//app下载

    private String name;//app名称
    
    private String content;//app内容
    
    private String img_path_1;//图片路径
    
    private String img_path_2;//图片路径
    
    private String img_path_3;//图片路径
    
    private String img_path_4;//图片路径
    
    private String img_path_5;//图片路径
    
    private String android_path;//app名称
    
    private String ios_path;//app名称
    
    private String android_img; //安卓二维码
    
    private String ios_img; //苹果二维码
    
    private String pc_img; //主页背景图
    
    private String gc_img; //购彩背景图
    
    private String download_img; //下载页面背景图
    
    private Integer state;//使用状态
    
    private String note;//备注

	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public String getImg_path_1() {
		return img_path_1;
	}

	public void setImg_path_1(String img_path_1) {
		this.img_path_1 = img_path_1;
	}

	public String getImg_path_2() {
		return img_path_2;
	}

	public void setImg_path_2(String img_path_2) {
		this.img_path_2 = img_path_2;
	}

	public String getImg_path_3() {
		return img_path_3;
	}

	public void setImg_path_3(String img_path_3) {
		this.img_path_3 = img_path_3;
	}

	public String getImg_path_4() {
		return img_path_4;
	}

	public void setImg_path_4(String img_path_4) {
		this.img_path_4 = img_path_4;
	}

	public String getImg_path_5() {
		return img_path_5;
	}

	public void setImg_path_5(String img_path_5) {
		this.img_path_5 = img_path_5;
	}

	public String getAndroid_path() {
		return android_path;
	}

	public void setAndroid_path(String android_path) {
		this.android_path = android_path;
	}

	public String getIos_path() {
		return ios_path;
	}

	public void setIos_path(String ios_path) {
		this.ios_path = ios_path;
	}

	public String getAndroid_img() {
		return android_img;
	}

	public void setAndroid_img(String android_img) {
		this.android_img = android_img;
	}

	public String getIos_img() {
		return ios_img;
	}

	public void setIos_img(String ios_img) {
		this.ios_img = ios_img;
	}

	public String getPc_img() {
		return pc_img;
	}

	public void setPc_img(String pc_img) {
		this.pc_img = pc_img;
	}

	public String getGc_img() {
		return gc_img;
	}

	public void setGc_img(String gc_img) {
		this.gc_img = gc_img;
	}

	public String getDownload_img() {
		return download_img;
	}

	public void setDownload_img(String download_img) {
		this.download_img = download_img;
	}

	public Integer getState() {
		return state;
	}

	public void setState(Integer state) {
		this.state = state;
	}

	public String getNote() {
		return note;
	}

	public void setNote(String note) {
		this.note = note;
	}

	public AppDownload() {
		super();
	}

	@Override
	public String toString() {
		return "AppDownload [id=" + id + ", name=" + name + ", content=" + content + ", img_path_1=" + img_path_1
				+ ", img_path_2=" + img_path_2 + ", img_path_3=" + img_path_3 + ", img_path_4=" + img_path_4
				+ ", img_path_5=" + img_path_5 + ", android_path=" + android_path + ", ios_path=" + ios_path
				+ ", android_img=" + android_img + ", ios_img=" + ios_img + ", pc_img=" + pc_img + ", gc_img=" + gc_img
				+ ", download_img=" + download_img + ", state=" + state + ", note=" + note + "]";
	}
}