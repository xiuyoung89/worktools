package com.ja.check.action;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Random;
import java.util.Set;

public class Combine {

	private static ArrayList<String> tmpArr = new ArrayList<>();

	/**
	 * N个数字或字符 取M个一组 的所有组合
	 * @param index 起始数
	 * @param k 几个一组
	 * @param arr    要组合的 数字或字符
	 * @param ccArr  接收的排好后的 组合
	 */
	public static void combine(int index, int k, String[] arr, ArrayList<String> ccArr) {
		Arrays.sort(arr);
		if (k == 1) {
			for (int i = index; i < arr.length; i++) {
				tmpArr.add(arr[i]);
				ccArr.add(tmpArr.toString().replace("[", "").replace("]", "").replace(", ", ","));
				tmpArr.remove((Object) arr[i]);
			}
		} else if (k > 1) {
			for (int i = index; i <= arr.length - k; i++) {
				tmpArr.add(arr[i]);
				combine(i + 1, k - 1, arr, ccArr);
				tmpArr.remove((Object) arr[i]);
			}
		}
	}
	
	/**
	 * 指定范围内取不重复随机数
	 * @param count 取值范围0-count-1
	 * @param size 取值下标的数量
	 * @param array 取值的数组
	 * @param nums 接收开奖号码
	 */
	public static void distinctNum(int count, int size, String[] array, List<String> nums) {
		String str = "";
		Set<Integer> set = new HashSet<>();
		for (int i = 0; i < 10000; i++) {
			set.add(new Random().nextInt(count));
			if (set.size() == size) {
				break;
			}
		}
		for (int index : set) {
			str += array[index] + ",";
		}
		nums.add(str);
	}


	
}
