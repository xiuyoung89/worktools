package com.ja.sevice;

import java.util.List;

import com.ja.domain.LuckyCount;
import com.ja.domain.LuckyLotter;
import com.ja.domain.LuckyRecord;

public interface LuckyRecordService {

	/**查询所有的奖品属性*/
	List<LuckyLotter> getAllLuckyLotter();
	
	/**修改幸运大转盘的属性*/
	int updateLotterData(LuckyLotter lucky);
	
	/**添加会员的抽奖信息*/
	int addLuckyRecord(LuckyRecord record);

	/**根据id查询当前用户的抽奖信息*/
	List<LuckyRecord> getOneLuckyRecord(Integer id);
	
	/**查询所有的用户抽奖信息*/
	List<LuckyRecord> getAllLuckyRecord();

	/**剩余抽奖次数*/
	LuckyCount getOneLuckyCount(Integer id);

	/**修改中奖次数*/
	int updateLuckyCount(LuckyCount counts);

	/**根据id查询信息*/
	LuckyLotter getOneLuckyLotter(Integer id);

	/**最新5条*/
	List<LuckyRecord> getMathLuckyRecord();
	/**
	 * 根据用户名修改用户摇奖次数
	 * @param counts
	 * @return
	 */
	int updateyaojiang(String name,Integer count);
	
	/**
	 * 查询全部用户的摇奖次数
	 * @return
	 */
	List<LuckyCount> frequency();
	
	LuckyCount frequencyuser(String name);
}
