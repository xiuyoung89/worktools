package com.ja.dao;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.ja.domain.TodayRecord;

public interface TodayRecordMapper {
	
	/**
	 * 
	 * ----TODO：报表管理
	 * 
	 */
	
	/**
	 *   方法名：findByTimeAllGlobalReport   
	 *   描述：    根据时间查询平台或用户的总计                   TODO   
	 *   参数：    @param startTime 开始时间
	 *   参数：    @param endTime 结束时间
	 *   参数：    @param userName 用户名
	 *   参数：    @param type 查询类型 1平台 2用户
	 *   参数：    @return 
	 * @return: TodayRecord
	 */
	TodayRecord findByTimeAllGlobalReport(@Param("date1")String startTime, @Param("date2")String endTime, @Param("name")String userName,@Param("type")Integer type);

	/**
	  *   方法名：findTimeUserIdYesterdayTotal   
	  *   描述：    根据时间和用户id查询统计情况                   TODO   
	  *   参数：    @param findLatelyDate
	  *   参数：    @param id
	  *   参数：    @return 
	 * @return: List<TodayRecord>
	 */
	List<TodayRecord> findByTimeUserIdYesterdayTotal(@Param("date")String date, @Param("user_id")Integer user_id);
	
	/**
	 * 方法名：insertTodayRecord 
	 * 描述：     添加用户和平台昨天的统计                 
	 * 参数：    @param record
	 * 参数：    @return 
	 * @return: int
	 */
	int insertTodayRecord(TodayRecord record);

	/**
	 * 方法名：findByIdTimeAllGlobalReport 
	 * 描述：    同时根据多名用户id查询代理下级总计                     
	 * 参数：    @param startTime 开始时间
	 * 参数：    @param endTime 结束时间
	 * 参数：    @param ids 用户id集合
	 * 参数：    @param i
	 * 参数：    @return 
	 * @return: TodayRecord
	 */
	TodayRecord findByIdTimeAllGlobalReport(@Param("date1")String startTime, @Param("date2")String endTime, @Param("ids")String ids,  @Param("count")int i);
	


	
}