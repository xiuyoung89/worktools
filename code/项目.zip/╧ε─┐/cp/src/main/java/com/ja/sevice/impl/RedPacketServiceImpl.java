package com.ja.sevice.impl;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.ja.dao.RedPacketMapper;
import com.ja.domain.RedPacket;
import com.ja.sevice.RedPacketService;

@Service
public class RedPacketServiceImpl implements RedPacketService {

	@Resource
	private RedPacketMapper redPacketMapper;
	
	public RedPacket searchById(Integer id){
		return redPacketMapper.selectByPrimaryKey(id);
	}
	
	@Transactional
	public int insert(RedPacket redPacket) {
		return redPacketMapper.insert(redPacket);
	}
	
	@Transactional
	public int update(RedPacket redPacket) {
		return redPacketMapper.updateByPrimaryKey(redPacket);
	}
	
	@Transactional
	public int delete(Integer id){
		return redPacketMapper.deleteByPrimaryKey(id);
	}

	@Override
	public void updredPack(Integer id, String linqu) {
		redPacketMapper.updredPack(id, linqu);
	}

	@Override
	public int saveUserChatRecord(RedPacket redPacket) {
		return redPacketMapper.saveUserChatRecord(redPacket);
	}

	@Override
	public List<RedPacket> getAllRedPackage() {
		return redPacketMapper.getAllRedPackage();
	}

	@Override
	public RedPacket LatestRedenvelopes() {
		return redPacketMapper.LatestRedenvelopes();
	}

	@Override
	public List<RedPacket> findUserChatRecord() {
		return redPacketMapper.findUserChatRecord();
	}

	@Override
	public int deleteUserChatRecord(String time) {
		return redPacketMapper.deleteUserChatRecord(time);
	}

	@Override
	public int deleteByIdUserChatRecord(Integer id) {
		return redPacketMapper.deleteByIdUserChatRecord(id);
	}


}