package com.ja.dao;

import java.util.List;

import com.ja.domain.KeFuQuick;

public interface KeFuQuickMapper {

	/**
	 * 查询所有的快捷回复
	 * @return
	 */
	List<KeFuQuick> findAllKeFuQuick();
	
	/**
	 * 根据类型查询快捷回复
	 * @param type 回复类型
	 * @return
	 */
	List<KeFuQuick> findTypeKeFuQuick(Integer type);
	
	/**
	 * 根据关键类型查询快捷回复
	 * @param type 类型 0客服 1会员
	 * @param keyWord 搜索关键词
	 * @return
	 */
	List<KeFuQuick> findLikeContentType(Integer type,String keyWord);

	/** 
	 * 添加客服咨询快捷回复
	 * @param keFuQuick 回复信息
	 * @return
	 */
	int addKeFuQuick(KeFuQuick keFuQuick);

	/** 
	 * 修改客服咨询快捷回复
	 * @param keFuQuick 回复信息
	 * @return
	 */
	int updateKeFuQuick(KeFuQuick keFuQuick);

	/**
	 * 删除客服咨询快捷回复
	 * @param id 删除的id
	 * @return
	 */
	int deleteKeFuQuick(Integer id);


}