package com.ja.controller;

import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

import com.ja.domain.AdminUser;
import com.ja.domain.IndexPicture;
import com.ja.domain.InfoNotice;
import com.ja.domain.UserNotice;
import com.ja.sevice.InfoNoticeService;
import com.ja.sevice.OperationlogService;
import com.ja.util.DateUtil;
import com.ja.util.JsonResult;
import com.ja.util.UploadUtil;

/**
 * 项目名称：cp   
 * 类名称：Ht_InfoNoticeController.java   
 * 类描述：   
 * 创建人：   GL
 * 创建时间：2019年2月21日 下午5:43:49   
 * @version v1.0.0
 */

@Controller
@RequestMapping("/infoNotice")
public class Ht_InfoNoticeController {

	@Autowired
	private InfoNoticeService infoNoticeService;

	@Autowired
	private OperationlogService operationlogService;
	
	
	/**
	 * 
	 * ---- TODO：首页公告管理
	 * 
	 */
	

	/**
	 * 方法名：noticeRelease 
	 * 描述：     首页公告管理页面                 
	 * 参数：    @return 
	 * @return: String
	 */
	@RequestMapping("/noticeRelease")
	public String noticeRelease() {
		return "htgl/ggfbgl";
	}

	/**
	 * 方法名：findInfoNotice 
	 * 描述：     查询所有的信息公告                 
	 * 参数：    @return 
	 * @return: JsonResult
	 */
	@ResponseBody
	@RequestMapping("/findInfoNotice")
	public JsonResult findInfoNotice() {
		return new JsonResult("success", infoNoticeService.getAllInfoNotice());
	}

	/**
	 * 方法名：addInfoNotice 
	 * 描述：     新增公告信息                 
	 * 参数：    @param info 公告信息
	 * 参数：    @param session
	 * 参数：    @param request
	 * 参数：    @return 
	 * @return: ModelAndView
	 */
	@RequestMapping("/addInfoNotice")
	public ModelAndView addInfoNotice(InfoNotice info, HttpSession session, HttpServletRequest request) {
		ModelAndView modelAndView = new ModelAndView("/htgl/ggfbgl");
		AdminUser admin1 = (AdminUser) session.getAttribute("admin1");
		info.setNoticeState(1);
		info.setCreateTime(DateUtil.getCurrTime());
		info.setUpdateName(admin1.getName());
		infoNoticeService.addInfoNotice(info);
		String remarks = "新增了一条："+info.getNoticeType()+"公告信息!";
		operationlogService.addOperationlog((AdminUser)session.getAttribute("admin1"),remarks,"首页公告管理");
		return modelAndView;
	}

	/**
	 * 方法名：updInfoNotice 
	 * 描述：    修改公告信息                  
	 * 参数：    @param info 公告信息
	 * 参数：    @param session
	 * 参数：    @return 
	 * @return: ModelAndView
	 */
	@RequestMapping("/updInfoNotice")
	public ModelAndView updInfoNotice(InfoNotice info, HttpSession session) {
		ModelAndView modelAndView = new ModelAndView("/htgl/ggfbgl");
		AdminUser admin1 = (AdminUser) session.getAttribute("admin1");
		info.setNoticeState(1);
		info.setCreateTime(DateUtil.getCurrTime());
		info.setUpdateName(admin1.getName());
		infoNoticeService.updInfoNotice(info);
		String remarks = "修改了一条："+info.getNoticeType()+"公告信息!";
		operationlogService.addOperationlog((AdminUser)session.getAttribute("admin1"),remarks,"首页公告管理");
		return modelAndView;
	}

	/**
	 * 方法名：updInfoNoticeState 
	 * 描述：     禁用或启用公告                 
	 * 参数：    @param state 1启用 0禁用
	 * 参数：    @param id 操作id
	 * 参数：    @return 
	 * @return: JsonResult
	 */
	@ResponseBody
	@RequestMapping("/updInfoNoticeState")
	public JsonResult updInfoNoticeState(Integer state,Integer id,HttpSession session) {
		String type = "启用了";
		if(state==0){
			type = "禁用了";
		}
		String remarks = type+"一条id为："+id+"的公告信息!";
		operationlogService.addOperationlog((AdminUser)session.getAttribute("admin1"),remarks,"首页公告管理");
		return new JsonResult("success", infoNoticeService.updInfoNoticeState(state,id));
	}
	
	/**
	 * 方法名：delInfoNotice 
	 * 描述：    删除公告信息                  
	 * 参数：    @param id 操作id
	 * 参数：    @return 
	 * @return: JsonResult
	 */
	@ResponseBody
	@RequestMapping("/delInfoNotice")
	public JsonResult delInfoNotice(Integer id,HttpSession session) {
		String remarks = "删除了一条id为："+id+"的公告信息!";
		operationlogService.addOperationlog((AdminUser)session.getAttribute("admin1"),remarks,"首页公告管理");
		return new JsonResult("success", infoNoticeService.delInfoNotice(id));
	}
	
	/**
	 * 
	 * ---- TODO：用户通知管理
	 * 
	 */
	
	/**
	 * 方法名：messageNotice 
	 * 描述：   用户通知管理页面                   
	 * 参数：    @return 
	 * @return: String
	 */
	@RequestMapping("/InformationNotice") 
	public String messageNotice() {
		return "htgl/xinxigonggao";
	}
	
	/**
	 * 方法名：findAllUserNotices 
	 * 描述：    查询用户通知信息                 
	 * 参数：    @return 
	 * @return: JsonResult
	 */
	@ResponseBody 
	@RequestMapping("/findAllUserNotices")
	public JsonResult findAllUserNotices() {
		return new JsonResult("success",infoNoticeService.findAllUserNotices());  
	}
	
	/**
	 * 方法名：findAllUserNotices 
	 * 描述：   根据id查询用户通知信息                      
	 * 参数：    @param id 查询id
	 * 参数：    @return 
	 * @return: JsonResult
	 */
	@ResponseBody 
	@RequestMapping("/findByIdAllUserNotices")
	public JsonResult findAllUserNotices(Integer id) {
		return new JsonResult("success",infoNoticeService.findByIdAllUserNotices(id));  
	}
	
	/**
	 * 方法名：saveUserNotice 
	 * 描述：     添加或修改用户通知信息                 
	 * 参数：    @param notice
	 * 参数：    @return 
	 * @return: JsonResult
	 */
	@ResponseBody 
	@RequestMapping("/saveUserNotice")
	public JsonResult saveUserNotice(HttpSession session,UserNotice notice) {
		String remarks = "修改了一条通知标题为："+notice.getTitle()+"的用户通知信息!";
		if(-1==notice.getId()) {
			remarks = "新增了一条通知标题为："+notice.getTitle()+"的用户通知信息!";
		}
		operationlogService.addOperationlog((AdminUser)session.getAttribute("admin1"),remarks,"用户通知管理");
		return new JsonResult("success",infoNoticeService.saveUserNotice(notice));  
	}
	
	/**
	 * 方法名：deleteUserNotice 
	 * 描述：   删除用户通知信息                      
	 * 参数：    @param id 删除id
	 * 参数：    @return 
	 * @return: JsonResult
	 */
	@ResponseBody 
	@RequestMapping("/deleteUserNotice")
	public JsonResult deleteUserNotice(HttpSession session,Integer id) {
		String remarks = "删除了一条id为："+id+"的用户通知信息!";
		operationlogService.addOperationlog((AdminUser)session.getAttribute("admin1"),remarks,"用户通知管理");
		return new JsonResult("success",infoNoticeService.deleteUserNotice(id));  
	}
	

	/**
	 * 
	 * ---- TODO：轮播发布管理
	 * 
	 */
	
	/**
	 * 方法名：wheelPlantingReleasePage 
	 * 描述：    轮播发布管理页面                  
	 * 参数：    @return 
	 * @return: String
	 */
	@RequestMapping("/lbtglshow")
	public String wheelPlantingReleasePage() {
		return "htgl/lbtpgl";
	}

	/**
	 * 方法名：allIndexPicture 
	 * 描述：    查询轮播图信息                  
	 * 参数：    @return 
	 * @return: JsonResult
	 */
	@ResponseBody
	@RequestMapping("/allIndexPicture")
	public JsonResult findWheelPlantingInfo() {
		return new JsonResult("success", infoNoticeService.getAllIndexPicture());
	}

	/**
	 * 方法名：addIndexPicture 
	 * 描述：    新增轮播图信息                  
	 * 参数：    @param pictureName 轮播标题
	 * 参数：    @param pictureType 轮播类型
	 * 参数：    @param session
	 * 参数：    @param file1 图片1
	 * 参数：    @param file2 图片2
	 * 参数：    @param file3 图片3
	 * 参数：    @param file4 图片4
	 * 参数：    @param file5 图片5
	 * 参数：    @param request
	 * 参数：    @return 
	 * @return: ModelAndView
	 */
	@RequestMapping("/addIndexPicture")
	public ModelAndView addIndexPicture(String pictureName, String pictureType, HttpSession session,
			MultipartFile file1, MultipartFile file2, MultipartFile file3, MultipartFile file4, MultipartFile file5,
			HttpServletRequest request) {
		ModelAndView modelAndView = new ModelAndView("/htgl/lbtpgl");
		AdminUser admin1 = (AdminUser) session.getAttribute("admin1");
		SimpleDateFormat ss = new SimpleDateFormat("yyyyMMddHHmmss");
		UploadUtil uploadUtil = new UploadUtil();
		IndexPicture index = new IndexPicture();
		String path = "d:/cp/img/";
		String img = "img/";
		String fNames1 = "";
		String fNames2 = "";
		String fNames3 = "";
		String fNames4 = "";
		String fNames5 = "";
		String name1 = file1.getOriginalFilename();
		String name2 = file2.getOriginalFilename();
		String name3 = file3.getOriginalFilename();
		String name4 = file4.getOriginalFilename();
		String name5 = file5.getOriginalFilename();
		if (!name1.equals("")) {
			String[] names12 = name1.split("\\.");
			String names13 =  "lb" + ss.format(new Date()) + 1;
			String names14 = names13 + "." + names12[1];
			fNames1 = img +uploadUtil.upload(file1, request, names14, path);
		}
		if (!name2.equals("")) {
			String[] names22 = name2.split("\\.");
			String names23 =  "lb" + ss.format(new Date()) + 2;
			String names24 = names23 + "." + names22[1];
			fNames2 = img +uploadUtil.upload(file2, request, names24, path);
		}

		if (!name3.equals("")) {
			String[] names32 = name3.split("\\.");
			String names33 =  "lb" + ss.format(new Date()) + 3;
			String names34 = names33 + "." + names32[1];
			fNames3 = img +uploadUtil.upload(file3, request, names34, path);
		}

		if (!name4.equals("")) {
			String[] names42 = name4.split("\\.");
			String names43 =  "lb" + ss.format(new Date()) + 4;
			String names44 = names43 + "." + names42[1];
			fNames4 = img +uploadUtil.upload(file4, request, names44, path);
		}

		if (!name5.equals("")) {
			String[] names52 = name5.split("\\.");
			String names53 = "lb" + ss.format(new Date()) + 5;
			String names54 = names53 + "." + names52[1];
			fNames5 = img + uploadUtil.upload(file5, request, names54, path);
		}
		index.setPictureState(1);
		index.setPictureName(pictureName);
		index.setPictureType(pictureType);
		index.setPicturePath1(fNames1);
		index.setPicturePath2(fNames2);
		index.setPicturePath3(fNames3);
		index.setPicturePath4(fNames4);
		index.setPicturePath5(fNames5);
		index.setPictureState(1);
		index.setUpdateName(admin1.getName());
		index.setCreateTime(DateUtil.getCurrTime());
		infoNoticeService.addIndexPicture(index);
		
		String remarks = "增加了一条标题为："+pictureName+"类型为： "+pictureType+"的轮播信息!";
		operationlogService.addOperationlog((AdminUser)session.getAttribute("admin1"),remarks,"轮播发布管理");
		return modelAndView;
	}

	/**
	 * 方法名：updIndexPicture 
	 * 描述：     修改轮播图信息                 
	 * 参数：    @param pictureName 轮播标题
	 * 参数：    @param pictureType 轮播类型
	 * 参数：    @param id 轮播id
	 * 参数：    @param session
	 * 参数：    @param file1 图片1
	 * 参数：    @param file2 图片2
	 * 参数：    @param file3 图片3
	 * 参数：    @param file4 图片4
	 * 参数：    @param file5 图片5
	 * 参数：    @param request
	 * 参数：    @return 
	 * @return: ModelAndView
	 */
	@RequestMapping("/updIndexPicture")
	public ModelAndView updIndexPicture(String pictureName, String pictureType, Integer id, HttpSession session,
			MultipartFile file1, MultipartFile file2, MultipartFile file3, MultipartFile file4, MultipartFile file5,
			HttpServletRequest request) {
		ModelAndView modelAndView = new ModelAndView("/htgl/lbtpgl");
		AdminUser admin1 = (AdminUser) session.getAttribute("admin1");
		SimpleDateFormat ss = new SimpleDateFormat("yyyyMMddHHmmss");
		UploadUtil uploadUtil = new UploadUtil();
		String path = "d:/cp/img/";
		IndexPicture index = new IndexPicture();
		IndexPicture picture = infoNoticeService.getOneByIdIndexPicture(id);
		String name1 = "";
		String name2 = "";
		String name3 = "";
		String name4 = "";
		String name5 = "";
		String fNames1 = "";
		String fNames2 = "";
		String fNames3 = "";
		String fNames4 = "";
		String fNames5 = "";
		String img = "img/";
		if (file1.getOriginalFilename() == "") {
			fNames1 = picture.getPicturePath1();
		} else {
			name1 = file1.getOriginalFilename();
			String[] names12 = name1.split("\\.");
			String names13 = "lb" + ss.format(new Date()) + 1;
			String names14 = names13 + "." + names12[1];
			fNames1 = img + uploadUtil.upload(file1, request, names14, path);
		}

		if (file2.getOriginalFilename() == "") {
			fNames2 = picture.getPicturePath2();
		} else {
			name2 = file2.getOriginalFilename();
			String[] names22 = name2.split("\\.");
			String names23 =  "lb" + ss.format(new Date()) + 2;
			String names24 = names23 + "." + names22[1];
			fNames2 = img +uploadUtil.upload(file2, request, names24, path);
		}
		
		if (file3.getOriginalFilename() == "") {
			fNames3 = picture.getPicturePath3();
		} else {
			name3 = file3.getOriginalFilename();
			String[] names32 = name3.split("\\.");
			String names33 =  "lb" + ss.format(new Date()) + 2;
			String names34 = names33 + "." + names32[1];
			fNames3 = img +uploadUtil.upload(file3, request, names34, path);
		}

		if (file4.getOriginalFilename() == "") {
			fNames4 = picture.getPicturePath4();
		} else {
			name4 = file4.getOriginalFilename();
			String[] names42 = name4.split("\\.");
			String names43 = "lb" + ss.format(new Date()) + 4;
			String names44 = names43 + "." + names42[1];
			fNames4 =  img +uploadUtil.upload(file4, request, names44, path);
		}

		if (file5.getOriginalFilename() == "") {
			fNames5 = picture.getPicturePath5();
		} else {
			name5 = file5.getOriginalFilename();
			String[] names52 = name5.split("\\.");
			String names53 =  "lb" + ss.format(new Date()) + 5;
			String names54 = names53 + "." + names52[1];
			fNames5 = img +uploadUtil.upload(file5, request, names54, path);
		}
		index.setId(id);
		index.setPictureName(pictureName); 
		index.setPictureType(pictureType);
		index.setPicturePath1(fNames1);
		index.setPicturePath2(fNames2);
		index.setPicturePath3(fNames3);
		index.setPicturePath4(fNames4);
		index.setPicturePath5(fNames5);
		index.setUpdateName(admin1.getName());
		index.setPictureState(1);
		index.setCreateTime(DateUtil.getCurrTime());
		infoNoticeService.updIndexPicture(index);
		String remarks = "修改了一条标题为："+pictureName+"类型为： "+pictureType+"的轮播信息!";
		operationlogService.addOperationlog((AdminUser)session.getAttribute("admin1"),remarks,"公告发布管理");
		return modelAndView;
	}
	
	/**
	 * 方法名：updIndexPictureState 
	 * 描述：    启用禁用轮播图信息                  
	 * 参数：    @param id 启用或禁用id
	 * 参数：    @param state 1启用 0禁用
	 * 参数：    @return 
	 * @return: JsonResult
	 */
	@ResponseBody
	@RequestMapping("/updIndexPictureState")
	public JsonResult updIndexPictureState(HttpSession session,Integer id,Integer state) {
		String type = "启用了";
		if(state==0){
			type = "禁用了";
		}
		String remarks = type+"了一条id为："+id+"的轮播信息!";
		operationlogService.addOperationlog((AdminUser)session.getAttribute("admin1"),remarks,"轮播发布管理");
		return new JsonResult("success", infoNoticeService.updIndexPictureState(id,state));
	}
	
	/**
	 * 方法名：delIndexPictures 
	 * 描述：    删除轮播单张图片                 
	 * 参数：    @param id 删除id
	 * 参数：    @param countPicture 删除图片名称
	 * 参数：    @return 
	 * @return: JsonResult
	 */
	@ResponseBody
	@RequestMapping("/delIndexPictures")
	public JsonResult delIndexPictures(HttpSession session,Integer id,String countPicture) {
		String remarks = "删除了一条id为："+id+"的轮播信息里的一张图片名为："+countPicture+"的轮播图片!";
		operationlogService.addOperationlog((AdminUser)session.getAttribute("admin1"),remarks,"轮播发布管理");
		return new JsonResult("success", infoNoticeService.delIndexPictures(id,countPicture));
	}

	/**
	 * 方法名：delIndexPicture 
	 * 描述：    删除轮播图信息                  
	 * 参数：    @param id 删除id
	 * 参数：    @return 
	 * @return: JsonResult
	 */
	@ResponseBody
	@RequestMapping("/delIndexPicture")
	public JsonResult delIndexPicture(HttpSession session,Integer id) {
		String remarks = "删除了一条id为："+id+"的轮播信息!";
		operationlogService.addOperationlog((AdminUser)session.getAttribute("admin1"),remarks,"轮播发布管理");
		return new JsonResult("success",infoNoticeService.delIndexPicture(id));
	}
	

}
