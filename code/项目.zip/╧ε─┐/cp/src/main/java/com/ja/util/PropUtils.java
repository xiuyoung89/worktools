package com.ja.util;

import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Properties;

public class PropUtils {

	public static String readProp(String key) {
		
		Properties prop = new Properties();
		try {
			prop.load(new InputStreamReader(PropUtils.class.getClassLoader().getResourceAsStream("param.properties"),
					"UTF-8"));
		} catch (IOException e) {
			System.out.println("读取配置文件异常:" + e);
		}
		return prop.getProperty(key);
	}

}
