package com.ja.domain;

import java.io.Serializable;

public class Logonlog implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1889679920037685846L;

	private Integer id;
	
	private String accountnumber;
	
	private String superrecord;
	
	private String ip;
	
	private String operationtime;

    
    public static long getSerialversionuid() {
		return serialVersionUID;
	}
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getAccountnumber() {
		return accountnumber;
	}

	public void setAccountnumber(String accountnumber) {
		this.accountnumber = accountnumber;
	}

	public String getSuperrecord() {
		return superrecord;
	}

	public void setSuperrecord(String superrecord) {
		this.superrecord = superrecord;
	}

	public String getIp() {
		return ip;
	}

	public void setIp(String ip) {
		this.ip = ip;
	}

	public String getOperationtime() {
		return operationtime;
	}

	public void setOperationtime(String operationtime) {
		this.operationtime = operationtime;
	}

	@Override
	public String toString() {
		return "Logonlog [id=" + id + ", accountnumber=" + accountnumber + ", superrecord=" + superrecord + ", ip=" + ip
				+ ", operationtime=" + operationtime + "]";
	}
	
	
}
