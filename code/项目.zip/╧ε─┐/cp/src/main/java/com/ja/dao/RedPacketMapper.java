package com.ja.dao;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.ja.domain.RedPacket;

public interface RedPacketMapper {
	
    int deleteByPrimaryKey(@Param(value="id")Integer id);

    int insert(RedPacket redPacket);

    RedPacket selectByPrimaryKey(@Param(value="id")Integer id);

    int updateByPrimaryKey(RedPacket redPacket);

	void updredPack(@Param(value="id")Integer id, @Param(value="linqu")String linqu);
	
	/**系统发了哪些红包*/
	List<RedPacket> getAllRedPackage();
	
	RedPacket LatestRedenvelopes();
	
	
	
	/**
	 * 方法名：saveUserChatRecord 
	 * 描述：    保存用户聊天记录                   TODO
	 * 参数：    @param redPacket
	 * 参数：    @return 
	 * @return: int
	 */
	int saveUserChatRecord(RedPacket redPacket);
	
	/**
	 * 方法名：findUserChatRecord 
	 * 描述：    用户聊天室聊天记录                   TODO
	 * 参数：    @return 
	 * @return: List
	 */
	List<RedPacket> findUserChatRecord();

	/**
	 * 方法名：deleteUserChatRecord 
	 * 描述：    按时间删除用户聊天记录                   TODO
	 * 参数：    @param time 删除时间
	 * 参数：    @return 
	 * @return: int
	 */
	int deleteUserChatRecord(String time);

	/**
	 * 方法名：deleteByIdUserChatRecord 
	 * 描述：    按照id删除聊天记录                    TODO
	 * 参数：    @param id 删除id
	 * 参数：    @return 
	 * @return: int
	 */
	int deleteByIdUserChatRecord(Integer id);
	
	
}