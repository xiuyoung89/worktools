package com.ja.controller;

import java.text.NumberFormat;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.ja.domain.PagingData;
import com.ja.domain.User;
import com.ja.sevice.AgencyCenterSevice;
import com.ja.sevice.IUserService;
/**
 * 第二套代理系统
 * 代理系统 开户  下级调赔率  以及查询代理相关赔率数据
 * @author Administrator
 *
 */
import com.ja.util.JsonResult;
@Controller
@RequestMapping("/agencyCenter")
public class AgencyCenterController {
	
	
	@Autowired
	private AgencyCenterSevice agencyCenterSevice;
	
	@Autowired
	private IUserService userService;
	/**
	 * 实现代理开户  
	 * @param session 代理本身
	 *  @param odds 代理设置的赔率
	 * @param u 代理开户的用户
	 * @return 成功则放回1  失败则返回0 返回2则参数不对  返回3则用户名已存在 返回4代表 赔率格式传输错误 5超过了平台规定的最低赔率 6用户名已经存在  7则代表 已经是玩家账号不能成为代理
	 */
	@RequestMapping("/openAccount")
	@ResponseBody
	public JsonResult openAccount(HttpSession session,User u,String oddss) {
		User users = (User) session.getAttribute("user");
		User user = userService.checkUser(users.getName());
		return new JsonResult(null,agencyCenterSevice.openAccount(user,  u, oddss));
	}
	/**
	 * 获取当前代理的 最高可调动的赔率
	 * @param session
	 * @return 返回当前玩家最高可调动的赔率
	 */
	@RequestMapping("/highest")
	@ResponseBody
	public JsonResult highest(HttpSession session) {
		User users = (User) session.getAttribute("user");
		User user = userService.checkUser(users.getName());
		String str = "";
		if(user.getRemainder() != null) {
			NumberFormat nf= NumberFormat.getPercentInstance();
			nf.setMaximumFractionDigits(5);
			nf.setMaximumIntegerDigits(5);
			str = nf.format(user.getRemainder());
		}
		return new JsonResult(null,str);
	}
	
	/**
	 * 查询当前 代理的代理连接  第二套代理系统的
	 * @param gamePlayer 根据代理类型查询 传1 查询代理类型的  传0查询玩家类型的
	 * @return 查到则返回list集合包含AgentLink对象数据 如果没有查询到则返回一个空集合
	 */
	@RequestMapping("/pueryProxyLinks")
	@ResponseBody
	public JsonResult  pueryProxyLinks(HttpSession session,Integer gamePlayer) {
		User user = (User)session.getAttribute("user");
		return new JsonResult(null,agencyCenterSevice.pueryProxyLinks(user.getName(),gamePlayer));
	}
	/**
	 * 根据代理邀请码删除代理连接 以及邀请码
	 * @param session 后期代理对象 信息
	 * @param invitationCode 邀请码
	 * @return 成功则返回1  不成功可能返回0 一下
	 */
	@RequestMapping("/deleteAgenLink")
	@ResponseBody
	public JsonResult deleteAgenLink(HttpSession session,String invitationCode) {
		User u = (User)session.getAttribute("user");
		return new JsonResult(null,agencyCenterSevice.deleteAgenLink(u, invitationCode));
	} 
	
	/**
	 * 方法名：insertProxyLinks 
	 * 描述：     生成用户的推广链接                  
	 * 参数：    @param session
	 * 参数：    @param request
	 * 参数：    @param gamePlayer 代理还是玩家  0-玩家   1-代理    这个是第二套代理系统的 不要乱改
	 * 参数：    @return 返回0则代表 插入数据库失败 返回1 则代表成功  返回2 则代表赔率设置不对 3赔率大于平台规定的最低赔率 4则代表试玩账号不能申请成为代理
	 * 				5则代表 已经被上级设置成玩家账号不能成为代理  6则代表参数为空  
	 * @return: JsonResult
	 */
	@ResponseBody
	@RequestMapping("/insertProxyLinks")
	public JsonResult insertProxyLinks(HttpSession session, HttpServletRequest request,String odds,Integer gamePlayer) {
		User user = (User)session.getAttribute("user");
		return new JsonResult(null,agencyCenterSevice.insertProxyLinks(user, request, odds, gamePlayer));
	}
	
	/**
	 * 查询代理下级的投注记录
	 * @param session  获取代理的User对象信息
	 * @param xname 代理下级的用户名
	 * @param cname 彩种名
	 * @param date1 开始时间
	 * @param date2 结束时间
	 * @param state 开奖状态 1待开奖-2未中奖-3-已中奖-6-和局中奖-7-8-撤单  状态
	 * @return 查询到责返回List集合  没有查询到则返回一个空集合
	 */
	@ResponseBody
	@RequestMapping("/xjcathecticRecord")
	public String xjcathecticRecord(HttpSession session,PagingData paging,String xname,Integer state,String cname,String date1,String date2) {
		User user = (User) session.getAttribute("user");
		paging.setAllCount(agencyCenterSevice.xjcathecticRecords(user, xname, state, cname, date1, date2));
		paging.setList(agencyCenterSevice.xjcathecticRecord(paging.getStartIndex(),paging.getLineCount(),user, xname, state, cname, date1, date2));
		return PagingData.pagingData(paging);
	}
	/**
	 * 查询当前代理的下级 
	 * @param session  获取当前代理对象信息
	 * @param name 当前代理查询下级的用户名  搜索框
	 * @param cname 查询这个代理下面的用户  点击查询下级的
	 * @return  查询到下级则返回list集合没有查询到则返回一个空集合
	 */
	@ResponseBody
	@RequestMapping("/subordinate")
	public JsonResult subordinate(HttpSession session,String name,String cname) {
		User user = (User) session.getAttribute("user");
		return new JsonResult(null,agencyCenterSevice.subordinate(user, name,cname));
	}
	/**
	 * 查询下级交易记录  包括账户明细 流水表  提款充值 充值提现表 
	 * @param session 获取当前代理的对象信息 
	 * @param name  搜索下级流水的用户名
	 * @param cname 查询他某个下级代理的全部下级流水和 充值提款记录
	 * @param state  查询那个  0-账户明细  1-提现记录  2-充值记录
	 * @param date1 开始时间
	 * @param date2 结束时间
	 * @param paging  分页对象
	 * @return  查询到则返回list集合包含数据对象 如果没有查询到则返回空集合
	 */
	@ResponseBody
	@RequestMapping("/subordinatePipeline")
	public String subordinatePipeline(HttpSession session,PagingData paging,String name,String cname,Integer state,String date1,String date2) {
		User u = (User)session.getAttribute("user");
		return PagingData.pagingData(agencyCenterSevice.subordinatePipeline(paging, u, name,cname, state, date1, date2));
	}
}
