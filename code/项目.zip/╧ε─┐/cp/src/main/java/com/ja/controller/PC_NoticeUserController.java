package com.ja.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.ja.config.WebsiteStateConfig;
import com.ja.sevice.InfoNoticeService;
import com.ja.util.JsonResult;

@Controller
@RequestMapping("/notices")
public class PC_NoticeUserController {
	
	@Autowired
	private InfoNoticeService infoNoticeService;
	
	/***
	 *     查询所有的内部用户公告
	   *   方法名：findAllUserNotices   
	   *   描述：                       TODO   
	   *   参数：    @return 
	 * @return: JsonResult
	 */
	@ResponseBody 
	@RequestMapping("/findAllUserNotices")
	public JsonResult findAllUserNotices() {
		return new JsonResult("",infoNoticeService.findAllUserNotices());  
	}
	
	
	/***
	 * 		根据id查询内部公告
	   *   方法名：findByIdAllUserNotices   
	   *   描述：                       TODO   
	   *   参数：    @return 
	 * @return: JsonResult
	 */
	@ResponseBody 
	@RequestMapping("/findByIdAllUserNotices")
	public JsonResult findAllUserNotices(Integer id) {
		return new JsonResult("",infoNoticeService.findByIdAllUserNotices(id));  
	}
	
	/**
	 * 返回网站维护现在的状态是开启还是关闭状态
	 * @return  返回0 代表网站还在维护状态 返回1代表维护已经结束
	 */
	@ResponseBody 
	@RequestMapping("/error")
	public JsonResult errpr() {
		System.out.println(WebsiteStateConfig.configs.get("weihukaiguan")+"----------------我拿到的值");
		return new JsonResult("",WebsiteStateConfig.configs.get("weihukaiguan"));  
	}
	
	
}

