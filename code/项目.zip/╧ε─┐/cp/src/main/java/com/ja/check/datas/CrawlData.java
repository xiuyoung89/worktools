package com.ja.check.datas;

import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;

import com.ja.check.action.SystemLotter;
import com.ja.config.WebsiteStateConfig;
import com.ja.controller.ChatWebSocketHandler;

 
public final class CrawlData implements ServletContextListener {
	
	public static boolean stopIt = false;
	
	/**
	 * Tomcat启动时加载
	 */
	@Override
	public void contextInitialized(ServletContextEvent arg0) {
		WebsiteStateConfig.lotteryStateConfig("", 1);
		WebsiteStateConfig.webisteAllConfig(null);
		WebsiteStateConfig.totalTodayRecord();
		System.err.println("-----web服务器启动啦!-----");
	}
	
	/**
	 *Tomcat关闭时加载 
	 */
	@Override
	public void contextDestroyed(ServletContextEvent arg0) {
		/**
		 * 清除websocket里面的数据
		 */
		new ChatWebSocketHandler().removes();
		stopIt = true;
		SystemLotter.checkNums(0);
		System.err.println("-----web服务器关闭啦!-----");
	}

}