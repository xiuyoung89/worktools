package com.ja.sevice;

import java.util.List;

import com.ja.domain.Dama;
import com.ja.util.JsonResult;

public interface DamaService {

	/**查询所有打码记录
	 * @param i 
	 * @param integer2 
	 * @param integer */
	List<Dama> getAllDama(Integer integer, Integer integer2, int i);

	/**根据条件查询打码记录
	 * @param i 
	 * @param integer2 
	 * @param integer */
	List<Dama> getMhdama(Integer integer, Integer integer2, Dama dama,String date1,String date2, int i);

	/**增加当前用户的打码记录*/
	int addDama(Dama dama);

	/**查询用户今日打码量
	 * @param time */
	double getDmTodyJl1(Integer id, String time);
	double getDmTodyJl2(Integer id, String time);

	/**查询用户本月打码量*/
	double getDmMonthJl1(Integer id);
	double getDmMonthJl2(Integer id);
	
	/**上月打码量*/
	double getDmLastMonthJl1(Integer id, String time);
	double getDmLastMonthJl2(Integer id, String time);
	
	/**根据id查询打码量*/
    Dama getOneDamaJl(Integer id,String time);

    /**
     * 
       *   方法名：findByTimeCodeCount   
       *   描述：    根据时间查询打码量信息                   TODO   
       *   参数：    @param type
       *   参数：    @param user_id
       *   参数：    @return 
     * @return: JsonResult
     */
	JsonResult findByTimeCodeCount(Integer type,Integer user_id);


}
