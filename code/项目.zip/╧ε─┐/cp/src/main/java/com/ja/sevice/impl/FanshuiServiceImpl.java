package com.ja.sevice.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ja.dao.FanshuiMapper;
import com.ja.domain.Fanshui;
import com.ja.sevice.FanshuiService;

/**
 * @author GL 反水设置-
 * @DATE 2018年1月15日 18:03:40
 */
@Service
public class FanshuiServiceImpl implements FanshuiService {

	@Autowired
	private FanshuiMapper fanshuiMapper;
	
	@Override
	public List<Fanshui> getAllfanshui() {
		return fanshuiMapper.getAllfanshui();
	}

	@Override
	public int upfanshui(Fanshui s) {
		return fanshuiMapper.upfanshui(s);
	}

	@Override
	public int kaiqifs(int id,int state) {
		return fanshuiMapper.kaiqifs(id,state);
	}

	@Override
	public int insertBackwater(Fanshui fanshui) {
		return fanshuiMapper.insertBackwater(fanshui);
	}

	@Override
	public int deleteBackwater(Integer id) {
		return fanshuiMapper.deleteBackwater(id);
	}

	@Override
	public Fanshui findByIdBackWaterSetup(Integer id) {
		return fanshuiMapper.findByIdBackWaterSetup(id);
	}

}