package com.ja.sevice;

import java.util.List;

import com.ja.domain.AgentRecord;
import com.ja.domain.AgentTotal;
import com.ja.domain.PagingData;
import com.ja.domain.SetupAgent;
import com.ja.domain.TodayRecord;
import com.ja.domain.User;
import com.ja.util.JsonResult;

public interface AgentService {
	
	/**
	 * 
	 * 
	 * 
	 * --------------------------TODO: 代理第1套 后台返点设置
	 * 
	 * 
	 * 
	 */
	
	/**
	  * 方法名：findAgentSetup 
	  * 描述：    查询代理返点设置                  
	  * 参数：    @return 
	 * @return: List<SetupAgent>
	 */
	List<SetupAgent> findAgentSetup(); 
	
	/**
	 * 方法名：findByIdAgentSetup 
	 * 描述：     根据id查询代理返点设置                  
	 * 参数：    @param id
	 * 参数：    @return 
	 * @return: SetupAgent
	 */
	SetupAgent findByIdAgentSetup(Integer id);
	
	/**
	  * 方法名：insertAgentSetup 
	  * 描述：    添加返点设置                  
	  * 参数：    @param setupAgent 返点设置信息
	  * 参数：    @return 
	 * @return: String
	 */
	String insertAgentSetup(SetupAgent setupAgent);
	
	/**
	  * 方法名：updateAgentSetup 
	  * 描述：    修改返点设置                  
	  * 参数：    @param setupAgent 返点设置信息
	  * 参数：    @return 
	 * @return: String
	 */
	String updateAgentSetup(SetupAgent setupAgent);
	
	/**
	  * 方法名：deleteAgentSetup 
	  * 描述：    删除返点设置                  
	  * 参数：    @param id 删除的id
	  * 参数：    @return 
	 * @return: String
	 */
	String deleteAgentSetup(Integer id);

	/**
	 * 方法名：updateDailiRule 
	 * 描述：     修改代理返点和用户返水说明                 
	 * 参数：    @param rule 代理返点说明
	 * 参数：    @param rules 用户返水说明
	 * 参数：    @return 
	 * @return: int
	 */
	int updateDailiRule(String rule, String rules);
	
	
	/**
	 * 
	 * 
	 * 
	 * --------------------------TODO: 后台代理返点记录管理
	 * 
	 * 
	 * 
	 */

	/**
	 * 方法名：findAgentRecord 
	 * 描述：    查询代理返点记录                                    
	 * 参数：    @param paging 分页信息
	 * 参数：    @param startDate 开始时间
	 * 参数：    @param endDate 结束时间
	 * 参数：    @param userName 下级名称
	 * 参数：    @param agentName 代理名称
	 * 参数：    @return 
	 * @return: String
	 */
	String findAgentRecord(PagingData paging, String startDate, String endDate, String userName, String agentName);
	
	/**
	 * 
	 * 
	 * 
	 * --------------------------TODO: 后台代理管理
	 * 
	 * 
	 * 
	 */

	/**
	 *   方法名：findAllNodes   
	 *   描述：    查询当前代理的所有下级                      
	 *   参数：    @param id
	 *   参数：    @return 
	 * @return: List<User>
	 */
	List<User> findAllNodes(Integer id);

	/**
	 *   方法名：findUserSuperior   
	 *   描述：    查询用户的所有上级                      
	 *   参数：    @param agent_id
	 *   参数：    @return 
	 * @return: User
	 */
	User findUserSuperior(Integer agent_id);

	/**
	   *   方法名：findAllAgentsCounts   
	   *   描述：     查询代理的数量                     
	   *   参数：    @return 
	 * @return: Integer
	 */
	Integer findAllAgentsCounts();

	/**
	   *   方法名：findAllAgents   
	   *   描述：    查询代理的信息                      
	   *   参数：    @param paging
	   *   参数：    @return 
	 * @return: List<User>
	 */
	List<User> findAllAgents(PagingData paging);

	/**
	   *   方法名：findAgentTotalCounts   
	   *   描述：    查询下级返点详情的个数                     
	   *   参数：    @param id 上级id
	   *   参数：    @return 
	 * @return: Integer
	 */
	Integer findAgentTotalCounts(Integer id);


	/**
	 * 查询这个代理的全部下级  直属下级
	 * @param paging  分页对象  包含代理的id
	 * @return 查询到则返回代理下级  如果没有查询到则返回一个空集合
	 */
	List<User> findAgentTotals(PagingData paging);

	/**
	   *   方法名：findAgentDetailsCounts   
	   *   描述：    查询下级详情的个数                      
	   *   参数：    @param user_id
	   *   参数：    @param type
	   *   参数：    @return 
	 * @return: Integer
	 */
	Integer findAgentDetailsCounts(Integer user_id, String type);

	/**
	   *   方法名：findAgentDetailsCounts   
	   *   描述：      查询下级详情                        
	   *   参数：    @param paging
	   *   参数：    @return 
	 * @return: List<?>
	 */
	List<TodayRecord> findAgentDetails(PagingData paging);
	
	/**
	 * 
	 * 
	 * 
	 * --------------------------TODO: 代理第1套
	 * 
	 * 
	 * 
	 */
	
	/**
	 * 
	 * ---- TODO：用户显示页面
	 * 
	 */
	
	/**
	  * 方法名：findOneAgent 
	  * 描述：    查询所有的一级代理                  
	  * 参数：    @param startIndex 起始记录数
	  * 参数：    @param lineCount 每页行数
	  * 参数：    @param agent_id 代理id
	  * 参数：    @param type 查询类型
	  * 参数：    @return 
	 * @return: List<AgentTotal>
	 */
	List<AgentTotal> findOneAgent(Integer startIndex, Integer lineCount, Integer agent_id, int type);
	
	/**
	  * 方法名：findAllAgent 
	  * 描述：     查询一级代理下面的所有的代理                    
	  * 参数：    @param agent_id 代理id 
	  * 参数：    @param user_id 一级id
	  * 参数：    @return 
	 * @return: List<AgentTotal>
	 */
	List<AgentTotal> findAllAgent(Integer agent_id, Integer user_id); 
	
	/**
	  * 方法名：findAgentInfo 
	  * 描述：   根据用户名和等级查询代理下级的详情                     
	  * 参数：    @param name 下级用户名
	  * 参数：    @param agent_id 代理id
	  * 参数：    @param grade 下级等级
	  * 参数：    @return 
	 * @return: List<AgentTotal>
	 */
	List<AgentTotal> findAgentInfo(String name, Integer agent_id, Integer grade);
	
	/**
	  * 方法名：findAgentRebateSum 
	  * 描述：   查询当前代理的返点总额                     
	  * 参数：    @param startDate 开始时间
	  * 参数：    @param endDate 结束时间
	  * 参数：    @param agent_id 代理id
	  * 参数：    @return 
	 * @return: AgentTotal
	 */
	AgentTotal findAgentRebateSum(String startDate, String endDate, Integer agent_id);
	
	/**
	  * 方法名：findAgentRebateInfoCounts 
	  * 描述：    查询代理返点记录总数                
	  * 参数：    @param paging
	  * 参数：    @return 
	 * @return: Integer
	 */
	Integer findAgentRebateInfoCounts(PagingData paging);
	
	/**
	  * 方法名：findAgentRebateInfo 
	  * 描述：    查询代理下级的返点记录                  
	  * 参数：    @param startIndex 开始记录
	  * 参数：    @param lineCount 每页行数
	  * 参数：    @param startDate 开始时间
	  * 参数：    @param endDate 结束时间
	  * 参数：    @param agent_id 代理id
	  * 参数：    @param model 查询类型
	  * 参数：    @return 
	 * @return: List<AgentTotal>
	 */
	List<AgentRecord> findAgentRebateInfo(Integer startIndex, Integer lineCount, String startDate, String endDate, Integer agent_id, int model);
	
	/**
	  * 方法名：receiveAReturnPoint 
	  * 描述：   查询代理领取返点最低金额                  
	  * 参数：    @return 
	 * @return: Double
	 */
	Double receiveAReturnPoint();
	
	/**
	  * 方法名：findAllTeamRcord 
	  * 描述：   查询团队报表记录                   
	  * 参数：    @param startDate 开始时间
	  * 参数：    @param endDate 结束时间
	  * 参数：    @param agent_id 代理id
	  * 参数：    @return 
	 * @return: TodayRecord
	 */
	TodayRecord findAllTeamRcord(String startDate, String endDate, Integer agent_id);
	
	

	/**
	 * 
	 * 
	 * 
	 * --------------------------TODO: 代理第2套
	 * 
	 * 
	 * 
	 */
	
	/**
	  *  方法名：findAgentTeamRebate 
	  * 描述：    查询代理团队的佣金明细                  
	  * 参数：    @param startIndex 起始记录数
	  * 参数：    @param lineCount 每页行数
	  * 参数：    @param user 代理id
	  * 参数：    @param startTime 开始时间
	  * 参数：    @param endTime 结束时间
	  * 参数：    @return 
	 * @return: String
	 */
	String findAgentTeamRebate(PagingData paging,User user, String startTime, String endTime,Integer type);
	
	/**
	  * 方法名：findAgentTeamReport 
	  * 描述：    查询代理的团队报表                  
	  * 参数：    @param user
	  * 参数：    @param userName
	  * 参数：    @param time
	  * 参数：    @return 
	 * @return: JsonResult
	 */
	JsonResult findAgentTeamReport(User user, String time);

	/**
	 * 方法名：findAgentSubordinateReport 
	 * 描述：    查询下级的报表                  
	 * 参数：    @param user
	 * 参数：    @param userName
	 * 参数：    @param time
	 * 参数：    @return 
	 * @return: JsonResult
	 */
	JsonResult findAgentSubordinateReport(User user, String userName, String time);

	
}
