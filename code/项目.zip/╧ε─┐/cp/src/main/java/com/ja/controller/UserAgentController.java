package com.ja.controller;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.util.DigestUtils;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.ja.domain.Agent;
import com.ja.domain.AgentRebate;
import com.ja.domain.Jine;
import com.ja.domain.Liushui;
import com.ja.domain.Order;
import com.ja.domain.PagingData;
import com.ja.domain.TodayRecord;
import com.ja.domain.User;
import com.ja.sevice.ILotteryService;
import com.ja.sevice.ISystemConfigService;
import com.ja.sevice.IUserAgentService;
import com.ja.sevice.YunyingbbService;
import com.ja.util.DateUtil;
import com.ja.util.JsonResult;
import com.ja.util.SessionListenerUtil;

/**
 * 项目名称：cp   
 * 类名称：UserAgentController.java   
 * 类描述：   
 * 创建人：   GL
 * 创建时间：2019年2月25日 下午2:46:56   
 * @version v1.0.0
 */
@RequestMapping("/userAgent")
@Controller
public class UserAgentController {
	
	@Autowired
	private IUserAgentService userAgentService;
	
	@Autowired
	private ISystemConfigService systemConfigService;
	
	@Autowired
	private ILotteryService lotterService;
	
	@Autowired
	private YunyingbbService yunyingbbService;
	
	/**
	 * 
	 * ----TODO：总代理登录管理
	 * 
	 */
	
	/**
	 * 方法名：index 
	 * 描述：    主页页面                  
	 * 参数：    @return 
	 * @return: String
	 */
	@RequestMapping("/index")
	public String index(){
		return "daili/dailmain";
	}
	
	/**
	 * 方法名：showLogin 
	 * 描述：    总代理登录页面                  
	 * 参数：    @return 
	 * @return: String
	 */
	@RequestMapping("/login")
	public String showLogin(){
		return "daili/login";
	}
	
	/**
	 * 方法名：login 
	 * 描述：    总代理用户登录                  
	 * 参数：    @param name 用户名
	 * 参数：    @param pass 用户密码
	 * 参数：    @param session
	 * 参数：    @return 
	 * @return: JsonResult
	 */
	@RequestMapping("/doLogin")
	@ResponseBody
	public JsonResult login(HttpSession session, String name, String pass) {
		Agent agent = userAgentService.login(name,DigestUtils.md5DigestAsHex(DigestUtils.md5DigestAsHex(pass.getBytes()).getBytes()));
		if(agent!=null) {
			if (agent.getStatus() == 0) {
				return new JsonResult("-1", "账号已被禁用，请联系管理员！");
			} else {
				session.setAttribute("agent", agent);
				return new JsonResult("1", "登录成功!");
			}
		}else {
			return new JsonResult("0", "账号或者密码错误！");
		}
	}
	
	/**
	 * 方法名：logOut 
	 * 描述：    退出登录系统                  
	 * 参数：    @param session
	 * 参数：    @param response 
	 * @return: void
	 */
	@RequestMapping("/logOut")
	public String logOut(HttpSession session){
		session.invalidate();
		return "daili/login";
	}
	
	/**
	 * 方法名：online 
	 * 描述：    获取总代理下面的在线用户                  
	 * 参数：    @param session
	 * 参数：    @param request
	 * 参数：    @return 
	 * @return: JsonResult
	 */
	@RequestMapping("/online")
	@ResponseBody
	public JsonResult online(HttpSession session,HttpServletRequest request) {
		Set<User> set = SessionListenerUtil.onlineNum(request);
		List<User> list = new ArrayList<User>();
		for (User user : set) {
			if(user.getAgent_id() == getUserId(session)) {
				list.add(user);
			}
		}
		return new JsonResult("success",list);
	}
	
	/**
	 * 方法名：getUserId 
	 * 描述：    获取当前总代理的用户id                  
	 * 参数：    @param session
	 * 参数：    @return 
	 * @return: Integer
	 */
	private Integer getUserId(HttpSession session){
		Agent agent = (Agent) session.getAttribute("agent");
		if(agent !=null)
		return agent.getId();
		return -1;
	}
	
	
	/**
	 * 
	 *  ----TODO：下级列表管理
	 * 
	 */
	
	/**
	 * 方法名：userListPage 
	 * 描述：    下级列表页面                  
	 * 参数：    @return 
	 * @return: String
	 */
	@RequestMapping("/userListPage")
	public String userListPage(){
		return "daili/userList";
	}
	
	/**
	 * 根据用户登录的session查询代理
	 * @param session
	 * @param online 在想状态，null为不清楚，1为在线，2为离线         注:功能暂缺，数据库无相关字段
	 * @param accountType 账户类型null为全部，1为会员，2为代理
	 * @param account 根据会员名查询
	 * @return Json对象
	 * 
	 * 注意：代理的登录页面还未写,无法获得session，所以在调用showUser的参数固定为1
	 */
	@RequestMapping("/agentList")
	@ResponseBody
	public JsonResult showAgent(HttpSession session,Integer online, Integer accountType,String account){
		Integer id = getUserId(session);
		List<User> users = userAgentService.showUser(id, online, accountType, account);
		return new JsonResult(users.size()==0?"0":"1", users.size()==0?"未检索到信息":users);
	}
	
	
	/**
	 * 
	 *  ----TODO：游戏记录管理
	 * 
	 */
	
	/**
	 * 方法名：lotteryBettingPage 
	 * 描述：    彩种投注页面                   
	 * 参数：    @return 
	 * @return: ModelAndView
	 */
	@RequestMapping("/gameRecordPage")
	public ModelAndView lotteryBettingPage() {
		ModelAndView m = new ModelAndView("daili/gamerecord");
		m.addObject("lottery", lotterService.getAllLotter());
		return m;
	}
	
	/**
	 * 方法名：findBettingRecord 
	 * 描述：    根据条件查询代理下级的投注记录                  
	 * 参数：    @param paging
	 * 参数：    @param session
	 * 参数：    @param o
	 * 参数：    @param time
	 * 参数：    @param time1
	 * 参数：    @return 
	 * @return: String
	 */
	@ResponseBody 
	@RequestMapping("/findBettingRecord")
	public String findBettingRecord(PagingData paging,HttpSession session,Order o,String time,String time1) {
		Agent a = (Agent) session.getAttribute("agent");
		paging.setAllCount(userAgentService.noteRecord(a, o, time, time1,paging.getStartIndex(),paging.getLineCount(),0).size());
		paging.setList(userAgentService.noteRecord(a, o, time, time1,paging.getStartIndex(),paging.getLineCount(),1));
		return PagingData.pagingData(paging);  
	}
	
	/**
	 * 
	 *  ----TODO：团队帐变管理
	 * 
	 */
	
	/**
	 * 方法名：teamAccount 
	 * 描述：     团队帐变管理页面                 
	 * 参数：    @return 
	 * @return: String
	 */
	@RequestMapping("/teamAccount")
	public String teamAccount(){
		return "daili/teamAccount";
	}

	/**
	 * 根据条件找到流水对象集合
	 * @param date1	起始时间
	 * @param date2	结束时间
	 * @param account 账号名
	 * @param type  类型
	 * @param orderId 订单号
	 * @return
	 */
	@RequestMapping("/showList")
	@ResponseBody
	public JsonResult showList(HttpSession session,String date1, String date2, String account, String type,  String orderId){
		List<Liushui> list = userAgentService.findLiushui(date1, date2, account, type, orderId,(Agent)session.getAttribute("agent"));
		return new JsonResult("显示流水", list);
	}
	
	/**
	 * 
	 *  ----TODO：团队统计管理
	 * 
	 */
	
	/**
	 * 方法名：teamStatistics 
	 * 描述：    团队统计管理页面                  
	 * 参数：    @return 
	 * @return: String
	 */
	@RequestMapping("/teamStatistics")
	public String teamStatistics(){
		return "daili/teamStatistics";
	}
	
	/**
	 * 方法名：teamInfo 
	 * 描述：    根据条件查询团队的统计信息                  
	 * 参数：    @param startTime 开始时间
	 * 参数：    @param endTime 结束时间
	 * 参数：    @param userName 用户名
	 * 参数：    @param session
	 * 参数：    @return 
	 * @return: JsonResult
	 */
	@RequestMapping("/teamInfo")
	@ResponseBody
	public JsonResult teamInfo(HttpSession session,String startTime,String endTime,String userName){
		TodayRecord record = new TodayRecord();
		DecimalFormat dec = new DecimalFormat("#0.00");
		if(!"".equals(userName)) {
			if(DateUtil.findFormatDate().equals(startTime)&&DateUtil.findFormatDate().equals(endTime)) {
				record = yunyingbbService.findJuniorStatistics(startTime,endTime,userName,1,-1);
			}else if(DateUtil.findFormatDate().equals(startTime)||DateUtil.findFormatDate().equals(endTime)) {
				record = yunyingbbService.findJuniorStatistics(startTime,endTime,userName,2,-1);
			}else if("".equals(startTime)&&"".equals(endTime)){
				record = yunyingbbService.findJuniorStatistics(startTime,endTime,userName,2,-1);
			}else {
				record = yunyingbbService.findJuniorStatistics(startTime,endTime,userName,3,-1);
			}
			User user = userAgentService.findByNameUser(userName);
			if(user!=null) {
				record.setTuanduiyue(Double.parseDouble(dec.format(user.getBalance())));
			}else {
				record.setTuanduiyue(0.00);
				record.setOrderCount(0);
			}
		}else {
			List<User> users = userAgentService.findByGeneralAgentIdUser(getUserId(session));
			String userNames = "";
			double balances = 0.00;
			for(User user : users) {
				balances+=user.getBalance();
				userNames+=user.getId()+",";
			}
			if(users.size()<1) {
				userName = "-10";
			}
			userNames = userNames.substring(0,userNames.length()-1);
			if(DateUtil.findFormatDate().equals(startTime)&&DateUtil.findFormatDate().equals(endTime)) {
				record = yunyingbbService.findJuniorStatistics(startTime,endTime,userNames,1,-2);
			}else if(DateUtil.findFormatDate().equals(startTime)||DateUtil.findFormatDate().equals(endTime)) {
				record = yunyingbbService.findJuniorStatistics(startTime,endTime,userNames,2,-2);
			}else if("".equals(startTime)&&"".equals(endTime)){
				record = yunyingbbService.findJuniorStatistics(startTime,endTime,userNames,2,-2);
			}else {
				record = yunyingbbService.findJuniorStatistics(startTime,endTime,userNames,3,-2);
			}
			record.setTuanduiyue(Double.parseDouble(dec.format(balances)));
		}
		return new JsonResult("success", record);
	}
	
	
	/**
	 * 
	 *  ----TODO：推广链接管理
	 * 
	 */
	
	
	/**
	 * 方法名：showSalesCommission 
	 * 描述：    推广链接管理页面                  
	 * 参数：    @return 
	 * @return: String
	 */
	@RequestMapping("/showSalesCommission")
	public String showSalesCommission(){
		return "daili/salesCommission";
	}
	
	
	/**
	 * 获取用户的推广链接
	 * @param session
	 * @return
	 */
	@RequestMapping("/extensionLink")
	@ResponseBody
	public JsonResult extensionLink(HttpSession session) {
		return new JsonResult(null,userAgentService.queryAgentConnection((Agent)session.getAttribute("agent")));
	}
	
	
	
	
	
	/**
	 * 
	 *  ----TODO：取款日志管理
	 * 
	 */
	

	/**
	 * 方法名：withdrawalLog 
	 * 描述：    取款日志管理页面                  
	 * 参数：    @return 
	 * @return: String
	 */
	@RequestMapping("/withdrawalLog")
	public String withdrawalLog(){
		return "daili/withdrawalLog";
	}

	/**
	 * 根据条件查询金额记录
	 * @param session 传入代理的登录账号的id
	 * @param status 状态
	 * @param type 类型
	 * @param account 账户名
	 * @param date1 起始时间
	 * @param date2 结束时间
	 * @return 金额对象
	 */
	@RequestMapping("/findUserWithdrawalRecord")
	@ResponseBody
	public JsonResult findUserWithdrawalRecord(HttpSession session, String status,String type,String account,
		String date1,String date2){
		Integer id = getUserId(session);
		List<Jine> log = userAgentService.findJineByUserId(id, status, type, account, date1, date2);
		for (Jine j : log) {
			if(j.getFukuanje() != null && j.getTikuanje() != null) {
				j.setTikuanje(j.getFukuanje()+j.getTikuanje());
			}
		}
		return new JsonResult("显示取款记录", log);
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	

	/**
	 * 根据id查找用户
	 * @param id
	 * @return Json对象
	 */
	@RequestMapping("/showSelf")
	@ResponseBody
	public JsonResult showSelf(Integer id){
		User user = userAgentService.showSelf(id);
		return new JsonResult(user==null?"0":"1", user==null?"请重新登录您的账户":user);
	}
	
	/**
	 * 修改用户返点数
	 * @param id
	 * @param rebate
	 * @return Json对象
	 */
	@RequestMapping("/editDebate")
	@ResponseBody
	public JsonResult editDebate(Integer id,Double rebate){
		Integer affectRow = userAgentService.updateRebate(id, rebate);
		return new JsonResult("修改数据"+(affectRow==1?"成功":"失败"),affectRow);
	}
	

	
	
	/**
	 * 返回代理信息
	 * @param session
	 * @return
	 */
	@RequestMapping("/agentInfo")
	@ResponseBody
	public JsonResult agentInfo(HttpSession session){
		Integer id = getUserId(session);
		Agent agent = systemConfigService.findAgentById(id);
		return new JsonResult("agent",agent);
	}
	
	/**
	 * 编辑代理用户信息
	 * @param session 
	 * @param agent 用户提交过来的表单信息
	 * @return	Json对象
	 */
	@RequestMapping("/editAgent")
	@ResponseBody
	public JsonResult editAgent(HttpSession session,String oldPassword,String newPassword){
		Agent ag = (Agent) session.getAttribute("agent");
		Integer affectRow = 0;
		try {
			affectRow = userAgentService.editeAgent(ag.getId(),oldPassword,newPassword);
		} catch (RuntimeException e) {
			return new JsonResult(e.getMessage(), affectRow);
		}
		return new JsonResult("修改代理账户信息"+(affectRow==1?"成功":"失败"), affectRow);
	}
	
	/**
	 * 代理的业绩提成
	 * @param session
	 * @param date1
	 * @param date2
	 * @return
	 */
	@RequestMapping("/salesCommission")
	@ResponseBody
	public JsonResult salesCommission(HttpSession session,
			@RequestParam(value="date1",required=false) String date1,
			@RequestParam(value="date2",required=false) String date2){
		Integer id = getUserId(session);
		List<AgentRebate> agentRebate = userAgentService.findAgentRebate(id, date1, date2);
		return new JsonResult("返回代理反水对象", agentRebate);
	}

	
	/**
	 * 查询代理用户下注记录
	 * @return
	 */
	@RequestMapping("/idQuery")
	@ResponseBody
	public JsonResult idQuery(Integer id) {
		Order o = userAgentService.idQuery(id);
		if(o != null) {
			if(o.getLotternum() == null) {
				o.setLotternum("待开奖");
			}
		}
		return new JsonResult(null,o);
	}
}
