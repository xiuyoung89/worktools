package com.ja.domain;

import java.io.Serializable;

public class ScavengingPayment implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = -6771498761878883740L;

	private Integer id;//id
	
	private String name;//支付名称
	
	private String pictureAddress;//图片路径
	
	private String created_user;//创建人
	
	private String paymentType;//支付类型
	
	private String created_date;//创建时间
	
	private Integer state;//状态-0禁用-1启用
    
    public static long getSerialversionuid() {
		return serialVersionUID;
	}
	public String getPaymentType() {
		return paymentType;
	}

	public void setPaymentType(String paymentType) {
		this.paymentType = paymentType;
	}

	public Integer getState() {
		return state;
	}

	public void setState(Integer state) {
		this.state = state;
	}

	public String getCreated_user() {
		return created_user;
	}

	public void setCreated_user(String created_user) {
		this.created_user = created_user;
	}

	public String getCreated_date() {
		return created_date;
	}

	public void setCreated_date(String created_date) {
		this.created_date = created_date;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getPictureAddress() {
		return pictureAddress;
	}

	public void setPictureAddress(String pictureAddress) {
		this.pictureAddress = pictureAddress;
	}

	@Override
	public String toString() {
		return "ScavengingPayment [id=" + id + ", name=" + name + ", pictureAddress=" + pictureAddress
				+ ", created_user=" + created_user + ", paymentType=" + paymentType + ", created_date=" + created_date
				+ ", state=" + state + "]";
	}
	
	
}
