package com.ja.dao;

import org.apache.ibatis.annotations.Param;

import com.ja.domain.FalseMoney;
import com.ja.domain.Order;

public interface FalseMoneyMapper {

	/**添加假金额信息*/
	int addInfo(@Param("f") FalseMoney fm);

	/**查询金额*/
	double getMoneySum(@Param("o") Order o);

}