package com.ja.controller;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.UUID;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;

import com.ja.domain.Activity;
import com.ja.domain.AdminUser;
import com.ja.domain.LuckyCount;
import com.ja.domain.LuckyLotter;
import com.ja.sevice.IActivityService;
import com.ja.sevice.LuckyRecordService;
import com.ja.sevice.OperationlogService;
import com.ja.util.ImgUtil;
import com.ja.util.JsonResult;
import com.ja.util.UploadUtil;

/**
 * 项目名称：cp   
 * 类名称：Ht_ActivityController.java   
 * 类描述：   
 * 创建人：   GL
 * 创建时间：2019年2月22日 上午11:16:54   
 * @version v1.0.0
 */
@Controller
@RequestMapping("/activity")
public class Ht_ActivityController {

	@Autowired
	private IActivityService activityService;

	@Autowired
	private LuckyRecordService luckyRecordService;
	
	@Autowired
	private OperationlogService operationlogService;

	/**
	 * 
	 * ---- TODO：优惠活动管理
	 * 
	 */
	
	/**
	 * 方法名：preferentialActivityPage 
	 * 描述：     优惠活动管理页面                 
	 * 参数：    @return 
	 * @return: String
	 */
	@RequestMapping("/preferentialActivityPage")
	public String preferentialActivityPage() {
		return "htgl/ckzscl";
	}

	/**
	 * 方法名：richTextPictureUpload 
	 * 描述：    富文本框图片上传工能                 
	 * 参数：    @param file
	 * 参数：    @param req
	 * 参数：    @return 
	 * @return: String
	 */
	@ResponseBody
	@RequestMapping("/richTextPictureUpload")
	public String richTextPictureUpload(@RequestParam MultipartFile[] file, HttpServletRequest req) {
		System.out.println("我进来啦");
		String imgs = "";
		for (int i = 0; i < file.length; i++) {
			if (file[i].getOriginalFilename() != "") {
				String path = "d:/cp/admin/";
				UploadUtil uploadUitl = new UploadUtil();
				String name1 = file[i].getOriginalFilename();
				String[] name2 = name1.split("\\.");
				String name3 = "" + System.currentTimeMillis();
				String name4 = name3 + "." + name2[1];
				String img = "/d/cp/admin/" + uploadUitl.upload(file[i], req, name4, path);
				imgs += "\"" + img + "\",";
			}
		}
		return "{\"errno\":0,\"data\":[" + imgs.substring(0, imgs.lastIndexOf(",")) + "]}";
	}
	
	/**
	 * 方法名：allActivity 
	 * 描述：     显示所有的活动           
	 * 参数：    @return 
	 * @return: JsonResult
	 */
	@RequestMapping("/allActivity")
	@ResponseBody
	public JsonResult allActivity() {
		List<Activity> activity = activityService.findAllActivity();
		return new JsonResult(activity.size() > 0 ? "显示所有活动信息" : "未检索到信息", activity);
	}
	
	/**
	 * 方法名：addActivityInfo 
	 * 描述：    添加活动信息                  
	 * 参数：    @param file
	 * 参数：    @param activity
	 * 参数：    @param session
	 * 参数：    @param req
	 * 参数：    @return 
	 * @return: String
	 */
	@RequestMapping("/addActivityInfo")
	public String addActivityInfo(MultipartFile file, Activity activity, HttpSession session, HttpServletRequest req) {
		AdminUser admin = (AdminUser) session.getAttribute("admin1");
		if (file.getOriginalFilename() != "") {
			String path = "d:/cp/admin/";
			UploadUtil uploadUitl = new UploadUtil();
			String name1 = file.getOriginalFilename();
			String[] name2 = name1.split("\\.");
			String name3 = "" + System.currentTimeMillis();
			String name4 = name3 + "." + name2[1];
			activity.setPhoto_path("admin/" + uploadUitl.upload(file, req, name4, path));
		}
		if(activity.getType()!=2) {
			List<Activity> list = activityService.findActivityByType(activity.getType());
			if(list.size() > 0) {
				return "htgl/ckzscl";
			}
		}
		activity.setCreated_user(admin.getName());
		activity.setCreated_time(new Date());
		activityService.insertActivity(activity);
		String type = "";
		switch (activity.getType()) {
			case 0:
				type = "绑定银行卡送彩金";
				break;
			case 1:
				type = "在线充值赠送彩金";
				break;
			case 2:
				type = "普通活动";
				break;
		}
		String remarks = "新增了一条活动名为："+activity.getName()+",类型为："+type+"的优惠活动信息!";
		operationlogService.addOperationlog((AdminUser)session.getAttribute("admin1"),remarks,"优惠活动管理");
		return "htgl/ckzscl";
	}

	/**
	 * 方法名：editActivity 
	 * 描述：    修改活动内容                  
	 * 参数：    @param file
	 * 参数：    @param activity
	 * 参数：    @param req
	 * 参数：    @return 
	 * @return: String
	 */
	@RequestMapping("/editActivity")
	public String editActivity(HttpSession session,MultipartFile file, Activity activity,HttpServletRequest req) {
		if (file.getOriginalFilename() != "") {
			String path = "d:/cp/admin/";
			UploadUtil uploadUitl = new UploadUtil();
			String name1 = file.getOriginalFilename();
			String[] name2 = name1.split("\\.");
			String name3 = UUID.randomUUID().toString().replaceAll("-", "").substring(23).toUpperCase()
					+ System.currentTimeMillis();
			String name4 = name3 + "." + name2[1];
			activity.setPhoto_path("admin/" + uploadUitl.upload(file, req, name4, path));
		}
		activityService.updateActivity(activity);
		String remarks = "修改了一条活动名为："+activity.getName()+"的优惠活动信息!";
		operationlogService.addOperationlog((AdminUser)session.getAttribute("admin1"),remarks,"优惠活动管理");
		return "htgl/ckzscl";
	}

	/**
	 * 方法名：editStatus 
	 * 描述：     禁用启用活动                 
	 * 参数：    @param activity
	 * 参数：    @return 
	 * @return: JsonResult
	 */
	@RequestMapping("/editStatus")
	@ResponseBody
	public JsonResult editStatus(HttpSession session,Activity activity) {
		Integer affectRow = activityService.updateActivity(activity);
		String type = "禁用了"; 
		if(activity.getStatus()==1) {
			type = "启用了";
		}
		String remarks = type+"了一条活动id为："+activity.getId()+"的优惠活动!";
		operationlogService.addOperationlog((AdminUser)session.getAttribute("admin1"),remarks,"优惠活动管理");
		return new JsonResult("修改状态" + (affectRow == 1 ? "成功" : "失败"), affectRow);
	}

	/**
	 * 方法名：editAlter 
	 * 描述：    修改弹窗内容                  
	 * 参数：    @param activity
	 * 参数：    @return 
	 * @return: JsonResult
	 */
	@RequestMapping("/editAlter")
	@ResponseBody
	public JsonResult editAlter(HttpSession session,Activity activity) {
		Integer affectRow = activityService.updateAlter(activity);
		String remarks = "修改了一条活动id为："+activity.getId()+"的优惠活动内容!";
		operationlogService.addOperationlog((AdminUser)session.getAttribute("admin1"),remarks,"优惠活动管理");
		return new JsonResult("修改状态" + (affectRow == 1 ? "成功" : "失败"), affectRow);
	}

	/**
	 * 方法名：deleteActivity 
	 * 描述：   删除活动                   
	 * 参数：    @param id
	 * 参数：    @return 
	 * @return: JsonResult
	 */
	@RequestMapping("/deleteActivity")
	@ResponseBody
	public JsonResult deleteActivity(HttpSession session,Integer id) {
		String remarks = "删除了一条活动id为："+id+"的优惠活动信息!";
		operationlogService.addOperationlog((AdminUser)session.getAttribute("admin1"),remarks,"优惠活动管理");
		return new JsonResult("success", activityService.deletehd(id));
	}

	/**
	 * 方法名：sortActivity 
	 * 描述：    对活动进行排序                  
	 * 参数：    @param sort 排序号
	 * 参数：    @param id 要排序活动的id
	 * 参数：    @return 
	 * @return: JsonResult
	 */
	@RequestMapping("/sortActivity")
	@ResponseBody
	public JsonResult sortActivity(HttpSession session,Integer sort,Integer id) {
		String remarks = "排序了一条活动id为："+id+",并设置排序号为："+sort+"的优惠活动信息!";
		operationlogService.addOperationlog((AdminUser)session.getAttribute("admin1"),remarks,"优惠活动管理");
		return new JsonResult("success",activityService.sortActivity(sort,id));
	}
	
	/**
	 * 
	 * ---- TODO：幸运抽奖管理
	 * 
	 */
	
	/**
	 * 方法名：luckyPage 
	 * 描述：    幸运大转盘界面                 
	 * 参数：    @return 
	 * @return: String
	 */
	@RequestMapping("/luckyPage")
	public String luckyPage() {
		return "/htgl/zhuanpanguanli";
	}

	/**
	 * 方法名：getAllLuckyLotter 
	 * 描述：     查询所有的奖品属性                 
	 * 参数：    @return 
	 * @return: JsonResult
	 */
	@RequestMapping("/getAllLuckyLotter")
	@ResponseBody
	public JsonResult getAllLuckyLotter() {
		return new JsonResult("success", luckyRecordService.getAllLuckyLotter());
	}

	/**
	 * 方法名：getAllLuckCheck 
	 * 描述：    查询所有的抽奖记录                  
	 * 参数：    @return 
	 * @return: JsonResult
	 */
	@RequestMapping("/getAllLuckCheck")
	@ResponseBody
	public JsonResult getAllLuckCheck() {
		return new JsonResult("success", luckyRecordService.getAllLuckyRecord());
	}

	/**
	 * 方法名：updateLuckyAttr 
	 * 描述：     转盘奖品属性设置                  
	 * 参数：    @param lucky
	 * 参数：    @return 
	 * @return: JsonResult
	 */
	@RequestMapping("/updateLuckyAttr")
	@ResponseBody
	public JsonResult updateLuckyAttr(HttpSession session, String lucky) {
		SimpleDateFormat ss = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		String time = ss.format(new Date());
		String[] luckyss = lucky.split("&");

		String[] lucky1 = luckyss[0].split(",");
		String[] lucky2 = luckyss[1].split(",");
		String[] lucky3 = luckyss[2].split(",");
		String[] lucky4 = luckyss[3].split(",");
		String[] lucky5 = luckyss[4].split(",");
		String[] lucky6 = luckyss[5].split(",");
		String[] lucky7 = luckyss[6].split(",");
		String[] lucky8 = luckyss[7].split(",");

		String[] a1 = { "特等奖", lucky1[0], lucky1[1] };
		String[] a2 = { "二等奖", lucky2[0], lucky2[1] };
		String[] a3 = { "三等奖", lucky3[0], lucky3[1] };
		String[] a4 = { "四等奖", lucky4[0], lucky4[1] };
		String[] a5 = { "五等奖", lucky5[0], lucky5[1] };
		String[] a6 = { "六等奖", lucky6[0], lucky6[1] };
		String[] a7 = { "幸运奖", lucky7[0], lucky7[1] };

		String p1 = "祝你好运";
		String p2 = "d:/cp/lucky/lucky1.png";
		String path = "d:/cp/lucky/lucky2.png";

		boolean flag = ImgUtil.createImage(p1, p2, a1, a2, a3, a4, a5, a6, a7, path);
		if (flag == false) {
			return new JsonResult("", "系统异常,请联系平台管理员");
		}

		List<LuckyLotter> list = new ArrayList<LuckyLotter>();

		LuckyLotter l1 = new LuckyLotter();
		l1.setId(1);
		l1.setLotterType("特等奖");
		l1.setLotterMoney(lucky1[0] + "," + lucky1[1]);
		l1.setLotterPicture(path);
		l1.setCreateTime(time);
		l1.setRebate(Double.parseDouble(lucky1[2]));
		list.add(l1);
		
		LuckyLotter l2 = new LuckyLotter();
		l2.setId(2);
		l2.setLotterType("二等奖");
		l2.setLotterMoney(lucky2[0] + "," + lucky2[1]);
		l2.setLotterPicture(path);
		l2.setCreateTime(time);
		l2.setRebate(Double.parseDouble(lucky2[2]));
		list.add(l2);
		
		LuckyLotter l3 = new LuckyLotter();
		l3.setLotterType("三等奖");
		l3.setId(3);
		l3.setLotterMoney(lucky3[0] + "," + lucky3[1]);
		l3.setLotterPicture(path);
		l3.setCreateTime(time);
		l3.setRebate(Double.parseDouble(lucky3[2]));
		list.add(l3);
		
		LuckyLotter l4 = new LuckyLotter();
		l4.setLotterType("四等奖");
		l4.setId(4);
		l4.setLotterMoney(lucky4[0] + "," + lucky4[1]);
		l4.setLotterPicture(path);
		l4.setCreateTime(time);
		l4.setRebate(Double.parseDouble(lucky4[2]));
		list.add(l4);
		
		LuckyLotter l5 = new LuckyLotter();
		l5.setLotterType("五等奖");
		l5.setId(5);
		l5.setLotterMoney(lucky5[0] + "," + lucky5[1]);
		l5.setLotterPicture(path);
		l5.setCreateTime(time);
		l5.setRebate(Double.parseDouble(lucky5[2]));
		list.add(l5);
		
		LuckyLotter l6 = new LuckyLotter();
		l6.setLotterType("六等奖");
		l6.setId(6);
		l6.setLotterMoney(lucky6[0] + "," + lucky6[1]);
		l6.setLotterPicture(path);
		l6.setCreateTime(time);
		l6.setRebate(Double.parseDouble(lucky6[2]));
		list.add(l6);
		
		LuckyLotter l7 = new LuckyLotter();
		l7.setLotterType("幸运奖");
		l7.setId(7);
		l7.setLotterMoney(lucky7[0] + "," + lucky7[1]);
		l7.setLotterPicture(path);
		l7.setCreateTime(time);
		l7.setRebate(Double.parseDouble(lucky7[2]));
		list.add(l7);
		
		LuckyLotter l8 = new LuckyLotter();
		l8.setLotterType("祝你好运");
		l8.setId(8);
		l8.setLotterMoney(lucky8[0] + "," + lucky8[1]);
		l8.setLotterPicture(p2);
		l8.setCreateTime(time);
		l8.setRebate(Double.parseDouble(lucky8[2]));
		list.add(l8);
		
		int line = 0;
		for (int i = 0; i < list.size(); i++) {
			line += luckyRecordService.updateLotterData(list.get(i));
		}
		String remarks = "修改了幸运大转盘奖品配置信息!";
		operationlogService.addOperationlog((AdminUser)session.getAttribute("admin1"),remarks,"幸运抽奖管理");
		return new JsonResult("success", line);
	}
	
	/**
	 * 方法名：findUserLuckyRecord 
	 * 描述：     查询用户的抽奖记录                 
	 * 参数：    @return 
	 * @return: JsonResult
	 */
	@RequestMapping("/findUserLuckyRecord")
	@ResponseBody
	public JsonResult findUserLuckyRecord() {
		return new JsonResult("success",luckyRecordService.frequency());
	}
	
	/**
	 * 方法名：findByNameLuckyCount 
	 * 描述：   根据用户名查询用户摇奖次数                   
	 * 参数：    @param name 用户名称
	 * 参数：    @return 
	 * @return: JsonResult
	 */
	@RequestMapping("/findByNameLuckyCount")
	@ResponseBody
	public JsonResult findByNameLuckyCount(String name) {
		List<LuckyCount> counts = new ArrayList<>();
		counts.add(luckyRecordService.frequencyuser(name));
		return new JsonResult("success",counts);
	}
	
	/**
	 * 方法名：updateUserLuckyCount 
	 * 描述：     修改用户摇奖次数                 
	 * 参数：    @param name 用户名称
	 * 参数：    @param count 摇奖次数
	 * 参数：    @return 
	 * @return: JsonResult
	 */
	@RequestMapping("/updateUserLuckyCount")
	@ResponseBody
	public JsonResult updateUserLuckyCount(HttpSession session, String name,Integer count) {
		if(null == name  || "".equals(name)) {
			return new JsonResult("2",2);
		}
		String remarks = "修改了用户名为："+name+"的幸运大转盘摇奖次数为："+count+"次!";
		operationlogService.addOperationlog((AdminUser)session.getAttribute("admin1"),remarks,"幸运抽奖管理");
		return new JsonResult("success",luckyRecordService.updateyaojiang(name, count));
	}
	
	
	
}
