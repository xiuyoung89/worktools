package com.ja.sevice.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ja.dao.FalseMoneyMapper;
import com.ja.domain.FalseMoney;
import com.ja.domain.Order;
import com.ja.sevice.FalseMoneyService;
@Service
public class FalseMoneyServiceImpl implements FalseMoneyService {
	
	@Autowired
	private FalseMoneyMapper flaseMoneyMapper;

	/**添加假金额信息*/
	@Override
	public int addInfo(FalseMoney fm) {
		return flaseMoneyMapper.addInfo(fm);
	}

	/**查询金额*/
	@Override
	public double getMoneySum(Order o) {
		return flaseMoneyMapper.getMoneySum(o);
	}



}
