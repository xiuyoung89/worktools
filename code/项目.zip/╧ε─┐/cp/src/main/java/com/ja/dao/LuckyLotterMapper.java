package com.ja.dao;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.ja.domain.LuckyLotter;

public interface LuckyLotterMapper {
	
	/**查询所有的奖品属性*/
	List<LuckyLotter> getAllLuckyLotter();
	
	/**修改幸运大转盘的属性*/
	int updateLotterData(@Param("l")LuckyLotter lucky);

	/**根据id查询信息*/
	LuckyLotter getOneLuckyLotter(Integer id);
	
	
}
