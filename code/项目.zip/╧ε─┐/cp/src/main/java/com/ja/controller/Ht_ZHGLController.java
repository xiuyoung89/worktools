package com.ja.controller;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.ja.domain.Admin;
import com.ja.domain.AdminUser;
import com.ja.domain.Dama;
import com.ja.domain.Damal;
import com.ja.domain.Fanshui;
import com.ja.domain.Jine;
import com.ja.domain.Liushui;
import com.ja.domain.PagingData;
import com.ja.domain.User;
import com.ja.sevice.AgentService;
import com.ja.sevice.DamaService;
import com.ja.sevice.DamalService;
import com.ja.sevice.FanshuiService;
import com.ja.sevice.ISystemConfigService;
import com.ja.sevice.IUserService;
import com.ja.sevice.JineService;
import com.ja.sevice.LiushuiService;
import com.ja.sevice.OperationlogService;
import com.ja.util.DateUtil;
import com.ja.util.JsonResult;
import com.ja.util.WebSocketJson;

/**
 * 项目名称：cp   
 * 类名称：Ht_ZHGLController.java   
 * 类描述：   
 * 创建人：   GL
 * 创建时间：2019年2月22日 下午1:47:46   
 * @version v1.0.0
 */
@Controller
@RequestMapping("/zhgl")
public class Ht_ZHGLController {

	@Autowired
	private JineService jineService;

	@Autowired
	private LiushuiService liushuiService;

	@Autowired
	private IUserService userService;

	@Autowired
	private DamaService damaService;

	@Autowired
	private DamalService damalService;

	@Autowired
	private AgentService agentService;

	@Autowired
	private FanshuiService fanshuiService;

	@Autowired
	private ISystemConfigService systemConfigService;

	@Autowired
	private OperationlogService operationlogService;
	
	/**
	 * 
	 * ---- TODO：用户充值管理   
	 * 
	 */
	
	/**
	 * 方法名：userRechargePage 
	 * 描述：     用户充值管理页面                   
	 * 参数：    @return 
	 * @return: String
	 */
	@RequestMapping("/userRechargePage")
	public String userRechargePage() {
		return "htgl/khczjl";
	}
	
	/**
	 * 
	   *   方法名：findRechargeRecord   
	   *   描述：   查询用户的充值记录                        
	   *   参数：    @param paging 分页信息
	   *   参数：    @return 
	 * @return: String
	 */
	@ResponseBody
	@RequestMapping("/findRechargeRecord")
	public String findRechargeRecord(PagingData paging) {
		paging.setAllCount(jineService.getAllJlCounts());
		paging.setList(jineService.getAllJl(paging.getStartIndex(),paging.getLineCount(),1));
		return PagingData.pagingData(paging);
	}
	

	/**
	   *   方法名：likeFindRechageRecord   
	   *   描述：     根据条件查询用户的充值记录                        
	   *   参数：    @param paging 分页信息
	   *   参数：    @param jine 查询条件
	   *   参数：    @param daili 代理名称
	   *   参数：    @param date1 开始时间
	   *   参数：    @param date2 结束时间
	   *   参数：    @return 
	 * @return: String
	 */
	@ResponseBody
	@RequestMapping("/likeFindRechageRecord")
	public String likeFindRechageRecord(PagingData paging, Jine jine, String daili, String date1, String date2) {
		List<Jine> list = new ArrayList<Jine>();
		String data = "";
		if (daili.equals("")) {
			paging.setAllCount(jineService.getTypeJlCounts(jine, date1, date2));
			paging.setList(jineService.getTypeJl(paging.getStartIndex(), paging.getLineCount(), jine, date1, date2, 1));
			data = PagingData.pagingData(paging);// 用户
		} else { 
			User user = userService.checkUser(daili);// 代理
			if (user != null) {
				List<User> users = agentService.findAllNodes(user.getId());
				for (int i = 0; i < users.size(); i++) {
					List<Jine> jine2 = jineService.getOneCzJl(jine, date1, date2, users.get(i).getId());
					if (jine2 != null) {
						list.addAll(jine2);
					}
				}
				paging.setAllCount(list.size());
				paging.setList(list);
				data = PagingData.pagingData(paging);
			} else {
				data = "代理不存在";
				return "{data:" + data + "}";
			}
		}
		return data;
	}
	
	/**
	 *   方法名：rechargeAudit   
	 *   描述：  	(银行卡转账)充值审核                         
	 *   参数：    @param jine 金额信息
	 *   参数：    @param session
	 *   参数：    @return 
	 * @return: JsonResult
	 */
	@ResponseBody
	@RequestMapping("/rechargeAudit")
	public synchronized JsonResult rechargeAudit(Jine jine, HttpSession session) {
		synchronized (this) {
			if(jine == null) {
				return new JsonResult("请填写完整信息", "请填写完整信息!");
			}
			AdminUser admin = (AdminUser) session.getAttribute("admin1");
			JsonResult jsonResult = jineService.rechargeAudit(admin,jine);
			String state = "";
			if("充值成功".equals(jine.getState())) {
				state = "审核成功！";
				userService.vip(null,jine.getName());
			}else {
				state = "审核失败！";
			}
			String remarks = "对用户："+jine.getName()+jine.getType()+jine.getFukuanje()+"元"+state;
			operationlogService.addOperationlog(admin,remarks,"用户充值管理");
			return jsonResult;
		}
	}
	
	/**
	   *   方法名：rechageOrDrawingLocking   
	   *   描述：    用户充值和提款锁定订单处理状态                        
	   *   参数：    @param jine 锁定状态
	   *   参数：    @param session
	   *   参数：    @return 
	 * @return: JsonResult
	 */
	@ResponseBody
	@RequestMapping("/rechageOrDrawingLocking")
	public JsonResult rechageOrDrawingLocking(Jine jine, HttpSession session) {
		AdminUser admin1 = (AdminUser) session.getAttribute("admin1");
		jine.setCzname(admin1.getName());
		jine.setCltime(DateUtil.getCurrTime());
		int jines = jineService.updateTikuansd(jine);
		int count = jineService.getCount();//充值
		WebSocketJson w = new WebSocketJson(0,count);
		w.sendAllHt();
		int countTk = jineService.getCountTk();//提款
		WebSocketJson w1 = new WebSocketJson(1,countTk);
		w1.sendAllHt();
		return new JsonResult("success", jines);
	}
	
	/**
	   *   方法名：rechargeOrDrawingVoicoPrompt   
	   *   描述：      用户充值提款语音提示                     
	   *   参数：    @return 
	 * @return: JsonResult
	 */
	@ResponseBody
	@RequestMapping("/rechargeOrDrawingVoicoPrompt")
	public JsonResult rechargeOrDrawingVoicoPrompt() {
		List<Jine> data = jineService.getByStateAllYuyin();
		return new JsonResult("success", data);
	}
	

	/**
	 *
	 * ----TODO：用户提款管理
	 * 
	 */
	
	
	/**
	 * 方法名：userDrawingPage 
	 * 描述：    用户提款管理页面                    
	 * 参数：    @return 
	 * @return: String
	 */
	@RequestMapping("/userDrawingPage")
	public String userDrawingPage() {
		return "htgl/khtkjl";
	}
	
	/**
	   *   方法名：findUserDrawingRecord   
	   *   描述：    查询用户的提款记录                       
	   *   参数：    @param paging 分页信息
	   *   参数：    @return 
	 * @return: String
	 */
	@ResponseBody
	@RequestMapping("/findUserDrawingRecord")
	public String findUserDrawingRecord(PagingData paging) {
		paging.setAllCount(jineService.getTikuanJlCounts());
		paging.setList(jineService.getTikuanJl(paging.getStartIndex(),paging.getLineCount(),1));
		return PagingData.pagingData(paging);
	}

	/**
	   *   方法名：likeFindUserDrawingRecord   
	   *   描述：     根据条件查询用户以及代理的提款记录                      
	   *   参数：    @param paging 分页信息
	   *   参数：    @param jine 查询条件
	   *   参数：    @param daili 代理账号
	   *   参数：    @param date1 开始时间
	   *   参数：    @param date2 结束时间
	   *   参数：    @return 
	 * @return: String
	 */
	@ResponseBody
	@RequestMapping("/likeFindUserDrawingRecord")
	public String likeFindUserDrawingRecord(PagingData paging,Jine jine, String daili, String date1, String date2) {
        String data = "";
		List<Jine> list = new ArrayList<Jine>();
		if (daili.equals("")) {// 普通
			paging.setAllCount(jineService.getTikuanTypeJlCounts(jine, date1, date2));
			paging.setList(jineService.getTikuanTypeJl(paging.getStartIndex(),paging.getLineCount(),jine, date1, date2,1));
			data =  PagingData.pagingData(paging);
		} else {
			User user = userService.checkUser(daili);// 代理
			if (user != null) {
				List<User> users = agentService.findAllNodes(user.getId());
				for (int i = 0; i < users.size(); i++) {
					List<Jine> jine2 = jineService.getOneTkJl(jine, date1, date2, users.get(i).getId());
					if (jine2 != null) {
						list.addAll(jine2);
					}
				}
				paging.setAllCount(list.size());
				paging.setList(list);
				data = PagingData.pagingData(paging);
			} else {
				data = "代理不存在!";
				return "{data:" + data + "}";
			}
		}
		return data;
	}
	
	/**
	   *   方法名：drawingNeed   
	   *   描述：     用户提款所需打码                     
	   *   参数：    @param id 用户id
	   *   参数：    @return 
	 * @return: JsonResult
	 */
	@ResponseBody
	@RequestMapping("/drawingNeed")
	public JsonResult drawingNeed(Integer id) {
		Damal damal = damalService.getOnedamal(id);
		Admin admin = systemConfigService.findAllConfig();
		String count1 = "";
		String count2 = "";
		String Money1 = "";
		String Money2 = "";
		if (admin.getTikuanshifousuccess() != 1) {
			count1 = jineService.getTikuanCount(id) + ",";
			Money1 = jineService.getTikuanSum(id) + ",";
		} else {
			count1 = jineService.getTikuanCount1(id) + ",";
			Money1 = jineService.getTikuanSum1(id) + ",";
		}
		count2 = jineService.getChongzhiCount(id) + ",";
		Money2 = jineService.getChongzhiSum(id) + ",";
		String message = count1 + Money1 + count2 + Money2;
		return new JsonResult(message, damal);
	}


	/**
	 *   方法名：drawingAudit   
	 *   描述：     提款审核                      
	 *   参数：    @param jine 提款信息
	 *   参数：    @param states 提款状态
	 *   参数：    @param session 
	 *   参数：    @return 
	 * @return: JsonResult
	 */
	@ResponseBody
	@RequestMapping("/drawingAudit")
	public JsonResult drawingAudit(Jine jine, String states, HttpSession session) {
		synchronized (this) {
		if(jine == null) {
			return new JsonResult("请填写信息处理信息", "请填写信息处理信息");
		}
		AdminUser admin = (AdminUser) session.getAttribute("admin1");
		JsonResult jsonResult = jineService.drawingAudit(jine,states,admin);
		
		String state = "";
		if("提款成功".equals(jine.getState())) {
			state = "审核成功！";
		}else {
			state = "审核失败！";
		}
		String remarks = "对用户："+jine.getName()+"在线提款"+jine.getTikuanje()+"元,手续费"+jine.getTikuansxf()+"元"+state;
		operationlogService.addOperationlog(admin,remarks,"用户提款管理");
		return jsonResult;
		}
	}

	/**
	 * 
	 * ----TODO：用户金额管理 
	 * 
	 */
	
	/**
	 * 方法名：userBalancePage 
	 * 描述：     用户金额管理页面                   
	 * 参数：    @return 
	 * @return: String
	 */
	@RequestMapping("/userBalancePage")
	public String userBalancePage() {
		return "htgl/hyjiakuan";
	}
	
	/**
	   *   方法名：findAllUserInfo   
	   *   描述：    查询所有的会员的信息                       
	   *   参数：    @return 
	 * @return: JsonResult
	 */
	@ResponseBody
	@RequestMapping("/findAllUserInfo")
	public JsonResult findAllUserInfo() {
		return new JsonResult("success", userService.getAllUsers());
	}
	
	/**
	   *   方法名：findByNameUserInfo   
	   *   描述：     根据用户名查询用户的信息                      
	   *   参数：    @param name 用户名称
	   *   参数：    @return 
	 * @return: JsonResult
	 */
	@ResponseBody
	@RequestMapping("/findByNameUserInfo")
	public JsonResult findByNameUserInfo(String name) {
		List<User> users = new ArrayList<>();
		if( null!=userService.checkUser(name)) {
			users.add(userService.checkUser(name));
		}
		return new JsonResult("success",users);
	}

	/**
	 *   方法名：addUserBalance   
	 *   描述：     用户加款                      
	 *   参数：    @param jine 加款信息
	 *   参数：    @param session 
	 *   参数：    @return 
	 * @return: JsonResult
	 */
	@ResponseBody
	@RequestMapping("/addUserBalance")	
	public JsonResult addUserBalance(Jine jine, HttpSession session) {
		if(jine == null) {
			return new JsonResult("加款金额不能为空", "加款金额不能为空!");
		}
		AdminUser admin = (AdminUser) session.getAttribute("admin1");
		String remarks = "对用户："+jine.getName()+jine.getType()+jine.getFukuanje()+"元！";
		operationlogService.addOperationlog(admin,remarks,"用户金额管理");
		JsonResult jsonResult = jineService.quickPayment(jine,admin);
		userService.vip(null, jine.getName());//添加会员等级
		return jsonResult;
	}
	
	/**
	 * 
	 * ----TODO： 用户帐变管理 
	 * 
	 */
	
	
	/**
	 * 方法名：userWaterPage 
	 * 描述：     用户帐变管理页面                   
	 * 参数：    @return 
	 * @return: String
	 */
	@RequestMapping("/userWaterPage")
	public String userWaterPage() {
		return "htgl/hyzb";
	}
	
	/**
	   *   方法名：findUserWaterRecord   
	   *   描述：     查询用户都流水记录                      
	   *   参数：    @param paging 分页信息
	   *   参数：    @return 
	 * @return: String
	 */
	@ResponseBody
	@RequestMapping("/findUserWaterRecord")
	public String findUserWaterRecord(PagingData paging) {
		paging.setAllCount(liushuiService.getAllJlCounts());
		paging.setList(liushuiService.getAllJl(paging.getStartIndex(),paging.getLineCount(),1));
		return PagingData.pagingData(paging);
	}

	/**
	 * 
	   *   方法名：likeFindUserWaterRecord   
	   *   描述：     根据条件查询用户的流水记录                      
	   *   参数：    @param paging 分页信息
	   *   参数：    @param liushui 查询信息
	   *   参数：    @param daili 代理名称
	   *   参数：    @param date1 开始时间
	   *   参数：    @param date2 结束时间
	   *   参数：    @return 
	 * @return: String
	 */
	@ResponseBody
	@RequestMapping("/likeFindUserWaterRecord")
	public String likeFindUserWaterRecord(PagingData paging,Liushui liushui, String daili, String date1, String date2) {
		List<Liushui> list = new ArrayList<Liushui>();
		String data = "";
		if (daili.equals("")) {// 普通
			paging.setAllCount(liushuiService.getTypeJlCounts(liushui, date1, date2));
			paging.setList(liushuiService.getTypeJl(paging.getStartIndex(),paging.getLineCount(),liushui, date1, date2,1));
			data = PagingData.pagingData(paging);
		} else {
			User user = userService.checkUser(daili);	// 代理
			if (user != null) {
				List<User> users = agentService.findAllNodes(user.getId());
				for (int i = 0; i < users.size(); i++) {
					List<Liushui> l2 = liushuiService.getOneLsJl(liushui, date1, date2, users.get(i).getId());
					if (l2 != null) {
						list.addAll(l2);
					}
				}
				paging.setAllCount(list.size());
				paging.setList(list);
				data = PagingData.pagingData(paging);
			} else{
				data = "代理不存在！";
				return "{data:" + data + "}";
			}
		}
		return data;
	}

	/**
	 * 
	 * ----TODO：用户打码管理
	 * 
	 */
	
	/**
	 * 方法名：userCodePage 
	 * 描述：   用户打码管理页面                     
	 * 参数：    @return 
	 * @return: String
	 */
	@RequestMapping("/userCodePage")
	public String userCodePage() {
		return "htgl/hyjiajiandml";
	}

	/**
	 * 方法名：findAllUserCodeInfo 
	 * 描述：    查询用户的打码详情                    
	 * 参数：    @return 
	 * @return: JsonResult
	 */
	@ResponseBody
	@RequestMapping("/findAllUserCodeInfo")
	public JsonResult findAllUserCodeInfo() {
		return new JsonResult("success", damalService.getAlldamal());
	}

	/**
	 * 方法名：likeFindUserCodeInfo 
	 * 描述：     根据条件查询用户的打码详情                    
	 * 参数：    @param damal
	 * 参数：    @return 
	 * @return: JsonResult
	 */
	@ResponseBody
	@RequestMapping("/likeFindUserCodeInfo")
	public JsonResult likeFindUserCodeInfo(Damal damal) {
		return new JsonResult("success", damalService.mhOneDama(damal));
	}

	/**
	 * 方法名：updateUserCodeState 
	 * 描述：     启用或禁用用户的打码功能                   
	 * 参数：    @param id 用户id
	 * 参数：    @param state 开启状态   1启用 0禁用
	 * 参数：    @param session
	 * 参数：    @return 
	 * @return: JsonResult
	 */
	@ResponseBody
	@RequestMapping("/updateUserCodeState")
	public JsonResult updateUserCodeState(Integer id, Integer state, String name ,HttpSession session) {
		String message = "操作失败!";
		int a = damalService.upDamal(id, state);
		if (a == 1) {
			message = "操作成功!";
		}
		String type = "启用了";
		if(state==0) {
			type = "禁用了";
		}
		String remarks = type +"用户："+ name + "的打码功能！";
		operationlogService.addOperationlog((AdminUser)session.getAttribute("admin1"),remarks,"用户打码管理");
		return new JsonResult("success", message);
	}

	/**
	 *   方法名：updateCodeCount   
	 *   描述：     变动用户的打码量                      
	 *   参数：    @param dama 变动信息
	 *   参数：    @param session
	 *   参数：    @return 
	 * @return: JsonResult
	 */
	@ResponseBody
	@RequestMapping("/updateCodeCount")
	public JsonResult updateCodeCount(Dama dama, HttpSession session) {
		AdminUser admin = (AdminUser) session.getAttribute("admin1");
		JsonResult jsonResult = damalService.updateCodeCount(dama, admin);
		String remarks = "对用户：" + dama.getHuiyuanzh() +dama.getBdtype()+"打码量"+dama.getBdcount()+"元！";
		operationlogService.addOperationlog((AdminUser)session.getAttribute("admin1"),remarks,"用户打码管理");
		return jsonResult;
	}
	

	/**
	 * 
	 *  ----TODO：用户打码量记录
	 * 
	 */
	
	
	/**
	 * 方法名：codeCountRecord 
	 * 描述：    用户打码量记录页面                    
	 * 参数：    @return 
	 * @return: String
	 */
	@RequestMapping("/userCodeRecordPage")
	public String userCodeRecordPage() {
		return "htgl/dmlbdjl";
	}
	
	/**
	 * 方法名：findUserCodeRecord 
	 * 描述：     查询用户的打码记录                   
	 * 参数：    @param paging 分页信息
	 * 参数：    @return  
	 * @return: String
	 */  
	@ResponseBody
	@RequestMapping("/findUserCodeRecord")
	public String findUserCodeRecord(PagingData paging) {
		paging.setAllCount(damaService.getAllDama(paging.getStartIndex(),paging.getLineCount(),0).size());
		paging.setList(damaService.getAllDama(paging.getStartIndex(),paging.getLineCount(),1));
		return PagingData.pagingData(paging);
	}

	/**
	 * 方法名：likeFindUserCodeRecord 
	 * 描述：    根据条件查询用户的打码记录                     
	 * 参数：    @param paging 分页信息
	 * 参数：    @param dama 查询条件
	 * 参数：    @param date1 开始时间
	 * 参数：    @param date2 结束时间
	 * 参数：    @return 
	 * @return: String
	 */
	@ResponseBody
	@RequestMapping("/likeFindUserCodeRecord")
	public String likeFindUserCodeRecord(PagingData paging,Dama dama, String date1, String date2) {
		paging.setAllCount(damaService.getMhdama(paging.getStartIndex(),paging.getLineCount(),dama, date1, date2,0).size());
		paging.setList(damaService.getMhdama(paging.getStartIndex(),paging.getLineCount(),dama, date1, date2,1));
		return PagingData.pagingData(paging);
	}
 
	/**
	 * 
	 *  ----TODO：日常反水管理
	 * 
	 */

	/**
	 * 方法名：backWaterSetupPage 
	 * 描述：     日常反水管理页面                   
	 * 参数：    @return 
	 * @return: String
	 */
	@RequestMapping("/backWaterSetupPage")
	public String backWaterSetupPage() {
		return "htgl/fanshuilvshezhi";
	}
	
	/**
	 * 方法名：findUserBackWaterRecord 
	 * 描述：   查询用户的返水记录                     
	 * 参数：    @return 
	 * @return: JsonResult
	 */
	@ResponseBody
	@RequestMapping("/findUserBackWaterRecord")
	public JsonResult findUserBackWaterRecord() {
		return new JsonResult("success", liushuiService.getFanshuiJl());
	}

	/**
	 * 方法名：likeFindUserBackWaterRecord 
	 * 描述：     根据条件查询用户的返水记录                   
	 * 参数：    @param paging 分页信息
	 * 参数：    @param water 查询条件
	 * 参数：    @param date1 开始时间
	 * 参数：    @param date2 结束时间
	 * 参数：    @return 
	 * @return: String
	 */
	@ResponseBody
	@RequestMapping("/likeFindUserBackWaterRecord")
	public String likeFindUserBackWaterRecord(PagingData paging,Liushui water, String date1, String date2) {
		paging.setAllCount(liushuiService.getTypeJl(paging.getStartIndex(),paging.getLineCount(),water, date1, date2,0).size());
		paging.setList(liushuiService.getTypeJl(paging.getStartIndex(),paging.getLineCount(),water, date1, date2,1));
		return PagingData.pagingData(paging);
	}

	/**
	 * 方法名：findAllBackWaterSetup 
	 * 描述：    查询日常返水设置                    
	 * 参数：    @return 
	 * @return: JsonResult
	 */
	@ResponseBody
	@RequestMapping("/findAllBackWaterSetup")
	public JsonResult findAllBackWaterSetup() {
		return new JsonResult("success", fanshuiService.getAllfanshui());
	}

	/**
	 * 方法名：insertBackwaterSetup 
	 * 描述：     添加返水设置                   
	 * 参数：    @param rebate 返水设置
	 * 参数：    @param session
	 * 参数：    @return 
	 * @return: JsonResult
	 */
	@ResponseBody
	@RequestMapping("/insertBackwaterSetup")
	public JsonResult insertBackwaterSetup(Fanshui setup, HttpSession session) {
		String type = "每日返水";
		if(Integer.parseInt(setup.getType())==2) {
			type = "每月返水";
		}
		String remarks = "添加了" + type + "设置,打码量所需：" + setup.getDamal() + ",充值所需：" + setup.getJine() + ",反水比率：" + setup.getFdianlv()+"！";
		operationlogService.addOperationlog((AdminUser)session.getAttribute("admin1"),remarks,"日常返水管理");
		String message = "添加失败,请联系系统管理员!";
		int line =  fanshuiService.insertBackwater(setup);
		if(line==1) {
			message = "添加成功!";
		}
		return new JsonResult("success", message);
	}

	/**
	 * 方法名：updateBackWaterSetup 
	 * 描述：     修改反水设置                   
	 * 参数：    @param rebate 返水设置
	 * 参数：    @param session
	 * 参数：    @return 
	 * @return: JsonResult
	 */
	@ResponseBody
	@RequestMapping("/updateBackWaterSetup")
	public JsonResult updateBackWaterSetup(Fanshui setup, HttpSession session) {
		String type = "每日返水";
		if(Integer.parseInt(setup.getType())==2) {
			type = "每月返水";
		}
		String message = "修改失败,请联系系统管理员!";
		int line =  fanshuiService.upfanshui(setup);
		if(line==1) {
			message = "修改成功!";
		}
		String remarks = "修改" + type + "设置,打码量所需：" + setup.getDamal() + ",充值所需：" + setup.getJine() + ",反水比率："+ setup.getFdianlv()+"!";
		operationlogService.addOperationlog((AdminUser)session.getAttribute("admin1"),remarks,"日常返水管理");
		return new JsonResult("success", message);
		
	}

	/**
	 * 方法名：enableBackWaterSetup 
	 * 描述：     开启或禁用反水设置                   
	 * 参数：    @param fanshui 返水设置
	 * 参数：    @param session
	 * 参数：    @return 
	 * @return: JsonResult
	 */
	@ResponseBody
	@RequestMapping("/enableBackWaterSetup")
	public JsonResult enableBackWaterSetup(Fanshui setup, HttpSession session) {
		String state = "禁用了一条";
		if(setup.getState()==1) {
			state = "启用了一条";
		}
		String message = "操作失败,请联系系统管理员!";
		Fanshui water = fanshuiService.findByIdBackWaterSetup(setup.getId());
		int line =  fanshuiService.kaiqifs(setup.getId(), setup.getState());
		if(line==1) {
			message = "操作成功!";
		}
		String remarks = state + water.getName()+"设置!";
		operationlogService.addOperationlog((AdminUser)session.getAttribute("admin1"),remarks,"日常返水管理");
		return new JsonResult("success", message);
	}
	
	/**
	 * 方法名：deleteBackwaterSetup 
	 * 描述：    删除返水设置                   
	 * 参数：    @param rebate 返水设置
	 * 参数：    @param session
	 * 参数：    @return 
	 * @return: JsonResult
	 */
	@ResponseBody
	@RequestMapping("/deleteBackwaterSetup")
	public JsonResult deleteBackwaterSetup(Fanshui rebate, HttpSession session) {
		String message = "删除失败,请联系系统管理员!";
		Fanshui water = fanshuiService.findByIdBackWaterSetup(rebate.getId());
		String remarks = "删除了一条" + water.getName() +"设置！";
		int line =  fanshuiService.deleteBackwater(rebate.getId());
		if(line==1) {
			message = "删除成功!";
		}
		operationlogService.addOperationlog((AdminUser)session.getAttribute("admin1"),remarks,"日常返水管理");
		return new JsonResult("success", message);
	}
	

}
