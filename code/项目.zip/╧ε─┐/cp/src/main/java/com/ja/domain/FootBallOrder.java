package com.ja.domain;

public class FootBallOrder extends FootBallMatch{
	
    /**
	 * 
	 */
	private static final long serialVersionUID = -8321487950409233914L;

	private Integer id; //足彩订单表  111

    private String name; //用户名

    private String ctime; //下注时间

    private String order_num; //订单号

    private String league; //赛事目录名称

    private String type; //下注玩法 1111
 
    private String types; //下注类型 1111

    private String team_h; //主队名称

    private String team_c; //客队名称

    private String attributes; //投注的属性 111
 
    private String des_in; //投注盘口信息  111

    private String rebate; //投注赔率 111

    private Integer state; //订单状态

    private Double acount; //投注金额

    private Double lotter_money; //中奖金额
    
    private Double return_money; //中奖金额

    private String fh_score_h; //半场 主队 进球比分

    private String fh_score_c; //半场  客队 进球比分

    private String score_h; //全场 主队 进球比分

    private String score_c; //全场 客队 进球比分

    private String ltime; //开奖时间

    private Integer user_id; //用户id
    
    private String mid; //赛事id
    
    private Integer sort; //排序
    
    public static long getSerialversionuid() {
		return serialVersionUID;
	}
    
    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name == null ? null : name.trim();
    }

    public String getCtime() {
        return ctime;
    }

    public void setCtime(String ctime) {
        this.ctime = ctime == null ? null : ctime.trim();
    }

	public String getOrder_num() {
		return order_num;
	}

	public void setOrder_num(String order_num) {
		this.order_num = order_num;
	}

	public String getLeague() {
		return league;
	}

	public void setLeague(String league) {
		this.league = league;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getTypes() {
		return types;
	}

	public void setTypes(String types) {
		this.types = types;
	}

	public String getTeam_h() {
		return team_h;
	}

	public void setTeam_h(String team_h) {
		this.team_h = team_h;
	}

	public String getTeam_c() {
		return team_c;
	}

	public void setTeam_c(String team_c) {
		this.team_c = team_c;
	}

	public String getAttributes() {
		return attributes;
	}

	public void setAttributes(String attributes) {
		this.attributes = attributes;
	}

	public String getDes_in() {
		return des_in;
	}

	public void setDes_in(String des_in) {
		this.des_in = des_in;
	}

	public String getRebate() {
		return rebate;
	}

	public void setRebate(String rebate) {
		this.rebate = rebate;
	}

	public Integer getState() {
		return state;
	}

	public void setState(Integer state) {
		this.state = state;
	}

	public Double getAcount() {
		return acount;
	}

	public void setAcount(Double acount) {
		this.acount = acount;
	}

	public Double getLotter_money() {
		return lotter_money;
	}

	public void setLotter_money(Double lotter_money) {
		this.lotter_money = lotter_money;
	}

	public Double getReturn_money() {
		return return_money;
	}

	public void setReturn_money(Double return_money) {
		this.return_money = return_money;
	}

	public String getFh_score_h() {
		return fh_score_h;
	}

	public void setFh_score_h(String fh_score_h) {
		this.fh_score_h = fh_score_h;
	}

	public String getFh_score_c() {
		return fh_score_c;
	}

	public void setFh_score_c(String fh_score_c) {
		this.fh_score_c = fh_score_c;
	}

	public String getScore_h() {
		return score_h;
	}

	public void setScore_h(String score_h) {
		this.score_h = score_h;
	}

	public String getScore_c() {
		return score_c;
	}

	public void setScore_c(String score_c) {
		this.score_c = score_c;
	}

	public String getLtime() {
		return ltime;
	}

	public void setLtime(String ltime) {
		this.ltime = ltime;
	}

	public Integer getUser_id() {
		return user_id;
	}

	public void setUser_id(Integer user_id) {
		this.user_id = user_id;
	}

	public String getMid() {
		return mid;
	}

	public void setMid(String mid) {
		this.mid = mid;
	}

	public Integer getSort() {
		return sort;
	}

	public void setSort(Integer sort) {
		this.sort = sort;
	}

	public FootBallOrder() {
		super();
	}

	@Override
	public String toString() {
		return "FootBallOrder [id=" + id + ", name=" + name + ", ctime=" + ctime + ", order_num=" + order_num
				+ ", league=" + league + ", type=" + type + ", types=" + types + ", team_h=" + team_h + ", team_c="
				+ team_c + ", attributes=" + attributes + ", des_in=" + des_in + ", rebate=" + rebate + ", state="
				+ state + ", acount=" + acount + ", lotter_money=" + lotter_money + ", return_money=" + return_money
				+ ", fh_score_h=" + fh_score_h + ", fh_score_c=" + fh_score_c + ", score_h=" + score_h + ", score_c="
				+ score_c + ", ltime=" + ltime + ", user_id=" + user_id + ", mid=" + mid + ", sort=" + sort + "]";
	}
   
}