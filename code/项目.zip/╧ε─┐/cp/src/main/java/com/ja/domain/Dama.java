package com.ja.domain;

import java.io.Serializable;

public class Dama implements Serializable{
    /**
	 * 
	 */
	private static final long serialVersionUID = 2220056306730985096L;

	private Integer id;//会员打码记录

    private String huiyuanzh;//会员帐号

    private String bdtype;//变动类型

    private Double bdqcount;//变动前打码量

    private Double bdcount;//变动打码量

    private Double bdhcount;//变动后打码量

    private String createtime;//创建时间

    private Double bdqtksx;//变动前提款所需

    private Double bdtksx;//变动提款所需

    private Double bdhtksx;//变动后提款所需

    private String czname;//操作员

    private String beizhu;//备注

    private Integer userid;//用户id

	public static long getSerialversionuid() {
		return serialVersionUID;
	}
    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getHuiyuanzh() {
        return huiyuanzh;
    }

    public void setHuiyuanzh(String huiyuanzh) {
        this.huiyuanzh = huiyuanzh == null ? null : huiyuanzh.trim();
    }

    public String getBdtype() {
        return bdtype;
    }

    public void setBdtype(String bdtype) {
        this.bdtype = bdtype == null ? null : bdtype.trim();
    }


    public Double getBdqcount() {
		return bdqcount;
	}

	public void setBdqcount(Double bdqcount) {
		this.bdqcount = bdqcount;
	}

	public Double getBdcount() {
		return bdcount;
	}

	public void setBdcount(Double bdcount) {
		this.bdcount = bdcount;
	}

	public Double getBdhcount() {
		return bdhcount;
	}

	public void setBdhcount(Double bdhcount) {
		this.bdhcount = bdhcount;
	}

	public String getCreatetime() {
        return createtime;
    }

    public void setCreatetime(String createtime) {
        this.createtime = createtime == null ? null : createtime.trim();
    }

    public Double getBdqtksx() {
        return bdqtksx;
    }

    public void setBdqtksx(Double bdqtksx) {
        this.bdqtksx = bdqtksx;
    }

    public Double getBdtksx() {
        return bdtksx;
    }

    public void setBdtksx(Double bdtksx) {
        this.bdtksx = bdtksx;
    }

    public Double getBdhtksx() {
        return bdhtksx;
    }

    public void setBdhtksx(Double bdhtksx) {
        this.bdhtksx = bdhtksx;
    }

    public String getCzname() {
        return czname;
    }

    public void setCzname(String czname) {
        this.czname = czname == null ? null : czname.trim();
    }

    public String getBeizhu() {
        return beizhu;
    }

    public void setBeizhu(String beizhu) {
        this.beizhu = beizhu == null ? null : beizhu.trim();
    }

    public Integer getUserid() {
        return userid;
    }

    public void setUserid(Integer userid) {
        this.userid = userid;
    }

	@Override
	public String toString() {
		return "Dama [id=" + id + ", huiyuanzh=" + huiyuanzh + ", bdtype=" + bdtype + ", bdqcount=" + bdqcount
				+ ", bdcount=" + bdcount + ", bdhcount=" + bdhcount + ", createtime=" + createtime + ", bdqtksx="
				+ bdqtksx + ", bdtksx=" + bdtksx + ", bdhtksx=" + bdhtksx + ", czname=" + czname + ", beizhu=" + beizhu
			    + ", userid=" + userid + "]";
	}

	public Dama() {
		super();
	}
}