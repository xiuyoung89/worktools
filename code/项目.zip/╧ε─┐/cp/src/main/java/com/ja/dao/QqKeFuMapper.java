package com.ja.dao;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.ja.domain.QqKeFu;

public interface QqKeFuMapper {

	/**查询所有的qq客服*/
	List<QqKeFu> getAllQqKeFu();

	/** 添加入QQ客服 */
	int addQqKeFuInfo(@Param("qq")QqKeFu qq);

	/** 修改入款银行卡 */
	int updateQqKeFuInfo(@Param("qq")QqKeFu qq);

	/** 删除入款银行卡 */
	int delQqKeFuInfo(Integer id);

}