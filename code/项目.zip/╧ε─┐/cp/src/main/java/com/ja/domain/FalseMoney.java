package com.ja.domain;

import java.io.Serializable;

public class FalseMoney implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 3158488852068119208L;

	private Integer id;//假金额表
	
	private String cname;//彩种名称
	
	private String period;//彩种期号
	
	private Double money;//假金额
	
	private String createTime;//假金额
	
	private Integer state;//状态

	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getCname() {
		return cname;
	}

	public void setCname(String cname) {
		this.cname = cname;
	}

	public String getPeriod() {
		return period;
	}

	public void setPeriod(String period) {
		this.period = period;
	}

	public Double getMoney() {
		return money;
	}

	public void setMoney(Double money) {
		this.money = money;
	}

	public String getCreateTime() {
		return createTime;
	}

	public void setCreateTime(String createTime) {
		this.createTime = createTime;
	}

	public Integer getState() {
		return state;
	}

	public void setState(Integer state) {
		this.state = state;
	}

	public FalseMoney() {
		super();
	}

	@Override
	public String toString() {
		return "FalseMoney [id=" + id + ", cname=" + cname + ", period=" + period + ", money=" + money + ", createTime="
				+ createTime + ", state=" + state + "]";
	}
}
