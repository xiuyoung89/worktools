package com.ja.check.data;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.jsoup.Jsoup;
import org.jsoup.helper.StringUtil;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;
import org.springframework.web.context.ContextLoader;

import com.ja.domain.FootBallMatch;
import com.ja.domain.FootballMatchResult;
import com.ja.sevice.FootBallMatchService;

/**
 * @DESC: 获取足球赛事盘口数据的工具类
 * @AUTH: qhzh 
 * @DATE: 2018年6月25日 下午4:35:05
 */
public class FootballData {

	private FootBallMatchService fMatchService = (FootBallMatchService) ContextLoader.getCurrentWebApplicationContext().getBean("fMatchService");

	/** 时间玩法: 今日  */
	public static final String TYPES_TODAY = "今日";
	
	/** 时间玩法: 早盘  */
	public static final String TYPES_FUTURE = "早盘";
	
	/** 时间玩法: 滚球  */
	public static final String TYPES_GQ = "滚球";
	
	/** 玩法: 单式  */
	public static final String PLAY_TYPE_DS = "单式";
	
	/** 玩法: 波胆 */
	public static final String PLAY_TYPE_BD = "波胆";
	
	/** 玩法: 入球数 */
	public static final String PLAY_TYPE_RQS = "入球数";
	
	/** 玩法: 滚球  */
	public static final String PLAY_TYPE_GQ = "滚球";
	
	/** 玩法: 半全场 */
	public static final String PLAY_TYPE_BQC = "半全场";
	
	/** 玩法: 综合过关 */
	public static final String PLAY_TYPE_ZHGG = "综合过关";
	
	
	/** 远程请求的Base URL */
	public static final String URL_BASE = "https://www.669bet365.com";

	/** 滚球盘口数据的URL */
	public static final String URL_GQ = URL_BASE + "/hg_sports/index/ft/gq";
	
	/** 今日单式盘口数据的URL */
	public static final String URL_TODAY_DS = URL_BASE + "/hg_sports/index/ft/ds";
	
	/** 早盘单式数据的URL */
	public static final String URL_FUTURE_DS = URL_BASE + "/hg_sports/index/fu/ds";
	
	/** 今日波胆盘口数据的URL */
	public static final String URL_TODAY_BD = URL_BASE + "/hg_sports/index/ft/bd";
	
	/** 早盘波胆盘口数据的URL */
	public static final String URL_FUTURE_BD = URL_BASE + "/hg_sports/index/fu/bd";
	
	/** 今日入球数盘口数据的URL */
	public static final String URL_TODAY_RQS = URL_BASE + "/hg_sports/index/ft/zrq";
	
	/** 早盘入球数盘口数据的URL */
	public static final String URL_FUTURE_RQS = URL_BASE + "/hg_sports/index/fu/zrq";
	
	/** 今日半全场盘口数据的URL */
	public static final String URL_TODAY_BQC = URL_BASE + "/hg_sports/index/ft/bqs";
	
	/** 早盘半全场盘口数据的URL */
	public static final String URL_FUTURE_BQC = URL_BASE + "/hg_sports/index/fu/bqs";
	
	/** 今日综合过关盘口数据的URL */
	public static final String URL_TODAY_ZHGG = URL_BASE + "/hg_sports/index/ft/zhgg";
	
	/** 早盘综合过关盘口数据的URL */
	public static final String URL_FUTURE_ZHGG = URL_BASE + "/hg_sports/index/fu/zhgg";
	
	/** 前一天赛果数据的URL */
	public static final String URL_PREDAY_SG = URL_BASE + "/hg_sports/index/sg/ft";
	
	/**
	 * 根据玩法url、玩法时间类型、玩法类型爬取盘口数据
	 * @param url
	 * @param types 早盘/今日/滚球
	 * @param playType
	 */
	public List<FootBallMatch> crawlPanKou(String url,String types,String playType) {
		List<FootBallMatch> entities = new ArrayList<>();
		Elements pageBar = null;
		switch (playType) {
		case PLAY_TYPE_DS:
			pageBar = crawlDSOfSinglePage(url,types,playType,entities,true);
			break;
		case PLAY_TYPE_BD:
			pageBar = crawlBDOfSinglePage(url,types,playType,entities,true);
			break;
		case PLAY_TYPE_RQS:
			pageBar = crawlRQSOfSinglePage(url,types,playType,entities,true);
			break;
		case PLAY_TYPE_BQC:
			pageBar = crawlBQCOfSinglePage(url,types,playType,entities,true);
			break;
		case PLAY_TYPE_GQ:
			pageBar = crawlGQOfSinglePage(url,types,playType,entities,true);
			break;
		case PLAY_TYPE_ZHGG:
			pageBar = crawlZHGGOfSinglePage(url,types,playType,entities,true);
		}
		if(pageBar != null && !pageBar.isEmpty()) {
			Elements tagsA = pageBar.first().getElementsByTag("a");
			for (int i=0;i<tagsA.size()-1;i++) {
				switch (playType) {
				case PLAY_TYPE_DS:
					crawlDSOfSinglePage(URL_BASE+tagsA.get(i).attr("href"),types,playType,entities,false);
					break;
				case PLAY_TYPE_BD:
					crawlBDOfSinglePage(URL_BASE+tagsA.get(i).attr("href"),types,playType,entities,false);
					break;
				case PLAY_TYPE_RQS:
					crawlRQSOfSinglePage(URL_BASE+tagsA.get(i).attr("href"),types,playType,entities,false);
					break;
				case PLAY_TYPE_BQC:
					crawlBQCOfSinglePage(URL_BASE+tagsA.get(i).attr("href"),types,playType,entities,false);
					break;
				case PLAY_TYPE_GQ:
					crawlGQOfSinglePage(URL_BASE+tagsA.get(i).attr("href"),types,playType,entities,false);
					break;
				case PLAY_TYPE_ZHGG:
					crawlZHGGOfSinglePage(URL_BASE+tagsA.get(i).attr("href"),types,playType,entities,false);
				}
			}
		}
		return entities;
	}
	
	/**
	 * 爬赛果数据
	 * @param url
	 */
	public List<FootballMatchResult> crawlSaiGuo(String url) {
		List<FootballMatchResult> results = new ArrayList<>();
		Elements trs = connectForTrsAndPageBar(url,false)[0];
		if(trs==null ||trs.isEmpty() || trs.size() == 1) {
			return results;
		}
		//从第二个tr标签开始遍历：如果是赛事名称class="b_title"-缓存起来，然后对接下来的数据进行封装
		//缓存赛事名称
		String league = "";
		for (int i=1 ; i < trs.size() ; i++) {
			Element tr = trs.get(i);
			Elements leagues = tr.getElementsByClass("b_title");
			//如果是赛事名称-缓存并进入下一行数据
			if(!leagues.isEmpty()) {
				league = leagues.first().text();
				tr = trs.get(++i);
			}	
			FootballMatchResult matchResult = new FootballMatchResult();
			matchResult.setLeague(league);
			matchResult.setCtime(getCurrTime());
			
			//解析每场比赛的盘口数据
			//解析第一行
			Elements tds = tr.getElementsByTag("td");
			int j = -1;
			if(!tds.get(++j).text().isEmpty()) {
				matchResult.setStart_time(tds.get(j).text());
			}
			j++;
			if(!tds.get(++j).text().isEmpty()) {
				matchResult.setTeam_h(tds.get(j).text().replaceAll(" ", ""));
			}
			if(!tds.get(++j).text().isEmpty()) {
				matchResult.setTeam_c(tds.get(j).text().replaceAll(" ", ""));
			}
			//解析第二行
			tr = trs.get(++i);
			tds = tr.getElementsByTag("td");
			j = 0;
			if(!tds.get(++j).text().isEmpty()) {
				matchResult.setFh_score_h(tds.get(j).text());
			}
			if(!tds.get(++j).text().isEmpty()) {
				matchResult.setFh_score_c(tds.get(j).text());
			}
			//解析第三行
			tr = trs.get(++i);
			tds = tr.getElementsByTag("td");
			j = 0;
			if(!tds.get(++j).text().isEmpty()) {
				matchResult.setScore_h(tds.get(j).text());
			}
			if(!tds.get(++j).text().isEmpty()) {
				matchResult.setScore_c(tds.get(j).text());
			}
			if(!FootBallMatch.DEFAULT_INIT_VALUE.equals(matchResult.getScore_h()) &&
					!FootBallMatch.DEFAULT_INIT_VALUE.equals(matchResult.getScore_c()) &&
					!FootBallMatch.DEFAULT_INIT_VALUE.equals(matchResult.getFh_score_h()) &&
					!FootBallMatch.DEFAULT_INIT_VALUE.equals(matchResult.getFh_score_c())) {				
				results.add(matchResult);
			}
			//System.out.println(matchResult);
		}
		return results;
	}
	
	/**
	 * 爬取滚球的每一页盘口数据
	 * @param url
	 * @param types 早盘/今日/滚球
	 * @param playType
	 * 
	 */
	private Elements crawlGQOfSinglePage(String url,String types,String playType,List<FootBallMatch> entities,boolean isDefaultPage) {
		Elements[] trsAndPageBar = connectForTrsAndPageBar(url,isDefaultPage);
		Elements trs = trsAndPageBar[0];
		if(trs==null || trs.isEmpty() || trs.size() == 1) {
			return null;
		}
		//从第二个tr标签开始遍历：如果是赛事名称class="b_title"-缓存起来，然后对接下来的数据进行封装
		//缓存赛事名称
		String league = "";
		for (int i=1 ; i < trs.size() ; i++) {
			Element tr = trs.get(i);
			Elements leagues = tr.getElementsByClass("b_title");
			//如果是赛事名称-缓存并进入下一行数据
			if(!leagues.isEmpty()) {
				league = leagues.first().text();
				tr = trs.get(++i);
			}	
			FootBallMatch entity = initFootBallMatch(playType,types,league,null);
			entity.setRoll("1");
			//解析每场比赛的三行盘口数据
			//第一行
			parseFirstRow(tr,entity,types);
			//第二行
			tr = trs.get(++i);
			parseSecondRow(tr,entity);
			//第三行
			tr = trs.get(++i);
			parseThirdRow(tr,entity);
			entities.add(entity);
			//跳过第四行的空行
			i++;
			//System.out.println(entity);
		}
		return trsAndPageBar[1];
	}
	
	/**
	 * 爬取综合过关的每一页盘口数据
	 * @param url
	 * @param types 早盘/今日/滚球
	 * @param playType
	 */
	private Elements crawlZHGGOfSinglePage(String url,String types,String playType,List<FootBallMatch> entities,boolean isDefaultPage) {
		Elements[] trsAndPageBar = connectForTrsAndPageBar(url,isDefaultPage);
		Elements trs = trsAndPageBar[0];
		if(trs==null || trs.isEmpty() || trs.size() == 1) {
			return null;
		}
		//从第二个tr标签开始遍历：如果是赛事名称class="b_title"-缓存起来，然后对接下来的数据进行封装
		//缓存赛事名称
		String league = "no";
		String sgNum = "no";
		for (int i=1 ; i < trs.size() ; i++) {
			Element tr = trs.get(i);
			Elements leagues = tr.getElementsByClass("b_title");
			//如果是赛事名称-缓存并进入下一行数据
			if(!leagues.isEmpty()) {
				league = leagues.first().text();
				sgNum = tr.getElementsByClass("b_title2").first().text();
				tr = trs.get(++i);
			}	
			FootBallMatch entity = initFootBallMatch(playType,types,league,sgNum);
			
			//解析每场比赛的三行盘口数据
			//第一行
			parseFirstRow(tr,entity,types);
			//第二行
			tr = trs.get(++i);
			parseSecondRow(tr,entity);
			//第三行
			tr = trs.get(++i);
			parseThirdRow(tr,entity);
			entities.add(entity);
			i++;
			//System.out.println(entity);
		}
		return trsAndPageBar[1];
	}
	
	/**
	 * 爬取半全场的每一页盘口数据
	 * @param url
	 * @param types 早盘/今日/滚球
	 * @param playType
	 */
	private Elements crawlBQCOfSinglePage(String url,String types,String playType,List<FootBallMatch> entities,boolean isDefaultPage) {
		Elements[] trsAndPageBar = connectForTrsAndPageBar(url,isDefaultPage);
		Elements trs = trsAndPageBar[0];
		if(trs==null || trs.isEmpty() || trs.size() == 1) {
			return null;
		}
		//从第二个tr标签开始遍历：如果是赛事名称class="b_title"-缓存起来，然后对接下来的数据进行封装
		//缓存赛事名称
		String league = "";
		for (int i=1 ; i < trs.size() ; i++) {
			Element tr = trs.get(i);
			Elements leagues = tr.getElementsByClass("b_title");
			//如果是赛事名称-缓存并进入下一行数据
			if(!leagues.isEmpty()) {
				league = leagues.first().text();
				tr = trs.get(++i);
			}	
			FootBallMatch entity = initFootBallMatch(playType,types,league,null);
			
			//解析每场比赛的盘口数据
			int j = 0;
			Elements tds1 = tr.getElementsByTag("td");
			parseTdTagForStartTime(tds1.get(j).text(),entity,types);
			parseTeamTdTagForTeams(tds1.get(++j).text().replaceAll("\\s+", " ").split(" "),entity);
			//主/主 主/和 主/客 和/主 和/和 和/客 客/主 客/和 客/客 
			if(!tds1.get(++j).text().isEmpty()) {
				entity.setHh(tds1.get(j).text());
			}
			if(!tds1.get(++j).text().isEmpty()) {
				entity.setHd(tds1.get(j).text());
			}
			if(!tds1.get(++j).text().isEmpty()) {
				entity.setHc(tds1.get(j).text());
			}
			if(!tds1.get(++j).text().isEmpty()) {
				entity.setDh(tds1.get(j).text());
			}
			if(!tds1.get(++j).text().isEmpty()) {
				entity.setDd(tds1.get(j).text());
			}
			if(!tds1.get(++j).text().isEmpty()) {
				entity.setDc(tds1.get(j).text());
			}
			if(!tds1.get(++j).text().isEmpty()) {
				entity.setCh(tds1.get(j).text());
			}
			if(!tds1.get(++j).text().isEmpty()) {
				entity.setCd(tds1.get(j).text());
			}
			if(!tds1.get(++j).text().isEmpty()) {
				entity.setCc(tds1.get(j).text());
			}
			entities.add(entity);
			//System.out.println(entity);
		}
		return trsAndPageBar[1];
	}
	
	/**
	 * 爬取波胆的每一页盘口数据
	 * @param url
	 * @param types 早盘/今日/滚球
	 * @param playType
	 */
	private Elements crawlBDOfSinglePage(String url,String types,String playType,List<FootBallMatch> entities,boolean isDefaultPage) {
		Elements[] trsAndPageBar = connectForTrsAndPageBar(url,isDefaultPage);
		Elements trs = trsAndPageBar[0];
		if(trs==null || trs.isEmpty() || trs.size() == 1) {
			return null;
		}
		//从第二个tr标签开始遍历：如果是赛事名称class="b_title"-缓存起来，然后对接下来的数据进行封装
		//缓存赛事名称
		String league = "";
		for (int i=1 ; i < trs.size() ; i++) {
			Element tr = trs.get(i);
			Elements leagues = tr.getElementsByClass("b_title");
			//如果是赛事名称-缓存并进入下一行数据
			if(!leagues.isEmpty()) {
				league = leagues.first().text();
				tr = trs.get(++i);
			}	
			FootBallMatch entity = initFootBallMatch(playType,types,league,null);
			
			//解析每场比赛的盘口数据
			int j = 0;
			Elements tds1 = tr.getElementsByTag("td");
			parseTdTagForStartTime(tds1.get(j).text(),entity,types);
			parseTeamTdTagForTeams(tds1.get(++j).text().replaceAll("\\s+", " ").split(" "),entity);
			//盘口的第一个tr标签：1:0 2:0 2:1 3:0 3:1 3:2 4:0 4:1 4:2 4:3 0:0 1:1 2:2 3:3 4:4 其它 
			if(!tds1.get(++j).text().isEmpty()) {
				entity.setBf10_h(tds1.get(j).text());
			}else {
				entity.setBf10_h("0");
			}
			if(!tds1.get(++j).text().isEmpty()) {
				entity.setBf20_h(tds1.get(j).text());
			}else {
				entity.setBf20_h("0");
			}
			if(!tds1.get(++j).text().isEmpty()) {
				entity.setBf21_h(tds1.get(j).text());
			}else {
				entity.setBf21_h("0");
			}
			if(!tds1.get(++j).text().isEmpty()) {
				entity.setBf30_h(tds1.get(j).text());
			}else {
				entity.setBf30_h("0");
			}
			if(!tds1.get(++j).text().isEmpty()) {
				entity.setBf31_h(tds1.get(j).text());
			}else {
				entity.setBf31_h("0");
			}
			if(!tds1.get(++j).text().isEmpty()) {
				entity.setBf32_h(tds1.get(j).text());
			}else {
				entity.setBf32_h("0");
			}
			if(!tds1.get(++j).text().isEmpty()) {
				entity.setBf40_h(tds1.get(j).text());
			}else {
				entity.setBf40_h("0");
			}
			if(!tds1.get(++j).text().isEmpty()) {
				entity.setBf41_h(tds1.get(j).text());
			}else {
				entity.setBf41_h("0");
			}
			if(!tds1.get(++j).text().isEmpty()) {
				entity.setBf42_h(tds1.get(j).text());
			}else {
				entity.setBf42_h("0");
			}
			if(!tds1.get(++j).text().isEmpty()) {
				entity.setBf43_h(tds1.get(j).text());
			}else {
				entity.setBf43_h("0");
			}
			if(!tds1.get(++j).text().isEmpty()) {
				entity.setBf00(tds1.get(j).text());
			}else {
				entity.setBf00("0");
			}
			if(!tds1.get(++j).text().isEmpty()) {
				entity.setBf11(tds1.get(j).text());
			}else {
				entity.setBf11("0");
			}
			if(!tds1.get(++j).text().isEmpty()) {
				entity.setBf22(tds1.get(j).text());
			}else {
				entity.setBf22("0");
			}
			if(!tds1.get(++j).text().isEmpty()) {
				entity.setBf33(tds1.get(j).text());
			}else {
				entity.setBf33("0");
			}
			if(!tds1.get(++j).text().isEmpty()) {
				entity.setBf44(tds1.get(j).text());
			}else {
				entity.setBf44("0");
			}
			if(!tds1.get(++j).text().isEmpty()) {
				entity.setOther(tds1.get(j).text());
			}else {
				entity.setOther("0");
			}
			//盘口的第二个tr标签：1:0 2:0 2:1 3:0 3:1 3:2 4:0 4:1 4:2 4:3
			tr = trs.get(++i);
			tds1 = tr.getElementsByTag("td");
			j = -1;
			if(!tds1.get(++j).text().isEmpty()) {
				entity.setBf10_c(tds1.get(j).text());
			}else {
				entity.setBf10_c("0");
			}
			if(!tds1.get(++j).text().isEmpty()) {
				entity.setBf20_c(tds1.get(j).text());
			}else {
				entity.setBf20_c("0");
			}
			if(!tds1.get(++j).text().isEmpty()) {
				entity.setBf21_c(tds1.get(j).text());
			}else {
				entity.setBf21_c("0");
			}
			if(!tds1.get(++j).text().isEmpty()) {
				entity.setBf30_c(tds1.get(j).text());
			}else {
				entity.setBf30_c("0");
			}
			if(!tds1.get(++j).text().isEmpty()) {
				entity.setBf31_c(tds1.get(j).text());
			}else {
				entity.setBf31_c("0");
			}
			if(!tds1.get(++j).text().isEmpty()) {
				entity.setBf32_c(tds1.get(j).text());
			}else {
				entity.setBf32_c("0");
			}
			if(!tds1.get(++j).text().isEmpty()) {
				entity.setBf40_c(tds1.get(j).text());
			}else {
				entity.setBf40_c("0");
			}
			if(!tds1.get(++j).text().isEmpty()) {
				entity.setBf41_c(tds1.get(j).text());
			}else {
				entity.setBf41_c("0");
			}
			if(!tds1.get(++j).text().isEmpty()) {
				entity.setBf42_c(tds1.get(j).text());
			}else {
				entity.setBf42_c("0");
			}
			if(!tds1.get(++j).text().isEmpty()) {
				entity.setBf43_c(tds1.get(j).text());
			}else {
				entity.setBf43_c("0");
			}
			entities.add(entity);
			//System.out.println(entity);
		}
		return trsAndPageBar[1];
	}
	
	/**
	 * 爬取入球数的每一页盘口数据
	 * @param url
	 * @param types 早盘/今日/滚球
	 * @param playType
	 */
	private Elements crawlRQSOfSinglePage(String url,String types,String playType,List<FootBallMatch> entities,boolean isDefaultPage) {
		Elements[] trsAndPageBar = connectForTrsAndPageBar(url,isDefaultPage);
		Elements trs = trsAndPageBar[0];
		if(trs==null || trs.isEmpty() || trs.size() == 1) {
			return null;
		}
		//从第二个tr标签开始遍历：如果是赛事名称class="b_title"-缓存起来，然后对接下来的数据进行封装
		//缓存赛事名称
		String league = "";
		for (int i=1 ; i < trs.size() ; i++) {
			Element tr = trs.get(i);
			Elements leagues = tr.getElementsByClass("b_title");
			//如果是赛事名称-缓存并进入下一行数据
			if(!leagues.isEmpty()) {
				league = leagues.first().text();
				tr = trs.get(++i);
			}	
			FootBallMatch entity = initFootBallMatch(playType,types,league,null);
			
			//解析每场比赛的盘口数据
			int j = 0;
			Elements tds1 = tr.getElementsByTag("td");
			parseTdTagForStartTime(tds1.get(j).text(),entity,types);
			parseTeamTdTagForTeams(tds1.get(++j).text().replaceAll("\\s+", " ").split(" "),entity);
			if(!tds1.get(++j).text().isEmpty()) {
				entity.setRq01(tds1.get(j).text());
			}else {
				entity.setRq01("0");
			}
			if(!tds1.get(++j).text().isEmpty()) {
				entity.setRq23(tds1.get(j).text());
			}else {
				entity.setRq23("0");
			}
			if(!tds1.get(++j).text().isEmpty()) {
				entity.setRq46(tds1.get(j).text());
			}else {
				entity.setRq46("0");
			}
			if(!tds1.get(++j).text().isEmpty()) {
				entity.setRq7(tds1.get(j).text());
			}else {
				entity.setRq7("0");
			}
			entities.add(entity);
			//System.out.println(entity);
		}
		return trsAndPageBar[1];
	}
	
	/**
	 * 爬取单式的每一页盘口数据
	 * @param url
	 * @param types 早盘/今日/滚球
	 * @param playType
	 */
	private Elements crawlDSOfSinglePage(String url,String types,String playType,List<FootBallMatch> entities,boolean isDefaultPage) {
		Elements[] trsAndPageBar = connectForTrsAndPageBar(url,isDefaultPage);
		Elements trs = trsAndPageBar[0];
		if(trs==null || trs.isEmpty() || trs.size() == 1) {
			return null;
		}
		//从第二个tr标签开始遍历：如果是赛事名称class="b_title"-缓存起来，然后对接下来的数据进行封装
		//缓存赛事名称
		String league = "";
		for (int i=1 ; i < trs.size() ; i++) {
			Element tr = trs.get(i);
			Elements leagues = tr.getElementsByClass("b_title");
			//如果是赛事名称-缓存并进入下一行数据
			if(!leagues.isEmpty()) {
				league = leagues.first().text();
				tr = trs.get(++i);
			}	
			FootBallMatch entity = initFootBallMatch(playType,types,league,null);
			
			//解析每场比赛的三行盘口数据
			//第一行
			parseFirstRow(tr,entity,types);
			//第二行
			tr = trs.get(++i);
			parseSecondRow(tr,entity);
			//第三行
			tr = trs.get(++i);
			parseThirdRow(tr,entity);
			entities.add(entity);
			//System.out.println(entity);
		}
		return trsAndPageBar[1];
	}

	/**
	 * 解析每场比赛的第三行盘口数据
	 * @param tr
	 * @param entity
	 */
	private void parseThirdRow(Element tr, FootBallMatch entity) {
		Elements tds3 = tr.getElementsByTag("td");
		if(!StringUtil.isBlank(tds3.get(1).text())) {
			entity.setDy_d(tds3.get(1).text());
		}
		if(!StringUtil.isBlank(tds3.get(3).text())) {
			entity.setFh_dy_d(tds3.get(3).text());
		}
	}

	/**
	 * 解析每场比赛的第二行盘口数据
	 * @param tr
	 * @param entity
	 */
	private void parseSecondRow(Element tr, FootBallMatch entity) {
		Elements tds2 = tr.getElementsByTag("td");
		int j = 0;
		if(!StringUtil.isBlank(tds2.get(j).text())) {
			entity.setDy_c(tds2.get(j).text());
		}
		if(!tds2.get(++j).getElementsByTag("font").isEmpty()) {
			entity.setRq_c(tds2.get(j).getElementsByTag("font").first().text().replaceAll(" ", ""));
		}
		if(!tds2.get(j).getElementsByTag("span").isEmpty()) {
			entity.setStrong("C");
			entity.setDes_rq("C"+tds2.get(j).getElementsByTag("span").first().text().replaceAll(" ", ""));					
		}
		if(!tds2.get(++j).getElementsByTag("font").isEmpty()) {
			entity.setDx_c(tds2.get(j).getElementsByTag("font").first().text().replaceAll(" ", ""));
			String des_dx_c = tds2.get(j).getElementsByTag("span").first().text().replaceAll(" ", "");
			des_dx_c = des_dx_c.substring(1);
			entity.setDes_dx_c(des_dx_c);
		}
		if(!tds2.get(++j).getElementsByTag("font").isEmpty()) {
			entity.setDs_c(tds2.get(j).getElementsByTag("font").first().text());
		}
		if(!StringUtil.isBlank(tds2.get(++j).text())) {
			entity.setFh_dy_c(tds2.get(j).text().replace(".00", ""));
		}
		if(!tds2.get(++j).getElementsByTag("font").isEmpty()) {
			entity.setFh_rq_c(tds2.get(j).getElementsByTag("font").first().text().replaceAll(" ", ""));
		}
		if(!tds2.get(j).getElementsByTag("span").isEmpty()) {
			entity.setStrong("C");
			entity.setDes_fh_rq("C"+tds2.get(j).getElementsByTag("span").first().text().replaceAll(" ", ""));
		}
		if(!tds2.get(++j).getElementsByTag("font").isEmpty()) {
			entity.setFh_dx_c(tds2.get(j).getElementsByTag("font").first().text().replaceAll(" ", ""));
			String des_fh_dx_c = tds2.get(j).getElementsByTag("span").first().text().replaceAll(" ", "");
			des_fh_dx_c = des_fh_dx_c.substring(1);
			entity.setDes_fh_dx_c(des_fh_dx_c);
		}
	}

	/**
	 * 解析每场比赛的第一行盘口数据
	 * @param tr
	 * @param entity
	 * @param types
	 */
	private void parseFirstRow(Element tr,FootBallMatch entity,String types) {
		int j = 0;
		Elements tds1 = tr.getElementsByTag("td");
		String teamText = tds1.get(++j).text();
		if(FootballData.TYPES_GQ.equals(types) && teamText.contains("红")) {
			teamText = teamText.replaceAll("红\\d+", "");
		}
		parseTeamTdTagForTeams(teamText.replaceAll("\\s+", " ").split(" "),entity);
		parseTdTagForStartTime(tds1.get(0).text(),entity,types);
		if(!tds1.get(++j).text().isEmpty()) {
			entity.setDy_h(tds1.get(j).text());
		}
		if(!tds1.get(++j).getElementsByTag("font").isEmpty()) {
			entity.setRq_h(tds1.get(j).getElementsByTag("font").first().text().replaceAll(" ", ""));
		}
		if(!tds1.get(j).getElementsByTag("span").isEmpty()) {
			entity.setStrong("H");
			entity.setDes_rq("H"+tds1.get(j).getElementsByTag("span").first().text().replaceAll(" ", ""));					
		}
		if(!tds1.get(++j).getElementsByTag("font").isEmpty()) {
			entity.setDx_h(tds1.get(j).getElementsByTag("font").first().text().replaceAll(" ", ""));
			String des_dx_h = tds1.get(j).getElementsByTag("span").first().text().replaceAll(" ", "");
			des_dx_h = des_dx_h.substring(1);
			entity.setDes_dx_h(des_dx_h);
		}
		if(!tds1.get(++j).getElementsByTag("font").isEmpty()) {
			entity.setDs_h(tds1.get(j).getElementsByTag("font").first().text());
		}
		if(!StringUtil.isBlank(tds1.get(++j).text())) {
			entity.setFh_dy_h(tds1.get(j).text());
		}
		if(!tds1.get(++j).getElementsByTag("font").isEmpty()) {
			entity.setFh_rq_h(tds1.get(j).getElementsByTag("font").first().text().replaceAll(" ", ""));
		}
		if(!tds1.get(j).getElementsByTag("span").isEmpty()) {
			entity.setStrong("H");
			entity.setDes_fh_rq("H"+tds1.get(j).getElementsByTag("span").first().text().replaceAll(" ", ""));
		}
		if(!tds1.get(++j).getElementsByTag("font").isEmpty()) {
			entity.setFh_dx_h(tds1.get(j).getElementsByTag("font").first().text().replaceAll(" ", ""));
			String des_fh_dx_h = tds1.get(j).getElementsByTag("span").first().text().replaceAll(" ", "");
			des_fh_dx_h = des_fh_dx_h.substring(1);
			entity.setDes_fh_dx_h(des_fh_dx_h);
		}
	}

	/**
	 * 解析比赛队伍名称
	 * @param split
	 */
	private void parseTeamTdTagForTeams(String[] teams,FootBallMatch entity) {
		switch (teams.length) {
		case 2:
			entity.setTeam_h(teams[0]);
			entity.setTeam_c(teams[1]);
			break;
		case 3:
			entity.setTeam_h(teams[0]+teams[1]);
			entity.setTeam_c(teams[2]);
			break;
		case 4:
			entity.setTeam_h(teams[0]+teams[1]);
			entity.setTeam_c(teams[2]+teams[3]);
			break;
		case 5:
			entity.setTeam_h(teams[0]+teams[1]+teams[2]);
			entity.setTeam_c(teams[3]+teams[4]);
			break;
		case 6:
			entity.setTeam_h(teams[0]+teams[1]+teams[2]);
			entity.setTeam_c(teams[3]+teams[4]+teams[5]);
			break;
		case 7:
			entity.setTeam_h(teams[0]+teams[1]+teams[2]+teams[3]);
			entity.setTeam_c(teams[4]+teams[5]+teams[6]);
			break;
		case 8:
			entity.setTeam_h(teams[0]+teams[1]+teams[2]+teams[3]);
			entity.setTeam_c(teams[4]+teams[5]+teams[6]+teams[7]);
			break;
		case 9:
			entity.setTeam_h(teams[0]+teams[1]+teams[2]+teams[3]+teams[4]);
			entity.setTeam_c(teams[5]+teams[6]+teams[7]+teams[8]);
			break;
		case 10:
			entity.setTeam_h(teams[0]+teams[1]+teams[2]+teams[3]+teams[4]);
			entity.setTeam_c(teams[5]+teams[6]+teams[7]+teams[8]+teams[9]);
			break;
		default:
			entity.setTeam_h(Arrays.toString(teams));
			entity.setTeam_c(Arrays.toString(teams));
			System.out.println("解析比赛队伍名称异常，拆分后数组的长度为："+teams.length);
			break;
		}
	}

	/**
	 * 解析比赛时间所在的单元格
	 * @param tds
	 * @param entity
	 * @return
	 */
	private void parseTdTagForStartTime(String startTime, FootBallMatch entity,String types) {
		if(startTime.contains(PLAY_TYPE_GQ)) {
			startTime = startTime.substring(0, startTime.indexOf(" "+PLAY_TYPE_GQ));
			entity.setRoll("1");
		}else {
			entity.setRoll("0");
		}
		if(FootballData.TYPES_TODAY.equals(types)) {
			entity.setStart_time(LocalDateTime.now().minusHours(12).toString().substring(5, 10)+" "+startTime);
		}else if(FootballData.TYPES_GQ.equals(types)) {
			String matchTime = startTime.replace('-', ':');
			entity.setMatch_time(matchTime);
			String[] timeText = startTime.replaceAll("\\s+", " ").split(" "); 
			entity.setScore_h(timeText[1]);
			entity.setScore_c(timeText[3]);
			entity.setStart_time(fMatchService.findStartTime(entity.getLeague(),entity.getTeam_h(),entity.getTeam_c(),LocalDateTime.now().minusHours(12).toString()));
		}else {
			entity.setStart_time(startTime);			
		}
	}
	
	/**
	 * 初始化实体对象
	 * @param type
	 * @param types
	 * @param league
	 * @param sgNum 综合过关串数
	 * @return
	 */
	private FootBallMatch initFootBallMatch(String type,String types, String league,String sgNum) {
		FootBallMatch entity = new FootBallMatch();
		entity.setType(type);
		entity.setTypes(types);
		entity.setCtime(getCurrTime());
		entity.setLeague(league);
		if(sgNum != null) {
			entity.setSg_num(sgNum);			
		}
		return entity;
	}

	/**
	 * 获取当前时间，格式为：yyyy-MM-dd HH:mm:ss
	 * @return
	 */
	public static String getCurrTime() {
		return LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));
	}

	/**
	 * 建立远程连接获取行数据
	 * @param url
	 * @return
	 */
	private Elements[] connectForTrsAndPageBar(String url,boolean isDefaultPage) {
		Elements[] trsAndPageBar = new Elements[2];
		Document doc = connectForDoc(url);
		Elements trs = null;
		Elements pageBar = null;
		if(doc != null) {			
			trs = doc.getElementsByTag("tr");
			if(isDefaultPage) {
				pageBar = doc.getElementsByClass("pageBar");
			}
		}
		trsAndPageBar[0] = trs;
		trsAndPageBar[1] = pageBar;
		return trsAndPageBar;
	}

	/**
	 * 根据url获取doc对象
	 * @param url
	 * @return
	 */
	private Document connectForDoc(String url) {
		Document doc = null;
		try {
			doc = Jsoup.connect(url).timeout(5000).get();
			while("".equals(doc.getElementsByTag("body").first().html())) {
				try {
					Thread.sleep(1000);
				} catch (InterruptedException e) {}
				doc = Jsoup.connect(url).timeout(5000).get();
				//System.out.println("FootballData.connectForDoc():doc对象中无可用数据!继续获取中。。。");
			}
		} catch (Exception e) {
			//System.out.println(e.getMessage());
		}
		return doc;
	}

	/**
	 * 
	 * @param args
	 */
	public static void main(String[] args) {
		//Document doc = Jsoup.parse("<body><div>fffff</div></body>");
		//System.out.println(doc.getElementsByTag("body").first().hasText());
		System.out.println(new FootballData().fMatchService);
	}
	
}
