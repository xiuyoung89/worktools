package com.ja.domain;

import java.io.Serializable;

public class Joint implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 4844267446205062241L;
	private Integer id;//合买订单
	private String user;//用户名
	private Integer zcount;//总分数
	private Double price;//单份金额
	private Integer rcount;//认购分数
	private Integer bcount;//保底份数
	private Integer sjbcount;//实际保底份数
	private Integer hcount;//合买分数
	private Integer scount;//剩下分数
	private Double hMoney;//购买金额
	private Double zjjine;//中奖金额
	private Double fajine;//方案金额
	private Double zMoney;//中奖金额
	private String shenglv;//中奖金额
	private String orderNum;//订单号
	private String checkNum;//订单号
	private String cpname;//彩种名称
	private String qihao;//期号
	private Integer ddstate;//订单状态
	private Integer tqstate;//退钱状态
	private String createtime;//创建时间
	private Integer state;//发起人-合买人-状态
	private Integer userid;//用户id

    
    public static long getSerialversionuid() {
		return serialVersionUID;
	}
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getUser() {
		return user;
	}

	public String getShenglv() {
		return shenglv;
	}

	public void setShenglv(String shenglv) {
		this.shenglv = shenglv;
	}

	public String getCpname() {
		return cpname;
	}

	public void setCpname(String cpname) {
		this.cpname = cpname;
	}

	public void setUser(String user) {
		this.user = user;
	}

	public Integer getZcount() {
		return zcount;
	}

	public void setZcount(Integer zcount) {
		this.zcount = zcount;
	}

	public Double getPrice() {
		return price;
	}

	public void setPrice(Double price) {
		this.price = price;
	}

	public String getCheckNum() {
		return checkNum;
	}

	public void setCheckNum(String checkNum) {
		this.checkNum = checkNum;
	}

	public String getCreatetime() {
		return createtime;
	}

	public void setCreatetime(String createtime) {
		this.createtime = createtime;
	}

	public Integer getRcount() {
		return rcount;
	}

	public void setRcount(Integer rcount) {
		this.rcount = rcount;
	}

	public Integer getBcount() {
		return bcount;
	}

	public void setBcount(Integer bcount) {
		this.bcount = bcount;
	}

	public Double getZjjine() {
		return zjjine;
	}

	public void setZjjine(Double zjjine) {
		this.zjjine = zjjine;
	}

	public Double getFajine() {
		return fajine;
	}

	public void setFajine(Double fajine) {
		this.fajine = fajine;
	}

	public Integer getHcount() {
		return hcount;
	}

	public void setHcount(Integer hcount) {
		this.hcount = hcount;
	}

	public Integer getScount() {
		return scount;
	}

	public void setScount(Integer scount) {
		this.scount = scount;
	}

	public Double gethMoney() {
		return hMoney;
	}

	public void sethMoney(Double hMoney) {
		this.hMoney = hMoney;
	}

	public Double getzMoney() {
		return zMoney;
	}

	public void setzMoney(Double zMoney) {
		this.zMoney = zMoney;
	}

	public String getOrderNum() {
		return orderNum;
	}

	public void setOrderNum(String orderNum) {
		this.orderNum = orderNum;
	}

	public Integer getSjbcount() {
		return sjbcount;
	}

	public void setSjbcount(Integer sjbcount) {
		this.sjbcount = sjbcount;
	}

	public String getQihao() {
		return qihao;
	}

	public void setQihao(String qihao) {
		this.qihao = qihao;
	}

	public Integer getDdstate() {
		return ddstate;
	}

	public void setDdstate(Integer ddstate) {
		this.ddstate = ddstate;
	}

	public Integer getTqstate() {
		return tqstate;
	}

	public void setTqstate(Integer tqstate) {
		this.tqstate = tqstate;
	}

	public Integer getUserid() {
		return userid;
	}

	public void setUserid(Integer userid) {
		this.userid = userid;
	}

	public Integer getState() {
		return state;
	}

	public void setState(Integer state) {
		this.state = state;
	}
	
	@Override
	public String toString() {
		return "Joint [id=" + id + ", user=" + user + ", zcount=" + zcount + ", price=" + price + ", rcount=" + rcount
				+ ", bcount=" + bcount + ", sjbcount=" + sjbcount + ", hcount=" + hcount + ", scount=" + scount
				+ ", hMoney=" + hMoney + ", zjjine=" + zjjine + ", fajine=" + fajine + ", zMoney=" + zMoney
				+ ", shenglv=" + shenglv + ", orderNum=" + orderNum + ", checkNum=" + checkNum + ", cpname=" + cpname
				+ ", qihao=" + qihao + ", ddstate=" + ddstate + ", tqstate=" + tqstate + ", createtime=" + createtime
				+ ", state=" + state + ", userid=" + userid + "]";
	}

	public Joint() {
		super();
	}

}
