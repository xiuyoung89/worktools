package com.ja.controller;

import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.ja.domain.FootBallMatch;
import com.ja.domain.FootBallOrder;
import com.ja.domain.User;
import com.ja.sevice.FootBallMatchService;
import com.ja.sevice.FootBallOrderService;
import com.ja.util.JsonResult;
@Controller
@RequestMapping("/match")
public class FootBallMatchController {

	@Autowired
	private FootBallMatchService fMatchService;

	@Autowired
	private FootBallOrderService fOrderService;

	public static Timer timer = new Timer();

	public static List<TimerTask> dataTasks = new ArrayList<>();

	public static List<TimerTask> resultTasks = new ArrayList<>();

	/**
	 * @param play
	 *            玩法
	 * @param type
	 *            投注类型
	 * @param time
	 *            时间
	 * @return 根据玩法以及投注类型查询赛事信息
	 */
	@RequestMapping("/findTypeMatch")
	@ResponseBody
	public JsonResult findTypeMatch(String play, String type) {
		SimpleDateFormat ss = new SimpleDateFormat("yyyy-MM-dd");
		String time = ss.format(new Date());
		return new JsonResult("findTypeMatch", fMatchService.findTypeMatch(play, type, time));
	}

	/**
	 * @param cname
	 *            赛事目录名称
	 * @param play
	 *            玩法
	 * @param type
	 *            投注类型
	 * @param time
	 *            时间
	 * @return 根据类型查询具体的赛事信息
	 */
	@RequestMapping("/findMatchInfo")
	@ResponseBody
	public JsonResult findMatchInfo(String cname, String play, String type) {
		SimpleDateFormat ss = new SimpleDateFormat("yyyy-MM-dd");
		String time = ss.format(new Date());
		return new JsonResult("findMatchInfo", fMatchService.findMatchInfo(cname, play, type, time));
	}

	/**
	 * 爬比赛数据
	 * 
	 * @return
	 */
	@RequestMapping("/getFootballData")
	@ResponseBody
	public JsonResult getFootballData() {
		TimerTask timerTask = new TimerTask() {
			public void run() {
				fMatchService.getFootballData();
			}
		};
		dataTasks.add(timerTask);
		timer.schedule(timerTask, 0, 30 * 1000);
		return new JsonResult("1", null);
	}

	/**
	 * 停止爬比赛数据
	 * 
	 * @return
	 */
	@RequestMapping("/stopGetFootballData")
	@ResponseBody
	public JsonResult stopGetFootballData() {
		for (TimerTask timerTask : dataTasks) {
			timerTask.cancel();
		}
		System.out.println("--------------------【已停止爬取比赛数据】-------------------");
		return new JsonResult("1", null);
	}

	/**
	 * 爬赛果数据
	 * 
	 * @return
	 */
	@RequestMapping("/getFootballResult")
	@ResponseBody
	public JsonResult getFootballResult() {
		TimerTask timerTask = new TimerTask() {
			public void run() {
				fMatchService.getFootballResult();
			}
		};
		resultTasks.add(timerTask);
		timer.schedule(timerTask, 0, 1000 * 60 * 60);
		return new JsonResult("1", null);
	}

	/**
	 * 停止爬赛果数据
	 * 
	 * @return
	 */
	@RequestMapping("/stopGetFootballResult")
	@ResponseBody
	public JsonResult stopGetFootballResult() {
		for (TimerTask timerTask : resultTasks) {
			timerTask.cancel();
		}
		System.out.println("--------------------【已停止爬取赛果数据】-------------------");
		return new JsonResult("1", null);
	}

	/**
	 * 
	 * @param order
	 *            订单信息
	 * @return 投注可赢金额
	 */
	@RequestMapping("/orderMaxMoney")
	@ResponseBody
	public JsonResult orderMaxMoney(FootBallOrder order, String fids) {
		DecimalFormat dec = new DecimalFormat("#0.00");
		double rebate = 0.00;
		double maxMoney = 0.00;
		if (order.getType().equals("综合过关")) {
			List<Double> rebate1 = new ArrayList<>();
			double maxRebate = 1;
			String[] rebates = order.getRebate().split(",");
			for (int i = 0; i < rebates.length; i++) {
				rebate1.add(Double.parseDouble(rebates[i].split(" ")[1]));
			}
			for (int i = 0; i < rebate1.size(); i++) {
				maxRebate *= rebate1.get(i);
			}
			maxMoney = (maxRebate - 1.0) * order.getAcount();
			return new JsonResult("orderMaxMoney", dec.format(maxMoney));
		}
		try {
			rebate = Double.parseDouble(order.getRebate().split(" ")[1]);
		} catch (Exception e) {
			rebate = Double.parseDouble(order.getRebate());
		}
		if (order.getAttributes().equals("rq_h") || order.getAttributes().equals("rq_c")
				|| order.getAttributes().equals("fh_rq_h") || order.getAttributes().equals("fh_rq_c")
				|| order.getAttributes().equals("dx_h") || order.getAttributes().equals("dx_c")
				|| order.getAttributes().equals("fh_dx_h") || order.getAttributes().equals("fh_dx_c")) {
			maxMoney = rebate * order.getAcount();
		} else {
			maxMoney = (rebate - 1) * order.getAcount();
		}
		return new JsonResult("orderMaxMoney", dec.format(maxMoney));
	}

	/**
	 * 
	 * @param order
	 *            订单信息
	 * @param session
	 * @return 插入订单
	 */
	@RequestMapping("/orderInfo")
	@ResponseBody
	public JsonResult orderInfo(String fid, FootBallOrder order, String fids, HttpSession session) {
		User user = (User) session.getAttribute("user");
		SimpleDateFormat ss = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		SimpleDateFormat sf = new SimpleDateFormat("yyyyMMddHHmmss");
		String time = ss.format(new Date());
		String league = "";
		String team_h = "";
		String team_c = "";
		String peril = "";
		String attr = "";
		FootBallMatchController fmc = new FootBallMatchController();
		String order_num = "L" + sf.format(new Date());
		if (order.getType().equals("综合过关")) {
			String[] ids = fids.split(",");
			String[] attributes = order.getAttributes().split(",");
			String[] des_in = order.getDes_in().split(",");
			String[] rebate = order.getRebate().split(",");
			for (int i = 0; i < ids.length; i++) {
				FootBallOrder fo = new FootBallOrder();
				FootBallMatch fm = fMatchService.findOneMatchInfo(Integer.parseInt(ids[i]));
				attr = fmc.attribute(attributes[i], "123");
				fo.setLeague(fm.getLeague());
				fo.setTeam_h(fm.getTeam_h());
				fo.setTeam_c(fm.getTeam_c());
				fo.setMid(fm.getId() + "");
				fo.setOrder_num(order_num);
				fo.setAttributes(attr);
				fo.setRebate(rebate[i]);
				fo.setDes_in(des_in[i]);
				fo.setCtime(time);
				fOrderService.addFootBallSeriesInfo(fo);

				league = fm.getLeague();
				team_h = fm.getTeam_h();
				team_c = fm.getTeam_c();
				fid = fm.getId() + "";
			}
			fids = ids[ids.length - 1];
		} else {
			FootBallMatch fm = fMatchService.findOneMatchInfo(Integer.parseInt(fids));
			league = fm.getLeague();
			team_h = fm.getTeam_h();
			team_c = fm.getTeam_c();
			if (order.getType().equals("滚球")) {
				peril = fm.getPeril();
			}
			attr = fmc.attribute(order.getAttributes(), fm.getTeam_h());
		}
		order.setLeague(league);
		order.setTeam_h(team_h);
		order.setTeam_c(team_c);
		order.setName(user.getName());
		order.setCtime(time);
		order.setState(1);
		order.setUser_id(user.getId());
		order.setOrder_num(order_num);
		order.setMid(fids);
		order.setAttributes(attr);
		if (user.getBalance() >= order.getAcount()) {
			int a = fOrderService.addFootBallOrder(order, user);
			String info = "";
			if (a == 1) {
				info = "下注成功";
			} else {
				info = "系统繁忙,请稍候再试";
			}
			return new JsonResult(peril, info);
		} else {
			/** 余额不足 */
			return new JsonResult("0", "余额不足 ");
		}
	}

	public String attribute(String attrs, String matchName) {
		String attr = "";
		String a1 = "";
		if (matchName.contains("上半")) {
			a1 = "半场比分 ";
		} else {
			a1 = "全场比分 ";
		}
		switch (attrs) {
		// 单式
		case "dy_h":
		case "dy_c":
		case "dy_d":
			attr = "全场-独赢";
			break;
		case "fh_dy_h":
		case "fh_dy_c":
		case "fh_dy_d":
			attr = "半场-独赢";
			break;
		case "rq_h":
		case "rq_c":
			attr = "全场-让球";
			break;
		case "fh_rq_h":
		case "fh_rq_c":
			attr = "半场-让球";
			break;
		case "dx_h":
		case "dx_c":
			attr = "全场-大小";
			break;
		case "fh_dx_h":
		case "fh_dx_c":
			attr = "半场-大小";
			break;
		case "ds_h":
		case "ds_c":
			attr = "全场-单双";
			break;

		// 波胆
		case "bf10_h":
			attr = a1 + "1:0";
			break;
		case "bf10_c":
			attr = a1 + "0:1";
			break;
		case "bf20_h":
			attr = a1 + "2:0";
			break;
		case "bf20_c":
			attr = a1 + "0:2";
			break;
		case "bf21_h":
			attr = a1 + "2:1";
			break;
		case "bf12_c":
			attr = a1 + "1:2";
			break;
		case "bf30_h":
			attr = a1 + "3:0";
			break;
		case "bf03_c":
			attr = a1 + "0:3";
			break;
		case "bf31_h":
			attr = a1 + "3:1";
			break;
		case "bf13_c":
			attr = a1 + "1:3";
			break;
		case "bf32_h":
			attr = a1 + "3:2";
			break;
		case "bf23_c":
			attr = a1 + "2:3";
			break;
		case "bf40_h":
			attr = a1 + "4:0";
			break;
		case "bf04_c":
			attr = a1 + "0:4";
			break;
		case "bf41_h":
			attr = a1 + "4:1";
			break;
		case "bf14_c":
			attr = a1 + "1:4";
			break;
		case "bf42_h":
			attr = a1 + "4:2";
			break;
		case "bf24_c":
			attr = a1 + "2:4";
			break;
		case "bf43_h":
			attr = a1 + "4:3";
			break;
		case "bf34_c":
			attr = a1 + "3:4";
			break;
		case "bf00_h":
			attr = a1 + "0:0";
			break;
		case "bf11_c":
			attr = a1 + "1:1";
			break;
		case "bf22_h":
			attr = a1 + "2:2";
			break;
		case "bf33_c":
			attr = a1 + "3:3";
			break;
		case "bf44_h":
			attr = a1 + "4:4";
			break;
		case "other":
			attr = a1 + "其他";
			break;
		// 入球数
		case "rq01":
			attr = "0~1";
			break;
		case "rq23":
			attr = "2~3";
			break;
		case "rq46":
			attr = "4~6";
			break;
		case "rq7":
			attr = "7up";
			break;
		// 半全场
		case "hh":
			attr = "主/主";
			break;
		case "hd":
			attr = "主/和";
			break;
		case "hc":
			attr = "主/客";
			break;
		case "dh":
			attr = "和/主";
			break;
		case "dd":
			attr = "和/和";
			break;
		case "dc":
			attr = "和/客";
			break;
		case "ch":
			attr = "客/主";
			break;
		case "cd":
			attr = "客/和";
			break;
		case "cc":
			attr = "客/客";
			break;
		}
		return attr;
	}

	/**
	 * @param session
	 *            用户信息
	 * @return 查询所有的订单信息
	 */
	@ResponseBody
	@RequestMapping("/findOneAllOrder")
	public JsonResult findOneAllOrder(HttpSession session) {
		User user = (User) session.getAttribute("user");
		List<FootBallOrder> fOrder = fOrderService.findOneAllOrder(user.getId());
		return new JsonResult("findOneAllOrder", fOrder);
	}

	/**
	 * @param id
	 *            订单id
	 * @return 根据id查询 订单详情
	 */
	@ResponseBody
	@RequestMapping("/findOrderInfo")
	public JsonResult findOrderInfo(Integer id) {
		FootBallOrder fOrder = fOrderService.findOrderInfo(id);
		return new JsonResult("findOrderInfo", fOrder);
	}

	/**
	 * 查询一组赛事的信息
	 * @param id 赛事id
	 * @return
	 */
	@ResponseBody
	@RequestMapping("/findGroupOrderInfo")
	public JsonResult findGroupOrderInfo(String id) {
		String[] strings = id.split(",");
		List<FootBallMatch> fbm = new ArrayList<>();
		for (int i = 0; i < strings.length; i++) {
			FootBallMatch fMatch = fMatchService.findOneMatchInfo(Integer.parseInt(strings[i]));
			fbm.add(fMatch);
		}
		return new JsonResult("findGroupOrderInfo", fbm);
	}
	/**
	 * 根据时间查询赛事结果
	 * @param date 查询时间
	 * @return
	 */
	@ResponseBody
	@RequestMapping("/findMatchResult")
	public JsonResult matchResult(String date) {
		List<FootBallMatch> matchResult = fMatchService.findMatchResult(date.substring(5,10));
		return new JsonResult("findGroupOrderInfo", matchResult);
	}

	/***
	 * 赛事作废时,一键退钱
	 * 
	 * @return
	 */
	public int returnMonery() {

		return 1;
	}

}
