package com.ja.controller;

import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.UUID;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

import com.ja.config.WebsiteStateConfig;
import com.ja.domain.Admin;
import com.ja.domain.AdminUser;
import com.ja.domain.Agent;
import com.ja.domain.AppDownload;
import com.ja.domain.DepositBank;
import com.ja.domain.ParkedDomains;
import com.ja.domain.RechargeInterface;
import com.ja.domain.ScavengingPayment;
import com.ja.domain.UpDataPage;
import com.ja.domain.User;
import com.ja.domain.WhiteList;
import com.ja.sevice.AddPaymentService;
import com.ja.sevice.DepositBankService;
import com.ja.sevice.IAdminService;
import com.ja.sevice.ISystemConfigService;
import com.ja.sevice.LiushuiService;
import com.ja.sevice.OperationlogService;
import com.ja.sevice.RechargeInterfaceService;
import com.ja.util.DateUtil;
import com.ja.util.JsonResult;
import com.ja.util.UploadUtil;
import com.ja.util.WebSocketJson;

/**
 * 项目名称：cp   
 * 类名称：Ht_XTSZController.java   
 * 类描述：   
 * 创建人：   GL
 * 创建时间：2019年2月21日 下午3:35:52   
 * @version v1.0.0
 */
@Controller
@RequestMapping("/admin")
public class Ht_XTSZController {
	@Autowired
	private ISystemConfigService systemConfigService;

	@Autowired
	private IAdminService adminService;

	@Autowired
	private DepositBankService depositBankService;

	@Autowired
	private LiushuiService liushuiService;

	@Autowired
	private OperationlogService operationlogService;
	
	@Autowired
	private  AddPaymentService addPaymentService;
	
	@Autowired
	private RechargeInterfaceService rechargeInterfaceService;

	
	/**
	 * 
	 * ----TODO：平台基本管理
	 * 
	 */
	
	/**
	 * 方法名：systemManagementPage 
	 * 描述：    平台基本管理页面                  
	 * 参数：    @return 
	 * @return: String
	 */
	@RequestMapping("/systemManagementPage")
	public String systemManagementPage() {
		return "htgl/wangzhanjibenshezhi";
	}
	
	/**
	 * 方法名：findSystemConfigure 
	 * 描述：     查询所有的网站配置                  
	 * 参数：    @return 
	 * @return: JsonResult
	 */
	@ResponseBody
	@RequestMapping("/findSystemConfigure")
	public JsonResult findSystemConfigure() {
		return new JsonResult("success", systemConfigService.findAllConfig());
	}
	
	/**
	 * 
	 * ----系统配置
	 * 
	 */
	
	/**
	 * 方法名：websiteMaintainSetup 
	 * 描述：    网站维护设置                   
	 * 参数：    @param weihukaiguan  修改状态 1是开启 0是关闭 
	 * 参数：    @return 
	 * @return: JsonResult
	 */
	@ResponseBody
	@RequestMapping("/websiteMaintainSetup")
	public JsonResult websiteMaintainSetup(HttpSession session,Integer weihukaiguan) {
		Admin admin = new Admin();
		admin.setWeihukaiguan(weihukaiguan);
		Integer line = systemConfigService.updateAllConfig(admin);
		WebsiteStateConfig.webisteAllConfig(admin);
		new  WebSocketJson(1,weihukaiguan).sendAll();
		String type = "开启了";
		if(weihukaiguan==0) {
			type = "关闭了";
		}
		AdminUser admins = (AdminUser) session.getAttribute("admin1");
		String remarks = type +"网站维护功能!";
		operationlogService.addOperationlog(admins, remarks, "平台基本管理 ");
		return new JsonResult("success",line);
	}

	/**
	 * 方法名：maintainReasonSetup 
	 * 描述：    网站维护原因                   
	 * 参数：    @param weihuyuanyin 维护原因
	 * 参数：    @return 
	 * @return: JsonResult
	 */
	@ResponseBody
	@RequestMapping("/maintainReasonSetup")
	public JsonResult maintainReasonSetup(HttpSession session,String weihuyuanyin) {
		Admin admin = new Admin();
		admin.setWeihuyuanyin(weihuyuanyin);
		Integer line = systemConfigService.updateAllConfig(admin);
		WebsiteStateConfig.webisteAllConfig(admin);
		AdminUser admins = (AdminUser) session.getAttribute("admin1");
		String remarks = "修改了网站维护原因!";
		operationlogService.addOperationlog(admins, remarks, "平台基本管理 ");
		return new JsonResult("success",line);
	}
	
	/**
	 * 方法名：flowingWaterSetup 
	 * 描述：    帐变记录开关                   
	 * 参数：    @param zhangbiankaiguan 修改状态 1是开启 0是关闭 
	 * 参数：    @return 
	 * @return: JsonResult
	 */
	@ResponseBody
	@RequestMapping("/flowingWaterSetup")
	public JsonResult flowingWaterSetup(HttpSession session,Integer zhangbiankaiguan) {
		Admin admin = new Admin();
		admin.setZhangbiankaiguan(zhangbiankaiguan);
		Integer line = systemConfigService.updateAllConfig(admin);
		WebsiteStateConfig.webisteAllConfig(admin);
		String type = "开启了";
		if(zhangbiankaiguan==0) {
			type = "关闭了";
		}
		AdminUser admins = (AdminUser) session.getAttribute("admin1");
		String remarks = type +"用户帐变功能!";
		operationlogService.addOperationlog(admins, remarks, "平台基本管理 ");
		return new JsonResult("success",line);
	}
	
	/**
	 * 方法名：whiteListSetup 
	 * 描述：    后台用户白名单开关                   
	 * 参数：    @param baimingdankaiguan 修改状态 1是开启 0是关闭 
	 * 参数：    @return 
	 * @return: JsonResult
	 */
	@ResponseBody
	@RequestMapping("/whiteListSetup")
	public JsonResult whiteListSetup(HttpSession session,Integer baimingdankaiguan) {
		Admin admin = new Admin();
		admin.setBaimingdankaiguan(baimingdankaiguan);
		Integer line = systemConfigService.updateAllConfig(admin);
		WebsiteStateConfig.webisteAllConfig(admin);
		String type = "开启了";
		if(baimingdankaiguan==0) {
			type = "关闭了";
		}
		AdminUser admins = (AdminUser) session.getAttribute("admin1");
		String remarks = type +"后台白名单功能!";
		operationlogService.addOperationlog(admins, remarks, "平台基本管理 ");
		return new JsonResult("success",line);
	}

	/**
	 * 方法名：chatRoomSetup 
	 * 描述：    聊天室开关                   
	 * 参数：    @param chatroomFlag 开启关闭状态
	 * 参数：    @return 
	 * @return: JsonResult
	 */
	@ResponseBody
	@RequestMapping("/chatRoomSetup")
	public JsonResult chatRoomSetup(HttpSession session,Integer chatroomFlag) {
		Admin admin = new Admin();
		admin.setChatroomFlag(chatroomFlag);
		Integer line = systemConfigService.updateAllConfig(admin);
		WebsiteStateConfig.webisteAllConfig(admin);
		new WebSocketJson(2,chatroomFlag).sendAll();
		String type = "开启了";
		if(chatroomFlag==0) {
			type = "关闭了";
		}
		AdminUser admins = (AdminUser) session.getAttribute("admin1");
		String remarks = type +"聊天室聊天功能!";
		operationlogService.addOperationlog(admins, remarks, "平台基本管理 ");
		return new JsonResult("success",line);
	}
	
	/**
	 * 方法名：agentMinMonyeSetup 
	 * 描述：     设置代理返点最低领取金额                  
	 * 参数：    @param receiveAReturnPoint 最低领取金额
	 * 参数：    @return 
	 * @return: JsonResult
	 */
	@RequestMapping("/agentMinMonyeSetup")
	@ResponseBody
	public JsonResult agentMinMonyeSetup(HttpSession session,Double receiveAReturnPoint) {
		Admin admin = new Admin();
		admin.setReceiveAReturnPoint(receiveAReturnPoint);
		Integer line = systemConfigService.updateAllConfig(admin);
		WebsiteStateConfig.webisteAllConfig(admin);
		AdminUser admins = (AdminUser) session.getAttribute("admin1");
		String remarks = "修改了代理返点最低领取金额："+receiveAReturnPoint +"!";
		operationlogService.addOperationlog(admins, remarks, "平台基本管理 ");
		return new JsonResult("success",line);
	}
	/**
	 *后台设置代理最低赔率
	 * @param odds
	 * @return 返回2则表示赔率不对  返回1 则表示成功 返回0是失败  我也不知道原因就是数据库修改失败了  3表示参数为null 或者是空串
	 */
	@RequestMapping("/minimumOdds")
	@ResponseBody
	public JsonResult minimumOdds(String odds) {
		System.out.println(odds+"-------odds的值");
		if(odds == null || "".equals(odds)) {
			return new JsonResult("参数不能为空",3);
		}
		NumberFormat nf= NumberFormat.getPercentInstance();	//将百分比转成 数字
		try {
			Number m=nf.parse(odds);
			DecimalFormat df = new DecimalFormat("#0.00000");
			String str = df.format(m);
			Admin admin = new Admin();
			admin.setMinimumOdds(Double.parseDouble(str));
			int num = systemConfigService.updateAllConfig(admin);
			WebsiteStateConfig.webisteAllConfig(admin);
			return new JsonResult(null,num);
		} catch (ParseException e) {
			return new JsonResult("赔率设置不对",2);
		}
	}
	
	/**
	 * 
	 * 快速下注金额配置
	 * 
	 */
	
	/**
	 * 方法名：quickBettingMoneySetup 
	 * 描述：    修改投注单注金额                   
	 * 参数：    @param admin 单注金额配置
	 * 参数：    @return 
	 * @return: JsonResult
	 */
	@RequestMapping("/quickBettingMoneySetup")
	@ResponseBody
	public JsonResult quickBettingMoneySetup(HttpSession session,Admin admin) {
		Integer line = systemConfigService.updateAllConfig(admin);
		WebsiteStateConfig.webisteAllConfig(admin);
		double money = 0.00;
		String remarks = "";
		if(null!=admin.getBuy1()) {
			money = admin.getBuy1();
			remarks = "修改了快速下注金额配置1为："+ money +"!";
		}else if(null!=admin.getBuy2()) {
			money = admin.getBuy2();
			remarks = "修改了快速下注金额配置2为："+ money +"!";
		}else if(null!=admin.getBuy3()) {
			money = admin.getBuy3();
			remarks = "修改了快速下注金额配置3为："+ money +"!";
		}else if(null!=admin.getBuy4()) {
			money = admin.getBuy4();
			remarks = "修改了快速下注金额配置4为："+ money +"!";
		}else if(null!=admin.getBuy5()) {
			money = admin.getBuy5();
			remarks = "修改了快速下注金额配置5为："+ money +"!";
		}
		AdminUser admins = (AdminUser) session.getAttribute("admin1");
		operationlogService.addOperationlog(admins, remarks, "平台基本管理 ");
		return new JsonResult("success",line);
	}
	
	
	/**
	 * 
	 * ----租户配置
	 * 
	 */
	
	
	/**
	 * 方法名：headerTitleSeting 
	 * 描述：     网站名称设置                  
	 * 参数：    @param headerTitle 网站名称
	 * 参数：    @return 
	 * @return: JsonResult
	 */
	@RequestMapping("/headerTitleSeting")
	@ResponseBody
	public JsonResult headerTitleSeting(HttpSession session,String headerTitle) {
		Admin admin  = new Admin();
		admin.setWangzhantitle(headerTitle);
		Integer line = systemConfigService.updateAllConfig(admin);
		WebsiteStateConfig.webisteAllConfig(admin);
		AdminUser admins = (AdminUser) session.getAttribute("admin1");
		String remarks = "修改了网站页面头部标题为："+headerTitle +"!";
		operationlogService.addOperationlog(admins, remarks, "平台基本管理 ");
		return new JsonResult("success",line);
	}

	/**
	 * 方法名：ipLimitRegisterSetup 
	 * 描述：     同一IP每天限制注册次数                 
	 * 参数：    @param ip 限制次数
	 * 参数：    @return 
	 * @return: JsonResult
	 */
	@RequestMapping("/ipLimitRegisterSetup")
	@ResponseBody
	public JsonResult ipLimitRegisterSetup(HttpSession session,Integer ip) {
		Admin admin = new Admin();
		admin.setZhuceipcount(ip);
		Integer line = systemConfigService.updateAllConfig(admin);
		WebsiteStateConfig.webisteAllConfig(admin);
		AdminUser admins = (AdminUser) session.getAttribute("admin1");
		String remarks = "修改了同一IP每天限制注册次数为："+ip +"次!";
		operationlogService.addOperationlog(admins, remarks, "平台基本管理 ");
		return new JsonResult("success",line);
	}
	
	/**
	 *   方法名：websiteLogoSetup   
	 *   描述：    设置网站logo                      
	 *   参数：    @param model model对象
	 *   参数：    @param file 上传的标志
	 *   参数：    @param requset request对象
	 *   参数：    @return 
	 * @return: ModelAndView
	 */
	@RequestMapping("websiteLogoSetup")
	public ModelAndView websiteLogoSetup(HttpSession session,ModelAndView model,MultipartFile file,HttpServletRequest requset) {
		model.setViewName("htgl/wangzhanjibenshezhi");
		String fileName = "";
		if (file.getOriginalFilename() != "") {
			String path = "d:/cp/admin/";
			UploadUtil uploadUitl = new UploadUtil();
			String name1 = file.getOriginalFilename();
			String[] name2 = name1.split("\\.");
			String name3 = UUID.randomUUID().toString().replaceAll("-", "").substring(23).toUpperCase()
					+ System.currentTimeMillis();
			String name4 = name3 + "." + name2[1];
			fileName = "admin/"+ uploadUitl.upload(file, requset, name4, path);
		}
		Admin admin = new Admin();
		admin.setLogo(fileName);
		systemConfigService.updateAllConfig(admin);
		WebsiteStateConfig.webisteAllConfig(admin);
		AdminUser admins = (AdminUser) session.getAttribute("admin1");
		String remarks = "修改了网站logo!";
		operationlogService.addOperationlog(admins, remarks, "平台基本管理 ");
		return model;
	}
	
	/**
	 * 方法名：websiteHeadWelcomeSetup 
	 * 描述：     设置网站PC端顶部欢迎语                  
	 * 参数：    @param admin
	 * 参数：    @return 
	 * @return: JsonResult
	 */
	@ResponseBody
	@RequestMapping("/websiteHeadWelcomeSetup")
	public JsonResult websiteHeadWelcomeSetup(HttpSession session,Admin admin) {
		Integer line = systemConfigService.updateAllConfig(admin);
		WebsiteStateConfig.webisteAllConfig(admin);
		AdminUser admins = (AdminUser) session.getAttribute("admin1");
		String remarks = "修改了网站头部欢迎语为："+admin.getPc_welcome()+"!";
		operationlogService.addOperationlog(admins, remarks, "平台基本管理 ");
		return new JsonResult("success",line);
	}
	
	/**
	 *   方法名：updateWeChat  
	 *   描述：    设置网站PC端微信客服的二维码                      
	 *   参数：    @param admin配置信息
	 *   参数：    @return 
	 * @return: JsonResult
	 */
	@RequestMapping("/updateWeChat")
	public ModelAndView updateWeChat(HttpSession session,ModelAndView model,MultipartFile file,HttpServletRequest requset) {
		model.setViewName("htgl/wangzhanjibenshezhi");
		String fileName = "";
		if (file.getOriginalFilename() != "") {
			String path = "d:/cp/admin/";
			UploadUtil uploadUitl = new UploadUtil();
			String name1 = file.getOriginalFilename();
			String[] name2 = name1.split("\\.");
			String name3 = UUID.randomUUID().toString().replaceAll("-", "").substring(23).toUpperCase()
					+ System.currentTimeMillis();
			String name4 = name3 + "." + name2[1];
			fileName = "admin/"+ uploadUitl.upload(file, requset, name4, path);
		}
		Admin admin = new Admin();
		admin.setPc_wechat(fileName);
		systemConfigService.updateAllConfig(admin);
		WebsiteStateConfig.webisteAllConfig(admin);
		AdminUser admins = (AdminUser) session.getAttribute("admin1");
		String remarks = "修改了网站PC端微信客服二维码!";
		operationlogService.addOperationlog(admins, remarks, "平台基本管理 ");
		return model;
	}
	
	
	/**
	 * 
	 * ----幸运转盘配置
	 * 
	 */
	
	/**
	 * 方法名：updateLuckyFlag 
	 * 描述：     幸运转盘配置                  
	 * 参数：    @param admin 配置信息
	 * 参数：    @return 
	 * @return: JsonResult
	 */
	@RequestMapping("/updateLuckyFlag")
	@ResponseBody
	public JsonResult updateLuckyFlag(HttpSession session,Admin admin) {
		Integer line = systemConfigService.updateAllConfig(admin);
		WebsiteStateConfig.webisteAllConfig(admin);
		String remarks = "";
		if(null!=admin.getLuckyFlag()) {
			String type = "启用了";
			if(admin.getLuckyFlag()==0) {
				type  = "禁用了";
			}
			remarks = type+"幸运大转盘抽奖功能!";
		}else if(null != admin.getRechargeMoney()) {
			remarks ="修改了幸运转盘抽奖需要最低充值金额："+admin.getRechargeMoney()+"!";
		}else if(null != admin.getReturnMoney()) {
			remarks ="修改了幸运转盘抽奖充值金额达到多少后,增加摇奖次数："+admin.getReturnMoney()+"次!";
		}else if(null != admin.getLuckyTitle()) {
			remarks ="修改了幸运转盘抽奖页面标题："+admin.getLuckyTitle()+"!";
		}else if(null != admin.getDluckCount()) {
			remarks ="修改了幸运转盘抽奖充值金额达到多少后,增加摇奖次数："+admin.getDluckCount()+"次!";
		}else if(null != admin.getDluckFlag()) {
			String type = "启用了";
			if(admin.getDluckFlag()==0) {
				type  = "禁用了";
			}
			remarks = type+"当打码量达到多少后增加幸运大转盘抽奖次数功能!";
		}
		AdminUser admins = (AdminUser) session.getAttribute("admin1");
		operationlogService.addOperationlog(admins, remarks, "平台基本管理 ");
		return new JsonResult("success",line);
	}
	
	/**
	 * 
	 * ----每日签到配置
	 * 
	 */
	
	/**
	 * 方法名：signInflag 
	 * 描述：    每日签到配置                   
	 * 参数：    @param admin
	 * 参数：    @return 
	 * @return: JsonResult
	 */
	@ResponseBody
	@RequestMapping("/signInflag")
	public JsonResult signInflag(HttpSession session,Admin admin) {
		Integer line = systemConfigService.updateAllConfig(admin);
		WebsiteStateConfig.webisteAllConfig(admin);
		String remarks = "修改了用户幸运签到功能的配置信息!";
		AdminUser admins = (AdminUser) session.getAttribute("admin1");
		operationlogService.addOperationlog(admins, remarks, "平台基本管理 ");
		return new JsonResult("success",line);
	}
	
	
	/**
	 * 
	 * ---系统红包设置
	 * 
	 */
	
	/**
	 * 方法名：systemEnvelope 
	 * 描述：    领取系统红包所需的条件配置                   
	 * 参数：    @param admin 配置信息
	 * 参数：    @return 
	 * @return: JsonResult
	 */
	@ResponseBody
	@RequestMapping("/systemEnvelope")
	public JsonResult systemEnvelope(HttpSession session,Admin admin) {
		Integer line = systemConfigService.updateAllConfig(admin);
		WebsiteStateConfig.webisteAllConfig(admin);
		String remarks = "修改了用户领取系统红包功能的配置信息!";
		AdminUser admins = (AdminUser) session.getAttribute("admin1");
		operationlogService.addOperationlog(admins, remarks, "平台基本管理 ");
		return new JsonResult("success",line);
	}

	/**
	 * 方法名：messageFlag 
	 * 描述：     充值提款信息 聊天室显示开关                  
	 * 参数：    @param state 修改状态 1是开启 0是关闭
	 * 参数：    @return 
	 * @return: JsonResult
	 */
	@RequestMapping("/messageFlag")
	@ResponseBody
	public JsonResult messageFlag(Integer state) {
		Admin admin = new Admin();
		admin.setMessageFlag(state);
		WebsiteStateConfig.webisteAllConfig(admin);
		return new JsonResult("success",systemConfigService.updateAllConfig(admin));
	}
	
	
	
	/**
	 * 
	 *---提款配置 
	 * 
	 */
	

	/**
	 * 方法名：startHandleTime 
	 * 描述：     后台处理提款、入款开始时间                  
	 * 参数：    @param startHandleTime 开始时间
	 * 参数：    @return 
	 * @return: JsonResult
	 */
	@RequestMapping("/startHandleTime")
	@ResponseBody
	public JsonResult startHandleTime(HttpSession session,String startHandleTime) {
		Admin admin = new Admin();
		admin.setStratchulitime(startHandleTime);
		Integer line = systemConfigService.updateAllConfig(admin);
		WebsiteStateConfig.webisteAllConfig(admin);
		String remarks = "修改了用户提款功能的配置信息!";
		AdminUser admins = (AdminUser) session.getAttribute("admin1");
		operationlogService.addOperationlog(admins, remarks, "平台基本管理 ");
		return new JsonResult("success",line);
	}

	/**
	 * 方法名：endHandleTime 
	 * 描述：     后台处理提款、入款结束时间                  
	 * 参数：    @param endHandleTime 结束时间
	 * 参数：    @return 
	 * @return: JsonResult
	 */
	@RequestMapping("/endHandleTime")
	@ResponseBody
	public JsonResult endHandleTime(HttpSession session,String endHandleTime) {
		Admin admin = new Admin();
		admin.setEndchulitime(endHandleTime);
		Integer line = systemConfigService.updateAllConfig(admin);
		WebsiteStateConfig.webisteAllConfig(admin);
		String remarks = "修改了用户提款功能的配置信息!";
		AdminUser admins = (AdminUser) session.getAttribute("admin1");
		operationlogService.addOperationlog(admins, remarks, "平台基本管理 ");
		return new JsonResult("success",line);
	}

	/**
	 * 方法名：minAmount 
	 * 描述：    提款最小金额配置                   
	 * 参数：    @param minAmount 最小金额
	 * 参数：    @return 
	 * @return: JsonResult
	 */
	@RequestMapping("/minAmount")
	@ResponseBody
	public JsonResult minAmount(HttpSession session,Double minAmount) {
		Admin admin = new Admin();
		admin.setMintikuanjine(minAmount);
		Integer line = systemConfigService.updateAllConfig(admin);
		WebsiteStateConfig.webisteAllConfig(admin);
		String remarks = "修改了用户提款功能的配置信息!";
		AdminUser admins = (AdminUser) session.getAttribute("admin1");
		operationlogService.addOperationlog(admins, remarks, "平台基本管理 ");
		return new JsonResult("success",line);
	}

	/**
	 * 方法名：maxAmount 
	 * 描述：     提款最大金额配置                  
	 * 参数：    @param maxAmount 最大金额
	 * 参数：    @return 
	 * @return: JsonResult
	 */
	@RequestMapping("/maxAmount")
	@ResponseBody
	public JsonResult maxAmount(HttpSession session,Double maxAmount) {
		Admin admin = new Admin();
		admin.setMaxtikuanjine(maxAmount);
		Integer line = systemConfigService.updateAllConfig(admin);
		WebsiteStateConfig.webisteAllConfig(admin);
		String remarks = "修改了用户提款功能的配置信息!";
		AdminUser admins = (AdminUser) session.getAttribute("admin1");
		operationlogService.addOperationlog(admins, remarks, "平台基本管理 ");
		return new JsonResult("success",line);
	}

	/**
	 * 方法名：withdrawalCountDay 
	 * 描述：    每日免费提款次数                   
	 * 参数：    @param withdrawalCountDay 免费次数
	 * 参数：    @return 
	 * @return: JsonResult
	 */
	@RequestMapping("/withdrawalCountDay")
	@ResponseBody
	public JsonResult withdrawalCountDay(HttpSession session,Integer withdrawalCountDay) {
		Admin admin = new Admin();
		admin.setMeiritikuancount(withdrawalCountDay);
		Integer line = systemConfigService.updateAllConfig(admin);
		WebsiteStateConfig.webisteAllConfig(admin);
		String remarks = "修改了用户提款功能的配置信息!";
		AdminUser admins = (AdminUser) session.getAttribute("admin1");
		operationlogService.addOperationlog(admins, remarks, "平台基本管理 ");
		return new JsonResult("success",line);
	}

	/**
	 * 方法名：isSuccessCount 
	 * 描述：     提款是否只记录成功次数                  
	 * 参数：    @param successCount 配置信息 1是  0否
	 * 参数：    @return 
	 * @return: JsonResult
	 */
	@RequestMapping("/successCount")
	@ResponseBody
	public JsonResult isSuccessCount(HttpSession session,Integer successCount) {
		Admin admin = new Admin();
		admin.setTikuanshifousuccess(successCount);
		Integer line = systemConfigService.updateAllConfig(admin);
		WebsiteStateConfig.webisteAllConfig(admin);
		String remarks = "修改了用户提款功能的配置信息!";
		AdminUser admins = (AdminUser) session.getAttribute("admin1");
		operationlogService.addOperationlog(admins, remarks, "平台基本管理 ");
		return new JsonResult("success",line);
	}

	/**
	 * 方法名：updateDrawing 
	 * 描述：    提款所需--手续费配置                   
	 * 参数：    @param admin 配置信息
	 * 参数：    @return 
	 * @return: JsonResult
	 */
	@ResponseBody
	@RequestMapping("/updateDrawingSteup")
	public JsonResult updateDrawing(HttpSession session,Admin admin) {
		Integer line = systemConfigService.updateAllConfig(admin);
		WebsiteStateConfig.webisteAllConfig(admin);
		String remarks = "修改了用户提款功能的配置信息!";
		AdminUser admins = (AdminUser) session.getAttribute("admin1");
		operationlogService.addOperationlog(admins, remarks, "平台基本管理 ");
		return new JsonResult("success",line);
	}
	
	/**
	 * 
	 *----存款配置 
	 * 
	 */
	
	/**
	 * 方法名：fastDeposit 
	 * 描述：     人工存款开关                  
	 * 参数：    @param fastDeposit 开启状态 1开启 0关闭
	 * 参数：    @return 
	 * @return: JsonResult
	 */
	@RequestMapping("/fastDeposit")
	@ResponseBody
	public JsonResult fastDeposit(HttpSession session,Integer fastDeposit) {
		Admin admin = new Admin();
		admin.setKuaisucunkuanflag(fastDeposit);
		Integer line = systemConfigService.updateAllConfig(admin);
		WebsiteStateConfig.webisteAllConfig(admin);
		String remarks = "修改了用户存款功能的配置信息!";
		AdminUser admins = (AdminUser) session.getAttribute("admin1");
		operationlogService.addOperationlog(admins, remarks, "平台基本管理 ");
		return new JsonResult("success",line);
	}

	/**
	 * 方法名：thirdPartyDeposit 
	 * 描述：     第三方存款开关                  
	 * 参数：    @param depositSwitch 开启状态 1开启 0关闭
	 * 参数：    @return 
	 * @return: JsonResult
	 */
	@RequestMapping("/depositSwitch")
	@ResponseBody
	public JsonResult thirdPartyDeposit(HttpSession session,Integer depositSwitch) {
		Admin admin = new Admin();
		admin.setDisanfangcunkuanflag(depositSwitch);
		Integer line = systemConfigService.updateAllConfig(admin);
		WebsiteStateConfig.webisteAllConfig(admin);
		String remarks = "修改了用户存款功能的配置信息!";
		AdminUser admins = (AdminUser) session.getAttribute("admin1");
		operationlogService.addOperationlog(admins, remarks, "平台基本管理 ");
		return new JsonResult("success",line);
	}

	/**
	 * 方法名：fastDepositExplain 
	 * 描述：     人工存款说明                  
	 * 参数：    @param fastDepositExplain 存款说明
	 * 参数：    @return 
	 * @return: JsonResult
	 */
	@RequestMapping("/fastDepositExplain")
	@ResponseBody
	public JsonResult fastDepositExplain(HttpSession session,String fastDepositExplain) {
		Admin admin = new Admin();
		admin.setKuaisucunkuannote(fastDepositExplain);
		Integer line = systemConfigService.updateAllConfig(admin);
		WebsiteStateConfig.webisteAllConfig(admin);
		String remarks = "修改了用户存款功能的配置信息!";
		AdminUser admins = (AdminUser) session.getAttribute("admin1");
		operationlogService.addOperationlog(admins, remarks, "平台基本管理 ");
		return new JsonResult("success",line);
	}

	/**
	 * 方法名：thirdDepositExplain 
	 * 描述：    第三方存款说明                   
	 * 参数：    @param thirdDepositExplain 存款说明
	 * 参数：    @return 
	 * @return: JsonResult
	 */
	@RequestMapping("/thirdDepositExplain")
	@ResponseBody
	public JsonResult thirdDepositExplain(HttpSession session,String thirdDepositExplain) {
		Admin admin = new Admin();
		admin.setDisanfangcunkuannote(thirdDepositExplain);
		Integer line = systemConfigService.updateAllConfig(admin);
		WebsiteStateConfig.webisteAllConfig(admin);
		String remarks = "修改了用户存款功能的配置信息!";
		AdminUser admins = (AdminUser) session.getAttribute("admin1");
		operationlogService.addOperationlog(admins, remarks, "平台基本管理 ");
		return new JsonResult("success",line);
	}
	
	/**
	 * 
	 *----在线客服配置 
	 * 
	 */
	
	/**
	 * 方法名：officeHours 
	 * 描述：     客服上班时间配置                  
	 * 参数：    @param officeHours 上班时间
	 * 参数：    @return 
	 * @return: JsonResult
	 */
	@RequestMapping("/officeHours")
	@ResponseBody
	public JsonResult officeHours(HttpSession session,String officeHours) {
		Admin admin = new Admin();
		admin.setKefusbtime(officeHours);
		Integer line = systemConfigService.updateAllConfig(admin);
		WebsiteStateConfig.webisteAllConfig(admin);
		String remarks = "修改了在线客服功能的配置信息!";
		AdminUser admins = (AdminUser) session.getAttribute("admin1");
		operationlogService.addOperationlog(admins, remarks, "平台基本管理 ");
		return new JsonResult("success",line);
	}

	/**
	 * 方法名：offHours 
	 * 描述：     客服下班时间配置                  
	 * 参数：    @param offHours 下班时间
	 * 参数：    @return 
	 * @return: JsonResult
	 */
	@RequestMapping("/offHours")
	@ResponseBody
	public JsonResult offHours(HttpSession session,String offHours) {
		Admin admin = new Admin();
		admin.setKefuxbtime(offHours);
		Integer line = systemConfigService.updateAllConfig(admin);
		WebsiteStateConfig.webisteAllConfig(admin);
		String remarks = "修改了在线客服功能的配置信息!";
		AdminUser admins = (AdminUser) session.getAttribute("admin1");
		operationlogService.addOperationlog(admins, remarks, "平台基本管理 ");
		return new JsonResult("success",line);
	}
	
	
	/**
	 * 
	 *----彩票配置 
	 * 
	 */
	
	/**
	 * 方法名：lotteryRatio 
	 * 描述：     系统彩开奖中奖比率                 
	 * 参数：    @param lotteryRatio 中奖比率
	 * 参数：    @return 
	 * @return: JsonResult
	 */
	@RequestMapping("/lotteryRatio")
	@ResponseBody
	public JsonResult lotteryRatio(HttpSession session,String lotteryRatio) {
		Admin admin = new Admin();
		admin.setXitongcaizjratio(lotteryRatio);
		Integer line = systemConfigService.updateAllConfig(admin);
		WebsiteStateConfig.webisteAllConfig(admin);
		String remarks = "修改了彩票功能的配置信息!";
		AdminUser admins = (AdminUser) session.getAttribute("admin1");
		operationlogService.addOperationlog(admins, remarks, "平台基本管理 ");
		return new JsonResult("success",line);
	}

	
	/**
	 * 
	 * ----试玩站点配置
	 * 
	 */
	

	/**
	 * 方法名：RegisterInitialAmount 
	 * 描述：     注册会员初始金额配置                    
	 * 参数：    @param registerInitialAmount 初始金额
	 * 参数：    @return 
	 * @return: JsonResult
	 */
	@RequestMapping("/registerInitialAmount")
	@ResponseBody
	public JsonResult RegisterInitialAmount(HttpSession session,Double registerInitialAmount) {
		Admin admin = new Admin();
		admin.setHuiyuanchushijine(registerInitialAmount);
		Integer line = systemConfigService.updateAllConfig(admin);
		WebsiteStateConfig.webisteAllConfig(admin);
		String remarks = "修改了试玩功能的配置信息!";
		AdminUser admins = (AdminUser) session.getAttribute("admin1");
		operationlogService.addOperationlog(admins, remarks, "平台基本管理 ");
		return new JsonResult("success",line);
	}

	/**
	 * 方法名：demoAccount 
	 * 描述：    注册试玩账号开启配置                   
	 * 参数：    @param demoAccount 开启状态 1开启 0关闭
	 * 参数：    @return 
	 * @return: JsonResult
	 */
	@RequestMapping("/demoAccount")
	@ResponseBody
	public JsonResult demoAccount(HttpSession session,Integer demoAccount) {
		Admin admin = new Admin();
		admin.setShiwanzhucekaiqi(demoAccount);
		Integer line = systemConfigService.updateAllConfig(admin);
		WebsiteStateConfig.webisteAllConfig(admin);
		String remarks = "修改了试玩功能的配置信息!";
		AdminUser admins = (AdminUser) session.getAttribute("admin1");
		operationlogService.addOperationlog(admins, remarks, "平台基本管理 ");
		return new JsonResult("success",line);
	}

	/**
	 * 方法名：demoInitialAmount 
	 * 描述：     玩账号初始金额配置                  
	 * 参数：    @param demoInitialAmount 初始金额
	 * 参数：    @return 
	 * @return: JsonResult
	 */
	@RequestMapping("/demoInitialAmount")
	@ResponseBody
	public JsonResult demoInitialAmount(HttpSession session,Double demoInitialAmount) {
		Admin admin = new Admin();
		admin.setShiwanchushijine(demoInitialAmount);
		Integer line = systemConfigService.updateAllConfig(admin);
		WebsiteStateConfig.webisteAllConfig(admin);
		String remarks = "修改了试玩功能的配置信息!";
		AdminUser admins = (AdminUser) session.getAttribute("admin1");
		operationlogService.addOperationlog(admins, remarks, "平台基本管理 ");
		return new JsonResult("success",line);
	}
	
	/**
	 * 
	 * ----TODO：在线入款管理 
	 * 
	 */
	
	/**
	 * 方法名：onlinePaymentPage 
	 * 描述：    在线入款管理页面                  
	 * 参数：    @return 
	 * @return: String
	 */
	@RequestMapping("/onlinePaymentPage")
	public String onlinePaymentPage() {
		return "htgl/wangzhanrukuan";
	}
	
	/**
	 * 方法名：getRecharge 
	 * 描述：     查询在线充值接口信息                 
	 * 参数：    @return 
	 * @return: JsonResult
	 */
	@ResponseBody
	@RequestMapping("/getRecharge")
	public JsonResult getRecharge() {
		return new JsonResult("success",rechargeInterfaceService.getRecharge());
	}
	
	/**
	 * 方法名：insertRecharge 
	 * 描述：     添加在线接口信息                 
	 * 参数：    @param recharge 接口配置
	 * 参数：    @param session
	 * 参数：    @return 
	 * @return: JsonResult
	 */
	@ResponseBody
	@RequestMapping("/insertRecharge")
	public JsonResult insertRecharge(RechargeInterface recharge,HttpSession session) {
		AdminUser admin = (AdminUser) session.getAttribute("admin1");
		recharge.setCreateTime(DateUtil.getCurrTime());
		recharge.setUpdateName(admin.getName());
		String remarks = "添加了名称为："+recharge.getPayName()+"的在线支付接口!";
		AdminUser admins = (AdminUser) session.getAttribute("admin1");
		operationlogService.addOperationlog(admins, remarks, "在线入款管理 ");
		return new JsonResult("success",rechargeInterfaceService.insertRecharge(recharge));
	}
	
	/**
	 * 方法名：updateRecharge 
	 * 描述：    修改在线接口信息                  
	 * 参数：    @param recharge 接口配置
	 * 参数：    @param session
	 * 参数：    @return 
	 * @return: JsonResult
	 */
	@ResponseBody
	@RequestMapping("/updateRecharge")
	public JsonResult updateRecharge(RechargeInterface recharge,HttpSession session) {
		AdminUser admin = (AdminUser) session.getAttribute("admin1");
		recharge.setCreateTime(DateUtil.getCurrTime());
		recharge.setUpdateName(admin.getName());
		String remarks = "修改了名称为："+recharge.getPayName()+"的在线支付接口!";
		AdminUser admins = (AdminUser) session.getAttribute("admin1");
		operationlogService.addOperationlog(admins, remarks, "在线入款管理 ");
		return new JsonResult("",rechargeInterfaceService.updateRecharge(recharge));
	}
	
	
	/**
	 * 
	 * ----TODO：入款银行管理 
	 * 
	 */
	
	
	/**
	 * 方法名：bankOfdepositPage 
	 * 描述：    入款银行管理页面                 
	 * 参数：    @return 
	 * @return: String
	 */
	@RequestMapping("/bankOfdepositPage")
	public String bankOfdepositPage() {
		return "/htgl/bankitemcontrol";
	}

	/**
	 * 方法名：findBankOfdeposit 
	 * 描述：    查询所有的入款银行                  
	 * 参数：    @return 
	 * @return: JsonResult
	 */
	@ResponseBody
	@RequestMapping("/findBankOfdeposit")
	public JsonResult findBankOfdeposit() {
		return new JsonResult("success", depositBankService.getAllDepositBank());
	}
	
	/**
	 * 方法名：addBankOfdeposit 
	 * 描述：     添加入款银行卡                 
	 * 参数：    @param bank 修改信息
	 * 参数：    @param session
	 * 参数：    @return 
	 * @return: JsonResult
	 */
	@ResponseBody
	@RequestMapping("/addBankOfdeposit")
	public JsonResult addBankOfdeposit(DepositBank bank, HttpSession session) {
		AdminUser admin1 = (AdminUser) session.getAttribute("admin1");
		bank.setOperationName(admin1.getName());
		bank.setCreateTime(DateUtil.getCurrTime());
		String remarks = "添加了收款账号为："+bank.getAcountName()+",入款银行为："+bank.getBankName()+"的入款信息!";
		AdminUser admins = (AdminUser) session.getAttribute("admin1");
		operationlogService.addOperationlog(admins, remarks, "入款银行管理 ");
		return new JsonResult("success", depositBankService.addDepositInfo(bank));
	}

	/**
	 * 方法名：updateBankOfdeposit 
	 * 描述：   修改入款银行卡                   
	 * 参数：    @param bank 修改信息
	 * 参数：    @param session
	 * 参数：    @return 
	 * @return: JsonResult
	 */
	@ResponseBody
	@RequestMapping("/updateBankOfdeposit")
	public JsonResult updateBankOfdeposit(DepositBank bank, HttpSession session) {
		AdminUser admin1 = (AdminUser) session.getAttribute("admin1");
		bank.setOperationName(admin1.getName());
		bank.setCreateTime(DateUtil.getCurrTime());
		String remarks = "修改了收款账号为："+bank.getAcountName()+",入款银行为："+bank.getBankName()+"的入款信息!";
		AdminUser admins = (AdminUser) session.getAttribute("admin1");
		operationlogService.addOperationlog(admins, remarks, "入款银行管理 ");
		return new JsonResult("success", depositBankService.updateDepositInfo(bank));
	}

	/**
	 * 方法名：deleteBankOfdeposit 
	 * 描述：    删除入款银行卡                  
	 * 参数：    @param id 删除的id 
	 * 参数：    @return 
	 * @return: JsonResult
	 */
	@ResponseBody
	@RequestMapping("/deleteBankOfdeposit")
	public JsonResult deleteBankOfdeposit(HttpSession session,Integer id) {
		String remarks = "删除了入款id编号为："+id+"的入款信息!";
		AdminUser admins = (AdminUser) session.getAttribute("admin1");
		operationlogService.addOperationlog(admins, remarks, "入款银行管理 ");
		return new JsonResult("success", depositBankService.delDepositInfo(id));
	}
	

	/**
	 * 
	 * ----TODO：扫码支付管理 
	 * 
	 */
	
	
	/**
	 * 方法名：sweepCodePaymentPage 
	 * 描述：    扫码支付管理页面                  
	 * 参数：    @return 
	 * @return: String
	 */
	@RequestMapping("/sweepCodePaymentPage")
	public String sweepCodePaymentPage() {
		return "htgl/Scavengingpayment";
	}
	
	/**
	 * 方法名：findSweepCodePayment 
	 * 描述：    查询扫码支付接口                  
	 * 参数：    @return 
	 * @return: JsonResult
	 */
	@ResponseBody
	@RequestMapping("/findSweepCodePayment")
	public JsonResult findSweepCodePayment() {
		return new JsonResult("success",addPaymentService.QueryPaymentInformation());
	}
	
	/**
	 * 方法名：addSweepCodePayment 
	 * 描述：    添加扫码支付接口                  
	 * 参数：    @param Payment 接口信息
	 * 参数：    @param file
	 * 参数：    @param session
	 * 参数：    @param req
	 * 参数：    @return 
	 * @return: String
	 */
	@RequestMapping("/addSweepCodePayment")
	public String addSweepCodePayment(HttpSession session,MultipartFile file, ScavengingPayment payment,HttpServletRequest req) {
		AdminUser admin = (AdminUser) session.getAttribute("admin1");
		if (file.getOriginalFilename() != "") {
			String path = "d:/cp/ScavengingPayment/";
			UploadUtil uploadUitl = new UploadUtil();
			String name1 = file.getOriginalFilename();
			String[] name2 = name1.split("\\.");
			String name3 = "" + System.currentTimeMillis();
			String name4 = name3 + "." + name2[1];
			payment.setPictureAddress("ScavengingPayment/" + uploadUitl.upload(file, req, name4, path));
		}
		payment.setCreated_user(admin.getName());
		payment.setCreated_date(DateUtil.getCurrTime());
		addPaymentService.AddPayment(payment);
		String remarks = "添加了支付名称为："+payment.getName()+",支付类型为："+payment.getPaymentType()+"的扫码支付接口!";
		AdminUser admins = (AdminUser) session.getAttribute("admin1");
		operationlogService.addOperationlog(admins, remarks, "扫码支付管理");
		return "htgl/Scavengingpayment";
	}

	/**
	 * 方法名：updateSweepCodePayment 
	 * 描述：    修改扫码支付接口信息                  
	 * 参数：    @param Payment 接口信息
	 * 参数：    @param file
	 * 参数：    @param req
	 * 参数：    @return 
	 * @return: String
	 */
	@RequestMapping("/updateSweepCodePayment")
	public String updateSweepCodePayment(HttpSession session,MultipartFile file, ScavengingPayment payment,HttpServletRequest req) {
		if (file.getOriginalFilename() != "") {
			String path = "d:/cp/ScavengingPayment/";
			UploadUtil uploadUitl = new UploadUtil();
			String name1 = file.getOriginalFilename();
			String[] name2 = name1.split("\\.");
			String name3 = UUID.randomUUID().toString().replaceAll("-", "").substring(23).toUpperCase()
					+ System.currentTimeMillis();
			String name4 = name3 + "." + name2[1];
			payment.setPictureAddress("ScavengingPayment/" + uploadUitl.upload(file, req, name4, path));
		}
		addPaymentService.modifyPaymentInterface(payment);
		String remarks = "修改了支付名称为："+payment.getName()+"的扫码支付接口信息!";
		AdminUser admins = (AdminUser) session.getAttribute("admin1");
		operationlogService.addOperationlog(admins, remarks, "扫码支付管理");
		return "htgl/Scavengingpayment";
	}
	
	/**
	 * 方法名：updateSweepCodePaymentState 
	 * 描述：     禁用或启用扫码支付                 
	 * 参数：    @param id 修改id
	 * 参数：    @param state 修改状态
	 * 参数：    @return 
	 * @return: JsonResult
	 */
	@ResponseBody
	@RequestMapping("/updateSweepCodePaymentState")
	public JsonResult updateSweepCodePaymentState(HttpSession session,Integer id,Integer state) {
		if(id == null || state == null) {
			return new JsonResult("请填写支付完整信息","请填写支付完整信息");
		}
		String type = "禁用了";
		if(state==1){
			type = "启用了";
		}
		String remarks = type+"编号id为："+id+"的扫码支付接口信息!";
		AdminUser admins = (AdminUser) session.getAttribute("admin1");
		operationlogService.addOperationlog(admins, remarks, "扫码支付管理");
		return new JsonResult("success",addPaymentService.state(id,state));
	}
	
	/**
	 * 方法名：deleteSweepCodePayment 
	 * 描述：    删除扫码支付接口                  
	 * 参数：    @param payment 接口信息
	 * 参数：    @return 
	 * @return: JsonResult
	 */
	@ResponseBody
	@RequestMapping("/deleteSweepCodePayment")
	public JsonResult deleteSweepCodePayment(HttpSession session,ScavengingPayment payment) {
		String remarks = "删除了编号id为："+payment.getId()+"的扫码支付接口信息!";
		AdminUser admins = (AdminUser) session.getAttribute("admin1");
		operationlogService.addOperationlog(admins, remarks, "扫码支付管理");
		return new JsonResult("success",addPaymentService.deletingPayment(payment));
	}
	
	/**
	 * 
	 * ----TODO：推广链接管理 
	 * 
	 */
	

	/**
	 * 方法名：promotionLinksPage 
	 * 描述：   推广链接管理页面                   
	 * 参数：    @return 
	 * @return: String
	 */
	@RequestMapping("/promotionLinksPage")
	public String promotionLinksPage() {
		return "htgl/tuiguanglianjie";
	}

	/**
	 * 方法名：findAgentUserList 
	 * 描述：     查询所有的推广链接                
	 * 参数：    @return 
	 * @return: JsonResult
	 */
	@RequestMapping("/findAgentUserList")
	@ResponseBody
	public JsonResult findAgentUserList() {
		return new JsonResult("success",liushuiService.findAgentUserList());
	}
	
	/**
	 * 方法名：termAgentList 
	 * 描述：    根据条件查询推广链接                  
	 * 参数：    @param user
	 * 参数：    @return 
	 * @return: JsonResult
	 */
	@RequestMapping("/findTermAgentList")
	@ResponseBody
	public JsonResult termAgentList(User user) {
		return new JsonResult("success",liushuiService.findTermAgentList(user));
	}
	
	/**
	 * 
	 * ----TODO：绑定域名管理 
	 * 
	 */
	
	/**
	 * 方法名：bindDomainNamePage 
	 * 描述：     绑定域名管理页面                 
	 * 参数：    @return 
	 * @return: String
	 */
	@RequestMapping("/bindDomainNamePage")
	public String bindDomainNamePage() {
		return "htgl/bangdingyuming";
	}
	

	/**
	 * 方法名：findParkedDomainsList 
	 * 描述：    查询所有的绑定域名           
	 * 参数：    @return 
	 * @return: JsonResult
	 */
	@RequestMapping("/findParkedDomainsList")
	@ResponseBody
	public JsonResult findParkedDomainsList(String domain,String agency) {
		List<ParkedDomains> domains = systemConfigService.findAllParkedDomains(null, domain, agency);
		return new JsonResult(domains.size() > 0 ? "查询绑定代理成功" : "未查到相关数据", domains);
	}
     
	/**
	 * 方法名：findByStateGeneralAgentList 
	 * 描述：     查询可以绑定域名的总代理                 
	 * 参数：    @return 
	 * @return: JsonResult
	 */
	@RequestMapping("/findByStateGeneralAgentList")
	@ResponseBody
	public JsonResult findByStateGeneralAgentList() {
		List<String> agentName = systemConfigService.findByStateGeneralAgentList(); 
		return new JsonResult(agentName.size() == 0 ? "没有可添加的代理，请添加总代理后再为其添加域名！" : "可以为代理指定域名！", agentName);
	}
	
	/**
	 * 方法名：addDomain 
	 * 描述：    添加域名绑定的代理                  
	 * 参数：    @param domain
	 * 参数：    @return 
	 * @return: JsonResult
	 */
	@RequestMapping("/addDomain")
	@ResponseBody
	public JsonResult addDomain(HttpSession session,ParkedDomains domain) {
		Integer affectRow = systemConfigService.insertParkedDomains(domain);
		String str = "添加域名失败";
		if (affectRow == -1)
			str = "已有当前域名,请勿重复添加!";
		if (affectRow == 1)
			str = "添加数据成功";
		String remarks = "绑定了总代理："+domain.getDefaultAgency()+"的新域名："+domain.getDomain()+"!";
		AdminUser admins = (AdminUser) session.getAttribute("admin1");
		operationlogService.addOperationlog(admins, remarks, "绑定域名管理");
		return new JsonResult(str, affectRow);
	}
	
	/**
	 * 方法名：editDomain 
	 * 描述：     后台修改域名                 
	 * 参数：    @param parkedDomains
	 * 参数：    @param session
	 * 参数：    @return 
	 * @return: JsonResult
	 */
	@RequestMapping("/editDomain")
	@ResponseBody
	public JsonResult editDomain(ParkedDomains parkedDomains,HttpSession session) {
		AdminUser admin1 = (AdminUser) session.getAttribute("admin1");
		parkedDomains.setCreated_user(admin1.getName());
		Integer affectRow = systemConfigService.updateDomain(parkedDomains);
		String str = "修改失败";
		if (affectRow == -1)
			str = "该域名已存在";
		if (affectRow == 1)
			str = "修改成功";
		String remarks = "修改了id为："+parkedDomains.getId()+"的绑定域名!";
		AdminUser admins = (AdminUser) session.getAttribute("admin1");
		operationlogService.addOperationlog(admins, remarks, "绑定域名管理");
		return new JsonResult(str, affectRow);
	}

	/**
	 * 方法名：editDomainStatus 
	 * 描述：    后台修改域名状态                  
	 * 参数：    @param id
	 * 参数：    @param status
	 * 参数：    @return 
	 * @return: JsonResult
	 */
	@RequestMapping("/editDomainStatus")
	@ResponseBody
	public JsonResult editDomainStatus(HttpSession session,Integer id, Integer status) {
		Integer affectRow = systemConfigService.updateDomainStatus(id, status);
		String state = "启用了";
		if(status==1) {
			state = "禁用了";
		}
		String remarks = state+"id为："+id+"的绑定域名!";
		AdminUser admins = (AdminUser) session.getAttribute("admin1");
		operationlogService.addOperationlog(admins, remarks, "绑定域名管理");
		return new JsonResult("修改域名状态" + (affectRow == 1 ? "成功" : "失败"), affectRow);
	}

	/**
	 * 方法名：deleteDomain 
	 * 描述：    删除绑定的域名                  
	 * 参数：    @param id
	 * 参数：    @return 
	 * @return: JsonResult
	 */
	@RequestMapping("/deleteDomain")
	@ResponseBody
	public JsonResult deleteDomain(HttpSession session,Integer id) {
		Integer affectRow = 0;
		try {
			affectRow = systemConfigService.deleteDomain(id);
		} catch (Exception e) {
			return new JsonResult(e.getMessage(), affectRow);
		}
		String remarks = "删除了编号id为："+id+"的绑定域名!";
		AdminUser admins = (AdminUser) session.getAttribute("admin1");
		operationlogService.addOperationlog(admins, remarks, "绑定域名管理");
		return new JsonResult("删除绑定域名成功", affectRow);
	}
	
	
	/**
	 * 
	 * ----TODO：下载页面管理 
	 * 
	 */
	
	/**
	 * 方法名：websiteAppPage 
	 * 描述：    下载页面管理页面                   
	 * 参数：    @param model
	 * 参数：    @return 
	 * @return: ModelAndView
	 */
	@RequestMapping("/websiteAppPage")
	public ModelAndView websiteAppPage(ModelAndView model) {
		model.setViewName("htgl/websiteApp"); 
		model.addObject("app", adminService.findAppImgPath());
		return model;
	}
	
	/**
	 * 方法名：findAppDownloadInfo 
	 * 描述：    app下载页面信息                  
	 * 参数：    @return 
	 * @return: JsonResult
	 */
	@RequestMapping("/findAppDownloadInfo")
	@ResponseBody
	public JsonResult findAppDownloadInfo() {
		return new JsonResult("", adminService.findAppImgPath());
	}
	
	/**
	 * 方法名：updateAppDownloadSetup 
	 * 描述：     修改App下载信息                 
	 * 参数：    @param model
	 * 参数：    @param ids
	 * 参数：    @param ios_path
	 * 参数：    @param app_path
	 * 参数：    @param content
	 * 参数：    @return 
	 * @return: ModelAndView
	 */
	@RequestMapping("/updateAppDownloadSetup")
	public ModelAndView updateAppDownloadSetup(HttpSession session,ModelAndView model, Integer ids, String ios_path, HttpServletRequest request,
			MultipartFile file1, MultipartFile file2, MultipartFile file3, MultipartFile file4, MultipartFile file5,
			MultipartFile file6,MultipartFile file7,MultipartFile file8,MultipartFile file9,MultipartFile file10, String app_path,String content) {
		model.setViewName("htgl/websiteApp");
		UploadUtil uploadUtil = new UploadUtil();
		String path = "d:/cp/app";
		String img = "app/";
		String fNames1 = "";
		String fNames2 = "";
		String fNames3 = "";
		String fNames4 = "";
		String fNames5 = "";
		String fNames6 = "";
		String fNames7 = "";
		String fNames8 = "";
		String fNames9 = "";
		String fNames10 = "";
		if(file1!=null) {
			if (!"".equals(file1.getOriginalFilename())) {
				String[] names12 = file1.getOriginalFilename().split("\\.");
				String names14 = "sy1_1" + "." + names12[1];
				fNames1 = img + uploadUtil.upload(file1, request, names14, path);
			}
		}
		if(file2!=null) {
			if (!"".equals(file2.getOriginalFilename())) {
				String[] names22 = file2.getOriginalFilename().split("\\.");
				String names24 = "sy2_1" + "." + names22[1];
				fNames2 = img + uploadUtil.upload(file2, request, names24, path);
			}
		}
		if(file3!=null) {
			if (!"".equals(file3.getOriginalFilename())) {
				String[] names32 = file3.getOriginalFilename().split("\\.");
				String names34 = "sy3_1" + "." + names32[1];
				fNames3 = img + uploadUtil.upload(file3, request, names34, path);
			}
		}

		if(file4!=null) {
			if (!"".equals(file4.getOriginalFilename())) {
				String[] names42 = file4.getOriginalFilename().split("\\.");
				String names44 = "sy4_1" + "." + names42[1];
				fNames4 = img + uploadUtil.upload(file4, request, names44, path);
			}
		}
		if(file5!=null) {
			if (!"".equals(file5.getOriginalFilename())) {
				String[] names52 = file5.getOriginalFilename().split("\\.");
				String names54 = "sy5_1" + "." + names52[1];
				fNames5 = img + uploadUtil.upload(file5, request, names54, path);
			}
		}
		if(file6!=null) {
			if (!"".equals(file6.getOriginalFilename())) {
				String[] names62 = file6.getOriginalFilename().split("\\.");
				String names64 = "android_img" + "." + names62[1];
				fNames6 = img + uploadUtil.upload(file6, request, names64, path);
			}
		}
		if(file7!=null) {
			if (!"".equals(file7.getOriginalFilename())) {
				String[] names72 = file7.getOriginalFilename().split("\\.");
				String names74 = "ios_img" + "." + names72[1];
				fNames7 = img + uploadUtil.upload(file7, request, names74, path);
			}
		}
		if(file8!=null) {
			if (!"".equals(file8.getOriginalFilename())) {
				String[] names82 = file8.getOriginalFilename().split("\\.");
				String names84 = "pc_img" + "." + names82[1];
				fNames8 = img + uploadUtil.upload(file8, request, names84, path);
			}
		}
		if(file9!=null) {
			if (!"".equals(file9.getOriginalFilename())) {
				String[] names92 = file9.getOriginalFilename().split("\\.");
				String names94 = "gc_img" + "." + names92[1];
				fNames9 = img + uploadUtil.upload(file9, request, names94, path);
			}
		}
		if(file10!=null) {
			if (!"".equals(file10.getOriginalFilename())) {
				String[] names102 = file10.getOriginalFilename().split("\\.");
				String names104 = "download_img" + "." + names102[1];
				fNames10 = img + uploadUtil.upload(file10, request, names104, path);
			}
		}
		AppDownload load = new AppDownload();
		if (ids != 0) {
			load.setId(ids);
		}
		load.setName("app");
		load.setContent("app信息");
		load.setImg_path_1(fNames1);
		load.setImg_path_2(fNames2);
		load.setImg_path_3(fNames3);
		load.setImg_path_4(fNames4);
		load.setImg_path_5(fNames5);
		load.setAndroid_img(fNames6);
		load.setIos_img(fNames7);
		load.setPc_img(fNames8);
		load.setGc_img(fNames9);
		load.setDownload_img(fNames10);
		load.setAndroid_path(app_path);
		load.setIos_path(ios_path);
		load.setIos_path(ios_path);
		load.setContent(content);
		load.setNote("app");
		int id = adminService.saveApp(load);
		model.addObject("id", id);
		model.addObject("app", adminService.findAppImgPath());
		String remarks = "修改了App下载页面的配置信息!";
		AdminUser admins = (AdminUser)session.getAttribute("admin1");
		operationlogService.addOperationlog(admins, remarks, "下载页面管理");
		return model;
	}
	
	/**
	 * 
	 * ----TODO：页面更新管理 
	 * 
	 */
	
	/**
	 * 方法名：updateSystemPage 
	 * 描述：     页面更新管理说明                 
	 * 参数：    @return 
	 * @return: String
	 */
	@RequestMapping("/updateSystemPage")
	public String updateSystemPage() {
		return "htgl/shojiduanyemianguanli";
	}
	
	/**
	 * 方法名：findSystemUpdatePage 
	 * 描述：      查询更新页面的信息                
	 * 参数：    @return 
	 * @return: JsonResult
	 */
	@ResponseBody
	@RequestMapping("/findSystemUpdatePage")
	public JsonResult findSystemUpdatePage() {
		return new JsonResult("success",systemConfigService.findSystemUpdatePage());
	}
	
	/**
	 * 方法名：updateSystemPageInfo 
	 * 描述：     修改手机端页面配置信息                 
	 * 参数：    @param updataTable
	 * 参数：    @return 
	 * @return: JsonResult
	 */
	@ResponseBody
	@RequestMapping("/updateSystemPageInfo")
	public JsonResult updateSystemPageInfo(HttpSession session,String page) {
		JSONArray arr = new JSONArray(page);
		List<UpDataPage> list = new ArrayList<UpDataPage>();
		for (int i = 0; i < arr.length(); i++) {
			UpDataPage p = new UpDataPage();
			JSONObject obj = arr.getJSONObject(i);
			p.setPage(obj.getString("page"));
			PageController.is.put(obj.getString("page"), null);//把手机端页面设置成null 重新加载
			p.setValue(Integer.parseInt(obj.getString("value")));
			list.add(p);
		}
		int num = systemConfigService.updateSystemPage(list);
		new WebSocketJson(0,list).sendAll();	//告诉前端页面发生了变化
		String remarks = "更新了手机端用户页面!";
		AdminUser admins = (AdminUser)session.getAttribute("admin1");
		operationlogService.addOperationlog(admins, remarks, "页面更新管理");
		return new JsonResult("success",num);
	}
	
	/**
	 * 
	 * ----TODO：总代理用户管理 
	 * 
	 */
	
	/**
	 * 方法名：generalAgentRegisterPage 
	 * 描述：    总代理用户管理页面                  
	 * 参数：    @return 
	 * @return: String
	 */
	@RequestMapping("/generalAgentRegisterPage")
	public String generalAgentRegisterPage() {
		return "htgl/registshezhi";
	}
	
	/**
	 * 方法名：findGeneralAgentList 
	 * 描述：    查询总代理用户                  
	 * 参数：    @return 
	 * @return: JsonResult
	 */
	@RequestMapping("/findGeneralAgentList")
	@ResponseBody
	public JsonResult findGeneralAgentList() {
		return new JsonResult("代理列表", systemConfigService.allAgentList());
	}
	
	/**
	 * 方法名：findByIdAgentUser 
	 * 描述：     根据id查询总代理用户                 
	 * 参数：    @param id
	 * 参数：    @return 
	 * @return: JsonResult
	 */
	@RequestMapping("/findByIdAgentUser")
	@ResponseBody
	public JsonResult findByIdAgentUser(Integer id) {
		Agent agent = systemConfigService.findAgentById(id);
		return new JsonResult("agentInfo", agent);
	}
	
	/**
	 * 方法名：addGeneralAgent 
	 * 描述：    添加总代理用户                  
	 * 参数：    @param agent 用户信息
	 * 参数：    @return 
	 * @return: JsonResult
	 */
	@RequestMapping("/addGeneralAgent")
	@ResponseBody
	public JsonResult addGeneralAgent(HttpSession session,Agent agent) {
		JsonResult jsonResult = systemConfigService.addGeneralAgent(agent);
		String remarks = "添加了一个总代理用户："+agent.getUsername()+"!";
		AdminUser admins = (AdminUser) session.getAttribute("admin1");
		operationlogService.addOperationlog(admins, remarks, "总代理用户管理");
		return jsonResult;
	}
	
	/**
	 * 方法名：editAgent 
	 * 描述：    修改总代理用户信息                  
	 * 参数：    @param agent
	 * 参数：    @return 
	 * @return: JsonResult
	 */
	@RequestMapping("/editAgent")
	@ResponseBody
	public JsonResult editAgent(HttpSession session,Agent agent) {
		agent.setPassword(null);
		agent.setCreatedTime(new Date());
		Integer affectRow = systemConfigService.editAgent(agent);
		String data = "修改成功!";
		if(affectRow==1) {
			data = "修改失败!";
		}
		String remarks = "修改了编号id为："+agent.getId()+"的总代理用户!";
		AdminUser admins = (AdminUser) session.getAttribute("admin1");
		operationlogService.addOperationlog(admins, remarks, "总代理用户管理");
		return new JsonResult("success", data);
	}

	/**
	 * 方法名：editAgentStatus 
	 * 描述：    启用或禁用总代理用户                  
	 * 参数：    @param id
	 * 参数：    @param status
	 * 参数：    @return 
	 * @return: JsonResult
	 */
	@RequestMapping("/editAgentStatus")
	@ResponseBody
	public JsonResult editAgentStatus(HttpSession session,Integer id, Integer status) {
		Agent agent = new Agent();
		agent.setId(id);
		agent.setStatus(status);
		agent.setCreatedTime(new Date());
		Integer affectRow = systemConfigService.editAgent(agent);
		String state = "启用了";
		if(status==0) {
			state = "禁用了";
		}
		String remarks = state+"编号id为："+id+"的总代理用户!";
		AdminUser admins = (AdminUser) session.getAttribute("admin1");
		operationlogService.addOperationlog(admins, remarks, "总代理用户管理");
		return new JsonResult("success", affectRow);
	}
	
	/**
	 * 删除总代理帐号
	 * @param id 代理帐号
	 * @return
	 */
	@ResponseBody
	@RequestMapping("/deleteGeneralAgent")
	public JsonResult deleteGeneralAgent(HttpSession session,Integer id) {
		String remarks ="删除了编号id为："+id+"的总代理用户!";
		AdminUser admins = (AdminUser) session.getAttribute("admin1");
		operationlogService.addOperationlog(admins, remarks, "总代理用户管理");
		return new JsonResult("success",systemConfigService.deleteGeneralAgent(id));
	}
	
	
	/**
	 * 
	 * ----TODO：白名单用户管理 
	 * 
	 */
	
	/**
	 * 方法名：whiteListPage 
	 * 描述：     白名单用户管理页面                 
	 * 参数：    @return 
	 * @return: String
	 */
	@RequestMapping("/whiteListPage")
	public String whiteListPage() {
		return "htgl/houtaibaimingdan";
	}

	/**
	 * 方法名：findAllWhiteList 
	 * 描述：    查询白名单用户列表                  
	 * 参数：    @return 
	 * @return: JsonResult
	 */
	@RequestMapping("/findAllWhiteList")
	@ResponseBody
	public JsonResult findAllWhiteList() {
		return new JsonResult("success", systemConfigService.findAllWhiteList());
	}
	
	/**
	 * 方法名：addWhiteListUser 
	 * 描述：    添加白名单用户                  
	 * 参数：    @param ip 添加ip
	 * 参数：    @return 
	 * @return: JsonResult
	 */
	@RequestMapping("/addWhiteListUser")
	@ResponseBody
	public JsonResult addWhiteListUser(HttpSession session,String ip) {
		WhiteList whiteList = new WhiteList();
		whiteList.setIp(ip);
		Integer affectRow = -1;
		try {
			affectRow = systemConfigService.insertWhiteList(whiteList);
		} catch (Exception e) {
			return new JsonResult(e.getMessage(), 0);
		}
		String remarks = "添加了后台白名单IP为："+ip+"!";
		AdminUser admins = (AdminUser) session.getAttribute("admin1");
		operationlogService.addOperationlog(admins, remarks, "白名单用户管理");
		return new JsonResult("插入白名单数据成功" + (affectRow == 1 ? "成功" : "失败"), affectRow);
	}

	/**
	 * 方法名：editWhiteStatus 
	 * 描述：    添加白名单用户状态                  
	 * 参数：    @param id 修改id
	 * 参数：    @param status 状态 1启用 2禁用
	 * 参数：    @return 
	 * @return: JsonResult
	 */
	@RequestMapping("/editWhiteListStatus")
	@ResponseBody
	public JsonResult editWhiteStatus(HttpSession session,Integer id, Integer status) {
		Integer affectRow = systemConfigService.updateWhiteListStatus(id, status);
		String state = "禁用了";
		if(status==1) {
			state = "启用了";
		}
		String remarks = state+"白名单IP!";
		AdminUser admins = (AdminUser) session.getAttribute("admin1");
		operationlogService.addOperationlog(admins, remarks, "白名单用户管理");
		return new JsonResult("编辑白名单状态" + (affectRow == 1 ? "成功" : "失败"), affectRow);
	}

	/**
	 * 方法名：deleteWhiteList 
	 * 描述：    删除白名单用户                  
	 * 参数：    @param id 删除id
	 * 参数：    @return 
	 * @return: JsonResult
	 */
	@RequestMapping("/deleteWhiteList")
	@ResponseBody
	public JsonResult deleteWhiteList(HttpSession session,Integer id) {
		try {
			systemConfigService.deleteWhiteList(id);
		} catch (Exception e) {
			return new JsonResult("删除白名单异常", 0);
		}
		String remarks = "删除了编号id为："+id+"的白名单IP!";
		AdminUser admins = (AdminUser) session.getAttribute("admin1");
		operationlogService.addOperationlog(admins, remarks, "白名单用户管理");
		return new JsonResult("删除白名单成功", 1);
	}
	
	
}
