package com.ja.sevice;

import java.util.List;

import com.ja.domain.QqKeFu;

public interface QqKeFuService {

	/**查询所有的qq客服*/
	List<QqKeFu> getAllQqKeFu();

	/** 添加入QQ客服 */
	int addQqKeFuInfo(QqKeFu qq);

	/** 修改入qq客服 */
	int updateQqKeFuInfo(QqKeFu qq);

	/** 删除qq客服 */
	int delQqKeFuInfo(Integer id);

	
}
