package com.ja.domain;

import java.io.Serializable;

public class Liushui implements Serializable{
    /**
	 * 
	 */
	private static final long serialVersionUID = -2811343921269979548L;

	private Integer id;//会员流水记录

    private String huiyuanzh;//会员帐号 放用户名

    private String bdtype;//变动类型

    private Double bdqjine;//变动前金额

    private Double bdjine;//变动金额

    private Double bdhjine;//变动后金额

    private String createtime;//变动时间

    private String ordernum;//订单号
    
    private String cname;//彩种
    
    private String period; //期号

    private String czname;//操作帐号

    private String beizhu;//备注

    private boolean state;//收入-支出类型
    
    private int statu; //已读流水
    
    private int user_type; //已读流水
    
    private Integer userid;//用户id
    
    public static long getSerialversionuid() {
		return serialVersionUID;
	}
    
    public int getStatu() {
		return statu;
	}

	public void setStatu(int statu) {
		this.statu = statu;
	}


    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getHuiyuanzh() {
        return huiyuanzh;
    }

    public void setHuiyuanzh(String huiyuanzh) {
        this.huiyuanzh = huiyuanzh ;
    }

    public String getCname() {
		return cname;
	}

	public void setCname(String cname) {
		this.cname = cname;
	}

	public String getBdtype() {
        return bdtype;
    }

    public String getPeriod() {
		return period;
	}

	public void setPeriod(String period) {
		this.period = period;
	}

	public void setBdtype(String bdtype) {
        this.bdtype = bdtype;
    }

    public Double getBdqjine() {
        return bdqjine;
    }

    public void setBdqjine(Double bdqjine) {
        this.bdqjine = bdqjine;
    }

    public Double getBdjine() {
        return bdjine;
    }

    public void setBdjine(Double bdjine) {
        this.bdjine = bdjine;
    }

    public Double getBdhjine() {
        return bdhjine;
    }

    public void setBdhjine(Double bdhjine) {
        this.bdhjine = bdhjine;
    }

    public String getCreatetime() {
        return createtime;
    }

    public void setCreatetime(String createtime) {
        this.createtime = createtime == null ? null : createtime.trim();
    }

    public String getOrdernum() {
        return ordernum;
    }

    public void setOrdernum(String ordernum) {
        this.ordernum = ordernum == null ? null : ordernum.trim();
    }

    public String getCzname() {
        return czname;
    }

    public void setCzname(String czname) {
        this.czname = czname == null ? null : czname.trim();
    }

    public String getBeizhu() {
        return beizhu;
    }

    public void setBeizhu(String beizhu) {
        this.beizhu = beizhu == null ? null : beizhu.trim();
    }

    public boolean isState() {
		return state;
	}

	public void setState(boolean state) {
		this.state = state;
	}

	public int getUser_type() {
		return user_type;
	}

	public void setUser_type(int user_type) {
		this.user_type = user_type;
	}

	public Integer getUserid() {
        return userid;
    }

    public void setUserid(Integer userid) {
        this.userid = userid;
    }

	@Override
	public String toString() {
		return "Liushui [id=" + id + ", huiyuanzh=" + huiyuanzh + ", bdtype=" + bdtype + ", bdqjine=" + bdqjine
				+ ", bdjine=" + bdjine + ", bdhjine=" + bdhjine + ", createtime=" + createtime + ", ordernum="
				+ ordernum + ", cname=" + cname + ", period=" + period + ", czname=" + czname + ", beizhu=" + beizhu
				+ ", state=" + state + ", statu=" + statu + ", userid=" + userid + "]";
	}

	public Liushui() {
		super();
	}

	public Liushui(String huiyuanzh, String bdtype, Double bdqjine, Double bdjine, Double bdhjine, String createtime,
			String ordernum, String cname, String period, String czname, String beizhu, boolean state, int statu,
			Integer userid) {
		super();
		this.huiyuanzh = huiyuanzh;
		this.bdtype = bdtype;
		this.bdqjine = bdqjine;
		this.bdjine = bdjine;
		this.bdhjine = bdhjine;
		this.createtime = createtime;
		this.ordernum = ordernum;
		this.cname = cname;
		this.period = period;
		this.czname = czname;
		this.beizhu = beizhu;
		this.state = state;
		this.statu = statu;
		this.userid = userid;
	}
	
}