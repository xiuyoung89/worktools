package com.ja.dao;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.ja.domain.Agent;
import com.ja.domain.AgentRebate;
import com.ja.domain.Jine;
import com.ja.domain.Liushui;
import com.ja.domain.Order;
import com.ja.domain.ProxyConnection;
import com.ja.domain.User;

/**
 * 用户代理管理系统
 * @author CY
 *@date 2018.3.14
 */
public interface UserAgentMapper {
	
	/**
	 * 根据条件查询会员
	 * @param online 在想状态，null为不清楚，1为在线，2为离线
	 * @param accountType 账户类型null为全部，1为会员，2为代理
	 * @param account 根据会员名查询
	 * @return	User的List集合
	 */
	List<User> showUser(@Param("id") Integer id,
			@Param("online") Integer online,
			@Param("accountType") Integer accountType,
			@Param("account") String account);
	

	/**
	 * 根据id找到用户
	 * @param id
	 * @return 用户
	 */
	User showSelf(Integer id);
	
	/**
	 * 修改返点数
	 * @param rebate
	 * @param id
	 * @return 影响数据库的行数
	 */
	Integer updateRebate(@Param("id") Integer id,@Param("rebate") Double rebate);
	
	/**
	 * 通过条件找到agent
	 * @param agent
	 * @return
	 */
	Agent findAgent(String agent);
	
	/**
	 * 像用户列表中插入代理id
	 * @param id
	 * @param agentId
	 * @return
	 */
	Integer addUserAgentID(@Param("id") Integer id,@Param("agentId") Integer agentId);
	
	/**
	 * 通过推广码找到用户
	 * @param icode
	 * @return User用户
	 */
	User findUserByIcode(String icode);
	
	/**
	 * 设置新注册用户的fid
	 * @param id
	 * @param fid
	 * @return
	 */
	Integer updateUserFid(@Param("id") Integer id,@Param("fid") Integer fid);
	
	/**
	 * 根据条件找到流水对象集合
	 * @param date1	起始时间
	 * @param date2	结束时间
	 * @param account 账号名
	 * @param type  类型
	 * @param orderId 订单号
	 * @return 流水对象
	 */
	List<Liushui> findLiushui(
			@Param("date1") String date1,
			@Param("date2") String date2,
			@Param("account") String account,
			@Param("type") String type,
			@Param("orderId") String orderId,
			@Param("a")Agent a);
	

	/**
	 * 根据条件查询报表
	 * @param userid 用户id
	 * @param date1 起始时间
	 * @param date2 结束时间
	 * @param account 账户名
	 * @return 运营报表对象
	 */
	Double findYunyingbbByUserId(@Param("a")Agent a,@Param("date1") String date1,@Param("date2") String date2,@Param("type")String type,@Param("name")String name);

	/**
	 * 根据条件查询金额记录
	 * @param agentId
	 * @param status
	 * @param type
	 * @param account
	 * @param date1
	 * @param date2
	 * @return 金额对象
	 */
	List<Jine> findJineByUserId(@Param("agentId") Integer agentId,
			@Param("status") String status,@Param("type") String type,
			@Param("account") String account,@Param("date1") String date1,@Param("date2") String date2);

	/** 根据用户名和密码查询用户 */
	Agent login(@Param("name") String name, @Param("pass") String pass);
	
	/**
	 * 修改代理用户信息
	 * @param agent
	 * @return
	 */
	Integer editeAgent(Agent agent);

	/**
	 * 根据代理的id找到相对应的代理
	 * @param id
	 * @return
	 */
	Agent findAgentById(Integer id);
	
	/**
	 * 添加代理返点率对象
	 * @param agentRebate
	 * @return
	 */
	Integer insertAgentRebate(AgentRebate agentRebate);
	
	/**
	 * 通过用户id找到相对应的代理
	 * @param userid
	 * @return
	 */
	Agent findAgentByUserId(Integer userid);
	
	/**
	 * 根据代理id和时间找到代理返点率对象
	 * @return
	 */
	List<AgentRebate> findAgentRebate(@Param("agentId") Integer agentId,@Param("date1") String date1,@Param("date2") String date2);
	
	/**
	 * 查询团队余额
	 * @param agentId
	 * @param date1
	 * @param date2
	 * @param account
	 * @return
	 */
	Double teamBalance(@Param("agentId") Integer agentId,@Param("date1") String date1,@Param("date2") String date2,@Param("account") String account);

	/**
	 * 获取用户的推广链接
	 * @param a
	 * @return
	 */
	List<ProxyConnection> queryAgentConnection(@Param("a")Agent a);
	/**
	 * 查询代理用户下面会员的下注记录
	 * @param a 代理信息
	 * @param o 用户信息
	 * @param time 开始时间
	 * @param time1 结束时间
	 * @param startIndex  起始页
	 * @param lineCount 结束页
	 * @return
	 */
	List<Order> noteRecord(@Param("a")Agent a,@Param("o")Order o,@Param("time")String time,@Param("time1")String time1,@Param("startIndex")Integer startIndex,@Param("lineCount")Integer lineCount,@Param("model")int model);

	/**
	 * 查询代理用户下面会员的下注记录
	 * @return
	 */
	Order idQuery(@Param("id")Integer id);
	/**
	 * 查询投注人数
	 * @param a
	 * @return
	 */
	List<Order> theNumberOfBets(@Param("a")Agent a,@Param("date1") String date1,@Param("date2") String date2);
	/**
	 * 统计团队余额
	 * @param a
	 * @return
	 */
	Double teamBalances(@Param("a")Agent a);
	
	

	/**
	 * 方法名：findByNameUser 
	 * 描述：     根据用户名查询用户的各项统计                 
	 * 参数：    @param userName 用户名
	 * 参数：    @return 
	 * @return: User
	 */
	User findByNameUser(String userName);

	/**
	 * 方法名：findByGeneralAgentIdUser 
	 * 描述：    根据总代理id查询总代理的下级                  
	 * 参数：    @param agent_id 总代理id
	 * 参数：    @return 
	 * @return: List<User>
	 */
	List<User> findByGeneralAgentIdUser(Integer agent_id);
	
}
