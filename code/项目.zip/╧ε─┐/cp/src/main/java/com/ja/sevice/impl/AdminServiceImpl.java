package com.ja.sevice.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ja.dao.AdminMapper;
import com.ja.dao.AppDownloadMapper;
import com.ja.domain.Admin;
import com.ja.domain.AppDownload;
import com.ja.sevice.IAdminService;

/**
 * @AUTH LBQ
 * @DATE 2017年11月10日 上午9:29:09
 * @DESC
 */
@Service
public class AdminServiceImpl implements IAdminService {

	@Autowired
	private AdminMapper adminMapper;

	@Autowired
	private AppDownloadMapper appDownloadMapper;

	@Override
	public int update(Admin admin) {
		return adminMapper.update(admin);
	}

	@Override
	public int updateTongzhi(String notice) {
		return adminMapper.updateTongzhi(notice);
	}

	@Override
	public int upwangzhanflag(Integer weihukaiguan) {
		return adminMapper.upwangzhanflag(weihukaiguan);
	}

	@Override
	public int upweihuyuanyin(String weihuyuanyin) {
		return adminMapper.upweihuyuanyin(weihuyuanyin);
	}

	@Override
	public int upzhangbianflag(Integer zhangbiankaiguan) {
		return adminMapper.upzhangbianflag(zhangbiankaiguan);
	}

	@Override
	public int upbaimingdanflag(Integer baimingdankaiguan) {
		return adminMapper.upbaimingdanflag(baimingdankaiguan);
	}

	@Override
	public int updateGendanDate(Integer count) {
		return adminMapper.updateGendanDate(count);
	}

	@Override
	public int updateFlag(String parameter, Integer flag) {
		return adminMapper.updateFlag(parameter, flag);
	}

	@Override
	public Integer getCplay() {
		return adminMapper.getCplay();
	}

	@Override
	public int defectionRuleUp(Admin admin) {
		return adminMapper.defectionRuleUp(admin);
	}

	@Override
	public int saveApp(AppDownload load) {
		int id = 0;
		if (load.getId() != null) {
			id = load.getId();
			appDownloadMapper.updateApp(load);
		} else {
			id = appDownloadMapper.insertApp(load);
		}
		return id;
	}

	@Override
	public AppDownload findAppImgPath() {
		return appDownloadMapper.findAppImgPath();
	}

	@Override
	public AppDownload findByIdAppDownload(Integer id) {
		return appDownloadMapper.findByIdAppDownload(id);
	}

	@Override
	public int updateDrawingSteup(Admin admin) {
		return adminMapper.updateDrawingSteup(admin);
	}
	
}
