package com.ja.controller;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.ja.domain.Order;
import com.ja.domain.PagingData;
import com.ja.domain.User;
import com.ja.sevice.IOrderService;
import com.ja.sevice.KongzhiService;
import com.ja.util.JsonResult;

@Controller
@RequestMapping("/orders")
public class PC_OrderController {
	
	@Autowired
	private IOrderService orderService;
	
	@Autowired
	private KongzhiService kongzhiService;
	
	/**
	 * 查询个人订单-全部-待开奖-已开奖-已中奖-已撤单
	 * @param session
	 * @param paging
	 * @param state
	 * @param cname
	 * @returne
	 */
	@RequestMapping("/myOrders")  
	@ResponseBody
	public String myOrders(HttpSession session,PagingData paging, Integer state, String cname) {
		User user = (User) session.getAttribute("user");
		if(user == null) {
			paging.setReplace1("0");
			return PagingData.pagingData(paging);
		}
		Order order  = new Order();
		order.setCname(cname);
		order.setState(state);
		order.setUserid(user.getId());
		paging.setAllCount(orderService.findMyOrdersCounts(order));
		paging.setList(orderService.findMyOrders(paging.getStartIndex(),paging.getLineCount(),user.getId(),state,cname,1));
		return PagingData.pagingData(paging);
	}
	
	/** 根据条件查询投注记录 */
	@ResponseBody 
	@RequestMapping("/touzhuRecord")
	public JsonResult touzhuRecord(Integer id) {
		return new JsonResult("success",orderService.getOneOrder(id));  
	}


	/**
	 * 查询订单相关的彩种
	 * @param session
	 * @return
	 */
	@RequestMapping("/myOrderLotters")
	@ResponseBody
	public JsonResult myOrderLotter(HttpSession session) {
		User user = (User) session.getAttribute("user");
		return new JsonResult("success", orderService.fenleiorder(user.getId()));
	}

	/**
	 *   方法名：cancelOrder   
	 *   描述：     彩票订单撤单                  TODO   
	 *   参数：    @param id 订单id
	 *   参数：    @param money 撤单金额
	 *   参数：    @param session
	 *   参数：    @return 
	 * @return: JsonResult
	 */
	@RequestMapping("/chedan")
	@ResponseBody
	public JsonResult chedan(int id, double money, HttpSession session){
		User user = (User) session.getAttribute("user");
		return orderService.cancelOrder(user, id);
	}

	/**
	  * 方法名：calculateBettingCount 
	  * 描述：     用户投注注数                 
	  * 参数：    @param o
	  * 参数：    @return 
	 * @return: JsonResult
	 */
	@RequestMapping("/awards1")
	@ResponseBody
	public JsonResult calculateBettingCount(Order o) {
		return orderService.calculateBettingCount(o);
	}
	
	/**
	 *   方法名：awards   
	 *   描述：     用户下注订单                  TODO   
	 *   参数：    @param order 下注信息
	 *   参数：    @param session
	 *   参数：    @return
	 *   参数：    @throws Exception 
	 * @return: JsonResult
	 */
	@RequestMapping("/awards")
	@ResponseBody
	public JsonResult awards(Order order, HttpSession session) throws Exception {
		User user = (User) session.getAttribute("user");
		return orderService.awards(order, user);
	}

	/**
	  * 方法名：xiazhugs 
	  * 描述：    查询下注玩法的控制球数                  
	  * 参数：    @return 
	 * @return: JsonResult
	 */
	@ResponseBody
	@RequestMapping("/xiazhugs")
	public JsonResult xiazhugs() {
		return new JsonResult("success", kongzhiService.getAllKongzhi());
	}
	
	
	
}

