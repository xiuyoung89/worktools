package com.ja.sevice;

import com.ja.domain.Admin;
import com.ja.domain.AppDownload;

/**
 * @AUTH LBQ
 * @DATE 2017年11月10日 上午9:28:44
 * @DESC 
 */
public interface IAdminService {

	/**
	 * @param load app的地址
	 * @return 添加或修改app
	 */
	int saveApp(AppDownload load);

	/**
	 * app下载地址
	 * @return
	 */
	AppDownload findAppImgPath();

	/**
	 * 根据id查询app的信息 
	 * @param id app ID
	 * @return
	 */
	AppDownload findByIdAppDownload(Integer id);
	
	
	
	/**首页轮播图设置*/
	int update(Admin admin);

	/**首页通知设置*/
	int updateTongzhi(String notice);

	/**网站开关设置*/
	int upwangzhanflag(Integer weihukaiguan);

	/**网站维护原因*/
	int upweihuyuanyin(String weihuyuanyin);

	/**帐变开关*/
	int upzhangbianflag(Integer zhangbiankaiguan);

	/**白名单开关*/
	int upbaimingdanflag(Integer baimingdankaiguan);

	/**跟单-第几单开始跟单以及倍数 */
	int updateGendanDate(Integer count);

	/**跟单-合买*/
	int updateFlag(String parameter,Integer flag);

	/**试玩账号*/
	Integer getCplay();
	
	/**修改反水规则内容*/
	int defectionRuleUp(Admin admin);

	/**
	 * 跟新提款手续费-次数手续费设置
	 * @param admin 设置信息
	 * @return
	 */
	int updateDrawingSteup(Admin admin);



}
