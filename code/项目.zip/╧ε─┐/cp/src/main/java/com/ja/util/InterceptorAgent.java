package com.ja.util;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.web.servlet.HandlerInterceptor;
import org.springframework.web.servlet.ModelAndView;

import com.ja.domain.Agent;

/**
 * @AUTH LBQ
 * @DATE 2017年10月27日 下午5:31:57
 * @DESC 
 */
public class InterceptorAgent implements HandlerInterceptor{

	@Override
	public void afterCompletion(HttpServletRequest request, HttpServletResponse response, Object object2, Exception object3) throws Exception {
		
	}

	@Override
	public void postHandle(HttpServletRequest request, HttpServletResponse response, Object object2, ModelAndView object3) throws Exception {
		
	}

	@Override
	public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object object2) throws Exception {
		HttpSession session = request.getSession();
		Agent agent = (Agent) session.getAttribute("agent");
		try {
			agent.getId();
			return true;
		} catch (Exception e) {
			response.sendRedirect("/userAgent/login.do");
			return false;
		}
	}
}
