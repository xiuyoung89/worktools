package com.ja.domain;

import java.io.Serializable;

/**
 * @author Administrator
 *2018年9月17日
 *
 */
public class AdminUser  implements Serializable{
	
	private static final long serialVersionUID = 8153334292416922783L;

	private Integer id; //后台管理员用户表
	
	private String name; //帐号
	
	private String nick_name; //昵称
	
	private String pass; //密码
	
	private String ip; //绑定ip
	
	private Integer admin_type; //管理员类型
	
	private String avatar; // 头像
	
	private String note; //备注
	
	private String created_time; //操作时间
	
	private Integer roleid; //角色
	
	private Integer state; //1 启用 0 禁用
	
	private String cwgl; //权限字段
	
	private Integer adminid;//管理员id
	
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	
	public String getNick_name() {
		return nick_name;
	}
	public void setNick_name(String nick_name) {
		this.nick_name = nick_name;
	}
	public String getPass() {
		return pass;
	}
	public void setPass(String pass) {
		this.pass = pass;
	}
	public String getIp() {
		return ip;
	}
	public void setIp(String ip) {
		this.ip = ip;
	}
	public Integer getAdmin_type() {
		return admin_type;
	}
	
	public String getAvatar() {
		return avatar;
	}
	public void setAvatar(String avatar) {
		this.avatar = avatar;
	}
	public String getNote() {
		return note;
	}
	public void setNote(String note) {
		this.note = note;
	}
	public void setAdmin_type(Integer admin_type) {
		this.admin_type = admin_type;
	}
	public String getCreated_time() {
		return created_time;
	}
	public void setCreated_time(String created_time) {
		this.created_time = created_time;
	}
	public Integer getRoleid() {
		return roleid;
	}
	public void setRoleid(Integer roleid) {
		this.roleid = roleid;
	}
	public Integer getState() {
		return state;
	}
	public void setState(Integer state) {
		this.state = state;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	public String getCwgl() {
		return cwgl;
	}
	public void setCwgl(String cwgl) {
		this.cwgl = cwgl;
	}
	
	public Integer getAdminid() {
		return adminid;
	}
	public void setAdminid(Integer adminid) {
		this.adminid = adminid;
	}
	public AdminUser() {
		super();
	}
	
	@Override
	public String toString() {
		return "AdminUser [id=" + id + ", name=" + name + ", nick_name=" + nick_name + ", pass=" + pass + ", ip=" + ip
				+ ", admin_type=" + admin_type + ", avatar=" + avatar + ", note=" + note + ", created_time="
				+ created_time + ", roleid=" + roleid + ", state=" + state + ", cwgl=" + cwgl + ", adminid=" + adminid
				+ "]";
	}
	
}
