package com.ja.check.action;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class SystemAttribute {

	/**
	 * 
	 * 方法名：gyhz   二分PK10
	 * 描述： TODO 
	 * 参数： @param attr 
	 * 参数： @return
	 * 
	 * @return: String
	 */
	public String gyhz(String attr) throws Exception{
		String lotterNum = SystemLotter.checkRandomNum1();
		String[] nums = lotterNum.split(",");
		int[] d = new int[nums.length];
		for (int i = 0; i < nums.length; i++) {
			d[i] = Integer.parseInt(nums[i]);
		}
		int k = d[0] + d[1];
		switch (attr) {
		case "dan":
			if (k % 2 != 0) {
				lotterNum = gyhz(attr);
			}
			break;
		case "shuang":
			if (k % 2 == 0) {
				lotterNum = gyhz(attr);
			}
			break;
		case "da":
			if (k > 11) {
				lotterNum = gyhz(attr);
			}
			break;
		case "xiao":
			if (k < 12) {
				lotterNum = gyhz(attr);
			}
			break;
		}
		return lotterNum;
	}

	
	/**
	 *  二分pk10
	 * 方法名：第几名
	 *  描述： 1-5球 TODO 参数： @return
	 * 
	 * @return: String
	 */
	public String djm(String cplay, String attr) throws Exception{
		String lotterNum = SystemLotter.checkRandomNum1();
		String[] nums = lotterNum.split(",");
		int[] d = new int[nums.length];
		for (int i = 0; i < nums.length; i++) {
			d[i] = Integer.parseInt(nums[i]);
		}
		System.err.println("没替换之前: " + lotterNum);
		int k1 = d[0];
		int k2 = d[1];
		int k3 = d[2];
		int k4 = d[3];
		int k5 = d[4];
		int k6 = d[5];
		int k7 = d[6];
		int k8 = d[7];
		int k9 = d[8];
		int k10 = d[9];

		switch (attr) {
		case "dan":
			switch (cplay) {
			case "gj":
				if (k1 % 2 != 0) {
					lotterNum = djm(cplay, attr);
				}
				break;
			case "yj":
				if (k2 % 2 != 0) {
					lotterNum = djm(cplay, attr);
				}

				break;
			case "d3m":
				if (k3 % 2 != 0) {
					lotterNum = djm(cplay, attr);
				}
				break;
			case "d4m":
				if (k4 % 2 != 0) {
					lotterNum = djm(cplay, attr);
				}
				break;
			case "d5m":
				if (k5 % 2 != 0) {
					lotterNum = djm(cplay, attr);
				}
			case "d6m":
				if (k6 % 2 != 0) {
					lotterNum = djm(cplay, attr);
				}
			case "d7m":
				if (k7 % 2 != 0) {
					lotterNum = djm(cplay, attr);
				}
			case "d8m":
				if (k8 % 2 != 0) {
					lotterNum = djm(cplay, attr);
				}
			case "d9m":
				if (k9 % 2 != 0) {
					lotterNum = djm(cplay, attr);
				}
			case "d10m":
				if (k10 % 2 != 0) {
					lotterNum = djm(cplay, attr);
				}
				break;

			}

			break;
		case "shuang":
			switch (cplay) {
			case "gj":
				if (k1 % 2 == 0) {
					lotterNum = djm(cplay, attr);
				}
				break;
			case "yj":
				if (k2 % 2 == 0) {
					lotterNum = djm(cplay, attr);
				}
				break;
			case "d3m":
				if (k3 % 2 == 0) {
					lotterNum = djm(cplay, attr);
				}
				break;
			case "d4m":
				if (k4 % 2 == 0) {
					lotterNum = djm(cplay, attr);
				}
				break;
			case "d5m":
				if (k5 % 2 == 0) {
					lotterNum = djm(cplay, attr);
				}
				break;
			case "d6m":
				if (k6 % 2 == 0) {
					lotterNum = djm(cplay, attr);
				}
				break;
			case "d7m":
				if (k7 % 2 == 0) {
					lotterNum = djm(cplay, attr);
				}
				break;
			case "d8m":
				if (k8 % 2 == 0) {
					lotterNum = djm(cplay, attr);
				}
				break;
			case "d9m":
				if (k5 % 2 == 0) {
					lotterNum = djm(cplay, attr);
				}
				break;
			case "d10m":
				if (k9 % 2 == 0) {
					lotterNum = djm(cplay, attr);
				}
				break;
			}
			break;
		case "da":
			switch (cplay) {
			case "gj":
				if (k1 >= 6) {
					lotterNum = djm(cplay, attr);
				}
				break;
			case "yj":
				if (k2 >= 6) {
					lotterNum = djm(cplay, attr);
				}
				break;
			case "d3m":
				if (k3 >= 6) {
					lotterNum = djm(cplay, attr);
				}
				break;
			case "d4m":
				if (k4 >= 6) {
					lotterNum = djm(cplay, attr);
				}
				break;
			case "d5m":
				if (k5 >= 6) {
					lotterNum = djm(cplay, attr);
				}
				break;
			case "d6m":
				if (k6 >= 6) {
					lotterNum = djm(cplay, attr);
				}
				break;
			case "d7m":
				if (k7 >= 6) {
					lotterNum = djm(cplay, attr);
				}
				break;
			case "d8m":
				if (k8 >= 6) {
					lotterNum = djm(cplay, attr);
				}
				break;
			case "d9m":
				if (k9 >= 6) {
					lotterNum = djm(cplay, attr);
				}
				break;
			case "d10m":
				if (k10 >= 6) {
					lotterNum = djm(cplay, attr);
				}
				break;
			}
			break;
		case "xiao":
			switch (cplay) {
			case "gj":
				if (k1 <= 5) {
					lotterNum = djm(cplay, attr);
				}
				break;
			case "yj":
				if (k2 <= 5) {
					lotterNum = djm(cplay, attr);
				}
				break;
			case "d3m":
				if (k3 <= 5) {
					lotterNum = djm(cplay, attr);
				}
				break;
			case "d4m":
				if (k4 <= 5) {
					lotterNum = djm(cplay, attr);
				}
				break;
			case "d5m":
				if (k5 <= 5) {
					lotterNum = djm(cplay, attr);
				}
				break;
			case "d6m":
				if (k6 <= 5) {
					lotterNum = djm(cplay, attr);
				}
				break;
			case "d7m":
				if (k7 <= 5) {
					lotterNum = djm(cplay, attr);
				}
				break;
			case "d8m":
				if (k8 <= 5) {
					lotterNum = djm(cplay, attr);
				}
				break;
			case "d9m":
				if (k9 <= 5) {
					lotterNum = djm(cplay, attr);
				}
				break;
			case "d10m":
				if (k10 <= 5) {
					lotterNum = djm(cplay, attr);
				}
				break;
			}
			break;
		case "longs":
			switch (cplay) {
			case "gj":
				if (k1 > k10) {
					lotterNum = djm(cplay, attr);
				}
				break;
			case "yj":
				if (k2 > k9) {
					lotterNum = djm(cplay, attr);
				}
				break;
			case "d3m":
				if (k3 > k8) {
					lotterNum = djm(cplay, attr);
				}
				break;
			case "d4m":
				if (k4 > k7) {
					lotterNum = djm(cplay, attr);
				}
				break;
			case "d5m":
				if (k5 > k6) {
					lotterNum = djm(cplay, attr);
				}
				break;
			}
			break;
		case "hu":
			switch (cplay) {
			case "gj":
				if (k1 < k10) {
					lotterNum = djm(cplay, attr);
				}
				break;
			case "yj":
				if (k2 < k9) {
					lotterNum = djm(cplay, attr);
				}
				break;
			case "d3m":
				if (k3 < k8) {
					lotterNum = djm(cplay, attr);
				}
				break;
			case "d4m":
				if (k4 < k7) {
					lotterNum = djm(cplay, attr);
				}
				break;
			case "d5m":
				if (k5 < k6) {
					lotterNum = djm(cplay, attr);
				}
				break;
			}
			break;

		case "d1q":
			switch (cplay) {
			case "gj":
				if (k1 == 1) {
					lotterNum = djm(cplay, attr);
				}
				break;
			case "yj":
				if (k2 == 1) {
					lotterNum = djm(cplay, attr);
				}
				break;
			case "d3m":
				if (k3 == 1) {
					lotterNum = djm(cplay, attr);
				}
				break;
			case "d4m":
				if (k4 == 1) {
					lotterNum = djm(cplay, attr);
				}
				break;
			case "d5m":
				if (k5 == 1) {
					lotterNum = djm(cplay, attr);
				}
			case "d6m":
				if (k6 == 1) {
					lotterNum = djm(cplay, attr);
				}
			case "d7m":
				if (k7 == 1) {
					lotterNum = djm(cplay, attr);
				}
			case "d8m":
				if (k8 == 1) {
					lotterNum = djm(cplay, attr);
				}
			case "d9m":
				if (k9 == 1) {
					lotterNum = djm(cplay, attr);
				}
			case "d10m":
				if (k10 == 1) {
					lotterNum = djm(cplay, attr);
				}
			}
			break;
		case "d2q":
			switch (cplay) {
			case "gj":
				if (k1 == 2) {
					lotterNum = djm(cplay, attr);
				}
				break;
			case "yj":
				if (k2 == 2) {
					lotterNum = djm(cplay, attr);
				}
				break;
			case "d3m":
				if (k3 == 2) {
					lotterNum = djm(cplay, attr);
				}
				break;
			case "d4m":
				if (k4 == 2) {
					lotterNum = djm(cplay, attr);
				}
				break;
			case "d5m":
				if (k5 == 2) {
					lotterNum = djm(cplay, attr);
				}
				break;
			case "d6m":
				if (k6 == 2) {
					lotterNum = djm(cplay, attr);
				}
				break;
			case "d7m":
				if (k7 == 2) {
					lotterNum = djm(cplay, attr);
				}
				break;
			case "d8m":
				if (k8 == 2) {
					lotterNum = djm(cplay, attr);
				}
				break;
			case "d9m":
				if (k9 == 2) {
					lotterNum = djm(cplay, attr);
				}
				break;
			case "d10m":
				if (k10 == 2) {
					lotterNum = djm(cplay, attr);
				}
				break;

			}

			break;
		case "d3q":
			switch (cplay) {
			case "gj":
				if (k1 == 3) {
					lotterNum = djm(cplay, attr);
				}
				break;
			case "yj":
				if (k2 == 3) {
					lotterNum = djm(cplay, attr);
				}
				break;
			case "d3m":
				if (k3 == 3) {
					lotterNum = djm(cplay, attr);
				}
				break;
			case "d4m":
				if (k4 == 3) {
					lotterNum = djm(cplay, attr);
				}
				break;
			case "d5m":
				if (k5 == 3) {
					lotterNum = djm(cplay, attr);
				}
				break;
			case "d6m":
				if (k6 == 3) {
					lotterNum = djm(cplay, attr);
				}
				break;
			case "d7m":
				if (k7 == 3) {
					lotterNum = djm(cplay, attr);
				}
				break;
			case "d8m":
				if (k8 == 3) {
					lotterNum = djm(cplay, attr);
				}
				break;
			case "d9m":
				if (k9 == 3) {
					lotterNum = djm(cplay, attr);
				}
				break;
			case "d10m":
				if (k10 == 3) {
					lotterNum = djm(cplay, attr);
				}
				break;
			}
			break;
		case "d4q":
			switch (cplay) {
			case "gj":
				if (k1 == 4) {
					lotterNum = djm(cplay, attr);
				}
				break;
			case "yj":
				if (k2 == 4) {
					lotterNum = djm(cplay, attr);
				}
				break;
			case "d3m":
				if (k3 == 4) {
					lotterNum = djm(cplay, attr);
				}
				break;
			case "d4m":
				if (k4 == 4) {
					lotterNum = djm(cplay, attr);
				}
				break;
			case "d5m":
				if (k5 == 4) {
					lotterNum = djm(cplay, attr);
				}
				break;
			case "d6m":
				if (k6 == 4) {
					lotterNum = djm(cplay, attr);
				}
				break;
			case "d7m":
				if (k7 == 4) {
					lotterNum = djm(cplay, attr);
				}
				break;
			case "d8m":
				if (k8 == 4) {
					lotterNum = djm(cplay, attr);
				}
				break;
			case "d9m":
				if (k9 == 4) {
					lotterNum = djm(cplay, attr);
				}
				break;
			case "d10m":
				if (k10 == 4) {
					lotterNum = djm(cplay, attr);
				}
				break;
			}
			break;
		case "d5q":
			switch (cplay) {
			case "gj":
				if (k1 == 5) {
					lotterNum = djm(cplay, attr);
				}
				break;
			case "yj":
				if (k2 == 5) {
					lotterNum = djm(cplay, attr);
				}
				break;
			case "d3m":
				if (k3 == 5) {
					lotterNum = djm(cplay, attr);
				}
				break;
			case "d4m":
				if (k4 == 5) {
					lotterNum = djm(cplay, attr);
				}
				break;
			case "d5m":
				if (k5 == 5) {
					lotterNum = djm(cplay, attr);
				}
				break;
			case "d6m":
				if (k6 == 5) {
					lotterNum = djm(cplay, attr);
				}
				break;
			case "d7m":
				if (k7 == 5) {
					lotterNum = djm(cplay, attr);
				}
				break;
			case "d8m":
				if (k8 == 5) {
					lotterNum = djm(cplay, attr);
				}
				break;
			case "d9m":
				if (k9 == 5) {
					lotterNum = djm(cplay, attr);
				}
				break;
			case "d10m":
				if (k10 == 5) {
					lotterNum = djm(cplay, attr);
				}
				break;
			}
			break;
		case "d6q":
			switch (cplay) {
			case "gj":
				if (k1 == 6) {
					lotterNum = djm(cplay, attr);
				}
				break;
			case "yj":
				if (k2 == 6) {
					lotterNum = djm(cplay, attr);
				}
				break;
			case "d3m":
				if (k3 == 6) {
					lotterNum = djm(cplay, attr);
				}
				break;
			case "d4m":
				if (k4 == 6) {
					lotterNum = djm(cplay, attr);
				}
				break;
			case "d5m":
				if (k5 == 6) {
					lotterNum = djm(cplay, attr);
				}
				break;
			case "d6m":
				if (k6 == 6) {
					lotterNum = djm(cplay, attr);
				}
				break;
			case "d7m":
				if (k7 == 6) {
					lotterNum = djm(cplay, attr);
				}
				break;
			case "d8m":
				if (k8 == 6) {
					lotterNum = djm(cplay, attr);
				}
				break;
			case "d9m":
				if (k9 == 6) {
					lotterNum = djm(cplay, attr);
				}
				break;
			case "d10m":
				if (k10 == 6) {
					lotterNum = djm(cplay, attr);
				}
				break;
			}
			break;
		case "d7q":
			switch (cplay) {
			case "gj":
				if (k1 == 7) {
					lotterNum = djm(cplay, attr);
				}
				break;
			case "yj":
				if (k2 == 7) {
					lotterNum = djm(cplay, attr);
				}
				break;
			case "d3m":
				if (k3 == 7) {
					lotterNum = djm(cplay, attr);
				}
				break;
			case "d4m":
				if (k4 == 7) {
					lotterNum = djm(cplay, attr);
				}
				break;
			case "d5m":
				if (k5 == 7) {
					lotterNum = djm(cplay, attr);
				}
				break;
			case "d6m":
				if (k6 == 7) {
					lotterNum = djm(cplay, attr);
				}
				break;
			case "d7m":
				if (k7 == 7) {
					lotterNum = djm(cplay, attr);
				}
				break;
			case "d8m":
				if (k8 == 7) {
					lotterNum = djm(cplay, attr);
				}
				break;
			case "d9m":
				if (k9 == 7) {
					lotterNum = djm(cplay, attr);
				}
				break;
			case "d10m":
				if (k10 == 7) {
					lotterNum = djm(cplay, attr);
				}
				break;
			}
			break;
		case "d8q":
			switch (cplay) {
			case "gj":
				if (k1 == 8) {
					lotterNum = djm(cplay, attr);
				}
				break;
			case "yj":
				if (k2 == 8) {
					lotterNum = djm(cplay, attr);
				}
				break;
			case "d3m":
				if (k3 == 8) {
					lotterNum = djm(cplay, attr);
				}
				break;
			case "d4m":
				if (k4 == 8) {
					lotterNum = djm(cplay, attr);
				}
				break;
			case "d5m":
				if (k5 == 8) {
					lotterNum = djm(cplay, attr);
				}
				break;
			case "d6m":
				if (k6 == 8) {
					lotterNum = djm(cplay, attr);
				}
				break;
			case "d7m":
				if (k7 == 8) {
					lotterNum = djm(cplay, attr);
				}
				break;
			case "d8m":
				if (k8 == 8) {
					lotterNum = djm(cplay, attr);
				}
				break;
			case "d9m":
				if (k9 == 8) {
					lotterNum = djm(cplay, attr);
				}
				break;
			case "d10m":
				if (k10 == 8) {
					lotterNum = djm(cplay, attr);
				}
				break;
			}
			break;
		case "d9q":
			switch (cplay) {
			case "gj":
				if (k1 == 9) {
					lotterNum = djm(cplay, attr);
				}
				break;
			case "yj":
				if (k2 == 9) {
					lotterNum = djm(cplay, attr);
				}
				break;
			case "d3m":
				if (k3 == 9) {
					lotterNum = djm(cplay, attr);
				}
				break;
			case "d4m":
				if (k4 == 9) {
					lotterNum = djm(cplay, attr);
				}
				break;
			case "d5m":
				if (k5 == 9) {
					lotterNum = djm(cplay, attr);
				}
				break;
			case "d6m":
				if (k6 == 9) {
					lotterNum = djm(cplay, attr);
				}
				break;
			case "d7m":
				if (k7 == 9) {
					lotterNum = djm(cplay, attr);
				}
				break;
			case "d8m":
				if (k8 == 9) {
					lotterNum = djm(cplay, attr);
				}
				break;
			case "d9m":
				if (k9 == 9) {
					lotterNum = djm(cplay, attr);
				}
				break;
			case "d10m":
				if (k10 == 9) {
					lotterNum = djm(cplay, attr);
				}
				break;
			}
			break;
		case "d10q":
			switch (cplay) {
			case "gj":
				if (k1 == 10) {
					lotterNum = djm(cplay, attr);
				}
				break;
			case "yj":
				if (k2 == 10) {
					lotterNum = djm(cplay, attr);
				}
				break;
			case "d3m":
				if (k3 == 10) {
					lotterNum = djm(cplay, attr);
				}
				break;
			case "d4m":
				if (k4 == 10) {
					lotterNum = djm(cplay, attr);
				}
				break;
			case "d5m":
				if (k5 == 10) {
					lotterNum = djm(cplay, attr);
				}
				break;
			case "d6m":
				if (k6 == 10) {
					lotterNum = djm(cplay, attr);
				}
				break;
			case "d7m":
				if (k7 == 10) {
					lotterNum = djm(cplay, attr);
				}
				break;
			case "d8m":
				if (k8 == 10) {
					lotterNum = djm(cplay, attr);
				}
				break;
			case "d9m":
				if (k9 == 10) {
					lotterNum = djm(cplay, attr);
				}
				break;
			case "d10m":
				if (k10 == 10) {
					lotterNum = djm(cplay, attr);
				}
				break;
			}
		}
		System.err.println("替换后: " + lotterNum);
		return lotterNum;
	}
	
	/**
	 * 
	 * 方法名：zh 二分时时彩
	 * 描述： 总和 TODO
	 *  参数： @return
	 * @return: String
	 */
	public String zh(String attr) throws Exception{
		String lotterNum = SystemLotter.checkRandomNum2();
		String[] nums = lotterNum.split(",");
		int[] d = new int[nums.length];
		for (int i = 0; i < nums.length; i++) {
			d[i] = Integer.parseInt(nums[i]);
		}
		int k = d[0] + d[1] + d[2] + d[3] + d[4];
		switch (attr) {
		case "dan":
			if (k % 2 != 0) {
				lotterNum = zh(attr);
			}
			break;
		case "shuang":
			if (k % 2 == 0) {
				lotterNum = zh(attr);
			}
			break;
		case "da":
			if (k > 22) {
				lotterNum = zh(attr);
			}
			break;
		case "xiao":
			if (k < 23) {
				lotterNum = zh(attr);
			}
			break;
		case "longs":
			if (d[0] > d[4]) {
				lotterNum = zh(attr);
			}
			break;
		case "hu":
			if (d[0] < d[4]) {
				lotterNum = zh(attr);
			}
			break;
		case "he":
			if (d[0] == d[4]) {
				lotterNum = zh(attr);
			}
			break;
		}
		return lotterNum;
	}


	/**
	 * 二分时时彩
	 * 方法名：d1q 描述： 1-5球 TODO 参数： @return
	 * 
	 * @return: String
	 */
	public String djqiu(String cplay, String attr) throws Exception{
		String lotterNum = SystemLotter.checkRandomNum2();
		String[] nums = lotterNum.split(",");
		int[] d = new int[nums.length];
		for (int i = 0; i < nums.length; i++) {
			d[i] = Integer.parseInt(nums[i]);
		}
		System.err.println("没替换之前: " + lotterNum);
		int k1 = d[0];
		int k2 = d[1];
		int k3 = d[2];
		int k4 = d[3];
		int k5 = d[4];
		switch (attr) {
		case "dan":
			switch (cplay) {
			case "d1q":
				if (k1 % 2 != 0) {
					lotterNum = djqiu(cplay, attr);
				}
				break;
			case "d2q":
				if (k2 % 2 != 0) {
					lotterNum = djqiu(cplay, attr);
				}

				break;
			case "d3q":
				if (k3 % 2 != 0) {
					lotterNum = djqiu(cplay, attr);
				}
				break;
			case "d4q":
				if (k4 % 2 != 0) {
					lotterNum = djqiu(cplay, attr);
				}
				break;
			case "d5q":
				if (k5 % 2 != 0) {
					lotterNum = djqiu(cplay, attr);
				}
				break;

			}

			break;
		case "shuang":

			switch (cplay) {
			case "d1q":
				if (k1 % 2 == 0) {
					lotterNum = djqiu(cplay, attr);
				}
				break;
			case "d2q":
				if (k2 % 2 == 0) {
					lotterNum = djqiu(cplay, attr);
				}
				break;
			case "d3q":
				if (k3 % 2 == 0) {
					lotterNum = djqiu(cplay, attr);
				}
				break;
			case "d4q":
				if (k4 % 2 == 0) {
					lotterNum = djqiu(cplay, attr);
				}
				break;
			case "d5q":
				if (k5 % 2 == 0) {
					lotterNum = djqiu(cplay, attr);
				}
				break;
			}
			break;
		case "da":
			switch (cplay) {
			case "d1q":
				if (k1 > 4 && k1 < 10) {
					lotterNum = djqiu(cplay, attr);
				}
				break;
			case "d2q":
				if (k2 > 4 && k2 < 10) {
					lotterNum = djqiu(cplay, attr);
				}
				break;
			case "d3q":
				if (k3 > 4 && k3 < 10) {
					lotterNum = djqiu(cplay, attr);
				}
				break;
			case "d4q":
				if (k4 > 4 && k4 < 10) {
					lotterNum = djqiu(cplay, attr);
				}
				break;
			case "d5q":
				if (k5 > 4 && k5 < 10) {
					lotterNum = djqiu(cplay, attr);
				}
				break;
			}
			break;
		case "xiao":
			switch (cplay) {
			case "d1q":
				if (k1 >= 0 && k1 < 5) {
					lotterNum = djqiu(cplay, attr);
				}
				break;
			case "d2q":
				if (k2 >= 0 && k2 < 5) {
					lotterNum = djqiu(cplay, attr);
				}
				break;
			case "d3q":
				if (k3 >= 0 && k3 < 5) {
					lotterNum = djqiu(cplay, attr);
				}
				break;
			case "d4q":
				if (k4 >= 0 && k4 < 5) {
					lotterNum = djqiu(cplay, attr);
				}
				break;
			case "d5q":
				if (k5 >= 0 && k5 < 5) {
					lotterNum = djqiu(cplay, attr);
				}
				break;
			}
			break;

		case "d1q":
			System.out.println("进来了1");
			System.out.println("dddd: " + cplay);
			switch (cplay) {
			case "d1q":
				System.out.println("进来了2");
				if (k1 == 0) {
					System.out.println("进来了3");
					lotterNum = djqiu(cplay, attr);

				}
				break;
			case "d2q":
				if (k2 == 0) {
					lotterNum = djqiu(cplay, attr);
				}
				break;
			case "d3q":
				if (k3 == 0) {
					lotterNum = djqiu(cplay, attr);
				}
				break;
			case "d4q":
				if (k4 == 0) {
					lotterNum = djqiu(cplay, attr);
				}
				break;
			case "d5q":
				if (k5 == 0) {
					lotterNum = djqiu(cplay, attr);
				}
				break;

			}
			break;
		case "d2q":
			switch (cplay) {
			case "d1q":
				if (k1 == 1) {
					lotterNum = djqiu(cplay, attr);
				}
				break;
			case "d2q":
				if (k2 == 1) {
					lotterNum = djqiu(cplay, attr);
				}
				break;
			case "d3q":
				if (k3 == 1) {
					lotterNum = djqiu(cplay, attr);
				}
				break;
			case "d4q":
				if (k4 == 1) {
					lotterNum = djqiu(cplay, attr);
				}
				break;
			case "d5q":
				if (k5 == 1) {
					lotterNum = djqiu(cplay, attr);
				}
				break;

			}

			break;
		case "d3q":
			switch (cplay) {
			case "d1q":
				if (k1 == 2) {
					lotterNum = djqiu(cplay, attr);
				}
				break;
			case "d2q":
				if (k2 == 2) {
					lotterNum = djqiu(cplay, attr);
				}
				break;
			case "d3q":
				if (k3 == 2) {
					lotterNum = djqiu(cplay, attr);
				}
				break;
			case "d4q":
				if (k4 == 2) {
					lotterNum = djqiu(cplay, attr);
				}
				break;
			case "d5q":
				if (k5 == 2) {
					lotterNum = djqiu(cplay, attr);
				}
				break;

			}

			break;
		case "d4q":
			switch (cplay) {
			case "d1q":
				if (k1 == 3) {
					lotterNum = djqiu(cplay, attr);
				}
				break;
			case "d2q":
				if (k2 == 3) {
					lotterNum = djqiu(cplay, attr);
				}

				break;
			case "d3q":
				if (k3 == 3) {
					lotterNum = djqiu(cplay, attr);
				}
				break;
			case "d4q":
				if (k4 == 3) {
					lotterNum = djqiu(cplay, attr);
				}
				break;
			case "d5q":
				if (k5 == 3) {
					lotterNum = djqiu(cplay, attr);
				}
				break;

			}
			break;
		case "d5q":
			switch (cplay) {
			case "d1q":
				if (k5 == 4) {
					lotterNum = djqiu(cplay, attr);
				}
				break;
			case "d2q":
				if (k5 == 4) {
					lotterNum = djqiu(cplay, attr);
				}

				break;
			case "d3q":
				if (k5 == 4) {
					lotterNum = djqiu(cplay, attr);
				}
				break;
			case "d4q":
				if (k5 == 4) {
					lotterNum = djqiu(cplay, attr);
				}
				break;
			case "d5q":
				if (k5 == 4) {
					lotterNum = djqiu(cplay, attr);
				}
				break;

			}
			break;
		case "d6q":
			switch (cplay) {
			case "d1q":
				System.out.println(111);
				if (k1 == 5) {
					System.out.println("k1的值：" + k1);
					lotterNum = djqiu(cplay, attr);
					System.out.println("执行次数");
				}
				break;
			case "d2q":
				if (k2 == 5) {
					lotterNum = djqiu(cplay, attr);
				}

				break;
			case "d3q":
				if (k3 == 5) {
					lotterNum = djqiu(cplay, attr);
				}
				break;
			case "d4q":
				if (k4 == 5) {
					lotterNum = djqiu(cplay, attr);
				}
				break;
			case "d5q":
				if (k5 == 5) {
					lotterNum = djqiu(cplay, attr);
				}
				break;

			}
			break;
		case "d7q":
			switch (cplay) {
			case "d1q":
				if (k1 == 6) {
					lotterNum = djqiu(cplay, attr);
				}
				break;
			case "d2q":
				if (k2 == 6) {
					lotterNum = djqiu(cplay, attr);
				}
				break;
			case "d3q":
				if (k3 == 6) {
					lotterNum = djqiu(cplay, attr);
				}
				break;
			case "d4q":
				if (k4 == 6) {
					lotterNum = djqiu(cplay, attr);
				}
				break;
			case "d5q":
				if (k5 == 6) {
					lotterNum = djqiu(cplay, attr);
				}
				break;

			}
			break;
		case "d8q":
			switch (cplay) {
			case "d1q":
				if (k1 == 7) {
					lotterNum = djqiu(cplay, attr);
				}
				break;
			case "d2q":
				if (k2 == 7) {
					lotterNum = djqiu(cplay, attr);
				}
				break;
			case "d3q":
				if (k3 == 7) {
					lotterNum = djqiu(cplay, attr);
				}
				break;
			case "d4q":
				if (k4 == 7) {
					lotterNum = djqiu(cplay, attr);
				}
				break;
			case "d5q":
				if (k5 == 7) {
					lotterNum = djqiu(cplay, attr);
				}
				break;

			}
			break;
		case "d9q":
			switch (cplay) {
			case "d1q":
				if (k1 == 8) {
					lotterNum = djqiu(cplay, attr);
				}
				break;
			case "d2q":
				if (k2 == 8) {
					lotterNum = djqiu(cplay, attr);
				}
				break;
			case "d3q":
				if (k3 == 8) {
					lotterNum = djqiu(cplay, attr);
				}
				break;
			case "d4q":
				if (k4 == 8) {
					lotterNum = djqiu(cplay, attr);
				}
				break;
			case "d5q":
				if (k5 == 8) {
					lotterNum = djqiu(cplay, attr);
				}
				break;

			}
			break;
		case "d10q":
			switch (cplay) {
			case "d1q":
				if (k1 == 9) {
					lotterNum = djqiu(cplay, attr);
				}
				break;
			case "d2q":
				if (k2 == 9) {
					lotterNum = djqiu(cplay, attr);
				}
				break;
			case "d3q":
				if (k3 == 9) {
					lotterNum = djqiu(cplay, attr);
				}
				break;
			case "d4q":
				if (k4 == 9) {
					lotterNum = djqiu(cplay, attr);
				}
				break;
			case "d5q":
				if (k5 == 9) {
					lotterNum = djm(cplay, attr);
				}
				break;

			}
		}
		System.err.println("替换后: " + lotterNum);
		return lotterNum;
	}

	/**
	 * 
	 * 方法名：q3 描述： 前三,中三,后三 TODO 参数： @return
	 * 
	 * @return: String
	 */
	public String q3(String cplay, String attr) throws Exception{
		String lotterNum = SystemLotter.checkRandomNum2();
		String[] nums = lotterNum.split(",");
		int[] d = new int[nums.length];
		for (int i = 0; i < nums.length; i++) {
			d[i] = Integer.parseInt(nums[i]);
		}
		switch (attr) {
		case "baozi":
			switch (cplay) {
			case "q3":
				if (d[0] == d[1] && d[0] == d[2]) {
					lotterNum = q3(cplay, attr);
				}
				break;
			case "z3":
				if (d[1] == d[2] && d[1] == d[3]) {
					lotterNum = q3(cplay, attr);
				}
				break;
			case "h3":
				if (d[2] == d[3] && d[2] == d[4]) {
					lotterNum = q3(cplay, attr);
				}
				break;
			}
			break;
		case "shunzi":
			switch (cplay) {
			case "q3":
				if (d[0] + 1 == d[1] && d[0] + 2 == d[2]) {
					lotterNum = q3(cplay, attr);
				} else if (d[0] + 2 == d[1] && d[0] + 1 == d[2]) {
					lotterNum = q3(cplay, attr);
				} else if (d[0] - 1 == d[1] && d[0] + 1 == d[2]) {
					lotterNum = q3(cplay, attr);
				} else if (d[0] + 1 == d[1] && d[0] - 1 == d[2]) {
					lotterNum = q3(cplay, attr);
				} else if (d[0] - 2 == d[1] && d[0] - 1 == d[2]) {
					lotterNum = q3(cplay, attr);
				} else if (d[0] - 1 == d[1] && d[0] - 2 == d[2]) {
					lotterNum = q3(cplay, attr);
				}
				break;
			case "z3":
				if (d[1] + 1 == d[2] && d[1] + 2 == d[3]) {
					lotterNum = q3(cplay, attr);
				} else if (d[1] + 2 == d[2] && d[1] + 1 == d[3]) {
					lotterNum = q3(cplay, attr);
				} else if (d[1] - 1 == d[2] && d[1] + 1 == d[3]) {
					lotterNum = q3(cplay, attr);
				} else if (d[1] + 1 == d[2] && d[1] - 1 == d[3]) {
					lotterNum = q3(cplay, attr);
				} else if (d[1] - 2 == d[2] && d[1] - 1 == d[3]) {
					lotterNum = q3(cplay, attr);
				} else if (d[1] - 1 == d[2] && d[1] - 2 == d[3]) {
					lotterNum = q3(cplay, attr);
				}
				break;
			case "h3":
				if (d[2] + 1 == d[3] && d[2] + 2 == d[4]) {
					lotterNum = q3(cplay, attr);
				} else if (d[2] + 2 == d[3] && d[2] + 1 == d[4]) {
					lotterNum = q3(cplay, attr);
				} else if (d[2] - 1 == d[3] && d[2] + 1 == d[4]) {
					lotterNum = q3(cplay, attr);
				} else if (d[2] + 1 == d[3] && d[2] - 1 == d[4]) {
					lotterNum = q3(cplay, attr);
				} else if (d[2] - 2 == d[3] && d[2] - 1 == d[4]) {
					lotterNum = q3(cplay, attr);
				} else if (d[2] - 1 == d[3] && d[2] - 2 == d[4]) {
					lotterNum = q3(cplay, attr);
				}
				break;
			}
			break;
		case "duizi":
			switch (cplay) {
			case "q3":
				if ((d[0] != d[1] || d[0] != d[2])) {
					if (d[0] == d[1] || d[0] == d[2] || d[1] == d[2]) {
						lotterNum = q3(cplay, attr);
					}
				}
				break;
			case "z3":
				if (d[1] != d[2] || d[1] != d[3]) {
					if (d[1] == d[2] || d[1] == d[3] || d[2] == d[3]) {
						lotterNum = q3(cplay, attr);
					}
				}
				break;
			case "h3":
				if (d[2] != d[3] || d[2] != d[4]) {
					if (d[2] == d[3] || d[2] == d[4] || d[3] == d[4]) {
						lotterNum = q3(cplay, attr);
					}
				}
				break;
			}
			break;
		case "banshun":
			switch (cplay) {
			case "q3":

				break;
			case "z3":

				break;
			case "h3":

				break;
			}
			break;
		case "zaliu":
			switch (cplay) {
			case "q3":

				break;
			case "z3":

				break;
			case "h3":

				break;
			}
			break;
		}
		return lotterNum;
	}

	/**
	 * 
	 * 方法名：zhix 描述： 前 TODO 参数： @return
	 * 
	 * @return: String
	 */
	public String zhix(String cplay, String attr) throws Exception{
		String lotterNum = SystemLotter.checkRandomNum2();
		String[] data = lotterNum.split(",");
		int[] d = new int[data.length];
		for (int i = 0; i < data.length; i++) {
			d[i] = Integer.parseInt(data[i]);
		}
		switch (attr) {
		case "d1q":
		case "d2q":
		case "d3q":
		case "d4q":
		case "d5q":
		case "d6q":
		case "d7q":
		case "d8q":
		case "d9q":
		case "d10q":
			switch (attr) {
			case "d1q":
				attr = "0";
				break;
			case "d2q":
				attr = "1";
				break;
			case "d3q":
				attr = "2";
				break;
			case "d4q":
				attr = "3";
				break;
			case "d5q":
				attr = "4";
				break;
			case "d6q":
				attr = "5";
				break;
			case "d7q":
				attr = "6";
				break;
			case "d8q":
				attr = "7";
				break;
			case "d9q":
				attr = "8";
				break;
			case "d10q":
				attr = "9";
				break;
			}
			switch (cplay) {
			case "q2zhix0":
				if (attr.equals(data[0])) {
					lotterNum = zhix(cplay, attr);
				}
				break;
			case "q2zhix1":
				if (attr.equals(data[1])) {
					lotterNum = zhix(cplay, attr);
				}
				break;
			case "h2zhix0":
				if (attr.equals(data[3])) {
					lotterNum = zhix(cplay, attr);
				}
				break;
			case "h2zhix1":
				if (attr.equals(data[4])) {
					lotterNum = zhix(cplay, attr);
				}
				break;
			case "q3zhix0":
				if (attr.equals(data[0])) {
					lotterNum = zhix(cplay, attr);
				}
				break;
			case "q3zhix1":
				if (attr.equals(data[1])) {
					lotterNum = zhix(cplay, attr);
				}
				break;
			case "q3zhix2":
				if (attr.equals(data[2])) {
					lotterNum = zhix(cplay, attr);
				}
				break;
			case "z3zhix0":
				if (attr.equals(data[1])) {
					lotterNum = zhix(cplay, attr);
				}
				break;
			case "z3zhix1":
				if (attr.equals(data[2])) {
					lotterNum = zhix(cplay, attr);
				}
				break;
			case "z3zhix2":
				if (attr.equals(data[3])) {
					lotterNum = zhix(cplay, attr);
				}
				break;
			case "h3zhix0":
				if (attr.equals(data[2])) {
					lotterNum = zhix(cplay, attr);
				}
				break;
			case "h3zhix1":
				if (attr.equals(data[3])) {
					lotterNum = zhix(cplay, attr);
				}
				break;
			case "h3zhix2":
				if (attr.equals(data[4])) {
					lotterNum = zhix(cplay, attr);
				}
				break;
			case "q2zx":
				if (attr.equals(data[0]) || attr.equals(data[1]) || !data[0].equals(data[1])) {
					lotterNum = zhix(cplay, attr);
				}
				break;
			case "h2zx":
				if (attr.equals(data[3]) || attr.equals(data[4]) || !data[0].equals(data[1])) {
					lotterNum = zhix(cplay, attr);
				}
				break;
			case "q3z6":
				if (data[0].equals(attr) && data[1].equals(attr) && data[2].equals(attr)) {
					if (!data[0].equals(data[1]) && !data[0].equals(data[2]) && !data[1].equals(data[2])) {
						lotterNum = zhix(cplay, attr);
					}
				}
				break;
			case "z3z6":
				if (data[1].equals(attr) && data[2].equals(attr) && data[3].equals(attr)) {
					if (!data[0].equals(data[1]) && !data[0].equals(data[2]) && !data[1].equals(data[2])) {
						lotterNum = zhix(cplay, attr);
					}
				}

				break;
			case "h3z6":
				if (data[2].equals(attr) && data[3].equals(attr) && data[4].equals(attr)) {
					if (!data[0].equals(data[1]) && !data[0].equals(data[2]) && !data[1].equals(data[2])) {
						lotterNum = zhix(cplay, attr);
					}
				}

				break;
			case "q3z3":
				if (attr.equals(data[0]) && attr.equals(data[1]) && attr.equals(data[2])) {
					if (d[0] == d[1] || d[0] == d[2] || d[1] == d[2]) {
						lotterNum = zhix(cplay, attr);
					}
				}
				break;
			case "z3z3":
				if (attr.equals(data[1]) && attr.equals(data[2]) && attr.equals(data[3])) {
					if (d[1] == d[2] || d[1] == d[3] || d[2] == d[3]) {
						lotterNum = zhix(cplay, attr);
					}
				}
				break;
			case "h3z3":
				if (attr.equals(data[2]) && attr.equals(data[3]) && attr.equals(data[4])) {
					if (d[2] == d[3] || d[2] == d[4] || d[3] == d[4]) {
						lotterNum = zhix(cplay, attr);
					}
				}
				break;
			}
			break;
		}
		return lotterNum;
	}
	
	/**
	 * 
	 * 方法名：sfk3dq 描述： 三分快三控制开奖 TODO:3fk3
	 *  参数： @return
	 * 
	 * @return: String
	 */
	public String sfk3dq(String cplay, String attr) throws Exception{
		String lotterNum = SystemLotter.checkRandomNum3();
		String[] data = lotterNum.split(",");
		int[] d = new int[data.length];
		for (int i = 0; i < data.length; i++) {
			d[i] = Integer.parseInt(data[i]);
		}
		int sm = 0;
		switch (attr) {
		case "d1q":
		case "d2q":
		case "d3q":
		case "d4q":
		case "d5q":
		case "d6q":
			switch (attr) {
			case "d1q":
				attr = "1";
				sm=1;
				break;
			case "d2q":
				attr = "2";
				sm=2;
				break;
			case "d3q":
				attr = "3";
				sm=3;
				break;
			case "d4q":
				attr = "4";
				sm=4;
				break;
			case "d5q":
				attr = "5";
				sm=5;
				break;
			case "d6q":
				attr = "6";
				sm=6;
				break;
			}
			switch (cplay) {
			case "c1gh":
				if (attr.equals(data[0])||attr.equals(data[1])||attr.equals(data[2])) {
					lotterNum = sfk3dq(cplay, attr);
				}
				break;
			case "ethfx":
				if ((sm == d[0] && sm == d[1] && d[0] == d[1])||(sm == d[1] && sm == d[2] && d[1] == d[2])) {
					lotterNum = sfk3dq(cplay, attr);
				}
				break;
			case "ethdx1":
			case "ethdx2":
				if ((d[0] == d[1] && sm == d[0] && sm == d[1] && sm == d[2])||(d[1] == d[2] && sm == d[0] && sm == d[1] && sm == d[2])) {
					lotterNum = sfk3dq(cplay, attr);
				}
				break;
			case "ebth":
				if (attr.equals(data[0])||attr.equals(data[1])||attr.equals(data[2])) {
					lotterNum = sfk3dq(cplay, attr);
				}
				break;
			case "ebthdt1":
			case "ebthdt2":
				if (attr.equals(data[0])||attr.equals(data[1])||attr.equals(data[2])) {
					lotterNum = sfk3dq(cplay, attr);
				}
				break;
			case "sthdx":
				if ((d[0] == d[1]) && (d[0] == d[2]) && (sm == d[0])
						&& (sm == d[1]) && (sm == d[2])) {
					lotterNum = sfk3dq(cplay, attr);
				}
				break;
			case "sbth":
				if (d[0] != d[1] && d[0] != d[2] && d[1] != d[2]) {
					if (sm == d[0]||sm==d[1]||sm==d[2]) {
						lotterNum = sfk3dq(cplay, attr);
					}
				}
				break;
			}
			break;
		case "slhtx":
			if (d[0] + 1 == d[1] && d[0] + 2 == d[2]) {
				lotterNum = sfk3dq(cplay, attr);
			}
			break;
		case "sthtx":
			if (d[0] == d[1] && d[0] == d[2]) {
				lotterNum = sfk3dq(cplay, attr);
			}
			break;
		case "baozi":
			if (d[0] == d[1] && d[0] == d[2]) {
				lotterNum = sfk3dq(cplay, attr);
			}
			break;
		case "shunzi":
			if (d[0] + 1 == d[1] && d[0] + 2 == d[2]) {
				lotterNum = sfk3dq(cplay, attr);
			} else if (d[0] + 2 == d[1] && d[0] + 1 == d[2]) {
				lotterNum = sfk3dq(cplay, attr);
			} else if (d[0] - 1 == d[1] && d[0] + 1 == d[2]) {
				lotterNum = sfk3dq(cplay, attr);
			} else if (d[0] + 1 == d[1] && d[0] - 1 == d[2]) {
				lotterNum = sfk3dq(cplay, attr);
			} else if (d[0] - 2 == d[1] && d[0] - 1 == d[2]) {
				lotterNum = sfk3dq(cplay, attr);
			} else if (d[0] - 1 == d[1] && d[0] - 2 == d[2]) {
				lotterNum = sfk3dq(cplay, attr);
			}
			break;
		case "duizi":
			if ((d[0] != d[1] || d[0] != d[2])) {
				if (d[0] == d[1] || d[0] == d[2] || d[1] == d[2]) {
					lotterNum = sfk3dq(cplay, attr);
				}
			}
			break;
		case "banshun":
			break;
		case "zaliu":
			boolean flag1 = d[0] + 1 != d[1];
			boolean flag2 = d[0] + 1 != d[2];
			boolean flag3 = d[1] + 1 != d[2];
			boolean flag4 = d[0] - 1 != d[1];
			boolean flag5 = d[0] - 1 != d[2];
			boolean flag6 = d[1] - 1 != d[2];
			boolean flag13 = d[0] != d[1] && d[0] != d[2];
			boolean flag14 = d[0] != d[1];
			boolean flag15 = d[0] != d[2];
			boolean flag16 = d[1] != d[2];
			if (flag1 && flag2 && flag3 && flag4 && flag5 && flag6) {
				if (flag13 && (flag14 || flag15 || flag16)) {
					lotterNum = sfk3dq(cplay, attr);
				}
			}
			break;
		}
		return lotterNum;
	}
	
	/**
	 * 
	 * 方法名：sfk3dq 描述： 三分快三控制开奖 TODO:3fk3
	 *  参数： @return
	 * 
	 * @return: String
	 */
	public String sfk3zhs(String attr) throws Exception{
		String lotterNum = SystemLotter.checkRandomNum3();
		String[] data = lotterNum.split(",");
		int[] d = new int[data.length];
		for (int i = 0; i < data.length; i++) {
			d[i] = Integer.parseInt(data[i]);
		}
		int sm = 0;
		int o = (d[0] + d[1] + d[2]);
		switch (attr) {
			case "d1q":
			case "d2q":
			case "d3q":
			case "d4q":
			case "d5q":
			case "d6q":
			case "d7q":
			case "d8q":
			case "d9q":
			case "d10q":
			case "d11q":
			case "d12q":
			case "d13q":
			case "d14q":
			case "d15q":
			case "d16q":
				switch (attr) {
				case "d1q":
					sm = 3;
					break;
				case "d2q":
					sm = 4;
					break;
				case "d3q":
					sm = 5;
					break;
				case "d4q":
					sm = 6;
					break;
				case "d5q":
					sm = 7;
					break;
				case "d6q":
					sm = 8;
					break;
				case "d7q":
					sm = 9;
					break;
				case "d8q":
					sm = 10;
					break;
				case "d9q":
					sm = 11;
					break;
				case "d10q":
					sm = 12;
					break;
				case "d11q":
					sm = 13;
					break;
				case "d12q":
					sm = 14;
					break;
				case "d13q":
					sm = 15;
					break;
				case "d14q":
					sm = 16;
					break;
				case "d15q":
					sm = 17;
					break;
				case "d16q":
					sm = 18;
					break;
				}
				if (sm==o) {
					lotterNum = sfk3zhs(attr);
				}
				break;
			case "da":
				if (o  > 10 && o < 19) {
					lotterNum = sfk3zhs(attr);
				}
				break;
			case "xiao":
				if (o < 11 && o > 2) {
					lotterNum = sfk3zhs(attr);
				}
				break;
			case "dan":
				if (o % 2 != 0) {
					lotterNum = sfk3zhs( attr);
				}
				break;
			case "shuang":
				if (o % 2 == 0) {
					lotterNum = sfk3zhs(attr);
				}
				break;
		}
		return lotterNum;
	}


	public String c1gh(List<Integer> attr) throws Exception{
		int m =0;
		String lotterNum = SystemLotter.checkRandomNum3();
		String[] data = lotterNum.split(",");
		int[] d = new int[data.length];
		for (int i = 0; i < data.length; i++) {
			d[i] = Integer.parseInt(data[i]);
		}
		//豹子--对子
		if(d[0]==d[1]||d[0]==d[2]||d[1]==d[2]) {
			lotterNum = c1gh(attr);
		}
		//杂六
		if(attr.size()<5) {
			for(int i=0;i<attr.size();i++) {
					if(attr.get(i)==d[0]||attr.get(i)==d[1]||attr.get(i)==d[2]) {
						m++;
					}
				}
			if(m>2) {
				lotterNum = c1gh(attr);
			}
		}
		return lotterNum;
	}


	/**
	 * 六合彩1-49
	   *   方法名：dsq   
	   *   描述：                       TODO   
	   *   参数：    @param cplay
	   *   参数：    @param attr
	   *   参数：    @return 
	 * @return: String
	 */
	public String dsq(String cplay, String attr) throws Exception{
		String lotterNum = SystemLotter.checkRandomNum4();
		String[] data = lotterNum.split(",");
		int[] d = new int[data.length];
		for (int i = 0; i < data.length; i++) {
			d[i] = Integer.parseInt(data[i]);
		}
		String[] tm = { "01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12", "13", "14", "15", "16",
				"17", "18", "19", "20", "21", "22", "23", "24", "25", "26", "27", "28", "29", "30", "31", "32", "33",
				"34", "35", "36", "37", "38", "39", "40", "41", "42", "43", "44", "45", "46", "47", "48", "49" };

			switch (attr) {
			case "d1q":
				attr = "01";
				break;
			case "d2q":
				attr = "02";
				break;
			case "d3q":
				attr = "03";
				break;
			case "d4q":
				attr = "04";
				break;
			case "d5q":
				attr = "05";
				break;
			case "d6q":
				attr = "06";
				break;
			case "d7q":
				attr = "07";
				break;
			case "d8q":
				attr = "08";
				break;
			case "d9q":
				attr = "09";
				break;
			case "d10q":
				attr = "10";
				break;
			case "d11q":
				attr = "11";
				break;
			case "d12q":
				attr = "12";
				break;
			case "d13q":
				attr = "13";
				break;
			case "d14q":
				attr = "14";
				break;
			case "d15q":
				attr = "15";
				break;
			case "d16q":
				attr = "16";
				break;
			case "d17q":
				attr = "17";
				break;
			case "d18q":
				attr = "18";
				break;
			case "d19q":
				attr = "19";
				break;
			case "d20q":
				attr = "20";
				break;
			case "d21q":
				attr = "21";
				break;
			case "d22q":
				attr = "22";
				break;
			case "d23q":
				attr = "23";
				break;
			case "d24q":
				attr = "24";
				break;
			case "d25q":
				attr = "25";
				break;
			case "d26q":
				attr = "26";
				break;
			case "d27q":
				attr = "27";
				break;
			case "d28q":
				attr = "28";
				break;
			case "d29q":
				attr = "29";
				break;
			case "d30q":
				attr = "30";
				break;
			case "d31q":
				attr = "31";
				break;
			case "d32q":
				attr = "32";
				break;
			case "d33q":
				attr = "33";
				break;
			case "d34q":
				attr = "34";
				break;
			case "d35q":
				attr = "35";
				break;
			case "d36q":
				attr = "36";
				break;
			case "d37q":
				attr = "37";
				break;
			case "d38q":
				attr = "38";
				break;
			case "d39q":
				attr = "39";
				break;
			case "d40q":
				attr = "40";
				break;
			case "d41q":
				attr = "41";
				break;
			case "d42q":
				attr = "42";
				break;
			case "d43q":
				attr = "43";
				break;
			case "d44q":
				attr = "44";
				break;
			case "d45q":
				attr = "45";
				break;
			case "d46q":
				attr = "46";
				break;
			case "d47q":
				attr = "47";
				break;
			case "d48q":
				attr = "48";
				break;
			case "d49q":
				attr = "49";
				break;
			}
			switch (cplay) {
			case "tma":
			case "tmb":
				for (int j = 0; j < tm.length; j++) {
					if (attr.equals(data[6]) && tm[j].equals(attr) && data[6].equals(tm[j])) {
						lotterNum = dsq(cplay, attr);
					}
				}
				break;
			case "dp":
				for (int k = 0; k < data.length; k++) {
					for (int j = 0; j < tm.length; j++) {
						if (attr.equals(data[k]) && tm[j].equals(attr)) {
							lotterNum = dsq(cplay, attr);
						}
					}
				}
				break;
			case "p2z2":
			case "p3z2":
				int a1 = 0;
				for (int j = 0; j < data.length - 1; j++) {
					if (attr.equals(data[j])) {
						a1++;
					}
				}
				if (a1 > 1) {
					lotterNum = dsq(cplay, attr);
				}
				break;
			case "p3z3":
				int a2 = 0;
				for (int j = 0; j < data.length - 1; j++) {
					if (attr.equals(data[j])) {
						a2++;
					}
				}
				if (a2 > 2) {
					lotterNum = dsq(cplay, attr);
				}
				break;
			case "wbz":
			case "lbz":
			case "qbz":
			case "bbz":
			case "jbz":
			case "shbz":
			case "sh1bz":
			case "sh2bz":
			case "sh3bz":
			case "sh4bz":
			case "sh5bz":
				int a3 = 0;
				for (int j = 0; j < data.length; j++) {
					if (attr.equals(data[j])) {
						a3++;
					}
				}
				if (a3 == 0) {
					lotterNum = dsq(cplay, attr);
				}
			break;
		}
		return lotterNum;
	}

	/**
	 * 六合彩鼠-猪
	   *   方法名：lhcshu   
	   *   描述：                       TODO   
	   *   参数：    @param cplay
	   *   参数：    @param attr
	   *   参数：    @return 
	 * @return: String
	 */
	public String lhcshu(String cplay, String attr) throws Exception{
		String lotterNum = SystemLotter.checkRandomNum4();
		String[] data = lotterNum.split(",");
		int[] d = new int[data.length];
		for (int i = 0; i < data.length; i++) {
			d[i] = Integer.parseInt(data[i]);
		}
		CheckOrder orc = new CheckOrder();
		Map<String, Object> map = orc.attribute1();
		String[] sx1 = (String[]) map.get("attr");
		String[][] sx2 = (String[][]) map.get("content");
		switch (attr) {
		case "shu":
			attr = "鼠";
			break;
		case "niu":
			attr = "牛";
			break;
		case "hu":
			attr = "虎";
			break;
		case "tu":
			attr = "兔";
			break;
		case "longs":
			attr = "龙";
			break;
		case "she":
			attr = "蛇";
			break;
		case "ma":
			attr = "马";
			break;
		case "yang":
			attr = "羊";
			break;
		case "hou":
			attr = "猴";
			break;
		case "ji":
			attr = "鸡";
			break;
		case "gou":
			attr = "狗";
			break;
		case "zhu":
			attr = "猪";
			break;
		}
		switch (cplay) {
		case "tmsx":
			for (int i = 0; i < sx1.length; i++) {
				for (int j = 0; j < sx2[i].length; j++) {
						if (sx1[i].equals(attr) && sx2[i][j].equals(data[6])) {
							lotterNum = lhcshu(cplay,attr);
						}
					}
				}
			break;
		case "sxzt":
		case "wxzt":
		case "lxzt":
			for (int i = 0; i < sx1.length; i++) {
				for (int j = 0; j < sx2[i].length; j++) {
						if (sx2[i][j].equals(data[6]) && attr.equals(sx1[i])) {
							lotterNum = lhcshu(cplay,attr);
						}
					}
				}
			break;
		case "pt1x":
			for (int i = 0; i < sx1.length; i++) {
				for (int j = 0; j < sx2[i].length; j++) {
						for (int n = 0; n < data.length; n++) {
							if (sx2[i][j].equals(data[n]) && attr.equals(sx1[i])) {// i就是data中对应的生肖
								lotterNum = lhcshu(cplay,attr);
							}
						}
					}
				}
			break;
		case "pt2x":
			int a1 = 0;
			for (int i = 0; i < sx1.length; i++) {
				for (int j = 0; j < sx2[i].length; j++) {
						for (int n = 0; n < data.length; n++) {
							if (sx2[i][j].equals(data[n]) && attr.equals(sx1[i])) {// i就是data中对应的生肖
								a1++;
							}
						}
					}
				}
			if (a1 > 1) {
				lotterNum = lhcshu(cplay,attr);
			}
			break;
		case "pt3x":
			int a2 = 0;
			for (int i = 0; i < sx1.length; i++) {
				for (int j = 0; j < sx2[i].length; j++) {
						for (int n = 0; n < data.length; n++) {
							if (sx2[i][j].equals(data[n]) && attr.equals(sx1[i])) {// i就是data中对应的生肖
								a2++;
							}
						}
					}
				}
			if (a2 > 2) {
				lotterNum = lhcshu(cplay,attr);
			}
			break;
		case "pt4x":
			int a3 = 0;
			for (int i = 0; i < sx1.length; i++) {
				for (int j = 0; j < sx2[i].length; j++) {
						for (int n = 0; n < data.length; n++) {
							if (sx2[i][j].equals(data[n]) && attr.equals(sx1[i])) {// i就是data中对应的生肖
								a3++;
							}
						}
					}
				}
			if (a3 > 3) {
				lotterNum = lhcshu(cplay,attr);
			}
			break;
		}
		return lotterNum;
	}

	/**
	 * 六合彩单双大小
	   *   方法名：lhcdsdx   
	   *   描述：                       TODO   
	   *   参数：    @param cplay
	   *   参数：    @param attr
	   *   参数：    @return 
	 * @return: String
	 */
	public String lhcdsdx(String cplay, String attr) throws Exception{
		String lotterNum = SystemLotter.checkRandomNum4();
		String[] data = lotterNum.split(",");
		int[] d = new int[data.length];
		for (int i = 0; i < data.length; i++) {
			d[i] = Integer.parseInt(data[i]);
		}
		switch (cplay) {
		case "dxds":
				if (d[6] % 2 != 0 && attr.equals("dan")) {
					lotterNum = lhcdsdx(cplay,attr);
				}
				if (d[6] % 2 == 0 && attr.equals("shuang")) {
					lotterNum = lhcdsdx(cplay,attr);
				}
				if (d[6] > 24 && attr.equals("da")) {
					lotterNum = lhcdsdx(cplay,attr);
				}
				if (d[6] < 25 && attr.equals("xiao")) {
					lotterNum = lhcdsdx(cplay,attr);
				}
			break;
		case "zh":
			int dh = d[0] + d[1] + d[2] + d[3] + d[4] + d[5] + d[6];
			if (attr.equals("dan")) {
				if (dh % 2 != 0) {
					lotterNum = lhcdsdx(cplay,attr);
				}
			}
			if (attr.equals("shuang")) {
				if (dh % 2 == 0) {
					lotterNum = lhcdsdx(cplay,attr);
				}
			}
			if (attr.equals("da")) {
				if (dh > 174) {
					lotterNum = lhcdsdx(cplay,attr);
				}
			}
			if (attr.equals("xiao")) {
				if (dh < 175) {
					lotterNum = lhcdsdx(cplay,attr);
				}
			}
			break;
		case "hs":
			int hss = (d[6] % 100) / 10 + d[6] % 10;
			if (attr.equals("dan")) {
				if (hss % 2 != 0) {
					lotterNum = lhcdsdx(cplay,attr);
				}
			}
			if (attr.equals("shuang")) {
				if (hss % 2 == 0) {
					lotterNum = lhcdsdx(cplay,attr);
				}
			}
			if (attr.equals("da")) {
				if (hss > 6) {
					lotterNum = lhcdsdx(cplay,attr);
				}
			}
			if (attr.equals("xiao")) {
				if (hss < 7) {
					lotterNum = lhcdsdx(cplay,attr);
				}
			}
			break;
		}
		return lotterNum;
	}


	/**
	 * 六合彩多少尾
	   *   方法名：dsw   
	   *   描述：                       TODO   
	   *   参数：    @param cplay
	   *   参数：    @param attr
	   *   参数：    @return 
	 * @return: String
	 */
	public String dsw(String cplay, String attr) throws Exception{
		String lotterNum = SystemLotter.checkRandomNum4();
		String[] data = lotterNum.split(",");
		int[] d = new int[data.length];
		for (int i = 0; i < data.length; i++) {
			d[i] = Integer.parseInt(data[i]);
		}
		String[][] w2 = { { "10", "20", "30", "40", "50" }, { "01", "11", "21", "31", "41" },
				{ "02", "12", "22", "32", "42" }, { "03", "13", "23", "33", "43" },
				{ "04", "14", "24", "34", "44" }, { "05", "15", "25", "35", "45" },
				{ "06", "16", "26", "36", "46" }, { "07", "17", "27", "37", "47" },
				{ "08", "18", "28", "38", "48" }, { "09", "19", "29", "39", "49" } };
		String[] w3 = { "0", "1", "2", "3", "4", "5", "6", "7", "8", "9" };
		switch (attr) {
			case "d1q":
				attr = "0";
				break;
			case "d2q":
				attr = "1";
				break;
			case "d3q":
				attr = "2";
				break;
			case "d4q":
				attr = "3";
				break;
			case "d5q":
				attr = "4";
				break;
			case "d6q":
				attr = "5";
				break;
			case "d7q":
				attr = "6";
				break;
			case "d8q":
				attr = "7";
				break;
			case "d9q":
				attr = "8";
				break;
			case "d10q":
				attr = "9";
				break;
		}
		switch (cplay) {
		case "pt1w":
		case "pt2w":
		case "pt3w":
		case "pt4w":
			for (int i = 0; i < w3.length; i++) {
				for (int j = 0; j < w2[i].length; j++) {
						for (int n = 0; n < data.length; n++) {
							if (w2[i][j].equals(data[n]) && attr.equals(w3[i])) {
								lotterNum = dsw(cplay,attr);
							}
						}
					}
				}
			break;
		}
		return lotterNum;
	}

	/**
	 * 六合彩家禽野兽
	   *   方法名：jqys   
	   *   描述：                       TODO   
	   *   参数：    @param attr
	   *   参数：    @return 
	 * @return: String
	 */
	public String jqys(String attr) throws Exception{
		String lotterNum = SystemLotter.checkRandomNum4();
		String[] data = lotterNum.split(",");
		int[] d = new int[data.length];
		for (int i = 0; i < data.length; i++) {
			d[i] = Integer.parseInt(data[i]);
		}
		CheckOrder orc = new CheckOrder();
		Map<String, Object> map = orc.attribute1();
		String[] sx1 = (String[]) map.get("attr");
		String[][] sx2 = (String[][]) map.get("content");
		/** 家禽野兽 */
		String[][][] jqyss = new String[4][6][5];
		List<Integer> idss = new ArrayList<Integer>();
		String[] sxss = { "鼠", "牛", "虎", "兔", "龙", "蛇", "马", "羊", "猴", "鸡", "狗", "猪" };
		for (int i10 = 0; i10 < sxss.length; i10++) {
			for (int j10 = 0; j10 < sx1.length; j10++) {
				if (sxss[i10].equals(sx1[j10])) {
					idss.add(j10);
				}
			}
		}
		String[] jqysss = { "家肖", "野肖", "天肖", "地肖" };
		/** jiax */
		jqyss[0][0] = sx2[idss.get(1)];
		jqyss[0][1] = sx2[idss.get(6)];
		jqyss[0][2] = sx2[idss.get(7)];
		jqyss[0][3] = sx2[idss.get(9)];
		jqyss[0][4] = sx2[idss.get(10)];
		jqyss[0][5] = sx2[idss.get(11)];
		/** yex */
		jqyss[1][0] = sx2[idss.get(0)];
		jqyss[1][1] = sx2[idss.get(2)];
		jqyss[1][2] = sx2[idss.get(3)];
		jqyss[1][3] = sx2[idss.get(4)];
		jqyss[1][4] = sx2[idss.get(5)];
		jqyss[1][5] = sx2[idss.get(8)];
		/** tianx */
		jqyss[2][0] = sx2[idss.get(1)];
		jqyss[2][1] = sx2[idss.get(3)];
		jqyss[2][2] = sx2[idss.get(4)];
		jqyss[2][3] = sx2[idss.get(6)];
		jqyss[2][4] = sx2[idss.get(8)];
		jqyss[2][5] = sx2[idss.get(11)];
		/** dix */
		jqyss[3][0] = sx2[idss.get(0)];
		jqyss[3][1] = sx2[idss.get(2)];
		jqyss[3][2] = sx2[idss.get(5)];
		jqyss[3][3] = sx2[idss.get(7)];
		jqyss[3][4] = sx2[idss.get(9)];
		jqyss[3][5] = sx2[idss.get(10)];
		switch (attr) {
		case "jiaxiao":
			attr = "家肖";
			break;
		case "yexiao":
			attr = "野肖";
			break;
		case "tianxiao":
			attr = "天肖";
			break;
		case "dixiao":
			attr = "地肖";
			break;
		}
		for (int i = 0; i < jqyss.length; i++) {
			for (int j = 0; j < jqyss[i].length; j++) {
				for (int k = 0; k < jqyss[i][j].length; k++) {
					if (jqyss[i][j][k].equals(data[6]) && jqysss[i].equals(attr) && attr.equals("家肖")) {
						lotterNum = jqys(attr);
					}
					if (jqyss[i][j][k].equals(data[6]) && jqysss[i].equals(attr) && attr.equals("野肖")) {
						lotterNum = jqys(attr);
					}
					if (jqyss[i][j][k].equals(data[6]) && jqysss[i].equals(attr) && attr.equals("天肖")) {
						lotterNum = jqys(attr);
					}
					if (jqyss[i][j][k].equals(data[6]) && jqysss[i].equals(attr) && attr.equals("地肖")) {
						lotterNum = jqys(attr);
					}
				}
			}
		}
		return lotterNum;
	}

	/**
	 *  六合彩头数
	   *   方法名：toushu   
	   *   描述：                       TODO   
	   *   参数：    @param attr
	   *   参数：    @return 
	 * @return: String
	 */
	public String toushu(String attr) throws Exception{
		String lotterNum = SystemLotter.checkRandomNum4();
		String[] data = lotterNum.split(",");
		int[] d = new int[data.length];
		for (int i = 0; i < data.length; i++) {
			d[i] = Integer.parseInt(data[i]);
		}
		/** 头数 */
		String[] t1 = { "0头", "1头", "2头", "3头", "4头" };
		String[][] t2 = { { "01", "02", "03", "04", "05", "06", "07", "08", "09" },
				{ "10", "11", "12", "13", "14", "15", "16", "17", "18", "19" },
				{ "20", "21", "22", "23", "24", "25", "26", "27", "28", "29" },
				{ "30", "31", "32", "33", "34", "35", "36", "37", "38", "39" },
				{ "40", "41", "42", "43", "44", "45", "46", "47", "48", "49" } };

		switch (attr) {
		case "lingtou":
			attr = "0头";
			break;
		case "yitou":
			attr = "1头";
			break;
		case "ertou":
			attr = "2头";
			break;
		case "santou":
			attr = "3头";
			break;
		case "sitou":
			attr = "4头";
			break;
		}
		for (int i = 0; i < t2.length; i++) {
			for (int j = 0; j < t2[i].length; j++) {
				for (int k = 0; k < t1.length; k++) {
					if (t2[i][j].equals(data[6]) && t1[k].equals(attr) && (t1[i].equals(attr))) {
						lotterNum = toushu(attr);
					}
				}
			}
		}
		return lotterNum;
	}

	/**
	 * 六合彩尾数
	   *   方法名：weishu   
	   *   描述：                       TODO   
	   *   参数：    @param attr
	   *   参数：    @return 
	 * @return: String
	 */
	public String weishu(String attr) throws Exception{
		String lotterNum = SystemLotter.checkRandomNum4();
		String[] data = lotterNum.split(",");
		int[] d = new int[data.length];
		for (int i = 0; i < data.length; i++) {
			d[i] = Integer.parseInt(data[i]);
		}
		/** 尾数 */
		String[] w1 = { "0尾", "1尾", "2尾", "3尾", "4尾", "5尾", "6尾", "7尾", "8尾", "9尾" };
		String[][] w2 = { { "10", "20", "30", "40", "50" }, { "01", "11", "21", "31", "41" },
				{ "02", "12", "22", "32", "42" }, { "03", "13", "23", "33", "43" }, { "04", "14", "24", "34", "44" },
				{ "05", "15", "25", "35", "45" }, { "06", "16", "26", "36", "46" }, { "07", "17", "27", "37", "47" },
				{ "08", "18", "28", "38", "48" }, { "09", "19", "29", "39", "49" } };
		switch (attr) {
		case "lingwei":
			attr = "0尾";
			break;
		case "yiwei":
			attr = "1尾";
			break;
		case "erwei":
			attr = "2尾";
			break;
		case "sanwei":
			attr = "3尾";
			break;
		case "siwei":
			attr = "4尾";
			break;
		case "wuwei":
			attr = "5尾";
			break;
		case "liuwei":
			attr = "6尾";
			break;
		case "qiwei":
			attr = "7尾";
			break;
		case "bawei":
			attr = "8尾";
			break;
		case "jiuwei":
			attr = "9尾";
			break;
		case "da":
			attr = "大";
			break;
		case "xiao":
			attr = "小";
			break;
		case "dan":
			attr = "单";
			break;
		case "shuang":
			attr = "双";
			break;
		}
		for (int i = 0; i < w2.length; i++) {
			for (int j = 0; j < w2[i].length; j++) {
				for (int k = 0; k < w1.length; k++) {
					if (w2[i][j].equals(data[6])) {
						if (w1[k].equals(attr)) {
							lotterNum = weishu(attr);
						}
						if (attr.equals("大")) {
							if (d[6] % 10 > 4 && d[6] % 10 < 10) {
								lotterNum = weishu(attr);
							}
						}
						if (attr.equals("小")) {
							if (d[6] % 10 < 5) {
								lotterNum = weishu(attr);
							}
						}
						if (attr.equals("单")) {
							if (d[6] % 2 != 0) {
								lotterNum = weishu(attr);
							}
						}
						if (attr.equals("双")) {
							if (d[6] % 2 == 0) {
								lotterNum = weishu(attr);
							}
						}
					}
				}
			}
		}
		return lotterNum;
	}

	/**
	 * 六合彩五行
	   *   方法名：wuxin   
	   *   描述：                       TODO   
	   *   参数：    @param attr
	   *   参数：    @return 
	 * @return: String
	 */
	public String wuxin(String attr) throws Exception{
		String lotterNum = SystemLotter.checkRandomNum4();
		String[] data = lotterNum.split(",");
		int[] d = new int[data.length];
		for (int i = 0; i < data.length; i++) {
			d[i] = Integer.parseInt(data[i]);
		}
		switch (attr) {
		case "jin":
			attr = "金";
			break;
		case "mu":
			attr = "木";
			break;
		case "shui":
			attr = "水";
			break;
		case "huo":
			attr = "火";
			break;
		case "tus":
			attr = "土";
			break;
		}
		/** 五行 */
		CheckOrder orc = new CheckOrder();
		Map<String, Object> maps = orc.attribute2();
		String[] x1 = (String[]) maps.get("attrs");
		String[][] x2 = (String[][]) maps.get("contents");
		for (int i = 0; i < x1.length; i++) {
			for (int j = 0; j < x2[i].length; j++) {
				if (attr.equals(x1[i]) && x2[i][j].equals(data[6])) {
					lotterNum = wuxin(attr);
				}
			}
		}
		return lotterNum;
	}

	/**
	 * 六合彩总肖
	   *   方法名：zongxiao   
	   *   描述：                       TODO   
	   *   参数：    @param attr
	   *   参数：    @return 
	 * @return: String
	 */
	public String zongxiao(String attr) throws Exception{
		String lotterNum = SystemLotter.checkRandomNum4();
		String[] data = lotterNum.split(",");
		int[] d = new int[data.length];
		for (int i = 0; i < data.length; i++) {
			d[i] = Integer.parseInt(data[i]);
		}
		/** 总肖 */
		String[] z1 = { "2肖", "3肖", "4肖", "5肖", "6肖", "7肖" };
		switch (attr) {
		case "erxiao":
			attr = "2肖";
			break;
		case "sanxiao":
			attr = "3肖";
			break;
		case "sixiao":
			attr = "4肖";
			break;
		case "wuxiao":
			attr = "5肖";
			break;
		case "liuxiao":
			attr = "6肖";
			break;
		case "qixiao":
			attr = "7肖";
			break;
		case "dan":
			attr = "单";
			break;
		case "shuang":
			attr = "双";
			break;
		}
		CheckOrder orc = new CheckOrder();
		Map<String, Object> map = orc.attribute1();
		String[] sx1 = (String[]) map.get("attr");
		String[][] sx2 = (String[][]) map.get("content");
		List<Integer> list1 = new ArrayList<Integer>();
		for (int i = 0; i < sx1.length; i++) {
			for (int j = 0; j < sx2[i].length; j++) {
				for (int n = 0; n < data.length; n++) {
					if (sx2[i][j].equals(data[n])) {
						list1.add(i);
					}
				}
			}
		}
		for (int i = 0; i < list1.size() - 1; i++) {
			for (int j = list1.size() - 1; j > i; j--) {
				if (list1.get(j).equals(list1.get(i))) {
					list1.remove(j);
				}
			}
		}
		if (list1.size() > 1) {
			for (int i = 0; i < z1.length; i++) {
				if (z1[i].contains(list1.size() + "") && attr.contains(list1.size() + "")) {
					lotterNum = zongxiao(attr);
				}
			}
		}
		if ((list1.size() % 2 != 0) && (attr.equals("单"))) {
			lotterNum = zongxiao(attr);
		} else if ((list1.size() % 2 == 0) && (attr.equals("双"))) {
			lotterNum = zongxiao(attr);
		}
		return lotterNum;
	}

	/**
	 * 六合彩色波
	   *   方法名：sebo   
	   *   描述：                       TODO   
	   *   参数：    @param attr
	   *   参数：    @return 
	 * @return: String
	 */
	public String sebo(String attr) throws Exception{
		String lotterNum = SystemLotter.checkRandomNum4();
		String[] data = lotterNum.split(",");
		int[] d = new int[data.length];
		for (int i = 0; i < data.length; i++) {
			d[i] = Integer.parseInt(data[i]);
		}
		String[] b1 = { "红", "蓝", "绿" };
		String[][] b2 = {
				{ "01", "02", "07", "08", "12", "13", "18", "19", "23", "24", "29", "30", "34", "35", "40", "45",
						"46" },
				{ "03", "04", "09", "10", "14", "15", "20", "25", "26", "31", "36", "37", "41", "42", "47", "48" },
				{ "05", "06", "11", "16", "17", "21", "22", "27", "28", "32", "33", "38", "39", "43", "44", "49" } };

		switch (attr) {
		case "hongbo":
			attr = "红波";
			break;
		case "lanbo":
			attr = "蓝波";
			break;
		case "lvbo":
			attr = "绿波";
			break;
		}
		for (int i = 0; i < b1.length; i++) {
			for (int j = 0; j < b2[i].length; j++) {
				if (b2[i][j].equals(data[6]) && attr.contains(b1[i])) {
					lotterNum = sebo(attr);
				}
			}
		}
		return lotterNum;
	}

	/**
	 * 六合彩半波
	   *   方法名：banbo   
	   *   描述：                       TODO   
	   *   参数：    @param attr
	   *   参数：    @return 
	 * @return: String
	 */
	public String banbo(String attr) throws Exception{
		String lotterNum = SystemLotter.checkRandomNum4();
		String[] data = lotterNum.split(",");
		int[] d = new int[data.length];
		for (int i = 0; i < data.length; i++) {
			d[i] = Integer.parseInt(data[i]);
		}
		String[] b1 = { "红", "蓝", "绿" };
		String[][] b2 = {
				{ "01", "02", "07", "08", "12", "13", "18", "19", "23", "24", "29", "30", "34", "35", "40", "45",
						"46" },
				{ "03", "04", "09", "10", "14", "15", "20", "25", "26", "31", "36", "37", "41", "42", "47", "48" },
				{ "05", "06", "11", "16", "17", "21", "22", "27", "28", "32", "33", "38", "39", "43", "44", "49" } };
		/** 半波 */
		String[] bb1 = { "红大", "红小", "红单", "红双", "蓝大", "蓝小", "蓝单", "蓝双", "绿大", "绿小", "绿单", "绿双" };

		switch (attr) {
		case "hongda":
			attr = "红大";
			break;
		case "hongxiao":
			attr = "红小";
			break;
		case "hongdan":
			attr = "红单";
			break;
		case "hongshuang":
			attr = "红双";
			break;
		case "landa":
			attr = "蓝大";
			break;
		case "lanxiao":
			attr = "蓝小";
			break;
		case "landan":
			attr = "蓝单";
			break;
		case "lanshuang":
			attr = "蓝双";
			break;
		case "lvda":
			attr = "绿大";
			break;
		case "lvxiao":
			attr = "绿小";
			break;
		case "lvdan":
			attr = "绿单";
			break;
		case "lvshuang":
			attr = "绿双";
			break;
		}
		int a = 0;
		for (int i = 0; i < b1.length; i++) {
			for (int j = 0; j < b2[i].length; j++) {
				if (b2[i][j].equals(data[6])) {
					a = i;
				}
			}
		}
		for (int j = 0; j < bb1.length; j++) {
			if (attr.equals(bb1[j])) {
				if (attr.contains(b1[a])) {
					if (d[6] > 24 && attr.contains("大")) {
						lotterNum = banbo(attr);
					}
					if (d[6] < 25 && attr.contains("小")) {
						lotterNum = banbo(attr);
					}
					if (d[6] % 2 != 0 && attr.contains("单")) {
						lotterNum = banbo(attr);
					}
					if (d[6] % 2 == 0 && attr.contains("双")) {
						lotterNum = banbo(attr);
					}
				}
			}
		}
		return lotterNum;
	}

	/**
	 * 六合彩半半波
	   *   方法名：banbanbo   
	   *   描述：                       TODO   
	   *   参数：    @param attr
	   *   参数：    @return 
	 * @return: String
	 */
	public String banbanbo(String attr) throws Exception{
		String lotterNum = SystemLotter.checkRandomNum4();
		String[] data = lotterNum.split(",");
		int[] d = new int[data.length];
		for (int i = 0; i < data.length; i++) {
			d[i] = Integer.parseInt(data[i]);
		}
		String[] bbb1 = { "红大单", "红大双", "红小单", "红小双", "蓝大单", "蓝大双", "蓝小单", "蓝小双", "绿大单", "绿大双", "绿小单", "绿小双" };
		/** 半波 */
		String[] bb1 = { "红大", "红小", "红单", "红双", "蓝大", "蓝小", "蓝单", "蓝双", "绿大", "绿小", "绿单", "绿双" };

		switch (attr) {
		case "hongdadan":
			attr = "红大单";
			break;
		case "hongdashuang":
			attr = "红大双";
			break;
		case "hongxiaodan":
			attr = "红小单";
			break;
		case "hongxiaoshuang":
			attr = "红小双";
			break;
		case "landadan":
			attr = "蓝大单";
			break;
		case "landashuang":
			attr = "蓝大双";
			break;
		case "lanxiaodan":
			attr = "蓝小单";
			break;
		case "lanxiaoshuang":
			attr = "蓝小双";
			break;
		case "lvdadan":
			attr = "绿大单";
			break;
		case "lvdashuang":
			attr = "绿大双";
			break;
		case "lvxiaodan":
			attr = "绿小单";
			break;
		case "lvxiaoshuang":
			attr = "绿小双";
			break;
		}

		String[] b1 = { "红", "蓝", "绿" };
		String[][] b2 = {
				{ "01", "02", "07", "08", "12", "13", "18", "19", "23", "24", "29", "30", "34", "35", "40", "45",
						"46" },
				{ "03", "04", "09", "10", "14", "15", "20", "25", "26", "31", "36", "37", "41", "42", "47", "48" },
				{ "05", "06", "11", "16", "17", "21", "22", "27", "28", "32", "33", "38", "39", "43", "44", "49" } };

		int a = 0;
		for (int i = 0; i < b1.length; i++) {
			for (int j = 0; j < b2[i].length; j++) {
				if (b2[i][j].equals(data[6])) {
					// 查看开奖号码的颜色
					a = i;
				}
			}
		}
		for (int j = 0; j < bb1.length; j++) {
			// 下注的匹配上半半波中的某个
			if (attr.equals(bbb1[j])) {
				// 下注的包含了中奖的某一个颜色
				if (attr.contains(b1[a])) {
					if (attr.contains("大单")) {
						if (d[6] > 24 && d[6] % 2 != 0) {
							 banbanbo(attr);
						}
					}
					if (attr.contains("大双")) {
						if (d[6] > 24 && d[6] % 2 == 0) {
							 banbanbo(attr);
						}
					}
					if (attr.contains("小单")) {
						if (d[6] < 25 && d[6] % 2 != 0) {
							 banbanbo(attr);
						}
					}
					if (attr.contains("小双")) {
						if (d[6] < 25 && d[6] % 2 == 0) {
							 banbanbo(attr);
						}
					}
				}
			}
		}
		return lotterNum;
	}

	/**
	 * 
	   *   方法名：jnd28Hunhe   
	   *   描述：                       TODO   
	   *   参数：    @param attr
	   *   参数：    @return 
	 * @return: String
	 */
	public String jnd28Hunhe(String attr) {
		String lotterNum = SystemLotter.checkRandomNum5();
		String[] data = lotterNum.split(",");
		int[] d = new int[data.length];
		for (int i = 0; i < data.length; i++) {
			d[i] = Integer.parseInt(data[i]);
		}
		int che = d[0] + d[1] + d[2];
		switch (attr) {
		case "da":
			attr = "大";
			break;
		case "xiao":
			attr = "小";
			break;
		case "dan":
			attr = "单";
			break;
		case "shuang":
			attr = "双";
			break;
		case "dadan":
			attr = "大单";
			break;
		case "dashuang":
			attr = "大双";
			break;
		case "xiaodan":
			attr = "小单";
			break;
		case "xiaoshuang":
			attr = "小双";
			break;
		case "jida":
			attr = "极大";
			break;
		case "jixiao":
			attr = "极小";
		}
			if("大".equals(attr)) {
				if(che>13) {
					 jnd28Hunhe(attr);
				}
			}
			
			if("小".equals(attr)) {
				if(che>13) {
					 jnd28Hunhe(attr);
				}
			}
			
			if("单".equals(attr)) {
				if(che % 2 == 0 ) {
					 jnd28Hunhe(attr);
				}
			}
			if("双".equals(attr)) {
				if(che % 2 != 0 ) {
					 jnd28Hunhe(attr);
				}
			}
			if("大单".equals(attr)) {
				if(che>13 && che % 2 != 0) {
					 jnd28Hunhe(attr);
				}
			}
			if("大双".equals(attr)) {
				if(che>13 && che % 2 == 0) {
					 jnd28Hunhe(attr);
				}
			}
			if("小单".equals(attr)) {
				if(che<13 && che % 2 != 0) {
					 jnd28Hunhe(attr);
				}
			}
			if("小双".equals(attr)) {
				if(che<13 && che % 2 == 0) {
					 jnd28Hunhe(attr);
				}
			}
			if("极大".equals(attr)) {
				switch (che) {
				case 22:
				case 23:
				case 24:
				case 25:
				case 26:
				case 27:
					jnd28Hunhe(attr);
					break;
				}
			}
			if("极小".equals(attr)) {
				switch (che) {
				case 0:
				case 1:
				case 2:
				case 3:
				case 4:
				case 5:
					jnd28Hunhe(attr);
					break;
				}
			}
		return lotterNum;
	}


	/**
	 * 
	   *   方法名：jnd28tema   
	   *   描述：                       TODO   
	   *   参数：    @param cplay
	   *   参数：    @param attr
	   *   参数：    @return 
	 * @return: String
	 */
	public String jnd28tema(String cplay, String attr) {
		String lotterNum = SystemLotter.checkRandomNum5();
		String[] data = lotterNum.split(",");
		int[] d = new int[data.length];
		for (int i = 0; i < data.length; i++) {
			d[i] = Integer.parseInt(data[i]);
		}
		int che = d[0] + d[1] + d[2];
		switch (attr) {
		case "d1q":
			attr = "0";
			break;
		case "d2q":
			attr = "1";
			break;
		case "d3q":
			attr = "2";
			break;
		case "d4q":
			attr = "3";
			break;
		case "d5q":
			attr = "4";
			break;
		case "d6q":
			attr = "5";
			break;
		case "d7q":
			attr = "6";
			break;
		case "d8q":
			attr = "7";
			break;
		case "d9q":
			attr = "8";
			break;
		case "d10q":
			attr = "9";
			break;
		case "d11q":
			attr = "10";
			break;
		case "d12q":
			attr = "11";
			break;
		case "d13q":
			attr = "12";
			break;
		case "d14q":
			attr = "13";
			break;
		case "d15q":
			attr = "14";
			break;
		case "d16q":
			attr = "15";
			break;
		case "d17q":
			attr = "16";
			break;
		case "d18q":
			attr = "17";
			break;
		case "d19q":
			attr = "18";
			break;
		case "d20q":
			attr = "19";
			break;
		case "d21q":
			attr = "20";
			break;
		case "d22q":
			attr = "21";
			break;
		case "d23q":
			attr = "22";
			break;
		case "d24q":
			attr = "23";
			break;
		case "d25q":
			attr = "24";
			break;
		case "d26q":
			attr = "25";
			break;
		case "d27q":
			attr = "26";
			break;
		case "d28q":
			attr = "27";
			break;
		}
		String [] tms1 = {"0","1","2","3","4","5","6","7","8","9","10","11","12","13","14","15","16","17","18","19","20",
				"21","22","23","24","25","26","27"}; 
		switch (cplay) {
		case "tema":
				for(int j=0;j<tms1.length;j++) {
					if(attr.equals(tms1[j])&&attr.equals(che+"")) {
						jnd28Hunhe(attr);
					}
				}
			break;
		case "teb3":
				for(int j=0;j<tms1.length;j++) {
					if(attr.equals(tms1[j])&&attr.equals(che+"")) {
						jnd28Hunhe(attr);
					}
				}
			break;
		}
		return lotterNum;
	}


	/**
	 * 
	   *   方法名：jnd28bs   
	   *   描述：                       TODO   
	   *   参数：    @param attr
	   *   参数：    @return 
	 * @return: String
	 */
	public String jnd28bs(String attr) {
		String lotterNum = SystemLotter.checkRandomNum5();
		String[] data = lotterNum.split(",");
		int[] d = new int[data.length];
		for (int i = 0; i < data.length; i++) {
			d[i] = Integer.parseInt(data[i]);
		}
		//波色
		String [][] bose = {{"1","4","7","10","16","19","22","25"},{"2","5","8","11","17","20","23","26"},{"3","6","9","12","15","18","21","24"}};
		int che = d[0] + d[1] + d[2];
		for(int i=0;i<bose.length;i++) {
			for(int j=0;j<bose[i].length;j++) {
					if(attr.equals(che+"")&&attr.equals(bose[i][j])) {
						jnd28Hunhe(attr);
					}
				}
			}
		return lotterNum;
	}

	/**
	 * 
	   *   方法名：jnd28bz   
	   *   描述：                       TODO   
	   *   参数：    @param attr
	   *   参数：    @return 
	 * @return: String
	 */
	public String jnd28bz(String attr) {
		String lotterNum = SystemLotter.checkRandomNum5();
		String[] data = lotterNum.split(",");
		int[] d = new int[data.length];
		for (int i = 0; i < data.length; i++) {
			d[i] = Integer.parseInt(data[i]);
		}
		if(d[0]==d[1]&&d[0]==d[2]&&d[1]==d[2]) {
			jnd28Hunhe(attr);
		}
		return lotterNum;
	}

}
