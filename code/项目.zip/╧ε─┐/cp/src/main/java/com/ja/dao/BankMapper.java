package com.ja.dao;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.ja.domain.BankCard;
import com.ja.domain.User;

public interface BankMapper {
	
	/**根据id查询当前用户的银行卡信息*/
	BankCard getBankByUid(Integer user_id);
	
	/**添加银行卡信息以及支付密码*/
	int add(@Param(value ="bank") BankCard bank);
	
	/**修改银行卡信息*/
	int upd(@Param("bank") BankCard bank);
	
	/**查询所有的用户的银行卡信息*/
	List<BankCard> getAll();
	
	/**根据用户id和支付密码查询当前用户信息*/
	BankCard checkPass(@Param("zhifupass")String zhifupass, @Param("userid")Integer id);
	
	/**根据用户id查询当前用户*/
	User queryUser(@Param("user")User user);
	
	/**加上赠送金额*/
	int updataUser(@Param("user")User user);
	/**
	 * 查询银行卡
	 * @param str
	 * @return
	 */
	BankCard inquiryBankCard(String str);
}