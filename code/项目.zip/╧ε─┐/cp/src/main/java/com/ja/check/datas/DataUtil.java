package com.ja.check.datas;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.json.JSONArray;
import org.json.JSONObject;
import org.jsoup.Connection;
import org.jsoup.Connection.Response;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.springframework.stereotype.Component;

import com.ja.check.data.SslUtils;
import com.ja.domain.Data;

/**
 * 过滤数据
 * @author Administrator
 *
 *核对
 *kj13322
 *重庆时时彩、北京PK10、重庆快乐十分、天津时时彩、广东11选5、山东11选5、安徽快3、江苏快3、广西快3、上海时时乐
 *新疆时时彩、 广东快乐10分 期号比较特殊 
 *
 *
 */
@Component
public class DataUtil {
	
	/**
	 * 获取开奖数据  c6
	 * @param data
	 * @return
	 */
	int c6;//用于判断这个接口是否还有用
	public Data filterC6(String cName,String URL) {
		String json = getJsonStrUseAgent(URL, 3000);
		Data data = null;
		if(json != null) {
			c6 = 0;
			JSONArray arr = new JSONArray(json);
			JSONObject obj = arr.getJSONObject(0);
			data = new Data();
			//openCode 开奖号
			//uniqueIssueNumber 期号
			//gameUniqueId 彩种名称
			/*System.out.println(obj.get("openCode"));
			System.out.println(obj.get("gameUniqueId"));
			System.out.println(obj.get("uniqueIssueNumber"));*/
			if(!"".equals(String.valueOf(obj.get("uniqueIssueNumber"))) && String.valueOf(obj.get("uniqueIssueNumber")) != null ) {
				SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
				data.setPeriod(String.valueOf(obj.get("uniqueIssueNumber")));
				data.setLotternumber((String)obj.get("openCode")+",");
				data.setCname(cName);
				data.setLottertime(sdf.format(new Date()));
			}
		}else {
			c6++;
			if(c6 >= 100) {
				System.err.println(c6+"c6已经100次以上没有爬到数据了");
			}
		}
		return data;
	}

	/**
	 * 获取开奖数据 
	 * @param data1 kj
	 * @return
	 */
	int kj;
	public Data filterKj(String cName,String URL) {
		String json = getJsonStrUseAgent(URL, 3000);
		Data data = null;
		if(json != null) {
			kj = 0;
			json = "["+json+"]";
			JSONArray arr = new JSONArray(json);
			JSONObject obj = arr.getJSONObject(0);
			data = new Data();
			//issue 期号
			//lotcode 彩种名 
			//predrawcode 开奖号
			//saleissue 期号
			if(cName.equals("xjssc") || cName.equals("gdkl10f")) {
				/**期号转换*/
				SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
				data.setPeriod(periodConversion((String)obj.get("preissue")));
				data.setLotternumber((String)obj.get("predrawcode")+",");
				data.setCname(cName);
				data.setLottertime(sdf.format(new Date()));
			}else {
				SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
				data.setPeriod((String)obj.get("preissue"));
				data.setLotternumber((String)obj.get("predrawcode")+",");
				data.setCname(cName);
				data.setLottertime(sdf.format(new Date()));
			}
		}else {
			kj++;
			if(kj >= 100) {
				System.err.println(kj+"kj已经100次以上没有返回数据了可能接口已经改变");
			}
		}
		return data;
	}
	
	/**
	 * 期号转换
	 * @param str
	 * @return
	 */
	public String periodConversion(String str) {
		StringBuffer sbr = new StringBuffer(str);
		sbr.insert(8, "0");
		return sbr.toString();
	}
	/**
	 * 对期号第一位做处理
	 * @return
	 */
	public String supplement(String str) {
		SimpleDateFormat sdf = new SimpleDateFormat("y");
		return sdf.format(new Date()).substring(0, 2)+str;
	}
	/**
	 * 190308040------数据库里面没有再一期数据------gxk3 
	 * 19030840------数据库里面没有再一期数据------ah11x5 
	 * 190308041------数据库里面没有再一期数据------jsk3	
	 * 2019030842------数据库里面没有再一期数据------gdkl10f
	 * 2019030848------数据库里面没有再一期数据------xjssc
	 * 获取全部开奖数据
	 */
	public List<Data> https1680380(String url){
		String json = getJsonStrUseAgent("https://api.api68.com/lottery/getList.do?name=&lotCode=&pageNo=&pageSize=100", 3000);
		List<Data> list = new ArrayList<Data>();
		if(json != null) {
			json = "["+json+"]";
			JSONArray arr = new JSONArray(json);
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			for (int i = 0; i < arr.length(); i++) {
				JSONObject obj = arr.getJSONObject(i);
				JSONObject obj1 = obj.getJSONObject("result");
				JSONArray obj2 = obj1.getJSONArray("data");
				for (int j = 0; j < obj2.length(); j++) {
					//currentAnalysisIssue 期号
					//name 彩种中文名
					//preDrawCode 开奖号
					if(String.valueOf(obj2.getJSONObject(j).get("currentAnalysisIssue")) != null && obj2.getJSONObject(j).getString("preDrawCode") != null
						&& !"".equals(String.valueOf(obj2.getJSONObject(j).get("currentAnalysisIssue")) )	&& !"".equals(obj2.getJSONObject(j).getString("preDrawCode"))) {
						Data data = new Data();
						String cName = cName(obj2.getJSONObject(j).getString("name"));
						if(cName != null) {
							if("xjssc".equals(cName) || "gdkl10f".equals(cName)) {
								data.setPeriod(periodConversion(String.valueOf(obj2.getJSONObject(j).get("currentAnalysisIssue"))));//期号
							}else if("gxk3".equals(cName) || "ah11x5".equals(cName) || "jsk3".equals(cName)){
								data.setPeriod(supplement(String.valueOf(obj2.getJSONObject(j).get("currentAnalysisIssue"))));//期号
							}else {
								data.setPeriod(String.valueOf(obj2.getJSONObject(j).get("currentAnalysisIssue")));//期号
							}
							data.setLotternumber(obj2.getJSONObject(j).getString("preDrawCode"));//开奖号
							data.setLottertime(sdf.format(new Date()));
							data.setCname(cName);//彩种名
							list.add(data);
						}
					}
				}
			}
		}
		return list;
	}
	/**
	 * 开奖号码转换
	 * @param str
	 * @return
	 */
	public String openingNumberConversion(String str){
		String[] s = str.split(",");
		String openingNumberConversion = "";
		for (int i = 0; i < s.length; i++) {
			if(new Integer(s[i]) < 10) {
				openingNumberConversion+="0"+s[i]+",";
			}else {
				openingNumberConversion+=s[i]+",";
			}
		}
		return openingNumberConversion.trim();
	}
	/**
	 * 获取json数据
	 * @param url：连接
	 * @param timeoutMillis：尝试连接时间
	 * @return
	 */
	public  String getJsonStrUseAgent(String url, int timeoutMillis) {
		try {
			SslUtils.ignoreSsl();
			Response r = Jsoup.connect(url).timeout(timeoutMillis).userAgent(
					"Mozilla/5.0(Macintosh;IntelMacOSX10_7_0)AppleWebKit/535.11(KHTML,likeGecko)Chrome/17.0.963.56Safari/535.11")
					.cookie("auth", "token").ignoreContentType(true).execute();
			return r.body();
		} catch (Exception e) {
		/**	System.out.println("["+DateUtil.getCurrTime()+"] url="+url+"--Exception--"+e.getMessage());
			e.printStackTrace();*/
		}catch (Error e) {
			/**System.out.println("["+DateUtil.getCurrTime()+"] url="+url+"--Error--"+e.getMessage());
			e.printStackTrace();*/
		}
		return null;
	}
	/**
	 * 带参数的请求  可定义post get 请求
	 */
	public void JsoupPost(){
		Connection connect;
		try {
			connect = Jsoup.connect("https://api.api68.com/klsf/getHistoryLotteryInfo.do?date=2019-2-28&lotCode=10009").userAgent(
					"Mozilla/5.0(Macintosh;IntelMacOSX10_7_0)AppleWebKit/535.11(KHTML,likeGecko)Chrome/17.0.963.56Safari/535.11")
					.cookie("auth", "token").ignoreContentType(true);
			// 带参数开始
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
			connect.data("date",sdf.format(new Date()));
			connect.data("lotCode", "10009");
//			connect.data("noloading", "true");
			Document document = connect.post();
					System.out.println(document.toString());
				} catch (IOException e1) {
					e1.printStackTrace();
				};
			}
	
	public String cName(String name) {
		switch (name) {
		case "幸运飞艇":
			return "xyft";
		case "北京PK10":
			return "bjpk10";
		case "天津时时彩":
			return "tjssc";
		case "新疆时时彩":
			return "xjssc";
		case "广东快乐十分":
			return "gdkl10f";
		case "广东11选5":
			return "gd11x5";
		case "江苏快3":
			return "jsk3";
		case "重庆幸运农场":
			return "cqkl10f";
		case "江西11选5":
			return "jx11x5";
		case "安徽11选5":
			return "ah11x5";
		case "上海11选5":
			return "sh11x5";
		case "广西快3":
			return "gxk3";
		case "安徽快3":
			return "ahk3";
		case "北京快3":
			return "bjk3";
		default:
			//System.out.println("没有找到这个彩种----"+name);
			return null;
		}
	}
	/**
	 * 
	 * 
	 * 
	吉林快3
	河北快3
	内蒙古快3
	福建快3
	湖北快3
	 */
	/**
	 * 测试main方法
	 * @param args
	 * @throws ParseException 
	 */
	public static void main(String[] args) {
		SimpleDateFormat sdfE = new SimpleDateFormat("E");
		String whatDayIsToday = sdfE.format(new Date());//今天是星期几
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		SimpleDateFormat sdf1 = new SimpleDateFormat("yyyy-MM-dd");
		String str = "2019-02-26 21:35:20";//设置的基数时间
		String times = " 21:30:00";//开奖时间
		int num = 2019023;//设置的基数
		//604800000 一周的毫秒
		String[] time1 = sdf.format(new Date()).split(" ");
		String period = "";
			try {
				period = String.valueOf((sdf1.parse(time1[0]).getTime() - 
					sdf1.parse(str.split(" ")[0]).getTime())/604800000*3+num+1);
				System.out.println(period+"-----我计算出来的天数");
			} catch (ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	}
}
