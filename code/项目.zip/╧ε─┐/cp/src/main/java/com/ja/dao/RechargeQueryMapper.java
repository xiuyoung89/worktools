package com.ja.dao;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.ja.domain.PayMoney;

public interface RechargeQueryMapper {
	
	/**
	  * 方法名：insertRechargeInfo 
	  * 描述：    保存充值信息                  
	  * 参数：    @param pays
	  * 参数：    @return 
	 * @return: int
	 */
	int insertRechargeInfo(PayMoney pays);
	
	/**
	  * 方法名：getQueryInfo 
	  * 描述：    异步查询充值信息                  
	  * 参数：    @param id 用户id
	  * 参数：    @return 
	 * @return: List<PayMoney>
	 */
	List<PayMoney> getQueryInfo(Integer id);
	
	/**
	  * 方法名：findByIdOrNumRechargeInfo 
	  * 描述：   查询充值处理状态  
	  * 参数：    @param payMoney
	  * 参数：    @return 
	 * @return: PayMoney
	 */
	PayMoney findByIdOrNumRechargeInfo(PayMoney payMoney);

	/**
	  * 方法名：updateRechargeState 
	  * 描述：    修改充值状态                  
	  * 参数：    @param id
	  * 参数：    @param state
	  * 参数：    @param platform
	  * 参数：    @return 
	 * @return: int
	 */
	int updateRechargeState(@Param("id")Integer id, @Param("state")Integer state);
	
}
