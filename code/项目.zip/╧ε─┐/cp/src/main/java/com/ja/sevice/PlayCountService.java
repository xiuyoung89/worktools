package com.ja.sevice;

import com.ja.domain.PlayCount;

public interface PlayCountService {
	
	/**查询当前这一期有没有下注*/
	PlayCount getCplay(PlayCount p);
	
	/**添加下注人数以及金额*/
	int addPlayCount(PlayCount cplay);
	
	/**修改这一期玩法的下注次数*/
	int updatePlayCount(PlayCount p1);

	/**统计这期玩法下注多少*/
	int getCplayCount(String period, String cname);

	
	
	
	
	
}
