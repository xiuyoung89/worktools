package com.ja.sevice;

public interface YunyingJlService {
	
}
