package com.ja.sevice;
import java.util.List;

import com.ja.domain.AdminUser;
import com.ja.domain.KeFuAutomatic;
import com.ja.domain.KeFuChat;
import com.ja.domain.KeFuQuick;

public interface KeFuService {
	
	/**
	 * 查询所有的在线客服
	 * @return
	 */
	List<AdminUser> findAllKeFuUser();

	/**
	 * 根据id查询客服的信息
	 * @param id 客服id
	 * @return
	 */
	AdminUser findByIdAmdinUser(Integer id);
	
	/**
	 * 根据类型查询在线客服的信息
	 * @param type 客服类型
	 * @return
	 */
	List<AdminUser> findByTypeKeFuUser(Integer type);
	
	/**
	 * 添加在线客服的信息
	 * @param admin 客服信息
	 * @return
	 */
	int saveKeFuUser(AdminUser admin);
	
	/**
	 * 修改在线客服的信息
	 * @param chat 客服信息
	 * @return
	 */
	int updateKeFuUser(AdminUser admin);

	/**
	 * 删除在线客服
	 * @param id 客服id
	 * @return
	 */
	int deleteKeFuUser(Integer id);

	/**
	 * 保存客服咨询聊天记录
	 * @param chat 聊天记录信息
	 * @return
	 */
	int saveChatRecord(KeFuChat chat);

	/**
	 * 查询客服咨询聊天记录
	 * @param kefu_id 客服id
	 * @param user_id 用户id
	 * @return
	 */
	List<KeFuChat> findChatRecord(KeFuChat chat);
	
	/**
	 * 查询所有的自动回复
	 * @return
	 */
	List<KeFuAutomatic> findAllKeFuAutomatic();
	
	/**
	 * 根据类型查询自动回复
	 * @param type 回复类型
	 * @return
	 */
	List<KeFuAutomatic> findTypeKeFuAutomatic(Integer type);

	/** 
	 * 添加客服咨询自动回复
	 * @param kefuAutomatic 回复信息
	 * @return
	 */
	int addKeFuAutomatic(KeFuAutomatic kefuAutomatic);

	/** 
	 * 修改客服咨询自动回复
	 * @param kefuAutomatic 回复信息
	 * @return
	 */
	int updateKeFuAutomatic(KeFuAutomatic kefuAutomatic);

	/**
	 * 删除客服咨询自动回复
	 * @param id 删除的id
	 * @return
	 */
	int deleteKeFuAutomatic(Integer id);
	
	/**
	 * 查询所有的快捷回复
	 * @return
	 */
	List<KeFuQuick> findAllKeFuQuick();
	
	/**
	 * 根据类型查询快捷回复
	 * @param type 回复类型
	 * @return
	 */
	List<KeFuQuick> findTypeKeFuQuick(Integer type);
	
	/**
	 * 根据关键类型查询快捷回复
	 * @param type 类型 0客服 1会员
	 * @param keyWord 搜索关键词
	 * @return
	 */
	List<KeFuQuick> findLikeContentType(Integer type,String keyWord);

	/** 
	 * 添加客服咨询快捷回复
	 * @param keFuQuick 回复信息
	 * @return
	 */
	int addKeFuQuick(KeFuQuick keFuQuick);

	/** 
	 * 修改客服咨询快捷回复
	 * @param keFuQuick 回复信息
	 * @return
	 */
	int updateKeFuQuick(KeFuQuick keFuQuick);

	/**
	 * 删除客服咨询快捷回复
	 * @param id 删除的id
	 * @return
	 */
	int deleteKeFuQuick(Integer id);

	/**
	 * 根据id查询客服最近联系人
	 * @param id
	 * @param type 
	 * @return
	 */
	List<KeFuChat> findChatLinkman(Integer id, Integer type);

	/**
	  *  删除最近联系人
	 * @param chat
	 * @return
	 */
	int updateChatStatu(KeFuChat chat);

}