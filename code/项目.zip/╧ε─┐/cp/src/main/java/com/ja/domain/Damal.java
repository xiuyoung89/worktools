package com.ja.domain;

import java.io.Serializable;

public class Damal implements Serializable{
    /**
	 * 
	 */
	private static final long serialVersionUID = 1655719998407303918L;

	private Integer id;//会员打码-提款所需

    private String huiyuanzh;//会员帐号

    private Double damaliang;//变动前提款所需  下注后操作  如果发生退款  要减掉这个的打码量  

    private Double tikuansx;//变动提款所需  暂时没用
    
    private Double new_damaliang;// 最新的打码量   派奖后操作
    
    private String createtime;//创建时间

    private Integer state;//开关

    private Integer userid;//用户id

	public static long getSerialversionuid() {
		return serialVersionUID;
	}
    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getHuiyuanzh() {
        return huiyuanzh;
    }

    public void setHuiyuanzh(String huiyuanzh) {
        this.huiyuanzh = huiyuanzh == null ? null : huiyuanzh.trim();
    }

	public Double getDamaliang() {
		return damaliang;
	}

	public void setDamaliang(Double damaliang) {
		this.damaliang = damaliang;
	}

	public Double getTikuansx() {
		return tikuansx;
	}

	public void setTikuansx(Double tikuansx) {
		this.tikuansx = tikuansx;
	}

	public Double getNew_damaliang() {
		return new_damaliang;
	}
	public void setNew_damaliang(Double new_damaliang) {
		this.new_damaliang = new_damaliang;
	}
	public String getCreatetime() {
		return createtime;
	}

	public void setCreatetime(String createtime) {
		this.createtime = createtime;
	}

	public Integer getState() {
		return state;
	}

	public void setState(Integer state) {
		this.state = state;
	}

	public Integer getUserid() {
		return userid;
	}

	public void setUserid(Integer userid) {
		this.userid = userid;
	}

	public Damal() {
		super();
	}

	@Override
	public String toString() {
		return "Damal [id=" + id + ", huiyuanzh=" + huiyuanzh + ", damaliang=" + damaliang + ", tikuansx=" + tikuansx
				+ ", createtime=" + createtime + ", state=" + state + ", userid=" + userid + "]";
	}


}