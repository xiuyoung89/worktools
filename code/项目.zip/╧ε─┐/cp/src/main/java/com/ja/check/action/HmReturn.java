package com.ja.check.action;

/** 
 * 
 * 合买退钱
 *  
 */

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Map;

import com.ja.util.JdbcUtil;

public class HmReturn {
	public int tuiQian(String qihao, String cpname) {
		JdbcUtil jdbcUtil = new JdbcUtil();
		jdbcUtil.getConnection();
		try {
			SimpleDateFormat ss = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			String p1 = ss.format(new Date());
			String[] cName = { "北京PK拾", "二分PK拾", "幸运飞艇", "幸运赛马", "重庆时时彩", "二分时时彩", "天津时时彩", "新疆时时彩", "广东快乐十分", "重庆快乐十分",
					"安徽11选5", "广东11选5", "江西11选5", "山东11选5", "上海11选5", "香港六合彩", "上海时时乐", "排列三", "福彩3D", "安徽快3", "广西快3",
					"江苏快3", "北京快3", "吉林快3" };
			String[] cName1 = { "bjpk10", "2fpk10", "xyft", "xyusm", "cqssc", "2fssc", "tjssc", "xjssc", "gdkl10f",
					"cqkl10f", "ah11x5", "gd11x5", "jx11x5", "sd11x5", "sh11x5", "xg6hc", "shssl", "pl3", "fc3d",
					"ahd3", "gxk3", "jsk3", "bjk3", "jlk3" };
			String cca = "";
			for (int i = 0; i < cName.length; i++) {
				if (cpname.equals(cName1[i])) {
					cca = cName[i];
				}
			}
			/** 根据期号 */
			String sql1 = "select DISTINCT(orderNum) from cp_joint where ddstate = 1 and tqstate = 0 and qihao =" + "'"
					+ qihao + "'" + " and cpname=" + "'" + cpname + "'";
			List<Map<String, Object>> result1 = jdbcUtil.findResult(sql1, null);
			for (Map<String, Object> map1 : result1) {
				// 这一期的订单号
				String orderNum = map1.get("orderNum").toString();
				String sql2 = "select * from cp_joint where orderNum=" + "'" + orderNum + "'";
				List<Map<String, Object>> result2 = jdbcUtil.findResult(sql2, null);
				for (Map<String, Object> map2 : result2) {
					// 查询余额
					String sql3 = "select * from cp_user where id = " + map2.get("userid");
					List<Map<String, Object>> result3 = jdbcUtil.findResult(sql3, null);
					double yue = Double.parseDouble(result3.get(0).get("balance").toString());
					int state1 = Integer.parseInt(result3.get(0).get("state").toString());
					double thje = Double.parseDouble(map2.get("hMoney").toString());
					double gxyue = yue + thje;
					String sql4 = "update cp_user set balance =" + gxyue + " where id = " + map2.get("userid");
					jdbcUtil.updateByPreparedStatement(sql4, null);
					/** 修改状态 */
					String sql11 = "update cp_joint set tqstate=" + 1 + ",ddstate=" + 2 + ",checkNum=" + "'" + 1 + "'"
							+ " where id=" + Integer.parseInt(map2.get("id").toString());
					jdbcUtil.updateByPreparedStatement(sql11, null);
					/** 添加流水记录 */
					String huiyuanzh = map2.get("user").toString();
					String bdtype = "合买失败";
					String ordernum = map2.get("orderNum").toString();
					String czname = map2.get("user").toString();
					boolean state = true;
					int userid = Integer.parseInt(map2.get("userid").toString());
					String sql5 = "insert into cp_liushui(huiyuanzh,bdtype,bdqjine,bdjine,bdhjine,createtime,ordernum,czname,beizhu,state,userid,period,cname)values"
							+ " (" + "'" + huiyuanzh + "'" + "," + "'" + bdtype + "'" + "," + yue + "," + thje + ","
							+ gxyue + "," + "'" + p1 + "'" + "," + "'" + ordernum + "'" + "," + "" + "'" + czname + "'"
							+ "" + "," + "'" + bdtype + "'" + "," + state + "," + userid + "," + "'" + qihao + "'" + ","
							+ "'" + cca + "'" + "" + ")";
					jdbcUtil.insertByPreparedStatement(sql5, null);
					/** 添加打码量记录 */
					if (state1 != 3 && state1 != 2) {
						/** 添加投注总计 */
						// 投注总计
						String sql6 = "select * from cp_yunyingbb where userid =" + userid;
						List<Map<String, Object>> result4 = jdbcUtil.findResult(sql6, null);
						double touzhuzj = Double.parseDouble(result4.get(0).get("touzhuzj").toString());
						double zhongjiangzj = Double.parseDouble(result4.get(0).get("zhongjiangzj").toString());
						touzhuzj -= thje;
						/** 计算亏盈 */
						double kuiying = touzhuzj - zhongjiangzj;
						String sql7 = "update cp_yunyingbb set touzhuzj=" + touzhuzj + ",yunyingky=" + kuiying
								+ " where userid =" + userid;
						jdbcUtil.updateByPreparedStatement(sql7, null);

						/** 计算打码量 */
						// 打码量总计情况
						String sql8 = "select * from cp_damal where userid =" + userid;
						List<Map<String, Object>> result5 = jdbcUtil.findResult(sql8, null);
						int state2 = Integer.parseInt(result5.get(0).get("state").toString());
						if (state2 == 1) {
							double sycount = Double.parseDouble(result5.get(0).get("damaliang").toString());
							double zycount = sycount - thje;
							double tksx = Double.parseDouble(result5.get(0).get("tikuansx").toString());
							// 打码记录
							String sql9 = "insert into cp_dama(huiyuanzh,bdtype,bdqcount,bdcount,bdhcount,createtime,bdqtksx,bdtksx,bdhtksx,czname,beizhu,userid)values("
									+ "'" + huiyuanzh + "'" + "," + "'" + bdtype + "'" + "," + sycount + "," + thje
									+ "," + zycount + "," + "'" + p1 + "'" + "," + tksx + "," + tksx + "," + tksx + ","
									+ "'" + czname + "'" + "," + "'" + bdtype + "'" + "," + userid + ")";
							jdbcUtil.insertByPreparedStatement(sql9, null);
							// 打码量总计
							String sql0 = "update cp_damal set damaliang=" + zycount + ",createtime=" + "'" + p1 + "'"
									+ " where userid = " + userid;
							jdbcUtil.updateByPreparedStatement(sql0, null);
						}
					}
				}
			}
		} catch (Exception e) {
			System.out.println("合买:" + e);
		} finally {
			jdbcUtil.releaseConn();
		}
		return 1;
	}

}
