package com.ja.sevice.impl;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ja.dao.DamaMapper;
import com.ja.dao.DamalMapper;
import com.ja.dao.FootBallOrderMapper;
import com.ja.dao.LiushuiMapper;
import com.ja.dao.UserMapper;
import com.ja.domain.AdminUser;
import com.ja.domain.Dama;
import com.ja.domain.Damal;
import com.ja.domain.FootBallOrder;
import com.ja.domain.Liushui;
import com.ja.domain.User;
import com.ja.domain.Yunyingbb;
import com.ja.sevice.FootBallOrderService;

@Service
public class FootBllOrderServiceImpl implements FootBallOrderService {

	@Autowired
	private FootBallOrderMapper footBallOrderMapper;

	@Autowired
	private LiushuiMapper liushuiMapper;

	@Autowired
	private UserMapper userMapper;

	@Autowired
	private DamalMapper damalMapper;

	@Autowired
	private DamaMapper damaMapper;

	@Override
	public int addFootBallOrder(FootBallOrder order, User user) {
		SimpleDateFormat ss = new SimpleDateFormat("yyyyMMddHHmmss");
		SimpleDateFormat sf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		AdminUser admin = new AdminUser();
		admin.setName("系统自动");
		flowChange(user, admin, false, order, "L" + ss.format(new Date()), sf.format(new Date()), "足彩投注");
		// 会员的投注总计以及打码
		if (user.getState() == 1) {
			codeRecord(user, order, true, 1, "足彩投注");
		}
		int a = footBallOrderMapper.addFootBallOrder(order);
		return a;
	}

	public int codeRecord(User user, FootBallOrder order, boolean state, int type, String model) {
		SimpleDateFormat sf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		if (user.getState() == 1) {
			Yunyingbb yunyin = new Yunyingbb();
			//YunyingJl record = yunyingJlMapper.findTodayJl(sf.format(new Date()).split(" ")[0]);
			double touzhuzj = 0.00;
			if (type == 1) {
				touzhuzj = yunyin.getTouzhuzj() + order.getAcount();
				yunyin.setTouzhuzj(touzhuzj);
				yunyin.setCpxiazhuzj(yunyin.getXtxiazhuzj() + order.getAcount());
			} else if (type == 2) {
				double zhongjiangzj = yunyin.getZhongjiangzj() + order.getAcount();
				yunyin.setZhongjiangzj(zhongjiangzj);
				yunyin.setCppaijiangzj(yunyin.getCppaijiangzj() + order.getAcount());
			} else {
				touzhuzj = yunyin.getTouzhuzj() - order.getAcount();
				yunyin.setTouzhuzj(touzhuzj);
				yunyin.setCpxiazhuzj(yunyin.getXtxiazhuzj() - order.getAcount());
			}
			yunyin.setCreatetime(sf.format(new Date()));
			//yunyingbbMapper.updatebb(yunyin);
			/** 计算打码量 */
			if (type != 2) {
				Damal damal = damalMapper.getOnedamal(user.getId());
				double count = damal.getDamaliang();
				double need = damal.getTikuansx();
				double counts = 0.00;
				if (state) {
					counts = count + order.getAcount();
				} else {
					counts = count - order.getAcount();
				}
				if (damal.getState() == 1) {
					Dama da = new Dama();
					da.setHuiyuanzh(user.getName());
					da.setBdtype(model);
					da.setBdqcount(count);
					da.setBdcount(order.getAcount());
					da.setBdhcount(counts);
					da.setCreatetime(sf.format(new Date()));
					da.setBdqtksx(need);
					da.setBdtksx(need);
					da.setBdhtksx(need);
					da.setCzname("系统自动");
					da.setBeizhu(model);
					da.setUserid(user.getId());
					damaMapper.addDama(da);
					damal.setDamaliang(counts);
					damal.setCreatetime(sf.format(new Date()));
					damalMapper.updateDamal(damal);
				}
			}
		}
		return 1;
	}

	public int flowChange(User user, AdminUser admin, boolean state, FootBallOrder order, String orderNum, String time,
			String model) {
		user = userMapper.getUserByid(user.getId());
		double amount = 0.00;
		if (state) {
			amount = user.getBalance() + order.getAcount();
		} else {
			amount = user.getBalance() - order.getAcount();
		}
		Liushui flow = new Liushui();
		flow.setHuiyuanzh(user.getName());
		flow.setBdtype(model);
		flow.setBdqjine(user.getBalance());
		flow.setBdjine(order.getAcount());
		flow.setBdhjine(amount);
		flow.setCreatetime(time);
		flow.setOrdernum(orderNum);
		flow.setCname("--");
		flow.setPeriod("--");
		flow.setCzname(admin.getName());
		flow.setBeizhu(model);
		flow.setState(state);
		flow.setStatu(0);
		flow.setUser_type(user.getState());
		flow.setUserid(user.getId());
		liushuiMapper.addUserFlowingWaterRecrod(flow);
		user.setBalance(amount);
		user.setCreatetime(time);
		userMapper.updateUserInfo(user);
		return 1;
	}

	@Override
	public int updateFootBallOrder(FootBallOrder matchRebate) {
		return footBallOrderMapper.updateFootBallOrder(matchRebate);
	}

	@Override
	public List<FootBallOrder> getCheckOrderInfo() {
		return footBallOrderMapper.getCheckOrderInfo();
	}

	@Override
	public FootBallOrder findOrderInfo(Integer id) {
		return footBallOrderMapper.findOrderInfo(id);
	}

	@Override
	public List<FootBallOrder> findOneAllOrder(Integer id) {
		return footBallOrderMapper.findOneAllOrder(id);
	}

	@Override
	public List<FootBallOrder> getCheckOrderSeries() {
		return footBallOrderMapper.getCheckOrderSeries();
	}

	@Override
	public List<FootBallOrder> getCheckOrderSeriesInfo(String order_num) {
		return footBallOrderMapper.getCheckOrderSeriesInfo(order_num);
	}

	@Override
	public int updateFootBallSeries(FootBallOrder order) {
		return footBallOrderMapper.updateFootBallSeries(order);
	}

	@Override
	public int addFootBallSeriesInfo(FootBallOrder fo) {
		return footBallOrderMapper.addFootBallSeriesInfo(fo);
	}

	@Override
	public FootBallOrder getLastMoney(Integer statu) {
		return footBallOrderMapper.getLastMoney(statu);
	}

	@Override
	public int returMoney(FootBallOrder order, User user,boolean state) {
		SimpleDateFormat ss = new SimpleDateFormat("yyyyMMddHHmmss");
		SimpleDateFormat sf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		AdminUser admin = new AdminUser();
		admin.setName("系统自动");
		String model = "";
		int a  =0;
		if(state) {
			model = "足彩派奖";
			a = 2;
		}else {
			model = "足彩退钱";
			a = 3;
		}
		flowChange(user, admin, state, order, "L" + ss.format(new Date()), sf.format(new Date()), model);
		// 会员的投注总计以及打码
		if (user.getState() == 1) {
			codeRecord(user, order, !state, a, model);
		}
		return 0;
	}

}
