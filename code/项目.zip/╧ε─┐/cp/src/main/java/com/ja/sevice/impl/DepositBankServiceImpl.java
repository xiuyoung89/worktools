package com.ja.sevice.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.ja.dao.DepositBankMapper;
import com.ja.domain.DepositBank;
import com.ja.sevice.DepositBankService;

public class DepositBankServiceImpl implements DepositBankService {

	@Autowired
	private DepositBankMapper depositBankMapper;

	/** 查询银行卡信息 */
	@Override
	public List<DepositBank> getAllDepositBank() {
		return depositBankMapper.getAllDepositBank();
	}

	/** 修改银行卡信息 */
	@Override
	public int updateDepositInfo(DepositBank bank) {
		return depositBankMapper.updateDepositInfo(bank);
	}

	/** 添加银行卡信息 */
	@Override
	public int addDepositInfo(DepositBank bank) {
		return depositBankMapper.addDepositInfo(bank);
	}

	 /**删除银行卡信息*/
	@Override
	public int delDepositInfo(Integer id) {
		return depositBankMapper.delDepositInfo(id);
	}

}
