package com.ja.domain;

import java.io.Serializable;

public class LuckyLotter implements Serializable{
	
    /**
	 * 
	 */
	private static final long serialVersionUID = 3457180564078451882L;

	private Integer id;//幸运转盘属性
    
    private String lotterType;//中奖类型

    private String lotterMoney;//奖品内容
    
    private String lotterColour;//中奖判断范围;
    
    private String lotterWords;//中奖判断范围;
    
    private String lotterPicture;//中奖判断范围;
    
    private String createTime;//创建时间

    private Double rebate;//中奖比例
    
    public static long getSerialversionuid() {
		return serialVersionUID;
	}
    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

	public String getLotterType() {
		return lotterType;
	}

	public void setLotterType(String lotterType) {
		this.lotterType = lotterType;
	}

	public String getLotterMoney() {
		return lotterMoney;
	}

	public void setLotterMoney(String lotterMoney) {
		this.lotterMoney = lotterMoney;
	}

	public String getCreateTime() {
		return createTime;
	}

	public void setCreateTime(String createTime) {
		this.createTime = createTime;
	}

	public Double getRebate() {
		return rebate;
	}

	public void setRebate(Double rebate) {
		this.rebate = rebate;
	}
	
	public String getLotterColour() {
		return lotterColour;
	}

	public void setLotterColour(String lotterColour) {
		this.lotterColour = lotterColour;
	}

	public String getLotterWords() {
		return lotterWords;
	}

	public void setLotterWords(String lotterWords) {
		this.lotterWords = lotterWords;
	}

	public String getLotterPicture() {
		return lotterPicture;
	}

	public void setLotterPicture(String lotterPicture) {
		this.lotterPicture = lotterPicture;
	}

	public LuckyLotter() {
		super();
	}

	@Override
	public String toString() {
		return "LuckyLotter [id=" + id + ", lotterType=" + lotterType + ", lotterMoney=" + lotterMoney
				+ ", lotterColour=" + lotterColour + ", lotterWords=" + lotterWords + ", lotterPicture=" + lotterPicture
				+ ", createTime=" + createTime + ", rebate=" + rebate + "]";
	}

}