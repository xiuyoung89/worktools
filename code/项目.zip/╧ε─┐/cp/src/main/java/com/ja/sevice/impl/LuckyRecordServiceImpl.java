package com.ja.sevice.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ja.dao.LuckyCountMapper;
import com.ja.dao.LuckyLotterMapper;
import com.ja.dao.LuckyRecordMapper;
import com.ja.domain.LuckyCount;
import com.ja.domain.LuckyLotter;
import com.ja.domain.LuckyRecord;
import com.ja.sevice.LuckyRecordService;


/**
 * @author GL 幸运大转盘
 * @DATE 2018年1月15日 18:03:40
 */
@Service
public class LuckyRecordServiceImpl implements LuckyRecordService {

	@Autowired
	private LuckyLotterMapper luckyLotterMapper;
	
	@Autowired
	private LuckyRecordMapper luckyRecordMapper;
	
	@Autowired
	private LuckyCountMapper luckyCountMapper;
	
	/**查询所有的奖品属性*/
	@Override
	public List<LuckyLotter> getAllLuckyLotter() {
		return luckyLotterMapper.getAllLuckyLotter();
	}

	/**修改幸运大转盘的属性*/
	@Override
	public int updateLotterData(LuckyLotter lucky) {
		return luckyLotterMapper.updateLotterData(lucky);
	}

	/**添加会员的抽奖信息*/
	@Override
	public int addLuckyRecord(LuckyRecord record) {
		return luckyRecordMapper.addLuckyRecord(record);
	}
	
	/**根据id查询当前用户的抽奖信息*/
	@Override
	public List<LuckyRecord> getOneLuckyRecord(Integer id) {
		return luckyRecordMapper.getOneLuckyRecord(id);
	}

	/**查询所有用户的抽奖记录*/
	@Override
	public List<LuckyRecord> getAllLuckyRecord() {
		return luckyRecordMapper.getAllLuckyRecord();
	}

	/**剩余抽奖次数*/
	@Override
	public LuckyCount getOneLuckyCount(Integer id) {
		return luckyCountMapper.getOneLuckyCount(id);
	}

	/**修改中奖次数*/
	@Override
	public int updateLuckyCount(LuckyCount counts) {
		return luckyCountMapper.updateLuckyCount(counts);
	}

	/**根据id查询信息*/
	@Override
	public LuckyLotter getOneLuckyLotter(Integer id) {
		return luckyLotterMapper.getOneLuckyLotter(id);
	}

	@Override
	public List<LuckyRecord> getMathLuckyRecord() {
		return luckyRecordMapper.getMathLuckyRecord();
	}

	@Override
	public int updateyaojiang(String name,Integer count) {
		LuckyCount counts = luckyCountMapper.inquiringUsersNumberOfAwards(name);
		if(counts == null) {
			return 3;
		}
		counts.setCount(count);
		return luckyCountMapper.updateyaojiang(counts);
	}

	@Override
	public List<LuckyCount> frequency() {
		return luckyCountMapper.frequency();
	}

	@Override
	public LuckyCount frequencyuser(String name) {
		LuckyCount luckyCount = luckyCountMapper.inquiringUsersNumberOfAwards(name);
		System.out.println(luckyCount);
		return luckyCount;
	}

}